import { usb, getDeviceList, findByIds, webusb } from 'usb';


let usbVendorId;
let usbProductId;
let baudRate = 115200;
let filename = "pon/2022-11-02T14-08-48.pon";


const devices = getDeviceList();

// for (const device of devices) {
//     console.log(device); // Legacy device
// }

const device = findByIds(0x0525, 0xA4A2);

const sleep = async (milliseconds) => {
    await new Promise(resolve => {
        return setTimeout(resolve, milliseconds)
    });
};

let port;

usb.on('open', function (data) {
    console.log('Open:', data)
  })



usb.on('attach', function(device) { 

//   vendorId = "5518";
//   productId = "2053";
    
    //console.log( "Device Connected!", device );
    console.log("Device Connected!  vendorId: ", device.deviceDescriptor.idVendor, "productId: ", device.deviceDescriptor.idProduct);

    usbVendorId = parseInt(device.deviceDescriptor.idVendor);
    usbProductId = parseInt(device.deviceDescriptor.idProduct);
    //getIDN()
   

 });

 usb.on('detach', function(device) { 
    
    //console.log( "Device Disconnected", device );
    console.log("Device Disconnected vendorId: ", device.deviceDescriptor.idVendor, "productId: ", device.deviceDescriptor.idProduct);
    //console.log( findByIds(0x0525, 0xA4A2))

 });

//  await 
//  sleep( 20000 );



//---------------------------------------------------------------
  // GET IDN
  //---------------------------------------------------------------
  async function getIDN() {
    let cmdStr = "*IDN?\n";
    let resp = await getData(cmdStr);
    console.log( resp );
  }

  //---------------------------------------------------------------
  // GET File list
  //---------------------------------------------------------------
  async function getFileList() {

    let cmdStr = "STOR:LIST?\n"
    await getData(cmdStr).then ( (resp) => {

        const myfiles = resp.split(",");
        myfiles.forEach((file) => {
          console.log("Result:", file);
        });
    });

  }


  //---------------------------------------------------------------
  // GET a file
  //---------------------------------------------------------------
  async function getDataFile( ) {

    let cmdStr = 'STOR:READ? "' + filename + '",1\n';
     let resp = await getData(cmdStr);
     console.log( resp );
  }

  //---------------------------------------------------------------
  // GET data from instrument
  //---------------------------------------------------------------
  async function getData( cmdStr ) {

    // const usbVendorId = parseInt(vendorId);
    // const usbProductId = parseInt(productId);
    //let navigator = webusb.getWebUsb();

    //---------------
    // get the serial port
    let port = await navigator.serial.requestPort({
      filters: [{ usbVendorId, usbProductId }],
    });

    //---------------
    // open the serial port
    await port.open({ baudRate: baudRate }); // for the MPOLP-85

    //---------------
    // Send  command
    const encoder = new TextEncoder();
    const writer = port.writable.getWriter();
    await writer.ready;
    await writer.write(encoder.encode(cmdStr));
    await writer.close();
    writer.releaseLock();

    //---------------
    // setup for the read
    const reader = port.readable.getReader();

    let textContent = "";
    let inProgress = true;

    // read loop
    while (inProgress) {
      let t1 = new Date();
      await readWithTimeout(reader, 300)
        .then((resp) => {
          let t2 = new Date();
          let delta= t2 - t1;
          console.log("response time ", delta);
          if (resp.value) {
            textContent += new TextDecoder("utf-8").decode(resp.value);
          }
          if (resp.done) {
            console.log("[readLoop] DONE", resp.done);
            inProgress = false;
          }
        })
        .catch(async (err) => {
          //console.log("Final content:", textContent);
          inProgress = false;
          await port.close();
          return textContent;
        });
    }
    return textContent;

  }

  //----------------------------------------------------------------
  async function readWithTimeout(reader, timeout) {
    const timer = setTimeout(() => {
      reader.releaseLock();
    }, timeout);
    const result = await reader.read();
    clearTimeout(timer);
    return result;
  }
