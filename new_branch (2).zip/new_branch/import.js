function handleImport ({target: {files: [file]}}) {
    if (file) {
      const reader = new FileReader();
      reader.onload = ({target: {result}}) => {
        db.bulkDocs(
          JSON.parse(result),
          {new_edits: false}, // not change revision
          (...args) => console.log('DONE', args)
        );
      };
      reader.readAsText(file);
    }
  }
  