export const environment = {
  production: true,
  version: '0.0.7+master.local.2023-10-09',
  paaDate: new Date('2023-05-01T00:00')
}
