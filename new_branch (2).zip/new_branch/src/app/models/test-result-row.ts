export interface TestResultRow {
    Timestamp: string;
    Test: string;
    Location: string;
    Status: string;
    Limit: string;
    device: string;
    id: number;
    technician: string;
}
