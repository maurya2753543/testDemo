export interface ReportInformation {
    title: string;
    company: string;
    technican: string;
    streetAddress: string;
    city: string;
    postalCode: string;
    phone: string;
    email: string;
    companyLogo: string;
}
