import { ProjectProfile } from "./project-profile";
import { ReportInformation } from "./report-information";

export interface UserSettings {
    levelUnits: string;
    distanceUnits: string;
    profile: ProjectProfile;
    reportInformation: ReportInformation;
    columns: any;
}
