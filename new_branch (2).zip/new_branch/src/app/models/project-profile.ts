export interface ProjectProfile {
    name: string;
    levels: string[]; // number, string,
}
