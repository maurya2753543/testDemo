export interface InstrumentOptionsTableData {
    name?: string;
    description?: string;
    optionLicenseType?: string;
    expirationDate?: string;
}
