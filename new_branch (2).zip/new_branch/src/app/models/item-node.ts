export interface ItemNode {
    children: ItemNode[];
    name: string;
    id: string;
    rev: string;
    parent: string;
    projectId: string;
    numResults: number;
}
