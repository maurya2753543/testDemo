import { TestGridCellComponent } from "../components/test-grid-cell/test-grid-cell.component";

export const MAXIMUM_NUMBER = 10;
export const TIER_1_MPO = [
  { field: 'fiberNumberLocal', headerName: $localize`Local`, headerTooltip: $localize`Local` },
  { field: 'fiberNumberRemote', headerName: $localize`Remote`, headerTooltip: $localize`Remote` },
  { field: 'loss', headerName: $localize`Loss(dB)`, headerTooltip: $localize`Loss(dB)` },
  { field: 'lossMarginUpper', headerName: $localize`Loss Margin Upper`, headerTooltip:  $localize`Upper Margin(dB)`},
  { field: 'lossMarginLower', headerName: $localize`Loss Margin Lower`, headerTooltip:  $localize`Lower Margin(dB)` },
  { field: 'lossTestStatus', headerName: $localize`Loss Test Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Status` },
  { field: 'power', headerName: $localize`Power`, headerTooltip:  $localize`Power (dBm)` },
  { field: 'powerReference', headerName: $localize`Power Reference`, headerTooltip:  $localize`Ref (dBm)` },
  { field: 'powerReferenceTime', headerName: $localize`Power Reference Time`, headerTooltip:  $localize`Ref Time` },
  { field: 'signalStatus', headerName: $localize`Signal Status`, headerTooltip:  $localize`Signal Status` }
];

export const TIER_1 = [
  { field: 'loss', headerName: $localize`Loss`, headerTooltip: "Loss(dB)" },
  { field: 'lossMarginUpper', headerName: $localize`Loss Margin Upper`, headerTooltip: $localize`Upper Margin(dB)`},
  { field: 'lossMarginLower', headerName: $localize`Loss Margin Lower`, headerTooltip: $localize`Lower Margin(dB)` },
  { field: 'lossTestStatus', headerName: $localize`Loss Test Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Status` },
  { field: 'power', headerName: $localize`Power`, headerTooltip: $localize`Power (dBm)` },
  { field: 'powerReference', headerName: $localize`Power Reference`, headerTooltip: $localize`Ref (dBm)` },
  { field: 'powerReferenceTime', headerName: $localize`Power Reference Time`, headerTooltip: $localize`Ref Time` },
  { field: 'signalStatus', headerName: $localize`Signal Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Signal Status` }
];

export const OPTICAL_POWER_GRID_1 = [
  { field: 'wavelengthNm', headerName: $localize`Wavelength(Nm)`, headerTooltip:$localize`Wavelength(Nm)`, width: 320 },
  { field: 'absolutePowerdBm', headerName: $localize`Absolute Power(dBm)`, headerTooltip: $localize`power`, width: 330, },
  { field: 'absoluteTestStatus', headerName: $localize`Absolute Test Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`status`, width: 330 }
];

export const OPTICAL_LOSS_GRID_1 = [
  { field: 'wavelengthNm', headerName: $localize`Wavelength`, headerTooltip: $localize`Wavelength` },
  { field: 'lossdB', headerName: $localize`Loss(dB)`, headerTooltip: "loss" },
  { field: 'status', headerName: $localize`Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`status` },
  { field: 'powerReferencedBm', headerName: $localize`Power Reference(dBm)`, headerTooltip: $localize`Reference` },
  { field: 'powerReferenceTime', headerName: $localize`Power Reference Time`, headerTooltip: $localize`RefTimeStamp` }
];

export const OPTICAL_POWER_LOSS_GRID_2 = [
  { field: 'wavelengthNm', headerName: $localize`Wavelength(Nm)`, headerTooltip: $localize`wavelength`, width: 250 },
  { field: 'lowerThresholddBm', headerName: $localize`Lower Threshold(dBm)`, headerTooltip: $localize`low`, width: 250 },
  { field: 'lowerMarginalThresholddBm', headerName: $localize`Lower Marginal Threshold(dBm)`, headerTooltip: $localize`lowMarginal`, width: 250 },
  { field: 'upperMarginalThresholddBm', headerName: $localize`Upper Marginal Threshold(dBm)`, headerTooltip: $localize`highMarginal`, width: 250 },
  { field: 'upperThresholddBm', headerName: $localize`Upper Threshold(dBm)`, headerTooltip: $localize`high`, width: 250 }
];

export const OTDR_GRID = [
  { field: 'wavelength', headerName: $localize`Wavelength(Nm)`, headerTooltip: $localize`Wavelength`, width: 250 },
  { field: 'fiberLength', headerName: $localize`Fiber Length`, headerTooltip: $localize`fiberLength`, width: 250 }
];

export const INSPECTION_GRID = [
  { field: 'name', headerName: $localize`Name`, headerTooltip: $localize`Name`, width: 185 },
  { field: 'passesAll', headerName: $localize`Passes All`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Status`, width: 185 },
  { field: 'passesDefects', headerName: $localize`Passes Defects`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Defect`, width: 222 }
];

export const INSTRUMENT_GRID = [
  { field: 'name', headerName: $localize`Name`, headerTooltip: $localize`Name`, width: 300 },
  { field: 'description', headerName: $localize`Description`, headerTooltip: $localize`Description`, width: 300 },
  { field: 'optionLicenseType', headerName: $localize`Type`, headerTooltip: $localize`Option License Type`, width: 300 },
  { field: 'expirationDate', headerName: $localize `Expiration Date`, headerTooltip: $localize`Expiration Date`, width: 300 }
];

export const EVENT_GRID = [
  { field: 'eventTestStatus', headerName: $localize`Status`, cellRenderer: TestGridCellComponent, headerTooltip: $localize`Status` },
  { field: 'id', headerName: $localize`Id`, headerTooltip: $localize`Id` },
  { field: 'eventType', headerName: $localize`Event Type`, headerTooltip: $localize`Event Type` },
  { field: 'distance', headerName: $localize`Distance`, headerTooltip: $localize`Distance` },
  { field: 'length', headerName: $localize`Length`, headerTooltip: $localize`Length` },
  { field: 'lossdB', headerName: $localize`Loss(dB)`, headerTooltip: $localize`Loss(dB)` },
  { field: 'reflectancedB', headerName: $localize`Reflectance(dB)`, headerTooltip: $localize`Reflectance(dB)` }
];