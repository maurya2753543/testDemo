import * as parts from "./parts.js";
import * as genParams from "./genParams.js";
import * as fixParams from "./fxdParams.js";
import * as supParams from "./supParams.js";
import * as dataPts from "./dataPts.js";
import * as keyEvents from "./keyEvents.js";
import * as cdmBuilder from "./cdmBuilder.js";
import * as dumpEvents from './dumpEvents.js'
import fs from "fs";

export function parseSorToCDM(data) {

  let formatversion = 1;
  let offset = 0;
  let version = 0.0;
  let nBytes = 0;
  let numBlocks = 0;

  let str = parts.get_string(data, offset);
  //console.log(str);
  
  // if str = 'Map' the version is 2 else version 1
  
  if (str == "Map") {
    formatversion = 2;
    offset += str.length + 1; // if version is 1 don't increament offset
  }
  
  // version = 1 byte * 0.1
  version = data.readInt16LE(offset);
  version = (version * 0.01).toFixed(2);
  console.log("version: " + version);
  offset += 2;
  
  // nbytes 2 bytes (little endian)
  nBytes = data.readUInt32LE(offset);
  console.log("numBytes: " + nBytes);
  offset += 4;
  
  numBlocks = data.readInt16LE(offset) - 1;
  console.log("numBlocks: " + numBlocks);
  offset += 2;
  
  // walk thru get the block name, version and size
  let mapBlock = [];
  let startPos = nBytes;
  for (let i = 0; i < numBlocks; i++) {
    let bname = parts.get_string(data, offset);
    offset += bname.length + 1;
    let bver = (data.readInt16LE(offset) * 0.01).toFixed(2);
    offset += 2;
    let bsize = data.readUInt32LE(offset);
    offset += 4;
  
    mapBlock[i] = { name: bname, version: bver, size: bsize, startPos: startPos };
  
    startPos += bsize;
  }
  
  for (let i = 0; i < numBlocks; i++) {
    console.log(
      mapBlock[i].name.padEnd(25) +
        "\tOffset: 0x" +
        mapBlock[i].startPos.toString(16) +
        "\tVer: " +
        mapBlock[i].version +
        "  Size: " +
        mapBlock[i].size.toString().padStart(4)
    );
  }
  
  let gp = genParams.parseGenParams(data, mapBlock[0].startPos);
  let sp = supParams.parseSupParams(data, mapBlock[1].startPos);
  let fp = fixParams.parseFixParams(data, mapBlock[2].startPos);
  
  
  let dp = dataPts.parseDataPoints(data, getMapBlockOffset('DataPts', mapBlock), fp);
  
  let ke = keyEvents.parseKeyEvents(data, getMapBlockOffset('KeyEvents', mapBlock), fp.index);
  //console.log( ke );

  //dumpEvents.writeToCSV( ke, "myEvents");

  
  let cdm = cdmBuilder.createCDM( gp, sp, fp, dp, ke );
  //const jsonStr = JSON.stringify(cdm, null, 2);
  
  return cdm


}

function getMapBlockOffset( name, mapBlock ) {
    for (let i = 0; i < mapBlock.length; i++ ) {
        if( mapBlock[i].name == name ) {
            return mapBlock[i].startPos;
        }
    }
}
