import * as parts from './parts.js'

const showDebug = false;
function logger( value ) {
    if( showDebug ) {
        console.log( value );
    }
}

export function parseDataPoints(data, offset, fxdParams) { 

    let namePad = 25;

    let dx = fxdParams.resolution;




    logger("-----------------------------------------");
    var str = parts.get_string( data, offset);
    logger( str );
    logger("-----------------------------------------");
    offset += str.length + 1;


    let N = data.readUInt32LE(offset);
    logger( "Number of points: ".padEnd(namePad) + N);
    offset += 4;

    let numTraces = data.readInt16LE( offset );
    logger( "Number of traces: ".padEnd(namePad) + numTraces);
    offset += 2;

    let N2 = data.readUInt32LE(offset);
    logger( "Number of points: ".padEnd(namePad) + N2);
    offset += 4;



    let scalingFactor = data.readUInt16LE( offset );
    scalingFactor = scalingFactor / 1000.0;
    logger( "scalingFactor: ".padEnd(namePad) + scalingFactor);
    offset += 2;



    // .....................................
    // adjusted resolution
    //var dx = results['FxdParams']['resolution'];
    let dlist = [];
    let nlist = [];
    for(let i=0; i<N; i++) {
        let val = data.readUInt16LE( offset );
        offset += 2;
        dlist.push(val)
    }

    //logger( dlist );
    
    let ymax = Math.max.apply( Math, dlist );
    let ymin = Math.min.apply( Math, dlist );
    let fsx = 0.001 * scalingFactor;
    let disp_min = (ymin * fsx).toFixed(3);
    let disp_max = (ymax * fsx).toFixed(3);
    // xref['max before offset'] = parseFloat(disp_max);
    // xref['min before offset'] = parseFloat(disp_min);

    logger( "data point read: ".padEnd(namePad) + dlist.length + "|  ymax: " + disp_max + "| ymin: " + disp_min);







    // .........................................
    // save to file
    var offsetType = 'STV';   // todo check model for OFL250 and set xscaling to 0.1 
    var xscaling = 1;
    
    // convert/scale to dB
    if (offsetType == 'STV') {
        nlist = dlist.map( function(x) { return (ymax - x )*fsx; } );
    }else if (offsetType == 'AFL') {
        nlist = dlist.map( function(x) { return (ymin - x )*fsx; } );
    }else{ // invert
        nlist = dlist.map( function(x) { return (-x*fsx); } );
    }

    var tracedata = [];
    for(let i=0; i<N; i++) {
        // more work but (maybe) less rounding issues
        let x = dx*i*xscaling / 1000.0 // output in km
        let pt = { x : parseFloat(x).toFixed(6), y: parseFloat(nlist[i]).toFixed(6) }
        //tracedata.push( `${parseFloat(x).toFixed(6)}, ${parseFloat(nlist[i]).toFixed(6)}` );
        tracedata.push( pt );
    }

    return tracedata;




}

var sep = "    :";

var process = (async function(fh, results, tracedata, logger, errlog, debug=false)
{
    var bname = "DataPts";
    var hsize = bname.length + 1; // include trailing '\0'
    var pname = "datapts.process():"
    var ref = null;
    var status = 'nok'

    try {
        ref = results['blocks'][bname];
        startpos = ref['pos'];
        // awake fh.seek( startpos );
    }catch(e){
        errlog( pname+" "+bname+"block starting position unknown");
        return status;
    }

    format = results['format'];
    
    if (format == 2) {
        var mystr = "";// awake parts.get_string(fh, hsize);

        if ( mystr != bname ) {
            errlog(pname+" incorrect header '"+mystr+"' vs '"+bname+"'");
	    return status;
	}
    }
    
    results[bname] = {};
    var xref = results[bname];

    // extra parameters
    xref['_datapts_params'] = { 'xscaling': 1, 'offset': 'STV' };
    // method used by STV: minimum reading shifted to zero
    // method used by AFL/Noyes Trace.Net: maximum reading shifted to zero (approx)

    status = "";// awake process_data(fh, results, tracedata, logger, errlog, debug);
    
    return status;
});

// ================================================================
var process_data = (async function(fh, results, tracedata, logger, errlog, debug) {
    
    var bname = "DataPts";
    var xref  = results[bname];

    try {
        // we assume SupParams block already processed
        model = results['SupParams']['OTDR'];
    }catch(e) {
        model = "";
    }
    
    // special case:
    // old Noyes/AFL OFL250 model is off by factor of 10
    if (model == 'OFL250') {
        xref['_datapts_params']['xscaling'] = 0.1;
    }
    if (debug) {
        logger(`${sep} [initial 12 byte header follows]`);
    }

    var N = "";// awake parts.get_uint(fh, 4);
    // confirm N equal to FxdParams num data points
    if ( N != results['FxdParams']['num data points'] ) {
        errlog("!!! WARNING !!! block says number of data points "+
               `is ${N} instead of ${results['FxdParams']['num data points']}`);
    }
    
    xref['num data points'] = N;
    if (debug) {
        logger(`${sep} num data points = ${N}`);
    }
    
    var val = // awake parts.get_signed(fh, 2);
    xref['num traces'] = val;
    if (debug) {
        logger(`${sep} number of traces = ${val}`);
    }

    if ( val > 1 ) {
        errlog(`WARNING!!!: Cannot handle multiple traces (${val}); aborting`);
        process.exit(1);
    }

    val = // awake parts.get_uint(fh, 4);
    xref['num data points 2'] = val;
    if (debug) {
        logger(`${sep} num data points again = ${val}`);
    }

    val = ""; // awake parts.get_uint(fh, 2);
    var scaling_factor = val / 1000.0;
    xref['scaling factor'] = scaling_factor;
    if (debug) {
        logger(`${sep} scaling factor = ${parseFloat(scaling_factor)}`);
    }

    // .....................................
    // adjusted resolution
    var dx = results['FxdParams']['resolution'];
    var dlist = [];
    for(var i=0; i<N; i++) {
        val = // awake parts.get_uint(fh, 2);
        dlist.push(val)
    }
    
    var ymax = Math.max.apply( Math, dlist );
    var ymin = Math.min.apply( Math, dlist );
    var fsx = 0.001* scaling_factor;
    var disp_min = (ymin * fsx).toFixed(3);
    var disp_max = (ymax * fsx).toFixed(3);
    xref['max before offset'] = parseFloat(disp_max);
    xref['min before offset'] = parseFloat(disp_min);
    
    if (debug) {
        logger(`${sep} before applying offset: max ${disp_max} dB, min ${disp_min} dB`);
    }    

    // .........................................
    // save to file
    var offset = xref['_datapts_params']['offset'];
    var xscaling = xref['_datapts_params']['xscaling'];
    
    // convert/scale to dB
    if (offset == 'STV') {
        nlist = dlist.map( function(x) { return (ymax - x )*fsx; } );
    }else if (offset == 'AFL') {
        nlist = dlist.map( function(x) { return (ymin - x )*fsx; } );
    }else{ // invert
        nlist = dlist.map( function(x) { return (-x*fsx); } );
    }

    for(let i=0; i<N; i++) {
        // more work but (maybe) less rounding issues
        let x = dx*i*xscaling / 1000.0 // output in km
        tracedata.push( `${parseFloat(x).toFixed(6)}\t${parseFloat(nlist[i]).toFixed(6)}` );
    }
    
    // .........................................
    status = 'ok';
    
    return status;
});


/* =====================================================================
 * export this as a module
 * =====================================================================
 */
// var DataPts = function()
// {
//     this.process = process;
// }

// module.exports = DataPts;
