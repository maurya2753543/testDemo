import * as parts from './parts.js'

const showDebug = false;
function logger( value ) {
    if( showDebug ) {
        console.log( value );
    }
}

export function parseKeyEvents(data, offset, indexOfRefraction ) { 

    let namePad = 25;
    let distanceUnitsCorrection = 1000.0;
    const factor = (1e-4 * parts.sol / indexOfRefraction) * distanceUnitsCorrection;

    //logger( parts.sol, indexOfRefraction, factor)

    logger("-----------------------------------------");
    var str = parts.get_string( data, offset);
    logger( str.padEnd(namePad) + "factor: " + factor );
    logger("-----------------------------------------");
    offset += str.length + 1;

    let format = 2;

    

    let numEvents = data.readInt16LE( offset );
    //fiberType = (version * 0.01).toFixed(2);
    logger( "Number of Events: ".padEnd(namePad) + numEvents);
    offset += 2;

    let eventArray = []

    for(let j=0; j<numEvents; j++) {
        //var x2ref = xref[`event ${1+j}`] = {};

        
        
        // var xid  = // awake parts.get_uint(fh, 2);            // 00-01: event number
        let eventsId = data.readUInt16LE( offset );
        logger( "Events Id: ".padEnd(namePad) + eventsId);
        offset += 2;

        // var dist = // awake parts.get_uint(fh, 4) * factor;   // 02-05: time-of-travel; need to convert to distance
        let dist = data.readUInt32LE(offset) * factor;
        logger( "distance: ".padEnd(namePad) + dist.toFixed(3));
        offset += 4;

        // var slope  = // awake parts.get_signed(fh, 2) * 0.001; // 06-07: slope
        let slope = data.readInt16LE( offset ) * 0.001;
        logger( "Slope: ".padEnd(namePad) + slope);
        offset += 2;

        // var splice = // awake parts.get_signed(fh, 2) * 0.001; // 08-09: splice loss
        let spliceLoss = data.readInt16LE( offset ) * 0.001;
        logger( "Splice loss: ".padEnd(namePad) + spliceLoss.toFixed(3));
        offset += 2;

        // var refl   = // awake parts.get_signed(fh, 4) * 0.001; // 10-13: reflection loss
        let refl = data.readInt32LE(offset) * 0.001;
        logger( "Reflection Loss: ".padEnd(namePad) + refl.toFixed(3));
        offset += 4;
         
        // var xtype = // awake fh.readString(8);                 // 14-21: event type
        var lang = parts.get_stringFixed( data, offset, 8);

        let eventType;
        let code = lang.charAt(0);
        switch( code ) {
            case "0":
                eventType = "Splice";
                break;
            case "1":
                eventType = "Reflectance";
                break;
            case "2":
                eventType = "Multiple";
                break;
            default:
                eventType = "Unknown";
        }


        logger( "Event Type: ".padEnd(namePad) + lang + "  " + eventType );
        offset += 8;

        let end_prev;
        let start_curr;
        let end_curr;
        let start_next;
        let pkpos;

        if (format == 2) {  
            // var end_prev   = // awake parts.get_uint(fh, 4) * factor; // 22-25: end of previous event
            end_prev = data.readUInt32LE(offset) * factor;
            logger( "End Prev: ".padEnd(namePad) + end_prev.toFixed(3));
            offset += 4;

            // var start_curr = // awake parts.get_uint(fh, 4) * factor; // 26-29: start of current event
            start_curr = data.readUInt32LE(offset) * factor;
            logger( "Start Current: ".padEnd(namePad) + start_curr.toFixed(3));
            offset += 4;

            // var end_curr   = // awake parts.get_uint(fh, 4) * factor; // 30-33: end of current event
            end_curr = data.readUInt32LE(offset) * factor;
            logger( "End Current: ".padEnd(namePad) + end_curr.toFixed(3));
            offset += 4;

            // var start_next = // awake parts.get_uint(fh, 4) * factor; // 34-37: start of next event
            start_next = data.readUInt32LE(offset) * factor;
            logger( "Start Next: ".padEnd(namePad) + start_next.toFixed(3));
            offset += 4; 
            

            // var pkpos      = // awake parts.get_uint(fh, 4) * factor; // 38-41: peak point of event
            pkpos = data.readUInt32LE(offset) * factor;
            logger( "Peak Point: ".padEnd(namePad) + pkpos.toFixed(3));
            offset += 4; 
	    }

        let event = {
            "eventId" : eventsId,
            "dist" : dist,
            "slope" : slope,
            "spliceLoss" : spliceLoss,
            "refl" : refl,
            "lang" : lang,
            "end_prev" : end_prev,
            "start_curr" : start_curr,
            "end_curr" : end_curr,
            "start_next" : start_next,
            "pkpos" : pkpos
    
        }
        eventArray.push( event );
    
        //var comments = // awake parts.get_string(fh);
        let comments = parts.get_string( data, offset);
        logger( "Comments: ".padEnd(namePad) + comments );
   
        offset += comments.length + 1;


        logger( "----------\n");
    }
    return eventArray;
}

var sep = "    :";

function process(fh, results, logger, errlog, debug=false)
{
    var bname = "KeyEvents";
    var hsize = bname.length + 1; // include trailing '\0'
    var pname = "keyevents.process():"
    var ref = null;
    var status = 'nok'

    try {
        ref = results['blocks'][bname];
        startpos = ref['pos'];
        // awake fh.seek( startpos );
    }catch(e){
        errlog( pname+" "+bname+"block starting position unknown");
        return status;
    }

    format = results['format'];
    
    if (format == 2) {
        var mystr = "";// awake parts.get_string(fh, hsize);

        if ( mystr != bname ) {
            errlog(pname+" incorrect header '"+mystr+"' vs '"+bname+"'");
	    return status;
	}
    }
    
    results[bname] = {};
    var xref = results[bname];

    status = "";// awake process_keyevents(fh, format, results, logger, errlog, debug);

    // read the rest of the block (just in case)
    /*
    var endpos = results['blocks'][bname]['pos'] + results['blocks'][bname]['size'];
    // awake fh.read( endpos - (// awake fh.tell()) );
    status = 'ok';
    */
    return status;
}

// ================================================================
function process_keyevents(fh, format, results, logger, errlog, debug) {
    // process version 1 or 2 format
    var bname = "KeyEvents";
    var xref  = results[bname];
    
    // number of events
    var nev = "";// awake parts.get_uint(fh, 2);
    if ( debug ) {
	logger(`${sep} ${nev} events`);
    }
    xref['num events'] = nev;
    
    var factor = 1e-4 * parts.sol / parseFloat(results['FxdParams']['index']);
    
    var pat = "(.)(.)9999LS";

    for(let j=0; j<nev; j++) {
        var x2ref = xref[`event ${1+j}`] = {};
        
        // var xid  = // awake parts.get_uint(fh, 2);            // 00-01: event number
        // var dist = // awake parts.get_uint(fh, 4) * factor;   // 02-05: time-of-travel; need to convert to distance
        
        // var slope  = // awake parts.get_signed(fh, 2) * 0.001; // 06-07: slope
        // var splice = // awake parts.get_signed(fh, 2) * 0.001; // 08-09: splice loss
        // var refl   = // awake parts.get_signed(fh, 4) * 0.001; // 10-13: reflection loss
        
        // var xtype = // awake fh.readString(8);                 // 14-21: event type
	
	var mresults = xtype.match(pat);
	if ( mresults != null ) {
	    var subtype = mresults[1];
	    var manual  = mresults[2];

            if (manual == 'A') {
                xtype += " {manual}";
	    }else{
                xtype += " {auto}";
            }
            if (subtype == '1') {
                xtype += " reflection";
	    }else if (subtype == '0') {
                xtype += " loss/drop/gain";
	    }else if (subtype == '2') {
                xtype += " multiple";
	    }else{
                xtype += " unknown '"+subtype+"'";
	    }
	}else{
            xtype += " [unknown type "+xtype+"]";
	}
	
        if (format == 2) {
            // var end_prev   = // awake parts.get_uint(fh, 4) * factor; // 22-25: end of previous event
            // var start_curr = // awake parts.get_uint(fh, 4) * factor; // 26-29: start of current event
            // var end_curr   = // awake parts.get_uint(fh, 4) * factor; // 30-33: end of current event
            // var start_next = // awake parts.get_uint(fh, 4) * factor; // 34-37: start of next event
            // var pkpos      = // awake parts.get_uint(fh, 4) * factor; // 38-41: peak point of event
	}

        var comments = // awake parts.get_string(fh);
        
        x2ref['type'] = xtype;
        x2ref['distance'] = dist.toFixed(3);
        x2ref['slope'] = slope.toFixed(3);
        x2ref['splice loss'] = splice.toFixed(3);
        x2ref['refl loss'] = refl.toFixed(3);
        x2ref['comments'] = comments;

        if (format == 2) {
            x2ref['end of prev'] = end_prev.toFixed(3);
            x2ref['start of curr'] = start_curr.toFixed(3);
            x2ref['end of curr'] = end_curr.toFixed(3);
            x2ref['start of next'] = start_next.toFixed(3);
            x2ref['peak'] = pkpos.toFixed(3);
	}

        if (debug) {
            logger(`${sep} Event ${xid}: type ${xtype}`);
            logger(`${sep}${sep} distance: ${dist.toFixed(3)} km`);
            logger(`${sep}${sep} slope: ${slope.toFixed(3)} dB/km`);
            logger(`${sep}${sep} splice loss: ${splice.toFixed(3)} dB`);
            logger(`${sep}${sep} refl loss: ${refl.toFixed(3)} dB`);
	    
	    // version 2
            if (format == 2) {
                logger(`${sep}${sep} end of previous event: ${end_prev.toFixed(3)} km`);
                logger(`${sep}${sep} start of current event: ${start_curr.toFixed(3)} km`);
                logger(`${sep}${sep} end of current event: ${end_curr.toFixed(3)} km`);
                logger(`${sep}${sep} start of next event: ${start_next.toFixed(3)} km`);
                logger(`${sep}${sep} peak point of event: ${pkpos.toFixed(3)} km`);
	    }

	    // common
            logger(`${sep}${sep} comments: ${comments}`);
	}
    }
    // ...................................................
    // var total      = // awake parts.get_signed(fh, 4) * 0.001;  // 00-03: total loss
    // var loss_start = // awake parts.get_signed(fh, 4) * factor; // 04-07: loss start position
    // var loss_finish= // awake parts.get_uint(fh, 4) * factor;   // 08-11: loss finish position
    // var orl        = // awake parts.get_uint(fh, 2) * 0.001;    // 12-13: optical return loss (ORL)
    // var orl_start  = // awake parts.get_signed(fh, 4) * factor; // 14-17: ORL start position
    // var orl_finish = // awake parts.get_uint(fh, 4) * factor;   // 18-21: ORL finish position
    
    if (debug) {
        logger(`${sep} Summary:`);
        logger(`${sep}${sep} total loss: ${total.toFixed(3)} dB`);
        logger(`${sep}${sep} ORL: ${orl.toFixed(3)} dB`);
        logger(`${sep}${sep} loss start: ${loss_start} km`);
        logger(`${sep}${sep} loss end: ${loss_finish} km`);
        logger(`${sep}${sep} ORL start: ${orl_start} km`);
        logger(`${sep}${sep} ORL finish: ${orl_finish} km`);
    }

    var x3ref = xref["Summary"] = {};
    x3ref["total loss"] = parseFloat( total.toFixed(3) );
    x3ref["ORL"]        = parseFloat( orl.toFixed(3) );
    x3ref["loss start"] = parseFloat( loss_start.toFixed(6) );
    x3ref["loss end"]   = parseFloat( loss_finish.toFixed(6) );
    x3ref["ORL start"]  = parseFloat( orl_start.toFixed(6) );
    x3ref["ORL finish"] = parseFloat( orl_finish.toFixed(6) );
    
    // ................
    status = 'ok';
    return status;
}

/* =====================================================================
 * export this as a module
 * =====================================================================
 */
// var KeyEvents = function()
// {
//     this.process = process;
// }

// module.exports = KeyEvents;
