import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import * as parts from './otdr-sor-parser/parts'
import * as genParams from "./otdr-sor-parser/genParams.js";
import * as fixParams from "./otdr-sor-parser/fxdParams.js";
import * as supParams from "./otdr-sor-parser/supParams.js";
import * as dataPts from "./otdr-sor-parser/dataPts.js";
import * as keyEvents from "./otdr-sor-parser/keyEvents.js";
var Buffer = require('buffer/').Buffer


@Injectable({
  providedIn: 'root'
})
export class OtdrSorService {

  constructor() { }


  showDebug = false;
    logger( value:string ) {
    if( this.showDebug ) {
        console.log( value );
    }
    }


  parseSorToCDM(content:any) : any{

    //var data = require('buffer/').Buffer;

    let data: Buffer = Buffer.from(content)

    let formatversion = 1;
    let offset = 0;
    let version = "0.0";
    let nBytes = 0;
    let numBlocks = 0;
  
    let str = parts.get_string(data, offset);
    //this.logger(str);
    
    // if str = 'Map' the version is 2 else version 1
    
    if (str == "Map") {
      formatversion = 2;
      offset += str.length + 1; // if version is 1 don't increament offset
    }
    
    // version = 1 byte * 0.1
    let ver = data.readInt16LE(offset);
    version = (ver * 0.01).toFixed(2);
    this.logger("version: " + version);
    offset += 2;
    
    // nbytes 2 bytes (little endian)
    nBytes = data.readUInt32LE(offset);
    this.logger("numBytes: " + nBytes);
    offset += 4;
    
    numBlocks = data.readInt16LE(offset) - 1;
    this.logger("numBlocks: " + numBlocks);
    offset += 2;
    
    // walk thru get the block name, version and size
    let mapBlock = [];
    let startPos = nBytes;
    for (let i = 0; i < numBlocks; i++) {
      let bname = parts.get_string(data, offset);
      offset += bname.length + 1;
      let bver = (data.readInt16LE(offset) * 0.01).toFixed(2);
      offset += 2;
      let bsize = data.readUInt32LE(offset);
      offset += 4;
    
      mapBlock[i] = { name: bname, version: bver, size: bsize, startPos: startPos };
    
      startPos += bsize;
    }
    
    for (let i = 0; i < numBlocks; i++) {
      this.logger(
        mapBlock[i].name.padEnd(25) +
          "\tOffset: 0x" +
          mapBlock[i].startPos.toString(16) +
          "\tVer: " +
          mapBlock[i].version +
          "  Size: " +
          mapBlock[i].size.toString().padStart(4)
      );
    }
    
    let gp = genParams.parseGenParams(data, mapBlock[0].startPos);
    let sp = supParams.parseSupParams(data, mapBlock[1].startPos);
    let fp = fixParams.parseFixParams(data, mapBlock[2].startPos);
    
    
    let dp = dataPts.parseDataPoints(data, this.getMapBlockOffset('DataPts', mapBlock), fp);
    
    let ke = keyEvents.parseKeyEvents(data, this.getMapBlockOffset('KeyEvents', mapBlock), fp.index);
    //this.logger( ke );
  
    //dumpEvents.writeToCSV( ke, "myEvents");
  
    
    let cdm = this.createCDM( gp, sp, fp, dp, ke );
    //const jsonStr = JSON.stringify(cdm, null, 2);
    
    return cdm;
  
  
  }
  
 getMapBlockOffset( name:any, mapBlock:any ) {
      for (let i = 0; i < mapBlock.length; i++ ) {
          if( mapBlock[i].name == name ) {
              return mapBlock[i].startPos;
          }
      }
  }





//-----------------------------------------------------------------------
createCDM( gp:any, sp:any, fp:any, dp:any, ke:any ) {

    //this.logger( dp );


    let cdm = {
        "cdmVersion" : "2.2",
        "workflow" : {
            "type": "viaviJob",
        },
        "assetInfo" : {
        },
        "tests" : []
    }

    // ------------------------------------------------------------
    // Populate the assetInfo block
    _.set( cdm, 'assetInfo.assetType', sp.OTDR);
    _.set( cdm, 'assetInfo.manufacturer', sp.supplier);
    _.set( cdm, 'assetInfo.uniqueId', sp.OTDR + '_' + sp.OTDR_SN);

    let modulesInfo = [];
    let myModule = { 
        "assetType": sp.module,
        "uniqueId": sp.module + '_' +sp.module_SN,
        "model": sp.module,
        "swVersion": sp.software    
    }
    modulesInfo.push(myModule );

    _.set( cdm, 'assetInfo.modulesInfo', modulesInfo);
 
    // ------------------------------------------------------------
    // Populate the tests block
    let tests = [];
    let myTest = {
        "type": "OTDR",
        "label": "OTDR",
        "schemaVersion": "1.5.0",
        "configuration" : {}, 
    }

    _.set( myTest, 'results.status', "PASS");
    _.set( myTest, 'results.testTime', fp.timestamp );
    _.set( myTest, 'results.comment', "");


    _.set( myTest, 'results.data.otdrResults.distanceUnits', fp.unit);

    let measuredResults = [];
    let meas = {};

    let events = [];
    let totalLength;
    let totalLengthM;
    let totalLoss = 0.0;
    let totalORL = 0.0;


    const connectorlossMax = 0.5;
    const splicelossMax = 0.3;
    const reflectanceMax = -35.0;
    const slopeMax = 1.00;

    let distanceOffset = ke[0].dist.toFixed(3)
    
    for(const element of ke) {

        

        let event = {};
        _.set( event, "id", element.eventId );
        _.set( event, "distance", (element.dist - distanceOffset).toFixed(3) );
        _.set( event, "distanceM", (element.dist - distanceOffset).toFixed(3) ); 
        _.set( event, "reflectancedB", element.refl.toFixed(3) ); 
        _.set( event, "lossdB", element.spliceLoss.toFixed(3) ); 

        let eventType;
        let code = element.lang.charAt(0);
        switch( code ) {
            case "0":
                eventType = "Splice";
                break;
            case "1":
                eventType = "Reflectance";
                break;
            case "2":
                eventType = "Multiple";
                break;
            default:
                eventType = "Unknown";
        }

        let eventTestStatus = "PASS";
        let lossAlarmFailed = false;
        let reflAlarmFailed = false;
        let slopeAlarmFailed = false;

        if( eventType == "Splice" ) {
            if( element.spliceLoss > splicelossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        } else {
            if( element.spliceLoss > connectorlossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
            if( element.refl > reflectanceMax) {
                reflAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        }
       
        if( element.slope > slopeMax ) {
            slopeAlarmFailed = true;
            eventTestStatus = "FAIL";
        }
        


        _.set( event, "eventType", eventType); 
        _.set( event, "eventTestStatus", "PASS" ); 
        _.set( event, "sectionLength", (element.start_next - element.start_curr).toFixed(3) ); 
        _.set( event, "sectionLengthM", (element.start_next - element.start_curr).toFixed(3) ); 
        _.set( event, "slope", element.slope.toFixed(3) );
        _.set( event, "lossAlarmFailed",  lossAlarmFailed);
        _.set( event, "reflAlarmFailed", reflAlarmFailed );
        _.set( event, "slopeAlarmFailed", slopeAlarmFailed  );
        _.set( event, "eventTestStatus", eventTestStatus );


        _.set( event, "groupNumber", 0 );  

 
        // "reflSaturated": false,
        // "reflPeakDistanceM": -2.55,
        //  "sectionLossdB": 0.0,
        // "cumulativeLossdB": 0.0,


         events.push( event ); 
        
         totalLength = element.dist;
         totalLengthM = element.dist; 
         totalLoss +=  element.spliceLoss;
         totalORL =  element.refl            // probably need to sum up something
        
    }

    _.set( meas, 'wavelength', fp.wavelength);
    _.set( meas, 'wavelengthTestStatus', "PASS");
    _.set( meas, 'acqDateTime', fp.timestamp);

    _.set( meas, 'fiberLength', totalLength.toFixed(3));
    _.set( meas, 'fiberLengthM', totalLengthM.toFixed(3));
    _.set( meas, 'linkLossdB', totalLoss);
    _.set( meas, 'linkOrldB', totalORL);
    _.set( meas, 'numberOfEvents', ke.numEvents );
    _.set( meas, 'maxConnectorMeasureddB', 7);
    _.set( meas, 'maxReflectanceMeasureddB', 7);
    _.set( meas, 'averageSlopedBkm', 7);
    _.set( meas, 'trace', dp);


    _.set( meas, 'events', events);

    measuredResults.push( meas );
    
    
    _.set( myTest, 'results.data.otdrResults.measuredResults', measuredResults);
    tests.push( myTest );


    _.set( cdm, 'tests', tests);

    //this.logger("-----------------------------------------");
    //this.logger( JSON.stringify( cdm, null, 3 ));

    return cdm;

}


}
