import { HttpClient } from "@angular/common/http";
import { Injectable, Renderer2, RendererFactory2 } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { DatabaseBridgeService } from "./database-bridge.service";
//import { environment, databaseMode } from 'src/environments/environment';
import '../window-extensions'

@Injectable({
  providedIn: 'root'
})

export class GlobalSettingsService {
  /** DATA SOURCE MODE */
  databaseLocal = true;
  //databaseLocal = databaseMode.useLocal;

  [x: string]: any;
  selectedProjectProfile: any
  // for DarkThemes service mode
  private isDarkMode = false;
  private renderer: Renderer2;

  language = 'English';
  defaultLevelUnits: string = '';
  defaultDistanceUnits = 'km';
  strataSyncUsername = '';
  strataSyncPassword = '';
  strataSyncServer: any;
  strataSyncServerUrl = 'https://stratasync.viavisolutions.com';
  projectProfileListData: any[] = [];
  languageList = [];
  strataSyncServerList = [];
  theme = 'light';
  splitViewOrientation = "horizontal";
  splitViewPositionExpanded = 80;
  splitViewPositionNormal = 20;

  constructor(private rendererFactory: RendererFactory2, private http: HttpClient, private databaseBridgeService: DatabaseBridgeService) {
    if (!window.db) {
      this.databaseLocal = false;
    }

    this.getAppSettings().then((settings: any) => {
      if (settings.settings) {
        this.language = settings.settings.language;
        this.defaultLevelUnits = settings.settings.defaultLevelUnits;
        this.defaultDistanceUnits = settings.settings.defaultDistanceUnits;
        this.strataSyncUsername = settings.settings.strataSyncUsername;
        this.strataSyncPassword = settings.settings.strataSyncPassword;
        this.strataSyncServer = settings.settings.strataSyncServerUrl;
      } else {
        this.language = settings.language;
        this.defaultLevelUnits = settings.defaultLevelUnits;
        this.defaultDistanceUnits = settings.defaultDistanceUnits;
        this.strataSyncUsername = settings.strataSyncUsername;
        this.strataSyncPassword = settings.strataSyncPassword;
        this.strataSyncServer = settings.strataSyncServerUrl;
      }
      this.strataSyncServerUrl = settings.strataSyncServerUrl.url;
      this.projectProfileListData = settings.projectProfiles;
      this.languageList = settings.languageList;
      this.strataSyncServerList = settings.strataSyncServers;
      this.theme = settings.theme;
      if (this.theme == "light") { this.isDarkMode = false; }
      this.splitViewOrientation = settings.splitViewOrientation;
      this.splitViewPositionExpanded = settings.splitViewPositionExpanded;
      this.splitViewPositionNormal = settings.splitViewPositionNormal;
    });

    this.renderer = rendererFactory.createRenderer(null, null);
    // this.getTheme();
  }

  //----------------------------------------------------------------------------------
  isDatabaseLocal() {
    return this.databaseLocal
  }

  //----------------------------------------------------------------------------------
  /** Language setting */
  getLanguage(): string {
    return this.language;
  }

  //----------------------------------------------------------------------------------
  /** Default Distance Units */
  getlanguageList(): string[] {
    return this.languageList;
  }

  //----------------------------------------------------------------------------------
  /** default Optical Level Units */
  getLevelUnitList(): string[] {
    return ['dBm', 'Watts'];
  }

  //----------------------------------------------------------------------------------
  getDefaultLevelUnits(): string {
    return this.defaultLevelUnits;
  }

  //----------------------------------------------------------------------------------
  /** Default Distance Units */
  getDistanceUnitList(): any[] {
    return [{ name: 'Feets', value: 'feet' }, { name: 'Meters', value: 'meter' }, { name: 'Kilometer', value: 'kilometers' }];
  }

  //----------------------------------------------------------------------------------
  getDefaultDistanceUnits(): string {
    return this.defaultDistanceUnits;
  }

  getDefaultProjectProfile(): any {
    return this.projectProfileListData[0];
  }

  //----------------------------------------------------------------------------------
  getStrataSyncServerList() {
    return this.strataSyncServerList;
  }

  //----------------------------------------------------------------------------------
  /** Method to retrieve the listData  Project Profile Name data listData */
  getProjectProfileListData() {
    return this.projectProfileListData;
  }

  //----------------------------------------------------------------------------------
  // User Preferences
  // light / dark theme

  // getTheme(): void {
  //   this.isDarkMode = !this.isDarkMode;
  //   if (this.isDarkMode) {
  //     this.renderer.addClass(document.body, 'dark-mode');
  //   } else {
  //     this.renderer.removeClass(document.body, 'dark-mode');
  //   }
  // }

  //----------------------------------------------------------------------------------
  public getAppSettings(): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getAppSettings()
    } else {
      return firstValueFrom(this.http.get("http://localhost:3000/api/v1/appsettings"))
    }
  };

  //----------------------------------------------------------------------------------
  public updateAppSettings(settings: any): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.setAppSettings(settings);
    }
    else {
      return firstValueFrom(this.http.patch("http://localhost:3000/api/v1/appsettings", settings));
    }
  };
}
