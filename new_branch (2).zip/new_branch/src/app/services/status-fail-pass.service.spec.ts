import { TestBed } from '@angular/core/testing';

import { StatusFailPassService } from './status-fail-pass.service';

describe('StatusFailPassService', () => {
  let service: StatusFailPassService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StatusFailPassService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
