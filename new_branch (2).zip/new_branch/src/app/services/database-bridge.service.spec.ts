import { TestBed } from '@angular/core/testing';

import { DatabaseBridgeService } from './database-bridge.service';

describe('DatabaseBridgeService', () => {
  let service: DatabaseBridgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatabaseBridgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
