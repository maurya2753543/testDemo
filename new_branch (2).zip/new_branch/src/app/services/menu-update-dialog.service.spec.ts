import { TestBed } from '@angular/core/testing';

import { menuUpdateDialogService } from './menu-update-dialog.service';

describe('menuUpdateDialogService', () => {
  let service: menuUpdateDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(menuUpdateDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
