import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StatusFailPassService {

  constructor() { }
  statusColorIcon(value: string) {
    if (value === 'FAIL') {
     return {'statusColor' : "red",'icon': "fa-circle-xmark"};
    } else if (value === 'NONE') {
      return {'statusColor' : "darkgray",'icon': "fa-solid fa-circle-question"};
    } else  {
      return {'statusColor' : "green",'icon': "fa-circle-check"};
    }
  }
}
