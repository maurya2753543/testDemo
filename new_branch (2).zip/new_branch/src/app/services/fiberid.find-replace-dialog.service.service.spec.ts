import { TestBed } from '@angular/core/testing';

import { FiberidFindReplaceDialogServiceService } from './fiberid.find-replace-dialog.service.service';

describe('FiberidFindReplaceDialogServiceService', () => {
  let service: FiberidFindReplaceDialogServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FiberidFindReplaceDialogServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
