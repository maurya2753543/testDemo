import { Injectable } from '@angular/core';
import '../window-extensions';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class InstrumentsService {


    isConnected = false;
    lastDevice:any;

    isInstrumentConnected() {
        return this.isConnected;
    }
    
    getConnectedInstrument() {
        return this.lastDevice;
    }
    


  constructor() {
    if(window.instrument) {
      window.instrument.deviceAttachedMsg((event: any, device: any) => {
        this.deviceAttached(device);
        this.lastDevice = device;
        this.isConnected = true;
      });
  
      window.instrument.deviceDetachedMsg((event: any, device: any) => {
        this.deviceDetached(device);
        this.lastDevice = device;
        this.isConnected = false;
      });
    }

  }

  //----------------------------------------------------------------------------
  private deviceAttachedSubject = new Subject<any>();
  deviceAttachedSubject$ = this.deviceAttachedSubject.asObservable();

  deviceAttached(device: any) {
    this.deviceAttachedSubject.next(device);
  }

  //----------------------------------------------------------------------------
  private deviceDetachedSubject = new Subject<any>();
  deviceDetachedSubject$ = this.deviceDetachedSubject.asObservable();

  deviceDetached(device: any) {
    this.deviceDetachedSubject.next(device);
  }

  //-----------------------------------------------------------------
  async Initialize() {
    console.log('INST - Initialized');
  }

  //-----------------------------------------------------------------
  async getInstrumentInfo(device:any) {
    const instInfo = await window.instrument.getInstrumentInfo(device);
  }

  //-----------------------------------------------------------------
  sendScipCommand(device: any, cmd: string) {
    // Call the main side function
    window.instrument.sendScipCommand(device, cmd);

    let myPromise: any = new Promise<any>(function (resolve, reject) {
      // wait for the response
      window.instrument.receivedScipResponse((event: any, response: any) => {
        resolve(response);
      });
    });
    return myPromise;
  }

//-----------------------------------------------------------------
getProjects(device: any) {
    // Call the main side function
    window.instrument.getProjects(device);

    let myPromise: any = new Promise<any>(function (resolve, reject) {
      // wait for the response
      window.instrument.getProjectsMsg((event: any, response: any) => {
        resolve(response);
      });
    });
    return myPromise;
  }


  //-----------------------------------------------------------------
  getProjectFileList(device: any, project: any) {
    // Call the main side function
    window.instrument.getProjectFileList(device, project);

    let myPromise: any = new Promise<any>(function (resolve, reject) {
      // wait for the response
      window.instrument.getProjectFileListMsg((event: any, response: any) => {
        resolve(response);
      });
    });
    return myPromise;
  }

//-----------------------------------------------------------------
getProjectFile(device: any, project: any, filename: any) {
    // Call the main side function
    window.instrument.getProjectFile(device, project, filename)

    let myPromise: any = new Promise<any>(function (resolve, reject) {
      // wait for the response
      window.instrument.getProjectFileMsg((event: any, response: any) => {
        resolve(response);
      });
    });
    return myPromise;
  }


}
