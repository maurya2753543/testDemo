import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject, firstValueFrom } from 'rxjs';
import * as _ from 'lodash';
import { DatabaseBridgeService } from './database-bridge.service';
import { GlobalSettingsService } from './global-settings.service';
import { OtdrSorService } from './otdr-sor.service';
import { columnsData } from '../columns-data';
import { UserSettings } from '../models/user-settings.interface';
import { TestResultRow } from '../models/test-result-row';
import { ITextFilterParams } from 'ag-grid-community';
import { TestGridCellComponent } from '../components/test-grid-cell/test-grid-cell.component';


@Injectable({
  providedIn: 'root',
})
export class ProjectsService {
  databaseLocal = false;
  data: any;

  //----------------------------------------------------------------------------
  constructor(
    private http: HttpClient,
    private databaseBridgeService: DatabaseBridgeService,
    private globalSettingsService: GlobalSettingsService,
    public otdrService: OtdrSorService
  ) {
    this.databaseLocal = globalSettingsService.isDatabaseLocal();
  }

  settings: UserSettings = {
    levelUnits: 'dBm',
    distanceUnits: 'km',
    profile: {
      name: 'tpa',
      levels: ['Project', 'Job'],
    },
    reportInformation: {
      title: 'Title',
      company: 'Company',
      technican: 'Operator',
      streetAddress: 'Street Address',
      city: 'city',
      postalCode: '123456',
      phone: '888-555-1212',
      email: 'operator@company.com',
      companyLogo:
        'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAH0AvAMBEQACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAABAAIGBAUHAwj/xAA5EAABAwMDAgMGAwUJAAAAAAABAAIDBAURBhIhMUETUWEHIjJCcYEUFZEjM1OhsRYkNFJiZHLh8P/EABsBAQADAQEBAQAAAAAAAAAAAAAEBQYDAgEH/8QALREBAAICAQMDAgMJAAAAAAAAAAECAwQRBSExEkFREyIyYeEVI3GBkbHB0fD/2gAMAwEAAhEDEQA/APZggkCgUCgUCgsIEIFBIJBIJBIAoBAIBBIBAIBAIFAhAoFAoFAgIFBIFBIJBIJBIBAEIAhAIBAIIoBAIEIEIJBkgUCECgUEgQgkBkHugchBIJAIBBIMSgEAUAgCgECgUCgUCEGSBQKCQa/qTVtBYP2cmZ6ojIgYeQPMnspWtp5M/eO0Iezu49ftPn4ai72nVxf7ltpg3/KZHE/r/wBKx/ZNPe0q2esW5/C0TU2ublqKufmaSlpmnEdPFIdv1J4yfquNtL6Ucx3hv+mVwRSItH3z5923eyXVNdJc/wAlrp5J4ZWOdA6QlxY4ckZ8iAf0UPNSIjmHnqunStPq0jj5bLqD2i0tnvEluFBJUeCQ2WRsgbg4BwARz19FAtmis8POl0LJtYIy+uI58R/36u+0/qW26ghc+glPiM/eQvGHs+3ceoXul4t4V+5oZ9O0RljtPifaXcL2hAoBAEIBAIBAFBigQgyQKBQIQKBQKDi3Ssbb7dU1jxkQRufjzwOi94qfUvFI93PLeMdJvPs8Eq6masqZampeXyyuL3uPmVraVilYrXxDH5Lze02nzL5L08Ogq7TUNmc6Fu9hdkYcAQuU147Npq9Z17Y4+pb02h617KNIz0sLb/Wub40sRbTRtOdueC4+vGP1Wd259OSaR7LXa6nXawVrj8e8/LpvaPa5Yrn+bsaTTVoG844jkAAIPlnAI+6qc1eLc/LSdA3K5df6E/ir/af9NesVwqLXdqaspCRIyQAgfOCcFp88rlW3pnmFtuYKZ8F8eTxx/T836JBy0HGMjorB+aT5RR8CAQYkIBAFAIBBBBkECgQECgyCBQKDodbbn6cuETBlxp3Ox6NIJ/kpOnMRsVmflF3I5wX4+HiS1LJMXPa3qQuOTYx4vxzw+xWZfWjZ+LqoqeNwDpHBu53AHPU+ijZOp6uOs3tbiIdMeG17RWHvtnpoaO10tNTOD4oomsa4HO4AdVnr5fq2nJ8tfipFKRWPZrl7u9toquelfTvqg799Cdpj57EEHKq9rqWLDb0ccrfT6dmyRGWtvT8fLjWCHS1TcWSUtsgpappyxsjc8/6ecZ/mmrua2aeIjiUndnqWPHMXyTavv+rd1ZKIFBFAIMSgxKAQCAQSDIIEIMggUCECgUHDucTnxCRjQ8szuYRw5pGCEiZjvD5MRMcS8p1PpT8FGa21SB9PI/a2B/D2HrgHo4Kxydbx4MP72eLeIlQ7PTZrb1U7w1eK01srwHRFg7ueQFR5eq6lI9U35n8u7hXUyzPHHDv7fQRUEZI5kI955/oszvdQybdvivws9fXjH47y3DS97kgt8tPG3dsky0uPDQR0/VdNfqWXWw/TiOf4+y71NP1R90tVvklTFdqh0hH7RxeOODlR5t9b77eZavXmIxREe3ZjDIcNlYdrhyCOoIXHvW3ZJ4i0cS9ft8j5qKnklBD3xNc4HsSBlbfFM2pE288MPlrFclq18RMuQujmCgCgxKAQBQYlAIHsgUCEGQQKBQKByguyDR9dv/vdLGwAMDHO46Ek4P8ARZvrlp9VK+zhl8tYVC5Pi+OSeYQxNLjxwF1pxEcp+rj9UdvLY7bSfgqfYSC9x3OI814tPqldYsforwa+hgrodk46fC4dQlbTVIpe1J5hybLo2EPidVVD5GY3mIR478Auz/JaHU6ZGStcuSfPfhH2OrWiJpSvf5bwBgADsr/wokgCgCgxKAQBQYlAIHsgQgQgyCBQcG93ihsVsmuNzqGQUsIy5zu/oB3J7BBp0Ul+1fE2qq6mssdqmGaaioiG1kzezpHnOwHyHOO6DgaHbUUntJvlBbrjX1VkpKdjJW1VQ6YNqHY4a49/iz989kHqXZBrl7oI6kuirI5NgeXxTR9W56jyUTb0se1WIv5jw82rFnW02maR7virJvQMDB9ycqvr0TDE/daXiMMe8uxmoKelaIH0rYI/kkiGTn1J6qVm6ZgyY4pEcceJSsGWcE/a4pt0p5ikhkb5teBj6gqiv0farPFeJWVd3FMd+zm220tfJvne14afhYcj7lTdTo01n155/lH+XDNu8xxRsAAHZaGFeUAgCgCgxKAQBQYlAIIIMggQgyCBQeQ3Gp/t97UnWuQGSx6ezJJF8s87TtwfP3jj6NPmg3/UTLoy1vgslRSQXKoID6mpJAiaermgDkgdBx2QcfStotemKCKiinaxo3TOlqHhslTJ80rs/wDgEGyyVMENOaiWaNkDW7jI5wDQPPPTCC/EwbYneNHtmx4R3jD+/Hn9kCJo/G8He3xdu7ZuG7HnjyQdbX6gtFHdqOzVlS0V1c1zoYCwu3NGckkDAHB646FB9qWC2VTTNSmGdgON0cm5ufLg4Qfc1dJC58JngjdEze9heAWN8yOw9UH1dUQsgM7pWNhDdxkLgGhvXOemPVBiKumdFHK2oiMUpAjeHja8npg90FU1VPSRh9VPFCwuDQ6V4aMnoOUE6ohbKyJ0rGyyAljC4BzsdcDugzKAKDFBIMSgEEEGQQKBQT37GF5GQ0ZOEHhenayp9nOvL26/W+rkt1yeXx1kERe0jeXMdx1zk5HUFB6MdT1l9iaNOWGaVpP+MujDTws9QD7zz6AfcIPMrVS19+tt+o7vYLlPqy5S+E6sniLIqaIEfOeGtBB4HLuOqD7azsOr/wAFYdH0dWbnQOiALaekMMe1hAHiSkn1PYDA4OQgy/slqWq9otFDBuNPaIo9lVPEW0lOSzLRC35g33RjOXFpyQgtCUt/pdY328m1XCrqTuhhrro/wo42Z96SQnk8NbhrQe44AQcGzAXmqrtZavZcLuyWSSloKWhgeG1IbzyG9I+gwepJznBQdnYBqvRugbjNZtPTU9RUTGZ7pzufFuIa0RQjJIaOdzsfQoOhvlquAstNDabHe3y3tw/MLjVRufPMWlri0MHws3HqcF23yGUGwa9brCutNo03abLLQW2pHgso4yHyljMY8aQe6zPXbn6nsg6646dvNJrWwUU1BX3OkttPFK2CjZiBjhkhjHOIGM7dz3HJ5PkEHL1i3U2oNeWyg1Ba5qm3QAVDaCgjL4y4gnaZDgOJwAXEgAE4HmHx07e7lePahcrrUUJuNxoGOp6Kkpj+whOS0kyEYa0DdlxGTngIPWdO0twZVTVdyr3VlTOAJBHllPA0ZwyNvc5PLjyf0QbAUGJQBQCAQSBCBQKDLqMIOIaIgnwKiSIE52jkIEW+M5M8kkzsdXnp9EELeD7ss80jB8jncIMpKFj3nEkjYz8UbT7pQH5dGThz5HMHwsLuG/RBqXtOiuUel30FobUVNZc5mUW/lwhY8+8TjoCBjPqg76w2SO22ejt9HPJFT0sQiZsPx46uPqTkoOf+WxtGY5JWyfxN3JQX5f8A7qfJ+L3viQX5cwcRyysYfiYHfEgjb2H3fGlEX8MO4CDR/alea+y2+lsunfHku15eYaZrCSYmDG8jyPIGe3J7IO40Tpan0/p+mtcbg5sQzUSM48eU/Ec+Q6D0CDaGtDGhrQAB0AQSAQBQBQCCQIQKBQIQZIFBIFBIPhUUoncHeJJG4cEsOMjyQfdjQxga0YAGAECgkAgMoOHUUj5pxIJtrf8Aj7zfPae2UHKYxsbAxgw0cAIIoBBigkGJQCCQIQKBQKBCBQKBQSBQSCQSAKCQCAJQCAQCAQBQCCQIQKBQSBQIKDJBIFBIJBIJAIJAEoBAIBAIBAIJBBBIFAhAoIIMkEgR0QSCQKCQCCQR6IBAIAoBBFAIAoBB/9k=',
    },
    columns: columnsData,
  };

  // Project data
  rowData: TestResultRow[] = [];
  activeNodeId: string = '';
  activeNode: any;
  activeProject: any;
  selectedResult: any;
  cdm: any;
  //----------------------------------------------------------------------------------
  theTextFilterParameters = {
    buttons: [$localize`reset`, $localize`apply`],
    closeOnApply: true,
  } as ITextFilterParams;

  //----------------------------------------------------------------------------
  // public async saveProjectSettings( project: any, newSettings: any ) : Promise<any> {
  //     let doc = {
  //         id : project.id,
  //         rev : project.rev,
  //         ...newSettings

  //     }
  //     if( this.databaseLocal ) {
  //         return this.databaseBridgeService.updateDocument( doc );
  //     } else {

  //         const body = {
  //             _id : project.id,
  //             ...newSettings
  //         }
  //         const url = 'http://localhost:3000/api/v1/update';

  //         return firstValueFrom(this.http.patch<any>(url, body));
  //     }

  // }
  // }

  //-----------------------------------------------------------------------
  public async saveProjectSettings(
    project: any,
    newSettings: any
  ): Promise<any> {
    let doc = {
      id: project.id,
      rev: project.rev,
      ...newSettings,
    };

    try {
      let updatedData: any;

      if (this.databaseLocal) {
        updatedData = await this.databaseBridgeService.updateDocument(doc);
      } else {
        const body = {
          _id: project.id,
          ...newSettings,
        };
        const url = 'http://localhost:3000/api/v1/update';

        updatedData = await firstValueFrom(this.http.patch<any>(url, body));
      }
      // Update the service's data with the updated data
      this.updateData(updatedData);

      return updatedData;
    } catch (error) {
      // Handle error
    }
  }

  //----------------------------------------------------------------------------
  updateData(updatedData: any) {
    this.data = updatedData;
    // Optionally, you can broadcast
  }

  //----------------------------------------------------------------------------
  updateOperator(toSAVE: any[]) {
    //resultId: string, name : string
    // get the result
    // add the new overlayed name

    toSAVE.forEach( async (element) => {
        let doc = {
            id: element.resultId,
            operator: element.name,
          };

          try {
            let updatedData: any;

            if (this.databaseLocal) {
              updatedData = await this.databaseBridgeService.updateDocument(doc);
            } else {
              const body = {
                _id:element.resultId,
                operator: element.name,
              };
              const url = 'http://localhost:3000/api/v1/update';

              updatedData = await firstValueFrom(this.http.patch<any>(url, body));
            }
            // Update the service's data with the updated data
            this.updateData(updatedData);

            return updatedData;
          } catch (error) {
            // Handle error
          }


    } );



  }

  //----------------------------------------------------------------------------
  updateCableId(toSAVE: any[]) {
     toSAVE.forEach( async (element) => {
        let doc = {
            id: element.resultId,
            location: element.Location,
          };

          try {
            let updatedData: any;

            if (this.databaseLocal) {
              updatedData = await this.databaseBridgeService.updateDocument(doc);
            } else {
              const body = {
                _id:element.resultId,
                location: element.Location,
              };
              const url = 'http://localhost:3000/api/v1/update';

              updatedData = await firstValueFrom(this.http.patch<any>(url, body));
            }
            // Update the service's data with the updated data
            this.updateData(updatedData);

            return updatedData;
          } catch (error) {
            // Handle error
          }


    } );

  }

  //----------------------------------------------------------------------------
  updateKpiThresholdAndResultStatus(resultId: string, thresholdPath: string, thresholdValue: number) {

    // get the results from the id
    // get the value to re-status
    // compare the value to the new thresold & calculate the new status
    // some how determine the if pass is above or below the threshold
    // add the new KPI threshold path and status to the overlay

  }

    //----------------------------------------------------------------------------
    moveResults( destinationId: string,  resultId: [string]) {
        this.databaseBridgeService.moveDocuments(destinationId, resultId).then((resp) => {
            this.projectUpdated('Moved Documents: ' + resp);
        });
    }


  //----------------------------------------------------------------------------
  public getActiveNode() {
    return this.activeNode;
  }

  //----------------------------------------------------------------------------
  public getActiveProject() {
    return this.activeProject;
  }

  //----------------------------------------------------------------------------
  public async getAppProjects(): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getAllProjects();
    } else {
      return firstValueFrom(
        this.http.get('http://localhost:3000/api/v1/project')
      );
    }
  }

  // Project management actions
  //----------------------------------------------------------------------------
  public newProject(name: string) {
    let settings: UserSettings = {
      levelUnits: this.globalSettingsService.getDefaultLevelUnits(),
      distanceUnits: this.globalSettingsService.getDefaultDistanceUnits(),
      profile: this.globalSettingsService.getDefaultProjectProfile(),
      reportInformation: {
        title: 'Title',
        company: 'Company',
        technican: 'Operator',
        streetAddress: 'Street Address',
        city: 'city',
        postalCode: '123456',
        phone: '888-555-1212',
        email: 'operator@company.com',
        companyLogo:
          'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAH0AvAMBEQACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAABAAIGBAUHAwj/xAA5EAABAwMDAgMGAwUJAAAAAAABAAIDBAURBhIhMUETUWEHIjJCcYEUFZEjM1OhsRYkNFJiZHLh8P/EABsBAQADAQEBAQAAAAAAAAAAAAAEBQYDAgEH/8QALREBAAICAQMDAgMJAAAAAAAAAAECAwQRBSExEkFREyIyYeEVI3GBkbHB0fD/2gAMAwEAAhEDEQA/APZggkCgUCgUCgsIEIFBIJBIJBIAoBAIBBIBAIBAIFAhAoFAoFAgIFBIFBIJBIJBIBAEIAhAIBAIIoBAIEIEIJBkgUCECgUEgQgkBkHugchBIJAIBBIMSgEAUAgCgECgUCgUCEGSBQKCQa/qTVtBYP2cmZ6ojIgYeQPMnspWtp5M/eO0Iezu49ftPn4ai72nVxf7ltpg3/KZHE/r/wBKx/ZNPe0q2esW5/C0TU2ublqKufmaSlpmnEdPFIdv1J4yfquNtL6Ucx3hv+mVwRSItH3z5923eyXVNdJc/wAlrp5J4ZWOdA6QlxY4ckZ8iAf0UPNSIjmHnqunStPq0jj5bLqD2i0tnvEluFBJUeCQ2WRsgbg4BwARz19FAtmis8POl0LJtYIy+uI58R/36u+0/qW26ghc+glPiM/eQvGHs+3ceoXul4t4V+5oZ9O0RljtPifaXcL2hAoBAEIBAIBAFBigQgyQKBQIQKBQKDi3Ssbb7dU1jxkQRufjzwOi94qfUvFI93PLeMdJvPs8Eq6masqZampeXyyuL3uPmVraVilYrXxDH5Lze02nzL5L08Ogq7TUNmc6Fu9hdkYcAQuU147Npq9Z17Y4+pb02h617KNIz0sLb/Wub40sRbTRtOdueC4+vGP1Wd259OSaR7LXa6nXawVrj8e8/LpvaPa5Yrn+bsaTTVoG844jkAAIPlnAI+6qc1eLc/LSdA3K5df6E/ir/af9NesVwqLXdqaspCRIyQAgfOCcFp88rlW3pnmFtuYKZ8F8eTxx/T836JBy0HGMjorB+aT5RR8CAQYkIBAFAIBBBBkECgQECgyCBQKDodbbn6cuETBlxp3Ox6NIJ/kpOnMRsVmflF3I5wX4+HiS1LJMXPa3qQuOTYx4vxzw+xWZfWjZ+LqoqeNwDpHBu53AHPU+ijZOp6uOs3tbiIdMeG17RWHvtnpoaO10tNTOD4oomsa4HO4AdVnr5fq2nJ8tfipFKRWPZrl7u9toquelfTvqg799Cdpj57EEHKq9rqWLDb0ccrfT6dmyRGWtvT8fLjWCHS1TcWSUtsgpappyxsjc8/6ecZ/mmrua2aeIjiUndnqWPHMXyTavv+rd1ZKIFBFAIMSgxKAQCAQSDIIEIMggUCECgUHDucTnxCRjQ8szuYRw5pGCEiZjvD5MRMcS8p1PpT8FGa21SB9PI/a2B/D2HrgHo4Kxydbx4MP72eLeIlQ7PTZrb1U7w1eK01srwHRFg7ueQFR5eq6lI9U35n8u7hXUyzPHHDv7fQRUEZI5kI955/oszvdQybdvivws9fXjH47y3DS97kgt8tPG3dsky0uPDQR0/VdNfqWXWw/TiOf4+y71NP1R90tVvklTFdqh0hH7RxeOODlR5t9b77eZavXmIxREe3ZjDIcNlYdrhyCOoIXHvW3ZJ4i0cS9ft8j5qKnklBD3xNc4HsSBlbfFM2pE288MPlrFclq18RMuQujmCgCgxKAQBQYlAIHsgUCEGQQKBQKByguyDR9dv/vdLGwAMDHO46Ek4P8ARZvrlp9VK+zhl8tYVC5Pi+OSeYQxNLjxwF1pxEcp+rj9UdvLY7bSfgqfYSC9x3OI814tPqldYsforwa+hgrodk46fC4dQlbTVIpe1J5hybLo2EPidVVD5GY3mIR478Auz/JaHU6ZGStcuSfPfhH2OrWiJpSvf5bwBgADsr/wokgCgCgxKAQBQYlAIHsgQgQgyCBQcG93ihsVsmuNzqGQUsIy5zu/oB3J7BBp0Ul+1fE2qq6mssdqmGaaioiG1kzezpHnOwHyHOO6DgaHbUUntJvlBbrjX1VkpKdjJW1VQ6YNqHY4a49/iz989kHqXZBrl7oI6kuirI5NgeXxTR9W56jyUTb0se1WIv5jw82rFnW02maR7virJvQMDB9ycqvr0TDE/daXiMMe8uxmoKelaIH0rYI/kkiGTn1J6qVm6ZgyY4pEcceJSsGWcE/a4pt0p5ikhkb5teBj6gqiv0farPFeJWVd3FMd+zm220tfJvne14afhYcj7lTdTo01n155/lH+XDNu8xxRsAAHZaGFeUAgCgCgxKAQBQYlAIIIMggQgyCBQeQ3Gp/t97UnWuQGSx6ezJJF8s87TtwfP3jj6NPmg3/UTLoy1vgslRSQXKoID6mpJAiaermgDkgdBx2QcfStotemKCKiinaxo3TOlqHhslTJ80rs/wDgEGyyVMENOaiWaNkDW7jI5wDQPPPTCC/EwbYneNHtmx4R3jD+/Hn9kCJo/G8He3xdu7ZuG7HnjyQdbX6gtFHdqOzVlS0V1c1zoYCwu3NGckkDAHB646FB9qWC2VTTNSmGdgON0cm5ufLg4Qfc1dJC58JngjdEze9heAWN8yOw9UH1dUQsgM7pWNhDdxkLgGhvXOemPVBiKumdFHK2oiMUpAjeHja8npg90FU1VPSRh9VPFCwuDQ6V4aMnoOUE6ohbKyJ0rGyyAljC4BzsdcDugzKAKDFBIMSgEEEGQQKBQT37GF5GQ0ZOEHhenayp9nOvL26/W+rkt1yeXx1kERe0jeXMdx1zk5HUFB6MdT1l9iaNOWGaVpP+MujDTws9QD7zz6AfcIPMrVS19+tt+o7vYLlPqy5S+E6sniLIqaIEfOeGtBB4HLuOqD7azsOr/wAFYdH0dWbnQOiALaekMMe1hAHiSkn1PYDA4OQgy/slqWq9otFDBuNPaIo9lVPEW0lOSzLRC35g33RjOXFpyQgtCUt/pdY328m1XCrqTuhhrro/wo42Z96SQnk8NbhrQe44AQcGzAXmqrtZavZcLuyWSSloKWhgeG1IbzyG9I+gwepJznBQdnYBqvRugbjNZtPTU9RUTGZ7pzufFuIa0RQjJIaOdzsfQoOhvlquAstNDabHe3y3tw/MLjVRufPMWlri0MHws3HqcF23yGUGwa9brCutNo03abLLQW2pHgso4yHyljMY8aQe6zPXbn6nsg6646dvNJrWwUU1BX3OkttPFK2CjZiBjhkhjHOIGM7dz3HJ5PkEHL1i3U2oNeWyg1Ba5qm3QAVDaCgjL4y4gnaZDgOJwAXEgAE4HmHx07e7lePahcrrUUJuNxoGOp6Kkpj+whOS0kyEYa0DdlxGTngIPWdO0twZVTVdyr3VlTOAJBHllPA0ZwyNvc5PLjyf0QbAUGJQBQCAQSBCBQKDLqMIOIaIgnwKiSIE52jkIEW+M5M8kkzsdXnp9EELeD7ss80jB8jncIMpKFj3nEkjYz8UbT7pQH5dGThz5HMHwsLuG/RBqXtOiuUel30FobUVNZc5mUW/lwhY8+8TjoCBjPqg76w2SO22ejt9HPJFT0sQiZsPx46uPqTkoOf+WxtGY5JWyfxN3JQX5f8A7qfJ+L3viQX5cwcRyysYfiYHfEgjb2H3fGlEX8MO4CDR/alea+y2+lsunfHku15eYaZrCSYmDG8jyPIGe3J7IO40Tpan0/p+mtcbg5sQzUSM48eU/Ec+Q6D0CDaGtDGhrQAB0AQSAQBQBQCCQIQKBQIQZIFBIFBIPhUUoncHeJJG4cEsOMjyQfdjQxga0YAGAECgkAgMoOHUUj5pxIJtrf8Aj7zfPae2UHKYxsbAxgw0cAIIoBBigkGJQCCQIQKBQKBCBQKBQSBQSCQSAKCQCAJQCAQCAQBQCCQIQKBQSBQIKDJBIFBIJBIJAIJAEoBAIBAIBAIJBBBIFAhAoIIMkEgR0QSCQKCQCCQR6IBAIAoBBFAIAoBB/9k=',
      },
      columns: columnsData,
    };

    if (this.databaseLocal) {
      this.databaseBridgeService.createProject(name, settings);
    } else {
      const url = 'http://localhost:3000/api/v1/project';
      const body = { name: name };
      this.http.post<any>(url, body);
    }

    this.projectUpdated('Added Project: ' + name);
    //return;
  } // verify name is unique or append a number

  //----------------------------------------------------------------------------
  public newFolder(name: string, parentId: any, projectId: any) {

    if (this.databaseLocal) {
      this.databaseBridgeService
        .addProjectFolder(name, parentId, projectId)
        .then((resp: any) => {
          this.projectUpdated('added folder ' + name);
        });
      return;
    } else {
      const url = 'http://localhost:3000/api/v1/project/folder';
      const body = {
        name: name,
        parentId: parentId,
        projectId: projectId,
      };

      this.http.post<any>(url, body).subscribe((resp) => {
        //console.log("PROJ: api response", resp);
      });
    }
  }

  //----------------------------------------------------------------------------
  public deleteProjectNew(node: any) {
    //mg todo - fix duplicate

    if (node.children.length == 0) {
      if (this.databaseLocal) {
        this.databaseBridgeService.deleteDocId(node.id, node.rev);
      } else {
        const body = {
          name: node.name,
          _id: node.id,
          _rev: node.rev,
        };

        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
          body: body,
        };
        const url = 'http://localhost:3000/api/v1/project';
        this.http.delete(url, httpOptions).subscribe((resp: any) => {
          //console.log("PROJ: delete response ", resp);
        });
      }

      this.projectUpdated('added folder ' + node.name);
    } else {
      //console.log( "ProjectService delete failed document has children: ");
    }
  } // project must be empty

  //----------------------------------------------------------------------------
  public renameTreeNode(node: any, editedNodeName: string) {
    if (this.databaseLocal) {
      this.databaseBridgeService.updateDocument(node).then((resp: any) => {
        this.projectUpdated('renamed folder ' + node.name);
      });
    } else {
      const url = 'http://localhost:3000/api/v1/update';
      const body = {
        name: node.name,
        _id: node.id,
        _rev: node.rev,
      };
      this.http.patch<any>(url, body);
    }
  } // can be a project, folder or result

  //----------------------------------------------------------------------------
  exportProject(remove: boolean) {
    let filename = this.activeProject.name + '.';
    if (this.databaseLocal) {
      this.databaseBridgeService.exportProject(
        this.activeProject._id,
        filename,
        remove
      );
    } else {
    }
  }

  //----------------------------------------------------------------------------
  importProject(filename: string) {
    if (this.databaseLocal) {
      this.databaseBridgeService.importProject(filename).then((resp: any) => {
        this.projectUpdated('Imported Project: ' + resp);
      });
    } else {
    }
  }

  // archiveProject() {

  //     let filename = this.activeProject.name + ".";
  //     if( this.databaseLocal ) {
  //         this.databaseBridgeService.exportProject(  this.activeProject._id, filename );
  //     }

  // }

  //----------------------------------------------------------------------------
  // general node
  // getActiveNode(): Node  {
  //     var node = <Node>{ id: 1, name: "myNode", chidren: [], treeLevel: 1};
  //     return node;
  // }
  //----------------------------------------------------------------------------
  getActiveNodeId(): string {
    return this.activeNodeId;
  }

  //----------------------------------------------------------------------------
  /**
   *
   * @param id
   * @returns
   */
  public getProjectDocument(id: string): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getDocumentId(id);
    } else {
      return firstValueFrom(
        this.http.get('http://localhost:3000/api/v1/project/info/' + id)
      );
    }
  }

  //----------------------------------------------------------------------------
  private activeNodeSubject = new Subject<any>();
  activeNodeSubject$ = this.activeNodeSubject.asObservable();

  setActiveNode(node: any) {
    if (node) {
      let id;
      id = node.parent ? node.projectId : node.id;
      this.getProjectDocument(id).then((proj) => {
        this.activeProject = proj;
      });
      this.activeNode = node;
      this.activeNodeId = node.id;
      this.activeNodeSubject.next(node.id);
      //this.getProjectData(node.id);
    }

  }

  private selectedResultSubject = new Subject<any>();
  selectedResultSubject$ = this.selectedResultSubject.asObservable();

  setSelectedResult(row: any) {
    let id = row.id;
    this.getResultById(id).then((result: any) => {
      this.selectedResult = result;
      this.cdm = this.getResultFile(result);
      this.selectedResultSubject.next(result);
    });
  }

  private projectDataUpdatedSubject = new Subject<any>();
  projectDataUpdatedSubject$ = this.projectDataUpdatedSubject.asObservable();

  projectUpdated(message: any) {
    this.projectDataUpdatedSubject.next(message);
  }

  // private projectColumnsUpdatedSubject = new Subject<any>();
  // projectColumnsUpdatedSubject$ = this.projectColumnsUpdatedSubject.asObservable();

  // projectColumnsUpdated( message: any ) {
  //     console.log("PROJ - projectColumnsUpdated", message);
  //     this.projectColumnsUpdatedSubject.next( message );

  // }

  //----------------------------------------------------------------------------
  public deleteNode(doc: any[]) {
    doc.forEach(async (item) => {
      if (this.databaseLocal) {
        return this.databaseBridgeService.deleteDocId(item.id, null);
      } else {
        return firstValueFrom(
          this.http.delete(
            'http://localhost:3000/api/v1/project/:name/results/' + item.id
          )
        );
      }
    });

    this.projectUpdated('deleted selected results');
  }

  //----------------------------------------------------------------------------
  // results
  public getProjectData(id: any): Promise<any> {
    if (this.activeNodeId == '') {
      this.activeNodeId = id;
    }

    if (this.databaseLocal) {
      return this.databaseBridgeService.getResultsGrid(this.activeNodeId);
    } else {
      let url;
      if (this.activeNodeId != '') {
        url =
          'http://localhost:3000/api/v1/project/results/grid/' +
          this.activeNodeId;
      } else {
        url = 'http://localhost:3000/api/v1/project/results/grid/';
      }
      return firstValueFrom(this.http.get(url));
    }
  }

  //----------------------------------------------------------------------------
  public getNodeChildren(id: string) {
    //return this.http.get('http://localhost:3000/api/v1/project/results/list/' + id);

    if (this.databaseLocal) {
      return this.databaseBridgeService.getChildrenOfDocument(id);
    } else {
      return firstValueFrom(
        this.http.get('http://localhost:3000/api/v1/project/results/list/' + id)
      );
    }
  }

  //----------------------------------------------------------------------------
  public getResultById(id: string): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getDocumentId(id);
    } else {
      return firstValueFrom(
        this.http.get('http://localhost:3000/api/v1/project/results/id/' + id)
      );
    }
  }


  //----------------------------------------------------------------------------
  public getResultFile(result: any) {
    return JSON.parse(atob(result._attachments.json.data));
  }

  //----------------------------------------------------------------------------
  public importResultFile(fileInfo: any, contentValue: any) {

    let content;

    if (fileInfo.name.endsWith('.json')) {
      content = contentValue ? JSON.parse(contentValue.toString()) : [];
    } else if (fileInfo.name.endsWith('.sor')) {
      content = this.otdrService.parseSorToCDM(contentValue);
    } else if (fileInfo.name.endsWith('.msor')) {
      content = this.otdrService.parseSorToCDM(contentValue);
    } else {
      return;
    }

    if (this.activeNode == null) {
      //console.log( "Active node not set yet");
      return;
    } else {
      console.log('Active node: ', this.activeNode);
    }

    let parentId = this.activeNode.id;
    let projectId = this.activeNode.projectId;

    if (this.activeNode.parent == null) {
      projectId = this.activeNode.id;
    }

    let body = {
      name: fileInfo.name,
      lastModified: fileInfo.lastModified,
      type: fileInfo.type,
      parentId: parentId,
      projectId: projectId,
      content: content,
    };

    let name: string = fileInfo.name;
    let type: string = fileInfo.type;

    if (this.databaseLocal) {
      this.databaseBridgeService
        .addResultFile(name, parentId, projectId, content, type)
        .then((response: any) => {
          this.projectUpdated(response.id);
        });
    } else {
      this.http
        .post<any>('http://localhost:3000/api/v1/project/results/import', body)
        .subscribe((response: any) => {
          this.projectUpdated(response.id);
        });
    }
  }

  //----------------------------------------------------------------------------
  columns: any = columnsData;

  //-------------------------------------------------------------------------------
  public setColumnHideState(category: string, name: string, state: boolean) {
    let measPath = _.get(this.columns, category);

    let index = _.findIndex(measPath, { name: name });
    let measEnablePath = category + '[' + index + '].enabled';

    _.set(this.columns, category + '[' + index + '].enabled', state);

    //todo save the column to the active project
  }

  //----------------------------------------------------------------------------
  public getColumnsTable() {
    let columnsTree: any = [];

    _.each(this.columns, (val, key) => {
      let childrenCommon = val.common;

      let childrenMeas = val.measurements;
      let childrenConfig = val.configuration;
      let test = { name: key };

      if (val.common) {
        //let comm =  [{ name : "Common" }]
        // _.set( comm[0], "children", childrenCommon);

        _.set(test, 'name', key);
        _.set(test, 'children', childrenCommon);
      } else {
        let categories = [{ name: 'Measurments' }, { name: 'Configuration' }];
        _.set(categories[0], 'children', childrenMeas);
        _.set(categories[1], 'children', childrenConfig);

        _.set(test, 'name', val.name);
        _.set(test, 'children', categories);
      }

      columnsTree.push(test);
    });

    return columnsTree;
  }

  //----------------------------------------------------------------------------
  getColumnsList() {
    let columnsList: any = [];

    _.each(this.columns, (val, key) => {
      if (val.enabled) {
        if (val.common) {
          // val.common.forEach((element: { enabled: any; name: any; }) => {
          //     if( element.enabled ) {
          //         // field, header, editable filterParms, tooltip, hide, width, cell renderer,
          //         const col = { field : element.name, headerName: element.name, headerTooltip: element.name, hide: false }
          //         columnsList.push( col );
          //     }
          // });
        } else if (val.measurements) {
          const header = { headerName: val.name };
          let children: any = [];
          val.measurements.forEach(
            (element: { enabled: any; name: any; header: any }) => {
              if (element.enabled) {
                // field, header, editable filterParms, tooltip, hide, width, cell renderer,
                const col = {
                  field: element.name,
                  headerName: element.header,
                  headerTooltip: element.header,
                  hide: false,
                };
                children.push(col);
                // _.set( header, "children", col)
                // columnsList.push( header );
              }
            }
          );
          _.set(header, 'children', children);
          columnsList.push(header);
        } else if (val.configuration) {
          const header = { headerName: val.name };
          let children: any = [];
          val.configuration.forEach(
            (element: { enabled: any; name: any; header: any }) => {
              if (element.enabled) {
                // field, header, editable filterParms, tooltip, hide, width, cell renderer,
                const col = {
                  field: element.name,
                  headerName: element.header,
                  headerTooltip: element.header,
                  hide: false,
                };
                children.push(col);
                // _.set( header, "children", col)
                // columnsList.push( header );
              }
            }
          );
          _.set(header, 'children', children);
          columnsList.push(header);
        }
      }
    });

    //.log( "COLUMN-LIST", columnsList) ;
    return columnsList;
  }

//----------------------------------------------------------------------------
    getCommonColumnsList() {

        let columnsList: any = [];
        let children: any = [];


        _.each(this.columns, (val, key) => {
        if( key == 'Common') {
            const header = { headerName: val.name };

            val.common.forEach(
                (element: { enabled: any; name: any; header: any }) => {
                  if (element.enabled) {
                    // field, header, editable filterParms, tooltip, hide, width, cell renderer,
                    if( element.name == 'Timestamp') {

                        const col = {
                            field: element.name,
                            headerName: element.header,
                            headerTooltip: element.header,
                            hide: false,
                            width: 265,
                            checkboxSelection: true,
                            headerCheckboxSelection: true,
                            filter: 'agDateColumnFilter',
                          };
                          children.push(col);

                    } else if( element.name == 'Status') {
                      const col = {
                        field: element.name,
                        headerName: element.header,
                        headerTooltip: element.header,
                        hide: false,
                        filterParams: this.theTextFilterParameters,                     
                        cellRenderer: TestGridCellComponent,
                        };
                      children.push(col);
                    }
                      else {
                        const col = {
                        field: element.name,
                        headerName: element.header,
                        headerTooltip: element.header,
                        hide: false,
                        filterParams: this.theTextFilterParameters,
                        };
                        children.push(col);
                    }
                  }
                }
              );
              _.set(header, 'children', children);
              columnsList.push(header);


        }
    });
    return columnsList;
}



  //----------------------------------------------------------------------------
  getColumnsListbyRow(type: any) {
    let columnsList: any = [];

    _.each(this.columns, (val, key) => {
      if (key == type) {
        const header = { headerName: val.name };
        let children: any = [];
        //if(val.name != 'common'  ) {




        val.measurements.forEach(
          (element: { enabled: any; name: any; header: any }) => {
            if (element.enabled) {
              // field, header, editable filterParms, tooltip, hide, width, cell renderer,
              const col = {
                field: element.name,
                headerName: element.header,
                headerTooltip: element.header,
                hide: false,
              };
              children.push(col);
            }
          }
        );
        val.configuration.forEach(
          (element: { enabled: any; name: any; header: any }) => {
            if (element.enabled) {
              // field, header, editable filterParms, tooltip, hide, width, cell renderer,
              const col = {
                field: element.name,
                headerName: element.header,
                headerTooltip: element.header,
                hide: false,
              };
              children.push(col);
            }
          }
        );

        //}
        _.set(header, 'children', children);
        columnsList.push(header);
      }
    });

    return columnsList;
  }

  ///////////////////////////////////////TREE Services////////////////////////////////////////

  public getProjectChildren(): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getAllProjects();
    } else {
      return firstValueFrom(
        this.http.get('http://localhost:3000/api/v1/project')
      );
    }
  }

  public createProject(name: string): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.createProject(name, this.settings);
    } else {
      const url = 'http://localhost:3000/api/v1/project';
      const body = { name: name, settings: this.settings };
      return firstValueFrom(this.http.post<any>(url, body));
    }
  }

  public deleteProject(node: any): Promise<any> {
    // const body = { name: message.name, _id: message.id, _rev: message.rev };

    // const httpOptions = {
    //   headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: body
    // };
    // const url = 'http://localhost:3000/api/v1/project';

    // return this.http.delete(url, httpOptions);

    // if( node.children.length == 0 ) {

    if (this.databaseLocal) {
      return this.databaseBridgeService.deleteDocId(node.id, node.rev);
    } else {
      const body = {
        name: node.name,
        _id: node.id,
        _rev: node.rev,
      };

      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
        body: body,
      };
      const url = 'http://localhost:3000/api/v1/project';

      return firstValueFrom(this.http.delete(url, httpOptions));

      // this.http.delete(url, httpOptions).subscribe( (resp:any) => {
      //     console.log("PROJ: delete response ", resp);
      // });
    }

    //this.projectUpdated("added folder " + node.name);;
    //console.log( "ProjectService delete Project: ", node.name);

    // } else {
    //     console.log( "ProjectService delete failed document has children: ");
    // }
  }

  public addFolderProject(
    parentId: string,
    projectId: string,
    name: string
  ): Promise<any> {
    // const url = 'http://localhost:3000/api/v1/project/folder';
    // const body = { name: name, projectId: projectId, parentId: parentId };
    // return this.http.post(url, body);

    if (this.databaseLocal) {
      return this.databaseBridgeService.addProjectFolder(
        name,
        parentId,
        projectId

      );
      // .then( (resp:any) => {
      //     console.log("PROJ: folder add result: ", resp);
      //     this.projectUpdated("added folder " + name);

      // });
      // return;
    } else {
      const url = 'http://localhost:3000/api/v1/project/folder';
      const body = {
        name: name,
        parentId: parentId,
        projectId: projectId,
      };

      return firstValueFrom(this.http.post<any>(url, body));
      //
    }
  }


}
