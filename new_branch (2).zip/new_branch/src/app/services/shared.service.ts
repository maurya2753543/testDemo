import { Injectable } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
export interface selectedSize {
  gridSize: number;
  detailSize: number;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  //-------------------------------------------------------------------------------
  private subject = new Subject<any>();
  sendClickEvent(event: any) {
    this.subject.next(event);
  }

  getClickEvent(): Observable<any> {
    return this.subject.asObservable();
  }

  //-------------------------------------------------------------------------------
  /** Vertical and Horizontal View */
  private selectedViewDirection = new Subject<any>();
  getselectedViewDirection() {
    return this.selectedViewDirection.asObservable();
  }

  setselectedViewDirection(value: any) {
    this.selectedViewDirection.next(value);
  }

  //-------------------------------------------------------------------------------
  private gridApi: any;
  setGridApi(gridApi: any) {
    this.gridApi = gridApi;
  }
  getGridApi() {
    return this.gridApi;
  }

  //-------------------------------------------------------------------------------
  columnDefs = new Subject<any>();
  getColumnDefinations() {
    return this.columnDefs;
  }

  setColumnDefincation(columnDefs: any) {
    this.columnDefs = columnDefs;
  }

  //-------------------------------------------------------------------------------
  /** logic for disabled navigation next */
  private disableNavigationNextButtonsSubject = new BehaviorSubject<boolean>(false);
  disableNavigationNextButtons$ = this.disableNavigationNextButtonsSubject.asObservable();

  setDisableNavigationNextButtons(disable: boolean) {
    this.disableNavigationNextButtonsSubject.next(disable);
  }

  //-------------------------------------------------------------------------------
  /** logic for disabled navigation previous */
  private disableNavigationPreviousButtonsSubject = new BehaviorSubject<boolean>(false);
  disableNavigationPreviousButtons$ = this.disableNavigationPreviousButtonsSubject.asObservable();

  setDisableNavigationPreviousButtons(disable: boolean) {
    this.disableNavigationPreviousButtonsSubject.next(disable);
  }

  //----------------------------------------------------------------------------
  /**import service data hire */
  /**Previous and next selection from detail tab to grid */
  private valuePrevNextSubject = new Subject<string>();
  valuePrevNext$: Observable<string> = this.valuePrevNextSubject.asObservable().pipe(debounceTime(300));

  setPreNextValue(value: string) {
    this.valuePrevNextSubject.next(value);
  }

  //----------------------------------------------------------------------------
  /**set Size value on split area when expand and collapse */
  private valueSizeSubject = new Subject<any>();
  valueSize$ = this.valueSizeSubject.asObservable();

  setSizeValue(value: any[]) {
    this.valueSizeSubject.next(value);
  }

  //----------------------------------------------------------------------------
  /** Breadcrumbs obj */
  private valueBreadcrumbsSubject = new Subject<any>();
  valueBreadcrumbsSubject$ = this.valueBreadcrumbsSubject.asObservable();

  setBreadcrumbsValue(value: any) {
    this.valueBreadcrumbsSubject.next(value);
  }

  //----------------------------------------------------------------------------
  /** Breadcrumbs tree node id */
  private valueIdSubject = new Subject<object>();
  valueidSubject$ = this.valueIdSubject.asObservable();
  setIdValue(value: string, nodeClicked: boolean) {
    this.valueIdSubject.next({ value: value, nodeClicked: nodeClicked });
  }


  //----------------------------------------------------------------------------
  /** Breeadcrumbs tree children */
  private breadCrumbsChildListSubject = new Subject<object>();
  breadCrumbsChildListSubject$ = this.breadCrumbsChildListSubject.asObservable();
  setBreadCrumbsChildListSubject(children: any) {
    this.breadCrumbsChildListSubject.next(children);
  }

  //----------------------------------------------------------------------------
  /** Manupilate the selected rows from grid */
  private updatedSelectedRowSubject = new Subject<any>();
  updatedSelectedRowSubject$ = this.updatedSelectedRowSubject.asObservable();
  setUpdatedSelectRow(updatedRows: any) {
    this.updatedSelectedRowSubject.next(updatedRows);
  }

  /////////////////////////////////////////////

  isVisibleSource: BehaviorSubject<boolean> = new BehaviorSubject(false);

  //----------------------------------------------------------------------------
  private globalMsgSubject = new Subject<any>();
  globalMsgSubject$ = this.globalMsgSubject.asObservable();

  sendGlobalMsg(msgLeft:string, msgRight:string) {

    const msg = { msgLeft, msgRight}

    this.globalMsgSubject.next(msg);

  }

    //--------------------------------------------------------------------
    private selectedRows = new BehaviorSubject<MatTableDataSource<any>>(
      new MatTableDataSource<any>([]) // Initialize with an empty array
    );
  
    setSelectedRowsData(data: MatTableDataSource<any>): void {
      this.selectedRows.next(data);
    }
  
    getSelectedRowsData(): BehaviorSubject<MatTableDataSource<any>> {
      return this.selectedRows;
    }
      
  //--------------------------------------------------------------------
  private pdfNoRowDataSource = new BehaviorSubject<boolean>(false);

  setNoRowPdfData(data: boolean): void {
    this.pdfNoRowDataSource.next(data);
  }

  getNoRowPdfData(): BehaviorSubject<boolean> {
    return this.pdfNoRowDataSource;
  }
  
}
