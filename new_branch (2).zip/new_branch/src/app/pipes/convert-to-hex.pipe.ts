import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'convertToHex'
})
export class ConvertToHexPipe implements PipeTransform {

  transform(decimalArray: number[]): string {
    const hexArray = decimalArray.map(dec => dec.toString(16).toUpperCase().padStart(2, '0'));
    return hexArray.join(' ');
  }

}
