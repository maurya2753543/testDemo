import { ConvertToHexPipe } from './convert-to-hex.pipe';

describe('ConvertToHexPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToHexPipe();
    expect(pipe).toBeTruthy();
  });
});
