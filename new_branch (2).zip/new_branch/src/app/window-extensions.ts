export {}
declare global {
  interface Window {
    api: {
      exit(): void,
      readFile(): Promise<string|undefined>,
      writeFile(data: ArrayBufferView | string, saveAs: string): Promise<void>,
      connectWirelessly(ipAddress: string, port: number): Promise<string|null>,
      sendIdnWirelessly(): Promise<string|null>,
      wirelessResponse(callback: (message: string) => void): void,
      getAppVersion() : Promise<string|null>,
      getPDFFile(fileName?: string): Promise<string>,
      saveImageFile(imageURL: string, fileName: string): Promise<void>,
      restartApp(): Promise<void>,
      getUserSetting(key: any, defaultValue?: any): Promise<any>,
      setUserSetting(key: any, value: any): Promise<void>,
      updateEvent(callback: (type: string, version: string) => void): void,
      cpus(): any,
      myVersion : string,
    }
  }
}

declare global {
    interface Window {
      db: {
        message(event:any):any,

        getDatabaseInfo(key: any, defaultValue?: any):  Promise<any> ,
        getDatabaseInfoMsg(event:any):any,

        getAppSettings():  Promise<any> ,
        getAppSetingsMsg(event:any):any,

        setAppSettings(settings: any):  Promise<any> ,
        setAppSetingsMsg(event:any):any,

        getAllProjects():  Promise<any> ,
        getAllProjectsMsg(event:any):any,
       
        getDocumentId(id: any):  Promise<any> ,
        getDocumentIdMsg(event:any):any,

        createProject(id: any, settings: any):  Promise<any> ,
        createProjectMsg(event:any):any,
       
        addProjectFolder(name:string, parentId: any, projectId: any):  Promise<any> ,
        addProjectFolderMsg(event:any):any,
       
        addResultFile(name:string, parentId: any, projectId: any, content: any, type: string):  Promise<any> ,
        addResultFileMsg(event:any):any,
       
        getResultsGrid(id:any):  Promise<any> ,
        getResultsGridMsg(event:any):any,
      
        getChildrenOfDocument(id:any ):  Promise<any> ,
        getChildrenOfDocumentMsg(event:any):any,
       
        updateDocument(doc:any ):  Promise<any> ,
        updateDocumentMsg(event:any):any,
       
        deleteDocId(doc:any, rev:any ):  Promise<any> ,
        deleteDocIdMsg(event:any):any,

        moveDocuments(destinationId: string, docIdArray : [string] ):  Promise<any> ,
        moveDocumentsMsg(event:any):any,
       
        exportProject(projectId:any, filename:any, remove:boolean ):  Promise<any> ,
        exportProjectMsg(event:any):any,
       
        importProject(target:any ):  Promise<any> ,
        importProjectMsg(event:any):any,

      },
      
    }
  }

  declare global {
    interface Window {
      instrument: {

        deviceAttachedMsg(event:any):any,
        deviceDetachedMsg(event:any):any,

        sendScipCommand( device: any, cmd: string ): Promise<any>,
        receivedScipResponse(event:any):any,


        getInstrumentInfo(device: any): Promise<any>,
        getInstrumentInfoMsg(event:any):any,
        
        getProjects(device: any): Promise<any>,
        getProjectsMsg(event:any):any,

        getProjectFileList( device: any, project: string) : Promise<any>,
        getProjectFileListMsg(event:any):any,

        getProjectFile( device: any, project: string, filename: string) : Promise<any>,
        getProjectFileMsg(event:any):any,

      }
    }
}