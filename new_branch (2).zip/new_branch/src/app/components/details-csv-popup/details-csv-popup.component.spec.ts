import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsCsvPopupComponent } from './details-csv-popup.component';

describe('DetailsCsvPopupComponent', () => {
  let component: DetailsCsvPopupComponent;
  let fixture: ComponentFixture<DetailsCsvPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetailsCsvPopupComponent]
    });
    fixture = TestBed.createComponent(DetailsCsvPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
