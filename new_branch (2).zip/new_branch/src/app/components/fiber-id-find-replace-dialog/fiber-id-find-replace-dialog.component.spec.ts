import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiberIdFindReplaceDialogComponent } from './fiber-id-find-replace-dialog.component';

describe('FiberIdFindReplaceDialogComponent', () => {
  let component: FiberIdFindReplaceDialogComponent;
  let fixture: ComponentFixture<FiberIdFindReplaceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FiberIdFindReplaceDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FiberIdFindReplaceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
