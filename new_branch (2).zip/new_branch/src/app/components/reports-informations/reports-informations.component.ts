import { Component, OnInit, Input, Renderer2 } from '@angular/core';
import {
  faClose,
  faSave
} from '@fortawesome/pro-solid-svg-icons';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';
import { ProjectsService } from 'src/app/services/projects.service';
import { ReportInformation } from 'src/app/models/report-information';
import { AbstractControl } from '@angular/forms';


  //----------------------------------------------------------------------------------
function numericPostalCodeValidator(control: AbstractControl): { [key: string]: any } | null {
  const numericPostalCodePattern = /^\d+$/;
  const value = control.value;

  if (!value || numericPostalCodePattern.test(value)) {
    return null; // No validation error
  }

  return { nonNumericPostalCode: true }; // Validation error
}

  //----------------------------------------------------------------------------------
function phoneNumberValidator(control: AbstractControl): { [key: string]: any } | null {
  const phoneNumberPattern = /^\d+$/;
  const value = control.value;

  if (!value || phoneNumberPattern.test(value)) {
    return null; // No validation error
  }

  return { invalidPhoneNumber: true }; // Validation error
}

@Component({
  selector: 'app-reports-informations',
  templateUrl: './reports-informations.component.html',
  styleUrls: ['./reports-informations.component.scss'],
})
export class ReportsInformationsComponent implements OnInit {
  isFormOpen: Boolean = false;
  faClose = faClose;
  faSave = faSave;
  @Input() DarkThemesApply: any;
  /** declaired veriable for drop image */
  droppedImage: File | null = null;
  ReportInfoIDForm!: FormGroup;
  /** Report info save array */
  ReportlistData: ReportInformation[] = [];
  /** select File Image */
  selectedImage: File | null = null;
  imageSrc: string | ArrayBuffer | null = null;
  imageStyles: any = {};
  reportInformation: any
  rowPdfData: any;

  //----------------------------------------------------------------------------------
  /** Constructor */
  //-----------------------------------------------
  constructor( public darkModeService: DarkModeService, private formBuilder: FormBuilder,
    private GlobalServicesetting: GlobalSettingsService, private ProjectsService: ProjectsService, private renderer: Renderer2) {
  }
  //----------------------------------------------------------------------------------
  /** onFile selected */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedImage = input.files[0];
      this.displayImage(this.selectedImage);
    }
  }

  //----------------------------------------------------------------------------------
  /** From drag and drop */
  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }
  
  //----------------------------------------------------------------------------------
  /** From drag Leave */
  onDragLeave(event: DragEvent): void {
    event.preventDefault();
  }

  //----------------------------------------------------------------------------------
  /** ondrop  image select file */
  onDrop(event: DragEvent): void {
    event.preventDefault();
    const files: FileList = event.dataTransfer!.files;
    if (files.length > 0) {
      const file: File = files[0];
      if (file.type.startsWith('image/')) {
        // Assign the dropped image to the selectedImage variable
        this.selectedImage = file;
        // Display the dropped image
        this.displayImage(this.selectedImage);
      } else {
        // this.toggleReportForm();
        console.log('Only image files are allowed');
      }
    }
  }

  //----------------------------------------------------------------------------------
  /** Display the Image */
  displayImage(imageFile: File): void {
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.imageSrc = e.target.result;
      this.calculateAspectRatio(this.imageSrc);
      // Assign the image URL to the variable
    };
    reader.readAsDataURL(imageFile);
  }

  //----------------------------------------------------------------------------------
  /** Function to handle image selection */
  onImageSelected(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    const files: FileList | null = inputElement.files;
    if (files && files.length > 0) {
      const file: File = files[0];
      if (file.type.startsWith('image/')) {
        this.selectedImage = file;
        this.displayImage(this.selectedImage);
      } else {
        console.log('Only image files are allowed');
      }
    }
  }

  //----------------------------------------------------------------------------------
  /** Calculate Aspect ratio */

  private calculateAspectRatio(imageSrc: any): void {
    if (imageSrc === null) {
      return;
      // Handle the case when imageSrc is null
    }
    const img = new Image();
    img.src = imageSrc.toString();
    img.onload = () => {
      const aspectRatio = img.width / img.height;
      this.imageStyles = {
        width: aspectRatio >= 1 ? '90%' : 'auto',
        height: aspectRatio < 1 ? '90%' : 'auto',

      };
    };
  }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    // Get the active project's ID or identifier
    this.reportInformation = this.ProjectsService.getActiveProject().reportInformation ? this.ProjectsService.getActiveProject().reportInformation : this.ProjectsService.settings.reportInformation;
    this.initializeForm(this.reportInformation); // Initialize the form with the data
    // ... Other initialization code ...
  }

  //----------------------------------------------------------------------------------
  initializeForm(initialData: any) {
    this.ReportInfoIDForm = this.formBuilder.group({
      title: [initialData.title, [Validators.maxLength(49)]],
      company: [initialData.company, [Validators.maxLength(49)]],
      technician: [initialData.technician, [Validators.maxLength(49)]],
      streetaddress: [initialData.streetaddress, [Validators.maxLength(49)]],
      city: [initialData.city, [Validators.maxLength(49)]],
      postalcode: [initialData.postalcode, [Validators.maxLength(25), numericPostalCodeValidator]],
      phone: [initialData.phone],
      email: [initialData.email, [Validators.maxLength(49), Validators.email]],
      companyLogo: [initialData.companyLogo]
    });
    this.calculateAspectRatio(initialData.companyLogo);
    if (initialData.companyLogo) {
      this.selectedImage = initialData.companyLogo;
      this.imageSrc = initialData.companyLogo;

    }
  }

  //----------------------------------------------------------------------------------
  submitForm() {
    if (this.ReportInfoIDForm.invalid) {
      return;
    } else {
      const formData = this.ReportInfoIDForm.value;
      this.reportInformation = formData; // Update the reportInformation with form data
      this.ReportInfoIDForm.value.companyLogo = this.imageSrc;
      this.ProjectsService.saveProjectSettings({
        id: this.ProjectsService.activeNode.id,
        rev: this.ProjectsService.activeNode.rev
      },
        { reportInformation: formData })
        .then((updatedData: any) => {
          // Handle success or error
        });
      this.ProjectsService.setActiveNode({
        id: this.ProjectsService.activeNode.id,
        rev: this.ProjectsService.activeNode.rev
      });
    }
  }

  //----------------------------------------------------------------------------------
  clearInputFieldInformation(field: string) {
    this.ReportInfoIDForm.get(field)?.setValue('');
  }
}
