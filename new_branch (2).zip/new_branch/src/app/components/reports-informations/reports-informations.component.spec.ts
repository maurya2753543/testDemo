import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsInformationsComponent } from './reports-informations.component';

describe('ReportsInformationsComponent', () => {
  let component: ReportsInformationsComponent;
  let fixture: ComponentFixture<ReportsInformationsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReportsInformationsComponent]
    });
    fixture = TestBed.createComponent(ReportsInformationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
