import { Component, OnInit ,Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { EVENT_GRID } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-events-table',
  templateUrl: './events-table.component.html',
  styleUrls: ['./events-table.component.scss']
})
export class EventsTableComponent implements OnInit {
  dataSource: any;
  @Input() DarkThemesApply: any;
  @Input() detailData:any;

  //----------------------------------------------------------------------------------
  columnEventDefs: ColDef[] = EVENT_GRID;

  //----------------------------------------------------------------------------------
  ngOnInit() {
      const eventData = this.detailData.tests[0].results.data.otdrResults.measuredResults[0].events;
      const updateEvents = []
      for (let i = 0; i < eventData.length; i++) {
        if (i > 0) {
          updateEvents.push({ ...eventData[i], length: eventData[i].distance - eventData[i - 1].distance });
        } else {
          updateEvents.push({ ...eventData[i], length: eventData[i].distance });
        }
      }
      this.dataSource = updateEvents;
  }
}
