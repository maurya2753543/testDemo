import { Component, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ColDef } from 'ag-grid-community';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-replace-cable-id',
  templateUrl: './replace-cable-id.component.html',
  styleUrls: ['./replace-cable-id.component.scss']
})
export class ReplacecableIdComponent implements OnInit {
  dataSource: any;
  newcableId: string = '';
  oldcableId: string = '';
  DarkThemesApply: any;
  num: number = 1;
  showExample: string = '';
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, private SharedService: SharedService, private ProjectsService: ProjectsService) {
    this.dataSource = new MatTableDataSource<any>(data.data);
    this.DarkThemesApply = data.DarkThemesApply;
  }


  columnSelectedDefs: ColDef[] = [
    { field: 'Location', headerName: 'Location', headerTooltip: "Location" ,width : 300 },
    { field: 'NewLocation', headerName: 'NewLocation', headerTooltip: "New Location", width : 297}
  ];

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource = this.dataSource.data.map((obj: any) => ({ ...obj, NewLocation: obj.Location }));
  }

  //----------------------------------------------------------------------------------
  onApply() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, NewLocation: obj.Location.replace(this.oldcableId, this.newcableId) }));
  }

  //----------------------------------------------------------------------------------
  oncableIdFormSubmit() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, Location: obj.NewLocation }));
    const toSaveData = this.dataSource.map((obj: any) => ({resultId: obj.id, Location: obj.NewLocation }));
    this.ProjectsService.updateCableId(toSaveData)
    this.SharedService.setUpdatedSelectRow(this.dataSource);
  }

  showNextExampleClick() {
    // TODO: Implement replace logic
    this.oldcableId = "ID",
      this.newcableId = "NO."
    this.showExample = 'Use "Find" to replace the firct match of text "ID" with the text "No."'

    // this.showExamplesSection = true
    // let incrementedValue = this.num + 1

    // this.showDescriptionOfExm = 'Description of example ' + this.num;
    this.num = this.num + 1;
    // let buttonNum = this.num +1;
    // this.showButtonText = 'Show next example(' + this.num + '/8)'
    switch (this.num) {
      case 2:
        this.oldcableId = "ID",
          this.newcableId = "NO."
        this.showExample = 'Use "Find" to replace the firct match of text "ID" with the text "No."'
        break;
      case 3:
        this.oldcableId = "***",
          this.newcableId = "Result"
        this.showExample = 'Use "***" to replace with the text "Result"'
        this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, NewLocation: 'Result' }));
        break;
      case 4:
        this.oldcableId = "***",
          this.newcableId = "Result***6"
        this.showExample = 'Use "***" and "###n" to replace with the text "Result 000001" etc'
        break;
      case 5:
        this.oldcableId = "<<<",
          this.newcableId = "XT=YZ Ltd.:"
        this.showExample = 'Use "<<<" to prepend text "XYZ Ltd.:"'
        break;
      case 6:
        this.oldcableId = ">>>",
          this.newcableId = "(of Room 102)"
        this.showExample = 'Use ">>>" to append the text "(of Room 102)"'
        break;
      case 7:
        this.oldcableId = "<<<",
          this.newcableId = "Task #7###2:"
        this.showExample = 'Use "<<<" and "###n" to prepend the text "Task #701:" etc.'
        break;
      case 8:
        this.oldcableId = "***",
          this.newcableId = ": FiberID #7###2"
        this.showExample = 'Use "***" and "###n" to replace with the text "Meas 1001: FiberID #701" etc.'
        break;
      case 9:
        this.oldcableId = "ID",
          this.newcableId = "[###6], Meas. #"
        this.showExample = 'Use "Find:" and "###n" to replace with the text "Number [000001], Meas. #" etc.'
        // this.showButtonText = 'Restore entries';
        this.num = 1;
        break;
      default:
        this.oldcableId = "",
          this.newcableId = ""
        this.showExample = ''
        break;
    }

  }
}
