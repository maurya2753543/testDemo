import { Component, ViewChild, Input, ElementRef, ChangeDetectorRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { CellClickedEvent, ColDef, GridApi, GridReadyEvent, SelectionChangedEvent } from 'ag-grid-community';
import { InstrumentsService } from '../../services/instruments.service';
import { DarkModeService } from '../../services/darkMode.service';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-instrument-comms-panel',
  templateUrl: './instrument-comms-panel.component.html',
  styleUrls: ['./instrument-comms-panel.component.scss'],
})
export class InstrumentCommsPanelComponent {
  DarkThemesApply: any;
  isDarkThemesActive: boolean = false;

  baudRate = 115200;

  vendorId = '5518';
  productId = '2053';
  filename = 'pon/2022-11-02T14-08-48.pon';

  selectedProject = '';

  @ViewChild('Command') InputCommand!: ElementRef;
  InstrumentForm!: FormGroup;

  port: any;

  instModel = ' ';
  instVersion = ' ';
  instSerial = ' ';

  activeDevice = {};

  rowGridApi?: GridApi;
  selectedFiles: any = {};

  command: string = '';

  columnDefs = [{ headerName: 'Projects/Jobs', field: 'project', width: 170 }];

  // specify the data
  rowData = [
    { project: 'Project A' },
    { project: 'Project B' },
    { project: 'Project C' },
  ];

  filesColumnDefs = [
    {
      headerName: 'Result Files',
      field: 'filename',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      showDisabledCheckboxes: true,
      width: 370,
    },
  ];

  // specify the data
  filesRowData = [
    { filename: 'Inspection Cable A1-1' },
    { filename: 'Inspection Cable A1-2' },
    { filename: 'Inspection Cable A1-3' },
  ];

  //---------------------------------------------------------------------------------
  constructor(
    public dialogRef: MatDialogRef<InstrumentCommsPanelComponent>,
    private formBuilder: FormBuilder,
    private instService: InstrumentsService,
    private projectsService: ProjectsService,
    public darkModeService: DarkModeService,
    private cd: ChangeDetectorRef
  ) {
    this.isDarkThemesActive = this.darkModeService.isDarkModeEnabled();

    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
      console.log(value);
      if (value == 'dark-theme') {
        this.isDarkThemesActive = true;
      } else {
        this.isDarkThemesActive = false;
      }
    });

    if( this.instService.isInstrumentConnected() ) {
        const device = this.instService.getConnectedInstrument();
        console.log( "Instrument is Connected ", device);
        this.activeDevice = device.device;
        //const infoArray = device.info.split(',');
        let uid
        if(device.uniqueId ) { uid = device.uniqueId};
        if( device.uniqueid){ uid = device.uniqueid};

        this.instModel = device.model;
        this.instSerial = uid
        this.instVersion = device.swVersion;
        this.getInstrumentData();
        
    }


    this.instService.deviceAttachedSubject$.subscribe((device: any) => {
      console.log('InstDia: - attach', device);
      this.activeDevice = device.device;
      //const infoArray = device.info.split(',');
      let uid
      if(device.uniqueId ) { uid = device.uniqueId};
      if( device.uniqueid){ uid = device.uniqueid};

      this.instModel = device.model;
      this.instSerial = uid;
      this.instVersion = device.swVersion;
      cd.detectChanges();
    });

    this.instService.deviceDetachedSubject$.subscribe((device: any) => {
      console.log('InstDia: - detach', device);
      this.instModel = ' ';
      this.instVersion = ' ';
      this.instSerial = ' ';
      cd.detectChanges();
    });



  }

  ngOnInit(): void {
    // this.rowData = [];
    // for (let i = 1; i < 8; i++) {
    //   let proj = 'Project-00' + i;
    //   this.rowData.push({ project: proj });
    // }
    // this.selectedProject = this.rowData[0].project;

    // this.filesRowData = [];
    // for (let i = 1; i < 8; i++) {
    //   let filename = this.selectedProject + ' Cable 123 fiber ' + i;
    //   this.filesRowData.push({ filename: filename });
    // }

    this.InstrumentForm = this.formBuilder.group({
      command: ['', [Validators.maxLength(100)]],
    });
  }

  onGridReady(params: GridReadyEvent) {
    console.log('grid ready');
  }

  onRowSelected(event: any) {
    console.log('row selected ', event);
    // if (event.event) {
    //   this.selectedProject = event.data.project;

    //   this.filesRowData = [];
    //   for (let i = 1; i < 8; i++) {
    //     let filename = this.selectedProject + ' Cable 123 fiber ' + i;
    //     this.filesRowData.push({ filename: filename });
    //   }
    // }
  }

  //   onSelectionChanged(event: SelectionChangedEvent) {
  //     this.selectedFiles = this.rowGridApi?.getSelectedRows();
  //     console.log('Selection updated', this.selectedFiles);
  //   }

  onGridReadyFiles(params: GridReadyEvent) {
    console.log('grid ready');
    this.rowGridApi = params.api;
  }

  onRowSelectedFiles(event: any) {
    console.log('File selected ', event);
    this.selectedFiles = this.rowGridApi?.getSelectedRows();
    console.log('Selected Rows:', this.selectedFiles);
  }

  cancelClick() {
    this.dialogRef.close();
  }

  //---------------------------------------------------------------
  // GET IDN
  //---------------------------------------------------------------
  async sendCommand() {
    const formData = this.InstrumentForm.value;
    console.log(formData.command);

    let cmd = formData.command + "\n"

    this.instService
      .sendScipCommand(this.activeDevice, cmd)
      .then((resp: any) => {
        console.log(resp);
      });
  }

  //---------------------------------------------------------------
  // GET IDN
  //---------------------------------------------------------------
  async getIDN() {
    let cmdStr = '*IDN?\n';
    this.instService
      .sendScipCommand(this.activeDevice, cmdStr)
      .then((resp: any) => {
        console.log(resp);
      });
  }

//---------------------------------------------------------------
  // GET Directories
  //---------------------------------------------------------------
  async getProjects() {
    console.log('DIALOG - Directory list');
    await this.instService
      .getProjects( this.activeDevice )
      .then((resp: any) => {
        console.log("get Projects", resp);

        const myfiles = resp.split(',');
        this.rowData = [];
        myfiles.forEach((proj: any) => {
          this.rowData.push({ project: proj });
          console.log('Result projects:', proj);
        });
      });
    }


  //---------------------------------------------------------------
  // GET File list
  //---------------------------------------------------------------
  async getFileList() {
    console.log('DIALOG - file list');
    await this.instService
      .getProjectFileList(this.activeDevice, "project")
      .then((resp: any) => {
        console.log("getFilesList", resp);

        const myfiles = resp.split(',');
        this.filesRowData = [];
        myfiles.forEach((file: any) => {
          this.filesRowData.push({ filename: file });
          console.log('Result files:', file);
        });
      });


  }

  async getInstrumentData() {

        await this.getProjects()
        await this.getFileList()
  }




  //---------------------------------------------------------------
  // GET a file
  //---------------------------------------------------------------
  async getDataFile() {
    if (this.selectedFiles.length > 0) {
      //let filename = this.selectedFiles[0].filename
      //console.log('DIALOG - get file', filename);

      this.selectedFiles.forEach( async (file: any) => {
        //let cmdStr: any = 'STOR:READ? "' + file.filename + '",1\n';
        await this.instService
          .getProjectFile(this.activeDevice, "proj", file.filename)
          .then((content: any) => {
            console.log(file.filename, content);


            
            const fileInfo = { name: file.filename+ ".json",  lastModified: 0, type: "application/json"}
            this.projectsService.importResultFile(fileInfo, content)
            


          });
      });
    }
  }
}
