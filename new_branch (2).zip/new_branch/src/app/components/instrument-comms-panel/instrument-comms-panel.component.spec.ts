import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstrumentCommsPanelComponent } from './instrument-comms-panel.component';

describe('InstrumentCommsPanelComponent', () => {
  let component: InstrumentCommsPanelComponent;
  let fixture: ComponentFixture<InstrumentCommsPanelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InstrumentCommsPanelComponent]
    });
    fixture = TestBed.createComponent(InstrumentCommsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
