import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplaceTechnicianComponent } from './replace-technician.component';

describe('ReplaceTechnicianComponent', () => {
  let component: ReplaceTechnicianComponent;
  let fixture: ComponentFixture<ReplaceTechnicianComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReplaceTechnicianComponent]
    });
    fixture = TestBed.createComponent(ReplaceTechnicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
