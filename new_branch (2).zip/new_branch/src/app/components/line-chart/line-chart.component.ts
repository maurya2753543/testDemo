import { Component, OnInit, ElementRef, Input, HostListener, SimpleChanges, Output, EventEmitter } from '@angular/core';
import * as d3 from 'd3';
import * as d3Axis from 'd3-axis';
import { ProjectsService } from 'src/app/services/projects.service';
import { D3BrushEvent, Line, ScaleLinear } from 'd3';
import { ZoomRegion } from 'src/app/shared/modules/material/display-window';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { faCancel, faMagnifyingGlass, faMagnifyingGlassMinus } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit {

  @Input() DarkThemesApply: any;
  private chartData = [
    { x: 1, y: 10 },
    { x: 2, y: 20 },
    { x: 1, y: 15 }
  ];
  @Input() zoomRegion: any;
  @Input() detailData: any;
  @Output() zoomValueChange = new EventEmitter<any>();

  graphHeight: number = 0;
  elementHeight: number = 500;
  readonly topMargin = 10
  readonly bottomMargin = 20
  markerAValueText: any;
  markerAValue: number = 0;
  markerBValue: number = 0;
  markerBYValue: number = 0;
  markerAYValue: number = 0;
  markerBAValue: number = 0;
  markerBAValueText: any;
  markerBADistance: number = 0;
  markerBALevelDelta: number = 0;
  markerBAdBperkm: number = 0;
  markerBValueText: any;
  freqMax: number = 0
  ampMax: number = 0
  ampMin: number = 0
  freqMin: number = 0
  line: Line<{ x: number; y: number }> | undefined
  xTicks: number[] = []
  yTicks: number[] = []
  matchingData: any = []
  xScale!: ScaleLinear<number, number>
  yScale!: ScaleLinear<number, number>
  // timeScale: ScaleLinear<number, number> | undefined
  maxY1 = -Infinity;
  maxX1 = -Infinity;
  traces: any = [1, 2, 3];
  readonly markerIcon = "-14,0 14,0 14,20 0,34 -14,20"
  yCord = this.graphHeight - this.topMargin;
  brush: d3.BrushBehavior<unknown> | undefined;
  magGlass = faMagnifyingGlass
  magGlassMinus = faMagnifyingGlassMinus
  isZooming = false;
  cancel = faCancel;
  brushGroup?: d3.Selection<SVGGElement, unknown, null, undefined>
  eventsData: any;
  existingEvents: any;
  svg: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Axis<d3.NumberValue>;
  yAxis: d3.Axis<d3.NumberValue>;
  // brushGroup?: d3.Selection<SVGGElement, unknown, HTMLElement, any>
  // Select the button and chart container elements

  maxX: number;
  showEvents: boolean = true;

  constructor(private elementRef: ElementRef, private projectService: ProjectsService, private darkModeService: DarkModeService) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value; // Update the value
      this.updateChart(); // Call the canvas creation function here
    });
  }

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.graphHeight = this.elementHeight - (this.topMargin + this.bottomMargin)
    this.saveTheTrace().then(() => {
      this.createChart()
    });
  }

  setAll(completed: boolean) {
    this.showEvents = completed;
    if (!this.showEvents) {

      this.svg.selectAll(".event-marker-text").remove();
    } else {
      // Append updated marker text elements
      const markerTexts = this.svg.selectAll<SVGTextElement, any>(".event-marker-text")
        .data(this.matchingData);

      const transform = d3.zoomTransform(this.svg.node() as SVGSVGElement);
      markerTexts.enter()
        .append("text")
        .attr('class', 'event-marker-text')
        .merge(markerTexts)
        .attr("x", (d: any) => transform.applyX(this.xScale(d.x)))
        .attr("y", (d: any) => transform.applyY(this.yScale(d.y)) + 40)
        .attr("fill", "red")
        .style("font-size", "10px")
        .style('-webkit-writing-mode', 'vertical-rl')
        .style("text-anchor", "middle")
        .each(function (d: any) {
          const text = d3.select(this);
          const lines = [
            `${parseFloat(d.x.toString()).toFixed(4)} km`,
            `${parseFloat(d.y.toString()).toFixed(4)} db`
          ];
          lines.forEach((line, i) => {
            text.append("tspan")
              .attr("x", text.attr("x"))
              .attr("dy", i ? "-4.5em" : 0)
              .attr("dx", i ? "1em" : 0)
              .text(line);
          });
        });

    }
  }
  //----------------------------------------------------------------------------------
  async saveTheTrace() {
    this.graphHeight = this.elementHeight - (this.topMargin + this.bottomMargin)
    const trace = this.detailData.tests[0].results.data.otdrResults.measuredResults[0].trace;
    this.eventsData = this.detailData.tests[0].results.data.otdrResults.measuredResults[0].events;
    this.maxX = this.eventsData[this.eventsData.length - 1].distanceM;
    this.chartData = trace;
    this.ampMin = d3.max(this.chartData, d => parseFloat(d.y.toString())) as number;
    this.freqMin = d3.max(this.chartData, d => parseFloat(d.x.toString())) as number;
    this.freqMin = (this.maxX / 1000) + 0.5;
  }


  //----------------------------------------------------------------------------------
  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.updateChart(); // Call the update function on resize
  }

  //----------------------------------------------------------------------------------
  private updateChart() {
    const chartContainer = document.getElementById('chart');
    const margin = { top: 20, right: 20, bottom: 30, left: 50 };
    if (chartContainer) {
      const containerWidth = chartContainer.offsetWidth;
      const height = 400; // Set your desired height

      const width = containerWidth - margin.left - margin.right;
      const svg = d3.select(this.elementRef.nativeElement)
        .select('#chart').select('svg');
      // svg.attr('width', width);

      this.xScale.range([0, width - margin.left - margin.right])
        .clamp(true);
      this.yScale.range([height - margin.top - margin.bottom, 0])
        .clamp(true);;

      this.xAxis = d3Axis.axisBottom(this.xScale)
        .tickValues([...this.xTicks, Math.floor(this.xScale.domain()[1])]) // Add the last x-coordinate value to the tick values
        .tickFormat((d: any) => d); // Format the tick labels as desired

      this.yAxis = d3Axis.axisLeft(this.yScale)
        .tickValues([...this.yTicks, Math.floor(this.yScale.domain()[1])]) // Add the last y-coordinate value to the tick values
        .tickFormat((d: any) => d); // Format the tick labels as desired

      const line = d3.line<{ x: number; y: number }>()
        .x((d: { x: d3.NumberValue; }) => this.xScale(d.x))
        .y((d: { y: d3.NumberValue; }) => this.yScale(d.y));

      this.svg.select('.axis--x')
        .call(this.xAxis as any)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("y1", -height));

      this.svg.select('.axis--y')
        .call(this.yAxis as any)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("x1", width));

      this.svg.select('path')
        .datum(this.chartData)
        .attr('d', line);

      this.eventsData.map((event: any) => {
        this.getClosestMatch(this.chartData, event.distance / 1000, event.id);
      });

      this.svg.select('.x')
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });
      this.svg.select('.y')
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });
      this.svg.select('.event-marker-id-text')
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });
      this.updateMarkers()
      this.isZooming = false;
    }
  }

  //----------------------------------------------------------------------------------
  private handleZoom = (event: D3BrushEvent<void>) => {
    const { type, selection } = event
    if (type === 'end' && selection) {
      const [[x1, y1], [x2, y2]] = selection as number[][]
      this.isZooming = false
      this.zoomRegion.update(
        this.xScale.invert(x1),
        this.yScale.invert(y1),
        this.xScale.invert(x2),
        this.yScale.invert(y2)
      )
      this.zoomValueChange.emit([this.zoomRegion]);
      this.xScale.domain([this.zoomRegion.freqMin, this.zoomRegion.freqMax])
      this.yScale.domain([this.zoomRegion.ampMax, this.zoomRegion.ampMin])

      if (this.brush) this.brushGroup?.call(this.brush.clear)
      this.isZooming = false
      this.brushGroup?.remove()
      this.brushGroup = undefined
      // this.refresh()
    } else if (type === 'start') {
    }
    this.line = d3.line<{ x: number; y: number }>()
      .x((d: { x: d3.NumberValue; }) => this.xScale(d.x))
      .y((d: { y: d3.NumberValue; }) => this.yScale(d.y));

    // Update the x-axis
    this.svg.select('.axis--x')
      .call(this.xAxis as any)
      .call((g: any) => g.select(".domain").remove());

    this.svg.select('path')
      .datum(this.chartData)
      .attr('d', this.line);
    const filteredData = this.eventsData.filter((d: any) => {
      return d.distance / 1000 >= this.zoomRegion.freqMin && d.distance / 1000 <= this.zoomRegion.freqMax;
    });

    this.matchingData = []
    filteredData.map((event: any) => {
      this.getClosestMatch(this.chartData, event.distance / 1000, event.id);
    });

    this.updateMarkers();
  }

  //----------------------------------------------------------------------------------
  private enableZoom = (event: any) => {
    const initialCoords = d3.pointer(event);
    //     // Function to handle the mouse move event
    const currentCoords = d3.pointer(event);
    //       // Calculate the width and height of the selected area
    const width = currentCoords[0] - initialCoords[0];
    const height = currentCoords[1] - initialCoords[1];
    this.brush = d3.brush()
      .on('end', this.handleZoom)
    if (!this.brushGroup) {
      this.brushGroup ??= this.svg
        .append<SVGGElement>('g',)
        .attr('clip-path', 'url(#backgroundClip)')
        .attr('width', width - 20)
        .attr('height', this.graphHeight - this.topMargin)
        .attr('class', 'brush')
      this.brushGroup.call(this.brush)
    }
    this.isZooming = true;
  }

  //----------------------------------------------------------------------------------
  private zoomOut = () => {
    const chartContainer = document.getElementById('chart');
    const margin = { top: 20, right: 20, bottom: 30, left: 50 };
    if (chartContainer) {
      const containerWidth = chartContainer.offsetWidth;
      const height = 400; // Set your desired height

      const width = containerWidth - margin.left - margin.right;
      const svg = d3.select(this.elementRef.nativeElement)
        .select('#chart').select('svg');
      svg.attr('width', width);
      this.freqMin = (this.maxX / 1000) + 0.5;
      this.xScale.domain([this.freqMax, this.freqMin])
      this.yScale.domain([this.ampMax, this.ampMin])
      const line = d3.line<{ x: number; y: number }>()
        .x((d: { x: d3.NumberValue; }) => this.xScale(d.x))
        .y((d: { y: d3.NumberValue; }) => this.yScale(d.y));
      this.svg.select('.axis--x')
        .call(this.xAxis as any)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("y1", -height));

      this.svg.select('.axis--y')
        .call(this.yAxis as any)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("x1", width));

      this.svg.select('path')
        .datum(this.chartData)
        .attr('d', line);

      this.eventsData.map((event: any) => {
        this.getClosestMatch(this.chartData, event.distance / 1000, event.id);
      });


      this.updateMarkers()
      this.isZooming = false;
      this.zoomValueChange.emit([])
    }
  }

  //----------------------------------------------------------------------------------
  private updateMarkers = () => {
    const transform = d3.zoomTransform(this.svg.node() as SVGSVGElement);

    // Update the marker elements
    const markers = this.svg.selectAll<SVGPathElement, any>(".marker")
      .data(this.matchingData);

    markers.enter()
      .append("path")
      .attr("class", "marker")
      .attr("d", d3.symbol().type(d3.symbolTriangle).size(50))
      .merge(markers)
      .attr("transform", (d: any) => `translate(${transform.applyX(this.xScale(d.x))}, ${transform.applyY(this.yScale(d.y))})`)
      .attr("fill", "steelblue")
      .select("title")
      .text((d: any) => `km: ${parseFloat(d.x.toString()).toFixed(4)}, dB: ${parseFloat(d.y.toString()).toFixed(4)}`);

    markers.exit().remove();

    // // Update the marker text elements

    this.svg.selectAll(".event-marker-text").remove();

    // Append updated marker text elements
    const markerTexts = this.svg.selectAll<SVGTextElement, any>(".event-marker-text")
      .data(this.matchingData);
    this.setAll(this.showEvents);
    this.svg.selectAll(".event-marker-id-text").remove();

    markerTexts.enter()
      .append("text")
      .attr('class', 'event-marker-id-text')
      .merge(markerTexts)
      .attr("x", (d: any) => transform.applyX(this.xScale(d.x)))
      .attr("y", -5)
      .text((d: any) => `${d.eventID}`)
      .style("font-size", "12px")
      .style("text-anchor", "middle")
      .attr("fill", () => {
        return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
      });

    markerTexts.exit().remove();
  };

  //----------------------------------------------------------------------------------
  private getClosestMatch = (obj: any, searchValue: number, id?: number) => {
    let closestObject = null;
    let closestDistance = Infinity;

    for (let i = 0; i < obj.length; i++) {
      let distance = Math.abs(searchValue - obj[i].x);
      if (distance < closestDistance) {

        closestObject = obj[i];
        closestDistance = distance;
      }
    }

    if (id) {

      closestObject.eventID = id; // Assign the eventID to the matched object
    }

    this.matchingData.push(closestObject);
    return closestObject;
  }

  //----------------------------------------------------------------------------------
  private createChart() {
    const margin = { top: 20, right: 20, bottom: 30, left: 50 };
    const height = 400 - margin.top - margin.bottom;

    const selectAreaButton = document.getElementById('select-area-button');
    const chartContainer = document.getElementById('chart');

    if (chartContainer) {
      const containerWidth = chartContainer.offsetWidth;
      const width = containerWidth - margin.left - margin.right;
      // Create a zoom behavior
      const initialScale = 1;
      this.svg = d3.select(this.elementRef.nativeElement)
        .select('#chart')
        .attr('preserveAspectRatio', 'xMinYMin meet')
        .select('svg')
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
      // let graphWidth = 500 - 40 / 2

      this.freqMin = (this.maxX / 1000) + 0.5;



      this.xScale = d3.scaleLinear()

        .domain([this.freqMax, this.freqMin])
        .range([0, width])
        .clamp(true);



      this.yScale = d3.scaleLinear()
        .domain([this.ampMax, Math.ceil(this.ampMin / 5) * 5])
        .range([height, 0])
        .clamp(true);

      this.xTicks = this.xScale.ticks()
      this.yTicks = this.yScale.ticks()

      //defines how to make a line
      this.line = d3.line<{ x: number; y: number }>()
        .x((d: { x: d3.NumberValue; }) => this.xScale(d.x))
        .y((d: { y: d3.NumberValue; }) => this.yScale(d.y));

      this.svg.append('path')
        .datum(this.chartData)
        .attr("fill", "none")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 1.5)
        .attr("stroke-linejoin", "round")
        .attr("stroke-linecap", "round")
        .attr("d", this.line);

      // Append x-axis units
      this.svg.append("text")
        .attr("class", "x label")
        .attr("text-anchor", "end")
        .attr("x", width / 2)
        .attr("y", height + 30)
        .text("km (kilometers)")
        .attr("fill", "grey") // Set the fill color to grey by default
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });

      // Append y-axis units
      this.svg.append("text")
        .attr("class", "y label")
        .attr("text-anchor", "end")
        .attr("x", -height / 2)
        .attr("y", -40)
        .attr("dy", ".75em")
        .attr("transform", "rotate(-90)")
        .text("dB")
        .attr("fill", "grey")// Set the fill color to grey by default
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });

      this.xAxis = d3Axis.axisBottom(this.xScale)
        .tickValues([...this.xTicks, Math.floor(this.xScale.domain()[1])]) // Add the last x-coordinate value to the tick values
        .tickFormat((d: any) => d); // Format the tick labels as desired

      this.yAxis = d3Axis.axisLeft(this.yScale)
        .tickValues([...this.yTicks, Math.floor(this.yScale.domain()[1])]) // Add the last y-coordinate value to the tick values
        .tickFormat((d: any) => d); // Format the tick labels as desired

      this.svg.append('g')
        .attr('class', 'axis axis--x')
        .attr('transform', 'translate(0,' + height + ')')
        .attr("stroke-opacity", 0.1)
        .call(this.xAxis)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("y1", -(height))
        );

      this.svg.append('g')
        .attr('class', 'axis axis--y')
        .call(this.yAxis as any)
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g.selectAll(".tick line")
            .clone()
            .attr("stroke-opacity", 0.1)
            .attr("x1", width)
        );

      this.eventsData.map((event: any) => {
        this.getClosestMatch(this.chartData, event.distance / 1000, event.id);
      });

      this.existingEvents = this.matchingData;

      const markers = this.svg.selectAll(".marker")
        .data(this.matchingData)
        .enter()
        .append("path")
        .attr("class", "marker")
        .attr("d", d3.symbol().type(d3.symbolTriangle).size(50))
        .attr("transform", (d: any) => `translate(${this.xScale(d.x)}, ${this.yScale(d.y)})`)
        .attr("fill", "steelblue");

      // // Add text elements for marker values
      // Add text elements for marker values
      this.svg.selectAll(".marker-text1")
        .data(this.matchingData)
        .enter()
        .append("text")
        .attr('class', 'event-marker-id-text')
        .attr("x", (d: any) => this.xScale(d.x))
        .attr("y", -5) // Set a fixed y-coordinate value here, in this case, 300
        .text((d: any) => `${d.eventID}`)
        .style("font-size", "12px")
        .style("text-anchor", "middle")
        .attr("fill", () => {
          return this.DarkThemesApply === 'dark-theme' ? "white" : "grey";
        });


      // Add text elements for marker values
      this.svg.selectAll(".marker-text")
        .data(this.matchingData)
        .enter()
        .append("text")
        .attr('class', 'event-marker-text')
        .attr("x", (d: any) => this.xScale(d.x))
        .attr("y", (d: any) => this.yScale(d.y) + 40)
        .attr("fill", "red")
        .style("font-size", "10px")
        .style('-webkit-writing-mode', 'vertical-rl')
        .style("text-anchor", "middle")
        .each(function (d: any) {
          const text = d3.select(this);
          const lines = [
            `${parseFloat(d.x.toString()).toFixed(4)} km`,
            `${parseFloat(d.y.toString()).toFixed(4)} db`
          ];
          lines.forEach((line, i) => {
            text.append("tspan")
              .attr("x", text.attr("x"))
              .attr("dy", i ? "-4.5em" : 0)
              .attr("dx", i ? "1em" : 0)
              .text(line);
          });
        });

      // // Add tooltip on marker hover
      markers.append("title")
        .text((d: any) => `km: ${parseFloat(d.x.toString()).toFixed(4)}, dB: ${parseFloat(d.y.toString()).toFixed(4)}`);

      const linePolygonA = this.svg.append('g')
        .attr('transform', 'translate( 0 , 0)');

      const linePolygonB = this.svg.append('g')
        .attr('transform', 'translate( 0 , 0)');

      const rectWidth = 20; // Set the desired width of the rectangle
      const rectHeight = 25; // Set the desired height of the rectangle
      const rectTextFont = 20; // Set the desired height of the rectangle
      const borderWidth = 2; // Set the desired width of the border
      const fillColor = '#808080'; // Set the desired color for the rectangle fill


      const markerGroupA = linePolygonA.append('g')
        .attr('class', 'marker-head')
        .attr('transform', 'translate(0, 0)');

      markerGroupA.append('rect')
        .attr('x', -10)
        .attr('y', 0)
        .attr('width', rectWidth) // Set the desired width of the rectangle
        .attr('height', rectHeight) // Set the desired height of the rectangle
        .attr('class', 'M3 M3-fill')
        .attr('stroke', fillColor) // Set the border color, here, black (#000)
        .attr('stroke-width', borderWidth); // Set the width of the border;

      markerGroupA.append('line')
        .attr("y1", 30)
        .attr("y2", 350)
        .attr("stroke-width", 2)
        .attr("stroke", fillColor)
        .attr('stroke-dasharray', '5,5,2,5');

      markerGroupA.append('text')
        .attr('class', 'marker-text unselectable M3')
        .text('A')
        .attr('x', 0) // Adjust the x position to center the text in the rectangle
        .attr('y', 1) // Adjust the y position to center the text in the rectangle
        .attr('dominant-baseline', 'middle')
        .attr('text-anchor', 'middle')
        .attr('fill', 'chocolate')
        .style('font-size', rectTextFont);

      const markerGroupB = linePolygonB.append('g')
        .attr('class', 'marker-head')
        .attr('transform', 'translate(0, 0)');

      markerGroupB.append('rect')
        .attr('x', -10)
        .attr('y', 0)
        .attr('width', rectWidth) // Set the desired width of the rectangle
        .attr('height', rectHeight) // Set the desired height of the rectangle
        .attr('class', 'M3 M3-fill')
        .attr('stroke', fillColor) // Set the border color, here, black (#000)
        .attr('stroke-width', borderWidth); // Set the width of the border;

      markerGroupB.append('line')
        .attr("y1", 30)
        .attr("y2", 350)
        .attr("stroke-width", 2)
        .attr("stroke", fillColor)
        .attr('stroke-dasharray', '5,5,2,5');

      markerGroupB.append('text')
        .attr('class', 'marker-text unselectable M3')
        .text('B')
        .attr('x', 0) // Adjust the x position to center the text in the rectangle
        .attr('y', 1) // Adjust the y position to center the text in the rectangle
        .attr('dominant-baseline', 'middle')
        .attr('text-anchor', 'middle')
        .style('font-size', rectTextFont);

      const dragHandler = (selection: d3.Selection<SVGGElement, any, any, any>) => {
        const chartWidth = width - margin.left - margin.right;
        const chartHeight = height - margin.top - margin.bottom;

        const drag = d3.drag<SVGGElement, any>()
          .on('drag', (event) => {
            // Calculate the new x-coordinate within the chart area
            let newX = event.x;
            newX = Math.max(0, Math.min(newX, chartWidth));

            // Update the marker positions based on the dragged coordinates
            if (selection.nodes()[0].textContent === 'A') {
              this.markerAValue = this.xScale.invert(newX);
              this.markerAYValue = parseFloat(this.getClosestMatch(this.chartData, newX / 1000).y);
            } else {
              this.markerBValue = this.xScale.invert(newX);
              this.markerBYValue = parseFloat(this.getClosestMatch(this.chartData, newX / 1000).y);
            }

            this.calculateBAMarkerValues();
            // Update the transform attribute of the selection to move the markers
            selection.attr('transform', `translate(${newX}, 0)`);
          });

        // Apply the drag behavior to the selection of markers
        selection.call(drag);

      };

      d3.select("#zoomOutBtn").on("click", this.zoomOut);
      markerGroupA.call(dragHandler);
      markerGroupB.call(dragHandler);

      selectAreaButton?.addEventListener('click', this.enableZoom)

    }
  }

  //----------------------------------------------------------------------------------
  private calculateBAMarkerValues() {
    this.markerBADistance = this.markerBValue - this.markerAValue;
    this.markerBALevelDelta = this.markerAYValue - this.markerBYValue;
    this.markerBAdBperkm = this.markerBALevelDelta / this.markerBADistance;
  }
}
