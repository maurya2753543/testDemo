import { Component, ViewChild, OnInit, HostListener, ElementRef, SimpleChanges } from '@angular/core';
import {
  faBars, faSliders, faDiagramProject, faTablets, faListCheck,
  faChartColumn, faList, faGear, faGears
} from '@fortawesome/free-solid-svg-icons'
import { MatDrawer } from '@angular/material/sidenav'
import { LayoutService } from '../../services/layout.service'
import { IconDefinition } from '@fortawesome/fontawesome-svg-core'
import { CustomSideBarComponent } from '../custom-side-bar/custom-side-bar.component';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-nav-panel',
  templateUrl: './nav-panel.component.html',
  styleUrls: ['./nav-panel.component.scss']
})
export class NavPanelComponent implements OnInit {
  @ViewChild('menuDrawer') menuDrawer!: MatDrawer
  @ViewChild('subMenuDrawer') subMenuDrawer!: MatDrawer
  @ViewChild(TestGridPanelComponent) GridChild1!: TestGridPanelComponent;
  @ViewChild(CustomSideBarComponent) CustomSideBarChild!: CustomSideBarComponent;

  showNavPanel = true
  showListView = false
  disabled = false
  expanded = false
  markersExpanded = false
  currentMenu = "Project"
  faBars = faBars
  faDiagramProject = faDiagramProject
  faTableRows = faTablets
  faSliders = faSliders
  faChartColumn = faChartColumn
  faList = faList
  faGear = faGear
  faListCheck = faListCheck
  faGears = faGears
  settingLocaleString = $localize`Project Settings`
  projectLocaleString = $localize`Project`
  ControlGridColLocaleString = $localize`Grid Columns`
  ExpandToolTipLocaleString = $localize`Expand Tools Menu`
  ExpandReportToolTipLocaleString = $localize`Report Information`
  ExpandProjectProfileToolTipLocaleString = $localize`Project Profiles `
  ExpandGlobalSettingToolTipLocaleString = $localize`Global Settings`
  menuGridAreaSize1: any = 20;
  menuGridAreaSize2: any = 80;
  @ViewChild('iconContainer', { static: true }) iconContainer!: ElementRef<HTMLDivElement>;

  /** Dark themes */
  DarkThemesApply: any

  //----------------------------------------------------------------------------------
  /** Report Information */
  menuItemsReport: { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.ExpandReportToolTipLocaleString,
        icon: faChartColumn,
        tooltip: this.ExpandReportToolTipLocaleString
      }
    ]

  //----------------------------------------------------------------------------------
  /** for Profile manager icon lable set */
  menuItemsProjectProfile: { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.ExpandProjectProfileToolTipLocaleString,
        icon: faList,
        tooltip: this.ExpandProjectProfileToolTipLocaleString
      }

    ]

  //----------------------------------------------------------------------------------
  /** for  Global setting icon set */
  menuItemsGlobalSetting: { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.ExpandGlobalSettingToolTipLocaleString,
        icon: faGear,
        tooltip: this.ExpandGlobalSettingToolTipLocaleString
      }
    ]

  //----------------------------------------------------------------------------------
  /** Project Local setting */
  menuProjectItem:
    { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.projectLocaleString,
        icon: faDiagramProject,
        tooltip: this.projectLocaleString
      }

    ]

  //----------------------------------------------------------------------------------
  /** setting local icon */
  menuSettingItem:
    { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.settingLocaleString,
        icon: faSliders,
        tooltip: this.settingLocaleString
      }

    ]

  //----------------------------------------------------------------------------------
  /** setting Control grid Icon */
  menuControlGridItem:
    { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.ControlGridColLocaleString,
        icon: faListCheck,
        tooltip: this.ControlGridColLocaleString
      }
    ]

  //----------------------------------------------------------------------------------
  /** for all lable */
  menuItems:
    { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.projectLocaleString,
        icon: faDiagramProject,
        tooltip: this.projectLocaleString
      },
      {
        label: this.settingLocaleString,
        icon: faSliders,
        tooltip: this.settingLocaleString
      },
      {
        label: this.ControlGridColLocaleString,
        icon: faListCheck,
        tooltip: this.ControlGridColLocaleString
      },
      {
        label: this.ExpandReportToolTipLocaleString,
        icon: faChartColumn,
        tooltip: this.ExpandReportToolTipLocaleString
      }

    ]

  //----------------------------------------------------------------------------------
  /** bottom other two button */
  menuItemsButtom:
    { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.ExpandProjectProfileToolTipLocaleString,
        icon: faList,
        tooltip: this.ExpandProjectProfileToolTipLocaleString
      },
      {
        label: this.ExpandGlobalSettingToolTipLocaleString,
        icon: faGear,
        tooltip: this.ExpandGlobalSettingToolTipLocaleString
      }
    ]

  //----------------------------------------------------------------------------------
  constructor(private layoutService: LayoutService, public darkModeService: DarkModeService) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })
  }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.menuGridAreaSize1 = localStorage.getItem('menuGridAreaSize1') ? localStorage.getItem('menuGridAreaSize1') : 20;
    this.menuGridAreaSize2 = localStorage.getItem('menuGridAreaSize2') ? localStorage.getItem('menuGridAreaSize2') : 80;
  }

  //----------------------------------------------------------------------------------
  public toggleSubMenu(subMenu: string) {
    // if (this.currentMenu === subMenu) {
    //   this.currentMenu = ''
    //   return
    // }
    this.currentMenu = subMenu
  }

  //----------------------------------------------------------------------------------
  refresh() {
    this.layoutService.refreshLayout()
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value
    })
  }

  //----------------------------------------------------------------------------------
  /** for icon auto scroll */
  @HostListener('window:scroll', ['$event'])
  onScroll(event: Event) {
    if (this.iconContainer && this.iconContainer.nativeElement) {
      this.iconContainer.nativeElement.style.transform = `translateY(${window.scrollY}px)`;
    }
  }

  //----------------------------------------------------------------------------------
  dragEnd(event: any) {
      localStorage.setItem('menuGridAreaSize1', event.sizes[0])
      localStorage.setItem('menuGridAreaSize2', event.sizes[1])
  }
}
