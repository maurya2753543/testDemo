import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartlinksComponent } from './smartlinks.component';

describe('SmartlinksComponent', () => {
  let component: SmartlinksComponent;
  let fixture: ComponentFixture<SmartlinksComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SmartlinksComponent]
    });
    fixture = TestBed.createComponent(SmartlinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
