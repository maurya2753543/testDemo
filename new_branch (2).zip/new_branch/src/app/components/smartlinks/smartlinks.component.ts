import { Component, OnInit, Input } from '@angular/core';
import {
  ColDef,
  ICellRendererComp,
  ICellRendererParams,
  RowSpanParams,
} from 'ag-grid-community';
//mport myIcon from '../../../assets/images/viavi-'


@Component({
  selector: 'app-smartlinks',
  templateUrl: './smartlinks.component.html',
  styleUrls: ['./smartlinks.component.scss'],
})
export class SmartlinksComponent {
  dataSource: any;
  @Input() DarkThemesApply: any;
  @Input() detailData: any;

  doubleCellStyle = { background: 'white', border: '0.5px solid lightgrey', 'text-align': "center"};
  doubleCellStyleRight = { background: 'white', border: '0.5px solid lightgrey', 'text-align': "right" };


  suppressRowTransform = true;

  //   const lossLabel =  "Loss (dB)"
  //   const ReflectanceLabel =  "Reflectance (dB)"
  //   const slopeLabel =  "Slope (dB/km)"

  columnEventDefs: ColDef[] = [
    { field: 'id', cellRenderer: idCellRenderer, rowSpan: rowSpan, 
      cellStyle: this.doubleCellStyle,
      width: 60,
      headerName: ""
       },
    { field: 'eventTypeIcon', cellRenderer: iconCellRenderer, rowSpan: rowSpan, 
    cellStyle: this.doubleCellStyle,
      width: 150,
      headerName: ""
       },
    { field: 'distance', cellRenderer: ShowCellRenderer, rowSpan: rowSpan, 
      cellStyle: this.doubleCellStyleRight,
      width: 150,
      headerName: ""
       },
    { field: 'measLabel',headerName: "" },
    { field: 'measvalueL1',headerName: "" },
    { field: 'measvalueL2', headerName: "" },
  ];

  public defaultColDef: ColDef = {
    resizable: true,
    width: 170,
  };

  rowData = [
    {
        measLabel: "Wavelength",
        measvalueL1: "1310",
        measvalueL2: "1550",
      },
    {
      id: { value: '1' },
      eventTypeIcon: { name: 'ICON', value: 'Start'  },
      distance: { name: 'Distance (m)', value: '2000' },
      measLabel: 'Loss (dB)',
      measvalueL1: '- -',
      measvalueL2: '- -',
    },
    {
      measLabel: "Reflectance (dB)",
      measvalueL1: "-66.66",
      measvalueL2: "-64.55",
    },
    {
      id: { value: '' },
      eventTypeIcon: { name: 'ICON', value: 'Slope' },
      distance: { name: 'Length (m)', value: '2000' },
      measLabel: 'Loss (dB)',
      measvalueL1: '- -',
      measvalueL2: '- -',
    },
    {
      measLabel: 'Slope (dB)',
      measvalueL1: '-66.66',
      measvalueL2: '-64.55',
    },
  ];

  ngOnInit() {
    const eventData =
      this.detailData.tests[0].results.data.otdrResults.measuredResults[0].events;
      console.log( eventData )
    const updateEvents = [];

       // id = id
       // distanceM
       // event type maps to an icon
       // lossdB -> loss     +  lossAlarmFailed  loss alarm p/f
       // reflectancedB -> reflectance   + reflAlarmFailed
       // sectionLengthM
       // slope  = slopeAlarmFailed







    //   for (let i = 0; i < eventData.length; i++) {
    //     if (i > 0) {
    //       updateEvents.push({ ...eventData[i], length: eventData[i].distance - eventData[i - 1].distance });
    //     } else {
    //       updateEvents.push({ ...eventData[i], length: eventData[i].distance });
    //     }
    //   }
    //   this.dataSource = updateEvents;
  }
}

class ShowCellRenderer implements ICellRendererComp {
  ui: any;

  init(params: ICellRendererParams) {
    const cellBlank = !params.value;
    if (cellBlank) {
      return;
    }

    this.ui = document.createElement('div');
    this.ui.innerHTML =
      '<div class="show-name">' +
      params.value.name +
      '' +
      '</div>' +
      '<div class="show-value">' +
      params.value.value +
      '</div>';
  }

  getGui() {
    return this.ui;
  }

  refresh() {
    return false;
  }
}


class idCellRenderer implements ICellRendererComp {
    ui: any;
  
    init(params: ICellRendererParams) {
      const cellBlank = !params.value;
      if (cellBlank) {
        return;
      }
  
      this.ui = document.createElement('div');
      this.ui.innerHTML =
        '<div class="show-id"><h1>' + params.value.value +'</h1></div>' ;
    }
  
    getGui() {
      return this.ui;
    }
  
    refresh() {
      return false;
    }
  }


  class iconCellRenderer implements ICellRendererComp {
    ui: any;
  
    init(params: ICellRendererParams) {
      const cellBlank = !params.value;
      if (cellBlank) {
        return;
      }
  
      this.ui = document.createElement('div');
      if( params.value.value == 'Start') {
        this.ui.innerHTML = "<img src='assets/images/Fttx_Table_Icon_First_Connect.png' style='width:72px'; height:45px;'>" ;
      } else if( params.value.value == 'Slope') {
        this.ui.innerHTML = "<img src='assets/images/Fttx_Table_Icon_Slope.png' style='width:72px'; height:45px;'>" ;
      }
    }
  
    getGui() {
      return this.ui;
    }
  
    refresh() {
      return false;
    }
  }


function rowSpan(params: RowSpanParams) {
    
  if (params.data.id) {
    return 2;
  } else if (params.data.eventTypeIcon) {
    return 2;
  } else if (params.data.distance) {
    return 2;
  } else {
    return 1;
  }
}

// function isHeaderRow(params: RowHeightParams | ColSpanParams) {
//     return params.data.section === 'title';
//   }
