
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';


@Component({
  selector: 'app-global-settings',
  templateUrl: './global-settings.component.html',
  styleUrls: ['./global-settings.component.scss']
})
export class GlobalSettingsComponent implements OnInit {
  globalsettingsData: any;
  DarkThemesApply: any;
  defaultOpticalPowerUnit: string[] | undefined;

  // ipput close button logic
  @ViewChild('nameInputUserName') nameInputUserName!: ElementRef;
  @ViewChild('InputFieldPassword') InputFieldPassword!: ElementRef;

  languageList: any;
  language: any;
  defaultLevelUnits: string | undefined;
  defaultDistanceUnits: string | undefined;
  strataSyncServerList: any[] | undefined;
  levelUnitList: string[] | undefined;
  distanceUnitList: any[] | undefined;
  strataSyncUsername: any;
  strataSyncPassword: any;
  strataSyncServerUrl: string = ''
  strataSyncServer: any;
  globalSettingsForm!: FormGroup;

  //----------------------------------------------------------------------------------
  clearInputFieldUserName() {
    this.nameInputUserName.nativeElement.value = '';
  }

  //----------------------------------------------------------------------------------
  clearInputFieldPassword() {
    this.InputFieldPassword.nativeElement.value = '';
  }

  constructor(public darkModeService: DarkModeService, private globalSettingsService: GlobalSettingsService, private formBuilder: FormBuilder) {
    /** Default values from global settings */
    //----------------------------------------------------------------------------------
    this.globalSettingsForm = this.formBuilder.group({
      language: this.globalSettingsService.language,
      defaultLevelUnits: this.globalSettingsService.defaultLevelUnits,
      defaultDistanceUnits: this.globalSettingsService.defaultDistanceUnits,
      strataSyncUsername: this.globalSettingsService.strataSyncUsername,
      strataSyncPassword: this.globalSettingsService.strataSyncPassword,
      strataSyncServer: this.globalSettingsService.strataSyncServer?.name
    });
  }

  //----------------------------------------------------------------------------------
  ngOnInit() {
    /** options list */
    //----------------------------------------------------------------------------------
    this.languageList = this.globalSettingsService.getlanguageList();
    this.levelUnitList = this.globalSettingsService.getLevelUnitList();
    this.distanceUnitList = this.globalSettingsService.getDistanceUnitList();
    this.strataSyncServerList = this.globalSettingsService.getStrataSyncServerList();

    //----------------------------------------------------------------------------------
    this.globalSettingsForm.valueChanges.subscribe((value) => {
      this.globalSettingsService.updateAppSettings({ settings: value })
    });
  }
}
