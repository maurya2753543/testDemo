import { ComponentFixture, TestBed } from '@angular/core/testing'
import { RouterTestingModule } from '@angular/router/testing'
import { MockMarkdownDirective } from 'src/unit_tests/mocks'
import { MarkdownComponent } from './markdown.component'

describe('MarkdownComponent', () => {
  let component: MarkdownComponent
  let fixture: ComponentFixture<MarkdownComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MarkdownComponent, MockMarkdownDirective ],
      imports: [ RouterTestingModule ],
    })
    .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkdownComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
