import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
@Component({
  selector: 'app-test-grid-cell',
  templateUrl: './test-grid-cell.component.html',
  styleUrls: ['./test-grid-cell.component.scss']
})

export class TestGridCellComponent implements ICellRendererAngularComp {

  value: any;
  statusColor: any;
  icon: any;
  isPass: boolean = false;

  //----------------------------------------------------------------------------------
  agInit(params: ICellRendererParams): void {
    this.value = params.value;
    if ((typeof this.value === 'boolean' && this.value === true) ||
      (typeof this.value === 'string' && this.value.toUpperCase() === 'PASS')) {
      this.statusColor = "green"
      this.icon = "fa-circle-check"
      this.isPass = true
      this.value = 'PASS'
    }

    if ((typeof this.value === 'boolean' && this.value === false) ||
      (typeof this.value === 'string' && this.value.toUpperCase() === 'FAIL')) {
      this.statusColor = "red"
      this.icon = "fa-circle-xmark"
      this.isPass = false
      this.value = 'FAIL'
    }

    if (typeof this.value === 'string' && this.value.toUpperCase() === 'NONE') {
      this.statusColor = "gray"
      this.icon = "fa-solid fa-circle-question"
      this.isPass = true
    }
  }

  //----------------------------------------------------------------------------------
  refresh(params: ICellRendererParams<any, any, any>): boolean {
    return false;
  }

}
