import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { ProjectsService } from 'src/app/services/projects.service';
import { InstrumentOptionsTableData } from 'src/app/models/instrument-options-table-data';
import { INSTRUMENT_GRID } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-instrument',
  templateUrl: './test-detail-instrument.component.html',
  styleUrls: ['./test-detail-instrument.component.scss'],
})
export class TestInstrumentComponent implements OnInit {
  cdm: any;
  optionsDetected = false;
  hideDetail: boolean = true;
  OptionsDataSource: InstrumentOptionsTableData[] = [];
  @Input() DarkThemesApply: string | undefined;

  constructor(
    private projectsService: ProjectsService
  ) { }

  //----------------------------------------------------------------------------------
  columnInstrumentDefs: ColDef[] = INSTRUMENT_GRID;

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.projectsService.selectedResultSubject$.subscribe((id) => {
      this.cdm = this.projectsService.getResultFile(id);
      this.OptionsDataSource = [];
      if (this.cdm.assetInfo.swOptions && this.cdm.assetInfo.swOptions.length > 0) {
        this.optionsDetected = true;
        this.OptionsDataSource = this.OptionsDataSource.concat(this.cdm.assetInfo.swOptions);
      }
      if (this.cdm.assetInfo.hwOptions && this.cdm.assetInfo.hwOptions.length > 0) {
        this.optionsDetected = true;
        this.OptionsDataSource = this.OptionsDataSource.concat(this.cdm.assetInfo.hwOptions);
      }
      this.hideDetail = false;
    });
  }

  //----------------------------------------------------------------------------------
  isString(value: any): boolean {
    return typeof value !== 'object';
  }
  //----------------------------------------------------------------------------------
  uppercaseValue(word: any) {
    const result = word.replace(/[A-Z]/g, ' $&');
    return result[0].toUpperCase() + result.substr(1);
  }
}
