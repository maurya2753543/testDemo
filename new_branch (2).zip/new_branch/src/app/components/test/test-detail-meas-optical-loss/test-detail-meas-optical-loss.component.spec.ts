import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMeasurementOpticalLossComponent } from './test-detail-meas-optical-loss.component';

describe('TestMeasurementOpticalLossComponent', () => {
  let component: TestMeasurementOpticalLossComponent;
  let fixture: ComponentFixture<TestMeasurementOpticalLossComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestMeasurementOpticalLossComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestMeasurementOpticalLossComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
