import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { OPTICAL_LOSS_GRID_1, OPTICAL_POWER_LOSS_GRID_2 } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-optical-loss',
  templateUrl: './test-detail-meas-optical-loss.component.html',
  styleUrls: ['./test-detail-meas-optical-loss.component.scss']
})
export class TestMeasurementOpticalLossComponent  {
  dataSource1: any;
  dataSource2: any;
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  opticalLossConfig: any;

  //----------------------------------------------------------------------------------
  displayedColumns1: ColDef[] = OPTICAL_LOSS_GRID_1;

  //----------------------------------------------------------------------------------
  displayedOpticalLoss2: ColDef[] = OPTICAL_POWER_LOSS_GRID_2;

  //----------------------------------------------------------------------------------
  ngOnChanges(): void {
    this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
    this.dataSource2 = this.detailData.tests[0].configuration.setup;
    this.opticalLossConfig = this.detailData.tests[0].configuration;
  }
}
