import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailTabsComponent } from './test-detail-tabs.component';

describe('TestDetailTabsComponent', () => {
  let component: TestDetailTabsComponent;
  let fixture: ComponentFixture<TestDetailTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailTabsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
