import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-test-detail-meas-result-truepon',
  templateUrl: './test-detail-meas-result-truepon.component.html',
  styleUrls: ['./test-detail-meas-result-truepon.component.scss']
})
export class TestDetailMeasurementResultTruePonComponent  {
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  truePonGpon: any;
  truePonxgspon: any;
  truePonConfig: any;
  
  //----------------------------------------------------------------------------------
  ngOnChanges(): void {
    this.truePonGpon = this.detailData.tests[0].results.data.gpon;
    this.truePonConfig = this.detailData.tests[0].configuration;
    this.truePonxgspon = this.detailData.tests[0].results.data.xgspon;
  }
}
