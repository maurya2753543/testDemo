import { Component , OnInit ,ChangeDetectorRef} from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { faChevronsUp, faChevronsDown } from '@fortawesome/pro-solid-svg-icons'
import { ProjectsService } from 'src/app/services/projects.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-test-detail-expand-collapse',
  templateUrl: './test-detail-expand-collapse.component.html',
  styleUrls: ['./test-detail-expand-collapse.component.scss']
})
export class TestDetailExpandCollapseComponent  implements OnInit {
  faChevronsUp = faChevronsUp
  faChevronsDown = faChevronsDown
  expandIcon: any = localStorage.getItem('expandIcon');
  splitAreaSize1 = 50;
  splitAreaSize2 = 50;
  splitAreaSize: any = []
  toggledIcon: boolean = false;
  selectedRows: any = [];
  disableNavigationNextButtons= false; // Initialize the property
  disableNavigationPreviousButtons =false;


  private disableNavigationNextButtonsSubscription!: Subscription; // Subscription to the service
  private disableNavigationPreviousButtonsSubscription!: Subscription; // Subscription to the service



  constructor(private sharedService: SharedService, private cdr: ChangeDetectorRef ,private ProjectsService: ProjectsService ) {

  }
  ngOnInit(): void {

    this.disableNavigationNextButtonsSubscription = this.sharedService.disableNavigationNextButtons$.subscribe((value) => {
      this.disableNavigationNextButtons = value;
     // this.cdr.detectChanges();
    });
    this.disableNavigationPreviousButtonsSubscription = this.sharedService.disableNavigationPreviousButtons$.subscribe((value) => {
      this.disableNavigationPreviousButtons = value;
     // this.cdr.detectChanges();
    });


    this.expandIcon = localStorage.getItem('expandIcon') === 'faChevronsUp'? faChevronsUp : faChevronsDown;
  }
  previousRow() {

    // this.sharedService.setPreNextValue('');
    this.sharedService.setPreNextValue('Previous');
  }

  nextRow() {
    this.sharedService.setPreNextValue('Next');
  }

  ngOnDestroy(): void {
    // Don't forget to unsubscribe when the component is destroyed
    this.disableNavigationNextButtonsSubscription.unsubscribe();
    this.disableNavigationPreviousButtonsSubscription.unsubscribe();


  }
  public toggleExpandIcon(toggledIcon: boolean) {
         this.splitAreaSize = {"gridSize": 50, "detailSize": 50}
         localStorage.setItem('splitAreaSize1', '50');
         localStorage.setItem('splitAreaSize2', '50');
        if(toggledIcon === true) {
          this.expandIcon = faChevronsUp;
          // this.splitAreaSize = {"gridSize": 50, "detailSize": 50}
        } else {
          this.expandIcon = faChevronsDown;
          this.splitAreaSize = {"gridSize": 20, "detailSize": 80};
          localStorage.setItem('splitAreaSize1', '20');
          localStorage.setItem('splitAreaSize2', '80');
          
        }

        localStorage.setItem('expandIcon', JSON.stringify(this.expandIcon));
        this.sharedService.setSizeValue([this.splitAreaSize, this.expandIcon]);
        this.toggledIcon = !toggledIcon;
      }
}
