import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailExpandCollapseComponent } from './test-detail-expand-collapse.component';

describe('TestDetailExpandCollapseComponent', () => {
  let component: TestDetailExpandCollapseComponent;
  let fixture: ComponentFixture<TestDetailExpandCollapseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailExpandCollapseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailExpandCollapseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
