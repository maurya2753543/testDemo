import { Component, Input, OnInit } from '@angular/core';
@Component({
  selector: 'app-test-detail-meas-ont-detecton',
  templateUrl: './test-detail-meas-ont-detecton.component.html',
  styleUrls: ['./test-detail-meas-ont-detecton.component.scss']
})
export class TestDetailMeasOntDetectonComponent implements OnInit {

  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  OntDetectonDetailData: any;
  
      //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.OntDetectonDetailData = this.detailData;
  }
}
