import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { ProjectsService } from 'src/app/services/projects.service';
import { DynamicPropertyChangeEvent, JsonSchemaDef } from '@viavi/core-angular/dynamic'

@Component({
  selector: 'app-test-detail-configuration',
  templateUrl: './test-detail-configuration.component.html',
  styleUrls: ['./test-detail-configuration.component.scss']
})
export class TestConfigurationComponent {
  constructor(private projectsService: ProjectsService, private http: HttpClient) {
  }

  loadTestSchemaInfo$(testType: string) {
    // TODO: replace this with code to load schema from database.
    return this.http.get<any>(`/assets/test-config-schemas/${testType + '.json'}`).pipe(
      catchError(() => of(null))
    );
  }

  #schemaCache: { [testType: string]: TestSchemaInfo } = {};

  testInfo$ = this.projectsService.selectedResultSubject$.pipe(
    map(result => {
      const cdm = result && this.projectsService.getResultFile(result);
      return (result != null && cdm != null
        ? { testType: cdm?.tests?.[0].type, configuration: cdm?.tests?.[0]?.configuration }
        : null) as TestConfigInfo;
    }),
    switchMap(configInfo => (configInfo == null ? of(null) : (this.#schemaCache[configInfo.testType] != null ? of(this.#schemaCache[configInfo.testType])
      : this.loadTestSchemaInfo$(configInfo.testType).pipe(
        tap(schemaInfo => {
          if (schemaInfo != null) {
            this.#schemaCache[configInfo.testType] = schemaInfo;
          }
        })
      )).pipe(
        map(schemaInfo => ({ ...configInfo, schemaInfo }))
      ))
    )
  );

  onConfigChange(change: DynamicPropertyChangeEvent, isBlur = false) {
    const immediate = change.schema.type == 'boolean' || change.schema.enum?.length;
    if ((immediate && !isBlur) || (!immediate && isBlur)) {
      // TODO: Whatever we want to do with the updated configuration.
      console.log('config change', change);
    }
  }
}

interface TestSchemaInfo {
  schema: JsonSchemaDef;
  includePaths?: string[];
  editPaths?: string[];
}

interface TestConfigInfo {
  testType: string;
  configuration: any;
  schemaInfo?: TestSchemaInfo;
}
