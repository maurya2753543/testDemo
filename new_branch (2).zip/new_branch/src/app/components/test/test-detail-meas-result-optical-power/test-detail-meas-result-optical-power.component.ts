import { Component, Input, SimpleChanges } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { OPTICAL_POWER_GRID_1, OPTICAL_POWER_LOSS_GRID_2 } from 'src/app/shared/app.constants'; 

@Component({
  selector: 'app-test-detail-meas-result-optical-power',
  templateUrl: './test-detail-meas-result-optical-power.component.html',
  styleUrls: ['./test-detail-meas-result-optical-power.component.scss']
})
export class TestDetailMeasurementResultOpticalPowerComponent {
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  dataSource2: any;
  dataSource1: any;
  opticalPowerConfig: any;
  //---------------------------------------------------------------
  columnMeasOpticalDefs1: ColDef[] = OPTICAL_POWER_GRID_1;
  //---------------------------------------------------------------
  columnMeasOpticalDefs2: ColDef[] = OPTICAL_POWER_LOSS_GRID_2;

  //---------------------------------------------------------------
  
  ngOnChanges(): void {
    this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
    this.dataSource2 = this.detailData.tests[0].configuration.setup;
    this.opticalPowerConfig = this.detailData.tests[0].configuration;
}
}
