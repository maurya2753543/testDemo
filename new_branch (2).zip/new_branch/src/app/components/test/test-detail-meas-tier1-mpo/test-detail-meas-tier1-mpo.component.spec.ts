import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasTier1MpoComponent } from './test-detail-meas-tier1-mpo.component';

describe('TestDetailMeasTier1MpoComponent', () => {
  let component: TestDetailMeasTier1MpoComponent;
  let fixture: ComponentFixture<TestDetailMeasTier1MpoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestDetailMeasTier1MpoComponent]
    });
    fixture = TestBed.createComponent(TestDetailMeasTier1MpoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
