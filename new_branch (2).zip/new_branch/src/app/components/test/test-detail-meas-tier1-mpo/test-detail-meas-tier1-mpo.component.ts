import { Component, Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { StatusFailPassService } from 'src/app/services/status-fail-pass.service';
import { TIER_1_MPO } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-tier1-mpo',
  templateUrl: './test-detail-meas-tier1-mpo.component.html',
  styleUrls: ['./test-detail-meas-tier1-mpo.component.scss']
})
export class TestDetailMeasTier1MpoComponent {
  @Input() DarkThemesApply: any;
  @Input() detailData: any
  tier1MpoData: any;
  value: any;
  statusColor: any;
  statuIcon: any;

  //----------------------------------------------------------------------------------
  columnTierDefs: ColDef[] = TIER_1_MPO;
  constructor(private StatusFailPassService: StatusFailPassService) { }
  //----------------------------------------------------------------------------------
  ngOnChanges(): void {
    this.tier1MpoData = this.detailData;
    this.statusColorIcon(this.tier1MpoData.tests[0].results.data.lengthTestStatus);
  }

  //----------------------------------------------------------------------------------
  statusColorIcon(value: any) {
    this.statusColor = this.StatusFailPassService.statusColorIcon(value).statusColor;   
    this.statuIcon = this.StatusFailPassService.statusColorIcon(value).icon;  
    }
 

}
