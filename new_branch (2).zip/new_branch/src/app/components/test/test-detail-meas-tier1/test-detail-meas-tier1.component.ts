import { Component, Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { StatusFailPassService } from 'src/app/services/status-fail-pass.service';
import { TIER_1 } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-tier1',
  templateUrl: './test-detail-meas-tier1.component.html',
  styleUrls: ['./test-detail-meas-tier1.component.scss']
})
export class TestDetailMeasTier1Component {

  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  dataSource: any;
  tier1DetailData: any;
  statusColor: string = '';
  statuIcon: string = '';
  //----------------------------------------------------------------------------------
  columnTierDefs: ColDef[] = TIER_1;
  constructor(private StatusFailPassService: StatusFailPassService) { }

  //----------------------------------------------------------------------------------
  ngOnChanges(): void {
    this.dataSource = this.detailData.tests[0].results.data.optical;
    this.tier1DetailData = this.detailData;
    this.statusColorIcon(this.tier1DetailData.tests[0].results.data.lengthTestStatus);
  }

  //----------------------------------------------------------------------------------
  statusColorIcon(value: any) {
   this.statusColor = this.StatusFailPassService.statusColorIcon(value).statusColor;   
   this.statuIcon = this.StatusFailPassService.statusColorIcon(value).icon;  
   }
 
}
