import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMeasurementOtdrComponent } from './test-detail-meas-otdr.component';

describe('TestMeasurementOtdrComponent', () => {
  let component: TestMeasurementOtdrComponent;
  let fixture: ComponentFixture<TestMeasurementOtdrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestMeasurementOtdrComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestMeasurementOtdrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
