import { Component, Input } from '@angular/core';
import * as d3 from 'd3';
import { ProjectsService } from 'src/app/services/projects.service';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { ColDef } from 'ag-grid-community';
import { ZoomRegion } from 'src/app/shared/modules/material/display-window';
import { OTDR_GRID } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-otdr',
  templateUrl: './test-detail-meas-otdr.component.html',
  styleUrls: ['./test-detail-meas-otdr.component.scss']
})
export class TestMeasurementOtdrComponent {
  columnOtdrDefs: ColDef[] = OTDR_GRID;
  private chartData = [
    { date: 1, value: 10 },
    { date: 2, value: 20 },
    { date: 1, value: 15 }
  ];

  // Dark themes
  @Input() DarkThemesApply: any;
  @Input() detailData: any;
  @Input() zoomRegion = new ZoomRegion();
  xScale!: d3.ScaleLinear<number, number>
  yScale!: d3.ScaleLinear<number, number>
  canvas: any;
  canvasHeight: number = 0;
  canvasWidth: number = 0;
  newZoomValue: any

  constructor(private projectsService: ProjectsService, private DarkModeService: DarkModeService) {
    this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value; // Update the value
      this.creteCanvas(); // Call the canvas creation function here
      this.handleZoomValueChange(this.newZoomValue);
    });
  }
  private darkThemesValue: string = 'dark-theme'; // Set a default value

  //----------------------------------------------------------------------------------
  ngOnChanges() {
    const trace = this.detailData.tests[0].results.data.otdrResults.measuredResults[0].trace;
    const result = [];

    for (const item of trace) {
      result.push({ date: parseFloat(item.x), value: parseFloat(item.y) });
    }

    this.chartData = result;
    this.creteCanvas();
  }

  //----------------------------------------------------------------------------------
  handleZoomValueChange(newZoomValue: any) {
    const context = this.canvas.getContext('2d');
    context.fillStyle = 'rgba(128, 128, 128, 0.5)';
    this.newZoomValue = newZoomValue;
    if (newZoomValue.length > 0) {
      context.fillRect(
        this.xScale(this.newZoomValue[0].freqMin),
        this.yScale(this.newZoomValue[0].ampMin),
        this.xScale(this.newZoomValue[0].freqMax) - this.xScale(this.newZoomValue[0].freqMin), // Width
        this.yScale(this.newZoomValue[0].ampMax) - this.yScale(this.newZoomValue[0].ampMin) // Height
      );
    } else {
      this.creteCanvas();
    }

  }

  //----------------------------------------------------------------------------------
  creteCanvas() {
    // Create the canvas element
    this.canvas = document.getElementById('canvas') as HTMLCanvasElement;
    if (this.canvas) {
      this.canvas.width = 400;
      this.canvasHeight = 150;


      const chartWidth = this.canvas.width; // Adjust for padding
      const chartHeight = this.canvasHeight - 40; // Adjust for paddin

      // Get the canvas context
      const context = this.canvas.getContext('2d');

      if (context) {
        // Clear the canvas

        context.clearRect(0, 0, this.canvas.width, this.canvasHeight);

        this.xScale = d3.scaleLinear()
          .range([20, this.canvas.width - 2])
          .domain([0, d3.max(this.chartData, d => d.date) as number]);

        this.yScale = d3.scaleLinear()
          .range([this.canvasHeight - 20, 20])
          .domain([0, d3.max(this.chartData, d => d.value) as number]);

        // Draw the chart on the canvas
        context.beginPath();

        for (let i = 1; i < this.chartData.length; i++) {
          const dataPoint = this.chartData[i];
          context.lineTo(this.xScale(dataPoint.date), this.yScale(dataPoint.value));
        }
        context.strokeStyle = 'steelblue';
        context.lineWidth = 2;
        context.stroke();
        const yAxisTicks = this.yScale.ticks(10); // Generate the tick values for the y-axis
        const xAxisTicks = this.xScale.ticks(10);

        // Render the y-axis labels
        yAxisTicks.forEach(tick => {
          const y = this.yScale(tick); // Calculate the y-coordinate for each tick

          // Draw the tick line
          context.beginPath();
          context.moveTo(20, y);
          context.lineTo(this.canvas.width, y);
          context.strokeStyle = "grey";

          if (this.DarkThemesApply === 'dark-theme') {
            context.fillStyle = "white";
          } else {
            context.fillStyle = "grey";
          }
          context.lineWidth = 0.5;
          context.stroke();
          // Draw the tick label
          context.textAlign = "end";
          context.fillText(tick.toString(), 10, y);
        });

        // Render the x-axis labels
        xAxisTicks.forEach(tick => {
          const x = this.xScale(tick); // Calculate the x-coordinate for each tick

          // Draw the tick line
          context.beginPath();
          context.moveTo(x, 20);
          context.lineTo(x, this.canvasHeight - 20);
          context.strokeStyle = "grey";

          context.strokeStyle = "grey";
          context.lineWidth = 0.5;
          context.stroke();

          // Draw the tick label
          context.textAlign = "center";
          context.fillText(tick.toString(), x, this.canvasHeight);
        });

      }

      // Append the canvas element to the chart container
      const chartContainer = document.getElementById('chart-container') as HTMLElement;
      if (chartContainer) {
        chartContainer.appendChild(this.canvas);
      }
    }
  }

}
