import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { ProjectsService } from 'src/app/services/projects.service';
import { StatusFailPassService } from 'src/app/services/status-fail-pass.service';
import { INSPECTION_GRID } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-inspection-mpo',
  templateUrl: './test-detail-meas-inspection-mpo.component.html',
  styleUrls: ['./test-detail-meas-inspection-mpo.component.scss']
})

export class TestDetailMeasInspectionMpoComponent  {
  @Input() DarkThemesApply: any;
  @Input() detailData: any;
  opticalPowerMpoData: any;
  statusColor: string = '';
  statuIcon: string = '';
  imageRows: any[] = [];
  imageUrl1: any[] = [];
  imageUrl2: any[] = [];
  imageUrl3: any[] = [];
  imageUrl4: any[] = [];
  displayImg: any;
  overallEvaluationResult: any;
  selectedImageIndex: number = 0;
  displayRowsCols: any;

  constructor(private StatusFailPassService: StatusFailPassService) {

  }
  //----------------------------------------------------------------------------------
  // Column definitions for AG-Grid
  columnInspetionDefs: ColDef[] = INSPECTION_GRID;

  //----------------------------------------------------------------------------------
  ngOnChanges() {
    this.opticalPowerMpoData = [];
    this.opticalPowerMpoData = this.detailData;
    this.processEndfaceImages();
  }

  //----------------------------------------------------------------------------------
  private processEndfaceImages() {
    this.imageRows = [];
    this.imageUrl1 = [];
    this.imageUrl2 = [];
    this.imageUrl3 = [];
    this.imageUrl4 = [];
    this.opticalPowerMpoData.tests[0].results.data.endfaces.forEach((element: any, index: number) => {
      if(element.rowPos) {
        switch (element.rowPos) {
          case 1:
            this.imageUrl1.push(this.convertBase64ToBinary(element, index)[0]);
            break;
          case 2:
            this.imageUrl2.push(this.convertBase64ToBinary(element, index)[0]);
            break;
          case 3:
            this.imageUrl3.push(this.convertBase64ToBinary(element, index)[0]);
            break;
          default:
            this.imageUrl4.push(this.convertBase64ToBinary(element, index)[0]);
            break;
        }
      } else {
        this.imageUrl1.push(this.convertBase64ToBinary(element, index)[0]);
      }

    });

    if (!this.displayImg) {
      this.displayImg = this.imageUrl1[0];
      this.overallEvaluationResult = this.imageUrl1[0].overallEvaluationResult;
    }
    this.imageRows.push(this.imageUrl1);
    this.imageRows.push(this.imageUrl2);
    this.imageRows.push(this.imageUrl3);
    this.imageRows.push(this.imageUrl4);
    this.statusColorIcon(this.displayImg.status);
  }

  //----------------------------------------------------------------------------------
  private convertBase64ToBinary(data: any, index: number) {
    let blob;
    if (data.images) {
      const binaryData = atob(data.images.highMag.fiberImage.dataBase64);
      const buffer = new ArrayBuffer(binaryData.length);
      const view = new Uint8Array(buffer);
      for (let i = 0; i < binaryData.length; i++) {
        view[i] = binaryData.charCodeAt(i);
      }
      blob = new Blob([buffer], { type: 'image/png' });
    }
    let rowData = [];
    rowData.push(
      {
        'img': blob ? URL.createObjectURL(blob) : null,
        "rowPos": data.rowPos,
        "columnPos": data.columnPos,
        "width": data.images ? data.images.highMag.fiberImage.width : null,
        'index': index, "status": data.status,
        "height": data.images ? data.images.highMag.fiberImage.height : null,
        'overallEvaluationResult': data.overallEvaluationResult
      });

    rowData.sort((a, b) => a.columnPos - b.columnPos);

    return rowData;
  }

  //----------------------------------------------------------------------------------
  displayImgClick(img: any) {
    this.displayImg = img;
    this.overallEvaluationResult = img.overallEvaluationResult;
    this.selectedImageIndex = img.index;
  }

  //----------------------------------------------------------------------------------
  statusColorIcon(value: any) {
    this.statusColor = this.StatusFailPassService.statusColorIcon(value).statusColor;   
    this.statuIcon = this.StatusFailPassService.statusColorIcon(value).icon;  
    }
}
