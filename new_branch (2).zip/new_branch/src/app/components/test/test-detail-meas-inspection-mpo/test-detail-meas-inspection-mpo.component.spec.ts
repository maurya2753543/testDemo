import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasInspectionMpoComponent } from './test-detail-meas-inspection-mpo.component';

describe('TestDetailMeasInspectionMpoComponent', () => {
  let component: TestDetailMeasInspectionMpoComponent;
  let fixture: ComponentFixture<TestDetailMeasInspectionMpoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestDetailMeasInspectionMpoComponent]
    });
    fixture = TestBed.createComponent(TestDetailMeasInspectionMpoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
