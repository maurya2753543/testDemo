import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasFcproComponent } from './test-detail-meas-fcpro.component';

describe('TestDetailMeasFcproComponent', () => {
  let component: TestDetailMeasFcproComponent;
  let fixture: ComponentFixture<TestDetailMeasFcproComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestDetailMeasFcproComponent]
    });
    fixture = TestBed.createComponent(TestDetailMeasFcproComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
