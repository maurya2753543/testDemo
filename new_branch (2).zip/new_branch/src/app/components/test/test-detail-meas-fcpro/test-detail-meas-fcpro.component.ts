import { Component } from '@angular/core';

@Component({
  selector: 'app-test-detail-meas-fcpro',
  templateUrl: './test-detail-meas-fcpro.component.html',
  styleUrls: ['./test-detail-meas-fcpro.component.scss']
})
export class TestDetailMeasFcproComponent {

}
