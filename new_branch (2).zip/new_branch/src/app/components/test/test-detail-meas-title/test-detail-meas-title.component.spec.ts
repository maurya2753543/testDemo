import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasurementTitleComponent } from './test-detail-meas-title.component';

describe('TestDetailMeasurementTitleComponent', () => {
  let component: TestDetailMeasurementTitleComponent;
  let fixture: ComponentFixture<TestDetailMeasurementTitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailMeasurementTitleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailMeasurementTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
