import { Component, Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { INSPECTION_GRID } from 'src/app/shared/app.constants';

@Component({
  selector: 'app-test-detail-meas-inspection',
  templateUrl: './test-detail-meas-inspection.component.html',
  styleUrls: ['./test-detail-meas-inspection.component.scss']
})

export class TestMeasurementInspectionComponent {
  columnInspetionDefs: ColDef[] = INSPECTION_GRID;

  //----------------------------------------------------------------------------------
  @Input() DarkThemesApply: any;
  @Input() detailData: any
  inspectionData: any;
  checkedFiberAndOverlaysImage: boolean = true;
  inspectionDataImg: any;

  //----------------------------------------------------------------------------------
  ngOnChanges() {
    this.inspectionData = this.detailData.tests[0];
    this.inspectionDataImg = this.inspectionData.results.data.endfaces[0].images;
    const dynamicDivCollection = document.getElementsByClassName("image-container");
    // Check if any element with the specified class is found
    if (dynamicDivCollection.length > 0) {
      /** Access the first element in the collection */
      const dynamicDiv = dynamicDivCollection[0] as HTMLElement;
      /** Set the dynamic height and width */
      dynamicDiv.style.height = this.inspectionDataImg.lowMag.fiberImage.height + "px";
      dynamicDiv.style.width = this.inspectionDataImg.lowMag.fiberImage.width + "px";
    }
  }

  //----------------------------------------------------------------------------------
  onShowFiberAndOverlaysImage(checked: boolean) {
    this.checkedFiberAndOverlaysImage = checked;
  }
}
