import { Component, Output, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { SelectionModel } from '@angular/cdk/collections';

interface ColumnNode {
  name: string;
  enabled: boolean;
  children?: ColumnNode[];
}
@Component({
  selector: 'app-custom-side-bar',
  templateUrl: './custom-side-bar.component.html',
  styleUrls: ['./custom-side-bar.component.scss']
})
export class CustomSideBarComponent implements OnInit {
  @ViewChild('TestGridPanelComponent')
  filterGrid!: TestGridPanelComponent;
  treeControl = new NestedTreeControl<ColumnNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<ColumnNode>();
  checklistSelection = new SelectionModel<ColumnNode>(true);

  //----------------------------------------------------------------------------------
  constructor(private SharedService: SharedService, private ProjectsService: ProjectsService) {
  }

  //----------------------------------------------------------------------------------
  hasChild = (_: number, node: ColumnNode) => !!node.children && node.children.length > 0;

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.fetchData()
  }

  //----------------------------------------------------------------------------------
  private async fetchData() {
    this.dataSource.data = this.ProjectsService.getColumnsTable();
  }

  //----------------------------------------------------------------------------------
  @Output() toggleColumnVisibility = new EventEmitter<string>();
  mainGridColumnDefs: any

  //----------------------------------------------------------------------------------
  /** Custom Hide and Show Coulumns in ag-grid */
  onToggleColumnVisibility(columnsFiled: string) {
    /** Find the column definition object with the matching field property */
    let matchingObj;
    this.mainGridColumnDefs = this.SharedService.getColumnDefinations();
    for (const group of this.mainGridColumnDefs) {
      for (const column of group.children) {
        if (column.field === columnsFiled) {
          matchingObj = column;
          break; // If you only want the first match, you can break out of the loop.
        }
      }
      if (matchingObj) {
        matchingObj.hide = !matchingObj.hide; // Or false to show the column
        const gridApi = this.SharedService.getGridApi();
        gridApi.setColumnDefs(this.mainGridColumnDefs);
        break; // If you found a match, break out of the outer loop as well.
      }
    }
  }

  //----------------------------------------------------------------------------------
  onCheckBoxClicked(columnsFiled: any) {
    this.ProjectsService.setColumnHideState(columnsFiled.category, columnsFiled.name, !columnsFiled.enabled);
    this.onToggleColumnVisibility(columnsFiled.name);
  }

}
