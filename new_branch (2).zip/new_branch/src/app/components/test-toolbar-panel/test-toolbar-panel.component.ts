import { Component, Input  } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import {MatDialog} from '@angular/material/dialog';
import {
    faFileExport,
    faCloudArrowDown,
    faPenToSquare,
    faUsbDrive,
    faFileImport,
    faEllipsis,
    faTruckMoving,
    faTrash
  } from '@fortawesome/pro-solid-svg-icons'

@Component({
  selector: 'app-test-toolbar-panel',
  templateUrl: './test-toolbar-panel.component.html',
  styleUrls: ['./test-toolbar-panel.component.scss']
})
export class TestToolbarPanelComponent {
    faFileExport = faFileExport
    faEllipsis = faEllipsis
    faCloudArrowDown = faCloudArrowDown
    faPenToSquare = faPenToSquare
    faUsbDrive = faUsbDrive
    faFileImport = faFileImport

    faTruckMoving = faTruckMoving
    faTrash = faTrash

    constructor( private sharedService: SharedService, public dialog: MatDialog) {

    }

    exportToCSV(event:any) {
        this.sharedService.sendClickEvent(event)
    }


    openeditFiberIdDialog(): void {
      // dialogRef.afterClosed().subscribe(result => {
      //   console.log('The dialog was closed');
      //   this.animal = result;
      // });

      // this.menuUpdateDialogService.openDialog();
      // this.menuUpdateDialogService.openDialog(this.selectedRows, this.dar);

      // dialogRef.afterClosed().subscribe(result => {
      //   console.log(`Dialog result: ${result}`);
      // });
    }


}


