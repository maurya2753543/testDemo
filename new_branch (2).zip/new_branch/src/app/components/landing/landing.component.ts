import { Component } from '@angular/core';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';
import {
    MatSnackBar,
    MatSnackBarHorizontalPosition,
    MatSnackBarModule,
    MatSnackBarVerticalPosition,
  } from '@angular/material/snack-bar';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']

})
export class LandingComponent {

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor( private globalSettings : GlobalSettingsService, private _snackBar: MatSnackBar, public sharedService: SharedService ) {

        // this insures the global settings service is active early on
        globalSettings.getLanguage();

        sharedService.globalMsgSubject$.subscribe( (msg) => {

            this.openSnackBar( msg.msgLeft, msg.msgRight) ;
        })

        //this.openSnackBar("Global Msg Servcice Started", "close"); 

    
}

openSnackBar(msgLeft:string, msgRight:string) {
    this._snackBar.open(msgLeft, msgRight, {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 5000,
    });
  }


}
    

