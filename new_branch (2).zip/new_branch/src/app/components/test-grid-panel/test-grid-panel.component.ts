import {
  Component,
  OnInit,
  EventEmitter,
  Output,
  OnDestroy,
} from '@angular/core';
import { TestGridCellComponent } from '../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';
import { SharedService } from 'src/app/services/shared.service';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { Subscription, retry } from 'rxjs';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

import {
  faCircleX,
  faCircleCheck,
  faEdit,
} from '@fortawesome/pro-solid-svg-icons';
import {
  ColDef,
  GridReadyEvent,
  IDateFilterParams,
  ITextFilterParams,
  RowDropZoneParams
} from 'ag-grid-community';
import { INumberFilterParams } from '@ag-grid-community/core';

@Component({
  selector: 'app-test-grid-panel',
  templateUrl: './test-grid-panel.component.html',
  styleUrls: ['./test-grid-panel.component.scss'],
})
export class TestGridPanelComponent implements OnInit, OnDestroy {
  //dark thems
  isDarkThemesActive: boolean = false;
  @Output() childEvent = new EventEmitter();
  @Output() rowEvent = new EventEmitter();
  rowData: any;
  gridApi: any;
  private gridColumnApi: any;
  gridOptionsApi: any;
  selectedRows: any = [];
  selectedRow: any = [];
  treeData: any = [];
  faCircleX = faCircleX;
  faCircleCheck = faCircleCheck;
  faEdit = faEdit;
  clickEventSubscription: Subscription;
  disableNavigationButtons: boolean = false;

  public autoGroupColumnDef: ColDef = {
    minWidth: 200,
  };
  items: string[] = ['Item 1', 'Item 2', 'Item 3'];
  isVisible = false;
  selectedRowIndex: number = 0;
  list: any = [];

  private darkThemesubscription!: Subscription;

  DarkThemesApply: any;

  activeNodeId: string = '';
  selectedNode: any;



  public overlayLoadingTemplate =
    '<span class="ag-overlay-loading-center">No data to show,  Create a project and import test resuts</span>';
  public overlayNoRowsTemplate =
    '<span style="padding: 10px; border: 2px solid #444; color : black; background: lightgoldenrodyellow;">This project as no data, please import some test results</span>';


  //----------------------------------------------------------------------------------
  constructor(
    private projectsService: ProjectsService,
    private sharedService: SharedService,
    public darkModeService: DarkModeService
  ) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });
    //---------------------------------------------------------------------------------


    this.sharedService.updatedSelectedRowSubject$.subscribe((rowsData) => {
      rowsData.forEach((row: any) => {
        const indexToUpdate = this.rowData.findIndex((item: { id: any; }) => item.id === row.id);
        if (indexToUpdate !== -1) {
          this.rowData[indexToUpdate] = row;
        }
      });
      this.gridApi.setRowData(this.rowData);
      setTimeout(() => {
        this.onFirstDataRendered();
      }, 50);

    })

    this.projectsService.activeNodeSubject$.subscribe((id) => {
      this.activeNodeId = id;
      // pull the data from this id
      this.projectsService.getProjectData(id).then((data) => {
        this.rowData = data;
      });

      this.projectsService.projectDataUpdatedSubject$.subscribe((message) => {
        this.projectsService.getProjectData(null).then((data) => {
          //mg todo check the null
          this.rowData = data;

          //  this.getColumnsDefsByType("Common");
        });
        // this.gridApi.setRowData(this.rowData);
        //this.rowEvent.emit(this.selectedRow);
      });

      this.projectsService.selectedResultSubject$.subscribe((message) => {
        //console.log('Grid selected ', message);
      });

      setTimeout(() => {
        this.onFirstDataRendered();
      }, 50);
    });

    this.clickEventSubscription = this.sharedService
      .getClickEvent()
      .subscribe(() => {
        // for the dark themes
        this.getSelectedRows();
      });

    this.sharedService.isVisibleSource.next(this.isVisible);
    // this.sharedService.columnDefs.next(this.columnDefs);

    if (this.projectsService.selectedResult) {

      this.getColumnsDefsByType(this.projectsService.selectedResult.measType);
      //   switch (this.projectsService.selectedResult.measType) {
      //     case 'fiberInspection':
      //       this.getColumnsDefsByType('Fiber Inspection');
      //       break;
      //     case 'truepon':
      //       this.getColumnsDefsByType('TruePON Test');
      //       break;
      //     case 'opticalloss':
      //       this.getColumnsDefsByType('Optical Loss Test');
      //       break;
      //     case 'powermeter':
      //       this.getColumnsDefsByType('Optical Power Test');
      //       break;
      //     default:
      //       break;
      //   }
    }

    this.sharedService.setColumnDefincation(this.columnDefs);
    // this.sharedService.setColumnDefincation(this.columnDefs);
    //  this.columnDefs = this.sharedService.getColumnDefs();
  }

  //----------------------------------------------------------------------------------
  onNoRowButtonClick() {
    console.log("Import test data")
  }


  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });
    this.darkThemesubscription = this.darkModeService.DarkThemeEvent.subscribe(
      () => {
        this.handleEvent();
      }
    );

    this.sharedService.valuePrevNext$.subscribe((value) => {
      if (value === 'Previous') {
        this.selectPreviousRow();
      } else {
        this.selectNextRow();
      }
      // Handle the value update in the grand-grand-grandparent component
    });
  }

  //----------------------------------------------------------------------------------
  theme(value: string) {
    if (value) {
      document.getElementsByTagName('body')[0].classList.add(value);
    } else {
      document.getElementsByTagName('body')[0].classList.remove('dark-theme');
    }
    this.#theme = value;
  }


  //----------------------------------------------------------------------------------
  #theme: string = '';
  handleEvent() {
    if (this.#theme === 'dark-theme') {
      this.isDarkThemesActive = false;
      this.#theme = '';
    } else {
      this.isDarkThemesActive = true;
      this.#theme = 'dark-theme';
    }
    this.theme(this.#theme);
  }

  //----------------------------------------------------------------------------------
  ngOnDestroy() {
    this.darkThemesubscription.unsubscribe();
  }

  //----------------------------------------------------------------------------------
  onItemDropped(event: CdkDragDrop<any[]>) { }

  //----------------------------------------------------------------------------------
  OnValueChangeTest(income: any) {
    this.gridApi.setColumnDefs(income);     // todo fix this
  }

  //----------------------------------------------------------------------------------
  theDateFilterParameters = {
    buttons: [$localize`reset`, $localize`apply`],
    closeOnApply: true,
  } as IDateFilterParams;

  //----------------------------------------------------------------------------------
  theTextFilterParameters = {
    buttons: [$localize`reset`, $localize`apply`],
    closeOnApply: true,
  } as ITextFilterParams;

  //----------------------------------------------------------------------------------
  theNumberFilterParameters = {
    buttons: [$localize`reset`, $localize`apply`],
    closeOnApply: true,
  } as INumberFilterParams;

  //----------------------------------------------------------------------------------
  commonColumnDefs = [
    {
      headerName: 'Common',
      children: [
        {

          field: 'Timestamp',
          width: 250,
          checkboxSelection: true,
          headerCheckboxSelection: true,
          filter: 'agDateColumnFilter',
          filterParams: this.theDateFilterParameters,
          headerTooltip: 'Time Stamp',
          hide: false,
        },
        {

          field: 'Test',
          headerName: $localize`Test Type`,
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Test Type',
        },
        {

          field: 'Location',
          headerName: $localize`Cable ID`,
          editable: true,
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Cable ID',
          hide: false,
        },
        {

          field: 'Status',
          cellRenderer: TestGridCellComponent,
          width: 100,
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Status',
          hide: false,
        },
        {

          field: 'technician',
          headerName: 'Technician',
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Technician / Operator',
          editable: true,
          hide: false,
        },
        {

          field: 'Limit Type',
          headerName: 'Limit Type',
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Limit Type',
          hide: false,
        },
        {

          field: 'device',
          headerName: $localize`Device`,
          filterParams: this.theTextFilterParameters,
          headerTooltip: 'Device',
          hide: false,
        },
        {

          headerName: $localize`UID`,
          hide: false,
          columnGroupShow: 'open',
        },
      ],
    },
  ];

  columnDefs = this.commonColumnDefs;

  defaultColDef: ColDef = { sortable: true, filter: true, resizable: true };
  //----------------------------------------------------------------------------------
  getColumnsDefsByType(type: any) {
    let additionalColumns = this.projectsService.getColumnsListbyRow(type);
    let commonColumns = this.projectsService.getCommonColumnsList();

    //this.columnDefs = this.commonColumnDefs.concat(additionalColumns);
    this.columnDefs = commonColumns.concat(additionalColumns);

    this.sharedService.setColumnDefincation(this.columnDefs);
    // this.sharedService.setColumnDefincation( this.gridColumnApi.getColumnDefs() );
  }

  //----------------------------------------------------------------------------------
  // rowDragEntireRow = true
  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    this.sharedService.setGridApi(this.gridApi);

    this.addDropZones(params);
    this.addCheckboxListener(params);
  }

  //----------------------------------------------------------------------------------
  onFirstDataRendered() {
    // Select the first row after the first data rendering is completed
    const nodes = this.gridApi.getRenderedNodes();
    if (nodes.length > 0) {
      nodes[0].setSelected(true); // Selects the first row in the rendered view
      this.selectedRowIndex = 0;
      this.selectedRows = this.gridApi.getSelectedRows();
      this.rowEvent.emit(this.selectedRowIndex);

      this.projectsService.setSelectedResult(this.rowData[0]);
      this.getColumnsDefsByType(this.rowData[0].TestId);
    }
  }

  //----------------------------------------------------------------------------------
  addCheckboxListener(params: GridReadyEvent) {
    var checkbox = document.querySelector('input[type=checkbox]')! as any;
    checkbox.addEventListener('change', function () {
      params.api.setSuppressMoveWhenRowDragging(checkbox.checked);
    });
  }
  //----------------------------------------------------------------------------------
  addDropZones(params: GridReadyEvent) {
    var tileContainer = document.querySelector('.tile-container') as any;
    var dropZone: RowDropZoneParams = {
      getContainer: () => {
        return tileContainer as any;
      },
      onDragStop: (params) => { },
    };
    params.api.addRowDropZone(dropZone);
  }

  //----------------------------------------------------------------------------------
  getSelectedRows(e?: any) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });
    this.selectedRows = [];
    this.selectedRows = this.gridApi.getSelectedRows();
    this.sharedService.setSelectedRowsData(this.gridApi.getSelectedRows());
    this.selectedRowsEmitEvent();
    this.navigatorStatusChange();
  }

  //----------------------------------------------------------------------------------
  selectedRowsEmitEvent() {
    this.childEvent.emit(this.selectedRows);
  }

  //---------------------------------------------------------------------
  onRowSelected(event: any) {
    if (event.event) {
      this.selectedRowIndex = event.rowIndex;
      this.selectedRow = event.data;
      // if(this.selectedRow < 0){
      //   this.rowEvent.emit(this.selectedRow);
      // }
      this.projectsService.setSelectedResult(event.data);
      this.sharedService.setSelectedRowsData(event.api.getSelectedRows());
      this.sharedService.setNoRowPdfData(event.node.selected);
      this.getColumnsDefsByType(event.data.TestId);
    }

  }

  //------------------------------------------------------------------------------------

  navigatorStatusChange() {
    const selectedNodes = this.gridApi.getSelectedNodes();
    if (selectedNodes.length > 0) {
      const firstIndex = selectedNodes[0].rowIndex;
      const lastIndex = selectedNodes[selectedNodes.length - 1].rowIndex;
      const displayedNodes = this.gridApi.getRenderedNodes();
      if (lastIndex < displayedNodes.length - 1) {

        this.sharedService.setDisableNavigationNextButtons(false); // Enable "Next" button
      } else {
        this.sharedService.setDisableNavigationNextButtons(true); // Disable "Next" button
      }
      // for previous logic
      if (firstIndex) {
        // There are more rows below the last selected row
        this.sharedService.setDisableNavigationPreviousButtons(false); // Enable "Next" button
      } else {
        // No more rows below the last selected row
        this.sharedService.setDisableNavigationPreviousButtons(true); // Disable "Next" button
      }
      // logic for disable nevigation previous
    }
  }
  //---------------------------------------------------------------------
  // logic for previous node
  selectPreviousRow() {
    setTimeout(() => {
      const selectedNodes = this.gridApi.getSelectedNodes();
      const displayedNodes = this.gridApi.getRenderedNodes();
      if (displayedNodes.length > 0) {
        const firstSelectedRowIndex = selectedNodes[0].rowIndex;
        displayedNodes[firstSelectedRowIndex - 1].setSelected(true);
        this.selectedRowIndex = firstSelectedRowIndex - 1;
        this.selectedRow = displayedNodes[firstSelectedRowIndex - 1].data;
        this.rowEvent.emit(this.selectedRow);
        this.projectsService.setSelectedResult(this.selectedRow);
        this.getColumnsDefsByType(this.selectedRow.TestId);
      }
    }, 5);
  }
  //---------------------------------------------------------------------
  // logic for Selected previous nodes

  selectNextRow() {
    setTimeout(() => {
      const selectedNodes = this.gridApi.getSelectedNodes();
      const displayedNodes = this.gridApi.getRenderedNodes();
      const lastIndex = selectedNodes.length - 1;
      const lastSelectedRowIndex = lastIndex >= 0 ? selectedNodes[lastIndex].rowIndex : -1;
      const nextNode = this.gridApi.getDisplayedRowAtIndex(lastSelectedRowIndex + 1);
      if (!nextNode) {
        // No next node, do nothing
        return;
      }
      nextNode.setSelected(true);
      if (lastSelectedRowIndex < 0) {
        // No selected nodes, do nothing
        return;
      }
      this.selectedRowIndex = lastSelectedRowIndex + 1;
      this.selectedRow = displayedNodes[lastSelectedRowIndex + 1].data;
      this.rowEvent.emit(this.selectedRow);
      this.projectsService.setSelectedResult(this.selectedRow);
      this.getColumnsDefsByType(this.selectedRow.TestId);
    }, 5);
  }

  //----------------------------------------------------------------------------------
  onRowDragStart(event: any) {
    const { rowNode } = event;
    const data = rowNode.data;
    const jsonData = JSON.stringify(data);

    event.dataTransfer.setData('text/palin', jsonData);
  }

  //----------------------------------------------------------------------------------
  onRowDragEnd(event: any) {
    // handle the data being dragged here
  }

  //----------------------------------------------------------------------------------
  onDragOver(event: any) {
    var dragSupported = event.dataTransfer.length;
    if (dragSupported) {
      event.dataTransfer.dropEffect = 'move';
    }
    event.preventDefault();
  }

  //----------------------------------------------------------------------------------
  onDrop(event: any) {
    var jsonData = event.dataTransfer.getData('application/json');
    var eJsonRow = document.createElement('div');
    eJsonRow.classList.add('json-row');
    eJsonRow.innerText = jsonData;
    // var eJsonDisplay = document.querySelector('#eJsonDisplay')!;
    // eJsonDisplay.appendChild(eJsonRow);
    var data = JSON.parse(jsonData);
    event.preventDefault();
  }

  onFileDrop (event:any) {
    console.log( event.target.files)
}
}
