import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsPdfPopupComponent } from './details-pdf-popup.component';

describe('DetailsPdfPopupComponent', () => {
  let component: DetailsPdfPopupComponent;
  let fixture: ComponentFixture<DetailsPdfPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetailsPdfPopupComponent]
    });
    fixture = TestBed.createComponent(DetailsPdfPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
