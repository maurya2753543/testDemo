import { Component, Input, Inject, OnInit } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { ProjectsService } from 'src/app/services/projects.service';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { saveAs } from 'file-saver-es';
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
import { HttpClient } from '@angular/common/http';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedService } from 'src/app/services/shared.service';
import {
  OPTICAL_POWER_GRID_1,
  TIER_1_MPO,
  TIER_1,
  INSPECTION_GRID,
  OPTICAL_POWER_LOSS_GRID_2,
  OPTICAL_LOSS_GRID_1,
  OTDR_GRID,
} from 'src/app/shared/app.constants';
import { ColDef } from 'ag-grid-community';
// Declare the type for TDocumentDefinitions
interface TDocumentDefinitions {
  content: any[];
  styles?: any;
  pageSize?: any;
  pageOrientation?: any;
  pageMargins?: any;
  defaultStyle?: any;
  header?: any;
  footer?: any;
  images?: any;
  columns?: any;
  background?: any;
  pageBreakBefore?: (
    currentNode: any,
    followingNodesOnPage: any,
    nodesOnNextPage: any,
    previousNodesOnPage: any
  ) => boolean;
  pageBreakAfter?: (currentNode: any, nodesOnNextPage: any) => boolean;
}

@Component({
  selector: 'app-details-pdf-popup',
  templateUrl: './details-pdf-popup.component.html',
  styleUrls: ['./details-pdf-popup.component.scss'],
})
export class DetailsPdfPopupComponent implements OnInit {
  rowPdfData: any;
  MappingPdfReportInfo: any = [];
  @Input() DarkThemesApply: any;
  //map details dat info
  // datils data info
  inputValue: any;
  projectName: any; // for  anme selection
  selectedId: string | null = null;
  selectedName: any;
  noRowselected: any;
  dataSourcecolumnOpticalPowerTest1: any[] = []; // this data source for Optical power test
  dataSourcecolumnOpticalPowerTest2: any[] = [];
  dataSourceColumnOpticallOSSTest1: any[] = []; // this data source for Optical loss test
  dataSourceColumnOpticallOSSTest2: any[] = [];
  dataSourceColumnTier1MPODefs: any[] = [];
  dataSourceColumnTier1MPODefs2: any[] = [];
  dataSourceColumnTier1: any[] = [];
  dataSourceColumnOTDR: any[] = [];
  dataSourceColumnFiberInspection: any[] = [];
  dataSourceColumnFiberInspectionLenght1: any[] = [];
  opticalPowerConfig: any;
  // true OPN
  truePonGponPdf: any;
  truePonxgsponPdf: any;
  truePonConfigPdf: any;
  ontdetectionGponPdf: any;
  ontdetectionXponPdf: any;
  ontdetectionConfigPdf: any;
  //----------------------------------------------------------------------------------
  // drag image
  draggedImage: any;
  detailInfo: any = [];
  // define all details test location here
  //-------------------------------------------------------------------------------
  headerNames = [
    { field: 'Timestamp', displayName: 'Time Stamp' },
    { field: 'Test', displayName: 'Test Type' },
    { field: 'Location', displayName: 'Cable ID' },
    { field: 'Status', displayName: 'Status' },
    { field: 'Limit', displayName: 'Limit Type' },
    { field: 'device', displayName: 'Device' },
  ];

  //--------------------------------------------------------------------------------
  columnTier1MPODefs: ColDef[] = TIER_1_MPO;
  //--------------------------------------------------------------------------------
  columnTier1: ColDef[] = TIER_1;
  //--------------------------------------------------------------------------------
  //--------------------------------------------------------------------------------
  columnOTDR_GRID: ColDef[] = OTDR_GRID;
  //--------------------------------------------------------------------------------
  //--------------------------------------------------------------------------------
  columnInspectionGrid: ColDef[] = INSPECTION_GRID;
  //--------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------
  columnOpticalPowerTest1 = OPTICAL_POWER_GRID_1;
  //--------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------
  columnOpticalPowerTest2 = OPTICAL_POWER_LOSS_GRID_2;
  //--------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------
  columnOpticallOSSTest1: ColDef[] = OPTICAL_LOSS_GRID_1;
  //--------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------
  columnOpticallOSSTest2 = OPTICAL_POWER_LOSS_GRID_2;
  //--------------------------------------------------------------------------------

  // //--------------------------------------------------------------------------------
  // columnTierDefs: ColDef[] = TIER_1_MPO;
  // //--------------------------------------------------------------------------------

  // Create a header row with centered alignment
  columnHeaders = this.headerNames.map((header) => ({
    text: header.displayName,
    bold: true,
  }));

  tableData = [this.columnHeaders]; // Create header row

  //----------------------------------------------------------------------------------
  constructor(
    public darkModeService: DarkModeService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public ProjectsService: ProjectsService,
    private http: HttpClient,
    private SharedService: SharedService
  ) {}

  ngOnInit(): void {
    this.SharedService.getSelectedRowsData().subscribe((data) => {
      this.rowPdfData = data;
      this.rowPdfData.forEach((child: any, index: number) => {
        this.ProjectsService.getResultById(child.id).then((result: any) => {
          this.detailInfo.push(this.ProjectsService.getResultFile(result));
          const selectedRowCount = this.detailInfo.length;

          for (let i = 0; i < selectedRowCount; i++) {
            const record = this.detailInfo[i];

            let MeasureType = '';

            MeasureType = this.detailInfo[i].tests[0].type;

            if (MeasureType === 'powermeter') {
              this.dataSourcecolumnOpticalPowerTest1 =
                record.tests[0].results.data.measuredResults;
              this.dataSourcecolumnOpticalPowerTest2 =
                record.tests[0].configuration.setup;
              this.opticalPowerConfig = record.tests[0].configuration;
            } else if (MeasureType === 'opticalloss') {
              this.dataSourceColumnOpticallOSSTest1 =
                record.tests[0].results.data.measuredResults;
              this.dataSourceColumnOpticallOSSTest2 =
                record.tests[0].configuration.setup;
              this.opticalPowerConfig = record.tests[0].configuration;
            } else if (MeasureType === 'truepon') {
              this.truePonGponPdf = record.tests[0].results.data.gpon;
              this.truePonConfigPdf = record.tests[0].configuration;
              this.truePonxgsponPdf = record.tests[0].results.data.xgspon;
            } else if (
              MeasureType === 'fiberInspection' &&
              record.tests[0].results.data.endfaces.length === 1
            ) {
              this.dataSourceColumnFiberInspectionLenght1 =
                record.tests[0].results.data.endfaces[0].overallEvaluationResult.zones;
            } else if (MeasureType === 'fiberInspection') {
              this.dataSourceColumnFiberInspection =
              record.tests[0].results.data.endfaces[0].overallEvaluationResult.zones;
            } else if (MeasureType === 'tier1') {
              this.dataSourceColumnTier1 = record.tests[0].results.data.optical;
            } else if (MeasureType === 'tier1mpo') {
              this.dataSourceColumnTier1MPODefs =
                record.tests[0].results.data.optical[0].channels;
              this.dataSourceColumnTier1MPODefs2 =
                record.tests[0].results.data.optical[1].channels;

              //TIER_1_MPO
            } else if (MeasureType === 'fcompPro') {
            } else if (MeasureType === 'OTDR') {
              this.dataSourceColumnOTDR =
                record.tests[0].results.data.otdrResults.measuredResults;
            } else if (MeasureType === 'ontdetection') {
              this.ontdetectionGponPdf = record.tests[0].results.data.gpon;
              this.ontdetectionConfigPdf = record.tests[0].configuration;
              this.ontdetectionXponPdf = record.tests[0].results.data.xgspon;
            }
          }
        });
        const dataRow = this.headerNames.map((header) => child[header.field]);
        this.tableData.push(dataRow);
      });
    });
    const ReportInfodata = this.ProjectsService.getActiveProject()
      .reportInformation
      ? this.ProjectsService.getActiveProject().reportInformation
      : this.ProjectsService.settings.reportInformation;
    this.draggedImage = ReportInfodata.companyLogo;
    this.MappingPdfReportInfo = ReportInfodata;
    this.projectName = this.ProjectsService.getActiveNode();
    this.updateInputValueWithDateTime();
  }
  //---------------------------------------------------------------------------------------

  updateInputValueWithDateTime(): void {
    // Get the current date and time
    const currentDateTime = new Date();
    const formattedDateTime = this.formatDateTime(currentDateTime);
    this.inputValue = this.projectName.name + '  ' + formattedDateTime;
  }

  //----------------------------------------------------------------------------------
  formatDateTime(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Add 1 because months are zero-based
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }

  //----------------------------------------------------------------------------------
  saveInputPdf() {
    // Fetch the SVG image using HttpClient
    this.http
      .get('assets/images/viavi_logo_rgb_purple.svg', { responseType: 'text' })
      .subscribe((svgContent: string) => {
        const logoImage = new Image();
        logoImage.src =
          'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgContent);
        const image = new Image();
        const backgroundColor = '#FFFFFF'; // HEX color code for red
        const logoWidth = 200;
        const logoHeight = 40;
        image.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = logoWidth;
          canvas.height = logoHeight;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = backgroundColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(logoImage, 0, 0, logoWidth, logoHeight);
            const jpgDataURL = canvas.toDataURL('image/jpeg');
            const companyTitle = this.MappingPdfReportInfo.company;
            const streetaddressTitle = this.MappingPdfReportInfo.streetaddress;
            const cityTitle = this.MappingPdfReportInfo.city;
            const postalcodeTitle = this.MappingPdfReportInfo.postalcode;
            const reportTitle =
              this.MappingPdfReportInfo.title || this.rowPdfData[0].Test;
            const desiredWidth = 90; // Desired width for the logo
            const contentStack = [];
            contentStack.push({
              text: companyTitle ? `Company: ${companyTitle} ` : '',
              bold: true,
              fontSize: 8,
              alignment: 'left',
              width: '100', // Set the maximum width
              noWrap: false,
            });
            // Check if at least one address field has data before showing the address section
            const addressStack = [];
            addressStack.push({
              text: streetaddressTitle
                ? `Street Address: ${streetaddressTitle} `
                : '',
              bold: true,
              fontSize: 8,
              alignment: 'left',
              width: '100', // Set the maximum width
              noWrap: false,
            });
            addressStack.push({
              text: cityTitle ? `City: ${cityTitle} ` : '',
              bold: true,
              fontSize: 8,
              alignment: 'left',
              width: '100', // Set the maximum width
              noWrap: false,
            });
            addressStack.push({
              text: postalcodeTitle ? `Postal Code: ${postalcodeTitle} ` : '',
              bold: true,
              fontSize: 8,
              alignment: 'left',
              margin: [0, 0, 0, 0],
              width: '100', // Set the maximum width
              noWrap: false,
            });
            contentStack.push({
              stack: addressStack,
            });
            const finalStack = {
              stack: contentStack,
              margin: [0, 5, 0, 0],
            };
            // here i declared first page containt
            const firstPageContent = [
              {
                table: {
                  headerRows: 1, // Treat the first row as the header
                  widths: ['20%', '20%', '40%', '20%'], // Adjust widths as needed
                  layout: {
                    hLineColor: () => '#000000', // Color of horizontal lines between rows
                    vLineColor: () => '#000000', // Color of vertical lines between columns
                  },
                  body: [
                    [
                      {
                        stack: [
                          this.draggedImage
                            ? {
                                image: this.draggedImage,
                                width: desiredWidth,
                                margin: [0, 5, 0, 0],
                                fontSize: 14,
                              }
                            : null,
                        ],
                      },
                      {
                        stack: [finalStack],
                      },
                      {
                        text: `${reportTitle}`,
                        fontSize: 14,
                        bold: true,
                        alignment: 'center',
                        margin: [0, 5, 100, 0],
                      },
                      {
                        stack: [
                          {
                            stack: [
                              {
                                image: jpgDataURL,
                                width: desiredWidth,
                                height: 40,
                                alignment: 'right',
                                margin: [0, 0, 0, 0],
                              },
                              {
                                text: 'ReportPRO v1.0',
                                fontSize: 9,
                                bold: true,
                                color: '#500778',
                                alignment: 'right',
                                margin: [0, 0, 10, 0],
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  ],
                },
                layout: 'lightHorizontalLines', // Apply lines within the table
              },
              {
                table: {
                  widths: ['50%', '50%'], // Equal width for both columns
                  layout: {
                    hLineColor: () => '#000000', // Color of horizontal lines between rows
                    vLineColor: () => '#000000', // Color of vertical lines between columns
                  },
                  body: [
                    [
                      {
                        text: formatDate(new Date()), // Format and display the current date
                        style: 'date',
                        alignment: 'right',
                        fontSize: 10,
                        margin: [0, 5, 0, 5],
                      },
                      {
                        text: formatTime(new Date()), // Format and display the current time
                        style: 'time',
                        alignment: 'left',
                        fontSize: 10,
                        margin: [0, 5, 0, 5],
                      },
                    ],
                  ],
                  // Remove all cell borders
                },
                layout: 'lightHorizontalLines', // Apply lines within the table
              },
              {
                table: {
                  widths: ['*'],
                  // Set the column widths as needed
                  body: [
                    [
                      {
                        table: {
                          headerRows: 1,
                          body: this.tableData,
                          layout: {
                            hLineColor: () => '#000000', // Color of horizontal lines between rows
                            vLineColor: () => '#000000', // Color of vertical lines between columns
                          },
                        },
                        layout: 'lightHorizontalLines', // Apply lines within the table
                      },
                    ],
                  ],
                },
              },
              // Other content elements...
            ];
            const pdfPages: any[] = [];
            //----------------------------------------------------------------------------------
            // Assuming this.selectedRows is an array of selected rows
            const selectedRowCount = this.detailInfo.length;
            if (selectedRowCount > 0) {
              for (let i = 0; i < selectedRowCount; i++) {
                const record = this.detailInfo[i]; // Get the current selected record
                const TestLocation =
                  record.tests?.[0]?.testLocations?.[0]?.label || '';
                const DateandTime = record.tests?.[0]?.results?.testTime || '';
                const Comment = record.tests?.[0]?.results?.comment || '';
                const TechnicianDetails = record.assetInfo?.techId || '';
                const DetailsTesttype = record.tests?.[0]?.label || '';
                const DetailsStatus = record.tests?.[0]?.results?.status || '';
                const PowerUnite = this.opticalPowerConfig?.powerUnit || '';
                const MeasureUnit =
                  this.opticalPowerConfig?.measurementMode || '';

                let MeasureType = '';

                MeasureType = this.detailInfo[i].tests[0].type;

                if (MeasureType === 'powermeter') {
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      widths: ['33.33%', '33.33%', '33.33%'], // Adjust widths as needed
                      body: [
                        // Header Row
                        this.columnOpticalPowerTest1.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourcecolumnOpticalPowerTest1?.map(
                          (rowData) =>
                            this.columnOpticalPowerTest1.map(
                              (header) => rowData[header.field]
                            )
                        ),
                      ],
                    },
                  };

                  // Create the table definition for table 1
                  const table2 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      body: [
                        // Header Row
                        this.columnOpticalPowerTest2.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourcecolumnOpticalPowerTest2?.map(
                          (rowData) =>
                            this.columnOpticalPowerTest2.map(
                              (header) => rowData[header.field]
                            )
                        ),
                      ],
                    },
                  };
                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['80%', '80%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Power Units: ${PowerUnite}`,
                              style: 'header',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Measurement Mode: ${MeasureUnit}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    table1,
                    pageContentMeasure,
                    table2,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'opticalloss') {
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      widths: ['20%', '15%', '15%', '25%', '25%'], // Equal width for both columns

                      body: [
                        // Header Row
                        this.columnOpticallOSSTest1.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnOpticallOSSTest1.map(
                          (rowData) => {
                            // Check if rowData is defined
                            if (rowData) {
                              return this.columnOpticallOSSTest1.map(
                                (header) => {
                                  // Check if the field exists in rowData
                                  if (header.field in rowData) {
                                    return rowData[header.field];
                                  } else {
                                    return ''; // Handle undefined cells by providing an empty string or appropriate default value
                                  }
                                }
                              );
                            } else {
                              return []; // Handle undefined rowData by providing an empty row
                            }
                          }
                        ),
                      ],
                    },
                  };
                  // Create the table definition for table 1
                  // Create the table definition for table 2
                  const table2 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      body: [
                        // Header Row
                        this.columnOpticallOSSTest2.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnOpticallOSSTest2.map(
                          (rowData) => {
                            // Check if rowData is defined
                            if (rowData) {
                              return this.columnOpticallOSSTest2.map(
                                (header) => {
                                  // Check if the field exists in rowData
                                  if (header.field in rowData) {
                                    return rowData[header.field];
                                  } else {
                                    return ''; // Handle undefined cells by providing an empty string or appropriate default value
                                  }
                                }
                              );
                            } else {
                              return []; // Handle undefined rowData by providing an empty row
                            }
                          }
                        ),
                      ],
                    },
                  };

                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['80%', '80%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Power Units: ${PowerUnite}`,
                              style: 'header',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Measurement Mode: ${MeasureUnit}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];

                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    table1,
                    pageContentMeasure,
                    table2,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'tier1mpo') {
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      // widths: ['20%', '15%','15%', '25%','25%'], // Equal width for both columns

                      body: [
                        // Header Row
                        this.columnTier1MPODefs.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnTier1MPODefs.map((rowData) => {
                          // Check if rowData is defined
                          if (rowData) {
                            return this.columnTier1MPODefs.map((header) => {
                              // Check if the field exists in rowData
                              if (header.field in rowData) {
                                return rowData[header.field];
                              } else {
                                return ''; // Handle undefined cells by providing an empty string or appropriate default value
                              }
                            });
                          } else {
                            return []; // Handle undefined rowData by providing an empty row
                          }
                        }),
                      ],
                    },
                  };
                  const table2 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      // widths: ['20%', '15%','15%', '25%','25%'], // Equal width for both columns

                      body: [
                        // Header Row
                        this.columnTier1MPODefs.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnTier1MPODefs2.map((rowData) => {
                          // Check if rowData is defined
                          if (rowData) {
                            return this.columnTier1MPODefs.map((header) => {
                              // Check if the field exists in rowData
                              if (header.field in rowData) {
                                return rowData[header.field];
                              } else {
                                return ''; // Handle undefined cells by providing an empty string or appropriate default value
                              }
                            });
                          } else {
                            return []; // Handle undefined rowData by providing an empty row
                          }
                        }),
                      ],
                    },
                  };
                  // Create the table definition for table 1
                  // Create the table definition for table 2

                  const WavelengthTab1 =
                    record.tests[0].results.data.optical[0].wavelength;
                  const WavelengthTab2 =
                    record.tests[0].results.data.optical[1].wavelength;

                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['80%', '80%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Wave Length: ${WavelengthTab1}`,
                              style: 'header',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const pageContentMeasure1 = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['80%', '80%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Wave Length: ${WavelengthTab2}`,
                              style: 'header',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];

                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    pageContentMeasure,
                    table1,
                    pageContentMeasure1,
                    table2,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'tier1') {
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      // widths: ['20%', '15%','15%', '25%','25%'], // Equal width for both columns

                      body: [
                        // Header Row
                        this.columnTier1.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnTier1.map((rowData) => {
                          // Check if rowData is defined
                          if (rowData) {
                            return this.columnTier1.map((header) => {
                              // Check if the field exists in rowData
                              if (header.field in rowData) {
                                return rowData[header.field];
                              } else {
                                return ''; // Handle undefined cells by providing an empty string or appropriate default value
                              }
                            });
                          } else {
                            return []; // Handle undefined rowData by providing an empty row
                          }
                        }),
                      ],
                    },
                  };
                  const WavelengthTab1 =
                    record.tests[0].results.data.optical[0].wavelength;

                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['80%', '80%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Wave Length: ${WavelengthTab1}`,
                              style: 'header',
                              fontSize: 10,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    pageContentMeasure,
                    table1,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'truepon') {
                  // Create the table definition for table 1
                  const Gpon_title = 'G-PON';
                  const OLTInformation = 'OLT Information';
                  const OpticalResults_main = 'Optical Results';
                  const ConfigurationGpon = 'Configuration';
                  const XGS_PON = 'XGS-PON';
                  const OLT_id_XGS_PON = this.truePonxgsponPdf?.oltId;
                  const hexArray = OLT_id_XGS_PON.map((dec) =>
                    dec.toString(16).toUpperCase().padStart(2, '0')
                  );
                  const convertXPON_id = hexArray.join(' ');
                  const TOL_XGS_PON = this.truePonxgsponPdf?.tol;
                  const Downstream_XGS_PON =
                    this.truePonxgsponPdf?.powerDownstream;
                  const Power_XGS_PON =
                    this.truePonxgsponPdf?.powerDownstreamSignalStatus;
                  const OLT_id = this.truePonGponPdf?.oltId;
                  const TOL = this.truePonGponPdf?.tol;
                  const Downstream_nm = this.truePonGponPdf?.powerDownstream;
                  const Power =
                    this.truePonGponPdf?.powerDownstreamSignalStatus;
                  const ConfigurationGpon_Testpoint =
                    this.truePonConfigPdf?.ponLocationLabel;
                  const ConfigurationGpon_OLT_Setup =
                    this.truePonConfigPdf?.gpon.odnClassSetup;
                  const ConfigurationGpon_OLT_Format =
                    this.truePonConfigPdf?.gpon.oltIdFormat;
                  const GPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `OLT-ID (hex): ${OLT_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `TOL : ${TOL}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `OLT-ID (hex): ${convertXPON_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `TOL : ${TOL_XGS_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const OpticalResults = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Downstream (nm) : ${Downstream_nm}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: ` Power : ${Power}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const OpticalResults_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Downstream (nm) : ${Downstream_XGS_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: ` Power : ${Power_XGS_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const Configuration_Gpon = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Testpoint : ${ConfigurationGpon_Testpoint}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `ODN Class Setup : ${ConfigurationGpon_OLT_Setup}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `OLT-ID Format : ${ConfigurationGpon_OLT_Format}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const Configuration_Xpon = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Testpoint : ${ConfigurationGpon_Testpoint}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `ODN Class Setup : ${ConfigurationGpon_OLT_Setup}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `OLT-ID Format : ${ConfigurationGpon_OLT_Format}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];

                  const GPON_Title_Main = [
                    {
                      text: `${Gpon_title}`,
                      style: 'header',
                      fontSize: 20,
                      bold: true,
                      margin: [5, 5, 20, 5],
                    },
                    {
                      canvas: [
                        {
                          type: 'line',
                          x1: 0,
                          y1: 0,
                          x2: 200, // Adjust the length as needed
                          y2: 0,
                          lineWidth: 2, // Adjust the line width as needed
                        },
                      ],
                      margin: [5, 0, 5, 0], // Adjust margins to position the line correctly
                    },
                  ];

                  const XPON_Title_Main = [
                    {
                      text: `${XGS_PON}`,
                      style: 'header',
                      fontSize: 20,
                      bold: true,
                      margin: [5, 5, 20, 5],
                    },
                    {
                      canvas: [
                        {
                          type: 'line',
                          x1: 0,
                          y1: 0,
                          x2: 200, // Adjust the length as needed
                          y2: 0,
                          lineWidth: 2, // Adjust the line width as needed
                        },
                      ],
                      margin: [5, 0, 5, 0], // Adjust margins to position the line correctly
                    },
                  ];

                  const OpticalResultsTitle = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OLTInformation}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsTitle_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OLTInformation}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsMain_Title = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OpticalResults_main}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsMain_Title_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OpticalResults_main}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const ConfigurationGpon_Title = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${ConfigurationGpon}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const ConfigurationGpon_Title_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${ConfigurationGpon}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  // Create separate arrays for each row of content
                  const gponContent = [
                    GPON_Title_Main,
                    OpticalResultsTitle,
                    GPON,
                    OpticalResultsMain_Title,
                    OpticalResults,
                    ConfigurationGpon_Title,
                    Configuration_Gpon,
                  ];
                  const xponContent = [
                    XPON_Title_Main,
                    OpticalResultsTitle_XPON,
                    XPON,
                    OpticalResultsMain_Title_XPON,
                    OpticalResults_XPON,
                    ConfigurationGpon_Title_XPON,
                    Configuration_Xpon,
                  ];
                  const GPON_XPON_Content = [
                    {
                      table: {
                        widths: ['60%', '60%'], // Adjust the widths as needed
                        body: [
                          [
                            // Left column for GPON content
                            {
                              stack: gponContent,
                              layout: 'noBorders',
                            },
                            // Right column for XPON content
                            {
                              stack: xponContent,
                              layout: 'noBorders',
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];

                  // Push the combined content for GPON and XPON to pdfPages
                  pdfPages.push(GPON_XPON_Content);

                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'ontdetection') {
                  // Create the table definition for table 1
                  const Gpon_title = 'G-PON';
                  const OLTInformation = 'OLT Information';
                  const OpticalResults_main = 'ONT Information';
                  const ConfigurationGpon = 'Status';
                  const XGS_PON = 'XGS-PON';
                  // XPON data
                  const OLT_id_XPON = this.ontdetectionXponPdf?.oltId || '';
                  const hexArray = OLT_id_XPON?.map((dec) =>
                    dec.toString(16).toUpperCase().padStart(2, '0')
                  );
                  const convertXPON_id = hexArray?.join(' ') || '';
                  const OntId_XGS_PON = this.ontdetectionXponPdf?.ontId || '';
                  const OntSerialNumber_XGS_PON =
                    this.ontdetectionXponPdf?.ontSerialNumber || '';
                  const OntdetectionConfigPdf_XPON =
                    this.ontdetectionXponPdf?.signalStatus || '';
                  const OntStatus_XON =
                    this.ontdetectionXponPdf?.ontStatus || '';
                  // GPON data
                  const OntdetectionConfigPdf_PON =
                    this.ontdetectionGponPdf?.signalStatus || '';
                  const OntStatus_GPON =
                    this.ontdetectionGponPdf?.ontStatus || '';
                  const OLT_id = this.ontdetectionGponPdf?.oltId || '';
                  const OntSerialNumber_id =
                    this.ontdetectionGponPdf?.ontSerialNumber || '';
                  const OntId_id = this.ontdetectionGponPdf?.ontId || '';
                  const GPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `OLT-ID (hex): ${OLT_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `OLT-ID (hex): ${convertXPON_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];

                  const OpticalResults = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `ONT ID : ${OntId_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                          [
                            {
                              text: ` Serial Number : ${OntSerialNumber_id}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const OpticalResults_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `ONT ID  : ${OntId_XGS_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                          [
                            {
                              text: `Serial Number : ${OntSerialNumber_XGS_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const Configuration_Gpon = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Signal : ${OntdetectionConfigPdf_PON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                          [
                            {
                              text: `ONT Status : ${OntStatus_GPON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const Configuration_XPon_ont = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Signal : ${OntdetectionConfigPdf_XPON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                          [
                            {
                              text: `ONT Status : ${OntStatus_XON}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [15, 1, 1, 1],
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  const GPON_Title_Main = [
                    {
                      text: `${Gpon_title}`,
                      style: 'header',
                      fontSize: 20,
                      bold: true,
                      margin: [5, 5, 20, 5],
                    },
                    {
                      canvas: [
                        {
                          type: 'line',
                          x1: 0,
                          y1: 0,
                          x2: 200, // Adjust the length as needed
                          y2: 0,
                          lineWidth: 2, // Adjust the line width as needed
                        },
                      ],
                      margin: [5, 0, 5, 0], // Adjust margins to position the line correctly
                    },
                  ];

                  const XPON_Title_Main = [
                    {
                      text: `${XGS_PON}`,
                      style: 'header',
                      fontSize: 20,
                      bold: true,
                      margin: [5, 5, 20, 5],
                    },
                    {
                      canvas: [
                        {
                          type: 'line',
                          x1: 0,
                          y1: 0,
                          x2: 200, // Adjust the length as needed
                          y2: 0,
                          lineWidth: 2, // Adjust the line width as needed
                        },
                      ],
                      margin: [5, 0, 5, 0], // Adjust margins to position the line correctly
                    },
                  ];
                  const OpticalResultsTitle = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OLTInformation}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsTitle_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OLTInformation}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsMain_Title = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OpticalResults_main}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const OpticalResultsMain_Title_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${OpticalResults_main}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];

                  const ConfigurationGpon_Title = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${ConfigurationGpon}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const ConfigurationGpon_Title_XPON = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `${ConfigurationGpon}`,
                              style: 'header',
                              fontSize: 14,
                              bold: true,
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];

                  // Create separate arrays for each row of content
                  const gponContent = [
                    GPON_Title_Main,
                    OpticalResultsTitle,
                    GPON,
                    OpticalResultsMain_Title,
                    OpticalResults,
                    ConfigurationGpon_Title,
                    Configuration_Gpon,
                  ];

                  const xponContent = [
                    XPON_Title_Main,
                    OpticalResultsTitle_XPON,
                    XPON,
                    OpticalResultsMain_Title_XPON,
                    OpticalResults_XPON,
                    ConfigurationGpon_Title_XPON,
                    Configuration_XPon_ont,
                  ];
                  const GPON_XPON_Content = [
                    {
                      table: {
                        widths: ['60%', '60%'], // Adjust the widths as needed
                        body: [
                          [
                            // Left column for GPON content
                            {
                              stack: gponContent,
                              layout: 'noBorders',
                            },
                            // Right column for XPON content
                            {
                              stack: xponContent,
                              layout: 'noBorders',
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                  ];
                  // Push the combined content for GPON and XPON to pdfPages
                  pdfPages.push(GPON_XPON_Content);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'OTDR') {
                  // Create the table definition for table 1
                  const Location_A =
                    record.tests[0].configuration.otdrSettings.fiber.locationA;
                  const Location_B =
                    record.tests[0].configuration.otdrSettings.fiber.locationB;
                  const Cable_id_OTDR =
                    record.tests[0].configuration.otdrSettings.fiber.cableId;
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      widths: ['50%', '50%'], // Equal width for both columns
                      margin: [5, 5, 5, 5],
                      body: [
                        // Header Row
                        this.columnOTDR_GRID.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 10,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnOTDR.map((rowData) => {
                          // Check if rowData is defined
                          if (rowData) {
                            return this.columnOTDR_GRID.map((header) => {
                              // Check if the field exists in rowData
                              if (header.field in rowData) {
                                return rowData[header.field];
                              } else {
                                return ''; // Handle undefined cells by providing an empty string or appropriate default value
                              }
                            });
                          } else {
                            return []; // Handle undefined rowData by providing an empty row
                          }
                        }),
                      ],
                    },
                  };
                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        widths: ['50%', '50%'], // Equal width for both columns

                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    {
                      table: {
                        headerRows: 1,
                        widths: ['50%', '50%'], // Equal width for both columns

                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Location A: ${Location_A}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Location B : ${Location_B}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Cable Id : ${Cable_id_OTDR}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    table1,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (
                  MeasureType === 'fiberInspection' &&
                  record.tests[0].results.data.endfaces.length === 1
                ) {
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      widths: ['33.33%', '33.33%', '33.33%'],
                      body: [
                        // Header Row
                        this.columnInspectionGrid.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 13,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnFiberInspectionLenght1.map(
                          (rowData) => {
                            // Check if rowData is defined
                            if (rowData) {
                              return this.columnInspectionGrid.map((header) => {
                                // Check if the field exists in rowData
                                if (header.field in rowData) {
                                  return rowData[header.field];
                                } else {
                                  return ''; // Handle undefined cells by providing an empty string or appropriate default value
                                }
                              });
                            } else {
                              return []; // Handle undefined rowData by providing an empty row
                            }
                          }
                        ),
                      ],
                    },
                  };
                  // Create the table definition for table 2
                  const AnalysisProfile =
                    record.tests?.[0]?.configuration.profileName;
                  const OpticalSetting =
                    record.tests?.[0]?.configuration.opticalSettingName;
                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Analysis Profile`,
                              style: 'header',
                              fontSize: 12.5,
                              bold: true,
                            },
                            {
                              text: ` ${AnalysisProfile}`,
                              style: 'header',
                              fontSize: 10,
                              margin: [0, 2, 0, 0],
                            },
                          ],

                          [
                            {
                              text: `Optical Setting`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 12.5,
                              bold: true,
                            },
                            {
                              text: `${OpticalSetting}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [0, 2, 0, 0],
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    pageContentMeasure,
                    table1,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                } else if (MeasureType === 'fiberInspection') {
                  // Create the table definition for table 1
                  // Create the table definition for table 1
                  const table1 = {
                    table: {
                      headerRows: 1, // Treat the first row as the header
                      widths: ['33.33%', '33.33%', '33.33%'],
                      body: [
                        // Header Row
                        this.columnInspectionGrid.map((header) => ({
                          text: header.headerName,
                          bold: true,
                          fontSize: 13,
                        })),
                        // Data Rows
                        ...this.dataSourceColumnFiberInspection.map(
                          (rowData) => {
                            // Check if rowData is defined
                            if (rowData) {
                              return this.columnInspectionGrid.map((header) => {
                                // Check if the field exists in rowData
                                if (header.field in rowData) {
                                  return rowData[header.field];
                                } else {
                                  return ''; // Handle undefined cells by providing an empty string or appropriate default value
                                }
                              });
                            } else {
                              return []; // Handle undefined rowData by providing an empty row
                            }
                          }
                        ),
                      ],
                    },
                  };
                  // Create the table definition for table 2
                  const AnalysisProfile =
                    record.tests?.[0]?.configuration.profileName;
                  const OpticalSetting =
                    record.tests?.[0]?.configuration.opticalSettingName;
                  const pageContentMeasure = [
                    {
                      table: {
                        headerRows: 1,
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Analysis Profile`,
                              style: 'header',
                              fontSize: 12.5,
                              bold: true,
                            },
                            {
                              text: ` ${AnalysisProfile}`,
                              style: 'header',
                              fontSize: 10,
                              margin: [0, 2, 0, 0],
                            },
                          ],

                          [
                            {
                              text: `Optical Setting`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 12.5,
                              bold: true,
                            },
                            {
                              text: `${OpticalSetting}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [0, 2, 0, 0],
                            },
                          ],
                        ],
                      },
                      bold: true,
                      layout: 'noBorders',
                      margin: [5, 5, 20, 5],
                    },
                  ];
                  const pageContent = [
                    {
                      table: {
                        headerRows: 1,
                        // widths: ['50%', '50%'],
                        layout: {
                          hLineStyle: 'none',
                          vLineStyle: 'none',
                        },
                        body: [
                          [
                            {
                              text: `Test Location: ${TestLocation}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Date/Time: ${DateandTime}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Comment: ${Comment}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Technician Details: ${TechnicianDetails}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                          [
                            {
                              text: `Test Type: ${DetailsTesttype}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                            {
                              text: `Status: ${DetailsStatus}`,
                              style: 'header',
                              alignment: 'left',
                              fontSize: 10,
                              margin: [5, 5, 5, 5],
                              bold: true,
                            },
                          ],
                        ],
                      },
                      layout: 'noBorders',
                    },
                    pageContentMeasure,
                    table1,
                  ];
                  pdfPages.push(pageContent);
                  // Add a page break after each selected row except the last one
                  if (i < selectedRowCount - 1) {
                    pdfPages.push({ text: '', pageBreak: 'after' });
                  }
                }
              }
            }
            // Now you can use the jpgDataURL in the documentDefinition
            const documentDefinition: TDocumentDefinitions = {
              content: [
                ...firstPageContent,
                { text: '', pageBreak: 'before' }, // Add a page break before secondPageContent
                ...pdfPages,
              ],
              footer: (currentPage: number, pageCount: number) =>
                createFooter(currentPage, pageCount),
              styles: {
                header: {
                  fontSize: 16,
                  bold: true,
                },
              },
            };
            // Function to format the date in a desired format (e.g., 'YYYY-MM-DD')
            function formatDate(date: any) {
              const options = {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
              };
              return date.toLocaleDateString(undefined, options);
            }
            // Function to format the time in a desired format (e.g., 'HH:mm:ss')
            function formatTime(date: any) {
              const options = {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              };
              return date.toLocaleTimeString(undefined, options);
            }
            //----------------------------------------------------------------------------------
            // Define the footer function with dynamic content
            const createFooter = (
              currentPage: number,
              pageCount: number
            ): any => {
              // Your dynamic footer content logic here
              const technicianTitle =
                this.MappingPdfReportInfo.technician || '';
              const technicianEmail = this.MappingPdfReportInfo.email || '';
              const technicianPhone = this.MappingPdfReportInfo.phone || '';
              return {
                columns: [
                  {
                    table: {
                      widths: ['33%', '33%', '33%'], // Equal width for all columns
                      body: [
                        [
                          {
                            text: `Technician: ${technicianTitle}`,
                            style: 'header',
                            alignment: 'left',
                            fontSize: 10,
                            margin: [20, 0, 0, 0],
                            bold: true,
                          },
                          {
                            text: `Page ${currentPage} of ${pageCount}`,
                            alignment: 'center',
                            fontSize: 10,
                          },
                          {
                            text: [
                              '',
                              ` Email: ${technicianEmail}`,
                              { text: ` Phone: ${technicianPhone}` },
                            ],
                            alignment: 'right',
                            fontSize: 10,
                            margin: [0, 0, 20, 0],
                            bold: true,
                          },
                        ],
                      ],
                      layout: 'noBorders', // Remove all cell borders
                    },
                    layout: 'lightHorizontalLines', // Apply lines within the table
                  },
                ],
                styles: {
                  header: {
                    fontSize: 14,
                    bold: true,
                    alignment: 'center',
                    margin: [0, 20, 0, 10],
                  },
                },
              };
            };
            const pdfDocGenerator = pdfMake.createPdf(documentDefinition);
            pdfDocGenerator.getBlob((pdfBlob: Blob) => {
              saveAs(pdfBlob, this.inputValue);
            });
          }
        };
        // Set the SVG content as the image source
        image.src =
          'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgContent);
      });
  }
}
