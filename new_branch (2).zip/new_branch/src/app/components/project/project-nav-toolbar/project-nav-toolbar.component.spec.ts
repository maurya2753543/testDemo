import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectNavToolbarComponent } from './project-nav-toolbar.component';

describe('ProjectNavToolbarComponent', () => {
  let component: ProjectNavToolbarComponent;
  let fixture: ComponentFixture<ProjectNavToolbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectNavToolbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectNavToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
