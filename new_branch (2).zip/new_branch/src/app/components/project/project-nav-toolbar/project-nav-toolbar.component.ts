import { Component, EventEmitter, Output , OnInit } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';
import { PopupInputComponent } from '../../popup-input/popup-input.component';
import {
    faPlus,
    faFileImport,
    faEllipsis,
    faFloppyDisk,
    faFloppyDiskPen,
    faEdit,
    faFileExport,
    faClose
  } from '@fortawesome/pro-solid-svg-icons'
  import { DarkModeService } from 'src/app/services/darkMode.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';



@Component({
  selector: 'app-project-nav-toolbar',
  templateUrl: './project-nav-toolbar.component.html',
  styleUrls: ['./project-nav-toolbar.component.scss']
})
export class ProjectNavToolbarComponent implements OnInit {
  // @Output() messageEvent = new EventEmitter<string>();
    faPlus = faPlus
    faFileImport = faFileImport
    faEllipsis = faEllipsis
    faFloppyDisk = faFloppyDisk
    faFloppyDiskPen = faFloppyDiskPen
    faEdit = faEdit;
    faFileExport = faFileExport
    faClose = faClose;
    // Dark themes
    DarkThemesApply :any

    constructor(private dialog: MatDialog,  private projectsService: ProjectsService, public darkModeService: DarkModeService) {

    }

    ngOnInit(): void {
      this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
    }

    // sendMessage() {
    //   // const message = 'Hello from child!';
    //   this.messageEvent.emit();
    // }


    // newProject() {
    //     this.projectsService.newProject("rename me");
    // }

    // importProject(event:  Event) {
    //   console.log('event', event);
    // }

    exportProject() {
        this.projectsService.exportProject(false);

        // const dialogRef = this.dialog.open(PopupInputComponent, {
        //   width: '400px', // Set the desired width for the dialog
        //   data: { title: ' Please enter project export File Name'},
        // //   panelClass: 'custom-modalbox',
        // });

        // dialogRef.afterClosed().subscribe(result => {
        //   console.log('Dialog closed with result:', result);
        //   // Perform any necessary actions after the dialog is closed
        // });

    }

    // renameProject() {
    //     // this.projectsService.renameTreeNode();
    // }

    archiveProject() {
        this.projectsService.exportProject(true);
    }


}
