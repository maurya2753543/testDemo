import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectNavPanelComponent } from './project-nav-panel.component';

describe('ProjectNavPanelComponent', () => {
  let component: ProjectNavPanelComponent;
  let fixture: ComponentFixture<ProjectNavPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectNavPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectNavPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
