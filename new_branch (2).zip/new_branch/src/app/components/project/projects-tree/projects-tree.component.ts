import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { ProjectsService } from 'src/app/services/projects.service';
import { SharedService } from 'src/app/services/shared.service';
import { ItemNode } from 'src/app/models/item-node';
/** Flat to-do item node with expandable and level information */
class ItemFlatNode {
  name: string = '';
  level: number = 0;
  expandable: boolean = true;
  children: any;
  id: string = '';
  rev: string = '';
  parent: string = '';
  projectId: string = '';
  haschild: boolean = false;
  numResults: number = 0;
}

@Component({
  selector: 'app-projects-tree',
  templateUrl: './projects-tree.component.html',
  styleUrls: ['./projects-tree.component.scss']
})
export class ProjectsTreeComponent implements OnInit {
  @Output() destinationId = new EventEmitter<any>();

  /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<ItemFlatNode, ItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<ItemNode, ItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: ItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<ItemFlatNode>;

  treeFlattener: MatTreeFlattener<ItemNode, ItemFlatNode>;

  dataSource: MatTreeFlatDataSource<ItemNode, ItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<ItemFlatNode>(true /* multiple */);

  getLevel = (node: ItemFlatNode) => node.level;

  isExpandable = (node: ItemFlatNode) => node.expandable;

  getChildren = (node: ItemNode): ItemNode[] => node.children;

  hasChild = (_: number, _nodeData: ItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: ItemFlatNode) => _nodeData.name === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: ItemNode, level: number) => {

    const existingNode = this.nestedNodeMap.get(node);
    const flatNode =
      existingNode && existingNode.name === node.name ? existingNode : new ItemFlatNode();
    flatNode.name = node.name;
    flatNode.id = node.id;
    flatNode.level = level;
    flatNode.expandable = true;
    flatNode.children = node.children;
    flatNode.rev = node.rev;
    flatNode.parent = node.parent;
    flatNode.projectId = node.projectId;
    flatNode.numResults = node.numResults
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    flatNode.haschild = (node.numResults > 0)              //!!node.children?.length;
    return flatNode;
  };

  //----------------------------------------------------------------------------------
  activeNode: any;
  @Input() nodeChildren: any
  @Input() dialogOpen: boolean = false;
  @Input() selectedIds: any;

  constructor(private projectsService: ProjectsService, private SharedService: SharedService) {
    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this.getLevel,
      this.isExpandable,
      this.getChildren,
    );
    this.treeControl = new FlatTreeControl<ItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    if (!this.dialogOpen) {
      this.SharedService.breadCrumbsChildListSubject$.subscribe((value: any) => {
        this.dataSource.data = value;
      });
    } else {

      this.projectsService.getAppProjects().then((resp: any) => {
        this.dataSource.data = resp;
      });
    }
  }

  //----------------------------------------------------------------------------------
  activeNodeClicked(node: any, nodeClicked?: boolean) {
    nodeClicked = nodeClicked !== undefined ? nodeClicked : true
    this.activeNode = node;
  }

  //----------------------------------------------------------------------------------
  updateBreadCrumbs(node: any) {
    if (!this.dialogOpen) {
      this.SharedService.setIdValue(node.id, false);
      this.projectsService.setActiveNode(node);
    } else {
      const payload = [this.selectedIds, node.id];
      this.destinationId.emit(node.id)
      this.projectsService.moveResults(node.id,this.selectedIds);
    }
  }

}
