import { ComponentFixture, TestBed } from '@angular/core/testing';

import { moveFilesDialogComponent } from './move-files-dialog.component';

describe('moveFilesDialogComponent', () => {
  let component: moveFilesDialogComponent;
  let fixture: ComponentFixture<moveFilesDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ moveFilesDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(moveFilesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
