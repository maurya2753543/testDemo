import { Component, Inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-move-files-dialog',
  templateUrl: './move-files-dialog.component.html',
  styleUrls: ['./move-files-dialog.component.scss']
})

export class moveFilesDialogComponent {
  dataSource: any;
  selectedIds: any;
  DarkThemesApply: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
    this.DarkThemesApply = data.DarkThemesApply
    this.selectedIds = this.data.data.map((obj: { id: any; }) => obj.id);

  }

  // handleDestinationIdChange(id: string) {
  //   this.ProjectsService.moveResults(id,this.selectedIds)
  // }

}
