import { Component, OnInit, Input } from '@angular/core';
import {
  faPlus,
  faEdit,
  faTrash
} from '@fortawesome/pro-solid-svg-icons';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';

@Component({
  selector: 'app-profile-manager',
  templateUrl: './profile-manager.component.html',
  styleUrls: ['./profile-manager.component.scss']
})

export class ProfileManagerComponent implements OnInit {
  faPlus = faPlus;
  faEdit = faEdit;
  faTrash = faTrash;
  isFormOpen: boolean = false;
  projectProfileListData: any;
  editIndex: number = -1;
  nameValue: string = '';
  @Input() DarkThemesApply: any;
  ProfileManagerIDForm: FormGroup;
  profileArray!: FormArray; // FormArray to hold profiles
  levels: number[] = []; // Array from 1 to 9
  levelFormControls: FormControl[] = []; // This array holds the FormControl instan
  originalSelectedItem: any;

  //----------------------------------------------------------------------------------
  constructor(public darkModeService: DarkModeService, private formBuilder: FormBuilder, private GlobalServicesetting: GlobalSettingsService) {
    this.profileArray = this.formBuilder.array([
      this.formBuilder.group({
        nameValue: ['', [Validators.required, Validators.maxLength(25)]],
        level0Value: ['', [Validators.maxLength(25)]],

      })
    ]);

    for (let i = 1; i <= 9; i++) {
      const levelControl = new FormControl('', [Validators.maxLength(25)]);
      (this.profileArray.at(0) as FormGroup).addControl('level' + i + 'Value', levelControl);
    }

    this.ProfileManagerIDForm = this.formBuilder.group({
      profileArray: this.profileArray, // Add the FormArray to the main FormGroup
    });

  }

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.projectProfileListData = this.GlobalServicesetting.projectProfileListData;
  }
  //----------------------------------------------------------------------------------

  // Function to delete all levels
  cancelLevel() {
    this.levelFormControls = [];
    this.isFormOpen=false;

    if (this.editIndex === -1) {
      // Update the edited item's data
      this.levels = [];
      this.ProfileManagerIDForm.reset();
      this.originalSelectedItem.levels = [];
      this.originalSelectedItem.name = [];
      this.isFormOpen=false;
    }

    //-----------------------------------------------------------------------
    this.ProfileManagerIDForm.patchValue({
      profileArray: [
        {
          nameValue: this.originalSelectedItem.name,
          level0Value: this.originalSelectedItem.levels[0],
          level1Value: this.originalSelectedItem.levels[1],
          level2Value: this.originalSelectedItem.levels[2],
          level3Value: this.originalSelectedItem.levels[3],
          level4Value: this.originalSelectedItem.levels[4],
          level5Value: this.originalSelectedItem.levels[5],
          level6Value: this.originalSelectedItem.levels[6],
          level7Value: this.originalSelectedItem.levels[7],
          level8Value: this.originalSelectedItem.levels[8],
          level9Value: this.originalSelectedItem.levels[9],
        },
      ],
    });
  }

  //----------------------------------------------------------------------------------
  addNewProjectProfile() {
    this.isFormOpen = true;
    this.levelFormControls = [];
    this.levels = [];
    this.ProfileManagerIDForm.reset();
  }

  //----------------------------------------------------------------------------------

  addLevel() {
    if (this.levels.length < 9) {
      this.levels.push(this.levels.length); // Store the index as the level
      this.levelFormControls.push(new FormControl(''));
    }
  }

  //----------------------------------------------------------------------------------

  editItem(index: number) {
    //  this.addLevel();
    this.isFormOpen = true;
    this.editIndex = index;
    const selectedItem = this.projectProfileListData[index];
    if (selectedItem) {
      this.addLevel();

    }

    // Store a copy of the original item
    this.originalSelectedItem = { ...selectedItem };

    this.ProfileManagerIDForm.patchValue({
      profileArray: [
        {
          nameValue: selectedItem.name,
          level0Value: selectedItem.levels[0],
          level1Value: selectedItem.levels[1],
          level2Value: selectedItem.levels[2],
          level3Value: selectedItem.levels[3],
          level4Value: selectedItem.levels[4],
          level5Value: selectedItem.levels[5],
          level6Value: selectedItem.levels[6],
          level7Value: selectedItem.levels[7],
          level8Value: selectedItem.levels[8],
          level9Value: selectedItem.levels[9],
        },
      ],
    });
  }


  //----------------------------------------------------------------------------------
  deleteItem(index: number) {
    this.projectProfileListData.splice(index, 1);
    this.ProfileManagerIDForm.reset();
  }

  //----------------------------------------------------------------------------------
  // Checking for duplicate profile names
  isDuplicateName(name: string) {
    if (this.editIndex !== -1) {
      for (let i = 0; i < this.projectProfileListData.length; i++) {
        if (i !== this.editIndex && this.projectProfileListData[i].name === name) {
          return false;
        }
      }
    } else {
      for (let i = 0; i < this.projectProfileListData.length; i++) {
        if (this.projectProfileListData[i].name === name) {
          return false;
        }
      }
    }
    return true;
  }


  //----------------------------------------------------------------------------------
  clearLevelInputValue(level: string) {
    this.ProfileManagerIDForm.get(level)?.setValue('');;
  }

  //----------------------------------------------------------------------------------
  clearLevelInputValueLevel(controlName: string) {
    const control = this.profileArray.at(0).get(controlName) as FormControl;
    if (control) {
      control.setValue('');
    }
  }

  //----------------------------------------------------------------------------------
  ProfilesubmitForm() {
    if (this.ProfileManagerIDForm.invalid) {
      return;
    }
    const nameFormControl = this.ProfileManagerIDForm.get('profileArray.0.nameValue');
    if (nameFormControl?.value) {
      const nameValue = nameFormControl.value;
      const duplicateProfile = this.isDuplicateName(nameValue);
      if (!duplicateProfile) {
        nameFormControl.setErrors({
          duplicate: true,
          message: `The profile "${duplicateProfile}" already exists.`,
        });
        return;
      } else {
        nameFormControl.setErrors(null); // Clear any existing errors

        const formValue = this.ProfileManagerIDForm.value.profileArray;
        const newEntry = {
          name: formValue[0].nameValue,
          levels: [
            formValue[0].level0Value,
            formValue[0].level1Value,
            formValue[0].level2Value,
            formValue[0].level3Value,
            formValue[0].level4Value,
            formValue[0].level5Value,
            formValue[0].level6Value,
            formValue[0].level7Value,
            formValue[0].level8Value,
            formValue[0].level9Value
          ]
        };
        if (this.editIndex !== -1) {
          /** Update the edited item's data */
          this.projectProfileListData[this.editIndex] = newEntry;
          this.editIndex = -1; // Reset editIndex after updating
        } else {
          /** Add new entry to the list */
          this.projectProfileListData.push(newEntry);
        }
        this.GlobalServicesetting.updateAppSettings({ projectProfiles: this.projectProfileListData });
        this.isFormOpen = false;
        this.cancelLevel();

      }
    }
  }
}
