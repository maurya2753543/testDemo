import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingsProjectComponent } from './settings-project.component';

describe('SettingsProjectComponent', () => {
  let component: SettingsProjectComponent;
  let fixture: ComponentFixture<SettingsProjectComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SettingsProjectComponent]
    });
    fixture = TestBed.createComponent(SettingsProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
