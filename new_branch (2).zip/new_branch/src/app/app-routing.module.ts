import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './components/landing/landing.component'
import { MarkdownComponent } from './components/markdown/markdown.component'

const routes: Routes = [
    { path: '', component: LandingComponent },
    { path: 'docs', component: MarkdownComponent }, // ?doc=help, ?doc=guide
    { path: '**', redirectTo: '/' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
