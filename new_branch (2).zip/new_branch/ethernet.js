import os from 'os'

console.log ( "Ethernet Test" );
const interfaces = os.networkInterfaces();
console.log ( interfaces );