exports.config = {
    framework: 'jasmine2',
    //seleniumAddress: 'http://localhost:4444/wd/hub',

  /* suites: {
      smoke: ['./e2e/tests/regression/loginScreen/loginPage.spec.js',
      './e2e/tests/regression/commonMethods/headerverification.js'],
      headerVerificaion: './e2e/tests/regression/commonMethods/headerverification.js'        
    },*/
    
    //specs: ['./e2e/tests/regression/loginScreen/g.spec.js'],
    //specs: ['./e2e/tests/regression/loginScreen/loginPage.spec.js'],
    specs: ['./e2e/tests/regression/enterpriseSearch/enterpriseSearchPage.spec.js'],

    //specs: ['./e2e/tests/regression/enterprisePerformance/regionalChartPage.spec.js'],
    //specs: ['./e2e/tests/regression/enterprisePerformance/systemChartPage.spec.js'],
   // D:\xpertrakautomation\e2e\tests\regression\enterprisePerformance\regionalChartPage.spec.js
    directConnect: true,

        capabilities: {
          'browserName': 'chrome'
          //'browserName': 'firefox'
          /*chromeOptions: {
            args: [ "--headless", "--disable-gpu", "--window-size=800,600" ]
          }*/
          /*'chromeOptions': {
            'args': ['show-fps-counter=true']
          }*/
        },
  
      plugins: [{
        package: 'protractor-screenshoter-plugin',
        screenshotPath: './REPORTS/e2e',
        screenshotOnExpect: 'failure+success',
        screenshotOnSpec: 'none',
        withLogs: true,
        writeReportFreq: 'asap',
        imageToAscii: 'none',
        clearFoldersBeforeTest: true
      }],
 
      onPrepare: function() {
          // returning the promise makes protractor wait for the reporter config before executing tests
          return global.browser.getProcessedConfig().then(function(config) {
              //it is ok to be empty
          });
      
        },

  }