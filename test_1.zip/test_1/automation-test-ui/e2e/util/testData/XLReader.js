var XLSX = require("xlsx");

class xlReader
{

    read_from_excel(sheetName,filepath)
    {
        var workbook = XLSX.readFile(filepath);
        var worksheet = workbook.Sheets[sheetName];
        return XLSX.utils.sheet_to_json(worksheet);
    }
}
module.exports = new xlReader();