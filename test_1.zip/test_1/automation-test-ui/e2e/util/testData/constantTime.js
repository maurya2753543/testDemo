const { browser } = require("protractor");
function constantTime()
{    
    this.wait = function(time)
    {
        browser.sleep(time);
    };
}

module.exports = new constantTime();