const { element, browser } = require("protractor");

function EnterpriseSystemChartObject()
{
    
var eleSystemMonthlyButton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/button[2]'));
var eleSystemDailyButton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/button[1]'));
var eleSystemMacTrakbutton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/select[1]'));
var eleSystemMacTrackbuttonOptions = element.all(by.tagName('option'));
var eleSystemHighchartItem = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]"));
var eleSystemHighchartforIndyItem = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect'][1]"));
//var eleSystemHighchartforSpy = element(by.xpath("//as-split[1]/as-split-area[1]/app-region-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]"));
var eleSystemHighchartsAllforIndy = element.all(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect']"));
var eleSystemHighchartsAllforSpy = element.all(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']"));

var eleSystemIndyCheckbox = element(by.xpath('//*[@id="Indy"]'));
var eleSystemShowAllCheckbox = element(by.xpath('//*[@id="selallsys"]'));
var eleSystemSpyCheckbox = element(by.xpath('//*[@id="Spy"]'));
var eleSystemHighChartdestination = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]"));
//var eleResetZoombutton = element(by.xpath("//*[local-name() = 'g' and @class = 'highcharts-button highcharts-reset-zoom          highcharts-button-normal']"));
var eleSystemMenuButton = element(by.xpath("//as-split-area[@id='spltr2']//a[1]//i[1]"));
var eleSystemResetZoombutton = element(by.xpath("//div[@id='highcharts-4ej8d1p-2']//*[local-name()='svg']//*[name()='g'][7]/*[name()='rect'][1]"));

    var toolTipCount;
    var TotalRegionChartsResults;
    var TotalSystemChartsResults;
    var mouseEle3;

this.sysMonthlyButtonValidation = function()
{
   // monthlyButton.click();
   expect(eleSystemMonthlyButton.isEnabled()).toBe(false);   
}

 this.sysVerifyIndySystemHighChartItemdata = function(buttonValue,mactrakdropdownvalue)
 {    
        // To get the rect values related to graphs count for dialy
        //element.all(by.xpath("//split-area[1]/regionchart[1]/div[1]/div[2]/div[1]/div[2]/chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']")).count().then(function(size)
        eleSystemHighchartsAllforIndy.count().then(function(size)
        {
            var TotalSystemIndyChartsResults = size;
            console.log("IndyChartsCount:" +TotalSystemIndyChartsResults);  
            
            for(var i = 1; i<=TotalSystemIndyChartsResults; i++)
                {
                    browser.sleep(10000);     
                var mouseEle = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect']["+i+"]"));
                                                 //as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect'][9]
                
                browser.actions().mouseMove(mouseEle).perform();
                mouseEle.click().then(function()
                    {
                    browser.sleep(10000);  
                    element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                       {
                        toolTipCount = size;
                        console.log("tooltipcountforIndy" +toolTipCount);
                       })
               
                        element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                           {                        
                           for(var Counter = 1; Counter<=toolTipCount; Counter++)
                               {
                                   item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                       {
                                          // console.log("TooltipText="+ value);
                                          switch(value){
                                            case "MACTrak™":
                                                if(mactrakdropdownvalue== 'mactrak'|| mactrakdropdownvalue== 'both') 
                                               { expect(value).toMatch("MACTrak™");}
                                                break;
                                             case "Spectral":
                                                if(mactrakdropdownvalue== 'spectral'|| mactrakdropdownvalue== 'both')  
                                               { expect(value).toMatch("Spectral");}
                                                 break;        
            
                                            case "Indy":
                                                expect(value).toMatch("Indy");
                                                break;                              
            
                                            case "Balto":
                                                expect(value).toMatch("Spy");
                                                break;                               
            
                                            case "Percent Failed:":
                                                expect(value).toMatch("Percent Failed:");
                                                break;                               
            
                                            case "Performance Severity:":
                                                expect(value).toMatch("Performance Severity:");
                                                break;                               
                                                
                                            case "Date:":
                                                expect(value).toMatch("Date:");
                                                break;     
                                        }
                                       })
                                }        
                            })                    
                    })
                }
                if(buttonValue == "monthly" && mactrakdropdownvalue == "spectral")
                {
                expect(TotalSystemIndyChartsResults).toBe(4);
                }
               else if(buttonValue == "monthly" && mactrakdropdownvalue== "mactrak") 
                {
                expect(TotalSystemIndyChartsResults).toBe(4);
                }
                else if(buttonValue == "monthly" && mactrakdropdownvalue== "both")
                {
                expect(TotalSystemIndyChartsResults).toBe(8);
                }
                if(buttonValue == "daily" && mactrakdropdownvalue == "spectral")
                {
                expect(TotalSystemIndyChartsResults).toBe(7);
                }
               else if(buttonValue == "daily" && mactrakdropdownvalue== "mactrak") 
                {
                expect(TotalSystemIndyChartsResults).toBe(7);
                }
                else if(buttonValue == "daily" && mactrakdropdownvalue== "both")
                {
                expect(TotalSystemIndyChartsResults).toBe(14);
                }
            })        
    }
    this.sysVerifySpySystemHighChartItemdata = function(buttonValue,mactrakdropdownvalue)
    {    
        browser.sleep(10000);  

           // To get the rect values related to graphs count for dialy
           //element.all(by.xpath("//split-area[1]/regionchart[1]/div[1]/div[2]/div[1]/div[2]/chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']")).count().then(function(size)
           eleSystemHighchartsAllforSpy.count().then(function(size)
           {
               var TotalSystemSpyChartsResults = size;
               console.log("SpyChartsCount:" +TotalSystemSpyChartsResults);  
               
               for(var i = 1; i<=TotalSystemSpyChartsResults; i++)
                   {
                    var mouseEle = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']["+i+"]"));
                    browser.actions().mouseMove(mouseEle).perform();
                    mouseEle.click().then(function()
                       {
                       browser.sleep(10000);  
                       element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                          {
                           toolTipCount = size;
                           console.log("tooltipcountforSpy:" + toolTipCount);
                          }) 
                  
                            element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                              {                        
                              for(var Counter = 1; Counter<=toolTipCount; Counter++)
                                  {
                                      item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                          {
                                             // console.log("TooltipText="+ value);
                                             switch(value){
                                               case "MACTrak™":
                                                   if(mactrakdropdownvalue== 'mactrak'|| mactrakdropdownvalue== 'both') 
                                                  { expect(value).toMatch("MACTrak™");}
                                                   break;
                                                case "Spectral":
                                                   if(mactrakdropdownvalue== 'spectral'|| mactrakdropdownvalue== 'both')  
                                                  { expect(value).toMatch("Spectral");}
                                                    break;        
               
                                               case "Indy":
                                                   expect(value).toMatch("Indy");
                                                   break;                              
               
                                               case "Spy":
                                                   expect(value).toMatch("Spy");
                                                   break;                               
               
                                               case "Percent Failed:":
                                                   expect(value).toMatch("Percent Failed:");
                                                   break;                               
               
                                               case "Performance Severity:":
                                                   expect(value).toMatch("Performance Severity:");
                                                   break;                               
                                                   
                                               case "Date:":
                                                   expect(value).toMatch("Date:");
                                                   break;     
                                           }
   
                                          })
                                   }        
                               })                    
                       })
                   }
                   if(buttonValue == "monthly" && mactrakdropdownvalue == "spectral")
                   {
                   expect(TotalSystemSpyChartsResults).toBe(3);
                   }
                  else if(buttonValue == "monthly" && mactrakdropdownvalue== "mactrak") 
                   {
                   expect(TotalSystemSpyChartsResults).toBe(3);
                   }
                   else if(buttonValue == "monthly" && mactrakdropdownvalue== "both")
                   {
                   expect(TotalSystemSpyChartsResults).toBe(6);
                   }
                   if(buttonValue == "daily" && mactrakdropdownvalue == "spectral")
                   {
                   expect(TotalSystemSpyChartsResults).toBe(6);
                   }
                  else if(buttonValue == "daily" && mactrakdropdownvalue== "mactrak") 
                   {
                   expect(TotalSystemSpyChartsResults).toBe(6);
                   }
                   else if(buttonValue == "daily" && mactrakdropdownvalue== "both")
                   {
                   expect(TotalSystemSpyChartsResults).toBe(12);
                   }
               })        
       }

this.verifySysMactrakDropdown = function(name)
 {  
     var name;
    eleSystemMacTrakbutton.click();
    eleSystemMacTrackbuttonOptions.each(function(item)
    {
        item.getAttribute("value").then(function(values)
        {
            if(values == name)
            {
                item.click();
                browser.sleep(5000);  
                return true;            
            }                      
            //mactrak , spectral,  both
        })
     })
     expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
 }
 

 this.clickSystemDailyButton = function()
{
    eleSystemDailyButton.click(); 
  // eleregionHighchart.isPresent().toBe(true);   
}

this.uncheckSystemIndy = function()
    {
        //Uncheck one of the regions from the Regions panel
        eleSystemIndyCheckbox.click().then(function()
            {
                expect(eleSystemSpyCheckbox.isSelected()).toBe(true);
                expect(eleSystemShowAllCheckbox.isSelected()).toBe(true);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
this.verifygraphdataDisplayedforIndy = function()
    {    
        browser.actions().mouseMove(eleSystemHighchartsAllforIndy).perform();
        eleSystemHighchartsAllforIndy.click().then(function()
            {
            browser.sleep(10000);
            element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                {
                toolTipCount = size;
                //console.log(toolTipCount);
                })

                element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                {                        
                    for(var Counter = 1; Counter<=toolTipCount; Counter++)
                        {
                            item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                {
                                    if(value=="Indy")
                                    {
                                        expect(value).toMatch("Indy");
                                        console.log(value);                                    
                                    }
                                })
                        }
                })
            })    
    }
    this.uncheckSystemSpy = function()
    {
        //Uncheck one of the regions from the Regions panel
        eleSystemIndyCheckbox.click().then(function()
            {
                expect(eleSystemIndyCheckbox.isSelected()).toBe(true);
                expect(eleSystemShowAllCheckbox.isSelected()).toBe(true);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
    this.verifygraphdataDisplayedforSpy = function()
    {    
        browser.actions().mouseMove(eleSystemHighchartsAllforSpy).perform();
        eleSystemHighchartsAllforSpy.click().then(function()
            {
            browser.sleep(10000);
            element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                {
                toolTipCount = size;
                //console.log(toolTipCount);
                })
                element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                {                        
                    for(var Counter = 1; Counter<=toolTipCount; Counter++)
                        {
                            item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                {
                                    if(value=="Spy")
                                    {
                                        expect(value).toMatch("Spy");
                                        console.log(value);                                    
                                    }
                                })
                        }
                })
            })    
    }
this.uncheckandCheckSystemShowAll = function()
    {
        eleSystemShowAllCheckbox.click().then(function()
            {
                expect(eleSystemIndyCheckbox.isSelected()).toBe(false);
                expect(eleSystemSpyCheckbox.isSelected()).toBe(false);
                expect(eleSystemHighchartItem.isPresent()).toBe(false);
            })
        eleSystemShowAllCheckbox.click().then(function()
            {
                expect(eleSystemIndyCheckbox.isSelected()).toBe(true);
                expect(eleSystemSpyCheckbox.isSelected()).toBe(true);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
this.unCheckSystemIndySpy = function()
    {
        eleSystemIndyCheckbox.click();
        eleSystemSpyCheckbox.click();
        expect(eleSystemShowAllCheckbox.isSelected()).toBe(false);
        expect(eleSystemHighchartItem.isPresent()).toBe(false);
    }

this.verifyclickSystemMenuButton = function()
    {
        eleSystemMenuButton.click().then(function()
            {
                //expect(element(by.xpath('//*[@id="snddiv"]/div/div[1]')).isDisplayed()).toBe(false);
                expect(eleSystemShowAllCheckbox.isDisplayed()).toBe(false);
                browser.sleep(5000);
            })
        //Click again on menu button
        eleSystemMenuButton.click().then(function()
            {
                //expect(element(by.xpath('//*[@id="snddiv"]/div/div[1]')).isDisplayed()).toBe(true);
                expect(eleSystemShowAllCheckbox.isDisplayed()).toBe(true);
            })    
    }    

this.verifyRegionZoomButton = function()
    {        
        eleSystemHighchartforIndyItem.click();
        browser.executeScript("document.body.style.zoom='90%';");
        browser.driver.actions().dragAndDrop(eleSystemHighchartforIndyItem,eleSystemHighChartdestination).perform().then(function()
            {
                browser.sleep(3000);
                //executeScript('document.getElementsByName')
                expect(eleSystemResetZoombutton.isPresent()).toBe(true);
                eleSystemResetZoombutton.click();
                browser.sleep(3000);
            })
        
    };
}
module.exports = new EnterpriseSystemChartObject();