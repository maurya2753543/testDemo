var loginPage = require('../../../pages/loginPO/loginScreen.po');
var sync = require('../../../util/testData/constantTime');
var common = require('../commonMethods/startUpSyncMethod.spec');
var XL = require('../../../util/testData/XLReader');

describe('Xpertrak Application Login Page:', function()
{        
    common.startUp();
    it('Login in to application with proper usename and credentials',function()
        { 
           // loginPage.get("https://www.google.com/");
            //sync.wait(50000); 
            var TEST_DATA = XL.read_from_excel('LoginTestData','./e2e/util/testData/XperTrakTestData.xlsx')
             TEST_DATA.forEach(function(data)
             {
            loginPage.get(data.URL);
            sync.wait(5000);            
            loginPage.enterUserName(data.UserName);
            loginPage.enterpassWord(data.Password);
            loginPage.clickSignin();
            sync.wait(15000);
           // loginPage.verifyResult();
            })
       })
    // it('Dashboard',function()
    // { 
    //     element(by.id("dropdownMenu2")).click();
    //     sync.wait(5000);
    //     var ele1 = element(by.css("div[aria-labelledby='dropdownMenu2']"));
    //     var ele2 = element(by.css("button[class='dropdown-item':nth-child(1)]"));

    // browser.actions().mouseDown(ele1).perform();
    // ele2.click()
    //   sync.wait(5000);
      
    //})

        //element(by.css("button.menu-button.menu-toggle")).click();
    // element(by.css("a[title='Enterprise']")).click();
    // sync.wait(5000);

    //   var ele1 = element(by.css("div[class='dropdown-menu dropdown-menu-right',]"));
    //   var ele2 = element(by.css("button[class='dropdown-item']"));

    // browser.actions().mouseDown(ele1).mouseMove(ele2).click().perform();
    //   sync.wait(5000);
       
    //   //which returns an array with the tabs and the 
    // browser.getAllWindowHandles().then(function(handles){
    // browser.switchTo().window(handles[1]);
    //   element(by.id("menu-toggle")).click();
    //   //element(by.css("button[title='Change Theme']")).click();
    //   sync.wait(5000);
    //   }); 
    // })
})

