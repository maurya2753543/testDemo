var loginPage = require('../../../pages/loginPO/loginScreen.po');
//var EnterpriseRegionalChartObject = require('../../../pages/enterprisePerformancePO/regionalChartPage.po.js');
var EnterpriseSystemChartObject = require('../../../pages/enterprisePerformancePO/systemsChartPage.po');
var common = require('../commonMethods/startUpSyncMethod.spec');
//var enterprisesearch = require('../../../pages/enterpriseSearchPO/enterpriseSearch.po');
var sync = require('../../../util/testData/constantTime');
const { browser } = require('protractor');

describe('Xpertrak EnterpriseSearch & Performance Application ', function()
{  
       common.startUp();
       it('Login in to application with proper usename and credentials',function()
       {             
           loginPage.get("http://173.165.99.66/pathtrak/login/view.html#/login");
           sync.wait(5000);            
           loginPage.enterUserName("admin");
           loginPage.enterpassWord("admin");
           loginPage.clickSignin();
           sync.wait(15000);
           loginPage.get("http://173.165.99.66/pathtrak/enterprise/index.html#/performance");
           sync.wait(5000);         
       })

      it('Verify the system performance page monthly',function()
       {  
        EnterpriseSystemChartObject.sysMonthlyButtonValidation();
       })

       it('Verify the system Graph data Monthly',function()
       {  
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("monthly","mactrak");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("monthly","mactrak");
       })

      it('Verify the system page for Monthly Spectral',function()
       {  
        EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");
       })
       
       //need to run
      it('Verify the System Graph data Monthly Spectral',function()
       {  
       // EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("monthly","spectral");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("monthly","spectral");
       })

      it('Verify the System page for Monthly both',function()
       {  
        EnterpriseSystemChartObject.verifySysMactrakDropdown("both");
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("monthly","both");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("monthly","both");        
       })
 
      it('Verify the System graph for Daily MacTrak',function()
       {  
        EnterpriseSystemChartObject.clickSystemDailyButton();
        EnterpriseSystemChartObject.verifySysMactrakDropdown("mactrak");        
       })
      
      it('Verify the System Graph data for Daily MacTrak',function()
       {
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("daily","mactrak");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("daily","mactrak");             
       })

       it('Verify the System graph for Daily Spectral',function()
       {        
        EnterpriseSystemChartObject.clickSystemDailyButton();
        EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");              
       })
      
       it('Verify the System graph data for Daily Spectral',function()
       {
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("daily","spectral");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("daily","spectral");        
       })
      
       it('Verify the System graph data Daily Both',function()
       {
        EnterpriseSystemChartObject.clickSystemDailyButton();
        EnterpriseSystemChartObject.verifySysMactrakDropdown("both");
        EnterpriseSystemChartObject.sysVerifyIndySystemHighChartItemdata("daily","both");
        EnterpriseSystemChartObject.sysVerifySpySystemHighChartItemdata("daily","both");                
       })      

     it('Verify the Uncheck button functionality of the Systems graph',function()
        {  
          EnterpriseSystemChartObject.uncheckSystemIndy();
          EnterpriseSystemChartObject.verifygraphdataDisplayedforIndy();
          EnterpriseSystemChartObject.uncheckSystemSpy();
          EnterpriseSystemChartObject.verifygraphdataDisplayedforSpy();
          EnterpriseSystemChartObject.uncheckandCheckSystemShowAll();
          EnterpriseSystemChartObject.unCheckSystemIndySpy();      
        })

      it('Verify click on System graph Menu button functionlity', function()
        {
          EnterpriseSystemChartObject.verifyclickSystemMenuButton();
        })
      
      it('Verify System graph Zoom functionality', function()
        {
          EnterpriseSystemChartObject.verifyRegionZoomButton();
        })      
      
  })        