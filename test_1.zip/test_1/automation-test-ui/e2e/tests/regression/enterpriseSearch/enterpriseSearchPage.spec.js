var loginPage = require('../../../pages/loginPO/loginScreen.po');
var common = require('../commonMethods/startUpSyncMethod.spec');
var enterprisesearch = require('../../../pages/enterpriseSearchPO/enterpriseSearch.po');
var sync = require('../../../util/testData/constantTime');
var XL = require('../../../util/testData/XLReader');
const { browser } = require('protractor');
const { verifyAccordion } = require('../../../pages/enterpriseSearchPO/enterpriseSearch.po');

//const { get } = require('../../../pages/enterpriseSearchPO/enterpriseSearch.po');

describe('Xpertrak EnterpriseSearch page validations:', function()
{        
  //browser.waitForAngularEnabled(false);

    common.startUp();
    /*it('Login in to application with proper usename and credentials',function()
        {             
            loginPage.get("http://173.165.99.66/pathtrak/login/view.html#/login");
            sync.wait(5000);            
            loginPage.enterUserName("admin");
            loginPage.enterpassWord("admin");
            loginPage.clickSignin();
            sync.wait(15000);
            //loginPage.get("http://173.165.99.66/pathtrak/enterprise/index.html#/entsearch");
            loginPage.get("http://173.165.99.66/pathtrak/enterprise/index.html#/entsearch");
            sync.wait(5000);
            /*element(by.css("button.menu-button.menu-toggle")).click();
            sync.wait(5000);
            element(by.css("span[class='menu-text-ellipse menu-text darkMenu']")).click();
            sync.wait(5000);
           
            //loginPage.verifyResult();
        })*/   

    it('Enterprise search field editable validation',function()
    {
      var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
      TEST_DATA.forEach(function(data)
      {      
        enterprisesearch.get(data.EnterpriseSearchURL);
        sync.wait(5000);
        enterprisesearch.enterSearchitem(data.RPMSearchItem1);

        enterprisesearch.verifySugessionList();
      })      
    });    

    it('Enterprise search with valid text ',function()
      {
        var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
        TEST_DATA.forEach(function(data)
        {                
          enterprisesearch.enterSearchitem(data.RPMSearchItem2);
          enterprisesearch.clickSugessionItem();
          enterprisesearch.verifyAccordion();
        })
      });
    it('Enterprise search field validation after sugession added',function()
      {
        var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
        TEST_DATA.forEach(function(data)
        {
          enterprisesearch.enterSearchitem(data.RPMSearchItem1);                   
          enterprisesearch.clickSugessionItem();
          enterprisesearch.verifyEditsearchbox();
        })  
      });
    it('Enterprise search with invalid text',function()
      {
        var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
        TEST_DATA.forEach(function(data)
        { 
          //enterprisesearch.enterSearchitem("QWE");
            enterprisesearch.invalidErrormsg(data.invalidSearchItem);             
        });
      })          

    /*validate whether only 4 accordions are adding */      
    it('Enterprise search verifying the count of the sugessions',function()
      {
        var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
        TEST_DATA.forEach(function(data)
        {         
          /*loginPage.get("http://173.165.99.66/pathtrak/enterprise/index.html#/performance");
          sync.wait(5000);
          element(by.css("button.menu-button.menu-toggle")).click();
          sync.wait(5000);
          element(by.css("span[class='menu-text-ellipse menu-text darkMenu']")).click();
          sync.wait(5000);*/
          browser.refresh();
          sync.wait(5000);
          enterprisesearch.enterSearchitem(data.addMultipleSearchItem1);
          enterprisesearch.addingMultiplesearch(data.addMultipleSearchItem1);              
          enterprisesearch.enterSearchitem(data.addMultipleSearchItem2);
          enterprisesearch.addingMultiplesearch(data.addMultipleSearchItem2);              
          enterprisesearch.enterSearchitem(data.addMultipleSearchItem3);
          enterprisesearch.addingMultiplesearch(data.addMultipleSearchItem3);
          enterprisesearch.enterSearchitem(data.addMultipleSearchItem3);
          enterprisesearch.addingMultiplesearch(data.addMultipleSearchItem4);
          enterprisesearch.enterSearchitem(data.addMultipleSearchItem4);
          enterprisesearch.addingMultiplesearch(data.addMultipleSearchItem5);                   
          enterprisesearch.verifyAccordionsize();
        })                
      })

    /* validate whether only 4 records are adding and 5th record is replcaed by 
    closing 1st record and 5th record appears as recent search */

    it('Enterprise search: verify the count of the accordion and validate the 5th accordion is replaced by closing 1st accordion',function()
    {
      var TEST_DATA = XL.read_from_excel('EnterpriseSearch','./e2e/util/testData/XperTrakTestData.xlsx')
      TEST_DATA.forEach(function(data)
        {                                       
          enterprisesearch.verifyAddedmaxAccordion(data.verifyFirstAccordionItem1,data.verifyFourthAccordionItem);
        })
    })

    /*expand n close records after clicking on ^ n validate 5 live data presence n 
    Check that the latest searched item record is open by default*/

    it('Enterprise search: expand n close records after clicking on ^ n validate 5 live data presence',function()
      {         
          enterprisesearch.verifyFirstaccordionElements();           
      })
    
    /*expand all records by cclicking on ^ n validate 5 live data presence and they are clickable links*/

    it('Enterprise search: expand n close records after clicking on ^ n validate 5 live data presence and clickable',function()
      {         
        enterprisesearch.expandAllAccordion();
        enterprisesearch.verifyAccordionelementclickable();          
      })

    /*clicking on "x" icon of each record to remove accordion*/
    it('Enterprise search: clicking on "x" icon of each record to remove accordion',function()
      {         
        enterprisesearch.accordionClose();         
      })
    })
                                                                    
