import React, { useState } from "react";
import "./side-nav-math.css";

function AppSideNav() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isFullWidth, setIsFullWidth] = useState(false);
  const [expandedSection, setExpandedSection] = useState(null); // To track expanded section
  const [activeContent, setActiveContent] = useState("Default content"); // To track active content

  const toggleSidebar = () => setIsExpanded(!isExpanded);
  const toggleFullWidth = () => setIsFullWidth(!isFullWidth);

  // Toggle section expansion
  const toggleSection = (section) => {
    if (expandedSection === section) {
      setExpandedSection(null); // Collapse if already expanded
    } else {
      setExpandedSection(section); // Expand the clicked section
    }
  };

  // Handle content click
  const handleContentClick = (content) => {
    setActiveContent(content); // Set active content when link is clicked
  };

  return (
    <div className="app-container">
      {/* Side Navigation */}
      <div className={`sidebar ${isExpanded ? "expanded" : "collapsed"}`}>
       

        {/* Expandable sections */}
        <div className="section">
          <div className="section-title" onClick={() => toggleSection("section1")}>
            {expandedSection === "section1" ? "-" : "+"} Section 1
          </div>
          {expandedSection === "section1" && (
            <div className="section-content">
              <ul>
                <li onClick={() => handleContentClick("Content 1A")}>Content 1A</li>
                <li onClick={() => handleContentClick("Content 1B")}>Content 1B</li>
              </ul>
            </div>
          )}
        </div>

        <div className="section">
          <div className="section-title" onClick={() => toggleSection("section2")}>
            {expandedSection === "section2" ? "-" : "+"} Section 2
          </div>
          {expandedSection === "section2" && (
            <div className="section-content">
              <ul>
                <li onClick={() => handleContentClick("Content 2A")}>Content 2A</li>
                <li onClick={() => handleContentClick("Content 2B")}>Content 2B</li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className={`content ${isFullWidth ? "full-width" : "regular-width"}`}>
        <div className="video-player">
        <button className="toggle-btn" onClick={toggleSidebar}>
          {isExpanded ? ">" : "<"}
        </button>
          {/* Display content based on activeContent state */}
          <h2>{activeContent}</h2>
          <video
            src="https://www.w3schools.com/html/mov_bbb.mp4"
            controls
            width="100%"
          />
        </div>
      </div>
    </div>
  );
}

export default AppSideNav;
