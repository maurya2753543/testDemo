import React from 'react';
import './MathGeniusHeader.css'; // Import your CSS file for styling

const MathGeniusHeader = () => {
  return (
    <>
    <div className="main-container-math">
    <div className="container course-single-title-top">
      <div className="row">
        <div className="col-md-8">
          <h1 className="tutor-course-header-h1">Maths Genius Program</h1>
        </div>
      </div>
      <div className="row mt-3">
        {/* Column for Course Level */}
        <div className="col text-center">
          <p className="color-math">Course Level</p>
          <h3 className="m-0">Intermediate</h3>
        </div>
        {/* Column for Video Tutorials */}
        <div className="col text-center1">
          <span className="color-math">Video Tutorials</span>
          <h3 className="m-0">351</h3>
        </div>
        {/* Column for Continue to Lesson Button */}
        <div className="col ">
          <button className="btn btn-custom">CONTINUE TO LESSON</button> <br />        

          <span  className="text_complate color-math">Complete all lessons to <br /> mark this course as complete.</span>

        </div>
      
      </div>
    </div>
    </div>
   
      <div class="col-lg-12">
                <div class="tutor-price-thumbnail">
                    
                    <img className="image-math-gen"
                     src="https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png" class="attachment-post-thumbnail size-post-thumbnail" alt="" decoding="async" loading="lazy" srcset="https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png 1920w, https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail-300x169.png 300w, https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail-1024x576.png 1024w, https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail-768x432.png 768w, https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail-1536x864.png 1536w, https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail-600x338.png 600w"
                      sizes="(max-width: 1920px) 100vw, 1920px" />    
                                </div>
            </div>
    </>
   
  );
};

export default MathGeniusHeader;
