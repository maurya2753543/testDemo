import React, { useState } from "react";
import "./MainHomeForm.css";
import MainHomeHeader from "./MainHomeHeader";
import Footer from "../footer/Footer";
const FormComponent = () => {
    const [formData, setFormData] = useState({
        phoneNumber: "",
        parentFirstName: "",
        parentLastName: "",
        gender: "",
        email: "",
        childName: "",
        grade: "",
        timezone: "",
        selectedDate: "",
        selectedTime: "",
        consentGiven: false, // Added for consent checkbox
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value,
        });
    };
    //   const handleChange = (e) => {
    //     setFormData({
    //       ...formData,
    //       [e.target.name]: e.target.value,
    //     });
    //   };

    const [selectedDate, setSelectedDate] = useState("");
    const [selectedTime, setSelectedTime] = useState("");

    const currentDate = new Date();
    const dates = Array.from({ length: 3 }, (_, i) => {
        const date = new Date();
        date.setDate(currentDate.getDate() + i);
        return date.toDateString();
    });

    const times = [
        "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
        "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM",
        "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM",
    ];

    const handleDateSelect = (date) => {
        setSelectedDate(date);
        setFormData({ ...formData, selectedDate: date });
    };

    const handleTimeSelect = (time) => {
        setSelectedTime(time);
        setFormData({ ...formData, selectedTime: time });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`Selected Date: ${formData.selectedDate}\nSelected Time: ${formData.selectedTime}`);
    };

    return (
        <>
        <MainHomeHeader/>
        <div className="form-card">
            <form onSubmit={handleSubmit}>

                {/* Phone Number and Parent First Name */}
                <div className="row1">
                    <div className="column" style={{ width: '20%', position: 'relative' }}>
                        <label>Code</label>
                        <select name="countryCode" onChange={handleChange}>
                            <option value="+1">US (+1)</option>
                            <option value="+1">CA (+1)</option>
                        </select>
                        <div className="vertical-separator" />

                    </div>
                    <div className="column" style={{ width: '78%' }}>
                        <label>Phone Number*</label>
                        <input
                            type="text"
                            name="phoneNumber"
                            value={formData.phoneNumber}
                            onChange={handleChange}
                            placeholder="Enter 10 digits phone number"
                            required
                        />
                    </div>
                </div>

                {/* Parent First Name and Last Name */}
                <div className="row1">
                    <div className="column">
                        <label>Parent First Name*</label>
                        <input
                            type="text"
                            name="parentFirstName"
                            value={formData.parentFirstName}
                            onChange={handleChange}
                            placeholder="Enter First Name"
                            required
                        />
                    </div>
                    <div className="column">
                        <label>Parent Last Name*</label>
                        <input
                            type="text"
                            name="parentLastName"
                            value={formData.parentLastName}
                            placeholder="Enter Last Name"
                            onChange={handleChange}
                            required
                        />
                    </div>
                </div>

                {/* Gender and Email */}
                <div className="row1">
                    <div className="column"  style={{ width: '20%', position: 'relative' }}>
                        <label>Gender</label>
                        <select name="gender" value={formData.gender} onChange={handleChange}>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <div className="vertical-separator" />

                    </div>
                    <div className="column" style={{ width: '78%' }}>
                        <label>Email Address*</label>
                        <input
                            type="email"
                            name="email"
                            placeholder="Email address"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                </div>

                {/* Child's Name and Grade */}
                <div className="row1">
                    <div className="column" style={{ width: '78%' }}>
                        <label>Your Child's Name*</label>
                        <input
                            type="text"
                            name="childName"
                            value={formData.childName}
                            placeholder="Enter your child's name"
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="column" style={{ width: '20%' , position: 'relative' }} > 
                        <label>Grade</label>
                        <select name="grade" value={formData.grade} onChange={handleChange}>
                            {Array.from({ length: 12 }, (_, i) => (
                                <option key={i + 1} value={i + 1}>{i + 1}</option>
                            ))}
                        </select>
                        <div className="vertical-separator" />

                    </div>
                </div>

                {/* Timezone */}
                <div className="row1">
                    <div className="column" style={{ width: '100%', position: 'relative' }}>
                        <label>Timezone</label>
                        <select name="timezone" value={formData.timezone} onChange={handleChange}>
                            <option value="PST">Select Timezone</option>
                            <option value="PST">Pacific Standard Time (PST)</option>
                            <option value="EST">Mountain Standard Time (MST)</option>
                            <option value="MST">Central Standard Time (CST)</option>
                            <option value="CST">Eastern Standard Time (EST)</option>
                        </select>
                        <div className="vertical-separator" />

                    </div>
                </div>

                {/* Date Selection */}
                <div className="date-row1">
                    <label>Pick a Date</label>
                    <div className="date-grid">
                        {dates.map((date, index) => (
                            <div
                                key={index}
                                className={`date-box ${selectedDate === date ? "selected" : ""}`}
                                onClick={() => handleDateSelect(date)}
                            >
                                {date}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Time Selection */}
                <div className="time-row1">
                    <label>Pick a Time</label>
                    <div className="time-grid">
                        {times.map((time, index) => (
                            <div
                                key={index}
                                className={`time-box ${selectedTime === time ? "selected" : ""}`}
                                onClick={() => handleTimeSelect(time)}
                            >
                                {time}
                            </div>
                        ))}
                    </div>
                </div>

                <div className="consent">
                    <input tyle={{ width: '5%' }}
                        type="checkbox"
                        name="consentGiven"
                        checked={formData.consentGiven}
                        onChange={handleChange}
                    />
                    <span style={{ width: '90%', marginLeft: '10px' }}>By submitting this information, you consent to receive information related to your class by phone, email, and WhatsApp.</span>
                </div>

                {/* Buttons */}
                <div className="row1 buttons">
                    <button type="button" className="back-button">
                        <i className="fas fa-long-arrow-alt-left"></i> {/* Moved the icon inside the button */}
                        Back
                    </button>
                    <button type="submit" className="submit-button">                  
                        Submit
                        <i class="fas fa-long-arrow-alt-right"></i>
                        </button>
                </div>
            </form>
        </div>
        <div>
            <Footer />
        </div>
        </>
        
    );
};

export default FormComponent;
