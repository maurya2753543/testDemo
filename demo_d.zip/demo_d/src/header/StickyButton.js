import React, { useState, useRef, useEffect } from 'react';
import './StickyButton.css'; // Make sure to import your CSS file

const StickyButton = () => {
  const [isPopupVisible, setPopupVisible] = useState(false);
  const [isArrowRotated, setArrowRotated] = useState(false);
  const [isContactFormVisible, setContactFormVisible] = useState(false);
  

  const formRef = useRef(null); // Ref for the form

  const toggleArrow = () => {
    setArrowRotated(!isArrowRotated);
    setPopupVisible(!isPopupVisible);
    setContactFormVisible(false);
    
  };

  const handleContactClick = () => {
    setContactFormVisible(!isContactFormVisible);

  };

  const handleMouseLeave = () => {
    setPopupVisible(false); // Hide the popup after the closing animation

    
  };
 

  // Detect clicks outside the form and close the form
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (formRef.current && !formRef.current.contains(event.target)) {
        setContactFormVisible(false); // Close the form
      }
    };

    // Attach the event listener to detect outside clicks
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup the event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [formRef]);

  return (
    <div className="mystickyelement-lists-wrap">
      <ul className="mystickyelements-lists mysticky">
        {/* Arrow Button - 20% Width */}
        <li className="mystickyelements-minimize" onClick={toggleArrow} style={{ width: '90px' }}>
          <span
            className="mystickyelements-minimize"
            style={{
              background: '#000',
              color: '#fff',
              fontSize: '20px',
              width: '60px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '40px',
              transition: 'transform 0.3s',
              transform: isArrowRotated ? 'rotate(180deg)' : 'rotate(0deg)',
            }}
          >
            →
          </span>
        </li>

        {/* Contact Us Button - 80% Width */}
        <li
          id="mystickyelements-contact-form"
          className="mystickyelements-contact-form"
          style={{
            width: '90px',
            transform: isArrowRotated ? 'rotate(-90deg)' : 'rotate(0deg)', // Rotate contact us button
            display: isPopupVisible ? 'none' : 'flex', // Hide/Show contact us button
            transition: 'transform 0.3s',
          }}
        >
          <span className="contactus_btn">
            <span
              style={{
                backgroundColor: 'rgb(119, 97, 223)',
                color: 'rgb(255, 255, 255)',
                width: '110px', // 80% of the total button width
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '55px', // Height of the button
                transform: 'rotate(-90deg)', // Rotate the button by -90 degrees
                gap: '15px',
                padding: '0 10px 10px 10px',
                borderRadius: '10px 0 0 0',
              }}
              onMouseEnter={handleContactClick} // Keep form open on hover
              onMouseLeave={handleMouseLeave} // Close form on mouse leave
            >
              <i className="far fa-envelope" style={{ fontSize: '15px' }}></i>
              Contact Us
            </span>
          </span>
        </li>

        {/* Contact Form */}
        {isContactFormVisible && (
          <div
            className="element-contact-form"
            ref={formRef}
            style={{ marginTop: '10px', display: isContactFormVisible ? 'block' : 'none' }}
            onMouseLeave={() => setContactFormVisible(false)} // Close form when mouse leaves
          >
            <h3 className="contact-header">
              Contact Us
              <a href="javascript:void(0);" className="element-contact-close" onClick={handleContactClick}>
                <i className="fas fa-times"></i>
              </a>
            </h3>

            <form id="stickyelements-form" action="" method="post" autoComplete="off">
              <input className="required" type="text" placeholder="Name" required autoComplete="off" />
              <input className="required" type="tel" placeholder="Phone" required autoComplete="off" />
              <input className="email required" type="email" placeholder="Email" required autoComplete="off" />
              <textarea className="required" placeholder="Message" required></textarea>
              <input
                id="stickyelements-submit-form"
                type="submit"
                value="Submit"
                style={{ backgroundColor: '#7761DF', color: '#FFFFFF' }}
              />
            </form>
            <p className="mse-form-success-message" style={{ display: 'none' }}></p>
          </div>
        )}
      </ul>
    </div>
  );
};

export default StickyButton;
