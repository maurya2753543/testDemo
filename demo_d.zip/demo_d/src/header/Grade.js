import React from 'react';
import './Grade.css';
import { Link, useNavigate } from 'react-router-dom';

const Grade = () => {
    return (
        <div>
            {/* Top Shape Divider */}
            <div className="qubely-shape-divider qubely-top-shape">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 99" preserveAspectRatio="none">
                    <path d="M526.35,17.11C607.41,28.38,687,48.17,768.06,59.5A1149.19,1149.19,0,0,0,1000,68.07V0H0V99C155.18,13.84,347.42-7.77,526.35,17.11Z" transform="translate(0 0.04)"></path>
                </svg>
            </div>

            {/* Grade 8+ Section */}
            <div className="wp-block-qubely-text qubely-block-5e8cd1">
                <div className="qubely-block-text">
                    <div className="qubely-block-text-title-container qubely-separator-position-top">
                        <div className="qubely-block-text-title-inner">
                            <h1 className="qubely-block-text-title" style={{ marginTop: '0px', paddingTop: '0px' }}>  {/* Reducing the margin and padding */}
                                <div style={{ textAlign: 'center', marginTop: '0px', paddingTop: '0px' }}>(Grade 8+)</div>
                                <br />
                                <span>AP Math Genius</span>
                            </h1>
                        </div>
                    </div>
                    <p className='text-p'>
                        <span style={{ color: '#062040' }}>
                            <strong>
                                Enroll your child in the AP Math Genius Program by Prof Ved and help them excel in high school, achieving
                                top grades in advanced math courses. If your child is in a lower grade but exhibits advanced math skills, our
                                faculty team will recommend enrolling them in this program.
                            </strong>
                        </span>
                    </p>
                </div>
            </div>

            {/* Grade 8+ Image */}
            <div style={{ marginLeft : '50px'}}>
            <figure className="wp-block-image size-large">
                <img
                    decoding="async"
                    loading="lazy"
                    width="1024"
                    height="576"
                    src="https://www.profved.com/wp-content/uploads/2024/09/AP-math-genius-thumbnail-1024x576.png"
                    alt="AP Math Genius"
                />
            </figure>
            </div>
           

            {/* Enroll Now and Trial Buttons */}
            <div className="wp-block-qubely-button qubely-block-c698c2">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn">
                        <Link className="qubely-block-btn-anchor is-large"
                         href="https://www.profved.com/ap-math-genius-program-by-prof-ved-algebra-geometry-calculus-statistics/">
                            Enroll Now
                        </Link>
                    </div>
                </div>
            </div>

            <div className="wp-block-qubely-button-book">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn-book">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/onboard.html?src=home">
                            Book A Free Trial cum Evaluation Class
                        </Link>
                    </div>
                </div>
            </div>

            {/* Grade 6-8 Section */}
            <div className="wp-block-qubely-text qubely-block-16934d">
                <div className="qubely-block-text">
                    <div className="qubely-block-text-title-container qubely-separator-position-top">
                        <div className="qubely-block-text-title-inner">
                            
                            <h1 className="qubely-block-text-title" style={{ marginTop: '20px', paddingTop: '0px' }}>  {/* Reducing the margin and padding */}
                                <div style={{ textAlign: 'center', marginTop: '0px', paddingTop: '0px' }}>(Grade 6-8)</div>
                                <br />
                                <span>Math Genius Pro</span>
                            </h1>
                        </div>
                    </div>
                    <p className='text-p'>
                        <span style={{ color: '#062040' }}>
                            Enroll your child in the Math Genius Pro Program by Prof Ved and set them on a path to excel in middle school,
                            consistently achieving scores well above grade level. If your child demonstrates advanced math abilities, they
                            may transition to the AP Math Genius Program at an appropriate time.
                        </span>
                    </p>
                </div>
            </div>

            {/* Grade 6-8 Image */}
            <figure style={{ marginLeft : '90px'}} className="wp-block-image size-large">
                <img
                    decoding="async"
                    loading="lazy"
                    width="1024"
                    height="576"
                    src="https://www.profved.com/wp-content/uploads/2023/09/Math-Genius-Pro-1024x576.png"
                    alt="Math Genius Pro"
                />
            </figure>

            {/* Enroll Now and Trial Buttons for Grade 6-8 */}
            <div className="wp-block-qubely-button qubely-block-c698c2">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/ap-math-genius-program-by-prof-ved-algebra-geometry-calculus-statistics/">
                            Enroll Now
                        </Link>
                    </div>
                </div>
            </div>

            <div className="wp-block-qubely-button-book">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn-book">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/onboard.html?src=home">
                            Book A Free Trial cum Evaluation Class
                        </Link>
                    </div>
                </div>
            </div>

            {/* Grade 4-5 Section */}
            <div className="wp-block-qubely-text qubely-block-2127bf">
                <div className="qubely-block-text">
                    <div className="qubely-block-text-title-container qubely-separator-position-top">
                        <div className="qubely-block-text-title-inner">
                            <h2 className="qubely-block-text-title">
                               <div style={{ textAlign : 'center'}}>(Grades 4-5) </div> 
                                <br />
                                <span style={{ color: '#2084F9' }}>Math Genius Program</span>
                            </h2>
                        </div>
                    </div>
                    <p className='text-p'>
                        <span style={{ color: '#062040' }}>
                            Enroll your child in the Math Genius Program by Prof Ved to take her interest and confidence in maths to the next
                            level. We promise that not only other students but even you will find it hard to catch up with your child when it
                            comes to doing lightning-fast math.
                        </span>
                    </p>
                </div>
            </div>

            {/* Grade 4-5 Image */}
            <figure style={{ marginLeft : '90px'}} className="wp-block-image size-large">
                <a href="https://www.profved.com/mathgenius">
                    <img
                        decoding="async"
                        loading="lazy"
                        width="1024"
                        height="576"
                        src="https://www.profved.com/wp-content/uploads/2023/09/MathGeniusProgram-1024x576.png"
                        alt="Math Genius Program"
                    />
                </a>
            </figure>
             {/* Enroll Now and Trial Buttons for Grade 6-8 */}
             <div className="wp-block-qubely-button qubely-block-c698c2">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn">
                        <a className="qubely-block-btn-anchor is-large" href="https://www.profved.com/ap-math-genius-program-by-prof-ved-algebra-geometry-calculus-statistics/">
                            Enroll Now
                        </a>
                    </div>
                </div>
            </div>

            <div className="wp-block-qubely-button-book">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn-book">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/onboard.html?src=home">
                            Book A Free Trial cum Evaluation Class
                        </Link>
                    </div>
                </div>
            </div>
              {/* Grade 6-8 Section */}
              <div className="wp-block-qubely-text qubely-block-16934d">
                <div className="qubely-block-text">
                    <div className="qubely-block-text-title-container qubely-separator-position-top">
                        <div className="qubely-block-text-title-inner">
                            
                            <h1 className="qubely-block-text-title" style={{ marginTop: '20px', paddingTop: '0px' }}>  {/* Reducing the margin and padding */}
                                <div style={{ textAlign: 'center', marginTop: '0px', paddingTop: '0px' }}>(Up to Grade 3)</div>
                                <br />
                                <span>Child Genius Program</span>
                            </h1>
                        </div>
                    </div>
                    <p className='text-p'>
                        <span style={{ color: '#062040' }}>
                        Enroll your child in the most powerful Child Genius Program by Prof Ved and give her the strongest math foundation possible. We promise that not only other students but even you will find it hard to catch up with your child when it comes to doing lighting-fast math. Check the program details below.
                        </span>
                    </p>
                </div>
                <figure style={{ marginLeft : '90px'}} className="wp-block-image size-large">
                <a href="https://www.profved.com/mathgenius">
                    <img
                        decoding="async"
                        loading="lazy"
                        width="1024"
                        height="576"
                        src="	https://www.profved.com/wp-content/uploads/2023/09/Child-Genius-Program.png"
                        alt="Math Genius Program"
                    />
                </a>
            </figure>
                 {/* Enroll Now and Trial Buttons for Grade 6-8 */}
            <div className="wp-block-qubely-button qubely-block-c698c2">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/ap-math-genius-program-by-prof-ved-algebra-geometry-calculus-statistics/">
                            Enroll Now
                        </Link>
                    </div>
                </div>
            </div>

            <div className="wp-block-qubely-button-book">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn-book">
                        <Link className="qubely-block-btn-anchor is-large" href="https://www.profved.com/onboard.html?src=home">
                            Book A Free Trial cum Evaluation Class
                        </Link>
                    </div>
                </div>
            </div>
            </div>
        </div>
    );
};

export default Grade;
