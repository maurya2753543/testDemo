import React, { useState } from 'react';
import './Dashboard.css'; // You can create a CSS file for styles if needed
import Header from '../comman-header/Header';
import Footer from '../footer/Footer';
import TabLayout from './TabLayout';
import TabContent from './DashbordContent'; // Import TabContent
import MyProfileLogin from './MyProfileLogin';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';


const Dashboard = ({ onLoginSuccess, isLoggedIn }) => {

  return (
    <>
      <Header />
      {/* <TabLayout />
      <TabContent /> */}
      {/* Show MyProfileLogin if not logged in, otherwise show TabLayout and TabContent */}
      {!isLoggedIn ? (
        <MyProfileLogin onLoginSuccess={onLoginSuccess} />
      ) : (
        <>
         <Router>
         <TabContent />

         <TabLayout />   

          </Router>
    {/*  */}

        </>
      )}
      <Footer />
    </>
  );
};

export default Dashboard;
