import React, { useState } from 'react';
import './Wishlist.css'; // Assuming you have some styles here
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faTrash,faPlus } from '@fortawesome/free-solid-svg-icons';

// Sample data for courses
const courses = [
  {
    id: 1,
    title: "Maths Genius Program",
    grade: "(Grades 4-5)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png",
    rating: 55.9,
    price: 599,
    actualPrice: 1000,
    oneTime: "One-Time LMS FEE",
    feedback: "4.5/5 - Great course, highly recommend!",
  },
  {
    id: 2,
    title: "(Up to Grade 3) Child Genius Program",
    grade: "(Up to Grade 3)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2023/09/Child-Genius-Program.png",
    rating: 55.9,
    price: 599,
    actualPrice: 1000,
    oneTime: "One-Time LMS FEE",
    feedback: "4.8/5 - Very informative and well-structured.",
  },
  {
    id: 3,
    title: "(Grade 6-8) Math Genius Pro",
    imageUrl: "https://www.profved.com/wp-content/uploads/2023/09/Math-Genius-Pro.png",
    rating: 55.9,
    grade: "(Grade 6-8)",
    price: 599,
    actualPrice: 1000,
    oneTime: "One-Time LMS FEE",
    feedback: "4.7/5 - Excellent content and delivery.",
  },
  {
    id: 4,
    title: "AP-math-genius",
    imageUrl: "https://www.profved.com/wp-content/uploads/2024/09/AP-math-genius-thumbnail.png",
    rating: 55.9,
    grade: "(Grade 8 +)",
    oneTime: "One-Time LMS FEE",
    price: 599,
    actualPrice: 1000,
    feedback: "4.2/5 - Useful for beginners.",
  },
  {
    id: 5,
    title: "Maths Genius Program (Monthly)",
    grade: "(Grades 4-5)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png",
    rating: 55.9,
    price: 299,
    actualPrice: 350,
    oneTime: "Monthly",
    feedback: "4.5/5 - Great course, highly recommend!",
  },
  {
    id: 6,
    title: "(Up to Grade 3) Child Genius Program (Monthly)",
    grade: "(Up to Grade 3)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2023/09/Child-Genius-Program.png",
    rating: 55.9,
    price: 299,
    actualPrice: 350,
    oneTime: "Monthly",
    feedback: "4.8/5 - Very informative and well-structured.",
  },
  {
    id: 7,
    title: "(Grade 6-8) Math Genius Pro (Monthly)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2023/09/Math-Genius-Pro.png",
    rating: 55.9,
    grade: "(Grade 6-8)",
    price: 299,
    actualPrice: 350,
    oneTime: "Monthly",
    feedback: "4.7/5 - Excellent content and delivery.",
  },
  {
    id: 8,
    title: "AP-math-genius (Monthly)",
    imageUrl: "https://www.profved.com/wp-content/uploads/2024/09/AP-math-genius-thumbnail.png",
    rating: 55.9,
    grade: "(Grade 8 +)",
    oneTime: "Monthly",
    price: 299,
    actualPrice: 350,
    feedback: "4.2/5 - Useful for beginners.",
  },
];

const Wishlist = () => {
  const [cart, setCart] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);

  const handleDelete = (id) => {
    setCart((prevCart) => prevCart.filter((course) => course.id !== id));
    console.log(`Deleted course with id: ${id}`);
  };

  const handleAddToCart = (course) => {
    if (!cart.some(item => item.id === course.id)) {
      setCart((prevCart) => [...prevCart, course]);
      console.log(`Added to cart: ${course.title}`);
    } else {
      alert(`${course.title} is already in your cart!`);
    }
  };

  const filteredCourses = courses.filter(course =>
    course.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedCourse(null);
  };

  const handleSelectCourse = (course) => {
    setSelectedCourse(course);
  };

  const handleAddCard = () => {
    if (selectedCourse) {
      handleAddToCart(selectedCourse);
      handleCloseModal();
    }
  };

  return (
    <div className="wishlist-container">
      <h1>Your Wishlist</h1>
      
      <div className="recommendation-section">
        <h2>Recommended Courses</h2>
        
        <div style={{ display: 'flex' }}>
          <input 
            type="text" 
            placeholder="Search courses..." 
            value={searchTerm} 
            onChange={(e) => setSearchTerm(e.target.value)} 
            style={{ width: '80%', marginRight: '10px' }}
          />
          <button className= "Recomendedbtn" onClick={handleOpenModal} >
            Recommended
          </button>
        </div>
               
      </div>

      <div className="wishlist-grid">
        {cart.length > 0 ? (
          cart.map((course) => {
            const discountPercentage = ((course.actualPrice - course.price) / course.actualPrice) * 100;

            return (
              <div className="course-item" key={course.id}>
                <div className="delete-icon" onClick={() => handleDelete(course.id)}>
                  <FontAwesomeIcon icon={faTrash} />
                </div>
                <img src={course.imageUrl} alt={course.title} className="course-image" />
                <h1 className="course-title">{course.title}</h1>
                <h1 className="course-title">{course.grade}</h1>
                <h1 className="course-title">{course.oneTime}</h1>
                <div className="course-info">
                  <div className="course-rating">
                    <span>↓</span>
                    <span>{discountPercentage.toFixed(2)}% off</span>
                  </div>
                  <div className="course-price">${course.actualPrice.toFixed(2)}</div>
                  <div className="course-price">${course.price.toFixed(2)}</div>
                </div>
                <div className="course-feedback">
                  {course.feedback}
                  <div className="course-stars">
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#B0B0B0" />
                  </div>
                </div>
                <button className="addcardbtn" >
                 Buy now
                 </button>
              </div>
            );
          })
        ) : (
          <p className="empty-cart-message">Cart is empty. Please add courses.</p>
        )}
      </div>

      {isModalOpen && (
        <div className="modal">
          <h2>Select a Course</h2>
          <select onChange={(e) => handleSelectCourse(courses.find(course => course.id === Number(e.target.value)))}>
            <option value="">Select a course...</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>
                {course.title}
              </option>
            ))}
          </select>
          <div style={{ display: 'flex', alignItems: 'center' }}>
  <button className="addcardbtn" onClick={handleAddCard}>
    <FontAwesomeIcon icon={faPlus} style={{ marginRight: '8px' }} /> Add Card
  </button>
  <button className="Model-fa-icon" onClick={handleCloseModal} style={{ marginLeft: 'auto' }}>
    <FontAwesomeIcon icon={faTrash} />
  </button>
</div>
        </div>
      )}
    </div>
  );
};

export default Wishlist;
