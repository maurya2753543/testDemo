import React, { useState, useEffect } from 'react';
import AppwriteService from '../appwrite/AppwriteService'; // Import AppwriteService
import './DashboardTopHeader.css'; // Assuming you want to style it in a separate CSS file

const DashboardTopHeader = () => {
  const [username, setUsername] = useState('');
  const [avatarUrl, setAvatarUrl] = useState(''); // State for avatar URL

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get(); // Fetch the current user's data
        console.log(user); // Log the fetched user data
        
        // Set the username and avatar URL
        setUsername(user.name || ''); // Assuming user.name contains the full name
        setAvatarUrl(user.avatar || "https://secure.gravatar.com/avatar/f72172a0cf3d814741f44ae012b5cbe5?s=150&d=mm&r=g"); // Example for avatar URL
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  return (
    <div className="tutor-dashboard-header">
      <div className="tutor-dashboard-header-avatar">
        <img
          src={avatarUrl}
          alt="User Avatar"
        />
      </div>
      <div className="tutor-dashboard-header-info">
        <div className="tutor-dashboard-header-display-name">
          <h1>
            <span className="howdy-text">Howdy,</span> <strong>{username}</strong>
          </h1>
        </div>
      </div>
      <div className="tutor-dashboard-header-button">
        {/* Add any buttons here, e.g., Logout button */}
      </div>
    </div>
  );
};

export default DashboardTopHeader;
