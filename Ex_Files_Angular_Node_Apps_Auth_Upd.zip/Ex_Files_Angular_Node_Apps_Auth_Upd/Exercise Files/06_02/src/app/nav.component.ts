import { Component } from '@angular/core'

@Component({
    selector: 'nav',
    template: `
        <md-toolbar color="primary">
            Message Board
        </md-toolbar>
    `
})
export class NavComponent {
    constructor() {}
}