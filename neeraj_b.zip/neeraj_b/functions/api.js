require("dotenv").config(); // Load environment variables
console.log("RAZORPAY_KEY_ID:", process.env.RAZORPAY_KEY_ID);
console.log("RAZORPAY_KEY_SECRET:", process.env.RAZORPAY_KEY_SECRET);

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const Razorpay = require("razorpay");
const serverless = require("serverless-http");

const app = express();
const router = express.Router();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Razorpay instance setup
const razorpay = new Razorpay({
  key_id: "rzp_live_KJe8XvuoMkjF6b",  // Direct API key
  key_secret: "LFfW4ZUay5RPQIgfrtj2ixSZ",  // Direct API secret
});

// Routes
router.get("/", (req, res) => {
  res.send("Hello World!");
});

router.post("/orders", async (req, res) => {
  const { amount, currency } = req.body;

  if (!amount || !currency) {
    return res.status(400).json({ error: "Amount and currency are required." });
  }

  const options = {
    amount: parseInt(amount),
    currency,
    receipt: `receipt#${Date.now()}`,
    payment_capture: 1,
  };

  try {
    const response = await razorpay.orders.create(options);
    res.json({
      order_id: response.id,
      currency: response.currency,
      amount: response.amount,
    });
  } catch (error) {
    console.error("Error creating Razorpay order:", error);
    res.status(500).json({ error: "Internal server error while creating order." });
  }
});

router.get("/payment/:paymentId", async (req, res) => {
  const { paymentId } = req.params;

  try {
    const payment = await razorpay.payments.fetch(paymentId);

    if (!payment) {
      return res.status(404).json({ error: "Payment not found." });
    }

    res.json({
      status: payment.status,
      method: payment.method,
      amount: payment.amount,
      currency: payment.currency,
    });
  } catch (error) {
    console.error("Error fetching payment:", error);
    res.status(500).json({ error: "Failed to fetch payment details." });
  }
});

// Use the router
app.use("/.netlify/functions/api", router);

// Export for serverless function
module.exports.handler = serverless(app);
