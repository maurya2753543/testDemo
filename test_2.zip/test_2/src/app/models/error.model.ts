

/*Class to handle error model for modules*/
export class AdminAppError {

  public errorCode: number;
  public errMsg:string;
  public errStatus: string;

  constructor(_errorData) {
    if(_errorData && _errorData._body && _errorData.json()) {
      let errorData = _errorData.json();
      if(errorData.errorMessage){
        this.setErrorMsg(errorData.httpStatus, errorData.errorMessage, errorData.errorCode);
      }else {
        this.setErrorMsg(null, "Internal Server Error", null);
      }
    }else {
      this.setErrorMsg(null, "Internal Server Error", null);
    }
  }

  /* Function used to give the object of the error model */
  private setErrorMsg(errStatus, errMsg, errorCode): void{
    this.errStatus = errStatus ? errStatus : null;
    this.errMsg = errMsg ? errMsg: null;
    this.errorCode = errorCode ? errorCode : null;
  }

}
