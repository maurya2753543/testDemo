

/* Used to give the response as a custom object */
export class AdminAppResponse {

  public status : boolean;
  public resModel : Object;

  constructor(_status, _response){
    this.status =  _status;
    this.resModel = (_response) ? _response: null;
  }
}
