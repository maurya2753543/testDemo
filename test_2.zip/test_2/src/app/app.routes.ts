import { Routes, RouterModule } from '@angular/router';
// import {HomeComponent} from "./components/home/home.component";
import { RouteResolverService } from "./shared/route.resolver.service";
import { PermissionGuard } from "./shared/permission.guard";
import {
    NAV_LINK_HOME, NAV_LINK_HCU, NAV_LINK_CMTS, NAV_LINK_OLT,NAV_LINK_ALARMS, NAV_LINK_ENTERPRISE, NAV_LINK_SETTING,
    NAV_LINK_INFO, NAV_LINK_USERS, HOME_MODULE, INFO_MODULE, HCU_MODULE, ALARMS_MODULE, CMTS_MODULE, OLT_MODULE, ENTERPRISE_MODULE,
    SETTINGS_MODULE, USERS_MODULE, DASHBOARD_MODULE, SITES_MODULE, NAV_LINK_SITES, NAV_LINK_CONTAINER, CONTAINER_MODULE,
    RCI_MODULE, NAV_LINK_RCI, OTU_MODULE, NAV_LINK_OTU, NAV_LINK_ADMIN_PON
} from "./constant/app.constants";
import { NgModule } from '@angular/core';
import { SettingsModule } from './modules/system-settings/system-settings.module';
import { LanguageLoaderGuard } from './shared/language-loader.guard';

// Route Configuration
const routes: Routes = [
    { 
        path: '', 
        redirectTo: DASHBOARD_MODULE, 
        pathMatch: 'full' 
    },
    { 
        path: DASHBOARD_MODULE, 
        loadChildren : () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule), 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_HOME } 
    },
    { 
        path: INFO_MODULE, 
        loadChildren:()=> import('./modules/information/info.module').then(m=>m.InfoModule), 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_INFO } },

    {
        path: HCU_MODULE, 
        loadChildren:()=>import('./modules/hcu/hcu.module').then(m=>m.HCUModule), 
        resolve: { login: RouteResolverService },
        data: { path: NAV_LINK_HCU }
    },

    { 
        path: ALARMS_MODULE, 
        loadChildren: ()=>import('./modules/alarms/alarms.module').then(m=>m.AlarmsModule), 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_ALARMS } 
    },
    { 
        path: CMTS_MODULE, 
        loadChildren: ()=>import('./modules/cmts/cmts.module').then(m=>m.CMTSModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_CMTS } 
    },
    { 
        path: OLT_MODULE, 
        loadChildren: ()=>import('./modules/olt/olt.module').then(m=>m.OltModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_ADMIN_PON } 
       
    },
    { 
        path: ENTERPRISE_MODULE, 
        loadChildren: ()=>import('./modules/enterprise/enterprise.module').then(m=>m.EnterpriseModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_ENTERPRISE } 
    },
    { 
        path: SETTINGS_MODULE, 
        loadChildren: ()=>import('./modules/system-settings/system-settings.module').then(m=>m.SettingsModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_SETTING } 
    },
    { 
        path: USERS_MODULE, 
        loadChildren: ()=>import('./modules/users/users.module').then(m=>m.UsersModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_USERS } 
    },
    { 
        path: SITES_MODULE, 
        loadChildren: ()=>import('./modules/sites/sites.module').then(m=>m.SitesModule), 
        canActivate: [PermissionGuard],
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_SITES } 
    },
    {
        path: CONTAINER_MODULE, 
        loadChildren: ()=>import( './modules/container/container.module').then(m=>m.ContainerModule), 
        canActivate: [PermissionGuard],
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_CONTAINER }
    },
    { 
        path: RCI_MODULE, 
        loadChildren: ()=>import('./modules/rci/rci.module').then(m=>m.RciModule),
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_RCI }
    },
    { 
        path: OTU_MODULE, 
        loadChildren: ()=>import('./modules/otu/otu.module').then(m=>m.OtuModule), 
        canActivate: [PermissionGuard], 
        resolve: { login: RouteResolverService }, 
        data: { path: NAV_LINK_OTU } 
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule],
    providers:[RouteResolverService]
  })

export class AppRoutes {};
//export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
