/**
 * Created by narayan.reddy on 23-06-2017.
 */
import { Injectable } from '@angular/core';
import { PATHTRAK_PATH } from "../../constant/app.constants";
import { SharedService } from "../../shared/shared.service";

@Injectable()
export class HeaderUrlService {

    private host:string = "";

    constructor(private sharedService: SharedService) {
    }
    
    /* Return url to get node list from server*/
    public getLogoutUrl(): string {
        return this.sharedService.getHost() + PATHTRAK_PATH + "auth/logout" ;
    }
}
