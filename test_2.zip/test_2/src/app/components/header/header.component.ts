import {Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, OnInit, ElementRef, Renderer2, Inject} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Subject, Observable, throwError} from "rxjs";
import {SharedService} from "../../shared/shared.service";
import {HeaderHttpService} from "./header.http.service";
import {WindowService} from '../../shared/nativeProvider/window.service';
import {Logger} from "../../utilities/logger";
import {LOGOUT_NAV_URL, DEFAULT_PRODUCTION, VIEW_HOME_URL, VIEW_LITE_APP_URL} from "../../constant/app.constants";
import {ENTERPRISE_LINK_URL} from "../../constant/app.constants";
import {ADMINISTRATION_LINK_URL} from "../../constant/app.constants";
import {UserSettingComponent} from "./user.settings/user.settings.component";
import { NavService } from '../../shared/nav.service';
import {ThemeService} from '../../shared/theme.service';
import {CookieService} from '../../shared/cookie.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'header-component',
    templateUrl: 'header.component.html',
    
})
export class HeaderComponent {
    private isDarkTheme:boolean = false;
    private window:Window;
    public userSettings: boolean = false;
    private isOverlayHidden:boolean = true;

	private tag:string = "header.component.ts";
	private HEADER_HOME:string = "Home";

    @ViewChild('targetUserSetting', {read: ViewContainerRef}) _targetUserSetting;

    constructor(private componentFactoryResolver: ComponentFactoryResolver,
            private viewContainerRef: ViewContainerRef ,
            private httpService:HeaderHttpService,
            private windowService:WindowService,
            private sharedService:SharedService,
            private logger:Logger,
            private navService: NavService,
            private elementRef: ElementRef,
            private themeService:ThemeService,
            private cookieService:CookieService,
            private renderer: Renderer2,
            @Inject(DOCUMENT) private document,
            private translate: TranslateService) {
        this.window = windowService.getWindow();
        this.cookieService.setThemeByCookie();
    }

    // ngOnInit() {
    //     this.elementRef.nativeElement.addEventListener('transitionend', this.navService.onNavOpen);
    // }

    // ngOnDestroy() {
    //     this.elementRef.nativeElement.removeEventListener('transitionend', this.navService.onNavOpen);
    // }

    //function loads user setting tab/slider.
    private LoadUserSettingsTab(): void{
        this.sharedService.getCloseSlidersSubject().next(true);
        this._targetUserSetting.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(UserSettingComponent);
        this._targetUserSetting.createComponent(factory);
    }

    //fucntion :: opens the user setting sidebar
    public openUserSetting():void {
        this.LoadUserSettingsTab();
        this.userSettings=!this.userSettings;
    }

     //function toggles side navbar
    public toggleNav(): void {
        this.navService.toggleNav();
    }

    //changes theme of application
    public applyDarkTheme():void {
        let isDarkThemeSet;
        let isDarkThemeString = this.cookieService.getCookie();
        if(isDarkThemeString == 'true'){
            this.isDarkTheme = true;
        }else{
            this.isDarkTheme = false;
        }
        this.isDarkTheme = !this.isDarkTheme;
        this.themeService.toggle();
        this.sharedService.getThemeChangeSubject().next(this.isDarkTheme);
        if (this.isDarkTheme) {
            this.renderer.addClass(this.document.body,"dark-theme");
            isDarkThemeSet = 'true';
        } else {
            this.renderer.removeClass(this.document.body,"dark-theme");
            isDarkThemeSet = 'false';
        }
        this.cookieService.setCookie(isDarkThemeSet);
    }

    //logout from application
    public logout():void {
        this.httpService.getLogoutCall().subscribe((dataList) => {
            let window : any = this.windowService.getWindow();
            let host :  string = window.location.host;
            let protocol : string =  window.location.protocol;
            let path : string = protocol.concat(DEFAULT_PRODUCTION, host, LOGOUT_NAV_URL);
            window.location.assign(path);
        }, (error) => {
            this.handleError
        });
    }

    /*Method to handle error*/
    public handleError(error) {
        return throwError(error);
    }


    // Function used for sitemap links navigation.
    private navigateTo(navigate:string):void {
        let host:string = this.window.location.host;
        let protocol:string = this.window.location.protocol;
        let path:string = protocol + DEFAULT_PRODUCTION + host;
        if (navigate == 'application') {
            path += ADMINISTRATION_LINK_URL;
        } else {
            path += ENTERPRISE_LINK_URL;
        }
        this.window.open(path);
    }

	public redirectToExternalView(){
		let externalUrl:string = this.sharedService.getHost() + VIEW_HOME_URL;
		if (externalUrl) {
			window.open(externalUrl);
		} else {
			this.logger.error(this.tag, "redirectToExternalView: url is not valid=", externalUrl);
		}
	}

    public redirectToLiteApp(){
		let externalUrl:string = this.sharedService.getHost() + VIEW_LITE_APP_URL;
		if (externalUrl) {
			window.open(externalUrl);
		} else {
			this.logger.error(this.tag, "redirectToLiteApp: url is not valid=", externalUrl);
		}
	}
}
