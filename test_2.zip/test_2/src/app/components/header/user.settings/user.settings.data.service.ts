import { map,catchError } from 'rxjs/operators';
/**
 * Created by nikita.dewangan on 05-06-2017.
 */
 declare var require: any;
import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {UserSettingsHttpService} from "./user-settings.http.service";
import {ENCRYPTION_SALT} from "../../../constant/app.constants";

let CryptoJS = require('crypto-js');

@Injectable()
export class UserSettingsDataService {

    constructor(private userSettingsHttpService: UserSettingsHttpService){}

    /* method to get userdata from server */
    public getUserData(): Observable<any> {
        return this.userSettingsHttpService.getUserData().pipe(
            map(
                (data) => {
                    return data;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

    /* method to get auth token from server */
    public getAuthToken(): Observable<any>{
        return this.userSettingsHttpService.getAuthData().pipe(
            map(
                (data) => {
                    return data;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

    /* method to get user profile from server*/
    public updateUserProfile(data: any): Observable<any>{
        return this.userSettingsHttpService.postUpdateUserProfile(data).pipe(
            map(
                (data) => {
                    return true;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

    /* method to change password at server */
    public changePassword(data: any): Observable<any>{
        return this.userSettingsHttpService.postChangePassword(data).pipe(
            map(
                (data) => {
                    return true;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

    /* method to send test sms to server*/
    public sendTestSMS(data: any): Observable<any>{
        return this.userSettingsHttpService.postTestSms(data).pipe(
            map(
                (data) => {
                    return true;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

    /* method to send test email to server */
    public sendTestEmail(data: any): Observable<any>{
        return this.userSettingsHttpService.postTestMail(data).pipe(
            map(
                (data) => {
                    return true;
                },
                (error) => {
                    return error;
                }
            )
        )
    }

}
