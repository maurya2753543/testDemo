/**
 * Created by Mehjabeen.Bari on 6/16/2017.
 */

import { Injectable } from '@angular/core';
import {SharedService} from "../../../shared/shared.service";
import {PATHTRAK_PATH} from "../../../constant/app.constants";

@Injectable()
export class UserSettingsUrlService {

    private host:string = "";

    constructor(private sharedService: SharedService) {
    }

    private getHost():string{
        return this.sharedService.getHost() + PATHTRAK_PATH;
    }
    
    /* Return url to get node list from server*/
    public getTestSmsUrl():string {
        return this.getHost() + "user/test/sms";
    }

    /* Return url to get modem list from server*/
    public getTestMailUrl():string {
        return this.getHost() + "user/test/email";
    }

    /* Return url to get node list from server*/
    public getChangePasswordUrl():string {
        return this.getHost() + "user/changepassword";
    }

    /* Return url to get modem list from server*/
    public getUpdateUserProfileUrl():string {
        return this.getHost()  + "user/profile";
    }

    public getAuthDataUrl():string {
        return this.getHost() + "auth";
    }

    /* Return url to get modem list from server*/
    public getUserDataUrl():string {
        return this.getHost() + "user/profile";
    }
}