/**
 * Created by nikita.dewangan on 05-06-2017.
 */

import {Component, OnInit} from '@angular/core';
import {SharedService} from "../../../shared/shared.service";
import {UserSettingsDataService} from "./user.settings.data.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {Logger} from "../../../utilities/logger";
import {EncryptDecryptUtils} from "../../../utilities/encryption-decryption.utils";
import {ControlMessagesService} from "../../../shared/control.messages.service";

@Component({
    selector: 'user-settings-component',
    templateUrl: 'user.settings.component.html'
})

export class UserSettingComponent implements OnInit {

    private tag:string = "UserSettingComponent";
    private position: string = 'right';
    private showBackdrop: boolean = true;
    private animate: boolean = false;
    private closeOnClickOutside: boolean = true;
    public editForm: boolean = false;
    public passwordForm: boolean = false;
    private userData: Object = {};
    public updateUserData: Object = {};
    public profileErrorMessage: string = '';
    public profileSuccessMessage: string = '';
    public passwordData: Object = {
        existingPassword: '',
        newPassword: '',
        confirmPassword: '',
    };
    public passwordErrorMessage: string = '';
    public passwordSuccessMessage: string = '';
    public disableSendTestEmailFlag: boolean ;
    public disableSendTestSMSFlag: boolean ;
    private userSettings: boolean = true;
    private auth:any;
    private localization:any;
    public isCloseRightSlider:boolean = false;

    private PROFILE_SUCCESS:string;
    private SMS_SEND_SUCCESS:string;
    private MAIL_SEND_SUCCESS:string ;
    private PASSWORD_SUCCESS:string ;
    private PASSWORD_DONT_MATCH:string;

    constructor(private controlMessagesService:ControlMessagesService, private showAlert: ShowAlert,
        private logger: Logger, private sharedService: SharedService , private userSettingsDataService: UserSettingsDataService,
        private localeDataService: LocaleDataService) {}

    ngOnInit() {
        this.localization = this.localeDataService.getLocalizationService();
        this.translateLocaleString();
        if(navigator.userAgent.search("Firefox") > -1){
            this.animate = false;
        }else{
            this.animate = true;
        }

        this.getUserData();
    }


    /* Method to Handle User data */
    private getUserData(): void{
        this.userSettingsDataService.getUserData().subscribe(this.getUserDataonNext.bind(this), this.onError.bind(this));
    }

    /* Method to Handle User data */
    private getUserDataonNext(data:any): void{
        this.logger.debug(this.tag, "getUserDataonNext=", data);
        let apiData:any = data;
        this.userData = {
            name: EncryptDecryptUtils.getDecrytedValue(apiData.fullName).trim(),
            email: EncryptDecryptUtils.getDecrytedValue(apiData.email).trim(),
            sms: EncryptDecryptUtils.getDecrytedValue(apiData.sms).trim()
        }
        this.reflectEditFormInitialLoadChanges();
        this.createNewObjectForUpdation();
    }

    /* Method to validate userdata input & set button status */
    private reflectEditFormInitialLoadChanges(): void{
        if(  this.userData['sms'] == '' ){
            this.disableSendTestSMSFlag = true;
        }else{ this.disableSendTestSMSFlag = false;}

        if( this.userData['email'] == ''){
            this.disableSendTestEmailFlag = true;
        }else{ this.disableSendTestEmailFlag = false;}
    }

    /*Form to validate Edit Form changes*/
    public reflectEditFormChanges(): void{

        let allSpaceRegexCheck = /^\s+$/;

        if(  this.updateUserData['sms'] == '' || this.updateUserData['sms'].match(allSpaceRegexCheck) ){
            this.disableSendTestSMSFlag = true;
        }else{
            this.disableSendTestSMSFlag = false;
        }

        if(this.updateUserData['email'] == '' || this.updateUserData['email'].match(allSpaceRegexCheck) ){
            this.disableSendTestEmailFlag = true;
        }else{
            this.disableSendTestEmailFlag = false;
        }
    }

    private createNewObjectForUpdation(): void {
        this.updateUserData = JSON.parse(JSON.stringify(this.userData));
    }

    /*This method will be called form UI to show/hide Edit Form*/
    public showEditForm(): void{
        this.logger.debug(this.tag, "showEditForm");
        this.editForm = !this.editForm;
        this.reflectEditFormChanges();
    }

    /*Method called form UI to show/hide Password form on button click*/
    public showPasswordForm(): void{
        this.logger.debug(this.tag, "showPasswordForm");
        this.passwordData = {
            existingPassword: '',
            newPassword: '',
            confirmPassword: '',
        };
        this.passwordForm = !this.passwordForm;
        // this.passwordErrorMessage = '';
    }

    /* This method is called form UI to close user settings slider*/
    public onClosed(): void{
        this.logger.debug(this.tag, "onClosed");
        this.userSettings = false;
        this.passwordForm = false;
        this.editForm = false;
        this.isCloseRightSlider = true;
    }

    /* Method to call on submitting Profile*/
    public onProfileSubmit(value): void {
        this.profileSuccessMessage = '';
        this.profileErrorMessage = '';
        this.logger.debug(this.tag, "onProfileSubmit:",value);
        let encryptedUserData: any = {
            fullName: EncryptDecryptUtils.getEncryptedValue(value.name),
            email: EncryptDecryptUtils.getEncryptedValue(value.email),
            sms: EncryptDecryptUtils.getEncryptedValue(value.sms)
        }
        this.userSettingsDataService.updateUserProfile(encryptedUserData).subscribe(this.updateUserProfileOnNext.bind(this), this.onError.bind(this));
    }

    /*Method called on successful submission of profile*/
    private updateUserProfileOnNext(data): void {
        this.logger.debug(this.tag, "updateUserProfileOnNext:",data);
        this.getUserData();
        this.showEditForm();
        this.profileSuccessMessage = this.PROFILE_SUCCESS;
        // this.showSuccessAlert(PROFILE_SUCCESS);
    }

    /* Method called on change password form submit method clicked*/
     onPasswordChangeSubmit(value): void {
        this.logger.debug(this.tag, "onPasswordChangeSubmit:", value);
        this.passwordSuccessMessage = '';
        this.passwordErrorMessage = '';
        let encryptedPasswordData:any = {
            newPassword: EncryptDecryptUtils.getEncryptedValue(value.newPassword),
            oldPassword: EncryptDecryptUtils.getEncryptedValue(value.existingPassword)
        }

        if(value.newPassword != value.confirmPassword){
            this.passwordErrorMessage = this.PASSWORD_DONT_MATCH;
        }else{
            this.userSettingsDataService.changePassword(encryptedPasswordData).subscribe(this.changePasswordOnNext.bind(this), this.onChangePwdError.bind(this));
        }
    }

    onChangePwdError(error){
        let errorResponse = this.showAlert.getErrorCode(error);
        let errorMessage:string = this.controlMessagesService.getMsg(errorResponse);
        this.passwordErrorMessage = errorMessage;
        this.logger.error("onChangePwdError():  passwordErrorMessage=", this.passwordErrorMessage);
    }

    /*Method called on successful password change*/
    private changePasswordOnNext(): void{
        this.logger.debug(this.tag, "onPasswordChangeSubmit:");
        this.passwordData = {};
        this.showPasswordForm();
        this.passwordSuccessMessage = this.PASSWORD_SUCCESS;
        // this.showSuccessAlert(this.PASSWORD_SUCCESS);
    }

    /*Method called on clicking send test email*/
    public sendTestEmail(value): void{
        this.profileSuccessMessage = '';
        this.profileErrorMessage = '';
        this.logger.debug(this.tag, "sendTestEmail:");
        let encryptedData = {
            address: EncryptDecryptUtils.getEncryptedValue(value.email)
        }
        this.userSettingsDataService.sendTestEmail(encryptedData).subscribe(this.sendMailOnNext.bind(this), this.onError.bind(this));
    }

    /*Method called on sucessfule email sent*/
    private sendMailOnNext(data): void{
        this.logger.debug(this.tag, "sendMailOnNext:", data);
        this.profileSuccessMessage = this.MAIL_SEND_SUCCESS;
    }

    /* Method called from UI on click to send test sms */
    public sendTestSMS(value): void {
        this.profileSuccessMessage = '';
        this.profileErrorMessage = '';
        this.logger.debug(this.tag, "sendTestSMS:");
        let encryptedData:any = {
            address: EncryptDecryptUtils.getEncryptedValue(value.sms)
        }
        this.userSettingsDataService.sendTestSMS(encryptedData).subscribe(this.sendSmsOnNext.bind(this), this.onError.bind(this));
    }

    /*Method to call on successful sms sent*/
    private sendSmsOnNext(data): void{
        this.logger.debug(this.tag, "sendSmsOnNext:",data);
        this.profileSuccessMessage = this.SMS_SEND_SUCCESS;
    }

    /*Method for error handling and displaying sweet alert*/
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        let errorResponse = this.showAlert.getErrorCode(error);
        let errorMessage:string = this.controlMessagesService.getMsg(errorResponse);
        this.profileErrorMessage = errorMessage;
    }

    /*Method for error handling and displaying sweet alert*/
    private showSuccessAlert(message): void {
        this.logger.debug("showSuccessAlert():  message=", message);
        let translatedMessage:string = this.localization.instant(message);
        this.showAlert.showSuccessAlert(translatedMessage);
    }

    //Translation
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.PROFILE_SUCCESS = localizationService.instant('PROFILE_SUCCESS');
        this.SMS_SEND_SUCCESS = localizationService.instant('SMS_SEND_SUCCESS');
        this.MAIL_SEND_SUCCESS = localizationService.instant('MAIL_SEND_SUCCESS');
        this.PASSWORD_SUCCESS = localizationService.instant('PASSWORD_SUCCESS');
        this.PASSWORD_DONT_MATCH = localizationService.instant('PASSWORD_DONT_MATCH');
    }


    private formfields: Array<any> = new Array();
    private cpassword: any = {
      name: 'cpassword',
      value: '',
      isValid: true
    };

    /* Method to restrict input characaters as per the limit */
   private restrictInputCharacters(fieldIndex: number, limit: number): void{
        let value: string = fieldIndex && this.formfields[fieldIndex] != null ? this.formfields[fieldIndex].value : this.cpassword.value;
        let length: number = value ? value.length : 0;
        if(length > limit){
            if(fieldIndex){
            this.formfields[fieldIndex].value = value.substring(0, limit);
            }
            else{
            this.cpassword.value = value.substring(0, limit);
            }   
        }
    }

}