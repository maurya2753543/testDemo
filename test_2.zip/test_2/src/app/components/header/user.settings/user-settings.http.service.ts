/**
 * Created by Mehjabeen.Bari on 6/8/2017.
 */

/*User Settings Common http service to call http request from Generic HTTP service*/

import {Injectable} from "@angular/core";
import {HttpService} from "../../../shared/http.service";
import {UserSettingsUrlService} from "./user-settings.url.service";
import {Observable} from "rxjs";

@Injectable()
export class UserSettingsHttpService{

    constructor(private httpService: HttpService, private userSettingsUrlService: UserSettingsUrlService){}

    public postTestSms(data: any) : Observable<any> {
        return this.httpService.POST(this.userSettingsUrlService.getTestSmsUrl(), data);
    }

    public postTestMail(data: any): Observable<any>  {
        return this.httpService.POST(this.userSettingsUrlService.getTestMailUrl(), data);
    }

    public postChangePassword(data: any): Observable<any>  {
        return this.httpService.POST(this.userSettingsUrlService.getChangePasswordUrl(),data);
    }

    public postUpdateUserProfile(data:Object): Observable<any> {
        return this.httpService.POST(this.userSettingsUrlService.getUpdateUserProfileUrl(), data);
    }

    public getAuthData(): Observable<any> {
        return this.httpService.GETTEXT(this.userSettingsUrlService.getAuthDataUrl());
    }
    
    public getUserData(): Observable<any> {
        return this.httpService.GET(this.userSettingsUrlService.getUserDataUrl());
    }

}
