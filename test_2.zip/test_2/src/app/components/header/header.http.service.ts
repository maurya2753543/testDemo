/**
 * Created by narayan.reddy on 23-06-2017.
 */

import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/http.service";
import {HeaderUrlService} from "./header.url.service";
import {Observable} from "rxjs";
import { map } from "rxjs/operators";
import { environment } from "src/environments/environment";
import { HttpHeaders } from "@angular/common/http";


@Injectable() export class HeaderHttpService {
    private enviorn = environment.production;
    private headers = new HttpHeaders({});

    constructor(private httpService: HttpService, private headerUrlService: HeaderUrlService){
        if(this.enviorn){
            this.headers = new HttpHeaders({'Content-Security-Policy': " frame-ancestors 'self';" });
        } 
    }

    public getLogoutCall(){
        let url:string = this.headerUrlService.getLogoutUrl()
        let date =  Math.round(Date.now()/1000|0);
        return this.httpService.GET(url+"?dt="+date,{headers:this.headers, withCredentials: true}).pipe(map(
            (data) => {
                return true;
            },
            (error) =>{
                return error;
            }
        ));
    }

}
