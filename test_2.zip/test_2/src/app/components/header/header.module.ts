/**
 * Created by nikita.dewangan on 05-06-2017.
 */

import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
//import { SharedModule } from './../shared/shared.module';
import { FormsModule, ReactiveFormsModule  } from "@angular/forms";

import { TranslateService, TranslateModule } from '@ngx-translate/core';
import {HeaderComponent} from "./header.component";
import {LocaleDataService} from "../../shared/locale.data.service";
import {UserSettingComponent} from "./user.settings/user.settings.component";
import { SidebarModule } from 'ng-sidebar';
import {UserSettingsHttpService} from "./user.settings/user-settings.http.service";
import {UserSettingsDataService} from "./user.settings/user.settings.data.service";
import {UserSettingsUrlService} from "./user.settings/user-settings.url.service";
import {HeaderHttpService} from "./header.http.service";
import {HeaderUrlService} from "./header.url.service";
import {SharedModule} from "../../modules/shared/shared.module";

@NgModule({
    imports: [
        CommonModule,
        SidebarModule.forRoot(),
        ReactiveFormsModule,
        BrowserModule,
        FormsModule,
        SharedModule,
        TranslateModule.forChild()
    ],
    declarations: [HeaderComponent, UserSettingComponent],
    entryComponents: [UserSettingComponent],
    providers: [
        LocaleDataService,
        UserSettingsHttpService,
        UserSettingsUrlService,
        UserSettingsDataService,
        HeaderHttpService,
        HeaderUrlService,
        TranslateService
    ],
    exports: [HeaderComponent]
})
export class HeaderModule {
    constructor(private localedataservice:LocaleDataService,private userSettingsHttpService:UserSettingsHttpService,private usersettingsurl:UserSettingsUrlService,private x:UserSettingsDataService,private y:HeaderHttpService,private z:HeaderUrlService){
       // super();
    }
}
