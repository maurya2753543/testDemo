import { environment } from './../../../environments/environment';
declare var process: { env: { [key: string]: string; } };
import {Component} from '@angular/core';
import { NavService } from '../../shared/nav.service';
import {SharedService} from "../../shared/shared.service";
import {AuthService} from "../../shared/auth.service";
import {NAV_LINK_HOME, NAV_LINK_HCU, NAV_LINK_CMTS,NAV_LINK_OLT, NAV_LINK_ALARMS, NAV_LINK_ENTERPRISE,
    NAV_LINK_SETTING, NAV_LINK_INFO, NAV_LINK_USERS, NAV_LINK_SITES, NAV_LINK_CONTAINER,
    NAV_LINK_RCI, NAV_LINK_OTU, NAV_LINK_ADMIN_PON} from "../../constant/app.constants";

@Component({
    selector: 'leftNav-Component',
    templateUrl: 'leftNav.component.html',
})

export class LeftNavComponent {
    
     selectedMenuItemIndex:number = 0;
    public loadNav: boolean = false;
    NAV_LINK_HOME: string = NAV_LINK_HOME;
    NAV_LINK_HCU: string = NAV_LINK_HCU;
    NAV_LINK_CMTS: string = NAV_LINK_CMTS;

    NAV_LINK_RCI: string = NAV_LINK_RCI;
    NAV_LINK_OLT: string = NAV_LINK_OLT;
    NAV_LINK_OTU: string = NAV_LINK_OTU;
    NAV_LINK_ALARMS: string = NAV_LINK_ALARMS;
     NAV_LINK_ENTERPRISE: string = NAV_LINK_ENTERPRISE;
     NAV_LINK_SITES: string = NAV_LINK_SITES;
     NAV_LINK_SETTING: string = NAV_LINK_SETTING;
    NAV_LINK_INFO: string = NAV_LINK_INFO;
     NAV_LINK_USERS: string = NAV_LINK_USERS;
    NAV_LINK_CONTAINER: string = NAV_LINK_CONTAINER;
    NAV_LINK_ADMIN_PON: string = NAV_LINK_ADMIN_PON;

    constructor( public navService: NavService, private sharedService:SharedService, private authService: AuthService){
        this.authService.permissionsCallback.subscribe((data) => {
            this.loadNav = true;
        });

        if(environment.production){
            this.authService.getPermissionsData();
        }
    }

    ngOnInit(){

    }

    //function :: selects clicked nav item.
    public setActiveNav(index :  number): void {
        if(this.sharedService.isMobileDevice()) {
            this.navService.closeNav();
        }
        this.selectedMenuItemIndex = index;
        if(index == 2 ){
            this.sharedService.checkWhichView = false;
           }
           if(index ==3 || index ==12 || index == 13|| index ==5 || index ==11 || index ==2 ){
            this.sharedService.RetainFilter = true;
           }
    }
    
     checkPermission(linkName: string){
        return this.sharedService.checkPermissions(linkName);
    }
}


















