/*
 * Copyright (c) 2023 Viavi Solutions Inc. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions is strictly prohibited.
 */

import {environment} from './../environments/environment';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import {TranslateService} from '@ngx-translate/core';
import {LocaleDataService} from "./shared/locale.data.service";
import {LanguageService} from "./shared/locale.language.service";
import {HostService} from "./shared/host.service";
import {AuthService} from "./shared/auth.service";
import {UserSettingsDataService} from "./components/header/user.settings/user.settings.data.service";
import {ShowAlert} from "./utilities/showAlert";
import {EncryptDecryptUtils} from "./utilities/encryption-decryption.utils";
import {SharedService} from "./shared/shared.service";
import {TimeFilter} from "./shared/time.filter";
import {CommonStringsService} from "./shared/commonStringsService";
import {NavService} from "./shared/nav.service";
import {Observable} from "rxjs";
import * as AppConstants from './constant/app.constants';
// Branch [B]
declare var require: any;
declare var process: { env: { [key: string]: string; } };

@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    })

export class AppComponent implements OnInit {
    public loadComponent: boolean = false;

    constructor(private hostService: HostService,
        private localeDataService: LocaleDataService,

        private navService: NavService,
        private authService: AuthService,
        private userSettingsDataService: UserSettingsDataService,
        private showAlert: ShowAlert,
        private sharedService: SharedService,
        private router: Router,
        private commonStringsService: CommonStringsService,
        private languageService: LanguageService,
        private translate: TranslateService) {
            this.translate.addLangs(AppConstants.LANGUAGE_LIST_SHORT);
            const langs = AppConstants.LANGUAGE_LIST_SHORT;
            const currLang = this.translate.getBrowserLang();
            const isLang = langs && langs.find(lang => lang === currLang);
            this.translate.setDefaultLang((isLang) ? isLang : 'en');
            this.translate.use((isLang) ? isLang : 'en');
    }

    ngOnInit() {

        this.siteIsReady.subscribe((isReady: boolean) => {
            if (isReady) {

                this.sharedService.setHeaderTemplate();

                if (!environment.production) {
                    this.authService.getAuthToken();
                }
                
                this.getAuthToken();

              //  this.authService.getAuthToken();
                document.title = this.translate.instant('TITLE_BAR_ADMIN_APP');
                this.authService.permissionsCallback.subscribe((response) => {
                    this.checkUrlPermission();
                });
            }
        });

        this.localeDataService.componentCallback.subscribe((response) => {
            this.loadComponent = true;

            TimeFilter.setLocalDataService(this.languageService);
            TimeFilter.setDateTimeService(this.sharedService);

            /*translate all the CommonStrings in one file*/
            this.commonStringsService.translateCommonStrings();

            document.title = this.translate.instant('TITLE_BAR_ADMIN_APP');
        });
        
        this.localeDataService.initLanguage();
        // its being initalized from the locale data service
        // this.languageService.initBrowserLanguag();
        //setTimeout(function(){

        //}, 2000)


    }

    public applicationClickOutsideNav() {
        let navState = this.navService.isNavOpenValue();
        if (navState == true) {
            this.navService.closeNav();
        }

    }

    /* Method to Get User data */
    private getAuthToken(): void {
        this.userSettingsDataService.getAuthToken().subscribe(this.getAuthOnNext.bind(this),this.onError.bind(this));
    }

    private getLanguage(): void {
        this.localeDataService.initLanguage();
    }

    /* Method to Handle User data */
    private getAuthOnNext(_authData: any): void {
        EncryptDecryptUtils.setApiAuthToken(_authData);
    }

    /*Method for error handling and displaying sweet alert*/
    private onError(error): void {
        this.showAlert.showErrorAlert(error);
    }

    private checkUrlPermission() {
        let urlPath: any = this.sharedService.getUrlDataPath();
        if (urlPath.status) {
            this.sharedService.setUrlDataPath({ urlPath: '', checkPath: '', status: false });
            if (this.sharedService.checkPermissions(urlPath.checkPath)) {
                this.router.navigate(['/' + urlPath.urlPath]);
            }
        }
    }

    public siteIsReady: Observable<boolean> = this.localeDataService.isReady;
}
