// Application Constants

/**
 * Created by Narayan.reddy on 04/28/2017.
 */

export const version: string = "0.2.2";
// 10/26/2020 - Server IP Addresses changed.
//"http://gerxpt-20.ds.jdsu.net"
export const DEFAULT_HOST: string = "http://50.195.211.29:8002" ; //"http://localhost"; // "http://173.165.99.68"; //"http://173.165.99.66"; //'http://10.11.20.69';//"http://173.165.99.68";//"http://10.211.55.6" //"http://173.165.99.70:8081";
export const PATHTRAK_PATH: string = "/pathtrak/api/";
export const PATHTRAK_SETTINGS_PATH: string = "/pathtrak/api/settings/";
export const PATHTRAK_PATH_LOCAL: string = "/pathtrak/api-test/";
export const PATHTRAK_ENTERPRISE_PATH = "/pathtrak/api/enterprise/";
export const PATHTRAK_CONTAINER_PATH = "/pathtrak/api/container";

export const LICENSE_PATH = "license";
export const DIAGNOSTIC_PATH = "diagnostic";
export const TRIGGER_PATH = "trigger";

export const ENCRYPTION_SALT: string = "9547bc25d943aec9";

export const CONFIRM_BUTTON_COLOR: string = "#8cd4f5";
export const CANCEL_BUTTON_COLOR: string = "#c1c1c1";

export const localhost: string = "http://localhost:8080";
export const DEFAULT_PRODUCTION: string = "//";
export const LOGOUT_NAV_URL: string = "/pathtrak";
export const ADMINISTRATION_LINK_URL: string = "/pathtrak";
export const ENTERPRISE_LINK_URL: string = "/pathtrak/enterprise";
export const BASIC_INFO_SITE_URL: string =
  "http://www.viavisolutions.com/en-us/product-family/pathtrak";
export const BASIC_INFO_LICENSE_URL: string =
  DEFAULT_HOST + "/pathtrak/PathTrakClient/lgpl-3.0.txt";
export const IS_DEBUG: boolean = true;
export const IS_PRODUCTION: boolean = false;
export const COLON_SYMBOL: string = ":";
export const URL_SEPARATOR: string = "/";

export const VIEW_HOME_URL: string = "/pathtrak";
export const VIEW_LITE_APP_URL: string = "/pathtrak/lite";

export const LANGUAGE_LIST_SHORT: Array<string> = [
  "en",
  "es",
  "de",
  "fr",
  "ja",
  "ko",
  "zh",
  "pt"
];
export const COUNTRY_LIST_SHORT: Array<string> = [
  "US",
  "ES",
  "DE",
  "FR",
  "JA",
  "KO",
  "ZH",
  "BR"
];

export const SUB_FORM_LANGUAGE_LIST_SHORT: Array<string> = [
  "zh-CN",
  "zh-TW",
  "zh-Hant-TW",
  "zh-Hans-CN",
];
export const SUB_FORM_COUNTRY_LIST_SHORT: Array<string> = [
  "ZH",
  "ZH",
  "ZH",
  "ZH",
];

export const LANGUAGE_SET_EVENT: string = "LanguageSet";

export const ALERT_INFO: string = "info";
export const ALERT_ERROR: string = "error";
export const ALERT_SUCCESS: string = "success";
export const ALERT_WARNING: string = "warning";
export const ALERT_QUESTION: string = "question";
export const SUCCESS: string = "Success";
// export const ALERT_TITLE: string = 'Error';
// export const ALERT_SUCCESS_TITLE: string = 'Success';
export const ALERT_INFO_TITLE: string = "Info";
// export const ALERT_CONFIRMATION_TITLE: string = 'Confirmation';

export const LIST_ACTION: string = "list";
export const PURGE_LIST_ACTION: string = "purge";
export const DELETE_LOG_FILE_ACTION: string = "delete";

export const ALERT_GEOCODE_TEXT: string = "Do you want to save File to Disk?";
export const ALARM_GOOD_PERCENTAGE_COLOR: string = "#88dd73"; //#88dd73
export const ALARM_MINOR_PERCENTAGE_COLOR: string = "#fdff6b"; //#fdff6b
export const ALARM_MAJOR_PERCENTAGE_COLOR: string = "#ffba00"; //#ffcc00
export const ALARM_CRITICAL_PERCENTAGE_COLOR: string = "#fe504f";
export const ALARM_WARNING_PERCENTAGE_COLOR: string = "#00c1c1"; //#01ffff
export const TOTAL_COUNT: string = "blue";
export const NO_DATA_AVAILABLE_COLOR: string = "#B0B0B0";

export const COLOR_BLACK: string = "#000000";
export const COLOR_WHITE: string = "white"; //#eae5e5

//WIDTH FOR SCREEN
export const SCREEN_SIZE_12INCHS: number = 1152;
export const NODE_FACTOR: number = 50000;
export const RANKING_BORDER_BOTTOM: string = "1px solid rgba(0, 0, 0, 0.15)";
export const ALARM_DROPDOWN_OPTION_ACTION: string = "action";
export const ALARM_DROPDOWN_OPTION_CLEAR: string = "clear";
export const ALARM_DROPDOWN_OPTION_EXPORT: string = "export";
export const ALARMS_LIMIT: number = 250;
export const RESIZE_MINIMIZE_MODE: string = "minimize";
export const RESIZE_MAXIMIZE_MODE: string = "maximize";
export const ALARM_LIST_COMPONENT: string = "alarmList";
export const INTERVAL: number = 30000;
export const REFRESH_ALARM_INTERVAL: number = 15000;
export const INTERVAL_REFRESH = 300000;

export const PERFORMANCE_MARGIN_THRESHOLD_VALUE: string =
  "MACTrak Marginal Alarm";
export const PERFORMANCE_FAILED_THRESHOLD_VALUE: string =
  "MACTrak Failed Alarm";
export const MEASUREMENT_OVERRANGE_VALUE: string = "Measurement Over-range";

export const TFTP_PROXY_URL = "TFTP_PROXY_URL";
export const SERVER_NOTIFICATION_PROXY_URL = "NOTIFICATION_PROXY_URL";
export const SERVER_DEFAULT_LOCALE = "DEFAULT_LOCALE";

export const PERFORMANCE_MARGIN_THRESHOLD_API_KEY: string =
  "PORT_MT_PERFORMANCE_MARGIN_THRESHOLD";
export const PERFORMANCE_FAILED_THRESHOLD_API_KEY: string =
  "PORT_MT_PERFORMANCE_FAILED_THRESHOLD";
export const MEASUREMENT_OVERRANGE_API_KEY: string =
  "PORT_MEASUREMENT_OVERRANGE";
export const THRESHOLD_INTERVAL_VIOL_KEY_1: string =
  "PORT_THRESHOLD_INTERVAL_VIOL";
export const THRESHOLD_INTERVAL_VIOL_KEY_2: string =
  "PORT_THRESHOLD_INTERVAL_VIOLATION";

export const THRESHOLD_INTERVAL_LABEL: string = "INTERVAL THRESHOLD";
export const THRESHOLD_1_LABEL: string = "Threshold 1";
export const THRESHOLD_2_LABEL: string = "Threshold 2";
export const THRESHOLD_3_LABEL: string = "Threshold 3";
export const THRESHOLD_4_LABEL: string = "Threshold 4";
export const THRESHOLD_INTERVAL_VAL: string = "Interval Threshold";

export const RANKING_LIST_COMPONENT: string = "rankingList";

export const EDIT_ICON: string =
  '<i class="fa fa-edit" aria-hidden="true"></i>';
  export const DOWNLOAD_ICON: string =
  '<i class="fa fa-download" aria-hidden="true"></i>';
export const USER_ICON: string =
  '<i class="fa fa-user userIconEdit" #userIcon aria-hidden="true"></i>';
export const GROUP_ICON: string =
  '<i class="fa fa-users" aria-hidden="true"></i>';
export const EXTERNAL_LINK_ICON =
  '<i class="fa fa-external-link-alt" aria-hidden="true"></i>';
export const SITE_ICON: string =
  '<i class="fa fa-university" #siteIcon aria-hidden="true"></i>';

export const SS_MEASUREMENT_SECTION: string = "Measurement";
export const SS_THRESHOLD_SECTION: string = "Thresholds";
export const SS_PORTFIELD_SECTION: string = "PortField";
export const SS_MODEM_CUSTOM_FIELDS: string = "modemCustomFields";
export const SS_FIRMWARE_SECTION: string = "Firmware";
export const SS_NOISE_TRAK_FIELDS: string = "noiseTrakFields";
export const SS_NODE_BROADCAST_SECTION: string = "NodeBroadcast";
export const SS_NODE_RCI_SWEEP: string = "RciSweep";
export const SS_SERVER_SECTION: string = "Proxy";
export const SS_CMTS_SECTION: string = "Cmts";
export const SS_MODEM_SECTION: string = "Modem";
export const SS_EVENT_PURGE: string = "EventPurge";
export const SS_SNMP_LISTNER: string = "SnmpListner";
export const SS_MAIL_SERVER: string = "MailServer";
export const SS_NODERANKING_SECTION: string = "NodeRanking";
export const SS_PERFORMANCE_DATA_SECTION: string = "PerformanceData";
export const SS_ALARM_THRESHOLDS_SECTION = "AlarmThresholds";
export const SS_MACTRAK_PERFORMANCE_SECTION: string = "MactrakPerformance";
export const SS_SPECTRUM_ANALYZER_SECTION: string = "SpectrumAnalyzer";
export const SS_QAMTRAK_ANALYZER_SECTION: string = "QamtrakAnalyzer";
export const SS_MONITORING_PLAN_SECTION: string = "MonitoringPlan";
export const SS_PRE_EQ_SECTION: string = "PreEq";
export const SS_DOWNSTREAM_SECTION: string = "Downstream";
export const SS_UPSTREAM_SECTION: string = "Upstream";
export const SS_UTILIZATION_SECTION: string = "Capacity/Utilization";
export const SS_LANGUAGE_SECTION: string = "Language";
export const SS_DOCSIS_3_1_SECTION: string = "DOCSIS 3.1";
export const SS_QOE_THRESHOLD: string = "qoethresholds";
export const SS_QOE: string = "qoe";
export const SS_NODE_HEALTH: string = "Node Health";
export const SS_RANK_INDEX: string = "rankindex";
export const SS_QOEWF: string = "qoewf";
export const SS_NODE_RANK_QOE: string = "noderankqoe";
export const SS_MAPOVERLAY: string = "Mapoverlay";
export const EXPORT_TIME_FORMAT: string = "YYYY-MM-DD HH:mm";
export const SS_RCI_SECTION = "RCI";
export const SS_OTU_SECTION = "OTU";
export const SS_MODEM_VIP_CUSTOMER_SECTION = "modemVipCustomer";
export const SS_MODEM_VIP_CUSTOMER_FIELDS = "modemVipCustomerFields";

export const MAX_STRING_LIMIT: number = 100;
export const TPC_MIN: number = -99;
export const TPC_MAX: number = 99;
export const ATTENUATION_MAX: number = 50;
export const ATTENUATION_MIN: number = 0;

export const MACKTRACK_LABELS_ARRAY: Object = {
  QP_UCWER_QF: "SS_UNCORRECTABLE_CODEWORD_ERROR",
  QP_CWER_QF: "SS_CORRECTABLE_CODEWORD_ERROR",
  QP_MER_QF: "SS_MER",
  QP_UNEQ_MER_QF: "SS_UNEQ_MER",
  QP_DELTA_LEVEL_QF: "SS_CL_DATA",
  QP_IMPULSE_QF: "SS_IN",
};
export const MACKTRACK_QP_UCWER_QF = "QP_UCWER_QF";
export const MACKTRACK_QP_CWER_QF = "QP_CWER_QF";
export const MACKTRACK_QP_UNEQ_MER_QF = "QP_UNEQ_MER_QF";
export const MACKTRACK_QP_DELTA_LEVEL_QF = "QP_DELTA_LEVEL_QF";
export const MACKTRACK_QP_IMPULSE_QF = "QP_IMPULSE_QF";
export const MACKTRACK_QP_MER_QF = "QP_MER_QF";

export const NO_FAILED_MODEMS: string = "No Failed Modems";

export const SS_QAM_INBAND: string = "Inband";
export const SS_QAM_GROUP_DELAY: string = "Group Delay";

export const NAV_LINK_HOME: string = "Home";
export const NAV_LINK_HCU: string = "ADMINISTER_PATHTRAK_HCUS";
export const NAV_LINK_CMTS: string = "ADMINISTER_PATHTRAK_CMTS";
export const NAV_LINK_OLT: string = "ADMINISTER_PATHTRAK_OLT";
export const NAV_LINK_ALARMS: string = "Alarms";
export const NAV_LINK_ENTERPRISE: string = "ADMINISTER_SYSTEM_PREFERENCES";
export const NAV_LINK_SETTING: string = "ADMINISTER_SYSTEM_PREFERENCES";
export const NAV_LINK_INFO: string = "Info";
export const NAV_LINK_USERS: string = "ADMINISTER_USERS_AND_GROUPS";
export const NAV_LINK_SITES: string = "ADMINISTER_PATHTRAK_SITES";
export const NAV_LINK_CONTAINER: string = "ADMINISTER_USER_DEFINED_CONTAINERS";
export const NAV_LINK_RCI: string = "ADMINISTER_RCI";
export const NAV_LINK_OTU: string = "ADMINISTER_OTU";
export const NAV_LINK_ADMIN_PON: string = "ADMIN_PON";
export const NAV_LINK_ALARMABLE_MODEMS: string = "ADMINISTER_ALARMABLE_MODEMS";
export const PERM_CLEAR_ALARM: string = "CLEAR_ALARMS";
export const PERM_REBOOT_HCU: string = "REBOOT_HCU";
export const PERM_ADMINISTER_PATHTRAK_PORTS: string =
  "ADMINISTER_PATHTRAK_PORTS";
export const PERM_LAUNCH_MONITORING_VIEW: string = "LAUNCH_MONITORING_VIEW";
export const PERM_LAUNCH_SPECTRUM_ANALYZER: string = "LAUNCH_SPECTRUM_ANALYZER";
export const PERM_LAUNCH_QAMTRAK_ANALYZER: string = "LAUNCH_QAMTRAK_ANALYZER";
export const PERM_LAUNCH_HEATMAP: string = "LAUNCH_HEATMAP";
export const PERM_ADMINISTER_FIELD_VIEW_BROADCAST: string =
  "ADMINISTER_FIELD_VIEW_BROADCAST";
export const PERM_ADMINISTER_PATHTRAK_SERVERS: string =
  "ADMINISTER_PATHTRAK_SERVERS";
export const PERM_SYNC_CMTS_IN_LITE_VIEW: string = "SYNC_CMTS_IN_LITE_VIEW";

export const Hz_To_MHz_CONCERSION_CONSTANT: number = 1000000;
export const DBMV: string = "dbmv";
export const DBMV_REQ: string = "dBmV";
export const DBUV: string = "dbuv";
export const DBUV_REQ: string = "dBμV";

export const SPECTRUM_PATH: string =
  "/pathtrak/live/index.html#/app/spectrum?hcu=";
export const QAMTRAK_PATH: string =
  "/pathtrak/live/index.html#/app/qamtrak?hcu=";
export const HEATMAP_PATH: string =
  "/pathtrak/live/index.html#/app/heatmap?hcu=";
export const ELEMENT_ANALYSIS: string = "/pathtrak/xpt/analysis/port/";

export enum MODULECODE {
  CMTS_MODEM_TAB_IMPORT_MODEM = 999,
  CMTS_MODEM_TAB_IMPORT_CMTS = 1004,
  USER_ACCOUNTS_TAB_IMPORT_USER = 1005,
}

export const HOUR_OF_DAY_AM = "am";
export const HOUR_OF_DAY_PM = "pm";

export const REQUEST_TYPE_DEVICE_LIST: number = 1000;
export const REQUEST_TYPE_ALARM_LIST: number = 1001;
export const REQUEST_TYPE_ALARM_DETAIL: number = 1002;

export const HEADEND_CONTROL_UNIT: string = "HCU";
export const RETURN_PATH_MONITOR: string = "RPM";
export const PORT: string = "Port";
export const HEADEND_STEALTH_MODEM: string = "HSM";

export const ALL = "ALL";
export const LOG_EVENT = "LOG_EVENT";
export const GENERATE_ALARM = "GENERATE_ALARM";
export const ALARM_SEVERITY = "ALARM_SEVERITY";
export const SEND_NOTIFICATION = "SEND_NOTIFICATION";
export const ESCAPE_CHAR: string = "&nbsp;";
export const AUTO_CLEAR = "AUTO_CLEAR";
export const NONE = "NONE";

export const ESCAPE_SYMBOL: string = "--";
export const LOCALIZATION_FILE_PATH: string = "assets/lang/";
export const LOCALIZATION_FILE_PATH_EN: string = "assets/lang/en/";
export const FILE_LOCALE: string = "locale-";

export const HOME_MODULE: string = "home";
export const INFO_MODULE: string = "info";
export const HCU_MODULE: string = "hcu";
export const ALARMS_MODULE: string = "alarms";
export const CMTS_MODULE: string = "cmts";
export const OLT_MODULE: string = "olt";
export const ENTERPRISE_MODULE: string = "enterprise";
export const SETTINGS_MODULE: string = "settings";
export const USERS_MODULE: string = "users";
export const CONTAINER_MODULE: string = "container";
export const DASHBOARD_MODULE: string = "dashboard";
export const SITES_MODULE: string = "sites";
export const RCI_MODULE: string = "rci";
export const OTU_MODULE: string = "otu";

export const DS_START_FREQ: string = "DS_START_FREQ";
export const DS_END_FREQ: string = "DS_END_FREQ";

export const LIVE_SA_START_FREQ_RPM_1K2K = "LIVE_SA_START_FREQ_RPM_1K2K";
export const LIVE_SA_END_FREQ_RPM_1K2K = "LIVE_SA_END_FREQ_RPM_1K2K";
export const LIVE_SA_START_FREQ_RPM_3K = "LIVE_SA_START_FREQ_RPM_3K";
export const LIVE_SA_END_FREQ_RPM_3K = "LIVE_SA_END_FREQ_RPM_3K";
export const LIVE_SA_START_FREQ_CMTS = "LIVE_SA_START_FREQ_CMTS";
export const LIVE_SA_END_FREQ_CMTS = "LIVE_SA_END_FREQ_CMTS";
export const LIVE_SA_START_FREQ_HCU_204 = "LIVE_SA_START_FREQ_HCU_204";
export const LIVE_SA_END_FREQ_HCU_204 = "LIVE_SA_END_FREQ_HCU_204";

export const MONTHLY_ROLLUP = "MONTHLY_ROLLUP";
export const MONTHLY_PURGE = "MONTHLY_PURGE";
export const DAILY_ROLLUP = "DAILY_ROLLUP";
export const DAILY_PURGE = "DAILY_PURGE";
export const DAILY_MINOR_THRESHOLD = "DAILY_MINOR_THRESHOLD";
export const DAILY_CRITICAL_THRESHOLD = "DAILY_CRITICAL_THRESHOLD";
export const MONTHLY_MINOR_THRESHOLD = "MONTHLY_MINOR_THRESHOLD";
export const MONTHLY_CRITICAL_THRESHOLD = "MONTHLY_CRITICAL_THRESHOLD";
export const DAILY_MACTRAK_MINOR_THRESHOLD = "DAILY_MACTRAK_MINOR_THRESHOLD";
export const DAILY_MACTRAK_CRITICAL_THRESHOLD =
  "DAILY_MACTRAK_CRITICAL_THRESHOLD";
export const MONTHLY_MACTRAK_MINOR_THRESHOLD =
  "MONTHLY_MACTRAK_MINOR_THRESHOLD";
export const MONTHLY_MACTRAK_CRITICAL_THRESHOLD =
  "MONTHLY_MACTRAK_CRITICAL_THRESHOLD";
export const ADD = "Add";
export const EDIT = "Edit";
export const DAYS = "days";
export const MONTHS = "months";
export const FEET = "feet";
export const METER = "meter";

export const STATUS_TEXT: string = "STATUS_";

export const DIAGNOSTIC_BLANK_ARR = [
  { startTime: "" },
  { startTime: "" },
  { startTime: "" },
];

//DashBoard Constants
export const DASHBOARD_KEY_TOTAL = "total";
export const DASHBOARD_KEY_OFFLINE = "offline";
export const DASHBOARD_KEY_ONTS = "onts";
export const DASHBOARD_KEY_PORTS = "ports";
export const DASHBOARD_KEY_ERROR = "error";
export const DASHBOARD_KEY_NODE = "node";
export const DASHBOARD_KEY_CMTS_MODEMS = "cmtsModems";
export const DASHBOARD_KEY_NODE_MODEMS = "nodeModems";
export const DASHBOARD_KEY_NODE_MODEMS_WITH_DOCSIS = "nodeModemsWithDocsis";
export const DASHBOARD_KEY_DOCSIS2 = "docsis2";
export const DASHBOARD_KEY_DOCSIS3 = "docsis30";
export const DASHBOARD_KEY_DOCSIS31 = "docsis31";
export const DASHBOARD_KEY_GEOCODE = "geocode";
export const DASHBOARD_KEY_DOWNLOADSPECTRUM = "downstreamSpectrum";
export const DASHBOARD_KEY_PREEQ = "preEq";
export const DASHBOARD_KEY_CMTS = "cmts";
export const DASHBOARD_KEY_ERRORTXT = "errorTxt";
export const DASHBOARD_KEY_SUCCESSTXT = "successTxt";
export const DASHBOARD_KEY_MODEMTXT = "modemTxt";
export const DASHBOARD_KEY_KEY = "key";
export const DASHBOARD_PERMISSION_KEY = "permissionKey";
export const DASHBOARD_PERMISSION_KEY_ERROR = "permissionError";
export const DASHBOARD_KEY_TXT = "txt";
export const DASHBOARD_KEY_VALUE = "value";
export const DASHBOARD_KEY_URL = "url";
export const DASHBOARD_KEY_TAB = "tab";
export const DASHBOARD_KEY_FILTER = "filter";
export const DASHBOARD_KEY_CLASS = "class";
export const DASHBOARD_KEY_CMTSDETAILS = "cmtsDetails";
export const DASHBOARD_KEY_MODEMDETAILS = "modemDetails";
export const DASHBOARD_KEY_FUA = "FIRMWARE_UPGRADE_AVAILABLE";
export const DASHBOARD_KEY_NOTI_TYPE = "notificationType";
export const DASHBOARD_KEY_HCU = "hcu";
export const DASHBOARD_KEY_INFO = "info";
export const DASHBOARD_KEY_INFO_LIC = "license";
export const DASHBOARD_KEY_RPM3 = "rpm3k";
export const DASHBOARD_KEY_RPM12 = "rpm12k";
export const DASHBOARD_KEY_PORT = "port";
export const DASHBOARD_KEY_HSM = "hsm";
export const DASHBOARD_KEY_RPM = "rpm";
export const DASHBOARD_KEY_VIRTUAL_HSM = "virtualHsm";
export const DASHBOARD_KEY_COUNT = "count";
export const DASHBOARD_KEY_HCU_DETAILS = "hcuDetails";
export const DASHBOARD_KEY_RCI = "rci";
export const DASHBOARD_KEY_OTU = "otu";
export const DASHBOARD_KEY_OLT = "olt";
export const USER_ACCOUNT = "UserAccount";

//grid Component Constants
export const GRID_COMP_KEY_STATUS = "status";
export const GRID_COMP_KEY_ONLY_SINGLE = "only-single";
export const GRID_COMP_KEY_SINGLE = "single";
export const GRID_COMP_KEY_MULTI = "multi";
export const GRID_COMP_KEY_ALL = "all";
export const GRID_COM_KEY_NO_SELECTION = "noSelection";
export const GRID_COMP_KEY_DISABLE = "disable";
export const GRID_COMP_KEY_TXT = "txt";
export const GRID_COMP_KEY_EVENT = "event";
export const GRID_COMP_KEY_SELECTED_DATA = "selectedData";
export const GRID_COMP_KEY_NAME = "name";

export const CMTS_KEY_UNAVAILABLE = "CMTS_KEY_UNAVAILABLE";
export const DASHBOARD_KEY_UNAVAILABLE = "DASHBOARD_KEY_UNAVAILABLE";


export const COMMA = ",";
export const DOT = ".";

//perfect-scrollbar config constant
export const PERFECT_SCROLLBAR_CONFIG = {
  suppressScrollX: true,
};

export const ELEMENT_TYPES: string[] = [
  "_ALIGNMENT_FAIL_CLEARED",
  "_ALIGNMENT_MARGINAL",
  "_ALIGNMENT_FAIL",
  "_ALIGNMENT_MARGINAL_CLEARED",
  "_OFFLINE_FAIL",
  "_OFFLINE_FAIL_CLEARED",
  "_FAIL",
  "_FAIL_CLEARED",
  "_MARGINAL",
  "_MARGINAL_CLEARED",
];

export const ALIGNMENT_TYPES: string[] = [
  "ALIGNMENT_US_TX_QAM_HIGH_FAIL_THRESHOLD",
  "ALIGNMENT_US_TX_QAM_LOW_FAIL_THRESHOLD",
  "ALIGNMENT_US_TX_OFDMA_HIGH_FAIL_THRESHOLD",
  "ALIGNMENT_US_TX_OFDMA_LOW_FAIL_THRESHOLD",
  "ALIGNMENT_DS_RX_QAM_HIGH_FAIL_THRESHOLD",
  "ALIGNMENT_DS_RX_QAM_LOW_FAIL_THRESHOLD",
  "ALIGNMENT_DS_RX_OFDM_HIGH_FAIL_THRESHOLD",
  "ALIGNMENT_DS_RX_OFDM_LOW_FAIL_THRESHOLD",
  "ALIGNMENT_US_TX_QAM_HIGH_MARGINAL_THRESHOLD",
  "ALIGNMENT_US_TX_QAM_LOW_MARGINAL_THRESHOLD",
  "ALIGNMENT_US_TX_OFDMA_HIGH_MARGINAL_THRESHOLD",
  "ALIGNMENT_US_TX_OFDMA_LOW_MARGINAL_THRESHOLD",
  "ALIGNMENT_DS_RX_QAM_HIGH_MARGINAL_THRESHOLD",
  "ALIGNMENT_DS_RX_QAM_LOW_MARGINAL_THRESHOLD",
  "ALIGNMENT_DS_RX_OFDM_HIGH_MARGINAL_THRESHOLD",
  "ALIGNMENT_DS_RX_OFDM_LOW_MARGINAL_THRESHOLD",
];

export const DECIMAL_RANGE: string = '1.1-2';
export const LOWER_THAN: string = 'LOWER_THAN';

export const SEARCH_CACHE_NAME: string = "searchData";
export const LOADING_TEXT: string = "Loading ...";
