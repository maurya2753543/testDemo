
export class CommonStrings {
  
    public static MODEM_ERROR:string = 'Modem Error';
    public static EXPORT:string = 'EXPORT';
    public static OK:string = 'OK';
    public static RESET:string = 'Reset';
    public static CANCEL:string = 'CANCEL';
    public static APP_LOADING:string = 'Loading..';
    public static ACTION_LABEL:string = 'Action';
    public static AG_GRID_NO_ROWS_TO_SHOW:string = 'No Rows To Show';
  
    public static PIN_LEFT:string = "Pin Left";
    public static PIN_RIGHT:string = "Pin Right";
    public static NO_PIN:string = "No Pin";
    public static PIN_COLUMN_MAIN_MENU:string = "Pin Column";
    public static FILTER_EQUALS:string = "Equals";
    public static FILETR_NOT_EQUALS:string = "Not Equals";
    public static FILTER_CONTAINS:string = "Contains";
    public static FILTER_STARTS_WITH:string = "Starts With";
    public static FILTER_NOT_CONTAINS:string = "Not Contains";
    public static FILTER_ENDS_WITH:string = "Ends With";
    public static FILTER:string = "Filter";
    public static SORT_ASCENDING:string = "Sort Ascending";
    public static SORT_DESCENDING:string = "Sort Descending";
    public static REMOVE_SORT:string = "Remove Sort";
    public static NO_DATA_AVAILABLE:string = 'No Data Available';
    public static TRY_AGAIN:string = 'Try again';
    public static IS_LANG_LOADED:boolean = false;
  
    public static ALARM_LIST_SEVERITY_CRITICAL:string = "Critical";
    public static ALARM_LIST_SEVERITY_MAJOR:string = "Major";
    public static ALARM_LIST_SEVERITY_MINOR:string = "Minor";
    public static ALARM_LIST_SEVERITY_WARNING:string = "Warning";
    public static ALARM_LIST_SEVERITY_GOOD:string = "Good";
    public static TABLE_LIST_SHOW_ALL:string = "Show all";
  
    public static TABLE_LIST_SHOWING:string = "Showing";
    public static TABLE_LIST_SHOWING_OF:string = "of";
    public static TABLE_LIST_SHOW_LESS:string = "Show less";
    public static ALARM_LIST_SEVERITY_DEFAULT:string = "Select";
  
    public static CLEAR_ALARM_OPTION_YES:string = "Yes";
    public static CLEAR_ALARM_OPTION_NO:string = "No";
    public static TABLE_LIST_ROWS:string = "rows";
  
    public static MEASUREMENT_UNIT:string = "measurementunit";
    public static THRESHOLDS:string = "thresholds";
    public static PORT_CUSTOM_FIELD:string = "userDefined";
    public static MODEM_CUSTOM_FIELD:string = "modemCustomFields";
    public static MODEM_VIP_CUSTOMER_FIELD: string = "modemVipCustomerFields";
    public static FIRMWARE:string = "firmware";
    public static NOISETRAK:string = "noiseTrak";
    public static SERVER:string = "proxy";
    public static MODEM:string = "modem";
    public static EVENTS:string = "events";
    public static SNMP:string = "snmp";
    public static SMTP:string = "smtp";
    public static NODE_BROADCAST:string = "broadcast";
    public static RCI_SWEEP:string ="rciSweep";
    public static MONITORING_PLAN:string = "";
    public static NODE_RANKING:string = "noderankhcu";
    public static PERFORMANCE: string = "purge";
    public static MACTRAK_PERFORMANCE:string = "mactrakwf";
    public static SPECTRUM_ANALYZER:string = "livesa";
    public static QAMTRAK:string = "qamtrak";
    public static PRE_EQ:string = "preeqwf";
    public static DOWNSTREAM:string = "downstream";
    public static MAPOVERLAY:string = "mapoverlay";
    public static QOETHRESHOLD:string = "qoethresholds";
    public static RANKINDEX:string = "rankindex";
    public static QOEWF:string = 'qoewf';
    public static NODE_RANK_QOE:string = 'noderankqoe';
    public static ALARM_THRESHOLDS = 'alarmthresholds';
    public static UTILIZATION_ALARM_THRESHOLDS = 'utilizationAlarmThresholds';
    public static UTILIZATION_THRESHOLDS = 'utilization';
    public static UPSTREAM_SETTINGS = 'upstreamsettings';
    public static UTILIZATION_SETTINGS = 'utilizationsettings';
    public static RCI:string = "rci";
    public static OTU:string = "otu";

    public static TABLE_LIST_EXPORT_ALL:string = "Export All";
    public static TABLE_LIST_EXPORT_SELECTED:string = "Export Selected";
  
    public static ALERT_TITLE: string = 'Error';
    public static ALERT_SUCCESS_TITLE: string = 'Success';
    public static ALERT_INFOR_TITLE: string = 'Info';
    public static ALERT_CONFIRMATION_TITLE: string = 'Confirmation';
    public static ALERT_SAVE_FILE_TEXT: string = 'Do you want to save File?';
    public static ALERT_DELETE_FILE_TEXT: string = 'Do you want to delete File?';
    public static ALERT_INFO_TITLE: string = 'Info';
    public static ALERT_WARNING: string = 'warning';
    public static NO_FAILED_MODEMS: string = 'No Failed Modems';
  
    public static SYSTEM_SETTINGS: string[] = [CommonStrings.MEASUREMENT_UNIT ,
      CommonStrings.THRESHOLDS , CommonStrings.PORT_CUSTOM_FIELD , CommonStrings.FIRMWARE,
      CommonStrings.SERVER , CommonStrings.MODEM , CommonStrings.EVENTS , CommonStrings.SNMP,
      CommonStrings.SMTP , CommonStrings.NODE_BROADCAST , CommonStrings.MONITORING_PLAN,
      CommonStrings.NODE_RANKING , CommonStrings.PERFORMANCE, CommonStrings.MACTRAK_PERFORMANCE ,
      CommonStrings.SPECTRUM_ANALYZER , CommonStrings.QAMTRAK , CommonStrings.PRE_EQ,
      CommonStrings.DOWNSTREAM
    ];

    public static ARRIS:string = "Arris";
    public static PLANT_MAP:string = "PlantMap";
    public static LEAKAGE_MAP:string = "LeakageMap";
    public static SS_MAP:string = "ssMap";

    public static COMMUNITY_STRINGS: string = "CommunityStrings";
    public static MODEM_WATCH: string = "ModemWatch";

    public static SUBMENU_SCHEDULE:string = "Schedule";
    public static SUBMENU_SPECTRAL_NODE_RANKING :string = "SpectralNodeRanking";
    public static SUBMENU_MACTRAK_NODE_RANKING:string = "MACTrakNodeRanking";
    public static SUBMENU_QOE_NODE_RANKING:string = "QoENodeRanking";

    public static SUBMENU_IN_HOME_IMPAIRMENTS:string = "InHomeImpairments";
    public static SUBMENU_WEIGHT_FACTORS:string = "WeightFactors";

    
    public static SUBMENU_GENERAL:string = "General";
    public static SUBMENU_SCORING_WEIGHT_FACTORS :string = "ScoringWeightFactors";
    public static SUBMENU_LTE:string = "LTE";
    public static SUBMENU_FM:string = "FM";
    public static SUBMENU_ADJACENCY:string = "Adjacency";

    public static SUBMENU_HCU_SPECTRUM:string = "HCUSpectrumMACTrak";
    public static SUBMENU_DOWNSTREAM :string = "performanceDownstream";
    public static SUBMENU_NODE_RANK:string = "performanceNodeRank";
    public static SUBMENU_PREEQ:string = "performancePreEq";
    public static SUBMENU_QOE:string = "performanceQoE";
    public static SUBMENU_ENHANCE_ALARAM = "performanceEnhanceAlarm"
    

    public static SUBMENU_ALARM_NODE_HEALTH:string = "Node Health";
    public static SUBMENU_ALARM_PREEQ:string = "PreEq";
    public static SUBMENU_ALARMMODEMOUTAGE:string = "Modem Outage";
    public static SUBMENU_ALARMMODEMQOE: string = "Modem QoE";
    public static SUBMENU_ALARMRPM:string = "rpm";
    public static SUBMENU_ALARMMACTRAK:string = "mactrak";
    public static SUBMENU_ALARM_QOE:string = "QoE";
    public static SUBMENU_ALARM_OFFLINE:string = "Offline";
    public static SUBMENU_ALARM_ALIGNMENT:string = "Alignment";

    public static SUBMENU_UPSTREAM_METRICS:string = "upstreamMetrics";
    public static SUBMENU_STABILITY_METRICS:string = "stabilityMetrics";
    public static SUBMENU_DOWNSTREAM_METRICS:string = "downstreamMetrics";
    public static SUBMENU_OTHER_METRICS:string = "otherMetrics";
    public static SUBMENU_UTILIZATION:string = "utilization";
    public static SUBMENU_CHRONIC:string = "chronic";

    public static UTILIZATION:string = "Capacity/Utilization";

    public static PERFORMANCE_INTERVAL:string = "HCUSpectrumMACTrak"
    public static PERFORMANCE_DOWNSTREAM:string = "performanceDownstream"
    public static PERFORMANCE_NODE_RANK:string = "performanceNodeRank"
    public static PERFORMANCE_PREEQ:string = "performancePreEq"
    public static PERFORMANCE_MACTRACK_PACKETS:string = "HCUSpectrumMACTrak"
    public static PERFORMANCE_QOE:string = "performanceQoE"
    public static PERFORMANCE_ENHANCE_ALARM = "performanceEnhanceAlarm"

    public static SCORE_WEIGHT_FACTORS: string[] = ['NODE_RANK_CHRONIC_IMPACTED_WF','NODE_RANK_CHRONIC_OTHER_WF','NODE_RANK_CHRONIC_STRESSED_WF','NODE_RANK_IMPACTED_WF','NODE_RANK_STRESSED_WF','NODE_RANK_NOMINAL_MODEM'];

    //ag-grid menu option
    public static GRID_MENU_GREATER_THAN: string = 'Greater Than';
    public static GRID_MENU_GREATER_THAN_OR_EQUAL: string = 'Greater Than or Equal';
    public static GRID_MENU_LESS_THAN: string = 'Less Than';
    public static GRID_MENU_LESS_THAN_OR_EQUAL: string = 'Less Than or Equal';
    public static GRID_MENU_NOT_EQUAL: string = 'Not Equal';
    public static GRID_MENU_IN_RANGE: string = 'In Range';
    public static GRID_MENU_AUTO_SIZE_THIS_COLUMN: string = 'Auto size this column';
    public static GRID_MENU_AUTO_SIZE_ALL_COLUMN: string = 'Auto size all column';
    public static GRID_MENU_RESET_COLUMN: string = 'Reset Columns';
    public static GRID_MENU_TOOL_PANEL: string = 'Tool Panel';
    public static GRID_NO_ROWS_TO_SHOW: string = 'No Rows To Show';
    public static GRID_LOADING: string = 'Loading';
    public static GRID_MENU_EXPAND_ALL: string = 'Expand All';
    public static GRID_MENU_COLLAPSE_ALL: string = 'Close All';

    //PAGInation related changes
    public static GRID_MENU_TO:string="to";
    public static GRID_MENU_OF:string="of";
    public static GRID_MENU_FIRST:string="First";
    public static GRID_MENU_PREVIOUS:string="Previous";
    public static GRID_MENU_PAGE:string="Page";
    public static GRID_MENU_NEXT:string="Next";
    public static GRID_MENU_LAST:string="Last";
  
  }
