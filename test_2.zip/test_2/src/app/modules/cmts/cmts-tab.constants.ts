/**
 * Created by yogesh.paisode on 6/12/2017.
 */

export const EDIT_OPERATION: string = "edit";
export const ADD_OPERATION: string = "add";
export const SINGLE_CONTS: string = "single";
export const ONLY_SINGLE_CONST:string = "only-single";
export const MULTI_CONTS: string = "multi";
export const ALL_CONTS: string = "all";
export const CMTS_CONTS: string = "CMTS";
export const MODEM_CONTS: string = "MODEM-CMTS";
export const NODE_CONTS: string = "NODE-CMTS";
export const CMTS_CONTAINER: string = "Container";
export const CMTS_SITE: string = "Site";
export const FIRST_SELECT_OPTION: string = "-- Select ";
export const MODEM_ALARM_CONTS: string = "MODEM-ALARM";
export const MODEM_WATCH_CONTS: string = "MODEM-WATCH";