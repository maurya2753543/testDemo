import {Component, OnInit, OnDestroy, ViewChild, ComponentFactoryResolver, ViewContainerRef} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import {Grid} from "../../../shared/ag-grid.options";
import {NodeTabDataService} from "./node-tab.data.service";
import {NodeTabService} from "./node-tab.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {NodeTabColumnDefinitionService} from "./node-tab.column-definition.service";
import {Logger} from "../../../utilities/logger";
import {CmtsTabDataService} from "../cmts-tab/cmts-tab.data.service";
import { CMTSDataService } from '../cmts.data.service';
import {SharedService} from "../../../shared/shared.service";
import {NodeTabFormComponent} from "./node-tab-form/node-tab.form.component";
import  { NodeModel }from "./node-tab.model";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {CmtsTabSharedService} from "../cmts-tab.shared.service";
import * as cstmConstants from "../cmts-tab.constants";
import {GRID_COMP_KEY_ONLY_SINGLE} from "../../../constant/app.constants";
import {CMTSViewEvent} from "../view-events/view-event.component";

@Component({
    selector: 'nodetab-component',
    templateUrl: 'node-tab.component.html',
    providers: [NodeTabService]
})

export class  NODETabComponent implements OnInit, OnDestroy {
    public nodeTabGridOptions: Grid = new Grid();
    public nodeTabGridRowData: any;
    private nameFilterInstance: any;
    private tag:string = "NODETabComponent:: ";
    private excludeColumns: string[] = ["0"];
    private selectedRowsNodeId: number[]= [];
    private NODE_TAB_ADD_GREENFIELD_NODE:string = "";
    private TABLE_LIST_EXPORT_SELECTED: string = "";
    private TABLE_LIST_EXPORT_ALL: string = "";
    private BILLING_IMPORT_MAPPING_REPORT_BTN: string="";
    public gridTabType:string = "NODEExport";
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    private EVENTS: string;
    public viewData: boolean = false;
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF: string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number;
    private DELETE_NODE: string;
    private EDIT_NODE: string;
    private DELETE_NODE_SUCCESS: string;
    private DELETE_NODE_CONFIRMATION: string;
    private CANNOT_DELETE_NODE: string;
    public nodeData: any = null;

    private VIEW_EVENTS:string = "";

    @ViewChild('targetNodeView', {read: ViewContainerRef}) _targetNodeView;

    constructor(private localeDataService: LocaleDataService,
           private cmtsTabSharedService: CmtsTabSharedService, 
           private componentFactoryResolver: ComponentFactoryResolver, 
           private viewContainerRef: ViewContainerRef, 
           private nodeTabService: NodeTabService, 
           private cmtsDataService: CMTSDataService, 
           private logger: Logger, 
           private nodeTabDataService: NodeTabDataService, 
           private showAlert: ShowAlert, 
           private sharedService: SharedService, 
           private nodeTabColumnDefinitionService: NodeTabColumnDefinitionService){
        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
            this.setEventButtonKeys();
        })
    }

    ngOnInit() {
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.handleAddNodeEvent();
        if(this.sharedService.RetainFilter){
            this.nodeTabDataService.nodetabfilterchangedata = "";
            this.cmtsDataService.cmtsmodeldata = "";
        }
    }

    /*
     *@name nodeCMTSEvent
     *@desc Events related to Node tab (CSTM).
     *@return void
     */
    public notifyActionEmitter($event) {
        switch($event.event.name) {
            case this.NODE_TAB_ADD_GREENFIELD_NODE:
                this.notifyAddGreenFieldNODECMST();
                break;
            case this.DELETE_NODE:
                this.deleteSelected();
                break;
            case this.EDIT_NODE:
                this.editNode();
                break;
            case this.VIEW_EVENTS:
                this.notifyViewEvent($event.selectedData);
                break;
            case this.BILLING_IMPORT_MAPPING_REPORT_BTN:
                this.linkToBillingImportMappingReport();
                break;
            default:
        }
    }

    private editNode(): void{
        this.nodeData = this.getSelectedId();
    }

    private getSelectedId(): any{
        return this.nodeTabGridOptions.api.getSelectedRows()[0];
    }

    private deleteNode(isConfirm: boolean): void{
        if(isConfirm){
            let selectedId: number = this.getSelectedId().nodeId;
            this.nodeTabDataService.deleteNode(selectedId).subscribe(this.onDeleteNodeSuccessNext.bind(this), this.onError.bind(this));
        }
    }

    /*
  * @Method :: Delete current selection
  * */
    private deleteSelected(): void{
        if(this.getSelectedId().cmts == "")
            this.showAlert.showInfoAlert(this.CANNOT_DELETE_NODE);
        else {
            this.showAlert.showCustomWarningAlertConfirm("", this.DELETE_NODE_CONFIRMATION , (isConfirm: boolean)=>{
            this.deleteNode(isConfirm);
            });
        }
    }

    private onDeleteNodeSuccessNext(): void{
        this.showAlert.showInfoAlert(this.DELETE_NODE_SUCCESS);
        this.getNodeList();
    }

    /*Method to set event buttons with localized strings*/
    private setEventButtonKeys():void {
        this.eventKeys = [
            { name: this.VIEW_EVENTS, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.CMTS_CONTS},
            {name: this.EDIT_NODE, status:GRID_COMP_KEY_ONLY_SINGLE, tabType:cstmConstants.NODE_CONTS},
            {name: this.DELETE_NODE, status:GRID_COMP_KEY_ONLY_SINGLE, tabType:cstmConstants.NODE_CONTS},
            {name: this.TABLE_LIST_EXPORT_SELECTED, status:cstmConstants.SINGLE_CONTS, tabType:cstmConstants.NODE_CONTS},
            {name: this.TABLE_LIST_EXPORT_ALL, status:cstmConstants.ALL_CONTS, tabType:cstmConstants.NODE_CONTS},
        ];
        this.buttonKeys = [
            {name: this.BILLING_IMPORT_MAPPING_REPORT_BTN , tabType: cstmConstants.NODE_CONTS}
        //     {name:this.NODE_TAB_ADD_GREENFIELD_NODE, tabType:cstmConstants.NODE_CONTS}
        ];
    }

    /*Method to set name filter*/
    private applyNameFilter(filterValue: string): void{
        if(filterValue) {
            this.nameFilterInstance.setFilter(filterValue);
            this.nameFilterInstance.onFilterChanged();
        }
    }

    /*Method to get name filter text*/
    private getNameFilterText(): string{
        let filterText: string = "";
        let filterModel: any = this.nameFilterInstance && this.nameFilterInstance.getModel();
        if(filterModel){
            filterText = filterModel.filter;
        }
        return filterText;
    }

    //method loads view events slider.
    private notifyViewEvent($event) {
        let data = $event;
        data["id"] = data[0].nodeId;
        data["headerName"] = "Node " + this.EVENTS + " - " + data[0].nodeName;
        data["type"] = "Node";
        this.loadSliderTab(CMTSViewEvent, data);
    }

    private linkToBillingImportMappingReport():void{
        window.open(window.location.origin + "/pathtrak/diagnosticview/index.html#/billing-import-mapping", "_blank");
    }


    //Method to clear other components
    private loadSliderTab(targetComponent: any, data?:any): void{
        this._targetNodeView.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        let cmpRef = this._targetNodeView.createComponent(factory);
        cmpRef.instance.childData = data;
    }

    /*Get node list from server*/
    private getNodeList(): void{
        this.storeSelection();
        this.showGridLoadingOverly();
        
        
        //this.sharedService.RetainFilter = false;
        this.nodeTabDataService.getNodeList().subscribe(this.onNext.bind(this), this.onError.bind(this));
        if(this.nodeTabGridOptions.api && (this.nodeTabDataService.nodetabfilterchangedata || this.cmtsDataService.cmtsmodeldata)){
            this.nodeTabGridOptions.api.setFilterModel(this.nodeTabDataService.nodetabfilterchangedata);            
            if(this.cmtsDataService.cmtsmodeldata || this.nodeTabDataService.nodetabfilterchangedata){
            const countryFilterComponent3 = this.nodeTabGridOptions.api.getFilterInstance("cmts");
            countryFilterComponent3.setModel(this.cmtsDataService.cmtsmodeldata);
            }
        }
    }

    /*Method to set column in table*/
    private setNodeGridColumnDefinition(): void{
        this.nodeTabGridOptions.api.setColumnDefs(this.nodeTabColumnDefinitionService.getColumnDef());
        // this.nameFilterInstance = this.nodeTabGridOptions.api.getFilterInstance('cmts');
        // this.applyNameFilter(this.cmtsTabSharedService.getNameFilterText());
        this.showGridLoadingOverly();
        this.getNodeList();
    }

    /*Update the node list after greenfield node is added*/
    private handleAddNodeEvent() {
        this.nodeTabService.getAddNodeEventSubject().subscribe( ()=>{
            this.getNodeList();
        });
    }

    private onSliderClose(refreshList: boolean): void{
        this.nodeData = null;
        refreshList && this.getNodeList();
    }

    /*Method for Export all feature*/
    public notifyExportAllNODECMST(event){
        this.nodeTabColumnDefinitionService.exportAll(this.nodeTabGridOptions, this.excludeColumns, true, false);
    }

    /*Method for Export Selected feature*/
    public notifyExportSelectedNODECMST(event){
        this.nodeTabColumnDefinitionService.exportOnlySelected(this.nodeTabGridOptions, this.excludeColumns, true, false);
    }

    /*Method for Add Green field node & to open slider for it*/
    public notifyAddGreenFieldNODECMST(): void{
        this.logger.debug(this.tag, "addGreenfieldNode(): request add green field node");
        this.loadSliderTab(NodeTabFormComponent);
        this.viewData =! this.viewData;
    }

    /*Method to Notify Grid Ready event*/
    public notifyGridReadyNODECMTS(): void{
        this.setNodeGridColumnDefinition();
    }

    /*Method to Notify Name Filter change event Selected feature*/
    public notifyFilterChangeNODECMTS(event): void{
        // let nameFilterText: string = this.getNameFilterText();
        // this.cmtsTabSharedService.setNameFilterText(nameFilterText);
        this.sharedService.RetainFilter = false;
        this.nodeTabDataService.nodetabfilterchangedata = this.nodeTabGridOptions.api.getFilterModel();
        const countryFilterComponent = this.nodeTabGridOptions.api.getFilterInstance('cmts');
        const model = countryFilterComponent.getModel();
        this.cmtsDataService.cmtsmodeldata = model;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.nodeTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    /*Method to set Grid Row in table*/
    private setGridRowData(nodeListData: Array<NodeList>): void{
        this.logger.debug(this.tag, "onNext(): set row data = ", nodeListData);
        if(nodeListData && nodeListData.length > 0) {
            //this.nodeTabGridOptions.api.setRowData(nodeListData);
            this.nodeTabGridRowData = nodeListData;
            this.nodeTabService.restoreSelection(this.selectedRowsNodeId, this.nodeTabGridOptions.api);
            this.hideGridOverly();
        } else {
            this.nodeTabGridRowData = [];
        }
        this.totalCount = this.nodeTabGridRowData.length;
        this.setShowAllLabel(this.nodeTabGridRowData.length, this.totalCount);
        

    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

	/* On gettting node list from server, set list in grid */
    private onNext(nodeListData) {
        this.setGridRowData(nodeListData);
    }

	/* Handle error & show sweet alert */
    private onError(error) {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.hideGridOverly();
        this.showAlert.showErrorAlert(error);
    }

    /*Method to hide overlay text from table*/
    private hideGridOverly(): void{
        this.nodeTabGridOptions.api.hideOverlay();
    }

    /*Method to show overlay text from table*/
    private showGridLoadingOverly(): void{
        this.nodeTabGridOptions.api.showLoadingOverlay();
    }

    /*Method to store selected rows to service*/
    private storeSelection(): number[]{
        this.selectedRowsNodeId.length = 0;
        this.nodeTabService.getSelectedRowsNodeIds(this.nodeTabGridOptions.api.getSelectedRows(), this.selectedRowsNodeId);
        return this.selectedRowsNodeId;
    }

    /*Method to clear grid data*/
    private clearGridData(): void{
        this.storeSelection();
        //this.nodeTabGridOptions.api.setRowData([]);
        this.nodeTabGridRowData = [];
    }

    public notifyRefreshGrid(): void{
        this.getNodeList();
    }

    /* Method get called when we come in HSM tab after switch the tab */
    public onTabSwitch(): void{
        this.getNodeList();
    }

    ngOnDestroy() {
    }

    /*Method to translate locale strings*/
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.NODE_TAB_ADD_GREENFIELD_NODE = localizationService.instant('NODE_TAB_ADD_GREENFIELD_NODE');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.VIEW_EVENTS = localizationService.instant('VIEW_EVENTS');
        this.EVENTS = localizationService.instant('EVENTS');
        this.DELETE_NODE = localizationService.instant('DELETE_NODE');
        this.EDIT_NODE = localizationService.instant('EDIT') + " " +localizationService.instant('CMTS_TABNODE');
        // this.EDIT_NODE = localizationService.instant('EDIT') + " " +localizationService.instant('OLT_TABPORT');
        this.DELETE_NODE_SUCCESS = localizationService.instant('DELETE_NODE_SUCCESS');
        this.DELETE_NODE_CONFIRMATION = localizationService.instant('DELETE_NODE_CONFIRMATION');
        this.CANNOT_DELETE_NODE = localizationService.instant('CANNOT_DELETE_NODE');
        this.BILLING_IMPORT_MAPPING_REPORT_BTN = localizationService.instant('BILLING_IMPORT_MAPPING_REPORT_BTN');

    }
}
