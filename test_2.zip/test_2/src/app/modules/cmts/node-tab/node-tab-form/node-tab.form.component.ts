/**
 * Created by Mehjabeen.Bari on 6/13/2017.
 */
import {Component} from '@angular/core';
import {CmtsTabModel} from "../../cmts-tab/cmts-tab.model";
import {CmtsTabDataService} from "../../cmts-tab/cmts-tab.data.service";
import {Logger} from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import {NodeTabDataService} from "../node-tab.data.service";
import {NodeTabService} from "../node-tab.service";
import {MAX_STRING_LIMIT} from "../../../../constant/app.constants";
import {CmtsTabSharedService} from "../../cmts-tab.shared.service";
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector: 'nodetab-form',
    templateUrl: 'node-tab.form.component.html'
})
export class NodeTabFormComponent {
    isReadOnly: boolean = false;
    public cmtsList:Array<CmtsTabModel> = [];
    private tag:string = "NodeTabFormComponent:: ";

    private node:string = '';
    private mac:string = '';
    private selectedCMTSId:number= 0;
    private validForm:boolean = true;
    public _MAX_STRING_LIMIT: number;
    public isCloseRightSlider:boolean = false;

    public errorMessages: any = {
        "isNameEmpty": false,
        "isMacAddressEmpty": false,
    };

    public addNode =  {
        node:'',
        mac:'',
        selectedCMTSId:0
    }

    constructor(private nodeTabService: NodeTabService,private sharedService:SharedService,
                private cmtsTabSharedService: CmtsTabSharedService, private nodeTabDataService: NodeTabDataService,
                private cmtsTabDataService:CmtsTabDataService, private logger: Logger, private showAlert: ShowAlert) {
        this._MAX_STRING_LIMIT = MAX_STRING_LIMIT;
    }

    ngOnInit() {
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.setCMTSListInDropdown();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.onCancel();
        })
    }

    public ipNameEmpty(): void{
        if(this.addNode.node.length === 0){
            this.errorMessages.isNameEmpty = true;
        }else{
            this.errorMessages.isNameEmpty = false;
        }
    }

    public macAddressEmpty(): void{
        if(this.addNode.mac.length === 0){
            this.errorMessages.isMacAddressEmpty = true;
        }else{
            this.errorMessages.isMacAddressEmpty = false;
        }
    }

    /*Method called to get cmts list from cmts service & set in dropdown*/
    private setCMTSListInDropdown(): void{
        let cmtsList:Array<CmtsTabModel> = this.cmtsTabDataService.getCmtsTabList();
        if(cmtsList && cmtsList.length>0) {
            this.cmtsList = cmtsList;
            this.addNode.selectedCMTSId = cmtsList[0].cmtsId;
        } else {
            this.validForm = false;
        }
    }

    /*Method called from UI on click to submit button. API call will be made to add greenfield node to server */
    public onSubmit(): void{
        this.logger.debug(this.tag, "addGreenfieldNode(): request add green field node data=", this.addNode);
        this.nodeTabDataService.addGreenFieldNode(this.addNode).subscribe(this.onAddNext.bind(this), this.onError.bind(this));
    }

    /*Method to handle success response on green field node addition */
    private onAddNext(data): void {
        this.logger.debug(this.tag, "onAddNext(): add green field node success data=", data);
        this.nodeTabService.getAddNodeEventSubject().next();
        this.onCancel();
    }

    //KeyUp event
    public keyUp(): void{
        this.addNode.node = this.cmtsTabSharedService.checkTextLength(this.addNode.node);
    }

    /*Method to handle error */
    private onError(error): void{
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    /*Method called from ui on click to cancel button.
    * This trigger to close the slider*/
    public onCancel(): void{
        this.logger.debug("onCancel: close slider");
        this.isCloseRightSlider = true;
    }


}