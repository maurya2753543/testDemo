/**
 * Created by Mehjabeen.Bari on 6/9/2017.
 */

import {Injectable} from "@angular/core";
import {EXTERNAL_LINK_ICON} from "../../../constant/app.constants";
import {CMTSUrlService} from "../cmts.url.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import {SelectBoxFilter, SelectBoxFilterParams} from "../../../shared/select-box.filter";
import { BooleanFilter } from "src/app/shared/boolean.filter";
import { TranslateService } from "@ngx-translate/core";
// import {log} from "util";

let vm:any;

@Injectable()
export class NodeTabColumnDefinitionService{

    private dataGridOption: any;
    private _NONE:string = '';
    private trueValue : string;
    private falseValue : string;
    private default: string;
    public nodetabfilterchangedata: any;
    constructor(private urlService: CMTSUrlService,
                private localeDataService: LocaleDataService,
                private translate: TranslateService,
                private sharedService: SharedService){
        vm = this;
    }

    private _HEADER_FIELDS: any = {
        nodeName : {field: "nodeName", name: "NODE_TAB_COLUMN_NODE"},
        modems : {field: "modems", name: "NODE_TAB_COLUMN_MODEMS"},
        cmts : {field: "cmts", name: "NODE_TAB_COLUMN_CMTS"},
        cmtsNode : {field: "cmtsNode", name: "NODE_TAB_COLUMN_CMTS_NODE"},
        rphy : {field: "rphy", name: "NODE_TAB_COLUMN_RPHY"},
        rphyVendor : {field: "rphyVendor", name: "NODE_TAB_COLUMN_RPHYVENDOR"},
        billingNode: {field: "billingNode", name: "NODE_TAB_COLUMN_BILLING_NODE"},
        rci : {field: "rci", name: "CMTS_TAB_HEADER_RCI"},
        hcu : {field: "hcu", name: "NODE_TAB_COLUMN_HCU"},
        icsCount : {field: "icsCount", name: "NODE_TAB_COLUMN_NOISETRAK_COUNT"},
        rpmPort : {field: "rpmPort", name: "NODE_TAB_COLUMN_PORT"},
        rpmPortMapTyp : {field: "rpmPortMapTyp", name: "NODE_TAB_COLUMN_PORT_MAPPING"},
        viewModems : {field: "viewModems", name: "NODE_TAB_COLUMN_MODEMS_DETAILS"},
        nodeMapping : {field: "viewNodeMapping", name:"NODE_TAB_COLUMN_NODE_MAPPING"},
        noiseTrakMapping : {field: "viewnoiseTrakMapping", name:"NODE_TAB_COLUMN_NOISETRAK_MAPPING"},
        daaDevice : {field: "daaDevice", name: "NODE_TAB_COLUMN_DAA_DEVICE"},
        cmtsUsPortName : {field: "cmtsUsPortName", name: "NODE_TAB_COLUMN_UPSTREAM_PORT"},
        fiberNode : {field: "fiberNode", name: "NODE_TAB_COLUMN_FIBER_NODE"},
        macDomain : {field: "macDomain", name: "NODE_TAB_COLUMN_MAC_DOMAIN"},
        serviceGroup : {field: "serviceGroup", name: "NODE_TAB_COLUMN_SERVICE_GROUP"},
        upstreamServiceGroup : {field: "upstreamServiceGroup", name:"NODE_TAB_COLUMN_UPSTREAM_SERVICE_GROUP"},
        downstreamServiceGroup : {field: "downstreamServiceGroup", name:"NODE_TAB_COLUMN_DOWNSTREAM_SERVICE_GROUP"},
        pnmLicensed : {field: "pnmLicensed", name: "NODE_TAB_COLUMN_PNM_LICENSED"},
        qoeLicensed : {field: "qoeLicensed", name: "NODE_TAB_COLUMN_QOE_LICENSED"},
        modemAnalyserLicensed : {field: "modemAnalyserLicensed", name: "NODE_TAB_COLUMN_DOCSIANALYZER_LICENSED"},
        modemHealthLicensed: {field: "modemHealthLicensed", name:"NODE_TAB_COLUMN_MODEM_HEALTH_LICENSED"},
        modemLiveAnalyzerLicensed: {field: "modemLiveAnalyzerLicensed", name:"NODE_TAB_COLUMN_MODEM_LIVE_ANALYZER_LICENSED"},
        modemHistoryLicensed: {field: "modemHistoryLicensed", name:"NODE_TAB_COLUMN_MODEM_HISTORY_LICENSED"},
        topologyAlarmLicensed: {field: "topologyAlarmLicensed", name:"NODE_TAB_COLUMN_TOPOLOGY_ALARM_LICENSED"},
        topologyOutageLicensed: {field:"topologyOutageLicensed", name:"NODE_TAB_COLUMN_TOPOLOGY_OUTAGE_LICENSED"}
    };

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        let localizationService = this.translate;
        this._HEADER_FIELDS.nodeName.name = localizationService.instant('NODE_TAB_COLUMN_NODE');
        this._HEADER_FIELDS.cmts.name = localizationService.instant('NODE_TAB_COLUMN_CMTS');
        this._HEADER_FIELDS.cmtsNode.name = localizationService.instant('NODE_TAB_COLUMN_CMTS_NODE');
        this._HEADER_FIELDS.rphy.name = localizationService.instant('NODE_TAB_COLUMN_RPHY');
        this._HEADER_FIELDS.rphyVendor.name = localizationService.instant('NODE_TAB_COLUMN_RPHYVENDOR');
        this._HEADER_FIELDS.billingNode.name = localizationService.instant('NODE_TAB_COLUMN_BILLING_NODE');
        this._HEADER_FIELDS.rci.name = localizationService.instant('CMTS_TAB_HEADER_RCI');
        this._HEADER_FIELDS.modems.name = localizationService.instant('NODE_TAB_COLUMN_MODEMS');
        this._HEADER_FIELDS.hcu.name = localizationService.instant('NODE_TAB_COLUMN_HCU');
        this._HEADER_FIELDS.icsCount.name = localizationService.instant('NODE_TAB_COLUMN_NOISETRAK_COUNT');
        this._HEADER_FIELDS.rpmPort.name = localizationService.instant('NODE_TAB_COLUMN_PORT');
        this._HEADER_FIELDS.rpmPortMapTyp.name = localizationService.instant('NODE_TAB_COLUMN_PORT_MAPPING');
        this._HEADER_FIELDS.viewModems.name = localizationService.instant('NODE_TAB_COLUMN_MODEMS_DETAILS');
        this._HEADER_FIELDS.nodeMapping.name = localizationService.instant('NODE_TAB_COLUMN_NODE_MAPPING');
        this._HEADER_FIELDS.noiseTrakMapping.name = localizationService.instant('NODE_TAB_COLUMN_NOISETRAK_MAPPING');
        this._NONE = localizationService.instant('NONE');

        this._HEADER_FIELDS.daaDevice.name = localizationService.instant('NODE_TAB_COLUMN_DAA_DEVICE');
        this._HEADER_FIELDS.cmtsUsPortName.name = localizationService.instant('NODE_TAB_COLUMN_UPSTREAM_PORT');
        this._HEADER_FIELDS.fiberNode.name = localizationService.instant('NODE_TAB_COLUMN_FIBER_NODE');
        this._HEADER_FIELDS.macDomain.name = localizationService.instant('NODE_TAB_COLUMN_MAC_DOMAIN');
        this._HEADER_FIELDS.serviceGroup.name = localizationService.instant('NODE_TAB_COLUMN_SERVICE_GROUP');
        this._HEADER_FIELDS.upstreamServiceGroup.name = localizationService.instant('NODE_TAB_COLUMN_UPSTREAM_SERVICE_GROUP');
        this._HEADER_FIELDS.downstreamServiceGroup.name = localizationService.instant('NODE_TAB_COLUMN_DOWNSTREAM_SERVICE_GROUP');
        this._HEADER_FIELDS.pnmLicensed.name = localizationService.instant('NODE_TAB_COLUMN_PNM_LICENSED');
        this._HEADER_FIELDS.qoeLicensed.name = localizationService.instant('NODE_TAB_COLUMN_QOE_LICENSED');
        this._HEADER_FIELDS.modemAnalyserLicensed.name = localizationService.instant('NODE_TAB_COLUMN_DOCSIANALYZER_LICENSED');
        this._HEADER_FIELDS.modemHealthLicensed.name = localizationService.instant('NODE_TAB_COLUMN_MODEM_HEALTH_LICENSED');
        this._HEADER_FIELDS.modemLiveAnalyzerLicensed.name = localizationService.instant('NODE_TAB_COLUMN_MODEM_LIVE_ANALYZER_LICENSED');
        this._HEADER_FIELDS.modemHistoryLicensed.name = localizationService.instant('NODE_TAB_COLUMN_MODEM_HISTORY_LICENSED');
        this._HEADER_FIELDS.topologyAlarmLicensed.name = localizationService.instant('NODE_TAB_COLUMN_TOPOLOGY_ALARM_LICENSED');
        this._HEADER_FIELDS.topologyOutageLicensed.name = localizationService.instant('NODE_TAB_COLUMN_TOPOLOGY_OUTAGE_LICENSED');
        this.trueValue = localizationService.instant('TRUE');
        this.falseValue = localizationService.instant('FALSE');
        this.default = localizationService.instant('DEFAULT');
    }

    
    public buildFilter(column) {
        let columnFilterParams = <SelectBoxFilterParams>{
            noSelectionDisplay: this.default,
            valuePassesFilter: (row, filter) => row.data[column] == filter,
            values: [{
                value: true,
                display: this.trueValue
            }, {
                value: false,
                display: this.falseValue
            }]
        };

        return columnFilterParams;
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {

        this.translateLocaleStr();
        BooleanFilter.setBoolValue(
            {
                default: this.default,
                true: this.trueValue,
                false: this.falseValue
            }
        );

        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.nodeName.name,headerTooltip:this._HEADER_FIELDS.nodeName.name,
                field: this._HEADER_FIELDS.nodeName.field,
                sort: "asc",
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.nodeName.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                pinned: true,
                cellRenderer: ((param:any)=>{
                    if(!param.value || !param.data) { return "<div></div>"; }
                    let url = this.urlService.getRedirectAnalysisUrl('node',param.data.nodeId);
                    return "<a class='cursorClass' target='_blank' href='" + url + "'>" + param.value + "</a>";
                })
            },
            {
                headerName: this._HEADER_FIELDS.modems.name,headerTooltip:this._HEADER_FIELDS.modems.name, field: this._HEADER_FIELDS.modems.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modems.name, 60),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.cmts.name,headerTooltip:this._HEADER_FIELDS.cmts.name, field: this._HEADER_FIELDS.cmts.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.cmts.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.daaDevice.name,headerTooltip:this._HEADER_FIELDS.daaDevice.name, field: this._HEADER_FIELDS.daaDevice.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.daaDevice.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.cmtsUsPortName.name,headerTooltip:this._HEADER_FIELDS.cmtsUsPortName.name, field: this._HEADER_FIELDS.cmtsUsPortName.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.cmtsUsPortName.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                cellRenderer: ((param:any)=>{
                    if(!param.value || !param.data) { return "<div></div>"; }
                    let url = this.urlService.getRedirectAnalysisUrl('cmts_us_port',param.data.cmtsUsPortId);
                    return "<a class='cursorClass' target='_blank' href='" + url + "'>" + param.value + "</a>";
                })
            },
            {
                headerName: this._HEADER_FIELDS.fiberNode.name,headerTooltip:this._HEADER_FIELDS.fiberNode.name, field: this._HEADER_FIELDS.fiberNode.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.fiberNode.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.macDomain.name,headerTooltip:this._HEADER_FIELDS.macDomain.name, field: this._HEADER_FIELDS.macDomain.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.macDomain.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.serviceGroup.name,headerTooltip:this._HEADER_FIELDS.serviceGroup.name, field: this._HEADER_FIELDS.serviceGroup.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serviceGroup.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.upstreamServiceGroup.name,headerTooltip:this._HEADER_FIELDS.upstreamServiceGroup.name, field: this._HEADER_FIELDS.upstreamServiceGroup.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.upstreamServiceGroup.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.downstreamServiceGroup.name,headerTooltip:this._HEADER_FIELDS.downstreamServiceGroup.name, field: this._HEADER_FIELDS.downstreamServiceGroup.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.downstreamServiceGroup.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.billingNode.name,headerTooltip:this._HEADER_FIELDS.billingNode.name, field: this._HEADER_FIELDS.billingNode.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.billingNode.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.rci.name,headerTooltip:this._HEADER_FIELDS.rci.name, field: this._HEADER_FIELDS.rci.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rci.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.hcu.name,
                headerTooltip:this._HEADER_FIELDS.hcu.name, 
                field: this._HEADER_FIELDS.hcu.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.hcu.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.rphyVendor.name,
                headerTooltip:this._HEADER_FIELDS.rphyVendor.name, 
                field: this._HEADER_FIELDS.rphyVendor.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rphyVendor.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this._HEADER_FIELDS.rpmPort.name,headerTooltip:this._HEADER_FIELDS.rpmPort.name, field: this._HEADER_FIELDS.rpmPort.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rpmPort.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                cellRenderer: ((param:any)=>{
                    if(!param.value || !param.data) { return "<div></div>"; }
                    let url = this.urlService.getRedirectAnalysisUrl('port',param.data.rpmPortId);
                    return "<a class='cursorClass' target='_blank' href='" + url + "'>" + param.value + "</a>";
                })
            },
            {
                headerName: this._HEADER_FIELDS.rpmPortMapTyp.name,
                headerTooltip:this._HEADER_FIELDS.rpmPortMapTyp.name, 
                field: this._HEADER_FIELDS.rpmPortMapTyp.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                cellRenderer: ((param:any)=>{
                    let val:string = "";
                    if(param.value === "NONE"){
                        val = this._NONE;
                    }else {
                        val = param.value;
                    }
                    return val;
                })
            },
            {
                headerName: this._HEADER_FIELDS.icsCount.name,
                headerTooltip:this._HEADER_FIELDS.icsCount.name, 
                field: this._HEADER_FIELDS.icsCount.field,
                minWidth: 90,
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.pnmLicensed.name,headerTooltip:this._HEADER_FIELDS.pnmLicensed.name, field: this._HEADER_FIELDS.pnmLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.pnmLicensed.name, 150),
                editable: false,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true,
                    newRowsAction: 'keep' 
				}, this.buildFilter("pnmLicensed")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, this.buildFilter("pnmLicensed")),
				valueFormatter: v => v.value ? this.trueValue : this.falseValue,
				exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.qoeLicensed.name,headerTooltip:this._HEADER_FIELDS.qoeLicensed.name, field: this._HEADER_FIELDS.qoeLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.qoeLicensed.name, 150),
                editable: false,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true ,
                    newRowsAction: 'keep'
				}, this.buildFilter("qoeLicensed")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, this.buildFilter("qoeLicensed")),
				valueFormatter: v => v.value ? this.trueValue : this.falseValue,
				exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.modemAnalyserLicensed.name,headerTooltip:this._HEADER_FIELDS.modemAnalyserLicensed.name, field: this._HEADER_FIELDS.modemAnalyserLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modemAnalyserLicensed.name, 150),
                editable: false,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true ,
                    newRowsAction: 'keep'
				}, this.buildFilter("modemAnalyserLicensed")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, this.buildFilter("modemAnalyserLicensed")),
				valueFormatter: v => v.value ? this.trueValue : this.falseValue,
				exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            /*{
                headerName: this._HEADER_FIELDS.modemHealthLicensed.name,headerTooltip:this._HEADER_FIELDS.modemHealthLicensed.name, field: this._HEADER_FIELDS.modemHealthLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modemHealthLicensed.name, 60),
                editable: false,
                filter: SelectBoxFilter,
                filterParams: Object.assign({
                    newRowsAction: 'keep'
                }, this.buildFilter("modemHealthLicensed")),
                floatingFilterComponent: SelectBoxFilter.FloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                }, this.buildFilter("modemHealthLicensed")),
                valueFormatter: v => v.value ? this.trueValue : this.falseValue,
                exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },*/
            {
                headerName: this._HEADER_FIELDS.modemLiveAnalyzerLicensed.name,headerTooltip:this._HEADER_FIELDS.modemLiveAnalyzerLicensed.name, field: this._HEADER_FIELDS.modemLiveAnalyzerLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modemLiveAnalyzerLicensed.name, 60),
                editable: false,
                filter: BooleanFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true ,
                    newRowsAction: 'keep'
                }, this.buildFilter("modemLiveAnalyzerLicensed")),
                floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                }, this.buildFilter("modemLiveAnalyzerLicensed")),
                valueFormatter: v => v.value ? this.trueValue : this.falseValue,
                exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.modemHistoryLicensed.name,headerTooltip:this._HEADER_FIELDS.modemHistoryLicensed.name, field: this._HEADER_FIELDS.modemHistoryLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modemHistoryLicensed.name, 60),
                editable: false,
                filter: BooleanFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true,
                    newRowsAction: 'keep'
                }, this.buildFilter("modemHistoryLicensed")),
                floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                }, this.buildFilter("modemHistoryLicensed")),
                valueFormatter: v => v.value ? this.trueValue : this.falseValue,
                exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.topologyAlarmLicensed.name,headerTooltip:this._HEADER_FIELDS.topologyAlarmLicensed.name, field: this._HEADER_FIELDS.topologyAlarmLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.topologyAlarmLicensed.name, 60),
                editable: false,
                filter: BooleanFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true,
                    newRowsAction: 'keep'
                }, this.buildFilter("topologyAlarmLicensed")),
                floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                }, this.buildFilter("topologyAlarmLicensed")),
                valueFormatter: v => v.value ? this.trueValue : this.falseValue,
                exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.topologyOutageLicensed.name,headerTooltip:this._HEADER_FIELDS.topologyOutageLicensed.name, field: this._HEADER_FIELDS.topologyOutageLicensed.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.topologyOutageLicensed.name, 60),
                editable: false,
                filter: BooleanFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true,
                    newRowsAction: 'keep'
                }),
                floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                }),
                valueFormatter: v => v.value ? this.trueValue : this.falseValue,
                exportFormatter: v => v.value ? this.trueValue : this.falseValue,
            },
            {
                headerName: this._HEADER_FIELDS.noiseTrakMapping.name,headerTooltip:this._HEADER_FIELDS.noiseTrakMapping.name, field: this._HEADER_FIELDS.noiseTrakMapping.field,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                minWidth: 100,
                sortingOrder: [null],
                suppressSorting : true,
                suppressMenu: true,
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                pinned: this.sharedService.isPinned(),
                cellRenderer: ((param:any)=>{
                    let data = param.data;
                    let gui = document.createElement('div');
                    if(!data || !data.modems) { return gui;}
                    gui.innerHTML = EXTERNAL_LINK_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param, false, true);
                    }));
                    gui.className = data?.icsCount > 0 ? "ag-Grid-cursor" : "d-none"
                    return gui;
                })
            },
            {
                headerName: this._HEADER_FIELDS.viewModems.name,headerTooltip:this._HEADER_FIELDS.viewModems.name, field: this._HEADER_FIELDS.viewModems.field,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                minWidth: 100,
                sortingOrder: [null],
                suppressSorting : true,
                suppressMenu: true,
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                pinned: this.sharedService.isPinned(),
                cellRenderer: ((param:any)=>{
                    let data = param.data;
                    let gui = document.createElement('div');
                    if(!data || !data.modems) { return gui;}
                    gui.innerHTML = EXTERNAL_LINK_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param, false, false);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            },
            {
                headerName: this._HEADER_FIELDS.nodeMapping.name,headerTooltip:this._HEADER_FIELDS.nodeMapping.name, field: this._HEADER_FIELDS.nodeMapping.field,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                minWidth: 100,
                sortingOrder: [null],
                suppressSorting : true,
                suppressMenu: true,
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                pinned: this.sharedService.isPinned(),
                cellRenderer: ((param:any)=>{
                    let data = param.data;
                    // console.log("\ndata is\n"+ JSON.stringify(data));
                    let gui = document.createElement('div');
                    if(!data && !data.modems) { return gui;}
                    gui.innerHTML = EXTERNAL_LINK_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param, true, false);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            }
        ]
        console.log('build filter', this.buildFilter("modemAnalyserLicensed"));
        return columnDef;
    }

    //@method :: callback action for view modem in new page
    private action(param: any, isNodeMapping: boolean, isNoiseTrakMapping:boolean): void{
        let externalUrl = (isNodeMapping) ? this.urlService.getNodeMappingByIDUrl() + param.data.nodeId : (isNoiseTrakMapping) ? this.urlService.getNoiseTrakMappingByIDUrl() + param.data.nodeId : this.urlService.getRedirectModemUrl() + param.data.nodeId;

        if (externalUrl) {
            window.open(externalUrl);
        } else {
            console.error("redirectToExternalView: url is not valid=", externalUrl);
        }
    }

    /*
     *@name exportAll
     *@desc Export data-grid row data
     *@param dataGridOption, excludeColumns[], gridDisplay, isTimeLocalization
     *@return void
     */
    public exportAll(dataGridOption: any, excludeColumns: string[], gridDisplay: boolean, isTimeLocalization: boolean): void {
        this.dataGridOption = dataGridOption;
        let keys: string[] = this.getkeys(excludeColumns, gridDisplay);
        let params: any = {
            processHeaderCallback: this.getvalues,
            columnKeys: keys,
            allColumns: false
        };

        dataGridOption.api.exportDataAsCsv(params);
    }

    /*
     *@name exportOnlySelected
     *@desc Export only selected row data from data-grid
     *@param dataGridOption, excludeColumns[], gridDisplay, isTimeLocalization
     *@return void
     */
    public exportOnlySelected(dataGridOption: any, excludeColumns: string[], gridDisplay: boolean, isTimeLocalization: boolean): void {
        this.dataGridOption = dataGridOption;
        let keys: string[] = this.getkeys(excludeColumns, gridDisplay);
        let selectedRows: any = this.getSelectedRows(dataGridOption);
        let params: any = {
            processHeaderCallback: this.getvalues,
            onlySelected: selectedRows,
            columnKeys: keys,
            allColumns: false
        };

        dataGridOption.api.exportDataAsCsv(params);
    }

    /*
     *@name getkeys
     *@desc Get columns name
     *@param excludeColumns[], gridDisplay
     *@return string[]
     */
    private getkeys(excludeColumns: string[], gridDisplay: boolean): string[] {
        let keys: string[] = [];
        let displayed: any = gridDisplay ? this.dataGridOption.columnApi.getAllDisplayedColumns() : this.dataGridOption.columnApi.getAllGridColumns();
        let hideColumn: boolean = false;
        for (let i = 0; i < displayed.length; i++) {
            excludeColumns.forEach((columnName) => {
                if (displayed[i].colId == columnName) {
                    hideColumn = true;
                }
            });
            if (hideColumn) {
                hideColumn = false;
                continue;
            } else {
                keys.push(displayed[i].colId);
            }
        }
        return keys;
    }
    /*
     *@name getvalues
     *@desc Get processed data-grid header name
     *@param params
     *@return string
     */
    private getvalues(params: any): string {
        let headerName: string = params.column.colDef.headerName;
        let spanRemovedHeader: string = vm.formateString(headerName);
        return spanRemovedHeader;
    }

    //Method to get selected row
    public getSelectedRows(dataGridOption: any): any[] {
        return dataGridOption.api.getSelectedRows();
    }

    //Method to format string
    private formateString(headerName: string): string {
        return headerName.replace(/<span class="badge">*\d/, "").replace("</span>", "");
    }

}
