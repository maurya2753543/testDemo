/**
 * Created by Mehjabeen.Bari on 6/9/2017.
 */

import {Injectable} from "@angular/core";
import {CMTSHttpService} from "../cmts.http.service";
import {Observable, throwError} from "rxjs";
import {map, catchError} from "rxjs/operators";
//import {NodeModel} from "./node-tab.model";
import {NodeTabService} from "./node-tab.service";
import {NodeModel} from "./node-tab.model";
import { LocaleDataService } from "./../../../shared/locale.data.service";

@Injectable()
export class NodeTabDataService{

    private tag: string = "NodeTabDataService:: ";
    public nodetabfilterchangedata: any;

    private nodeList : Array<NodeModel> = new Array<NodeModel>();

    constructor(private cmtsHttpService: CMTSHttpService, private nodeTabService: NodeTabService, private localeDataService:LocaleDataService){}

    /*Method to get Node list from server*/
    public getNodeList(): Observable<any> {
        this.nodeList = [];
        return this.cmtsHttpService
            .getNodeListData()
            .pipe(map((nodeListDataObj) => {
                this.setNodeList(nodeListDataObj);
                return this.nodeList;
            }),
            catchError(this.handleError))
    }

    public deleteNode(id: number): Observable<any>{
        return this.cmtsHttpService.deleteNode(id)
        .pipe(map(()=>{
            return true;
        }),catchError(this.handleError))
    }

    public editNode(nodeData: any): Observable<any>{
        return this.cmtsHttpService.editNode(nodeData)
        .pipe(map(()=>{
            return true;
        }),catchError(this.handleError))
    }


    /*Method to add greenfield Node to server*/
    public addGreenFieldNode(newNodeData: Object): Observable<any> {
        return this.cmtsHttpService
            .postAddGreenFieldNode(this.getJSONData(newNodeData))
            .pipe(map((greenFieldNodeRes) => {
                return greenFieldNodeRes;
            }),
            catchError(this.handleError))
    }

    /*method to get data in required json format*/
    private getJSONData(newNodeData: Object): Object{
        return {
            "node": newNodeData['node'],
            "mac": newNodeData['mac'],
            "cmtsId": newNodeData['selectedCMTSId'].toString()
        }
    }

    /*Method to handle error*/
    public handleError(error) {
        return throwError(error);
    }

    /*Method to set Node list*/
    public setNodeList(dataListObj): void {

        for(let i=0; i<dataListObj.length; i++) {
            let nodeModel : NodeModel = new NodeModel(dataListObj[i], this.localeDataService.getLocalizationService());
            this.nodeList.push(nodeModel);
        }  
    }

    /*Method to get node from node list with index*/
    public getNodeModel(index : number) : NodeModel {
        if(this.nodeList && index > 0){
            return this.nodeList[index];
        }
        return null;
    }

    /*Method to get node array*/
    public getNodeArray() : Array<NodeModel> {
        if(this.nodeList) {
            return this.nodeList;
        }
        return null;
    }

    /*Method to get nodelist size*/
    public getNodeListSize() : number {
        if(this.nodeList){
            return this.nodeList.length;
        }

        return 0;

    }



}