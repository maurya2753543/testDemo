/*
 * Viavi-XPERTrak-GlobalLogic
*/

import {Component, EventEmitter, Input, Output} from "@angular/core";

import {NodeTabDataService} from "../node-tab.data.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {NODE_FACTOR} from "../../../../constant/app.constants";

@Component({
    templateUrl: 'edit-view.component.html',
    selector: 'node-edit-view'
})
export class EditViewComponent {
    // isSaveBtnDisabled: boolean = true;

    public nodePostData: any;
    public isReadOnly: boolean = true;
    public isReadOnlyName = true;
    public errorMessages: any = {
        isNameEmpty: false
    };

    @Output() closeSliderEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private nodeTabDataService: NodeTabDataService,
                private showAlert: ShowAlert){}

    @Input() private set nodeData(nodeData: number) {
      if(nodeData){
          this.nodePostData = JSON.parse(JSON.stringify(nodeData));
          if(this.nodePostData.rphy && this.nodePostData.billingNodeId ==0){
              this.isReadOnlyName = false;
          }
      }
    }

    public closeSlider(refreshList: boolean = false): void{
        this.closeSliderEvent.emit(refreshList);
    }

    public toggleEdit(): void{
        this.isReadOnly = false;
    }

    public isNameEmpty(): void{
        this.errorMessages.isNameEmpty = (this.nodePostData.nodeName.length === 0);
    }

    public onSubmit(): void{
       this.nodePostData.name = this.nodePostData.nodeName;
       this.nodeTabDataService.editNode(this.nodePostData).subscribe(this.closeSlider.bind(this), this.onError.bind(this));       
    }

    private onAlertCallBack(): void{
        this.closeSlider();
    }
    /* Handle error & show sweet alert */
    private onError(error) {
        this.showAlert.showAlertWithCallBack(error, this.onAlertCallBack.bind(this), NODE_FACTOR);
    }
}
