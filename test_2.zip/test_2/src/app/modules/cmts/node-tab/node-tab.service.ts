/**
 * Created by Mehjabeen.Bari on 6/9/2017.
 */

import {Injectable} from "@angular/core";
import {NodeModel} from "./node-tab.model";
import {Subject} from "rxjs";

@Injectable()
export class NodeTabService{

    private tag: string = "NodeTabService:: ";
    private nodeAddedEventSubject: Subject<any>;

    constructor(){
        this.initSubjects();
    }

    /*Method to initialize subject*/
    private initSubjects(): void{
        this.nodeAddedEventSubject = new Subject();
    }

    /*Method to get add node event to the node list component*/
    public getAddNodeEventSubject(): Subject<any>{
        return this.nodeAddedEventSubject;
    }

    /*Method to get selected node rows*/
    public getSelectedRowsNodeIds(nodeModels: NodeModel[], selectedRowsCmtsId: number[]): void{
        nodeModels.forEach(( nodeModel: NodeModel)=> {
            selectedRowsCmtsId.push(nodeModel.nodeId);
        });
    }

    /*Method to restore checkbox selection in case of list refresh*/
    public restoreSelection(selectedRowsNodeId: number[], nodeTabGridOptionsAPI: any): void{
        if(selectedRowsNodeId.length >= 1){
            nodeTabGridOptionsAPI.forEachNode((node)=>{
                for(let i = 0; i < selectedRowsNodeId.length; i ++){
                    if (node.data.nodeId === selectedRowsNodeId[i]) {
                        node.setSelected(true);
                        break;
                    }// End of if
                }// End of For
            });// End of forEachNode
        }// End of If
    }

}