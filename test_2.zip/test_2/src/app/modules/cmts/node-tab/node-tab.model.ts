/**
 * Created by Mehjabeen.Bari on 6/9/2017.
 */

export class NodeModel{

    public nodeId: number;
    public nodeName: string;
    public cmts: string;
    public cmtsNode: string;
    public rphy: boolean;
    public rphyVendor:string;
    public modems: number;
    public hcu: string;
    public rpmPort: string;
    public rpmPortMapTyp: string;
    public billingNode: string;
    public billingNodeId: number;

    public rci: string;
    public icsCount: number;
    public daaDevice: string;
    public cmtsUsPortId: number;
    public fiberNode: string;
    public macDomain: string;
    public serviceGroup: string;
    public upstreamServiceGroup: string;
    public downstreamServiceGroup: string;
    public pnmLicensed: boolean;
    public qoeLicensed: boolean;
    public modemAnalyserLicensed: boolean;
    public rpmPortId: number;
    public cmtsUsPortName: string;
    public modemHistoryLicensed: boolean;
    public modemLiveAnalyzerLicensed: boolean;
    public modemHealthLicensed: boolean;
    public topologyAlarmLicensed: boolean;
    public topologyOutageLicensed: boolean;

    constructor(_nodeData, localizationService:any){
        if(_nodeData) {
            this.nodeId = _nodeData.nodeId;
            this.nodeName = _nodeData.name ? _nodeData.name : '';
            this.cmts = _nodeData.cmts ? _nodeData.cmts : '';
            this.cmtsNode = _nodeData.cmtsNode ? _nodeData.cmtsNode : '';
            this.rphy = _nodeData.rphy;
            this.rphyVendor = _nodeData.rphyVendor;
            this.modems = _nodeData.modems;
            this.hcu = _nodeData.hcu ? _nodeData.hcu : '';
            this.rpmPort = _nodeData.rpmPort ? _nodeData.rpmPort : '';
            this.rpmPortMapTyp = _nodeData.rpmPortMapTyp ? _nodeData.rpmPortMapTyp : '';
            this.billingNodeId = _nodeData.billingNodeId;
            this.billingNode = _nodeData.billingNode ? _nodeData.billingNode : '';
            this.icsCount = _nodeData.icsCount;

            this.rci = _nodeData.rci ? _nodeData.rci : '';
            this.daaDevice = _nodeData.rphyMac ? _nodeData.rphyMac : '';
            this.cmtsUsPortId = _nodeData.cmtsUsPortId ? _nodeData.cmtsUsPortId : '';
            this.fiberNode = _nodeData.cmtsNode ? _nodeData.cmtsNode : '';
            this.macDomain = _nodeData.macDomain ? _nodeData.macDomain : '';
            this.serviceGroup = _nodeData.serviceGroup ? _nodeData.serviceGroup : '';
            this.upstreamServiceGroup = _nodeData.upstreamServiceGroup ? _nodeData.upstreamServiceGroup : '';
            this.downstreamServiceGroup = _nodeData.downstreamServiceGroup ? _nodeData.downstreamServiceGroup : '';
            this.pnmLicensed = _nodeData.pnmLicensed;
            this.qoeLicensed = _nodeData.qoeLicensed;
            this.modemAnalyserLicensed = _nodeData.modemAnalyserLicensed;
            this.rpmPortId = _nodeData.rpmPortId ? _nodeData.rpmPortId : '';
            this.cmtsUsPortName = _nodeData.cmtsUsPortName ? _nodeData.cmtsUsPortName : '';

            this.modemLiveAnalyzerLicensed = _nodeData.modemLiveAnalyzerLicensed ? _nodeData.modemLiveAnalyzerLicensed : '';
            this.modemHealthLicensed = _nodeData.modemHealthLicensed ? _nodeData.modemHealthLicensed : '';
            this.modemHistoryLicensed = _nodeData.modemHistoryLicensed ? _nodeData.modemHistoryLicensed : '';
            this.topologyAlarmLicensed = _nodeData.topologyAlarmLicensed ? _nodeData.topologyAlarmLicensed : '';
            this.topologyOutageLicensed = _nodeData.topologyOutageLicensed ? _nodeData.topologyOutageLicensed : '';
        }
    }

}

