import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { CommonModule, registerLocaleData } from '@angular/common';
import {UiSwitchModule} from "ngx-ui-switch";

import {LocaleDataService} from "../../shared/locale.data.service";
import {CMTSComponent} from "./cmts.component";
import {CMTSTabComponent} from "./cmts-tab/cmts-tab.component";
import {NODETabComponent} from "./node-tab/node-tab.component";
import {MODEMTabComponent} from "./modem-tab/modem-tab.component";
import {CmtsRoutes} from "./cmts.route";
import {CMTSHttpService} from "./cmts.http.service";
import {CmtsTabDataService} from "./cmts-tab/cmts-tab.data.service";
import {NodeTabDataService} from "./node-tab/node-tab.data.service";
import {NodeTabService} from "./node-tab/node-tab.service";
import {NodeTabColumnDefinitionService} from "./node-tab/node-tab.column-definition.service";
import {CMTSUrlService} from "./cmts.url.service";
import { SharedModule } from "../shared/shared.module";

import {CmtsViewComponent} from "./cmts-tab/cmts-view/cmts-view.component";
import {CmtsTabSharedService} from "./cmts-tab.shared.service";

import {ModemTabColumnDefinitionService} from "./modem-tab/modem-tab.column-definition.service";
import {ModemTabDataService} from "./modem-tab/modem-tab.data.service";
import {ImportModemComponent} from "./cmts-tab/import-modem/import-modem.component";
import {ImportCmtsComponent} from "./cmts-tab/import-cmts/import-cmts.component";
import {ImportNoisetrakComponent} from "./cmts-tab/import-noisetrak/import-noisetrak.component";

import {NodeTabFormComponent} from "./node-tab/node-tab-form/node-tab.form.component";
import {CmtsTabService} from "./cmts-tab/cmts-tab.service";
import {CmtsTabColumnDefinitionService} from "./cmts-tab/cmts-tab.column-definition.service";

import {CmtsFeatureComponent} from "./cmts-tab/cmts-feature/cmts-feature.component";
import {CmtsFeatureService} from "./cmts-tab/cmts-feature/cmts-feature.service";
import {NumberDirective} from "./cmts-tab/import-modem/number-input.directive";
import { ContainerUrlService } from './../container/container-url.service';
import { ContainerHttpService } from './../container/container-http.service';
import { ContainerDataService } from './../container/container.data.service';
import {SitesHTTPService} from './../sites/sites.http.service';
import {SitesUrlService} from '../sites/sites.url.service';
import {SiteListDataService} from '../sites/site-list/site-list.data.service';
import {SitesHttpServiceMock} from '../sites/sites.http.service.mock';
import {CMTSViewEvent} from "./view-events/view-event.component";
import {ViewEventsColumnDefinitionService} from "../shared/common-components/listView/viewEvents.column-definition.service";
import {CMTSDataService} from "./cmts.data.service";
import {EditViewComponent} from "./node-tab/edit-view/edit-view.component";
import {UndefinedTextToDashPipe} from "../../pipes/undefined-text-to-dash.pipe";
import { CmtsControlFeaturesComponent } from './cmts-tab/cmts-control-features/cmts-control-features.component';
import {CmtsConfigureComponent} from "./cmts-tab/cmts-configure/cmts-configure.component";
import {ValidationPipe} from "./cmts-tab/cmts-configure/validation.pipe";
import {AlarmableModemTabComponent} from './alarmableModem-tab/alarmableModem-tab.component';
import {AlarmableModemTabColumnDefinitionService} from './alarmableModem-tab/alarmable-modem-tab-column-definition.service';
import {AlarmableModemTabDataService} from './alarmableModem-tab/alarmableModem-tab.data.service';
import {AlarmableModemViewComponent} from './alarmableModem-tab/alarmableModem-view/alarmableModem-view.component';
import {AlarmableModemSharedService} from './alarmableModem-tab/alarmableModem.shared.service';
import {modemSearchComponent} from '../shared/modem-search/modemSearch.component';
import {AlarmableModemTabService} from './alarmableModem-tab/alarmableModem-tab.service';
import {ModemWatchTabComponent} from './modemWatch-tab/modem-watch-tab.component';
import {ModemWatchViewComponent} from './modemWatch-tab/modemWatch-view/modem-watch-view.component';
import {ModemWatchTabDataService} from './modemWatch-tab/modem-watch-tab.data.service';
import {ModemWatchSharedService} from './modemWatch-tab/modem-watch.shared.service';
import {ModemWatchTabService} from './modemWatch-tab/modem-watch-tab.service';
import {ModemWatchTabColumnDefinitionService} from './modemWatch-tab/modem-watch-tab-column-definition.service';
import {ModemWatchHttpService} from './modemWatch-tab/modem-watch.http.service';
import {ModemWatchUrlService} from './modemWatch-tab/modem-watch.url.service';
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { LanguageService } from 'src/app/shared/locale.language.service';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';

import { SystemSettingsDataService } from '../system-settings/system-settings.data.service';
import { AgGridModule } from 'ag-grid-angular';
import CmtsControlFeatureConfigService from './cmts-tab/cmts-control-features/cmtsControlFeature.configuration.service';
import { SystemSettingsHttpService } from '../system-settings/system-settings.http.service';
import { SystemSettingsUrlService } from '../system-settings/system-settings.url.service';
import { MultiRangeSliderService } from '../shared/multi-range/multi-range.service';
//import { MultiRangeComponent } from '../system-settings/directive/multi-range/multi-range.component';
import { SystemSettingService } from '../system-settings/system-setting.service';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/cmts-locale-`, ".json");
  }
  
@NgModule({
    imports: [
        //AgGridModule.withComponents([GridComponent]),
        SharedModule,
        FormsModule,
        CmtsRoutes,
        CommonModule,
       // LocaleModule.forRoot(),
       UiSwitchModule,
       // LocalizationModule.forRoot(),
        ReactiveFormsModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),
        
    ],
    declarations: [
        CMTSComponent,
        CMTSTabComponent,
        NODETabComponent,
        MODEMTabComponent,
        ImportModemComponent,
        ImportNoisetrakComponent,
        //GridComponent
        CmtsViewComponent,
        NodeTabFormComponent,
        NumberDirective,
        CMTSViewEvent,
        EditViewComponent,
        UndefinedTextToDashPipe,
        CmtsFeatureComponent,
        CmtsControlFeaturesComponent,
        CmtsConfigureComponent,
        ValidationPipe,
		ImportCmtsComponent,
        AlarmableModemTabComponent,
        AlarmableModemViewComponent,
        modemSearchComponent,
        ModemWatchTabComponent,
        ModemWatchViewComponent
       // MultiRangeComponent
    ],
    entryComponents: [
        CMTSTabComponent,
        NODETabComponent,
        MODEMTabComponent,
        CmtsViewComponent,
        ImportModemComponent,
        ImportNoisetrakComponent,
        NodeTabFormComponent,
        CMTSViewEvent,
        CmtsFeatureComponent,
        CmtsControlFeaturesComponent,
        AlarmableModemTabComponent,
        AlarmableModemViewComponent,
        ModemWatchTabComponent,
        ModemWatchViewComponent
    ],
    providers: [
        LocaleDataService,
        CMTSHttpService,
        CmtsTabDataService,
        NodeTabDataService,
        NodeTabService,
        CMTSDataService,
        ModemTabDataService,
        CMTSUrlService,
        CmtsTabColumnDefinitionService,
        NodeTabColumnDefinitionService,
        ModemTabColumnDefinitionService,
        CmtsTabSharedService,
        CmtsTabService,
        ContainerDataService,
        ContainerHttpService,
        ContainerUrlService,
        SitesHTTPService,
        SitesUrlService,
        SiteListDataService,
        SitesHttpServiceMock,
        ViewEventsColumnDefinitionService,
        CmtsFeatureService,
        AlarmableModemTabColumnDefinitionService,
        AlarmableModemTabDataService,
        AlarmableModemSharedService,
        AlarmableModemTabService,
        ModemWatchTabColumnDefinitionService,
        ModemWatchTabDataService,
        ModemWatchSharedService,
        ModemWatchTabService,
        ModemWatchHttpService,
        ModemWatchUrlService,
        TranslateService,
        LanguageService,
        SystemSettingsDataService,
        MultiRangeSliderService,
        CmtsControlFeatureConfigService,
        SystemSettingsHttpService,
        SystemSettingsUrlService,
        SystemSettingService
    ]
})

export class CMTSModule {

}
