import {Injectable} from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import {HttpResponse} from "@angular/common/http";
import {map, catchError} from "rxjs/operators";

import {ViewEventsModel} from "../shared/common-components/models/viewEvents.model";
import {LocaleDataService} from "../../shared/locale.data.service";
import {CMTSHttpService} from "./cmts.http.service";
import {ThresholdModel} from "../shared/common-components/models/threshold.model";
import {ThresholdService} from "../shared/threshold.service";

@Injectable()

export class CMTSDataService {
    private localService:any;
    private selectedTab: string;
    public cmtsmodeldata: any;
    public cmtsmodeldata1: any;
    public OSInfo$: BehaviorSubject<any> = new BehaviorSubject<string>('');

    constructor(private cmtsHttpService:CMTSHttpService,
                private thresholdService: ThresholdService,
                private localeDataService:LocaleDataService){
        this.localService = this.localeDataService.getLocalizationService();
    }

    //Method to get HCU EVENTS list
    public getEventListData(elementID: any, type: string): Observable<any> {
        return this.cmtsHttpService
            .getEventList(elementID, type)
            .pipe(map((eventListDataObj: HttpResponse<any>) => {
                return new ViewEventsModel(eventListDataObj, this.localService);
            }),
            catchError(this.handleError))
    }

    public getThresholdsName(): Observable<any>{
        return this.cmtsHttpService
            .getThresholdLabels()
            .pipe(map((resObj: any[])=>{
                const thresholds: any[] = resObj;
                this.setThresholds(thresholds);
                return this.processThresholdsName(thresholds);
            }),
            catchError(this.handleError))
    }

    private setThresholds(thresholds: any[]): void {
        const obj: any = {};
        thresholds.forEach((threshold: any, index: number) => {
            obj["threshold".concat((index + 1).toString(), "Label")] = threshold.value;
        });
        this.thresholdService.thresholdList = obj;
    }

    private processThresholdsName(res: any[]): ThresholdModel[]{
        let thresholdModels: ThresholdModel[] = [];
        res.forEach((obj: any)=>{
            thresholdModels.push(obj);
        });
        return thresholdModels;
    }

    getTab(){
        return this.selectedTab;
    }

    setTab(value: string){
        this.selectedTab = value;
    }

    public OSInfoStatus() {
        this.cmtsHttpService.getOSInfo().subscribe(response => {
           const info = response && response['operatingSystem'];
           this.OSInfo$.next(info);
        })
    }

    //Error handler
    public handleError(error) {
        return throwError(error);
    }
}
