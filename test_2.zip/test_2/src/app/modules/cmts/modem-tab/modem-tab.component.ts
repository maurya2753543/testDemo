import {Component, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/toPromise';

import {Grid} from "../../../shared/ag-grid.options";
import {ModemTabColumnDefinitionService} from "./modem-tab.column-definition.service";
import {ModemTabDataService} from "./modem-tab.data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {Logger} from "../../../utilities/logger";
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import {ɵBrowserDomAdapter} from "@angular/platform-browser";
import {LocaleDataService} from "../../../shared/locale.data.service";
import * as cstmConstants from "../cmts-tab.constants";
import {NO_FAILED_MODEMS} from "../../../constant/app.constants";

@Component({
    selector: 'modemtab-component',
    templateUrl: 'modem-tab.component.html'
})

export class  MODEMTabComponent {
    dom:any = ɵBrowserDomAdapter;
    private modemTabGridOptions: Grid = new Grid();
    private jsonData: any;
    private modemTabGridRowData:any;
    private tag: string = "MODEMTabComponent:: ";
    private gridTabType:string = "MODEMExport";
    @ViewChild('targetImportMODEM', {read: ViewContainerRef}) _targetImportMODEM;

    private CMTS_MODEM_BTN_EXPORT_GEOCODE: string = "";
    private CMTS_MODEM_BTN_PERFORM_GEOCODING: string = "";
    private TABLE_LIST_EXPORT_SELECTED: string = "";
    private TABLE_LIST_EXPORT_ALL: string = "";
    private NO_FAILED_MODEMS: string = "";
    private GEOCODING_INITIATED: string = "";

    private eventKeys: Object[];
    private buttonKeys: Object[];

    private showAllLabel:string = '';
    private showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number;
    
    public loadImportModem: boolean = false;

    constructor(
                private localeDataService: LocaleDataService,
                private showAlert: ShowAlert,
                private logger: Logger,
                private componentFactoryResolver: ComponentFactoryResolver,
                private modemTabDataService: ModemTabDataService,
                private modemTabColumnDefinitionService: ModemTabColumnDefinitionService) {
                this.localeDataService.componentCallback.subscribe((response) => { 
                    this.translateLocaleString();
                    this.setEventButtonKeys();
                });
    }
    
    ngOnInit() {
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.dom = new ɵBrowserDomAdapter();
    }

    /*
     *@name modemCMTSEvent
     *@desc Events related to Modem tab (CSTM).
     *@return void
     */
    private notifyActionEmitter($event) {
        switch($event.event.name) {
            case this.CMTS_MODEM_BTN_EXPORT_GEOCODE:
                this.notifyExportGeocodeMODEMCMST();
                break;
            case this.CMTS_MODEM_BTN_PERFORM_GEOCODING:
                this.notifyPerformGeocodeMODEMCMST();
                break;
            default:

        }
    }

    private getModemList(): void{
        this.modemTabDataService.getModemList().subscribe(this.onNext.bind(this), null);
    }
    private notifyFilterChangeMODEMCMTS(event): void{
        this.modemTabDataService.modemtabfilterchangedata = this.modemTabGridOptions.api.getFilterModel();
        console.log("filterchange data",this.modemTabDataService.modemtabfilterchangedata);

    }
    /*method to set standalone button keys*/
    private setEventButtonKeys():void {
        this.buttonKeys = [
            {name: this.CMTS_MODEM_BTN_EXPORT_GEOCODE, tabType: cstmConstants.MODEM_CONTS},
            {name: this.CMTS_MODEM_BTN_PERFORM_GEOCODING, tabType: cstmConstants.MODEM_CONTS}
        ];
        this.eventKeys = [
            {name: this.TABLE_LIST_EXPORT_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.MODEM_CONTS},
            {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.MODEM_CONTS},
        ];
    }

    /*set ag-grid columndefs*/
    private setGridColumnDefinition(): void{
        this.modemTabGridOptions.api.setColumnDefs(this.modemTabColumnDefinitionService.getColumnDef());
        this.getModemList();
        this.showGridLoadingOverly();
    }

    /*Method to show overlay text from table*/
    private showGridLoadingOverly(): void{
        this.modemTabGridOptions.api.showLoadingOverlay();
    }

    private onNext(modemListData):void {
        this.setGridRowData(modemListData);
    }

    /*set ag-grid rowdata*/
    private setGridRowData(modemListData: Array<NodeList>): void{
        //this.modemTabGridOptions.api.setRowData(modemListData);
        const isDocsis = modemListData.find((elem: any) => elem.docsisVersion)
        if(!isDocsis) {
            this.modemTabGridOptions.columnApi.setColumnVisible('docsisVersion', false)
        }
        this.modemTabGridRowData = modemListData;
        this.totalCount = this.modemTabGridRowData.length;
        this.setShowAllLabel(this.modemTabGridRowData.length, this.totalCount);
        if(this.modemTabGridOptions.api && this.modemTabDataService.modemtabfilterchangedata){
            this.modemTabGridOptions.api.setFilterModel(this.modemTabDataService.modemtabfilterchangedata);            
            console.log("filter executed",this.modemTabDataService.modemtabfilterchangedata);
        }
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    private modelUpdatedEmitter(e:any):void {
        let rowCount = this.modemTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    private onCancel():void{
        this.logger.debug("onCancel: close slider");
        this.dom.addClass(this.dom.query("div.right-slider"),"close-right-slider");
        this.dom.addClass(this.dom.query("div.right-slider.overlay"),"close-right-slider-overlay");
    }

    private notifyExportGeocodeMODEMCMST():void{
        this.modemTabDataService.getExportGeocodeModem().subscribe(this.onExportGeocodeNext.bind(this), this.onError.bind(this));
    }

    private notifyPerformGeocodeMODEMCMST():void{
        this.modemTabDataService.getPerformGeocodeModem().subscribe(this.onPerformGeocodeNext.bind(this), this.onError.bind(this));
    }

    /* On gettting geocode from server */
    private onPerformGeocodeNext(data):void {
        this.showAlert.showSuccessAlert(this.GEOCODING_INITIATED);
    }

    private notifyGridReadyMODEMCMTS():void{
        this.setGridColumnDefinition();
    }

    /*check if data is null or json data*/
    private onExportGeocodeNext(data):void{
        if(data.length == 0){
            this.showAlert.showInfoAlert(this.NO_FAILED_MODEMS);
        }
        else {
            this.exportToCsv(data);
        }
    }

    private notifyRefreshGrid(): void{
        this.getModemList();
    }

    /* Method get called when we come in HSM tab after switch the tab */
    public onTabSwitch(): void{
        this.getModemList();
    }

    /*export json data in csv format */
    private exportToCsv(data):void{
        let options: any = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true
        };
        new Angular2Csv(data, 'export', options);
    }

    /* Handle error & show sweet alert */
    private onError(error):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.CMTS_MODEM_BTN_EXPORT_GEOCODE = localizationService.instant('CMTS_MODEM_BTN_EXPORT_GEOCODE');
        this.CMTS_MODEM_BTN_PERFORM_GEOCODING = localizationService.instant('CMTS_MODEM_BTN_PERFORM_GEOCODING');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.NO_FAILED_MODEMS = localizationService.instant('NO_FAILED_MODEMS');
       this.GEOCODING_INITIATED =  localizationService.instant('GEOCODING_INITIATED');
    }

}
