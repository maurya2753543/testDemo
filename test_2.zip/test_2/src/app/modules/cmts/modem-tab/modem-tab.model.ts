/**
 * Created by nikita.dewangan on 13-06-2017.
 */

export class ModemModel{

    public vendor: string;
    public hardwareVersion: string;
    public softwareVersion: string;
    public model: string;
    public modemCount: number;
    public docsisVersion: string;

    constructor(_modemData){
        this.vendor = _modemData.vendor ? _modemData.vendor: null;
        this.hardwareVersion = _modemData.hardwareVersion ? _modemData.hardwareVersion : null;
        this.softwareVersion = _modemData.softwareVersion ? _modemData.softwareVersion: null;
        this.model = _modemData.model ? _modemData.model: null;
        this.modemCount = _modemData.modemCount ? _modemData.modemCount : 0;
        this.docsisVersion = _modemData.docsisVersion ? _modemData.docsisVersion : null;
    }

}
