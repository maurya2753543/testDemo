/**
 * Created by nikita.dewangan on 13-06-2017.
 */

import {Injectable} from "@angular/core";

import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from "@ngx-translate/core";

@Injectable()
export class ModemTabColumnDefinitionService{

    constructor( private localeDataService: LocaleDataService,
        private translate: TranslateService,
        private sharedService : SharedService){
    }

    private _HEADER_FIELDS: any = {
        vendor : {field: "vendor", name: "CMTS_MODEM_TAB_COL_MANUFACTURER"},
        hardwareVersion : {field: "hardwareVersion", name: "CMTS_MODEM_TAB_COL_HARDWARE_VER"},
        softwareVersion : {field: "softwareVersion", name: "CMTS_MODEM_TAB_COL_SOFTWARE_VER"},
        model : {field: "model", name: "CMTS_MODEM_TAB_COL_MODEL"},
        modemCount : {field: "modemCount", name: "CMTS_MODEM_TAB_COL_MODEM_COUNT"},
        docsisVersion : {field: "docsisVersion", name: "CMTS_MODEM_TAB_COL_DOCSIS_VERSION"}
    };

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        let localizationService = this.translate;

        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.vendor.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.vendor.name),
                field: this._HEADER_FIELDS.vendor.field,
                //minWidth: 200,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.vendor.name), 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.hardwareVersion.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.hardwareVersion.name), field: this._HEADER_FIELDS.hardwareVersion.field,
                //minWidth: 100,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.hardwareVersion.name), 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.softwareVersion.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.softwareVersion.name), field: this._HEADER_FIELDS.softwareVersion.field,
                //minWidth: 100,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.softwareVersion.name), 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.model.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.model.name), field: this._HEADER_FIELDS.model.field,
                //minWidth: 100,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.model.name), 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.docsisVersion.name), headerTooltip: localizationService.instant(this._HEADER_FIELDS.docsisVersion.name), 
                field: this._HEADER_FIELDS.docsisVersion.field,
                // hide: this._HEADER_FIELDS.docsisVersion.field === 'docsisVersion',
                suppressToolPanel: true,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.docsisVersion.name), 60),
                filter: 'text', floatingFilterComponentParams: { suppressFilterButton: true},
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.modemCount.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.modemCount.name), field: this._HEADER_FIELDS.modemCount.field,
                //minWidth: 100,
                minWidth: this.sharedService.getHeaderTemplate(localizationService.instant(this._HEADER_FIELDS.modemCount.name), 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            }
        ]
        return columnDef;
    }

}