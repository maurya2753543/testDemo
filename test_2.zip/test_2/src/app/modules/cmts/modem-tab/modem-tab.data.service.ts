
import { map ,catchError} from 'rxjs/operators';
/**
 * Created by nikita.dewangan on 13-06-2017.
 */

import {Injectable} from "@angular/core";
import { Observable, throwError} from "rxjs";
import {CMTSHttpService} from "../cmts.http.service";
import {ModemModel} from "./modem-tab.model";

@Injectable()
export class ModemTabDataService{

    private modemList : Array<ModemModel> = new Array<ModemModel>();
    public modemtabfilterchangedata: any;
    constructor(private cmtsHttpService: CMTSHttpService){}

    /*Method to get Modem list from server*/
    public getModemList(): Observable<any> {
        this.modemList = [];
        return this.cmtsHttpService
            .getModemListData()
            .pipe(
                map((modemListDataObj) => {
                    this.setModemList(modemListDataObj);
                    return this.modemList;
                }),catchError(this.handleError)
            )
            
    }

    /*Method to getExported geocode Modem from server*/
    public getExportGeocodeModem(): Observable<any> {
        return this.cmtsHttpService
            .getExportGeocodeModemData()
            .pipe(
                map((res) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    /*Method to perform geocode Modem from server*/
    public getPerformGeocodeModem(): Observable<any> {
        return this.cmtsHttpService
            .getPerformGeocodeModemData()
            .pipe(
                map((res) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    public handleError(error) {
        return throwError(error);
    }

    /*Method to set Modem list*/
    public setModemList(dataListObj): void {
        for(let i=0; i<dataListObj.length; i++) {
            let modemModel : ModemModel = new ModemModel(dataListObj[i]);
            this.modemList.push(modemModel);
        }
    }
}
