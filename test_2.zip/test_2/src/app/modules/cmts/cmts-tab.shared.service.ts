/**
 * Created by yogesh.paisode on 6/12/2017.
 */
import {Injectable} from "@angular/core";
import {Subject} from "rxjs";
import {CmtsTabModel} from "./cmts-tab/cmts-tab.model";
import {MAX_STRING_LIMIT} from "../../constant/app.constants";

@Injectable()
export class CmtsTabSharedService{

    //----Cmts Tab----
    private cmtsTabFormChangeSubject: Subject<any>;
    private cmtsListRefreshSubject: Subject<any>;
    private cmtsTabModelData: any;
    private nameFilterText: string;
    private cmtsFeatures: any[] = [];
    bulkModifyFlag: boolean = false;
    mactrakThresholdFlag: boolean = false;
    selectedCmts:any;
    deviceIds: number[];

    constructor(){
        this.nameFilterText = "";
        this.initSubjects();
    }

    public getNameFilterText(): string{
        return this.nameFilterText;
    }

    public setNameFilterText(nameFilterText: string): void{
        this.nameFilterText = nameFilterText;
    }

    public getCmtsTabModelData(): any{
        return this.cmtsTabModelData;
    }

    public setCmtsTabModelData(cmtsTabModelData: any): void{
        this.cmtsTabModelData = cmtsTabModelData;
    }

    public getCmtsTabFormChangeSubject(): Subject<any>{
        return this.cmtsTabFormChangeSubject;
    }

    public getCmtsListRefreshSubject(): Subject<any>{
        return this.cmtsListRefreshSubject;
    }

    private initSubjects(): void{
        this.cmtsTabFormChangeSubject = new Subject();
        this.cmtsListRefreshSubject = new Subject();
    }

    public checkTextLength(value: string): string{
        let length: number = value.length;
        if(length > MAX_STRING_LIMIT){
            value = value.substring(0, MAX_STRING_LIMIT);
        }
        return value;
    }

    public setCmtsFeatures(cmtsfeatures: any): void {
        this.cmtsFeatures = cmtsfeatures;
    }

    public getCmtsFeatures(): any {
        return this.cmtsFeatures;
    }
}
