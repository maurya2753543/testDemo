/**
 * Created by Mehjabeen.Bari on 6/8/2017.
 */

/* Common HTTP service to call http request from Generic Http Service*/

import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/http.service";
import {CMTSUrlService} from "./cmts.url.service";
import {Observable} from "rxjs";
import {AlarmableModemModel} from './alarmableModem-tab/alarmableModem-tab.model';

@Injectable()
export class CMTSHttpService {

    constructor(private httpService: HttpService, private cmtsUrlService: CMTSUrlService){}

    public getNodeListData(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getNodeListUrl());
    }

    public getEventList(elementId: number, type): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getRPMEventListUrl(elementId, type));
    }

    public deleteNode(id: number): Observable<any> {
        return this.httpService.DELETE(this.cmtsUrlService.getDeleteNodeUrl(id));
    }

    public editNode(nodeData: any): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getDeleteNodeUrl(nodeData.nodeId), nodeData);
    }

    public getModemListData(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getModemListUrl());
    }

    public getExportGeocodeModemData(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getExportGeocodeModemUrl());
    }

    public getThresholdLabels():Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getThresholdLabelsUrl());
    }

    public getPerformGeocodeModemData(): Observable<any> {
        return this.httpService.GETTEXT(this.cmtsUrlService.getPerformGeocodeModemUrl());
    }

    public getAllCmtsList(): Observable<any> {
        console.log('service, getAllCmtsList --> ');
        return this.httpService.GET(this.cmtsUrlService.getCMTSListUrl());
    }

    public getCustomFields(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getCustomModemFieldsUrl());
    }

    public getSweepConfig(id: number): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getSweepConfig(id));
    }

    public validateCMTSConfig(postData: any): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getValidateCMTSConfigUrl(postData.id), postData);
    }

    public updateCMTSConfig(postData: any): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getSweepConfig(postData.id), postData);
    }

    public getCmtsFeatures(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getCMTSFeaturesUrl());
    }

    public topologyExportFields(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.topologyExportFieldsUrl());
    }

    public noisetrakExportFields(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.noisetrakExportUrl());
    }    

    public postAddGreenFieldNode(data:Object): Observable<any>{
        return this.httpService.POST(this.cmtsUrlService.postAddGreenFieldNodeUrl(), data);
    }

    public putCMTS(id:number, data:Object): Observable<any> {
        return this.httpService.PUT(this.cmtsUrlService.putEditCMTSUrl(id), data);
    }

    public deleteCMTS(id:number): Observable<any> {
        return this.httpService.DELETE(this.cmtsUrlService.deleteCMTSUrl(id));
    }

    public addCMTS(data:Object): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.addCMTSUrl(), data);
    }

    public syncAllCmts(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getSyncAllCmtsUrl());
    }

    public syncSelectedCmts(cmtsIds: number[]): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getSyncSelectedCmtsUrl(), cmtsIds);
    }

    public addModemToServer(modemData): Observable<any>{
        return this.httpService.POSTFILEDATA(this.cmtsUrlService.getCSVUploadNodeUrl(), modemData);
    }

    public addModemToServerCSV(modemData): Observable<any>{
        return this.httpService.POSTFILEDATA(this.cmtsUrlService.getCSVUploadFilesUrl(), modemData);
    }

    public addNoisetrakToServerCSV(modemData): Observable<any>{
        return this.httpService.POSTFILEDATA(this.cmtsUrlService.getNoisetrakCSVUploadFilesUrl(), modemData);
    }   

    public postCmtsFeatures(modifiedCmtsFeatures: any): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getCMTSFeaturesUrl(), modifiedCmtsFeatures);
    }

    public addCmtsToServer(cmtsData): Observable<any> {
        return this.httpService.POSTFILEDATA(this.cmtsUrlService.getCSVUploadCmtsUrl(), cmtsData);
    }

    public getAlarmableModemListData() {
        return this.httpService.GET(this.cmtsUrlService.getAlarmableModemsUrl());
    }

    public addAlarmableModem(data: any, modemId: any): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getAddAlarmableModemsUrl(modemId,data.expirationDuration), {});
    }

    public deleteAlarmableModems(modemIds: number[]): Observable<any> {
        return this.httpService.POST(this.cmtsUrlService.getDeleteAlarmableModemsUrl(), modemIds);
    }

	public getRemainingAlarmableModes(): any {
		// return this.httpService.GET(this.cmtsUrlService.getRemainingAlarmableModemsUrl());
        return this.httpService.getData(this.cmtsUrlService.getRemainingAlarmableModemsUrl());
	}

    public updateAlarmableModem(dataModel: AlarmableModemModel) {
        return this.httpService.POST(this.cmtsUrlService.getUpdateAlarmableModemUrl(dataModel.modemId,dataModel.expirationDuration.toString()),null);
    }

    public getModemDetails(modemId:number):any {
        return this.httpService.GET(this.cmtsUrlService.getModemUrl(modemId));
    }

    public getCmtsDeviceThreshold(): Observable<any>{
        return this.httpService.GET(this.cmtsUrlService.getCmtsDeviceThreshold()); 
    }

    public deleteMACTrakThreshold(deviceIds:number[],settings:any[]): Observable<any>{
        var data = {
            "attributeList": settings,
            "deviceIds": deviceIds           
     }
        return this.httpService.DELETEWITHDATA(this.cmtsUrlService.getdeleteMACTrakThresholdUrl(),data); 
    }

    public updateMACTrakBulkThreshold(deviceIds :number[], newStressedThreshold, newFailThreshold) : Observable<any>  {
        var data = {
             "deviceIds": deviceIds,
             "settings": {
                "QP_MARGINAL_THRESHOLD": newStressedThreshold,
                "QP_FAIL_THRESHOLD": newFailThreshold
            }
         }
        return this.httpService.POST(this.cmtsUrlService.updateMACTrakBulkThresholdUrl(),data);
    }
    
    public getOSInfo(): Observable<any> {
        return this.httpService.GET(this.cmtsUrlService.getOSInfoUrl());
    }
    
}
