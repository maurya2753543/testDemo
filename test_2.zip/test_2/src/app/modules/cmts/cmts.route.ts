
import { Routes, RouterModule } from '@angular/router';
import {CMTSComponent} from "./cmts.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: CMTSComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class CmtsRoutes{}
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);