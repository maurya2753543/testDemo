import {Component, Input} from '@angular/core';

import {Grid} from "../../../shared/ag-grid.options";
import {ViewEventsColumnDefinitionService} from '../../shared/common-components/listView/viewEvents.column-definition.service';
import { Logger } from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {CMTSDataService} from "../cmts.data.service";
import {EventListItems} from "../../shared/common-components/models/viewEvents.model";
import {ThresholdService} from "../../shared/threshold.service";

@Component({
    selector:'view-event',
    templateUrl:'../../shared/common-components/listView/listView.component.html'
})

export class CMTSViewEvent {

    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata=[];
    public eventKeys: Object[];
    public buttonKeys: Object[];
    private tag:string = "CMTS View Event Component";
    private TABLE_LIST_EXPORT_ALL:string;
    private CLOSE_SLIDER:string;
    public gridTabType:string = "CMTSEventExport";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private eventList: any[];
    public styleForHeaderBtns:string = 'max-width:56%'  // Bug fix XPTUI 621

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;

    @Input('childData') childData: any;

    constructor(private localeDataService: LocaleDataService,
                private ViewEventsColumnDefinitionService:ViewEventsColumnDefinitionService,
                private logger: Logger,
                private thresholdService: ThresholdService,
                private cmtsDataService: CMTSDataService,
                private showAlert: ShowAlert,
                private sharedService:SharedService){
        this.translateLocaleString();
        this.setEventButtonKeys();
    }

    ngOnInit(){
        this.isCloseRightSlider = false;
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    private translateLocaleString(){
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'CMTS_VIEW_EVENT', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'CMTS_VIEW_EVENT', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }

    //sets slider label.
    private setHeaderLabel():void {
        this.headerTxt = this.childData["headerName"];
    }
    
    private btnClose_click(){
        this.isCloseRightSlider = true;
    }

    //function :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    // function :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.ViewEventsColumnDefinitionService.getColumnDef());
        this.listViewOptions["getRowHeight"] = (params) => {
            return 18 * (Math.floor(params.data.eventType.length / 45) + 2);
        }
        this.childData && this.getViewEventData();
    }

    private getViewEventData():void {
        this.setHeaderLabel();

        this.cmtsDataService.getEventListData(this.childData["id"], this.childData["type"])
            .subscribe(this.getThresholdsList.bind(this),this.onError.bind(this));
    }

    private getThresholdsList(eventList: any): void{
        this.eventList = eventList;
        this.cmtsDataService.getThresholdsName()
            .subscribe(this.processEventList.bind(this),this.onError.bind(this));
    }

    private processEventList(thresholds: any): void{
        this.onViewEventSuccess(this.eventList);
    }

    private onViewEventSuccess(data:any):void {
        this.rowdata = this.processThresholds(data);
        this.totalCount = data.length;
        this.setShowAllLabel(data.length, this.totalCount);
        this.logger.debug(this.tag, "onViewEventSuccess(): View Events success response=", data);
    }

    private processThresholds(eventListItems: EventListItems[]): EventListItems[] {
        eventListItems.forEach((eventList: EventListItems) => {
            eventList.eventName = this.thresholdService.getThresholdIndex(eventList.eventType);
        });
        return eventListItems;
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    public notifyGridReadyViewEvents(params:any){
        this.setGridColDefinition();
    }

    public notifyCloseSlider(params:any){
        this.isCloseRightSlider = true;
    }

    //refresh
    public notifyRefreshGrid(params:any){
        this.getViewEventData();
    }
    
    //function called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }
}