import { Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';

import {LocaleDataService} from "../../shared/locale.data.service";
import {SharedService} from "../../shared/shared.service";
import {CMTSTabComponent} from "./cmts-tab/cmts-tab.component";
import {NODETabComponent} from "./node-tab/node-tab.component";
import {MODEMTabComponent} from "./modem-tab/modem-tab.component";
import {StatusFilter} from "../../shared/status.filter";
import {CMTS_MODULE} from "../../constant/app.constants";
import {ThresholdService} from "../shared/threshold.service";
import {AlarmableModemTabComponent} from './alarmableModem-tab/alarmableModem-tab.component';
import {ModemWatchTabComponent} from './modemWatch-tab/modem-watch-tab.component';
import { TranslateService } from '@ngx-translate/core';
import { CMTSDataService } from './cmts.data.service';
import { NavService } from '../../shared/nav.service';

@Component({
    selector: 'cmts-component',
    templateUrl: 'cmts.component.html'
})

export class CMTSComponent  implements OnDestroy{
    public loadComponent:boolean;
    private CMTSTabRef: any;
    private MODEMTabRef: any;
    private NODETabRef: any;
    private ALARMABLEMODEMTabRef: any;
    private MODEMWATCHTabRef: any;
    private oldSelectedSettings: Object = {};
    public selectedTab : string;

    @ViewChild('targetCMTS', {read: ViewContainerRef }) _targetCMTS;
    @ViewChild('targetNODE', {read: ViewContainerRef }) _targetNODE;
    @ViewChild('targetMODEM', {read: ViewContainerRef}) _targetMODEM;
    @ViewChild('targetALARMABLEMODEM', {read: ViewContainerRef}) _targetALARMABLEMODEM;
    @ViewChild('targetMODEMWATCH', {read: ViewContainerRef}) _targetMODEMWATCH;

    constructor( 
                // public locale: LocaleService,  
                //  public localization: LocalizationService,
                public navService: NavService,
                private cmtsDataService: CMTSDataService,
                private sharedService:SharedService,
                public localeDataService:LocaleDataService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private viewContainerRef: ViewContainerRef,
                private thresholdService: ThresholdService,
                public translate : TranslateService) {
        // super(locale, localization);
            let module = CMTS_MODULE;
            this.localeDataService.initLanguage(module);
            this.cmtsDataService.OSInfoStatus();
    }

    ngOnInit(){
        if(this.sharedService.getRedirectTAB()) {
            this.getTranslated(this.sharedService.getRedirectTAB(), true);
            if(this.cmtsDataService.getTab() && this.sharedService.getRedirectTAB()){
                this.LoadTab(this.sharedService.getRedirectTAB())
                this.sharedService.setRedirectTAB('');
            }
        }else {
            if(this.cmtsDataService.getTab()){
                this.translateLocaleString();
                this.selectedTab = 'cmts';
            } else {
                this.getTranslated('cmts', false);
            }
        }
    }
    
    getTranslated(tabValue: string, bool?: boolean){
        this.translate.onLangChange.subscribe(lang => {
            this.translateLocaleString();
            this.LoadTab(tabValue);
            this.cmtsDataService.setTab(tabValue);
        })
    }
    
    LoadTab(tabName : string): void{
        let selectedTab = this.sharedService.getRedirectTAB();
        this.selectedTab = tabName.toLowerCase();
        if (selectedTab && selectedTab.length > 0) {
            this.selectedTab = selectedTab;
            this.sharedService.setRedirectTAB("");
        }
        // switch (this.selectedTab) {
        //     case "cmts":
        //     {
        //         this.CMTSTabRef !== this.oldSelectedSettings["comp"] && this.CMTSTabRef ? this.CMTSTabRef.instance.onTabSwitch(true) : "";
        //         this.CMTSTabRef = this.createComponentOnClick(CMTSTabComponent, this._targetCMTS, this.CMTSTabRef);
        //         break;
        //     }
        //     case "node":
        //     {
        //         this.NODETabRef !== this.oldSelectedSettings["comp"] && this.NODETabRef ? this.NODETabRef.instance.onTabSwitch(true) : "";
        //         this.NODETabRef = this.createComponentOnClick(NODETabComponent, this._targetNODE, this.NODETabRef);
        //         break;
        //     }
        //     case "modem":
        //     {
        //         this.MODEMTabRef !== this.oldSelectedSettings["comp"] && this.MODEMTabRef ? this.MODEMTabRef.instance.onTabSwitch(true) : "";
        //         this.MODEMTabRef = this.createComponentOnClick(MODEMTabComponent, this._targetMODEM, this.MODEMTabRef);
        //         break;
        //     }
        //     case "alarmablemodem":
        //     {
        //         this.ALARMABLEMODEMTabRef !== this.oldSelectedSettings["comp"] && this.ALARMABLEMODEMTabRef ? this.ALARMABLEMODEMTabRef.instance.onTabSwitch(true) : "";
        //         this.ALARMABLEMODEMTabRef = this.createComponentOnClick(AlarmableModemTabComponent, this._targetALARMABLEMODEM, this.ALARMABLEMODEMTabRef);
        //         break;
        //     }
        //     case "modemwatch":
        //     {
        //         this.MODEMWATCHTabRef !== this.oldSelectedSettings["comp"] && this.MODEMWATCHTabRef ? this.MODEMWATCHTabRef.instance.onTabSwitch(true) : "";
        //         this.MODEMWATCHTabRef = this.createComponentOnClick(ModemWatchTabComponent, this._targetMODEMWATCH, this.MODEMWATCHTabRef);
        //         break;
        //     }
        //     default:
        //     {
        //         //TO DO: Show error for tab loading
        //         console.log("Invalid choice");
        //         break;
        //     }
        // }
    }

    /* Function used to create component on settings section link click */
    private createComponentOnClick(clickedComponent: any, currentViewContainer: any, currentCompRef: any): void {
        this.oldSelectedSettings['comp'] ? this.oldSelectedSettings['viewRef'].detach() : '';
        if(!currentCompRef){
            let componentFactory: any = this.componentFactoryResolver.resolveComponentFactory(clickedComponent);
            currentCompRef = currentViewContainer.createComponent(componentFactory);
        }else{
            currentViewContainer.insert(currentCompRef.hostView);
        }
        this.oldSelectedSettings = {'comp' : currentCompRef, 'viewRef' : currentViewContainer};
        return currentCompRef;
    }

    //function :: used for localization
    private translateLocaleString(): void {
       // let localizationService = this.localeDataService.getLocalizationService();

        StatusFilter.setSeverity(
            {
                default: this.translate.instant('DEFAULT'),
                online: this.translate.instant('ONLINE'),
                offline: this.translate.instant('OFFLINE'),
                busy: this.translate.instant('BUSY'),
                error: this.translate.instant('ERROR'),
                disabled: this.translate.instant('DISABLED'),
                unavailable: this.translate.instant('UNAVAILABLE')
            }
        );
        this.thresholdService.alarmClear = this.translate.instant("PORT_ALARM_CLEARED");
        this.thresholdService.nodeOutage = this.translate.instant("NODE_OUTAGE");
        this.thresholdService.violation = this.translate.instant("PORT_VIOLATION");
        this.thresholdService.threshold = this.translate.instant("THRESHOLD");
        this.thresholdService.thresholdInterval = this.translate.instant("ALARM_LIST_THRESHOLD_INTERVAL_VALUE");

        StatusFilter.setCMTSVisibility(true);
        StatusFilter.setRCIVisibility(false);
    }

    ngOnDestroy(): void {
        this.cmtsDataService.cmtsmodeldata = null;
    }
}
