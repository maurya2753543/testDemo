/**
 * Created by jerry.blum 10/02/2020.
 **/

import {Injectable} from '@angular/core';
import {AlarmableModemModel} from './alarmableModem-tab.model';

@Injectable()
export class AlarmableModemTabService{

	//Method to get selected rows from grid
	public getSelectedModemIds(alarmableModemModels: AlarmableModemModel[], selectedRowsModemsId: number[]): void{
		alarmableModemModels.forEach((alarmableModemModel: AlarmableModemModel)=>{
			selectedRowsModemsId.push(alarmableModemModel.modemId);
		});
	}
}