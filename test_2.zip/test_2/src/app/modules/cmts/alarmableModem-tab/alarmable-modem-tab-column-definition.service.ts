import {Injectable} from '@angular/core';
import {LocaleDataService} from '../../../shared/locale.data.service';
import {SharedService} from '../../../shared/shared.service';
import {gridCustomComparator} from '../../../shared/ag-Grid.comparator';
import {DisabledFilter} from '../../shared/grid/disabled.filter';
import {EDIT_ICON} from '../../../constant/app.constants';
import {EDIT_OPERATION} from '../cmts-tab.constants';
import {AlarmableModemSharedService} from './alarmableModem.shared.service';
import {Subject} from 'rxjs';
import {TimeFilter} from '../../../shared/time.filter';

@Injectable()
export class AlarmableModemTabColumnDefinitionService{
	private _HEADER_FIELDS: any = {
		modem : {field: "modem", name: "CMTS_ALARMABLE_MODEM_TAB_MODEM"},
		address : {field: "address", name: "CMTS_ALARMABLE_MODEM_TAB_ADDRESS"},
		customerName: {field: "customerName", name: "CMTS_ALARMABLE_MODEM_TAB_CUSTOMER_NAME"},
		phoneNumber: {field: "phoneNumber", name: "CMTS_ALARMABLE_MODEM_TAB_PHONE_NUMBER"},
		nodeName: {field: "nodeName", name: "CMTS_ALARMABLE_MODEM_TAB_NODE_NAME"},
		source: {field: "source", name: "CMTS_ALARMABLE_MODEM_TAB_SOURCE"},
		expirationTime: {field: "expiration", name: "CMTS_ALARMABLE_MODEM_TAB_EXPIRATION_TIME"},
		edit : {field: "edit", name: "Edit"},
	};

	private alarmableModemTabFormChangeSubject: Subject<any>;

	constructor(private localeDataService: LocaleDataService,
				private sharedService: SharedService,
				private alarmableModemSharedService: AlarmableModemSharedService) {
		this.alarmableModemTabFormChangeSubject = this.alarmableModemSharedService.getAlarmableModemTabFormChangeSubject();
	}

	private translateLocaleStr(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this._HEADER_FIELDS.modem.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_MODEM');
		this._HEADER_FIELDS.address.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_ADDRESS');
		this._HEADER_FIELDS.customerName.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_CUSTOMER_NAME');
		this._HEADER_FIELDS.phoneNumber.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_PHONE_NUMBER');
		this._HEADER_FIELDS.nodeName.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_NODE_NAME');
		this._HEADER_FIELDS.source.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_SOURCE');
		this._HEADER_FIELDS.edit.name = localizationService.instant('CMTS_TAB_HEADER_EDIT');
		this._HEADER_FIELDS.expirationTime.name = localizationService.instant('CMTS_ALARMABLE_MODEM_TAB_EXPIRATION_TIME');
	}

	public getColumnDef(): any[] {
		this.translateLocaleStr();

		let columnDef: any[] = [
			{
				headerName: '',
				width: 21,
				checkboxSelection: true,
				pinned: true,
				sortingOrder: [null],
				field: '',
				headerCheckboxSelection: true,
				suppressFilter: true,
				suppressSizeToFit: true,
				suppressMenu: true,
				filterParams: {newRowsAction: 'keep'},
				suppressResize: true
			},
			{
				headerName: this._HEADER_FIELDS.modem.name,
				headerToolTip: this._HEADER_FIELDS.modem.name,
				field: this._HEADER_FIELDS.modem.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modem.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.address.name,
				headerToolTip: this._HEADER_FIELDS.address.name,
				field: this._HEADER_FIELDS.address.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.address.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.customerName.name,
				headerToolTip: this._HEADER_FIELDS.customerName.name,
				field: this._HEADER_FIELDS.customerName.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.customerName.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.phoneNumber.name,
				headerToolTip: this._HEADER_FIELDS.phoneNumber.name,
				field: this._HEADER_FIELDS.phoneNumber.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.phoneNumber.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.nodeName.name,
				headerToolTip: this._HEADER_FIELDS.nodeName.name,
				field: this._HEADER_FIELDS.nodeName.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.nodeName.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.source.name,
				headerToolTip: this._HEADER_FIELDS.source.name,
				field: this._HEADER_FIELDS.source.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.source.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.expirationTime.name,headerTooltip: this._HEADER_FIELDS.expirationTime.name, field: this._HEADER_FIELDS.expirationTime.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.expirationTime.name, 90),
				floatingFilterComponentParams:{ suppressFilterButton:true },
				comparator: this.sharedService.dateComparator,
				filterParams: {newRowsAction: 'keep'},
				filter: TimeFilter.ParentFilter,
				floatingFilterComponent: TimeFilter.ChildFloatingFilter,
				cellRenderer:(params:any)=>{
					let dateInSpanish = this.sharedService.getLocaleDate(params.value);// moment(params.value).format('lll');
					return dateInSpanish;
				}
			},
			{
				headerName: this._HEADER_FIELDS.edit.name, headerToolTip: this._HEADER_FIELDS.edit.name,
				minWidth: 70, maxWidth: 150,
				pinned: this.sharedService.isPinned(),
				sortingOrder: [null],
				suppressSorting : true,
				cellStyle : () => {
					return { 'text-align': 'center' };
				},
				filter: 'text',
				comparator: gridCustomComparator,
				floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {newRowsAction: 'keep'},
				suppressMenu: true,
				cellRenderer: ((param:any)=>{
					let gui = document.createElement('div');
					gui.innerHTML = EDIT_ICON;
					let eFilterText = gui.querySelector('i');
					eFilterText.addEventListener("click", (()=>{
						this.action(param);
					}));
					gui.className = "ag-Grid-cursor";
					return gui;
				})
			}
		]
		return columnDef;
	}

	//@method :: callback action for clear icon click
	private action(param: any): void{
		let data: any = {operation: EDIT_OPERATION, alarmableModemTabModel: param.data};
		this.alarmableModemSharedService.setAlarmableModemModelData(data);
		this.alarmableModemTabFormChangeSubject.next(data);
	}
}