/**
 * Created by jerry.blum on 2020-09-23
 */

export class AlarmableModemModel{

	public modemId: number;
	public modem: string;
	public address: string;
	public customerName: string;
	public phoneNumber: string;
	public nodeName: string;
	public source: string;
	public expiration: Date;
	public expirationDuration: number;

	constructor(alarmableModemData: any, localizationService: any) {
		this.modemId = alarmableModemData.modemId ? alarmableModemData.modemId : null;
		this.modem = alarmableModemData.macString ? alarmableModemData.macString : null;
		this.address = alarmableModemData.address ? alarmableModemData.address : null;
		this.customerName = alarmableModemData.customerName ? alarmableModemData.customerName : null;
		this.phoneNumber = alarmableModemData.phoneNumber ? alarmableModemData.phoneNumber : null;
		this.nodeName = alarmableModemData.nodeName ? alarmableModemData.nodeName : null;
		this.source = alarmableModemData.source ? alarmableModemData.source : null;
		this.expiration = alarmableModemData.expiration ? alarmableModemData.expiration : null;
		this.expirationDuration = alarmableModemData.expirationDuration ? alarmableModemData.expirationDuration : null;
	}
}