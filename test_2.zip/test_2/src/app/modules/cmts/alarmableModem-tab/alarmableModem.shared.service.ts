/**
 * Created by jerry.blum 30-09-2020
 */

import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';

@Injectable()
export class AlarmableModemSharedService {
	private alarmableModemFormChangeSubject: Subject<any>;
	private alarmableModemListRefreshSubject: Subject<any>;
	private alarmableModemModelData: any;

	constructor() {
		this.initSubject();
	}

	private initSubject(): void {
		this.alarmableModemFormChangeSubject = new Subject();
		this.alarmableModemListRefreshSubject = new Subject();
	}

	public setAlarmableModemModelData(data: any) {
		this.alarmableModemModelData = data;
	}

	public getAlarmableModemModelData(): any {
		return this.alarmableModemModelData;
	}

	public getAlarmableModemListRefreshSubject(): Subject<any>{
		return this.alarmableModemListRefreshSubject;
	}

	getAlarmableModemTabFormChangeSubject() {
		return this.alarmableModemFormChangeSubject;
	}
}