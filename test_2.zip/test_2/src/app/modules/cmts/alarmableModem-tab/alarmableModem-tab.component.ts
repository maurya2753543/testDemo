import {Component, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';
import {ShowAlert} from '../../../utilities/showAlert';
import {Logger} from '../../../utilities/logger';
import {LocaleDataService} from '../../../shared/locale.data.service';
import {Grid} from '../../../shared/ag-grid.options';
import {AlarmableModemTabDataService} from './alarmableModem-tab.data.service';
import * as cstmConstants from "../cmts-tab.constants";
import {AlarmableModemTabColumnDefinitionService} from './alarmable-modem-tab-column-definition.service';
import {AlarmableModemModel} from './alarmableModem-tab.model';
import {ADD_OPERATION} from '../cmts-tab.constants';
import {CmtsTabSharedService} from '../cmts-tab.shared.service';
import {AlarmableModemSharedService} from './alarmableModem.shared.service';
import {AlarmableModemViewComponent} from './alarmableModem-view/alarmableModem-view.component';
import {AlarmableModemTabService} from './alarmableModem-tab.service';
import {Subject} from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
	selector: 'modemAlarm-tab-component',
	templateUrl: 'alarmableModem-tab.component.html'
})

export class AlarmableModemTabComponent{

	public viewData: boolean = false;
	private dataModel: AlarmableModemModel = new AlarmableModemModel({}, null);
	public alarmableModemTabGridOptions: Grid = new Grid();
	public eventKeys: Object[];
	public buttonKeys: Object[];
	public modemAlarmTabRowData: any;
	public showAllLabel: string = '';
	public showAllLabelMob: string = '';
	private CMTS_MODEM_ALARM_BTN_ADD_MODEM: string = "";
	private CMTS_MODEM_ALARM_DELETE_MODEM: string = "";
	private TABLE_LIST_EXPORT_SELECTED: string = "";
	private TABLE_LIST_EXPORT_ALL: string = "";
	private TABLE_LIST_SHOWING:string = '';
	private TABLE_LIST_SHOWING_OF:string = '';
	private TABLE_LIST_ROWS:string = "";
	private DELETE_ALARMABLE_MODEM_SUCCESS: string = "";

	private tag: string = "AlarmableModemTabComponent:: ";
	public gridTabType: string = "ALARMABLEMODEMExport";
	private totalCount:number = 0;
	private selectedRowsModemIds: number[] = [];
	private ngUnsubscribe: Subject<void> = new Subject<void>();
	private alarmableModemTabGridRowData: any;
	public headerTxt: any;
	@ViewChild('targetAlarmableModemView', {read: ViewContainerRef}) _targetAlarmableModemView;


	constructor(private showAlert: ShowAlert,
				private logger: Logger,
				private localeDataService: LocaleDataService,
				private alarmableModemTabDataService: AlarmableModemTabDataService,
				private alarmableModemTabService: AlarmableModemTabService,
				private modemAlarmTabColumnDefinitionService: AlarmableModemTabColumnDefinitionService,
				private alarmableModemSharedService: AlarmableModemSharedService,
				private componentFactoryResolver: ComponentFactoryResolver) {
	}

	ngOnInit(){
		this.translateLocaleString();
		this.initAllSubjectListener();
		this.setEventButtonKeys();
	}

	public notifyRefreshGrid(): void{
		this.getAlarmableModemList();
	}

	private getAlarmableModemList(): void {
		this.alarmableModemTabDataService.getAlarmableModemList().subscribe(this.onNext.bind(this), null);
	}

	private onNext(modemAlarmListData): void {
		this.setGridRowData(modemAlarmListData);
	}

	private setGridRowData(modemAlarmListData: Array<NodeList>): void {
		this.modemAlarmTabRowData = modemAlarmListData;
		this.totalCount = this.modemAlarmTabRowData.length;
		this.setShowAllLabel(this.modemAlarmTabRowData.length, this.totalCount);
	}

	private setShowAllLabel(rowCount, totalCount): void {
		this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
		this.showAllLabelMob = rowCount + "/" + totalCount;
	}

	private setEventButtonKeys() {
		this.buttonKeys = [
			{name: this.CMTS_MODEM_ALARM_BTN_ADD_MODEM, tabType: cstmConstants.MODEM_ALARM_CONTS}
		];

		this.eventKeys = [
			{name: this.TABLE_LIST_EXPORT_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.MODEM_ALARM_CONTS},
			{name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.MODEM_ALARM_CONTS},
			{name: this.CMTS_MODEM_ALARM_DELETE_MODEM, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.MODEM_ALARM_CONTS}
		];
	}

	//updates row message.
	public modelUpdatedEmitter(e:any):void {
		let rowCount = this.alarmableModemTabGridOptions.api.getDisplayedRowCount();
		this.setShowAllLabel(rowCount, this.totalCount);
	}

	private setGridColumnDefinition(): void{
		this.showGridLoadingOverlay();
		this.alarmableModemTabGridOptions.api.setColumnDefs(this.modemAlarmTabColumnDefinitionService.getColumnDef());
		this.getAlarmableModemList();
	}

	private showGridLoadingOverlay(): void{
		this.alarmableModemTabGridOptions.api.showLoadingOverlay();
	}

	public notifyGridReadyALARMABLEMODEMCMTS():void{
		this.setGridColumnDefinition();
	}

	/*
     *@name modemAlarmCMTSEvent
     *@desc Events related to Modem Alarm tab (CSTM).
     *@return void
     */
	public notifyActionEmitter($event) {
		switch($event.event.name) {
			case this.CMTS_MODEM_ALARM_BTN_ADD_MODEM:
				this.notifyAddAlarmableModem();
				break;
			case this.CMTS_MODEM_ALARM_DELETE_MODEM:
				this.notifyDeleteAlarmableModem();
				break;
			default:
				break;
		}
	}

	private notifyAddAlarmableModem() {
		let data: any = {operation: ADD_OPERATION, alarmableModemModel: null};
		this.alarmableModemSharedService.setAlarmableModemModelData(data);
		this.LoadViewTab(AlarmableModemViewComponent);
	}

	/* Handle error & show sweet alert */
	private onError(error):void {
		this.logger.debug(this.tag, "onError(): error data=", error);
		this.alarmableModemTabGridOptions.api.hideOverlay();
		this.showAlert.showErrorAlert(error);
	}

	private translateLocaleString() {
		let localizationService = this.localeDataService.getLocalizationService();
		this.CMTS_MODEM_ALARM_BTN_ADD_MODEM = localizationService.instant('CMTS_MODEM_ALARM_BTN_ADD_MODEM');
		this.CMTS_MODEM_ALARM_DELETE_MODEM = localizationService.instant('CMTS_MODEM_ALARM_DELETE_MODEM');
		this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
		this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
		this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
		this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
		this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
		this.DELETE_ALARMABLE_MODEM_SUCCESS = localizationService.instant('DELETE_ALARMABLE_MODEM_SUCCESS');
	}

	private LoadViewTab(targetComponent: any, data?: any): void {
		this._targetAlarmableModemView.clear();
		const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
		let cmpRef = this._targetAlarmableModemView.createComponent(factory);
		cmpRef.instance.childData = data;
	}

	private notifyDeleteAlarmableModem() {
		let selectedRows: number[] = JSON.parse(JSON.stringify(this.storeSelection()));
		this.alarmableModemTabDataService.deleteAlarmableModem(selectedRows).subscribe(this.onDeleteAlarmableModeSuccessNext.bind(this), this.onError.bind(this));
	}

	private storeSelection() {
		this.selectedRowsModemIds.length = 0;
		this.alarmableModemTabService.getSelectedModemIds(this.alarmableModemTabGridOptions.api.getSelectedRows(), this.selectedRowsModemIds);
		return this.selectedRowsModemIds;
	}

	private alarmableModemRefreshSubjectListner(): void{
		this.alarmableModemSharedService.getAlarmableModemListRefreshSubject()
			.pipe(takeUntil(this.ngUnsubscribe))
			.subscribe((isHardReset) => {
				this.clearGridData();
				this.getAlarmableModemList();
		})
	}

	private clearGridData(): void {
		this.storeSelection();
		this.alarmableModemTabGridRowData = [];
	}

	private onTabSwitch(): void {
		this.getAlarmableModemList();
	}

	private onDeleteAlarmableModeSuccessNext(): void {
		this.showAlert.showInfoAlert(this.DELETE_ALARMABLE_MODEM_SUCCESS);
		this.getAlarmableModemList();
	}

	private alarmableModemTabFormChangeSubjectListener(): void{
		this.alarmableModemSharedService
			.getAlarmableModemTabFormChangeSubject()
			.pipe(takeUntil(this.ngUnsubscribe))
			.subscribe(() => {
				this.LoadViewTab(AlarmableModemViewComponent);
				this.viewData = !this.viewData;
			});
	}

	private initAllSubjectListener() {
		this.alarmableModemTabFormChangeSubjectListener();
		this.alarmableModemRefreshSubjectListner();
	}
}