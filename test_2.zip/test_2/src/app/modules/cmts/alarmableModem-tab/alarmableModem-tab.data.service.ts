import { map,catchError } from 'rxjs/operators';
/**
 * Created by jerry.blum on 2020-09-23
 */

import {Injectable} from '@angular/core';
import {CMTSHttpService} from '../cmts.http.service';
import {Observable, throwError} from 'rxjs';
import {AlarmableModemModel} from './alarmableModem-tab.model';
//import {Response} from '@angular/http';

@Injectable()
export class AlarmableModemTabDataService {

	private alarmableModemList: Array<AlarmableModemModel> = new Array<AlarmableModemModel>();

	constructor(private cmtsHttpService: CMTSHttpService) {
	}

	public getModemDetail(modemId:number): Observable<any> {
		return this.cmtsHttpService
			.getModemDetails(modemId)
			.map((modemDataObj) => {
				return modemDataObj;
			})
			.catch(this.handleError);
	}

	public getAlarmableModemList(): Observable<any> {
		this.alarmableModemList = [];
		return this.cmtsHttpService
			.getAlarmableModemListData()
			.pipe(
				map((modemAlarmListDataObj) => {
					console.log('get getAlarmableModemList', modemAlarmListDataObj);
					this.setAlarmableModemList(modemAlarmListDataObj);
					return this.alarmableModemList;
				})
				,catchError(this.handleError)
			)
	}

	public handleError(error) {
		return throwError(error);
	}

	private setAlarmableModemList(dataListObj): void {
		for (let i = 0; i < dataListObj.length; i++) {
			let alarmableModemModel: AlarmableModemModel = new AlarmableModemModel(dataListObj[i],null);
			this.alarmableModemList.push(alarmableModemModel);
		}
	}

	public addAlarmableModem(data: any, modemId: any): Observable<any> {
		return this.cmtsHttpService
			.addAlarmableModem(data, modemId)
			.pipe(
				map((res) => {
					console.log('get addAlarmableModem', res);
					return res;
				})
				,catchError(this.handleError)
			)
	}

	public getRemainingAlarmableModems(): any {
		return this.cmtsHttpService
			.getRemainingAlarmableModes();
	}

	public deleteAlarmableModem(selectedRows: number[]): Observable<any> {
		return this.cmtsHttpService.deleteAlarmableModems(selectedRows);
	}

	public updateAlarmableModem(dataModel: AlarmableModemModel) {
		return this.cmtsHttpService
			.updateAlarmableModem(dataModel)
			.pipe(
				map((res) => {
					console.log('get updateAlarmableModem', res);
					return res;
				})
				,catchError(this.handleError)
			)
	}
}