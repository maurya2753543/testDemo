import {Component} from '@angular/core';
import 'rxjs/Rx';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {SharedService} from '../../../../shared/shared.service';
import {AlarmableModemModel} from '../alarmableModem-tab.model';
import {ShowAlert} from '../../../../utilities/showAlert';
import {AlarmableModemTabDataService} from '../alarmableModem-tab.data.service';
import {Observable} from 'rxjs';
import {ADD_OPERATION, EDIT_OPERATION} from '../../cmts-tab.constants';
import {AlarmableModemSharedService} from '../alarmableModem.shared.service';
import { AbstractControl } from '@angular/forms';

@Component({
	selector: 'addalarmablemodem',
	templateUrl: './alarmableModem-view.component.html'
})

export class AlarmableModemViewComponent {

	public isCloseRightSlider: boolean = false;
	public isSaveBtnDisabled: boolean = true;
	public isEditHidden: boolean;
	private isEdit : boolean = false;
	public isReadOnly: boolean;
	public isAddActive: boolean = true;
	private newModemId: any;
	private remainingAlarmableModemsText: Observable<string>;
	private remainingAlarmableModemsCount: number;
	private currentOperation: string;
	public enabled: boolean = false;
	public isExpirationEnabled: boolean = true;

	public dataModel: AlarmableModemModel = new AlarmableModemModel({}, null);
	public custumorDetail:boolean = true;

	private errorMessages: any = {
		isModemEmpty: false
	}

	constructor(private localeDataService: LocaleDataService,
				private sharedService: SharedService,
				private showAlert: ShowAlert,
				private alarmableModemTabDataService: AlarmableModemTabDataService,
				private alarmableModemSharedService: AlarmableModemSharedService) {}

	ngOnInit() {
		this.closeSliderSubjectListener();
		this.isCloseRightSlider = false;
		this.clearFormData(false,false);
		this.alarmableModemTabFormChangeSubjectListener();
		this.setFormData(this.alarmableModemSharedService.getAlarmableModemModelData());
		this.dataModel.expirationDuration = 1;

		this.remainingAlarmableModemsText = this.alarmableModemTabDataService.getRemainingAlarmableModems()
			.map((res) => {
				this.remainingAlarmableModemsCount = res;
				if(this.remainingAlarmableModemsCount == 0){
					this.isSaveBtnDisabled = true;
				} 
				return res;
			});
	}

	private closeSliderSubjectListener() {
		this.sharedService.getCloseSlidersSubject().subscribe((res) => {
			if(res) this.btnClose_click();
		})
	}

	public btnClose_click(): void {
		this.isCloseRightSlider = true;
	}

	public onSubmit(): void{
		if(this.currentOperation === EDIT_OPERATION){
			this.postData();
		} else if(this.currentOperation === ADD_OPERATION){
			this.addData();
		}
	}

	private postData(): void{
		this.alarmableModemTabDataService.updateAlarmableModem(this.dataModel).subscribe(
			this.onSubmitSuccess.bind(this),
			this.onError.bind(this)
		);
	}

	private addData(): void{
		this.dataModel.source = "UI"
		this.alarmableModemTabDataService.addAlarmableModem(this.dataModel, this.newModemId).subscribe(
			this.onSubmitSuccess.bind(this),
			this.onError.bind(this)
		);
	}

	private onSubmitSuccess(data: any) {
		this.clear();
	}

	//Method to handle sweet alert
	private onError(error): void{
		this.showAlert.showErrorAlert(error);
	}

	private clear(): void {
		this.clearFormData(true, true);
	}

	private clearFormData(isHardReset: boolean, closeSlider: boolean) {
		this.refreshAlarmableModemList(isHardReset);
		this.setDataModel(null);
		this.isReadOnly = true;
		if(closeSlider){
			this.btnClose_click();
		}
	}

	private setFormData(formData: any): void{
		if(formData){
			this.currentOperation = formData.operation;
			this.validateOperation(this.currentOperation);
			this.setDataModel(formData.alarmableModemTabModel);
		}
	}

	private setDataModel(alarmableModemData: AlarmableModemModel): any {
		if(alarmableModemData){
			this.dataModel.modem = alarmableModemData.modem;
			this.dataModel.modemId = alarmableModemData.modemId;
			this.dataModel.address = alarmableModemData.address;
			this.dataModel.customerName = alarmableModemData.customerName;
			this.dataModel.phoneNumber = alarmableModemData.phoneNumber;
			this.dataModel.source = alarmableModemData.source;
			this.dataModel.expiration = this.sharedService.getLocaleDate(alarmableModemData.expiration);
			this.dataModel.nodeName = alarmableModemData.nodeName;
			this.dataModel.expirationDuration = alarmableModemData.expirationDuration;

			if(this.dataModel.expiration == null){
				this.enabled = true;
				this.isExpirationEnabled = false;
			} else {
				this.enabled = false;
				this.isExpirationEnabled = true;
			}
		}
	}

	getSelectedModemId(modemId: any) {
		if(modemId > 0){
			this.newModemId = modemId;
			this.alarmableModemTabDataService.getModemDetail(modemId).subscribe(this.onNext.bind(this), null);
			this.isSaveBtnDisabled = false;
			this.errorMessages.isModemEmpty = false
		}
	}

	private onNext(modemData): void {
		this.custumorDetail = false;
		this.dataModel.modem = modemData.modem;
		this.dataModel.modemId = modemData.modemId;
		this.dataModel.address = modemData.address;
		this.dataModel.customerName = modemData.customerName;
		this.dataModel.phoneNumber = modemData.phoneNumber;
		this.dataModel.source = 'API';
		this.dataModel.expiration = this.sharedService.getLocaleDate(modemData.expiration);
		this.dataModel.nodeName = modemData.nodeName;
		
	}

	getModemSearchType() {
		return "alarmablemodem";
	}

	//Method to toggle Edit View
	public toggleEdit(): void {
		this.isReadOnly = false;
		this.onEdit(this.isReadOnly);
	}

	private onEdit(flag: boolean): void {
		this.toggleEditVisibility(!flag);
	}

	private toggleEditVisibility(flag: boolean): void {
		this.isEditHidden = flag;
	}

	private validateOperation(operation: string): void{
		if(operation == EDIT_OPERATION){
			this.isReadOnly = true;
			this.isAddActive = false;
			this.isEdit = true;
			this.onEdit(true);
		} else if(operation == ADD_OPERATION){
			this.isAddActive = true;
			this.isReadOnly = false;
			this.isEdit = false;
		}
	}

	private alarmableModemTabFormChangeSubjectListener() {
		this.alarmableModemSharedService.getAlarmableModemTabFormChangeSubject().subscribe((formData: any) =>{
			this.setFormData(formData);
		});
	}

	public onChange() {
		if(this.enabled){
			this.enabled = false;
			this.isExpirationEnabled = true;
		} else {
			this.enabled = true;
			this.isExpirationEnabled = false;
			this.dataModel.expirationDuration = 0;
		}
		this.isSaveBtnDisabled = false;
	}

	public updateExpiration(event: any){
		if(event != ""){
			this.isSaveBtnDisabled = false;
		} else {
			this.isSaveBtnDisabled = true;
		}
	}

	private refreshAlarmableModemList(isHardReset: boolean) {
		this.alarmableModemSharedService.getAlarmableModemListRefreshSubject().next(isHardReset);
	}

	// Resets blank values to 0 on the form on blur.
	private onBlurMethod(control: AbstractControl): void {
		if (control.value == null) {
			control.setValue(0);
		}
	}
}