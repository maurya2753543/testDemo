/**
 * Created by jerry.blum on 10/22/2020
 */

import {Injectable} from '@angular/core';
import {SharedService} from '../../../shared/shared.service';
import {PATHTRAK_PATH} from '../../../constant/app.constants';

@Injectable()
export class ModemWatchUrlService {
	private host: string = "";

	constructor(private sharedService: SharedService) {
		this.setHost();
	}

	private setHost(): void {
		this.host = this.sharedService.getHost();
	}

	private getHost(): string {
		return this.host + PATHTRAK_PATH;
	}

	public getModemWatchUrl(): string {
		return this.getHost() + "modemwatch";
	}

	public getAddModemWatchUrl(): string {
		return this.getHost() + "modemwatch";
	}

	public getRemainingModemWatchesUrl(): string {
		return this.getHost() + "modemwatch/availableCount";
	}

	public getDeleteModemWatchUrl(): string {
		return this.getHost() + "modemwatch/";
	}

	public getUpdateModemWatchUrl(expiration: string) {
		return this.getHost() + "modemwatch?watchDays=" + expiration;
	}
}