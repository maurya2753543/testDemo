/**
 * Created by jerry.blum 10/22/2020.
 **/


import {Injectable} from '@angular/core';
import {ModemWatchModel} from './modemWatch-tab.model';

@Injectable()
export class ModemWatchTabService{

	//Method to get selected rows from grid
	public getSelectedModemIds(modemWatchModels: ModemWatchModel[], selectedRowModemsId: number[]): void {
		modemWatchModels.forEach((modemWatchModel: ModemWatchModel)=>{
			selectedRowModemsId.push(modemWatchModel.elementId);
		});
	}
}