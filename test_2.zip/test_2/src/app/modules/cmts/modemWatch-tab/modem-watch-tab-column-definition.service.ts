import {Injectable} from '@angular/core';
import {LocaleDataService} from '../../../shared/locale.data.service';
import {SharedService} from '../../../shared/shared.service';
import {gridCustomComparator} from '../../../shared/ag-Grid.comparator';
import {TimeFilter} from "../../../shared/time.filter";
import {DisabledFilter} from '../../shared/grid/disabled.filter';
import {EDIT_ICON} from '../../../constant/app.constants';
import {ModemWatchSharedService} from './modem-watch.shared.service';
import {Subject} from 'rxjs';
import {EDIT_OPERATION} from '../cmts-tab.constants';

@Injectable()
export class ModemWatchTabColumnDefinitionService {
	private _HEADER_FIELDS: any = {
		modem: {field: "mac", name: "CMTS_MODEM_WATCH_TAB_MODEMMAC"},
		addType: {field: "addType", name: "CMTS_MODEM_WATCH_TAB_ADD_TYPE"},
		customerName: {field: "customerName", name: "CMTS_MODEM_WATCH_TAB_CUSTOMER_NAME"},
		phoneNumber: {field: "phoneNumber", name: "CMTS_MODEM_WATCH_TAB_PHONE_NUMBER"},
		startTime: {field: "startTime", name: "CMTS_MODEM_WATCH_TAB_START_TIME"},
		expirationTime: {field: "expirationTime", name: "CMTS_MODEM_WATCH_TAB_EXPIRATION_TIME"},
		edit : {field: "edit", name: "Edit"},
	};

	private modemWatchTabFormChangeSubject: Subject<any>;

	constructor(private localeDataService: LocaleDataService,
				private sharedService: SharedService,
				private modemWatchSharedService: ModemWatchSharedService) {
		this.modemWatchTabFormChangeSubject = this.modemWatchSharedService.getModemWatchTabFormChangeSubject();
	}

	private translateLocaleStr(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this._HEADER_FIELDS.modem.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_MODEMMAC');
		this._HEADER_FIELDS.addType.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_ADD_TYPE');
		this._HEADER_FIELDS.customerName.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_CUSTOMER_NAME');
		this._HEADER_FIELDS.phoneNumber.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_PHONE_NUMBER');
		this._HEADER_FIELDS.startTime.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_START_TIME');
		this._HEADER_FIELDS.expirationTime.name = localizationService.instant('CMTS_MODEM_WATCH_TAB_EXPIRATION_TIME');
		this._HEADER_FIELDS.edit.name = localizationService.instant('CMTS_TAB_HEADER_EDIT');

	}

	public getColumnDef(): any[] {
		this.translateLocaleStr();

		let columnDef: any[] = [
			{
				headerName: '',
				width: 21,
				checkboxSelection: true,
				pinned: true,
				sortingOrder: [null],
				field: '',
				headerCheckboxSelection: true,
				suppressFilter: true,
				suppressSizeToFit: true,
				suppressMenu: true,
				filterParams: {newRowsAction: 'keep'},
				suppressResize: true
			},
			{
				headerName: this._HEADER_FIELDS.modem.name,
				headerToolTip: this._HEADER_FIELDS.modem.name,
				field: this._HEADER_FIELDS.modem.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modem.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.addType.name,
				headerToolTip: this._HEADER_FIELDS.addType.name,
				field: this._HEADER_FIELDS.addType.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.addType.name, 60),
				filter: 'text', floatingFilterComponentParams: {suppressFilterButton:true},
				comparator: gridCustomComparator,
				filterParams: {newRowsAction: 'keep'}
			},
			{
				headerName: this._HEADER_FIELDS.startTime.name,headerTooltip: this._HEADER_FIELDS.startTime.name, field: this._HEADER_FIELDS.startTime.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.startTime.name, 90),
				floatingFilterComponentParams:{ suppressFilterButton:true },
				comparator: this.sharedService.dateComparator,
				filterParams: {newRowsAction: 'keep'},
				filter: TimeFilter.ParentFilter,
				floatingFilterComponent: TimeFilter.ChildFloatingFilter,
				cellRenderer:(params:any)=>{
					let dateInSpanish = this.sharedService.getLocaleDate(params.value);// moment(params.value).format('lll');
					return dateInSpanish;
				}
			},
			{
				headerName: this._HEADER_FIELDS.expirationTime.name,headerTooltip: this._HEADER_FIELDS.expirationTime.name, field: this._HEADER_FIELDS.expirationTime.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.expirationTime.name, 90),
				floatingFilterComponentParams:{ suppressFilterButton:true },
				comparator: this.sharedService.dateComparator,
				filterParams: {newRowsAction: 'keep'},
				filter: TimeFilter.ParentFilter,
				floatingFilterComponent: TimeFilter.ChildFloatingFilter,
				cellRenderer:(params:any)=>{
					let dateInSpanish = this.sharedService.getLocaleDate(params.value);// moment(params.value).format('lll');
					return dateInSpanish;
				}
			},
			{
				headerName: this._HEADER_FIELDS.edit.name, headerToolTip: this._HEADER_FIELDS.edit.name,
				minWidth: 70, maxWidth: 150,
				pinned: this.sharedService.isPinned(),
				sortingOrder: [null],
				suppressSorting : true,
				cellStyle : () => {
					return { 'text-align': 'center' };
				},
				filter: 'text',
				comparator: gridCustomComparator,
				floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {newRowsAction: 'keep'},
				suppressMenu: true,
				cellRenderer: ((param:any)=>{
					let gui = document.createElement('div');
					gui.innerHTML = EDIT_ICON;
					let eFilterText = gui.querySelector('i');
					eFilterText.addEventListener("click", (()=>{
						this.action(param);
					}));
					gui.className = "ag-Grid-cursor";
					return gui;
				})
			}

		]
		return columnDef;
	}

	private action(param: any) {
		let data: any = {operation: EDIT_OPERATION, modemWatchModel: param.data};
		this.modemWatchSharedService.setModemWatchModelData(data);
		this.modemWatchTabFormChangeSubject.next(data);
	}
}