/**
 * Created by jerry.blum 10-22-2020
 */

import { Injectable} from '@angular/core';
import {Subject} from 'rxjs';

@Injectable()
export class ModemWatchSharedService {
	private modemWatchFormChangeSubject: Subject<any>;
	private modemWatchListRefreshSubject: Subject<any>;
	private modemWatchModelData: any;

	constructor() {
		this.initSubject();
	}

	private initSubject(): void {
		this.modemWatchFormChangeSubject = new Subject();
		this.modemWatchListRefreshSubject = new Subject();
	}

	public setModemWatchModelData(data: any) {
		this.modemWatchModelData = data;
	}

	public getModemWatchModelData(): any {
		return this.modemWatchModelData;
	}

	public getModemWatchListRefreshSubject(): Subject<any>{
		return this.modemWatchListRefreshSubject;
	}

	getModemWatchTabFormChangeSubject() {
		return this.modemWatchFormChangeSubject;
	}
}