import {Component, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';
import {ShowAlert} from '../../../utilities/showAlert';
import {Logger} from '../../../utilities/logger';
import {LocaleDataService} from '../../../shared/locale.data.service';
import * as cstmConstants from '../cmts-tab.constants';
import {ModemWatchTabColumnDefinitionService} from './modem-watch-tab-column-definition.service';
import {Grid} from '../../../shared/ag-grid.options';
import {ModemWatchTabService} from './modem-watch-tab.service';
import {ModemWatchTabDataService} from './modem-watch-tab.data.service';
import {ModemWatchSharedService} from './modem-watch.shared.service';
import {ModemWatchViewComponent} from './modemWatch-view/modem-watch-view.component';
import {ADD_OPERATION} from '../cmts-tab.constants';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
@Component({
	selector: 'modem-watch-tab-component',
	templateUrl: 'modem-watch-tab.component.html'
})

export class ModemWatchTabComponent{

	public modemWatchTabGridOptions: Grid = new Grid();
	public eventKeys: Object[];
	public buttonKeys: Object[];
	public modemWatchTabRowData: any;
	private totalCount:number = 0;
	public showAllLabel: string = '';
	public showAllLabelMob: string = '';
	private selectedRowsModemIds: number[] = [];
	private tag:string = "MODEMWATCHTabComponent:: ";
	private ngUnsubscribe: Subject<void> = new Subject<void>();
	public viewData: boolean = false;

	private CMTS_MODEM_WATCH_BTN_ADD_MODEM: string = ""
	private CMTS_MODEM_WATCH_DELETE_MODEM: string = "";
	private TABLE_LIST_EXPORT_SELECTED: string = "";
	private TABLE_LIST_EXPORT_ALL: string = "";
	private TABLE_LIST_SHOWING:string = '';
	private TABLE_LIST_SHOWING_OF:string = '';
	private TABLE_LIST_ROWS:string = "";
	private DELETE_MODEM_WATCH_SUCCESS: string;
	public headerTxt: string;

	public gridTabType: any;
	
	@ViewChild('targetModemWatchView', {read: ViewContainerRef}) _targetModemWatchView;


	constructor(private showAlert: ShowAlert,
				private logger: Logger,
				private localeDataService: LocaleDataService,
				private componentFactoryResolver: ComponentFactoryResolver,
				private modemWatchTabColumnDefinitionService: ModemWatchTabColumnDefinitionService,
				private modemWatchTabService: ModemWatchTabService,
				private modemWatchTabDataService: ModemWatchTabDataService,
				private modemWatchSharedService: ModemWatchSharedService) {}

	ngOnInit(){
		this.translateLocaleString();
		this.initAllSubjectListener();
		this.setEventButtonKeys();
	}

	private translateLocaleString() {
		let localizationService = this.localeDataService.getLocalizationService();
		this.CMTS_MODEM_WATCH_BTN_ADD_MODEM = localizationService.instant('CMTS_MODEM_WATCH_BTN_ADD_MODEM');
		this.CMTS_MODEM_WATCH_DELETE_MODEM = localizationService.instant('CMTS_MODEM_WATCH_DELETE_MODEM');
		this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
		this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
		this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
		this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
		this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
		this.DELETE_MODEM_WATCH_SUCCESS = localizationService.instant('DELETE_MODEM_WATCH_SUCCESS');
	}

	private LoadViewTab(targetComponent: any, data?: any): void {
		this._targetModemWatchView.clear();
		const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
		let cmpRef = this._targetModemWatchView.createComponent(factory);
		cmpRef.instance.childData = data;
	}

	private setEventButtonKeys() {
		this.buttonKeys = [
			{name: this.CMTS_MODEM_WATCH_BTN_ADD_MODEM, tabType: cstmConstants.MODEM_WATCH_CONTS}
		];

		this.eventKeys = [
			{name: this.TABLE_LIST_EXPORT_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.MODEM_ALARM_CONTS},
			{name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.MODEM_ALARM_CONTS},
			{name: this.CMTS_MODEM_WATCH_DELETE_MODEM, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.MODEM_WATCH_CONTS}
		]
	}

	private onNext(modemWatchListData): void {
		this.setGridRowData(modemWatchListData);
	}

	private setGridRowData(modemWatchListData: any) {
		this.modemWatchTabRowData = modemWatchListData;
		this.totalCount = this.modemWatchTabRowData.length;
		this.setShowAllLabel(this.modemWatchTabRowData.length, this.totalCount);
	}

	public notifyActionEmitter($event) {
		switch($event.event.name) {
			case this.CMTS_MODEM_WATCH_BTN_ADD_MODEM:
				this.notifyAddModemWatch();
				break;
			case this.CMTS_MODEM_WATCH_DELETE_MODEM:
				this.notifyDeleteModemWatch();
				break;
			default:
				break;
		}
	}

	public modelUpdatedEmitter(e:any): void {
		let rowCount = this.modemWatchTabGridOptions.api.getDisplayedRowCount();
		this.setShowAllLabel(rowCount, this.totalCount);
	}

	public notifyRefreshGrid(): void {
		this.getModemWatchList();
	}

	public notifyGridReadyMODEMWATCHCMTS(): void {
		this.setGridColumnDefinition();
	}

	private notifyAddModemWatch() {
		let data: any = {operation: ADD_OPERATION, modemWatchModel: null};
		this.modemWatchSharedService.setModemWatchModelData(data);
		this.LoadViewTab(ModemWatchViewComponent);
	}

	private notifyDeleteModemWatch() {
		let selectedRows: number[] = JSON.parse(JSON.stringify(this.storeSelection()));
		this.modemWatchTabDataService.deleteModemWatch(selectedRows)
			.subscribe(this.onDeleteModemWatchSuccessNext.bind(this), this.onError.bind(this));
	}

	private getModemWatchList() {
		this.modemWatchTabDataService.getModemWatchList().subscribe(this.onNext.bind(this), null);
	}

	private setGridColumnDefinition() {
		this.showGridLoadingOverlay();
		this.modemWatchTabGridOptions.api.setColumnDefs(this.modemWatchTabColumnDefinitionService.getColumnDef());
		this.getModemWatchList();
	}

	private showGridLoadingOverlay() {
		this.modemWatchTabGridOptions.api.showLoadingOverlay();
	}

	private setShowAllLabel(rowCount: any, totalCount: number) {
		this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
		this.showAllLabelMob = rowCount + "/" + totalCount;
	}

	private storeSelection() {
		this.selectedRowsModemIds.length = 0;
		this.modemWatchTabService.getSelectedModemIds(this.modemWatchTabGridOptions.api.getSelectedRows(), this.selectedRowsModemIds);
		return this.selectedRowsModemIds;
	}

	private onTabSwitch(): void {
		this.getModemWatchList();
	}

	private onDeleteModemWatchSuccessNext(): void{
		this.showAlert.showInfoAlert(this.DELETE_MODEM_WATCH_SUCCESS);
		this.getModemWatchList();
	}

	/* Handle error & show sweet alert */
	private onError(error) {
		this.logger.debug(this.tag, "onError(): error data=", error);
		this.hideGridOverly();
		this.showAlert.showErrorAlert(error);
	}

	/*Method to hide overlay text from table*/
	private hideGridOverly(): void{
		this.modemWatchTabGridOptions.api.hideOverlay();
	}

	private modemWatchTabFormChangeSubjectListener(): void{
		this.modemWatchSharedService
			.getModemWatchTabFormChangeSubject()
			.pipe(takeUntil(this.ngUnsubscribe))
			.subscribe(() => {
				this.LoadViewTab(ModemWatchViewComponent);
				this.viewData = !this.viewData;
			})
	}

	private initAllSubjectListener(){
		this.modemWatchTabFormChangeSubjectListener();
		this.modemWatchRefreshSubjectListener();
	}

	private modemWatchRefreshSubjectListener() {
		this.modemWatchSharedService.getModemWatchListRefreshSubject()
			.pipe(takeUntil(this.ngUnsubscribe))
			.subscribe((isHardReset) => {
				this.clearGridData();
				this.getModemWatchList();
			})
	}

	private clearGridData() {
		this.storeSelection();
		this.modemWatchTabRowData = [];
	}
}