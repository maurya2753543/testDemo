/**
 * Created by jerry.blum 10/22/2020
 */

import {Injectable} from '@angular/core';
import {HttpService} from '../../../shared/http.service';
import {ModemWatchUrlService} from './modem-watch.url.service';
import {Observable} from 'rxjs';
import {ModemWatchModel} from './modemWatch-tab.model';

@Injectable()
export class ModemWatchHttpService {

	constructor(private httpService: HttpService, private modemWatchUrlService: ModemWatchUrlService) {}

	public getModemWatchListData() {
		return this.httpService.GET(this.modemWatchUrlService.getModemWatchUrl());
	}

	public addModemWatch(modemIds: any): Observable<any> {
		return this.httpService.PUT(this.modemWatchUrlService.getAddModemWatchUrl(), modemIds);
	}

	public getRemainingModemWatches(): any {
		return this.httpService.getData(this.modemWatchUrlService.getRemainingModemWatchesUrl());
	}

	public deleteModemWatch(selectedRow: number[]): Observable<any> {
		return this.httpService.DELETEWITHDATA(this.modemWatchUrlService.getDeleteModemWatchUrl(), selectedRow);
	}

	public updateModemWatch(dataModel: ModemWatchModel): Observable<any> {
		let modemIds: number[] = [];
		modemIds.push(dataModel.elementId);
		let url = this.modemWatchUrlService.getUpdateModemWatchUrl(dataModel.expiration.toString());
		console.log("Url: " + url);
		return this.httpService.POST(this.modemWatchUrlService.getUpdateModemWatchUrl(dataModel.expiration.toString()), modemIds);
	}
}