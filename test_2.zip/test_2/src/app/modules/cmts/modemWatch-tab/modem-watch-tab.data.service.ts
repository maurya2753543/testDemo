
import { map ,catchError} from 'rxjs/operators';
/**
 * Created by jerry.blum on 10/22/2020
 */

import {Injectable} from '@angular/core';
import {ModemWatchModel} from './modemWatch-tab.model';
import {Observable, throwError} from 'rxjs';
import {ModemWatchHttpService} from './modem-watch.http.service';

@Injectable()
export class ModemWatchTabDataService {
	private modemWatchList: Array<ModemWatchModel> = new Array<ModemWatchModel>();

	constructor(private modemWatchHttpService: ModemWatchHttpService) {
	}

	public getModemWatchList(): Observable<any> {
		this.modemWatchList = [];
		return this.modemWatchHttpService
			.getModemWatchListData()
			.pipe(
				map((modemWatchListDataObj) => {
				this.setModemWatchList(modemWatchListDataObj);
				return this.modemWatchList;
			}),catchError(this.handleError)
			)
	}

	public handleError(error) {
		return throwError(error);
	}

	private setModemWatchList(dataListObj): void {
		for(let i = 0; i< dataListObj.length; i++) {
			let modemWatchModel: ModemWatchModel = new ModemWatchModel(dataListObj[i]);
			this.modemWatchList.push(modemWatchModel);
		}
	}

	public addModemWatch(modemIds): Observable<any> {
		return this.modemWatchHttpService
			.addModemWatch(modemIds)
			.pipe(catchError(this.handleError))
		
	}

	public getRemainingModemWatches(): any {
		return this.modemWatchHttpService
			.getRemainingModemWatches();
	}

	public deleteModemWatch(selectedRow: number[]): Observable<any> {
		return this.modemWatchHttpService.deleteModemWatch(selectedRow);
	}

	public updateModemWatch(dataModel: ModemWatchModel): Observable<any> {
		return this.modemWatchHttpService
			.updateModemWatch(dataModel)
			.pipe(
			catchError(this.handleError)
			)
	}
}