import {Component} from '@angular/core';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {SharedService} from '../../../../shared/shared.service';
import {ShowAlert} from '../../../../utilities/showAlert';
import {ModemWatchTabDataService} from '../modem-watch-tab.data.service';
import {Observable} from 'rxjs';
import {ModemWatchModel} from '../modemWatch-tab.model';
import {ADD_OPERATION, EDIT_OPERATION} from '../../cmts-tab.constants';
import {ModemWatchSharedService} from '../modem-watch.shared.service';

@Component({
	selector: 'viewModemWatch',
	templateUrl: './modem-watch-view.component.html'
})

export class ModemWatchViewComponent {

	public isCloseRightSlider: boolean = false;
	public isSaveBtnDisabled: boolean = true;
	public isReadOnly: boolean;
	private newModemId: any;
	private remainingModemWatchesText: Observable<string>;
	private remainingModemWatchesCount: number;

	public isAddActive: boolean = true;
	private isEdit : boolean = false;
	public isEditHidden: boolean;
	private currentOperation: string;
	private enabled: boolean;
	private isExpirationEnabled: boolean = true;

	private dataModel: ModemWatchModel = new ModemWatchModel({});

	private errorMessages: any = {
		isExpirationEmpty: false
	}

	constructor(private localeDataService: LocaleDataService,
				private sharedService: SharedService,
				private showAlert: ShowAlert,
				private modemWatchTabDataService: ModemWatchTabDataService,
				private modemWatchSharedService: ModemWatchSharedService){}

	ngOnInit(){
		this.closeSliderSubjectListener();
		this.isCloseRightSlider = false;
		this.clearFormData(false,false);
		this.modemWatchTabFormChangeSubjectListener();
		this.setFormData(this.modemWatchSharedService.getModemWatchModelData());

		this.remainingModemWatchesText = this.modemWatchTabDataService.getRemainingModemWatches()
			.map((res) => {
				this.remainingModemWatchesCount = res;
				if(this.remainingModemWatchesCount == 0){
					this.isSaveBtnDisabled = true;
				} 
				return res;
			});
	}

	private closeSliderSubjectListener() {
		this.sharedService.getCloseSlidersSubject().subscribe((res) => {
			if(res) this.btnClose_click();
		});
	}

	public btnClose_click(): void {
		this.isCloseRightSlider = true;
	}

	public onSubmit(): void {
		if(this.currentOperation === EDIT_OPERATION){
			this.postData();
		} else if(this.currentOperation === ADD_OPERATION){
			this.addData();
		}
	}

	private postData() {
		this.modemWatchTabDataService.updateModemWatch(this.dataModel).subscribe(
			this.onSubmitSuccess.bind(this),
			this.onError.bind(this)
		);
	}

	private addData() {
		this.dataModel.addType = "UI";
		let modemIds = [];
		modemIds.push(this.newModemId);
		this.modemWatchTabDataService.addModemWatch(modemIds).subscribe(
			this.onSubmitSuccess.bind(this),
			this.onError.bind(this)
		);
	}

	//Method to handle sweet alert
	private onError(error): void{
		this.showAlert.showErrorAlert(error);
	}

	private onSubmitSuccess(data: any) {
		this.clear();
	}

	private onChange($event: any) {
		if(this.enabled){
			this.enabled = false;
			this.isExpirationEnabled = true;
			this.isSaveBtnDisabled = true;
		} else {
			this.enabled = true;
			this.isExpirationEnabled = false;
			this.isSaveBtnDisabled = false;
			this.dataModel.expiration = 0;
		}
	}

	private clear(): void {
		this.clearFormData(true, true);
	}

	private clearFormData(isHardReset: boolean, closeSlider: boolean) {
		this.refreshModemWatchList(isHardReset);
		this.setDataModel(null);
		this.currentOperation = null;
		this.isReadOnly = true;
		this.toggleEditVisibility(true);
		if(closeSlider){
			this.btnClose_click();
		}
	}

	private setDataModel(modemWatchData: ModemWatchModel): any {
		if(modemWatchData){
			this.dataModel.elementId = modemWatchData.elementId;
			this.dataModel.mac = modemWatchData.mac;
			this.dataModel.addType = modemWatchData.addType;
			this.dataModel.startTime = this.sharedService.getLocaleDate(modemWatchData.startTime);
			this.dataModel.expirationTime = this.sharedService.getLocaleDate(modemWatchData.expirationTime);
			this.dataModel.latestError = modemWatchData.latestError;
			this.dataModel.totalErrors = modemWatchData.totalErrors;

			if(this.dataModel.expirationTime == null){
				this.enabled = true;
				this.isExpirationEnabled = false;
			} else {
				this.enabled = false;
				this.isExpirationEnabled = true;
			}
		}
	}

	getSelectedModemId(modemId: any) {
		if(modemId > 0){
			this.newModemId = modemId;
			//Add selected ModemId to text box

			this.isSaveBtnDisabled = false;
		}
	}

	getModemSearchType() {
		return "modemwatch";
	}

	private setFormData(formData: any): void{
		if(formData){
			this.currentOperation = formData.operation;
			this.validateOperation(this.currentOperation);
			this.setDataModel(formData.modemWatchModel);
		}
	}

	private validateOperation(operation: string): void {
		if(operation == EDIT_OPERATION){
			this.isReadOnly	= true;
			this.isAddActive = false;
			this.isEdit = true;
			this.onEdit(true);
		} else if(operation == ADD_OPERATION){
			this.isAddActive = true;
			this.isReadOnly = false;
			this.isEdit = false;
		}
	}

	public toggleEdit(): void {
		this.isReadOnly = false;
		this.onEdit(this.isReadOnly);
	}
	private onEdit(flag: boolean): void {
		this.toggleEditVisibility(!flag);
	}

	private toggleEditVisibility(flag: boolean): void {
		this.isEditHidden = flag;
	}

	private modemWatchTabFormChangeSubjectListener(){
		this.modemWatchSharedService.getModemWatchTabFormChangeSubject().subscribe((formData: any) =>{
			this.setFormData(formData);
		});
	}

	private updateExpiration(event: any) {
		if(event != ""){
			this.isSaveBtnDisabled = false;
		} else {
			this.isSaveBtnDisabled = true;
		}
	}

	private refreshModemWatchList(isHardReset: boolean) {
		this.modemWatchSharedService.getModemWatchListRefreshSubject().next(isHardReset);
	}

	private isExpirationEmpty(): void {
		if(this.dataModel.expiration != null && this.dataModel.expiration != 0){
			this.errorMessages.isExpirationEmpty = false;
			if(this.isEdit) this.isSaveBtnDisabled = false;
		} else {
			this.errorMessages.isExpirationEmpty = true;
		}
	}
}