/**
 * Created by jerry.blum 10/22/2020.
 **/

export class ModemWatchModel {
	public elementId: number;
	public mac : string;
	public addType: string;
	public startTime: Date;  //Is this the correct type for this
	public expirationTime: Date; //Same above
	public latestError: number;
	public totalErrors: number;
	public debug: boolean;
	public expiration: number;

	constructor(modemWatchData: any) {
		this.elementId = modemWatchData.elementId ? modemWatchData.elementId : null;
		this.mac = modemWatchData.mac ? modemWatchData.mac : null;
		this.addType = modemWatchData.addType ? modemWatchData.addType : null;
		this.startTime = modemWatchData.startTime ? modemWatchData.startTime : null;
		this.expirationTime = modemWatchData.expirationTime ? modemWatchData.expirationTime : null;
		this.latestError = modemWatchData.latestError ? modemWatchData.latestError : null;
		this.totalErrors = modemWatchData.totalErrors ? modemWatchData.totalErrors : null;
		this.debug = modemWatchData.debug ? modemWatchData.debug : null;
		this.expiration = modemWatchData.expiration ? modemWatchData.expiration : null;
	}
}