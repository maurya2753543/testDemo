/**
 * Created by Yogesh Paisode on 6/12/2017.
 */

import {ChangeDetectorRef, Component} from '@angular/core';

import {CmtsTabSharedService} from "../../cmts-tab.shared.service";
import {CmtsTabModel} from "./../cmts-tab.model";
import {ADD_OPERATION, 
    EDIT_OPERATION, 
    CMTS_CONTAINER, 
    CMTS_SITE, 
    FIRST_SELECT_OPTION
} from "../../cmts-tab.constants";
import {CmtsTabDataService} from "./../cmts-tab.data.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {
    ALERT_INFO, MAX_STRING_LIMIT,
} from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {map, catchError} from "rxjs/operators";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SharedService} from "../../../../shared/shared.service";
import {SiteListModel} from "../../../sites/models/site-list.model";
import {SiteListDataService} from '../../../sites/site-list/site-list.data.service';
import { SitesSelect } from './../../../shared/dropdown/models/sitesSelect.model';
import { ContainersSelect } from './../../../shared/dropdown/models/containersSelect.model';
import { ContainerDataService } from './../../../container/container.data.service';
import { MultiRangeSliderService } from '../../../shared/multi-range/multi-range.service';

@Component({
    selector: 'cmts-view-component',
    templateUrl: 'cmts-view.component.html'
})

export class CmtsViewComponent {

    public dataModel: CmtsTabModel = new CmtsTabModel({}, null);
    private currentOperation: string;
    public isReadOnly: boolean;
    public rciIndex: number = null;
    private testPointComp: number = 0;
    private testPointMax: number = 50;
    private attenuationCMTS: boolean = false;
    public isEditHidden: boolean;
    public isDeleteHidden: boolean;
    public isAddActive: boolean = true;
    public isSavebtnDisabled : boolean = true;
    public isEdit : boolean = false;
    private CMTS_TAB_REMOVE_CMTS_STRING:string = '';
    public _MAX_STRING_LIMIT: number;
    private REMOVE_CMTS:string = "";
    public isCloseRightSlider:boolean = false;
    public containerOptions:any;
    public siteOptions:any;
    public defaultContainer = FIRST_SELECT_OPTION + CMTS_CONTAINER;
    public defaultSite = FIRST_SELECT_OPTION + CMTS_SITE;
    public defaultSelect = FIRST_SELECT_OPTION;
    public errorMessages: any = {
        isHostNameEmpty: false,
        isNameEmpty: false,
        isSnmpReadOnlyEmpty: false,
        isSnmpReadWriteEmpty: false,
        isContainerEmpty: false,

        rciMonRateDelayEmpty: false,
        rciMonRatePercentEmpty: false
    }
    private featureConfig: Object = {};

    private defaultFeature:any;

    public rciMonitoringChange: any = {
        setValue: function(){},
        defaultValue: '',
        options: {
            displayOptions: ["Delay", "Percentage"],
            serverOptions: ["0", "1"]
        }
    };
    currentLang: string = '';
    constructor(private cmtsTabSharedService: CmtsTabSharedService,
                private cmtsTabDataService: CmtsTabDataService,
                private showAlert: ShowAlert,
                private sweetAlert:SweetAlert,
                private localeDataService: LocaleDataService,
                private sharedService:SharedService,
                private cd: ChangeDetectorRef,
                private containerDataService:ContainerDataService,
                private siteListDataService:SiteListDataService,
                private multiRangeSliderService:MultiRangeSliderService
    ){
        this._MAX_STRING_LIMIT = MAX_STRING_LIMIT;
    }

    ngOnInit() {
        this.translateLocaleString();
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.clearFormData(false, false);
        this.cmtsTabFormChangeSubjectListener();
        this.containerDataService.getNodeOnlyContainers()
            .pipe(map((json) => {
                return new ContainersSelect(json);
            }))
            .subscribe(this.setContainerOptions.bind(this));
        this.siteListDataService.getSiteList(true,"HARDWARE")
            .pipe(map((json) => {
                return new SitesSelect(json);
            }))
            .subscribe(this.setSiteOptions.bind(this));
        this.setFormData(this.cmtsTabSharedService.getCmtsTabModelData());
        this.defaultFeature = this.cmtsTabSharedService.getCmtsFeatures();
        if(this.multiRangeSliderService.newFailThreshold !=undefined){
            this.dataModel.mactrakFailThreshold =  this.multiRangeSliderService.newFailThreshold;
        }

        if(this.multiRangeSliderService.newStressedThreshold !=undefined){
            this.dataModel.mactrakMarginalThreshold = this.multiRangeSliderService.newStressedThreshold;
        } 
        this.rciMonitoringChange.defaultValue = this.rciMonitoringChange.options.displayOptions[0];
    }

    dateTranslate(date: string) {
        const lang = this.localeDataService.getLocalizationService().getBrowserLang();
        if(lang !== 'ja') {
            return date;
        }
        let milliseconds = new Date(date).getTime();
        let customDate = new Date(milliseconds - (milliseconds%(1000*60*60*24)));
        let dt = customDate.toLocaleDateString(window.navigator.language, {year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })
        return dt;
    }

    private setContainerOptions(data: any): void {
        //Removed setting of default value here because dropdown component handles that
        //and default is set using defaultContainer on component html.;
        this.containerOptions = data;
    }
  
    private setSiteOptions(data: any): void {
        //Removed setting of default value here because dropdown component handles that
        //and default is set using defaultSite on component html.;
        this.siteOptions = data;
    }

    public getContainerSelection(dropdownItem) : void {
        this.dataModel.container = dropdownItem.innerText;
        this.dataModel.containerId = dropdownItem.value;
        this.errorMessages.isContainerEmpty = Number(dropdownItem.value) < 1;
        this.isSavebtnDisabled = !this.dataModel.container;
    }

    public getSiteSelection(dropdownItem) : void {
        if (dropdownItem.value === "-1") {
            this.dataModel.site = null;
            this.dataModel.siteId = null;
        }
        else {
            this.dataModel.site = dropdownItem.innerText;
            this.dataModel.siteId = dropdownItem.value;
        }
        if(this.isEdit) this.isSavebtnDisabled = false;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    ngDoCheck(){
        this.setHeight();
    }
    
    //Subject listener for Form change
    private cmtsTabFormChangeSubjectListener(): void{
        this.cmtsTabSharedService.getCmtsTabFormChangeSubject().subscribe((formData: any)=>{
            this.setFormData(formData);
        });
    }

    //Method to set data
    private setFormData(formData: any): void{
        if(formData){
            this.currentOperation = formData.operation;
            this.validateOperation(this.currentOperation);
            this.setDataModel(formData.cmtsTabModel);
            this.getFeatureOverridesArray();
        }
    }


    //Method to set operation type
    private validateOperation(operation: string): void{
        if(operation === EDIT_OPERATION){
            this.isReadOnly = true;
            this.isAddActive = false;
            this.isEdit = true;
            this.onEdit(true);
        }else if(operation === ADD_OPERATION){
            this.toggleDeleteVisibility(true);
            this.isAddActive = true;
            this.isReadOnly = false;
            this.isEdit = false;
        }
    }

    //Method to set edit UI for edit operation
    private onEdit(flag: boolean): void{
        this.toggleEditVisibility(!flag);
        this.toggleDeleteVisibility(flag);
    }

    //Method Toggle EDIT view on UI
    private toggleEditVisibility(flag: boolean): void{
        this.isEditHidden = flag;
    }

    //Method to toggle DELETE view on UI
    private toggleDeleteVisibility(flag: boolean): void{
        this.isDeleteHidden = flag;
    }

    //Method to set data model for UI form
    private setDataModel(cmtsData: CmtsTabModel): any{
        if(cmtsData){
            this.dataModel.rciMonRatePercent = cmtsData.rciMonRatePercent;
            this.dataModel.rciMonRateDelay = cmtsData.rciMonRateDelay;
			this.dataModel.rciMonRateControl = this.rciMonitoringChange.options.displayOptions[cmtsData.rciMonRateControl];
            this.rciIndex = cmtsData.rciMonRateControl;
			this.dataModel.cmtsId = cmtsData.cmtsId;
            this.dataModel.name =  cmtsData.name;
            this.dataModel.hostname = cmtsData.hostname;
            this.dataModel.proxyHostname = cmtsData.proxyHostname;
            this.dataModel.snmpCommunityString = cmtsData.snmpCommunityString;
            this.dataModel.snmpWriteCommunityString = cmtsData.snmpWriteCommunityString;
            this.dataModel.docsisVersion = cmtsData.docsisVersion;
            this.dataModel.manufacture = cmtsData.manufacture;
            this.dataModel.description = cmtsData.description;
            this.dataModel.upstreamCount = cmtsData.upstreamCount;
            this.dataModel.modemCount = cmtsData.modemCount;
            this.dataModel.nodeCount = cmtsData.nodeCount;
            this.dataModel.accessed = this.dateTranslate(cmtsData.accessed);
            this.dataModel.container = cmtsData.container;
            this.dataModel.containerId = cmtsData.containerId;
            this.dataModel.containerPath  = cmtsData.containerPath;
            this.dataModel.site = cmtsData.site;
            this.dataModel.siteId = cmtsData.siteId;
            this.dataModel.config = cmtsData.config;
            this.dataModel.mactrakFailThreshold = cmtsData.mactrakFailThreshold;
            this.dataModel.mactrakMarginalThreshold = cmtsData.mactrakMarginalThreshold;
        }
    }

    private getFeatureOverridesArray(): void {
        if(this.dataModel.config) {
            this.featureConfig = this.dataModel.config;
        }
    }

    private userOverridenFeature(modifiedFeatureArr: Object[]): void {
        this.updateCmtsFeatures(modifiedFeatureArr);
        if(this.isEdit) {
            this.isSavebtnDisabled = false;
        }
    }

    private updateCmtsFeatures(featuresArray: Object[] = []): void {
        if(this.dataModel.config) {
            this.dataModel.config['featureOverrides'] = featuresArray;
        }

        if(this.currentOperation === ADD_OPERATION) {
            if(this.dataModel.config == undefined) {
                this.dataModel.config = {
                    //'configVersion': 1, //Ignore the config version while adding CMTS 
                    'featureOverrides': featuresArray
                }
            }
        }

    }

    //Method to submit form
    public onSubmit(): void{
        let localizationService = this.localeDataService.getLocalizationService();
        let rciMonRateControlValue:any = this.dataModel.rciMonRateControl;
        if(rciMonRateControlValue == localizationService.instant('PERCENTAGE'))
        {
            this.dataModel.rciMonRateControl = 1;
        }
        else if(rciMonRateControlValue == localizationService.instant('DELAY')){
            this.dataModel.rciMonRateControl = 0;
        }
       
        if (this.dataModel.rciMonRateDelay) {
            this.dataModel.rciMonRateDelay = parseInt(this.dataModel.rciMonRateDelay.toString());
        }

        if (this.dataModel.rciMonRatePercent) {
            this.dataModel.rciMonRatePercent = parseInt(this.dataModel.rciMonRatePercent.toString());
        }

        if(this.currentOperation === EDIT_OPERATION){
            this.postData();
        }else if(this.currentOperation === ADD_OPERATION){
            this.addData();
        }
    }

    //Method to post form data
    private postData(): void{
        this.addTestComp();
        this.cmtsTabDataService.editCMTSRow(this.dataModel).subscribe(()=>{
            this.clear();
        },this.onError.bind(this));
    }

    private addTestComp(): void {
        if (this.attenuationCMTS) {
            this.dataModel.config['descendAttribute'] =
                {
                    "forceCascade": true,
                    "testPointComp": this.testPointComp
                }
        }
    }

    //Method to listener to add operation
    private addData(): void{
        this.cmtsTabDataService.addCMTSRow(this.dataModel).subscribe(()=>{
            this.clear();
        },this.onError.bind(this));
    }

    //Method to delete row from ag-grid
    public deleteData(): void{
        let status = this.showAlert.showAlertConfirm();
        this.sweetAlert.showConformationAlert(ALERT_INFO ,this.REMOVE_CMTS ,this.CMTS_TAB_REMOVE_CMTS_STRING ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.cmtsTabDataService.deleteCMTSRow(this.dataModel.cmtsId).subscribe(()=>{
                        this.clear();
                    },this.onError.bind(this));
                }
            }
        );
    }

    //Method to toggle Edit view
    public toggleEdit(): void{
        this.isReadOnly = false;
        this.onEdit(this.isReadOnly);
    }

    //Common method to clear form
    private clear(): void{
        this.clearFormData(true, true);
    }

    //Method to clear form data
    private clearFormData(isHardReset: boolean, closeSlider: boolean): void{
        this.refreshCmtsList(isHardReset);
        this.setDataModel(null);
        this.currentOperation = null;
        this.isReadOnly = true;
        this.toggleEditVisibility(true);
        this.toggleDeleteVisibility(true);
        if(closeSlider){
            this.btnClose_click();
        }
    }

    //Method to refresh ag-grid
    private refreshCmtsList(isHardReset: boolean): void{
        this.cmtsTabSharedService.getCmtsListRefreshSubject().next(isHardReset);
    }

    //Method to handle sweet alert
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }

    //KeyUp event
    public keyUp(): void{
        if(this.dataModel.name) {
            this.dataModel.name = this.cmtsTabSharedService.checkTextLength(this.dataModel.name);
        }
    }

    //Method to close UI side panel
    public btnClose_click() : void {
        this.isCloseRightSlider = true;
    }

    //Translation
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.CMTS_TAB_REMOVE_CMTS_STRING = localizationService.instant('CMTS_TAB_REMOVE_CMTS_STRING');
        this.REMOVE_CMTS = localizationService.instant('REMOVE_CMTS');
        this.rciMonitoringChange.options.displayOptions[0] = localizationService.instant('DELAY');
        this.rciMonitoringChange.options.displayOptions[1] = localizationService.instant('PERCENTAGE');
        this.currentLang = localizationService.getBrowserLang();
    }

    public isHostnameEmpty(): void{
        if(this.dataModel.hostname != null && this.dataModel.hostname.length === 0){
            this.errorMessages.isHostNameEmpty = true;
        }else{
            this.errorMessages.isHostNameEmpty = false;
            if(this.isEdit) this.isSavebtnDisabled = false;
        }
    }

    public isNameEmpty(): void{
        if(this.dataModel.name != null && this.dataModel.name.length === 0){
            this.errorMessages.name = true;
        }else{
            this.errorMessages.name = false;
            if(this.isEdit) this.isSavebtnDisabled = false;
        }
    }

    public isSnmpReadOnly(): void{
        if(this.dataModel.snmpCommunityString != null && this.dataModel.snmpCommunityString.length === 0){
            this.errorMessages.isSnmpReadOnlyEmpty = true;
        }else{
            this.errorMessages.isSnmpReadOnlyEmpty = false;
            if(this.isEdit) this.isSavebtnDisabled = false;
        }
    }

    private isRciMonRateDelayEmpty(): void {
        if (this.dataModel.rciMonRateDelay) {
            if(this.dataModel.rciMonRateDelay > 1000) {
                this.dataModel.rciMonRateDelay = 1000;
            } else if (this.dataModel.rciMonRateDelay < 0) {
                this.dataModel.rciMonRateDelay = 0;
            }
        } else {
            this.dataModel.rciMonRateDelay = 0;
        }
        if(this.isEdit) this.isSavebtnDisabled = false;
    }

    private rciMonRatePercentEmpty(): void {
        if (this.dataModel.rciMonRatePercent){
            if (this.dataModel.rciMonRatePercent > 100) {
                this.dataModel.rciMonRatePercent = 100;
            } else if (this.dataModel.rciMonRatePercent < 0) {
                this.dataModel.rciMonRatePercent = 0;
            }
        } else {
            this.dataModel.rciMonRatePercent = 0;
        }
        if(this.isEdit) this.isSavebtnDisabled = false;
    }

    public isSnmpReadWrite(): void{
        if(this.dataModel.snmpWriteCommunityString != null && this.dataModel.snmpWriteCommunityString.length === 0){
            this.errorMessages.isSnmpReadWriteEmpty = true;
        }else{
            this.errorMessages.isSnmpReadWriteEmpty = false;
            if(this.isEdit) this.isSavebtnDisabled = false;
        }
    }

    private setHeight(): void{
        let id: any = document.getElementById("cmtsDescription");
        if(id){
            id.style.height = (id.scrollHeight)+ "px";
        }
    }

    public onRciMonitoringChange(data: any): void {
        this.dataModel.rciMonRateControl = parseInt(data.value);
        this.rciIndex = this.dataModel.rciMonRateControl;
        if(this.isEdit) this.isSavebtnDisabled = false;
    }

    private valueChanged(value: string): void {
        const parsedVal: number = parseInt(value);
        if (value) {
            if (parsedVal < 0) {
                this.testPointComp = 0;
            } else if (parsedVal > this.testPointMax) {
                this.testPointComp = this.testPointMax;
            }
        } else {
            this.testPointComp = 0;
        }
    }

    private validateForm(): void {
        if(this.isEdit) this.isSavebtnDisabled = false;
    }

    private onCMTSCheckBoxChange(): void {
        this.isSavebtnDisabled = false;
    }
}
