
/**
 * @ Author: Vrishabh Mishra
 * @ Create Time: 2019-05-29 12:50:05
 */

import { Component, Input } from "@angular/core";
import { CmtsTabSharedService } from "../../cmts-tab.shared.service";
import { CmtsTabDataService } from "../cmts-tab.data.service";
import { ControlFeaturesModel } from "./cmts-control-features.model";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import { ALERT_INFO,SUCCESS } from "../../../../constant/app.constants";
import { CommonStrings } from "../../../../constant/common.strings";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { Grid } from "../../../../shared/ag-grid.options";
import CmtsControlFeatureConfigService from "./cmtsControlFeature.configuration.service";
import {CMTSHttpService } from "../../cmts.http.service";
import { SystemSettings, SystemSettingsList } from "../../../system-settings/models/system-settings.model";
import { MultiRangeSliderService } from "../../../shared/multi-range/multi-range.service";
import { StressedImpactedItem } from "../../../system-settings/measurement-defaults/qoe-thresholds/qoe-thresholds.view.component";
import { SystemSettingsDataService } from "../../../system-settings/system-settings.data.service";
import { SystemSettingsHttpService } from "../../../system-settings/system-settings.http.service";
import { Observable } from "rxjs";
import { isFunction } from "jquery";

const QP_FAIL_THRESHOLD = "QP_FAIL_THRESHOLD";
const QP_MARGINAL_THRESHOLD = "QP_MARGINAL_THRESHOLD";
const NODE_RANK_PERCENTAGE = "NODE_RANK_PERCENTAGE";

@Component({
    selector: 'cmts-control-features',
    templateUrl: 'cmts-control-features.component.html'
})

export class CmtsControlFeaturesComponent {

    public defaultFeature: any;
    public isCloseRightSlider: boolean;
    private postControlFeatures: Object;
    private CONTROL_FEATURES_CMTS: string = '';
    private CMTS_TAB_CONTROL_FEATURES: string = '';
    private isDefaultFeatures: boolean;
    private eventKeys: Object[];
    private buttonKeys: Object[];
    private gridOptions: Grid = new Grid();
    private gridApi: any;
    private QP_FAIL_THRESHOLD: any;
    private QP_MARGINAL_THRESHOLD: any;
    private settingsMap = new Map<string, SystemSettingsList>();

    @Input('childData') 
    private childData: number[];
    bulkModifyFlag: boolean = false;
    mactrakThresholdFlag: boolean = false;
    cmtsApiData: any;
    rowdata: any;
    thresholdSettings: SystemSettingsList;
    rangeData: any = [];
    public qoeUsThresholdData: StressedImpactedItem[];
    private nodeRankFields: Array<any> = new Array();
    marginalThresholdResponse: any;
    impactedThresholdResponse: any;
    measurementUnit: any;
    private NODE_RANK_PERCENTAGE: any;
    nodeRankPercentage: any;
    private BULK_UPDATE_THRESHOLD_CONFIRMATION: string = '';

    constructor(private cmtsTabSharedService: CmtsTabSharedService,
                private cmtsTabDataService: CmtsTabDataService,
                private localeDataService: LocaleDataService,
                private showAlert: ShowAlert,
                private sweetAlert: SweetAlert,
                private cmtsControlFeatureConfigService: CmtsControlFeatureConfigService,
                private cmtsHttpService: CMTSHttpService,
                private multiRangeSliderService:MultiRangeSliderService,
                private systemSettingsHttpService: SystemSettingsHttpService,
                private systemSettingDataService: SystemSettingsDataService) {
    }

    ngOnInit() {
        this.bulkModifyFlag = this.cmtsTabSharedService.bulkModifyFlag;
        this.mactrakThresholdFlag = this.cmtsTabSharedService.mactrakThresholdFlag;
        if(this.cmtsTabSharedService.mactrakThresholdFlag)
            this.multiRangeSliderService.setMakTrakThresholdFlag = true;
        else
            this.multiRangeSliderService.setMakTrakThresholdFlag = false;
        this.getNodeRanking().subscribe(res=>{});       

        this.setEventButtonKeys();
        this.initializeVariables();
        this.translateLocaleString();
        this.getDefaultCmtsFeatures();
    }

    public getNodeRanking(): Observable<any> {
        return this.systemSettingsHttpService.getNodeRanking()
        .map((nodeRanking) => {            
            let nodeRankingList: SystemSettingsList = new SystemSettingsList(nodeRanking);   
            this.setSliderData(nodeRankingList);
        })
    }

    private initializeVariables(): void {
        this.isCloseRightSlider = false;
        this.isDefaultFeatures = true;
    }


    private setSliderData(nodeRankingList){  
        for(let i=0; i< nodeRankingList.length; i++){            
            switch(nodeRankingList[i].name){
                case QP_FAIL_THRESHOLD:                    
                    this.QP_FAIL_THRESHOLD = {
                        response: nodeRankingList[i],
                        label: 'SS_PERFORMANCE_INDEXFAIL_THRESHOLD',
                        desc: 'SS_PERFORMANCE_INDEXFAIL_TEXT',
                        field: 'input',
                        index: 5
                    };
                    this.impactedThresholdResponse = this.QP_FAIL_THRESHOLD.response
                    this.nodeRankFields.push(this.QP_FAIL_THRESHOLD);
                break;
                case QP_MARGINAL_THRESHOLD:
                    let FailedIndex = this.nodeRankFields.findIndex((x)=> x.response.name == QP_FAIL_THRESHOLD);
                    nodeRankingList[i].rangeStart = this.nodeRankFields[FailedIndex].response.value ? this.nodeRankFields[FailedIndex].response.value : nodeRankingList[i].rangeStart;
                    this.marginalThresholdResponse = nodeRankingList[i];
                    this.marginalThresholdResponse.rangeStart = 0;

                    nodeRankingList[i].customTitle = 'SS_PERFORMANCE_INDEXMARGINAL_TEXT_TITLE';
                    this.QP_MARGINAL_THRESHOLD = {
                        response: nodeRankingList[i],
                        label: 'SS_PERFORMANCE_INDEXMARGINAL_THRESHOLD',
                        desc: 'SS_PERFORMANCE_INDEXMARGINAL_TEXT',
                        field: 'input',
                        index: 6
                    };
                    this.nodeRankFields.push(this.QP_MARGINAL_THRESHOLD);
                break;
            }
        }
        this.systemSettingsHttpService.getMeasurement().subscribe(res=>{
            let rawData: any[] = res;
            let measurementUnit: SystemSettings = new SystemSettings(rawData[0]);
            let distanceUnit: SystemSettings = new SystemSettings(rawData[1]);
            let generalSettingsList: SystemSettingsList = new SystemSettingsList(undefined);
            if (measurementUnit) generalSettingsList.push(measurementUnit);
            if (distanceUnit) generalSettingsList.push(distanceUnit);
            
            this.multiRangeSliderService.measurementUnit = rawData[0].value          
            this.rangeData = [[this.QP_FAIL_THRESHOLD.response,this.marginalThresholdResponse]]                    
        })
    }

    //Method to set button keys
    private setEventButtonKeys(): void {
        this.buttonKeys = [];
        this.eventKeys = [];
    }

    private notifyGridReady(): void {
        this.gridApi = this.gridOptions.api;
        this.setColDef();
        if(this.mactrakThresholdFlag){
            this.cmtsHttpService.getCmtsDeviceThreshold().subscribe(res =>{
                   this.cmtsApiData = res; 
                   this.getRowData();
             })
        }
       // this.gridApi.sizeColumnsToFit();
        // this.gridApi.setDomLayout("normal");
    }

    private setColDef(): void {
        this.showGridNoDataAvilable();
        this.gridApi.setColumnDefs(this.cmtsControlFeatureConfigService.getColumnDef());
        this.gridOptions["getRowHeight"] = 85;
        this.showGridNoDataAvilable();
      }

      private showGridNoDataAvilable(): void {
        this.gridApi.showNoRowsOverlay();
      }

    private getRowData() {
        var rowData:any =[];

        this.cmtsTabSharedService.selectedCmts.forEach(element => {
            rowData.push({
                'id':element.cmtsId,
                'device':element.name,
                'impacted': "",
                'stressed': ""                                            
           }) 
          var objIndex = rowData.findIndex((obj => obj.id == element.cmtsId));
         
            if (this.cmtsApiData) {
                for (let i = 0; i < this.cmtsApiData.length; i++) {
                    if (element.cmtsId === this.cmtsApiData[i].id) { 
                       rowData[objIndex].impacted = this.cmtsApiData[i].settings.QP_FAIL_THRESHOLD
                       rowData[objIndex].stressed = this.cmtsApiData[i].settings.QP_MARGINAL_THRESHOLD
                   }
                }
            }
        });
     
        // this.cmtsTabSharedService.selectedCmts.forEach(element => {
        //     console.log('element',element)  
        //     console.log('this.cmtsApiData',this.cmtsApiData)
        //     if (this.cmtsApiData) {
        //         for (let i = 0; i < this.cmtsApiData.length; i++) {
        //             if (element.cmtsId === this.cmtsApiData[i].id) {  
                                         
        //                 rowData.push({
        //                     'device':this.cmtsApiData[i].name,
        //                     'impacted': (this.cmtsApiData[i].settings.QP_FAIL_THRESHOLD) == "null" ? "" : this.cmtsApiData[i].settings.QP_FAIL_THRESHOLD,
        //                     'stressed': this.cmtsApiData[i].settings.QP_MARGINAL_THRESHOLD === "null" ? "": this.cmtsApiData[i].settings.QP_MARGINAL_THRESHOLD                         

        //                 })                        
        //             }
        //         }
        //     }
        // });
        this.rowdata = rowData;
    }



    private setControlFeaturesData(featuresArray: Object[] = []): void {
        this.postControlFeatures = {
            'cmtsFeatures': featuresArray,
            'cmtsIds': this.childData
        };
    }

    private getDefaultCmtsFeatures(): void {
        this.defaultFeature = this.cmtsTabSharedService.getCmtsFeatures();
    }

    private userOverridenDefaultFeature(modifiedFeatureArr: Object[]): void {
        this.setControlFeaturesData(modifiedFeatureArr);
        this.isDefaultFeatures = false;
    }

    //Method to close UI side panel
    private btnClose_click() : void {
        this.isCloseRightSlider = true;
    }

    private saveThreshold(): void {
        var deviceIds = this.cmtsTabSharedService.deviceIds

        this.sweetAlert.showConformationAlert(ALERT_INFO, SUCCESS, this.BULK_UPDATE_THRESHOLD_CONFIRMATION, true, true, CommonStrings.OK, CommonStrings.CANCEL,
            (isConfirm) => {
                if (isConfirm) {
                    this.cmtsHttpService.updateMACTrakBulkThreshold(deviceIds, this.multiRangeSliderService.newStressedThreshold, this.multiRangeSliderService.newFailThreshold).subscribe(res => {
                        this.btnClose_click();
                        this.cmtsHttpService.getCmtsDeviceThreshold().subscribe(res => {
                            this.cmtsApiData = res;
                            this.getRowData();
                        })
                    })
                }
                else {
                    this.btnClose_click();
                }
            })
    }

    private saveFeatures(): void {
        if(this.isDefaultFeatures) {
            this.setControlFeaturesData();
        }
        this.sweetAlert.showConformationAlert(ALERT_INFO , this.CONTROL_FEATURES_CMTS , this.CMTS_TAB_CONTROL_FEATURES ,true , true, CommonStrings.OK, CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.saveFeaturesForMultipleCmts();
                    this.btnClose_click();
                }
            }
        );  
    }

    private saveFeaturesForMultipleCmts(): void {
        this.cmtsTabDataService.saveCmtsfeatures(this.postControlFeatures).subscribe(()=>{
            this.clear();
        },this.onError.bind(this));
    }

    //Common method to clear form
    private clear(): void{
        this.clearFormData(true, true);
    }

    //Method to clear form data
    private clearFormData(isHardReset: boolean, closeSlider: boolean): void{
        this.refreshCmtsList(isHardReset);
        if(closeSlider){
            this.btnClose_click();
        }
    }

    //Method to refresh ag-grid
    private refreshCmtsList(isHardReset: boolean): void{
        this.cmtsTabSharedService.getCmtsListRefreshSubject().next(isHardReset);
    }

    //Method to handle sweet alert
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }

    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.CMTS_TAB_CONTROL_FEATURES = localizationService.instant('CMTS_TAB_CONTROL_FEATURES');
        this.CONTROL_FEATURES_CMTS = localizationService.instant('CONTROL_FEATURES_CMTS');
        this.BULK_UPDATE_THRESHOLD_CONFIRMATION = localizationService.instant('BULK_UPDATE_THRESHOLD_CONFIRMATION');
    }

}
