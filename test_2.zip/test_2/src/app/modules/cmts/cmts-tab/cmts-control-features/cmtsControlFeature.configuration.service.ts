import {Injectable} from "@angular/core";
import { gridCustomComparator } from "../../../../shared/ag-Grid.comparator";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { SharedService } from "../../../../shared/shared.service";
import { TimeFilter } from "../../../../shared/time.filter";



@Injectable()
export default class CmtsControlFeatureConfigService{

    private _HEADER_FIELDS: any = {
        device : {field: "device", name: "DEVICE"},
        impacted : {field: "impacted", name: "IMPACTED_THRESHOLD"},
        stressed : {field: "stressed", name: "STRESSED_THRESHOLD"},
    };

    constructor(private localeDataService: LocaleDataService,
                private sharedService : SharedService){}

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();
        this._HEADER_FIELDS.device.name = localizationService.instant('DEVICE');
        this._HEADER_FIELDS.impacted.name = localizationService.instant('IMPACTED_THRESHOLD');
        this._HEADER_FIELDS.stressed.name = localizationService.instant('STRESSED_THRESHOLD');
    }


    /*
    *@name getColumnDef
    *@desc Get column def for alarm-list data-grid
    *@return array[any]
   */
    public getColumnDef(): any[] {
        this.translateLocaleStr();

        let columnDef: any[] = [
            // {
            //     headerName: '',
            //     width: 5,
            //     checkboxSelection: false,
            //     pinned: true,
            //     sortingOrder: [null],
            //     headerCheckboxSelection: false,
            //     suppressFilter: true,
            //     suppressSizeToFit: false,
            //     suppressMenu: true,
            //     filterParams: {newRowsAction: 'keep'},
            //     suppressResize: false
            // },
            this.getColumns(this._HEADER_FIELDS.device.name,
                this._HEADER_FIELDS.device.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.device.name, 150), "text"),

            this.getColumns(this._HEADER_FIELDS.impacted.name,
                this._HEADER_FIELDS.impacted.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.impacted.name, 70), "text"),


            this.getColumns(this._HEADER_FIELDS.stressed.name,
                this._HEADER_FIELDS.stressed.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.stressed.name, 70), "text"),

        ];

        return columnDef;
    }

    //@method :: get column definition
    private getColumns(headerName: string, field: string, minWidth: number, filter: string): any{
        let def: any = {
            headerName: headerName,
            field: field,
            minWidth: minWidth,
            width: minWidth,
            filter: filter,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {suppressAndOrCondition: true}
        }
        // if(!(field === this._HEADER_FIELDS.logLocation.name || field === this._HEADER_FIELDS.details.name)){
        //     def["width"] = minWidth;
        // }
        // if(field === this._HEADER_FIELDS.timestamp.field){
        //     def["cellRenderer"] = (params:any)=>{
        //         return this.sharedService.getLocaleDate(params.value);
        //     };
        //     def["comparator"] = this.sharedService.dateComparator;
        //     def["filter"] = TimeFilter.ParentFilter;
        //     def["floatingFilterComponent"] = TimeFilter.ChildFloatingFilter;
        // }else{
            def["comparator"] = gridCustomComparator;
       // }

        // if(field === this._HEADER_FIELDS.details.field){
        //     def["cellStyle"] = { "white-space": "normal" };
        // }

        return def;
    }
}