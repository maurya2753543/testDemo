/**
 * Created by Priyanka on 29-03-2022 against XPTUI-718.
 */

 import {Component, EventEmitter, Output} from '@angular/core';
 import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
 import * as FileSaver from 'file-saver';
 import * as AppConstants from '../../../../constant/app.constants';
 import {LocaleDataService} from "../../../../shared/locale.data.service";
 import {SharedService} from "../../../../shared/shared.service";
 import {UrlService} from "../../../../shared/url.service";
 import {Logger} from "../../../../utilities/logger";
 import {ShowAlert} from "../../../../utilities/showAlert";
 import {CmtsTabDataService} from "../cmts-tab.data.service";
 import {ALERT_ERROR} from "../../../../constant/app.constants";
 import { Observable } from 'rxjs';
 
 @Component({
     selector: 'import-noisetrak-component',
     templateUrl: 'import-noisetrak.component.html'
 })
 
 export class ImportNoisetrakComponent {
     public closeSlider: Observable<boolean>;
     @Output() onCloseSlider: EventEmitter<any> = new EventEmitter<any>();
 
     private isValidCSVFile: boolean = false;
     private isValidTxtFile: boolean = false;
     public form: FormGroup;
     private tag: string = "ImportNoisetrakComponent ::";
     private IMPORT_NOISETRAK_SUCCESS: string = '';
     private IMPORT_NOISETRAK_ERROR: string = '';
     private IMPORT_FILE_OTHER_THAN_JSON_INVALID: string = '';
     private IMPORT_FILE_INVALID: string = '';
     private EMPTY_CSV_ERROR: string;
     private VALIDATION_SUCCESSFUL: string = '';
    
     constructor(private urlService: UrlService,
                 private cmtsTabDataService: CmtsTabDataService,
                 private fb: FormBuilder,
                 private logger: Logger, private showAlert: ShowAlert,
                 private sharedService: SharedService,
                 private localeDataService: LocaleDataService) {
     }
 
     private buildForm(): FormGroup {
         return this.fb.group(this.getFormProperties());
     }
 
     private getFormProperties(): any {
         const formatProperties: any = {
             csvFile: this.fb.control(null, Validators.required),
             importConfig: this.fb.control(null, Validators.required), 
             header: this.fb.control(true),
         };
         return formatProperties;
     }
 
 
     // Form Properties
     private get csvFile() {
         return this.form.get('csvFile');
     }
 
     private get importConfig() {
         return this.form.get('importConfig');
     }
 
     private get header() {
         return this.form.get('header');
     }
 
     ngOnInit() {
         this.form = this.buildForm();
         this.translateLocaleString();
     }
 
     fileChangeText(event: any): void {
         const target: any = event.target;
         this.isValidTxtFile = target.value.endsWith('.json');
         if (this.isValidTxtFile) {
             let files: any = target.files;
             if (files.length) {
                 this.importConfig.setValue(files[0]);
             }
         } else {
             this.showAlert.showSuccessAlert(this.IMPORT_FILE_OTHER_THAN_JSON_INVALID, true, ALERT_ERROR);
         }
     }
 
     fileChangeCSV(event: any): void {
         const target: any = event.target;
         this.isValidCSVFile = target.value.endsWith('.csv');
         if (this.isValidCSVFile) {
             let files: any = target.files;
             if (files.length) {
                 this.csvFile.setValue(files[0]);
             }
         } else {
             this.showAlert.showSuccessAlert(this.IMPORT_FILE_INVALID, true, ALERT_ERROR);
         }
     }
 
     private noisetrakExport(){     
         this.cmtsTabDataService.noisetrakExportFeature().subscribe(this.onExportNoisetrakSuccess.bind(this),this.onError.bind(this));
     }
 
     private onExportNoisetrakSuccess(response):void{
         let exportFileData: string = JSON.stringify(response,null,"  ");        
         let file = new Blob([exportFileData], { type: 'text/text;charset=utf-8' });           
         FileSaver.saveAs(file.slice(), 'noisetrakConfig' +  '.json');
     }
 
     // Cancels out of the noisetrak import editor without submitting the form.
     private onCancel(): void {
         this.onCloseSlider.emit(Math.random());
     }
 
     // Add imported noisetrak to server on submit.
     private onSubmit(): void {
         let formData = new FormData();
         formData.append('csvFile', this.csvFile.value, this.csvFile.value.name);        
         formData.append('importConfig', this.importConfig.value, this.importConfig.value.name);
         formData.append('isToBePersisted', this.header.value);
               
         this.cmtsTabDataService.addNoisetrakCSVConfigToServer(formData)
         .subscribe(this.onAddNext.bind(this), this.onError.bind(this));
     }    
 
 
     // Handles successful noisetrak import.
     private onAddNext(data: any): void {
         if (data.errorCode == 0) {
            if(this.header.value == true){
                this.showAlert.showSuccessAlert(this.IMPORT_NOISETRAK_SUCCESS);
                this.onCancel();
            }
            else{
                this.showAlert.showSuccessAlert(this.VALIDATION_SUCCESSFUL);
            }
         } else {
             let errorMessage: string;
             if (data && data.noiseTrakLinesWithError.length) {
                 errorMessage = this.IMPORT_NOISETRAK_ERROR;
             } else {
                errorMessage = this.EMPTY_CSV_ERROR;
             }
 
             this.showAlert.showAlertWithExportNoisetrak(data, errorMessage);
             this.onCancel();
         }
     }
 
 
     // Handles request errors from submitting noisetrak import.
     private onError(error: any): void {
         this.logger.debug(this.tag, "onError(): error data=", error);
         this.showAlert.showErrorAlert(error);
         this.onCancel();         
     }
 
     // Sets up localization resources used by this component.
     private translateLocaleString(): void {
         let localizationService = this.localeDataService.getLocalizationService();
         this.EMPTY_CSV_ERROR = localizationService.instant('EMPTY_CSV_ERROR');
         this.IMPORT_NOISETRAK_ERROR = localizationService.instant('IMPORT_NOISETRAK_ERROR');
         this.IMPORT_NOISETRAK_SUCCESS = localizationService.instant('IMPORT_NOISETRAK_SUCCESS');
         this.VALIDATION_SUCCESSFUL = localizationService.instant('VALIDATION_SUCCESSFUL');
         this.IMPORT_FILE_INVALID = localizationService.instant('IMPORT_FILE_INVALID');
         this.IMPORT_FILE_OTHER_THAN_JSON_INVALID = localizationService.instant('IMPORT_FILE_OTHER_THAN_JSON_INVALID');
     }
    
 }
 