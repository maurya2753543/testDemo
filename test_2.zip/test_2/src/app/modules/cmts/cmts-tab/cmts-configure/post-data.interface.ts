export interface PostDataInterface {
    dsPortToChannelIndex: any[];
    usPortToChannelIndex: any[];
    id: number;
}
