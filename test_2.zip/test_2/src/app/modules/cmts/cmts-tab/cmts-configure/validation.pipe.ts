import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'validation'
})
export class ValidationPipe implements PipeTransform{

    transform(value: any[]): any {
        if (value) {
            value.sort((entry1: any, entry2: any) => {
                return entry1.isValidated - entry2.isValidated;
            });
        }
        return value;
    }
}
