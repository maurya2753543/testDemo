/*@Author::  Yogesh Paisode
* Components is design to add NDF/NDR Mapping for Upstream and Downstream.
* */

import {Component, EventEmitter, Input, Output} from '@angular/core';
import {CmtsTabDataService} from '../cmts-tab.data.service';
import {ShowAlert} from '../../../../utilities/showAlert';
import {Logger} from '../../../../utilities/logger';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {PostDataInterface} from "./post-data.interface";

@Component({
    selector: 'cmts-configure',
    templateUrl: 'cmts-configure.component.html'
})
export class CmtsConfigureComponent {

    @Output()
    private onSliderClose: EventEmitter<boolean> = new EventEmitter<boolean>();

    public usPortToChannelIndex: any[] = [];
    public dsPortToChannelIndex: any[] = [];
    public isChannelPresent: boolean = true;
    public saveDisabled: boolean = true;
    private cmtsId: number;
    public showValidationFailsAlert: boolean = false;
    private NDF_NDR_UPDATE_SUCCESS: string = '';

    constructor(private showAlert: ShowAlert,
                private logger: Logger,
                private localeDataService: LocaleDataService,
                private cmtsTabDataService: CmtsTabDataService) {
    }

    // collect cmtsId
    @Input()
    set cmtsData(data: any) {
        if (data && data[0]) {
            this.cmtsId = data[0].cmtsId;
            this.getSweepConfig();
        }
    }

    ngOnInit() {
        this.translateLocaleString();
    }

    private modelChange(index: number, obj: any, key: string): any {
        let value: string = obj[index][key] && obj[index][key].toString();
        if (value && value.length > 10) {
            value = value.split('.').join('').substring(0, 10);
            obj[index][key] = value;
        }
    }

    private onBlur(index: number, obj: any, key: string): any {
        const value: string = obj[index][key];
        if(!value || isNaN(parseInt(value))) {
            obj[index][key] = 0;
        }
    }

    // On Validation Alert click
    private onAlertClick(): void {
        this.showValidationFailsAlert = false;
    }

    // On Slider Close
    public onClose(): void {
        this.onSliderClose.emit(true);
    }

    private disableSave(): void {
        this.saveDisabled = true;
    }

    // Get Sweep config list from the API
    private getSweepConfig(): void {
        this.cmtsTabDataService.getSweepConfig(this.cmtsId)
            .subscribe(this.onSweepConfigSuccess.bind(this));
    }

    // On Sweep Config list API success
    private onSweepConfigSuccess(data: any): void {
        this.usPortToChannelIndex = data.usPortToChannelIndex ? data.usPortToChannelIndex : [];
        this.dsPortToChannelIndex = data.dsPortToChannelIndex ? data.dsPortToChannelIndex : [];
    }

    // UI event:: On mapping close Remove entries from the array.
    private closeMapping(type: string, index: number): void {
        this.disableSave();
        if (type === 'us') {
            this.usPortToChannelIndex.splice(index, 1);
        } else if (type === 'ds') {
            this.dsPortToChannelIndex.splice(index, 1);
        }

        if (this.usPortToChannelIndex.length === 0 &&
            this.dsPortToChannelIndex.length === 0) {
            this.isChannelPresent = true;
        }
    }

    // Get Data to be post
    private getPostData(): PostDataInterface {
        const data: PostDataInterface = {
            dsPortToChannelIndex: this.dsPortToChannelIndex,
            usPortToChannelIndex: this.usPortToChannelIndex,
            id: this.cmtsId
        };
        return data;
    }

    // On save click, update CMTS config
    public updateCMTS(): void {
        this.cmtsTabDataService.updateCMTSConfig(this.getPostData())
            .subscribe(this.onUpdateCMTSConfigSuccess.bind(this), this.onError.bind(this));
    }

    // On save success, close slider.
    private onUpdateCMTSConfigSuccess(data: any): void {
        this.onClose();
        this.showAlert.showInfoAlert(this.NDF_NDR_UPDATE_SUCCESS);
    }

    // API call to validate CMTS mapping
    public validateCMTS(): void {
        this.cmtsTabDataService.validateCMTSConfig(this.getPostData())
            .subscribe(this.onValidationSuccess.bind(this), this.onError.bind(this));
    }

    // On Validation api success, Highlight the mapping
    private onValidationSuccess(responseData: any): void {
        const dsPortToChannelIndex: any[] = responseData.dsPortToChannelIndex;
        const usPortToChannelIndex: any[] = responseData.usPortToChannelIndex;

        if (dsPortToChannelIndex.length || usPortToChannelIndex.length) {
            this.showValidationFailsAlert = true;
        }
        this.onUsData(usPortToChannelIndex);
        this.onDsData(dsPortToChannelIndex);
        this.saveDisabled = false;
    }

    private onUsData(usPortToChannelIndex: any[]): void {
        this.usPortToChannelIndex.forEach((usPostChannels: any) => {
            let channelMatched: boolean = false;
            for (let i = 0; i < usPortToChannelIndex.length; i++) {
                if ((usPostChannels.channelIndex === usPortToChannelIndex[i].channelIndex) &&
                    (usPostChannels.portIndex === usPortToChannelIndex[i].portIndex)) {
                    channelMatched = true;
                    break;
                }
            }
            usPostChannels.isValidated = !channelMatched;
        });
        this.usPortToChannelIndex = JSON.parse(JSON.stringify(this.usPortToChannelIndex)); // Need Deep copy to trigger change detection.
    }

    private onDsData(dsPortToChannelIndex: any[]): void {
        this.dsPortToChannelIndex.forEach((dsPostChannels: any) => {
            let isDirty: boolean = false;
            for (let i = 0; i < dsPortToChannelIndex.length; i++) {
                if ((dsPostChannels.channelIndex === dsPortToChannelIndex[i].channelIndex) &&
                    (dsPostChannels.portIndex === dsPortToChannelIndex[i].portIndex)) {
                    isDirty = true;
                    break;
                }
            }
            dsPostChannels.isValidated = !isDirty;
        });
        this.dsPortToChannelIndex = JSON.parse(JSON.stringify(this.dsPortToChannelIndex)); // Need Deep copy to trigger change detection.

    }

    // UI-Event:: Add new mapping and update the arrays.
    public addMapping(type: string): void {
        this.disableSave();
        const newMapping: any = {
            'portIndex': 0,
            'channelIndex': 0,
            'isValidated': true
        };
        if (type.toLowerCase() === 'us') {
            this.usPortToChannelIndex.push(newMapping);
        } else if (type.toLowerCase() === 'ds') {
            this.dsPortToChannelIndex.push(newMapping);
        }
        this.isChannelPresent = false;
    }

    // Handle error
    private onError(error): void {
        this.logger.error('onError():  error data=', error);
        this.showAlert.showErrorAlert(error);
    }

    //Translation
    private translateLocaleString(): void {
        const localizationService = this.localeDataService.getLocalizationService();
        this.NDF_NDR_UPDATE_SUCCESS = localizationService.instant('NDF_NDR_UPDATE_SUCCESS');
    }
}
