/**
 * Created by jerry.blum on 2020-06-12
 */

import {Component, EventEmitter, Output} from '@angular/core';
import {CmtsTabDataService} from '../cmts-tab.data.service';
import {ALERT_ERROR} from '../../../../constant/app.constants';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ShowAlert} from '../../../../utilities/showAlert';
import {Logger} from '../../../../utilities/logger';
import {SharedService} from '../../../../shared/shared.service';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import * as AppConstants from '../../../../constant/app.constants';
import { Observable } from 'rxjs';

@Component({
	selector: 'import-cmts-component',
	templateUrl: 'import-cmts.component.html'
})

export class ImportCmtsComponent{
	public closeSlider: Observable<boolean>;
	@Output() onCloseSlider: EventEmitter<any> = new EventEmitter<any>();
	
	private isValidCSVFile: boolean = false;
	public form: FormGroup;
	private tag: string = "ImportCmtsComponent ::";

	private IMPORT_CMTS_SUCCESS: string = '';
	private IMPORT_FILE_INVALID: string = '';
	private IMPORT_CMTS_ERROR: string = '';

	// Form Properties
	private get file() {
		return this.form.get('file');
	}


	constructor(private cmtsTabDataService: CmtsTabDataService,
				private showAlert: ShowAlert, private fb: FormBuilder,
				private logger: Logger,
				private sharedService: SharedService,
				private localeDataService: LocaleDataService){
	}

	private getFormProperties(): any {
		const formatProperties: any = {
			file: this.fb.control(null, Validators.required)
		}

		return formatProperties;
	}

	private buildForm(): FormGroup {
		return this.fb.group(this.getFormProperties());
	}

	ngOnInit() {
		this.form = this.buildForm();
		this.translateLocaleString();
	}

	// Cancels out of the modem import editor without submitting the form.
	private onCancel(): void {
		this.onCloseSlider.emit(Math.random());
	}

	// Add imported cmts' to server on submit
	private onSubmit(cmtsForm: any): void {
		let formData = new FormData();
		formData.append('file', this.file.value, this.file.value.name);

		this.cmtsTabDataService.addCmtsToServer(formData)
			.subscribe(this.onAddNext.bind(this), this.onError.bind(this));
	}

	// Handle successful cmts import.
	private onAddNext(data: any): void {
		if(data.errorCode == 0) {
			this.showAlert.showSuccessAlert(this.IMPORT_CMTS_SUCCESS);
		} else {
			let errorcode = parseInt(AppConstants.MODULECODE.CMTS_MODEM_TAB_IMPORT_CMTS + "" + data.errorCode);
			let errorObj = {
				errorCode: errorcode
			}
			this.showAlert.showAlertWithExportCmtsImport(data, this.IMPORT_CMTS_ERROR);
		}
		this.onCancel();
	}

	// Handles request errors from submitting modem import.
	private onError(error: any): void {
		this.logger.debug(this.tag, "onError(): error data=", error);
		this.showAlert.showErrorAlert(error);
		this.onCancel();
	}

	private fileChange(event: any): void {
		const target: any = event.target;
		this.isValidCSVFile = target.value.endsWith('.csv');
		if (this.isValidCSVFile) {
			let files: any = target.files;
			if (files.length) {
				this.file.setValue(files[0]);
			}
		} else {
			this.showAlert.showSuccessAlert(this.IMPORT_FILE_INVALID, true, ALERT_ERROR);
		}
	}

	// Sets up localization resources used by this component.
	private translateLocaleString(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this.IMPORT_CMTS_SUCCESS = localizationService.instant('IMPORT_CMTS_SUCCESS');
		this.IMPORT_FILE_INVALID = localizationService.instant('IMPORT_FILE_INVALID');
		this.IMPORT_CMTS_ERROR = localizationService.instant('IMPORT_CMTS_ERROR');
	}
}