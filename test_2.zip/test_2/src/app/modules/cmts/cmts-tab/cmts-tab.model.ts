/**
 * Created by yogesh.paisode on 6/8/2017.
 */

export class CmtsTabModel{
    public cmtsId: number;
    public name: string;
    public hostname: string;
    public proxyHostname: string;
    public snmpCommunityString: string;
    public snmpWriteCommunityString: string;
    public docsisVersion: number;
    public manufacture: string;
    public status: string;
    public description: string;
    public upstreamCount: number;
    public modemCount: number;
    public nodeCount: number;
    public accessed: string;
    public container: string;
    public containerId: string;
    public containerPath: string;
    public site: string;
    public siteId: string;
    public config: Object;
    public mactrakFailThreshold: number;
    public mactrakMarginalThreshold: number;
    public rciMonRateDelay: number;
    public rciMonRateControl: number;
    public rciMonRatePercent: number;
    public cmtsUsPortCount: number;
    public rci: string;

    constructor(cmtsData: any, localizationService: any){
        this.rciMonRatePercent = cmtsData.rciMonRatePercent;
        this.rciMonRateDelay = cmtsData.rciMonRateDelay;
        this.rciMonRateControl = cmtsData.rciMonRateControl;

        if (!this.rciMonRateDelay) {
            this.rciMonRateDelay = 0;
        }

        if (!this.rciMonRatePercent) {
            this.rciMonRatePercent = 0;
        }


        this.cmtsId = cmtsData.cmtsId;
        this.name = cmtsData.name ? cmtsData.name : null;
        this.hostname = cmtsData.hostname ? cmtsData.hostname : null;
        this.proxyHostname = cmtsData.proxyHostname;
        this.snmpCommunityString = cmtsData.snmpCommunityString ? cmtsData.snmpCommunityString : null;
        this.snmpWriteCommunityString = cmtsData.snmpWriteCommunityString ? cmtsData.snmpWriteCommunityString : null;
        this.docsisVersion = cmtsData.docsisVersion ? cmtsData.docsisVersion : null;
        this.manufacture = cmtsData.manufacture ? cmtsData.manufacture : null;
        this.description = cmtsData.description ? cmtsData.description : null;
        this.upstreamCount = cmtsData.upstreamCount;
        this.modemCount = cmtsData.modemCount;
        this.nodeCount = cmtsData.nodeCount;
        this.accessed = cmtsData.accessed ? cmtsData.accessed : null;
        this.container = cmtsData.containerName;
        this.containerId = cmtsData.containerId;
        this.containerPath = cmtsData.containerPath;
        this.site = cmtsData.siteName;
        this.siteId = cmtsData.siteId;
        this.config = cmtsData.config;
        this.cmtsUsPortCount = cmtsData.cmtsUsPortCount;
        this.mactrakFailThreshold = cmtsData.mactrakFailThreshold;
        this.mactrakMarginalThreshold = cmtsData.mactrakMarginalThreshold;
        this.rci = cmtsData.rci;
        if(localizationService){
            this.status = cmtsData.online ? ("ONLINE".toUpperCase()) : localizationService.instant("UNAVAILABLE".toUpperCase());
            this.status = this.status.toUpperCase();
        }
    }
}