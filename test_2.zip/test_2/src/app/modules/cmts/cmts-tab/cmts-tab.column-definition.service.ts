/**
 * Created by yogesh.paisode on 6/9/2017.
 */
import {Injectable} from "@angular/core";

import {EDIT_ICON} from "../../../constant/app.constants";
import {CmtsTabSharedService} from "../cmts-tab.shared.service";
import {Subject} from "rxjs";
import {EDIT_OPERATION} from "../cmts-tab.constants";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {TimeFilter} from "../../../shared/time.filter";
import {StatusFilter} from "../../../shared/status.filter";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import {CMTSUrlService} from "../cmts.url.service";
import { TranslateService } from "@ngx-translate/core";
//import * as moment from "moment/moment";

@Injectable()
export class CmtsTabColumnDefinitionService{

    private _HEADER_FIELDS: any = {
        status : {field: "status", name: "Status"},
        hostname : {field: "hostname", name: "Hostname"},
        name : {field: "name", name: "Name"},
        manufacturer : {field: "manufacture", name: "Manufacturer"},
        docsisVersion : {field: "docsisVersion", name: "DOCSIS Version"},
        upstreamChannels : {field: "upstreamCount", name: "Upstream Channels"},
        modems : {field: "modemCount", name: "Modems"},
        nodes : {field: "nodeCount", name: "Nodes"},
        lastUpdate : {field: "accessed", name: "Last Update"},
        edit : {field: "edit", name: "Edit"},
        container : {field: "container", name: "Container"},
        site : {field: "site", name: "Site"},
        rci : {field: "rci", rci: "RCI"},
        cmtsUsPortCount : {field: "cmtsUsPortCount", name: "CMTS_TAB_HEADER_UPSTREAM_PORT_COUNT"},
    };
    private cmtsTabFormChangeSubject: Subject<any>;

    constructor(private localeDataService: LocaleDataService,
        private cmtsTabSharedService: CmtsTabSharedService,
        private sharedService : SharedService,
        private translate: TranslateService,
        private urlService: CMTSUrlService){
        this.cmtsTabFormChangeSubject = this.cmtsTabSharedService.getCmtsTabFormChangeSubject();
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.status.name = this.translate.instant('CMTS_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.hostname.name = this.translate.instant('CMTS_TAB_HEADER_HOSTNAME');
        this._HEADER_FIELDS.name.name = this.translate.instant('CMTS_TAB_HEADER_NAME');
        this._HEADER_FIELDS.manufacturer.name = this.translate.instant('CMTS_TAB_HEADER_MANUFACTURER');
        this._HEADER_FIELDS.docsisVersion.name = this.translate.instant('CMTS_TAB_HEADER_DOCSIS_VERSION');
        this._HEADER_FIELDS.upstreamChannels.name = this.translate.instant('CMTS_TAB_HEADER_UPSTREAM_CHANNELS');
        this._HEADER_FIELDS.modems.name = this.translate.instant('CMTS_TAB_HEADER_MODEM');
        this._HEADER_FIELDS.nodes.name = this.translate.instant('CMTS_TAB_HEADER_NODES');
        this._HEADER_FIELDS.lastUpdate.name = this.translate.instant('CMTS_TAB_HEADER_LAST_UPDATE');
        this._HEADER_FIELDS.edit.name = this.translate.instant('CMTS_TAB_HEADER_EDIT');
        this._HEADER_FIELDS.container.name = this.translate.instant('CMTS_TAB_HEADER_CONTAINER');
        this._HEADER_FIELDS.site.name = this.translate.instant('CMTS_TAB_HEADER_SITE');
        this._HEADER_FIELDS.rci.name = this.translate.instant('CMTS_TAB_HEADER_RCI');
        this._HEADER_FIELDS.cmtsUsPortCount.name = this.translate.instant('CMTS_TAB_HEADER_UPSTREAM_PORT_COUNT');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        this.translateLocaleStr();
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.name.name,headerTooltip: this._HEADER_FIELDS.name.name, field: this._HEADER_FIELDS.name.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.name.name, 70),
                filter: 'text',sort: 'asc',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.status.name,headerTooltip: this._HEADER_FIELDS.status.name, field: this._HEADER_FIELDS.status.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 95),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                filter: StatusFilter.ParentFilter,
                floatingFilterComponent: StatusFilter.ChildFloatingFilter
            },
            {
                headerName: this._HEADER_FIELDS.hostname.name,headerTooltip: this._HEADER_FIELDS.hostname.name, field: this._HEADER_FIELDS.hostname.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.hostname.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                cellRenderer: ((param:any)=>{
                    if(!param.value || !param.data) { return "<div></div>"; }
                    let url = this.urlService.getRedirectCmtsDiagnosticUrl(param.data.cmtsId);
                    return "<a class='cursorClass' target='_blank' href='" + url + "'>" + param.value + "</a>";
                })
            },
            {
                headerName: this._HEADER_FIELDS.manufacturer.name,headerTooltip: this._HEADER_FIELDS.manufacturer.name, field: this._HEADER_FIELDS.manufacturer.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.manufacturer.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.docsisVersion.name,headerTooltip: this._HEADER_FIELDS.docsisVersion.name, field: this._HEADER_FIELDS.docsisVersion.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.docsisVersion.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.upstreamChannels.name,headerTooltip: this._HEADER_FIELDS.upstreamChannels.name, field: this._HEADER_FIELDS.upstreamChannels.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.upstreamChannels.name, 60),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.cmtsUsPortCount.name,headerTooltip: this._HEADER_FIELDS.cmtsUsPortCount.name, field: this._HEADER_FIELDS.cmtsUsPortCount.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.cmtsUsPortCount.name, 90),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.modems.name,headerTooltip: this._HEADER_FIELDS.modems.name, field: this._HEADER_FIELDS.modems.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modems.name, 90),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.nodes.name,headerTooltip: this._HEADER_FIELDS.nodes.name, field: this._HEADER_FIELDS.nodes.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.nodes.name, 60),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.lastUpdate.name,headerTooltip: this._HEADER_FIELDS.lastUpdate.name, field: this._HEADER_FIELDS.lastUpdate.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.lastUpdate.name, 90),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: this.sharedService.dateComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                filter: TimeFilter.ParentFilter,
                floatingFilterComponent: TimeFilter.ChildFloatingFilter,
                cellRenderer:(params:any)=>{
                    let dateInSpanish = this.sharedService.getLocaleDate(params.value);// moment(params.value).format('lll');
                    return dateInSpanish;
                }
            },
            {
                headerName: this._HEADER_FIELDS.container.name,
                headerTooltip: this._HEADER_FIELDS.container.name, 
                field: this._HEADER_FIELDS.container.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.container.name, 80),
                floatingFilterComponentParams:{ suppressFilterButton:true},
                filter: 'text',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.site.name,
                headerTooltip: this._HEADER_FIELDS.site.name, 
                field: this._HEADER_FIELDS.site.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.site.name, 80),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'text',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true.valueOf,
                    newRowsAction: 'keep'},
                sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.rci.name,
                headerTooltip: this._HEADER_FIELDS.rci.name,
                field: this._HEADER_FIELDS.rci.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rci.name, 80),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'text',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                minWidth: 70, maxWidth: 150,
				pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }

        ]
        return columnDef;
    }

    //@method :: callback action for clear icon click
    private action(param: any): void{
        let data: any = {operation: EDIT_OPERATION, cmtsTabModel: param.data};
        this.cmtsTabSharedService.setCmtsTabModelData(data);
        this.cmtsTabFormChangeSubject.next(data);
    }
}