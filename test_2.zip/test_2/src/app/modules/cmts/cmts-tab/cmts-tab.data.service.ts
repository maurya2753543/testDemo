import { map,catchError } from 'rxjs/operators';
import {_throw} from 'rxjs/observable/throw';
/**
 * Created by yogesh.paisode on 6/8/2017.
 */
import {Injectable} from "@angular/core";
import {CMTSHttpService} from "../cmts.http.service";
import {Observable} from "rxjs";
import {HttpResponse} from "@angular/common/http";
import {CmtsTabModel} from "./cmts-tab.model";
import { TranslateService } from '@ngx-translate/core';
import {LanguageService} from "../../../shared/locale.language.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import { SharedService } from 'src/app/shared/shared.service';

@Injectable()
export class CmtsTabDataService {

    private cmtsTabList: Array<CmtsTabModel> = new Array<CmtsTabModel>();
    private localizationService: any;
    private readonly language: string;
    public cmtstabfilterchangedata: any;

    constructor(private cmtsHttpService: CMTSHttpService,
                private localeDataService: LocaleDataService,
                private languageService: LanguageService,
                translateService : TranslateService,
                private sharedService:SharedService) {
                    this.localizationService = this.localeDataService.getLocalizationService();
                    this.language = translateService.currentLang;
    }

    public getSweepConfig(id: number): Observable<any> {
        return this.cmtsHttpService
            .getSweepConfig(id)
            .pipe(
                map((response: any) => {
                    return this.processData(response);
                })
                ,catchError(this.handleError)
            )
    }

    private processData(data: any): any {
        if (data.usPortToChannelIndex) {
            data.usPortToChannelIndex.forEach((obj: any) => {
                obj['id'] = Math.random();
                obj['isValidated'] = true;
            });
        }
        if (data.dsPortToChannelIndex) {
            data.dsPortToChannelIndex.forEach((obj: any) => {
                obj['id'] = Math.random();
                obj['isValidated'] = true;
            });
        }
        return data;
    }

    public validateCMTSConfig(postData: any): Observable<any> {
        return this.cmtsHttpService
            .validateCMTSConfig(postData)
            .pipe(
                map((data) => data),
                catchError(this.handleError)
            )

    }

    public updateCMTSConfig(postData: any): Observable<any> {
        return this.cmtsHttpService
            .updateCMTSConfig(postData)
            .pipe(
                catchError(this.handleError)
            )
    }

    //Method to get all CMTS list
    public getAllCmtsList(): Observable<any> {
        return this.cmtsHttpService
            .getAllCmtsList()
            .pipe(
                map((cmtsTabListDataObj: HttpResponse<any>) => {
                    this.setCmtsTabList(cmtsTabListDataObj);
                    return this.cmtsTabList;
                }), catchError(this.handleError)
            )

    }

    public getModemCustomFields(): Observable<any> {
        return this.cmtsHttpService
            .getCustomFields()
            .pipe(
                map((customFields: HttpResponse<any>) => {
                   // const data: any[] = customFields;
                   const data: any = customFields;
                    data.forEach((field: any, index: number) => {
                        field['formKey'] = 'customField' + (index + 1);
                    });
                    return data;
                }),catchError(this.handleError)
            )
    }

    public topologyExportFields(){
        return this.cmtsHttpService
        .topologyExportFields()
        .pipe(
            map((response: HttpResponse<any>) => {
                return response;
            }),catchError(this.handleError)
        )
    }

    //Method to export Noisetrak config features
    public noisetrakExportFeature(){
        return this.cmtsHttpService
        .noisetrakExportFields()
        .pipe(
            map((response: HttpResponse<any>) => {
                return response;
            }),catchError(this.handleError)
        )
    }
    

    //Method to get CMTS features
    public getCmtsFeatures(): Observable<any> {
        return this.cmtsHttpService
            .getCmtsFeatures()
            .pipe(
                map((customFields: HttpResponse<any>) => {
                    //const data: any[] = customFields;
                    const data: any = customFields;
                    data.forEach((field: any, index: number) => {
                        field['formKey'] = 'customField' + (index + 1);
                    });
                    return data;
                }),catchError(this.handleError)
            )
    }

    //CMTS EDIT
    public editCMTSRow(cmtsTabModel: CmtsTabModel): Observable<any> {
        return this.cmtsHttpService
            .putCMTS(cmtsTabModel.cmtsId, cmtsTabModel)
            .pipe(
                map((updatedCMTS: HttpResponse<any>) => {
                    return updatedCMTS;
                }),catchError(this.handleError)
            )
    }

    //CMTS DELETE
    public deleteCMTSRow(cmtsId): Observable<any> {
        return this.cmtsHttpService
            .deleteCMTS(cmtsId)
            .pipe(
                map((res: HttpResponse<any>) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    //CMTS ADD
    public addCMTSRow(data): Observable<any> {
        return this.cmtsHttpService
            .addCMTS(data)
            .pipe(
                map((res: HttpResponse<any>) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    //CMTS CONTROL OPERATIONS
    public saveCmtsfeatures(data): Observable<any> {
        return this.cmtsHttpService
            .postCmtsFeatures(data)
            .pipe(
                map((res: HttpResponse<any>) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    //CMTS SYNC all
    public syncAllCmts(): Observable<any> {
        return this.cmtsHttpService
            .syncAllCmts()
            .pipe(
                map((res: HttpResponse<any>) => {
                    return res;
                }), catchError(this.handleError)
            )
    }

    //CMTS sync selected
    public syncSelectedCmts(cmtsIds: number[]): Observable<any> {
        return this.cmtsHttpService
            .syncSelectedCmts(cmtsIds)
            .pipe(
                map((res: HttpResponse<any>) => {
                    return res;
                }), catchError(this.handleError)
            )
    }

    //Error handler
    public handleError(error) {
        return _throw(error);
    }

    /*Method to set Node list*/
    public setCmtsTabList(dataListObj: any): void {
        this.cmtsTabList = [];
        let lang = this.languageService.getCurrentLanguage();
        for (let i = 0; i < dataListObj.length; i++) {
            dataListObj[i].docsisVersion = this.sharedService.toDecimalForDocsis(dataListObj[i].docsisVersion, '1.1-3');
            let cmtsTabModel: CmtsTabModel = new CmtsTabModel(dataListObj[i], this.localizationService);
            this.cmtsTabList.push(cmtsTabModel);
        }
    }

    //Get cmts list
    public getCmtsTabList(): Array<CmtsTabModel> {
        if (this.cmtsTabList) {
            return this.cmtsTabList;
        }
        return null;
    }

    /*Method to Import modem data */
    public addModemToServer(data): Observable<any> {
        return this.cmtsHttpService
            .addModemToServer(data)
            .pipe(
                map((response) => {
                    return response;
                }),catchError(this.handleError)
            )
    }

    public addCSVConfigToServer(data): Observable<any> {
        return this.cmtsHttpService
            .addModemToServerCSV(data)
            .pipe(
                map((response) => {
                    return response;
                }),catchError(this.handleError)
            )
    }

     /* Method to Import Noisetrak Data */
    public addNoisetrakCSVConfigToServer(data): Observable<any> {
        return this.cmtsHttpService
            .addNoisetrakToServerCSV(data)
            .pipe(
                map((response) => {
                    return response;
                }),catchError(this.handleError)
            )
    }
    

    /* Method to Import CMTS Data */
	public addCmtsToServer(data): Observable<any> {
		return this.cmtsHttpService
			.addCmtsToServer(data)
			.pipe(
                map((response) => {
                    return response;
                }),catchError(this.handleError)
            )
	}
}
