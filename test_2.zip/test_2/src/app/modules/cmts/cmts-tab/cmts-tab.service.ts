/**
 * Created by yogesh.paisode on 6/13/2017.
 */
import {Injectable} from "@angular/core";

import {CmtsTabModel} from "./cmts-tab.model";

@Injectable()
export class CmtsTabService{

    //Method to get selected rows from grid
    public getSelectedRowsCmtsIds(cmtsModels: CmtsTabModel[], selectedRowsCmtsId: number[]): void{
        cmtsModels.forEach((cmtsModel: CmtsTabModel)=>{
            selectedRowsCmtsId.push(cmtsModel.cmtsId);
        });
    }

    //Method to restore grid selection
    public restoreSelection(selectedRowsCmtsId: number[], cmtsTabGridOptionsAPI: any): void{
        if(selectedRowsCmtsId.length >= 1){
            cmtsTabGridOptionsAPI.forEachNode((node)=>{
                for(let i = 0; i < selectedRowsCmtsId.length; i ++){
                    if (node.data.cmtsId === selectedRowsCmtsId[i]) {
                        node.setSelected(true);
                        break;
                    }// End of if
                }// End of For
            });// End of forEachNode
        }// End of If
    }
}
