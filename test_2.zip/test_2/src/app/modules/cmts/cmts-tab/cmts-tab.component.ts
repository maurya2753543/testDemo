import {Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, OnDestroy} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import {Grid} from "../../../shared/ag-grid.options";
import {CmtsTabDataService} from "./cmts-tab.data.service";
import {CmtsTabModel} from "./cmts-tab.model";
import {CmtsTabColumnDefinitionService} from "./cmts-tab.column-definition.service";
import {CmtsViewComponent} from './cmts-view/cmts-view.component';
import {Logger} from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {CmtsTabSharedService} from "../cmts-tab.shared.service";
import {CmtsTabService} from "./cmts-tab.service";
import {ADD_OPERATION} from "../cmts-tab.constants";
import {LocaleDataService} from "../../../shared/locale.data.service";
import * as cstmConstants from "../cmts-tab.constants";
import {Subject} from 'rxjs/';
import {takeUntil} from 'rxjs/operators';
import {SharedService} from "../../../shared/shared.service";
import {StatusFilter} from "../../../shared/status.filter";
import {CMTSViewEvent} from "../view-events/view-event.component";
import {CmtsControlFeaturesComponent} from './cmts-control-features/cmts-control-features.component';
import { SweetAlert } from '../../../utilities/sweetAlert';
import { ALERT_INFO } from '../../../constant/app.constants';
import { CommonStrings } from '../../../constant/common.strings';
import { CMTSHttpService } from '../cmts.http.service';
import { CMTSDataService } from '../cmts.data.service';

let vm;

function isExternalFilterPresent() {
    return vm.showSelected;
}

function doesExternalFilterPass(node) {
    return node.data.status.toUpperCase() === vm.currentFilter.toUpperCase();
}

@Component({
    selector: 'cmtstab-component',
    templateUrl: 'cmts-tab.component.html'
})

export class CMTSTabComponent implements OnDestroy {
    public viewData: boolean = false;
    public cmtsTabGridOptions: Grid = new Grid();
    private selectedRowsCmtsId: number[] = [];
    private nameFilterInstance: any;
    public eventKeys: Object[];
    public buttonKeys: Object[];
    public cmtsTabGridRowData: any;
    private CMTS_TAB_BTN: string = "";
    private CMTS_DIAGNOSTIC_BTN: string = "";
    private EVENTS: string;
    private CMTS_TAB_SYNC_SELECTED: string = "";
    private CMTS_TAB_SYNC_ALL = "";
    private TABLE_LIST_EXPORT_SELECTED: string = "";
    private TABLE_LIST_EXPORT_ALL: string = "";
    private BULK_MODIFY_FEATURES: string = "";
    private SET_MACTRAK_THRESHOLD: string= "";
    private RESET_MACTRAK_THRESHOLD: string ="";
    private CONFIG_NDF_NDR: string = "";
    private SYNC_SUCCESS: string = "";
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    public gridTabType: string = "CMTSExport";
    public showAllLabel: string = '';
    public showAllLabelMob: string = '';
    private TABLE_LIST_SHOWING: string = '';
    private TABLE_LIST_SHOWING_OF: string = '';
    private TABLE_LIST_ROWS: string = "";
    private CMTS_MODEM_BTN_IMPORT_MODEM: string = "";
    private CMTS_BTN_IMPORT_NOISETRAK:string = "";
    private CMTS_IMPORT_CMTS_BTN: string = "";
    private totalCount: number = 0;
    private showSelected: boolean = false;
    private currentFilter: string;
    private VIEW_EVENTS: string = "";
    public enableImportModemSlider: boolean = false;
    public enableImportCmtsSlider: boolean = false;
    public enableImportNoisetrakSlider: boolean = false;
    public openNdfNdrSliderData: any = null;
    private RESET_MACKTRACK_TITLE: string = "";
    private RESET_MACKTRACK_CONFIRMATION_MSG: string = "";
    private osInfo: any;

    @ViewChild('targetCmtsView', {read: ViewContainerRef}) _targetCmtsView;

    constructor(private showAlert: ShowAlert,
                private logger: Logger,
                private cmtsTabDataService: CmtsTabDataService,
                private cmtsTabSharedService: CmtsTabSharedService,
                private cmtsTabService: CmtsTabService,
                private cmtsTabColumnDefinitionService: CmtsTabColumnDefinitionService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private localeDataService: LocaleDataService,
                private sharedService: SharedService,
                private viewContainerRef: ViewContainerRef,
                private sweetAlert: SweetAlert,
                private cmtsDataService: CMTSDataService,
                private cmtsHttpService: CMTSHttpService) {
        vm = this;
        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
            this.setEventButtonKeys();
        });
    }

    ngOnInit() {
        this.translateLocaleString();
        this.cmtsDataService.OSInfo$.subscribe(response => {
            this.osInfo = response;
            this.setEventButtonKeys();
            this.initAllSubjectListener();
            this.getCmtsFeaturesFromAPI();
        })
        if(this.sharedService.RetainFilter){
            this.cmtsTabDataService.cmtstabfilterchangedata = "";
            this.cmtsDataService.cmtsmodeldata = "";
        }
    }

    /*
     *@name CMTSEvent
     *@desc Events related to cstm tab (CSTM).
     *@return void
     */
    public notifyActionEmitter($event) {
        switch ($event.event.name) {
            case this.CMTS_TAB_SYNC_ALL:
                this.notifySyncAllCMST();
                break;
            case this.CMTS_TAB_SYNC_SELECTED:
                this.notifySyncSelectedCMST();
                break;
            case this.CMTS_TAB_BTN:
                this.notifyAddCMTS();
                break;
            case this.CMTS_MODEM_BTN_IMPORT_MODEM:
                this.importModem();
                break;
            case this.VIEW_EVENTS:
                this.notifyViewEvent($event.selectedData);
                break;
            case this.CMTS_DIAGNOSTIC_BTN:
                this.linkToCmtsDiagnostic();
                break;
            case this.BULK_MODIFY_FEATURES:
                this.notifyControlFeatures($event.selectedData);
                break;
            case this.SET_MACTRAK_THRESHOLD:              
                this.notifyControlFeaturesMacktrak($event.selectedData);
                break;
            case this.RESET_MACTRAK_THRESHOLD:
                    this.notifyControlFeaturesMacktrakReset($event.selectedData);
                    break;

            // to hide Configure NDF / NDR dropdown action as per XPTUI-767
            // case this.CONFIG_NDF_NDR:
            //     this.notifyConfigNDF_NDR($event.selectedData);
            //     break;
            case this.CMTS_IMPORT_CMTS_BTN:
                this.importCMTS();
                break;
            case this.CMTS_BTN_IMPORT_NOISETRAK:
                this.importNoisetrak();
                break;
            default:
                break;
        }
    }

    //Method to set button keys
    private setEventButtonKeys(): void {
        this.eventKeys = [
            {name: this.CMTS_TAB_SYNC_SELECTED, status: cstmConstants.MULTI_CONTS, tabType: cstmConstants.CMTS_CONTS},
            {name: this.CMTS_TAB_SYNC_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.CMTS_CONTS},
            {name: this.VIEW_EVENTS, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.CMTS_CONTS},
            {name: this.BULK_MODIFY_FEATURES, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.CMTS_CONTS},
            {name: this.SET_MACTRAK_THRESHOLD, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.CMTS_CONTS},
            {name: this.RESET_MACTRAK_THRESHOLD, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.CMTS_CONTS},
        //    {name: this.CONFIG_NDF_NDR, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.CMTS_CONTS},
            {
                name: this.TABLE_LIST_EXPORT_SELECTED,
                status: cstmConstants.SINGLE_CONTS,
                tabType: cstmConstants.CMTS_CONTS
            },
            {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.CMTS_CONTS}
        ];
        this.buttonKeys = [
            {name: this.CMTS_BTN_IMPORT_NOISETRAK, tabType: cstmConstants.MODEM_CONTS},
            {name: this.CMTS_MODEM_BTN_IMPORT_MODEM, tabType: cstmConstants.MODEM_CONTS},
            {name: this.CMTS_TAB_BTN, tabType: cstmConstants.CMTS_CONTS},
            {name: this.CMTS_IMPORT_CMTS_BTN, tabType: cstmConstants.CMTS_CONTS},
            {
                name: this.CMTS_DIAGNOSTIC_BTN,
                tabType: cstmConstants.CMTS_CONTS,
                iconClass: 'fa fa-stethoscope',
                txt: ' '
            }
        ];
        this.buttonKeys = this.buttonKeys.filter((elem: any) => {
            if(this.osInfo != 'LINUX'){
                return elem.name != this.CMTS_BTN_IMPORT_NOISETRAK
            }
            return elem;
        })
    }

    //method loads control features slider.
    private notifyControlFeatures($event) {
        this.cmtsTabSharedService.bulkModifyFlag = true;
        this.cmtsTabSharedService.mactrakThresholdFlag = false;
        let data = $event;
        let cmtsIdArr: number[] = [];
        for (let i = 0; i < data.length; i++) {
            cmtsIdArr.push(data[i].cmtsId);
        }
        this.LoadViewTab(CmtsControlFeaturesComponent, cmtsIdArr);
    }

    private notifyControlFeaturesMacktrak($event){
        this.cmtsTabSharedService.mactrakThresholdFlag = true;
        this.cmtsTabSharedService.bulkModifyFlag = false;
        this.cmtsTabSharedService.selectedCmts = $event;
        let data = $event;
                    let cmtsIdArr: number[] = [];
                    for (let i = 0; i < data.length; i++) {
                        cmtsIdArr.push(data[i].cmtsId);
        }
        this.cmtsTabSharedService.deviceIds = cmtsIdArr
        this.LoadViewTab(CmtsControlFeaturesComponent);
    }

    private notifyControlFeaturesMacktrakReset($event){       
        this.sweetAlert.showConformationAlert(ALERT_INFO , this.RESET_MACKTRACK_TITLE , this.RESET_MACKTRACK_CONFIRMATION_MSG ,true , true, CommonStrings.RESET, CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) { 
                    let data = $event;
                    let cmtsIdArr: number[] = [];
                    for (let i = 0; i < data.length; i++) {
                        cmtsIdArr.push(data[i].cmtsId);
                    }
                    var attributeList = ["QP_MARGINAL_THRESHOLD", "QP_FAIL_THRESHOLD"]
                    this.cmtsHttpService.deleteMACTrakThreshold(cmtsIdArr,attributeList).subscribe(res =>{})
                }
            }
        ); 
    }

    private notifyConfigNDF_NDR(data: any): void {
        this.openNdfNdrSliderData = data;
    }

    private onCloseCmtsSlider(): void {
        this.openNdfNdrSliderData = null;
    }

    private importModem(): void {
        this.enableImportModemSlider = true;
    }

    private importCMTS(): void {
        this.enableImportCmtsSlider = true;
    }

    private importNoisetrak(): void {
        this.enableImportNoisetrakSlider =true;
    }
    
    //method loads view events slider.
    private notifyViewEvent($event) {
        let data = $event;
        data["id"] = data[0].cmtsId;
        data["headerName"] = "CMTS " + this.EVENTS + " - " + data[0].name;
        data["type"] = "CMTS";
        this.LoadViewTab(CMTSViewEvent, data);
    }

    //Method to apply filter on ag-Grid
    private applyNameFilter(filterValue: string): void {
        // this.nameFilterInstance.setFilter(filterValue);
        // this.nameFilterInstance.onFilterChanged();
    }

    //Method to get filter text
    private getNameFilterText(): string {
        let filterText: string = "";
        let filterModel: any = this.nameFilterInstance.getModel();
        if (filterModel) {
            filterText = filterModel.filter;
        }
        return filterText;
    }

    //Listener for filter change from node ag-Grid
    public notifyfilterChangeCMTS(e) {
        this.sharedService.RetainFilter = false;
        const countryFilterComponent = this.cmtsTabGridOptions.api.getFilterInstance('name');
        const model = countryFilterComponent.getModel();
        this.cmtsDataService.cmtsmodeldata = model;
        // let nameFilterText: string = this.getNameFilterText();
        // this.cmtsTabSharedService.setNameFilterText(nameFilterText);
        this.cmtsTabDataService.cmtstabfilterchangedata = this.cmtsTabGridOptions.api.getFilterModel(); 
    }

    //Listener for form change
    private cmtsTabFormChangeSubjectListener(): void {
        this.cmtsTabSharedService
            .getCmtsTabFormChangeSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(() => {
                this.LoadViewTab(CmtsViewComponent);
                this.viewData = !this.viewData;
            });
    }

    //Method for SYNC all CMTS
    private notifySyncAllCMST(): void {
        this.cmtsTabDataService
            .syncAllCmts()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(() => {
                this.onSyncSuccess();
                this.logger.info("CMTS Sync all Successful..");
            }), this.onError.bind(this);
    }

    //Method for SYNC selected CMTS
    private notifySyncSelectedCMST(): void {
        let selectedRows: number[] = JSON.parse(JSON.stringify(this.storeSelection()));
        if (selectedRows.length >= 1) {
            this.cmtsTabDataService
                .syncSelectedCmts(selectedRows)
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(() => {
                    this.onSyncSuccess();
                    this.logger.info("CMTS Sync selected Successful..");
                }), this.onError.bind(this);
        }
    }

    private linkToCmtsDiagnostic(): void {
        window.open(window.location.origin + "/pathtrak/diagnosticview/index.html#/cmts", "_blank");
    }

    //Method to Add CMTS
    private notifyAddCMTS(): void {
        let data: any = {operation: ADD_OPERATION, cmtsTabModel: null};
        this.cmtsTabSharedService.setCmtsTabModelData(data);
        this.LoadViewTab(CmtsViewComponent);
    }

    //Grid Ready Event
    public notifyGridReadyCMTS(): void {
        this.setGridColumnDefinition();
    }

    //Init all subject listener
    private initAllSubjectListener(): void {
        this.cmtsListRefreshSubjectListener();
        this.cmtsTabFormChangeSubjectListener();
    }

    //Get CMTS list from API
    private getCmtsListFromAPI(): void {
        this.storeSelection();
        this.showGridLoadingOverly();
        this.cmtsTabDataService
            .getAllCmtsList()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.onCmtsListNext.bind(this), this.onError.bind(this));
    }

    //Get CMTS Features from API
    private getCmtsFeaturesFromAPI(): void {
        this.cmtsTabDataService
            .getCmtsFeatures()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((features) => {
                if (features) {
                    this.cmtsTabSharedService.setCmtsFeatures(features);
                }
            });
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount): void {
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e: any): void {
        let rowCount = this.cmtsTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //Method to clear other components
    private LoadViewTab(targetComponent: any, data?: any): void {
        this._targetCmtsView.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        let cmpRef = this._targetCmtsView.createComponent(factory);
        cmpRef.instance.childData = data;
    }

    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.cmtsTabGridOptions.api.setColumnDefs(this.cmtsTabColumnDefinitionService.getColumnDef());
        //this.nameFilterInstance = this.cmtsTabGridOptions.api.getFilterInstance('name');
        //this.applyNameFilter(this.cmtsTabSharedService.getNameFilterText());
        this.getCmtsListFromAPI();
    }

    //Method to refresh ag-Grid
    private cmtsListRefreshSubjectListener(): void {
        this.cmtsTabSharedService
            .getCmtsListRefreshSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((isHardReset: boolean) => {
                if (isHardReset) {
                    this.clearGridData();
                    this.getCmtsListFromAPI();
                }
            });
    }

    //Set row data
    private onCmtsListNext(cmtsTabList: CmtsTabModel[]): void {
        if (this.sharedService.getFilterForTAB().length > 0) {
            this.showSelected = true;
            this.cmtsTabGridOptions["isExternalFilterPresent"] = isExternalFilterPresent;
            this.cmtsTabGridOptions["doesExternalFilterPass"] = doesExternalFilterPass;
            this.currentFilter = this.sharedService.getFilterForTAB();
            StatusFilter.setFilter(this.currentFilter);
            this.cmtsTabGridOptions.api.getFilterInstance('status').setModel(this.currentFilter);
            this.cmtsTabGridOptions.api.onFilterChanged();
            this.showSelected = false;
        }
        
        this.cmtsTabGridRowData = cmtsTabList;
        this.totalCount = cmtsTabList.length;
        this.setShowAllLabel(cmtsTabList.length, this.totalCount);
        this.setGridRowData(cmtsTabList);
        
        // if(this.cmtsTabGridOptions.api && ( this.cmtsDataService.cmtsmodeldata) ){
        if(this.cmtsTabGridOptions.api && ( !jQuery.isEmptyObject(this.cmtsTabDataService.cmtstabfilterchangedata) || this.cmtsDataService.cmtsmodeldata) ){
            this.cmtsTabGridOptions.api.setFilterModel(this.cmtsTabDataService.cmtstabfilterchangedata);            
            if(this.cmtsDataService.cmtsmodeldata || this.cmtsTabDataService.cmtstabfilterchangedata){
            const countryFilterComponent3 = this.cmtsTabGridOptions.api.getFilterInstance("name");
            countryFilterComponent3.setModel(this.cmtsDataService.cmtsmodeldata);
            }
        }

    }

    //Hide ag-Grid overlay
    private hideGridOverly(): void {
        this.cmtsTabGridOptions.api.hideOverlay();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.cmtsTabGridOptions.api.showLoadingOverlay();
    }

    //clear existing selection of ag-Grid
    private clearGridData(): void {
        this.storeSelection();
        //this.cmtsTabGridOptions.api.setRowData([]);
        this.cmtsTabGridRowData = [];
    }

    //Store existing selection of ag-Grid
    private storeSelection(): number[] {
        this.selectedRowsCmtsId.length = 0;
        this.cmtsTabService.getSelectedRowsCmtsIds(this.cmtsTabGridOptions.api.getSelectedRows(), this.selectedRowsCmtsId);
        return this.selectedRowsCmtsId;
    }

    //Set ag-Grid data
    private setGridRowData(cmtsTabList: CmtsTabModel[]): void {
        this.cmtsTabGridRowData = cmtsTabList;
        this.cmtsTabService.restoreSelection(this.selectedRowsCmtsId, this.cmtsTabGridOptions.api);
        this.hideGridOverly();
    }

    //Handle error
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //Show Sweetalert on SYNC success
    private onSyncSuccess(): void {
        this.showAlert.showInfoAlert(this.SYNC_SUCCESS);
    }

    ngOnDestroy() {
        this.sharedService.setFilterForTAB('');
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    public notifyRefreshGrid(event) {
        this.getCmtsListFromAPI();
    }

    /* Method get called when we come in HSM tab after switch the tab */
    public onTabSwitch(): void {
        //this.sharedService.RetainFilter = true;
        this.getCmtsListFromAPI();
        this.getCmtsFeaturesFromAPI();
    }

    private onCloseImportModem(): void {
        this.enableImportModemSlider = false;
    }

    private onCloseImportCmts(): void {
        this.enableImportCmtsSlider = false;
    }

    private onCloseImportNoisetrak(): void {
        this.enableImportNoisetrakSlider = false;
    }

    //Translation
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.CMTS_TAB_BTN = localizationService.instant('CMTS_TAB_BTN');

        this.VIEW_EVENTS = localizationService.instant('VIEW_EVENTS');
        this.EVENTS = localizationService.instant('EVENTS');
        this.CMTS_DIAGNOSTIC_BTN = localizationService.instant('CMTS_DIAGNOSTIC_BTN');
        this.CMTS_TAB_SYNC_SELECTED = localizationService.instant('CMTS_TAB_SYNC_SELECTED');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.CMTS_TAB_SYNC_ALL = localizationService.instant('CMTS_TAB_SYNC_ALL');
        this.SYNC_SUCCESS = localizationService.instant('SYNC_SUCCESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.BULK_MODIFY_FEATURES = localizationService.instant('BULK_MODIFY_FEATURES');
        this.SET_MACTRAK_THRESHOLD = localizationService.instant('SET_MACTRAK_THRESHOLD')
        this.RESET_MACTRAK_THRESHOLD = localizationService.instant('RESET_MACTRAK_THRESHOLD')
        this.CMTS_MODEM_BTN_IMPORT_MODEM = localizationService.instant('CMTS_MODEM_BTN_IMPORT_MODEM');
        this.CMTS_BTN_IMPORT_NOISETRAK = localizationService.instant('CMTS_BTN_IMPORT_NOISETRAK');
      //  this.CONFIG_NDF_NDR = localizationService.instant('CONFIG_NDF_NDR');
        this.CMTS_IMPORT_CMTS_BTN = localizationService.instant('CMTS_IMPORT_CMTS_BTN'),
        this.RESET_MACKTRACK_TITLE = localizationService.instant('RESET_MACKTRAK_TITLE');
        this.RESET_MACKTRACK_CONFIRMATION_MSG = localizationService.instant('RESET_MACKTRACK_CONFIRMATION_MSG')
    }
}
