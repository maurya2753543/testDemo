/**
 * Created by Punam Kolte 30/05/2019.
 */
import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import { CmtsTabSharedService } from "../../cmts-tab.shared.service";

@Injectable()
export class CmtsFeatureService{

    private serverDefaultFeature: any;
    private overrideFeature = [];
    private feature:any;

    constructor(private cmtsTabSharedService : CmtsTabSharedService){
        this.serverDefaultFeature = JSON.parse(JSON.stringify(this.cmtsTabSharedService.getCmtsFeatures()));
    }

    // Method to return changed feature and subFeatures.
    public getChangedData(defaultFeature: any[], serverDefaultFeature: any): any[] {
        const changedData: any[] = [];
        let masterData: any[];
        let viewData: any[];

        let viewSubFeatures: any[];
        let masterSubFeatures: any[];

        let bulkEditChangeData: any[] = [];

        for (let i = 0; i < defaultFeature.length; i++) {
            masterData = serverDefaultFeature[i];
            masterSubFeatures = masterData['subFeatures'];

            viewData = defaultFeature[i];
            viewSubFeatures = viewData['subFeatures'];

            if (viewData['feature'].enabled != masterData['feature'].enabled) {
                changedData.push(viewData['feature']);
            }

            if (viewSubFeatures) {
                for (let j = 0; j < viewSubFeatures.length; j ++) {
                    if (viewSubFeatures[j].feature.enabled != masterSubFeatures[j].feature.enabled) {
                        changedData.push(viewSubFeatures[j].feature);
                    }
                }
            }
        }

        return changedData;
    } // getChangedData

    public getDefaultOverriddenFeatures(defaultFeature: any[], featureConfiguration: any): any[] {

        let viewData: any[];
        let viewSubFeatures: any[];
        for (let i = 0; i < defaultFeature.length; i ++) {

            viewData = defaultFeature[i];
            viewSubFeatures = viewData['subFeatures'];

            featureConfiguration['featureOverrides'] && featureConfiguration['featureOverrides'].forEach(element => {
                if (viewData['feature'].name == element.name) {
                    if(viewData['feature'].enabled != element.enabled) {
                        viewData['feature'].enabled = element.enabled;
                    }
                }

                if (viewSubFeatures) {
                    for (let j = 0; j < viewSubFeatures.length; j ++) {
                        if (viewSubFeatures[j].feature.name == element.name) {
                            if(viewSubFeatures[j].feature.enabled != element.enabled) {
                                viewSubFeatures[j].feature.enabled = element.enabled;
                            }
                        }
                    }
                }
            });

        }
        return defaultFeature;
    }
}
