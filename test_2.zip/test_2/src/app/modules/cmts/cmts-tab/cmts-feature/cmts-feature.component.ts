/**
 * Created by Punam Kolte on 29/05/2019.
 */

import { Component, Input, Output, EventEmitter} from '@angular/core';

import { CmtsTabSharedService } from "../../cmts-tab.shared.service";
import {CmtsFeatureService} from "./cmts-feature.service";


@Component({
    selector: 'cmts-feature-component',
    templateUrl: 'cmts-feature.component.html'
})

export class CmtsFeatureComponent {

    private isEditMode: boolean;

    @Input('cmtsFeature')
    private cmtsFeature: any;

    @Input('featureConfig') 
    private featureConfig: any;

    @Input('isEdit')
    private isEdit: boolean;

    @Input('isReadOnly')
    private set isReadOnly(isReadOnly: boolean) {
        this.isEditMode = isReadOnly;
        if (!this.isEditMode) {
            this.processData();
        }
    };

    @Output() overrideFeature: EventEmitter<any> = new EventEmitter<any>();

    public defaultFeature: any[];
    private serverDefaultFeature: any[];

    private overriddenFeaturesArr:any[];

    constructor(private cmtsTabSharedService : CmtsTabSharedService,
                private cmtsFeatureService : CmtsFeatureService) {

    }

    ngOnInit() {
        this.defaultFeature = JSON.parse(JSON.stringify(this.cmtsFeature));
        this.processData();
        this.serverDefaultFeature = JSON.parse(JSON.stringify(this.cmtsTabSharedService.getCmtsFeatures()));
        this.onDefaultFeatureOveride(); 
    }

    private processData(): void {
        this.defaultFeature.forEach((feature: any) => {
            if (feature.subFeatures) {
                feature.subFeatures.forEach((subFeature: any) => {
                    if (!feature.feature.enabled) {
                        subFeature.feature.enabled = false;
                        subFeature.feature['disableInput'] = true;
                    } else {
                        subFeature.feature['disableInput'] = false;
                    }
                });
            }
        })
    }

    private onDefaultFeatureOveride(): void {
        if(this.isEdit) {
            this.defaultFeature = JSON.parse(JSON.stringify(this.cmtsFeatureService.getDefaultOverriddenFeatures(this.defaultFeature, this.featureConfig)));
        }
    }

    private onInputModelChange(data ?: any): void {
        if (data) {
            this.checkChild(data);
        }
        const changedData: any[] = this.cmtsFeatureService.getChangedData(this.defaultFeature, this.serverDefaultFeature);
        this.overrideFeature.emit(changedData);
    }

    private checkChild(data: any): void {
        if (data.subFeatures) {
            data.subFeatures.forEach((subFeature: any) => {
                if (!data.feature.enabled) {
                    subFeature.feature.enabled = false;
                }
                subFeature.feature['disableInput'] = !data.feature.enabled;
            });
        }
    }

}
