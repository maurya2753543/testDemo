/*
 * Copyright (c) 2022 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

/**
 * Created by Mehjabeen.Bari on 6/9/2017.
 */

import { Injectable } from '@angular/core';
import { PATHTRAK_PATH } from "../../constant/app.constants";
import { SharedService } from "../../shared/shared.service";

@Injectable()
export class CMTSUrlService {

    private host:string = "";

    constructor(private sharedService: SharedService) {
        this.setHost();
    }
    
    private setHost(): void{
        this.host = this.sharedService.getHost();
    }

    private getHost() : string{
        return this.host + PATHTRAK_PATH;
    }

    // returns url to get rpm tab data
    public getRPMEventListUrl(elementId: number, type):string {
        return this.getHost() + "event/element/type/" + type+ "/id/" + elementId ;
    }

    /* Return url to get node list from server*/
    public getNodeListUrl(): string {
        return this.getHost() + "node";
    }

    public getDeleteNodeUrl(id: number): string{
        return this.getHost() + "node/" + id;
    }

    /* Return url to get modem list from server*/
    public getModemListUrl(): string {
        return this.getHost() + "modem/summary";
    }

    /* Return url to get exported modem from server*/
    public getExportGeocodeModemUrl():string {
        return this.host +"/pathtrak/api/modems/geocode/failed";
    }

    public getNodeMappingByIDUrl():string {
        return this.host + "/pathtrak/diagnosticview/index.html#/mapper/nodedetails?id=";
    }

    public getNoiseTrakMappingByIDUrl():string {
        return this.host + "/pathtrak/diagnosticview/index.html#/noisetrak?nodeId=";
    }

    public getThresholdLabelsUrl():string {
        return this.getHost() + 'settings/thresholds';
    }

    /* Return url toperform geocoding from server*/
    public getPerformGeocodeModemUrl():string {
        return this.host +"/pathtrak/api/modems/geocode/restart";
    }

    /* Return url to get cmts list from server */
    public getCMTSListUrl(): string {
        return this.getHost() + "cmts";
    }

    public getCustomModemFieldsUrl(): string {
        return this.getHost() + "settings/modemCustomFields";
    }

    public getSweepConfig(id: number): string {
        return this.getHost() + "cmts/" + id + "/sweep/config";
    }

    public getValidateCMTSConfigUrl(id: number): string {
        return this.getHost() + "cmts/" + id + "/sweep/validate";
    }

    /* Return url to get cmts list from server */
    public getCMTSFeaturesUrl(): string {
        return this.getHost() + "cmts/features";
    }

    public topologyExportFieldsUrl(): string {
        return this.getHost() + "topology/import/topologyConfig";
    }

    public noisetrakExportUrl(): string {
        return this.getHost() + "noiseTrakImport/csvParserConfig";
    }
    
    /* Return url to add greenfield nodeto server*/
    public postAddGreenFieldNodeUrl(): string {
        return this.getHost()+ "node/greenfield";
    }

    /* Return url to add exit cmts to server*/
    public putEditCMTSUrl(cmtsId: number): string {
        return this.getHost() + "cmts/" + cmtsId ;
    }

    /* Return url to delete cmts from server*/
    public deleteCMTSUrl(cmtsId: number): string {
        return this.getHost() + "cmts/" + cmtsId ;
    }

    /* Return url to add cmts to server*/
    public addCMTSUrl(): string {
        return this.getHost() + "cmts";
    }

    /* Return url to redirect to modem hyperlink*/
    public getRedirectModemUrl(): string {
        return this.host + "/pathtrak/diagnosticview/index.html#/modem?node=";
    }

    public getRedirectCmtsDiagnosticUrl(id: number): string {
        return this.host + "/pathtrak/diagnosticview/index.html#/cmts?id=" + id;
    }

    /* Return url to sync all cmts from server*/
    public getSyncAllCmtsUrl(): string {
        return this.getHost() + "trigger/cmts/sync";
    }

    /* Return url to sync selected cmts from server*/
    public getSyncSelectedCmtsUrl(): string {
        return this.getHost() + "cmts/sync";
    }

    /* Return url to upload csv to server*/
    public getCSVUploadNodeUrl(): string {
        return this.host + "/pathtrak/api/topology/import/csv";
    }

    public getCSVUploadFilesUrl(): string {
        return this.host + "/pathtrak/api/topology/import/csvAndConfig";
    }

    public getNoisetrakCSVUploadFilesUrl(): string {
        return this.host + "/pathtrak/api/noiseTrakImport/csvCustomParser";
    }    
    
    /* Return url to upload csv to server */
    public  getCSVUploadCmtsUrl(): string {
        return this.host + "/pathtrak/api/cmts/import/csv";
    }

    public getRedirectAnalysisUrl(element: string, id: number): string {
        if(id == 0 || id == null){
            return;
        }
        return this.host.concat('/pathtrak/xpt/analysis/', element,'/',id.toString());
    }

    public getAlarmableModemsUrl(): string {
        return this.getHost() + "modem/alarmableModems";
    }

    public getAddAlarmableModemsUrl(modemId: any, expirationDuration: any): string {
        return this.getHost() + "modem/alarmableModems/add1?modemId=" + modemId.toString() + "&expirationDays=" + expirationDuration.toString() + "&action=UI";
    }

    public getDeleteAlarmableModemsUrl(): string {
        return this.getHost() + "modem/alarmableModems/delete";
    }

	public getRemainingAlarmableModemsUrl(): string {
        return this.getHost() + "modem/alarmableModems/addable";
	}

	public getUpdateAlarmableModemUrl(modemId: number, expiration: string): string {
        let url = this.getHost() + "modem/alarmableModems/edit?modemId=" + modemId + "&additionalExpirationDays=" + expiration;
		return this.getHost() + "modem/alarmableModems/edit?modemId=" + modemId + "&additionalExpirationDays=" + expiration;
    }
    
    public getModemUrl(modemId:number ): string {
        return this.getHost() + "modemFields/modem/" + modemId;
    }

    public getCmtsDeviceThreshold(): string{
        return this.getHost() + "deviceSettings/cmts";
    }

    public getdeleteMACTrakThresholdUrl(): string{
        return this.getHost() + "deviceSettings/reset/";
    }

    public updateMACTrakBulkThresholdUrl(): any{
        return this.getHost() + "deviceSettings/bulkUpdate/"; 
    }
    
    public getOSInfoUrl(): any{
        return this.getHost() + "osinfo";
    }
}
