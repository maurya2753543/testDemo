import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { OltTabModel } from './olt-tab/olt-tab.model';

@Injectable({
  providedIn: 'root'
})
export class OltTabSharedService {

  public oltFiltermodel;
  private oltTabModelData:OltTabModel;
  public oltTabModelDataChange = new Subject();
  private oltPortTabFormChangeSubject: Subject<any>;
  private oltPortListRefreshSubject: Subject<any>;
  private nameFilterText: string;
  public sideNavClose = new Subject()
  public oltmodeldatachange: any;
  constructor() { 
    this.nameFilterText = "";
    this.initSubjects();
  }
  public getNameFilterText(): string{
    return this.nameFilterText;
  }

  public setNameFilterText(nameFilterText: string): void{
      this.nameFilterText = nameFilterText;
  }


  public  getOltTabModelData(){
    return this.oltTabModelData
  }

  public setOltTabModelData(data:OltTabModel){
    this.oltTabModelData = data;
    this.oltTabModelDataChange.next(this.oltTabModelData)
  }

  public getSelectedRowsOLTIds(cmtsModels: OltTabModel[], selectedRowsCmtsId: number[]): void{
    cmtsModels.forEach((cmtsModel: OltTabModel)=>{
        selectedRowsCmtsId.push(cmtsModel.elementId);
    });
}

  public getOltPortListRefreshSubject(): Subject<any>{
      return this.oltPortListRefreshSubject;
  }

  private initSubjects(): void{
      this.oltPortTabFormChangeSubject = new Subject();
      this.oltPortListRefreshSubject = new Subject();
  }
}

