import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { NavService } from 'src/app/shared/nav.service';
import { SharedService } from 'src/app/shared/shared.service';
import {OLT_MODULE} from "../../constant/app.constants";
import { OltPortTabComponent } from './olt-port-tab/olt-port-tab.component';
import { OltSummaryTabComponent } from './olt-summary-tab/olt-summary-tab.component';
import { OltTabComponent } from './olt-tab/olt-tab.component';
import { OltService } from './olt.service';
import {StatusFilter} from "../../shared/status.filter";
import { LocaleDataService } from 'src/app/shared/locale.data.service';
import { OltTabSharedService } from './olt-tab-shared.service';




@Component({
  selector: 'app-olt',
  templateUrl: './olt.component.html',
  styleUrls: ['./olt.component.scss']
})
export class OltComponent implements OnDestroy {
  public selectedTab : string;
  public loadComponent:boolean;

  constructor(
    public navService: NavService,
    private sharedService:SharedService,
    public translate : TranslateService,
    public localeDataService:LocaleDataService,
    private oltService : OltService,
    private oltTabSharedService: OltTabSharedService
  ) { 
    let module = OLT_MODULE;
    this.localeDataService.initLanguage(module);
    //this.oltService.OSInfoStatus();
  }

  ngOnInit(): void {
    if(this.sharedService.getRedirectTAB()) {
      this.getTranslated(this.sharedService.getRedirectTAB(), true);
      if(this.oltService.getTab() && this.sharedService.getRedirectTAB()){
          this.LoadTab(this.sharedService.getRedirectTAB())
          this.sharedService.setRedirectTAB('');
      }
    }else {
      if(this.oltService.getTab()){
          this.translateLocaleString();
          this.selectedTab = 'olt';
      } else {
          this.getTranslated('olt', false);
      }
    }
  }

  getTranslated(tabValue: string, bool?: boolean){
    this.translate.onLangChange.subscribe(lang => {
        this.translateLocaleString();
        this.LoadTab(tabValue);
        this.oltService.setTab(tabValue);
    })
  }

  LoadTab(tabName : string): void{
    let selectedTab = this.sharedService.getRedirectTAB();
    this.selectedTab = tabName.toLowerCase();
    if (selectedTab && selectedTab.length > 0) {
        this.selectedTab = selectedTab;
        this.sharedService.setRedirectTAB("");
    }
    
  }

  private translateLocaleString(): void {
     let localizationService = this.localeDataService.getLocalizationService();

    StatusFilter.setSeverity(
        {
            default: this.translate.instant('DEFAULT'),
            online: this.translate.instant('ONLINE'),
            offline: this.translate.instant('OFFLINE'),
            busy: this.translate.instant('BUSY'),
            error: this.translate.instant('ERROR'),
            disabled: this.translate.instant('DISABLED'),
            unavailable: this.translate.instant('UNAVAILABLE')
        }
    );
    StatusFilter.setCMTSVisibility(false);
    StatusFilter.setRCIVisibility(false);
}

ngOnDestroy(): void {
    this.oltTabSharedService.oltmodeldatachange = null;
}

}
