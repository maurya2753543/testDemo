import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OltSummaryTabComponent } from './olt-summary-tab.component';

describe('OltSummaryTabComponent', () => {
  let component: OltSummaryTabComponent;
  let fixture: ComponentFixture<OltSummaryTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OltSummaryTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OltSummaryTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
