import { Component, OnInit } from '@angular/core';
import {Grid} from "../../../shared/ag-grid.options";

import { ViewChild, ComponentFactoryResolver, ViewContainerRef, OnDestroy} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Logger} from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {ADD_OPERATION} from "../../olt/olt-tab.constants";
import {LocaleDataService} from "../../../shared/locale.data.service";
import * as cstmConstants from "../../olt/olt-tab.constants";
import {Subject} from 'rxjs/';
import {takeUntil} from 'rxjs/operators';
import {SharedService} from "../../../shared/shared.service";
import {StatusFilter} from "../../../shared/status.filter";
import { SweetAlert } from '../../../utilities/sweetAlert';
import { ALERT_INFO } from '../../../constant/app.constants';
import { CommonStrings } from '../../../constant/common.strings';
import { OLTUrlService } from '../olt.url.service';
import { OLTHttpService } from '../olt.http.service';
import { OltTabSharedService } from '../olt-tab-shared.service';
import { SummaryTabColumnDefinitionService } from './olt-summary.column-definition.service';
import { OltSummaryTabModel } from './olt-summary-tab.model';
import { OltSummryTabService } from './olt-summary-tab.service';
import { NO_FAILED_MODEMS } from "../../../constant/app.constants";
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

let vm;

function isExternalFilterPresent() {
    return vm.showSelected;
}

function doesExternalFilterPass(node) {
    return node.data.status.toUpperCase() === vm.currentFilter.toUpperCase();
}

@Component({
  selector: 'app-olt-summary-tab',
  templateUrl: './olt-summary-tab.component.html',
  styleUrls: ['./olt-summary-tab.component.scss']
})
export class OltSummaryTabComponent implements OnInit {

  public eventKeys: Object[];
  public viewData: boolean = false;

  public oltSummaryTabGridOptions: Grid = new Grid();
  public oltSummaryTabGridRowData: any;
  public oltfilterchangeData: any;

  private selectedRowsOltId: number[] = [];
  private nameFilterInstance: any;
  public buttonKeys: Object[];
  private OLT_TAB_BTN: string = "";
  private OLT_DIAGNOSTIC_BTN: string = "";
  private EVENTS: string;

  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public gridTabType: string = "ONTExport";
  public showAllLabel: string = '';
  public showAllLabelMob: string = '';
  private CMTS_MODEM_BTN_EXPORT_GEOCODE: string = "";
  private CMTS_MODEM_BTN_PERFORM_GEOCODING: string = "";
  private PORT_TAB_EXPORT_SELECTED: string = "";
  private PORT_TAB_EXPORT_ALL:string = "";
  private TABLE_LIST_EXPORT_SELECTED: string = "";
  private TABLE_LIST_EXPORT_ALL: string = "";
  private NO_FAILED_MODEMS: string = "";
  private GEOCODING_INITIATED: string = "";
  public enableImportOlt: boolean = false;
  public enableImportCmtsSlider: boolean = false;
  public enableImportNoisetrakSlider: boolean = false;
  public openNdfNdrSliderData: any = null;
  private TABLE_LIST_SHOWING:string = '';
  private TABLE_LIST_SHOWING_OF:string = '';
  private TABLE_LIST_ROWS:string = "";
  private totalCount:number;

  private oltSummaryTabModel: OltSummaryTabModel;

  constructor(
    private showAlert: ShowAlert,
    private logger: Logger,
    private componentFactoryResolver: ComponentFactoryResolver,
    private localeDataService: LocaleDataService,
    private sharedService: SharedService,
    private viewContainerRef: ViewContainerRef,
    private sweetAlert: SweetAlert,
    private oltUrlService:OLTUrlService,
    private oltHttpService:OLTHttpService,
    private oltTabSharedService: OltTabSharedService,
    private summaryTabColumnDefinitionService: SummaryTabColumnDefinitionService,
    private oltSummryTabService:OltSummryTabService,
  ) { 
    vm = this;
    this.localeDataService.componentCallback.subscribe((response) => {
        this.translateLocaleString();
        this.setEventButtonKeys();
});
  }

  ngOnInit(): void {
    this.translateLocaleString();
    this.setEventButtonKeys();
    //this.initAllSubjectListener();
    if(this.sharedService.RetainFilter){
        this.oltSummryTabService.oltsummmodeldata = "";
        this.oltTabSharedService.oltmodeldatachange = "";
    }
  }

      /*
     *@name SummaryOLTevents
     *@desc Events related to Summary tab (OLT).
     *@return void
     */
     public notifyActionEmitter($event) {
        switch($event.event.name) {
            case this.CMTS_MODEM_BTN_EXPORT_GEOCODE:
                this.notifyExportGeocodeONT();
                break;
            case this.CMTS_MODEM_BTN_PERFORM_GEOCODING:
                this.notifyPerformGeocodeONT();
                break;
            default:

        }
    }


    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.oltSummaryTabGridOptions.api.setColumnDefs(this.summaryTabColumnDefinitionService.getColumnDef());
        this.nameFilterInstance = this.oltSummaryTabGridOptions.api.getFilterInstance('name');
        this.getOltPortListFromAPI();
    }


    public getOltPortListFromAPI(){ 
        this.oltHttpService.getOltSummaryTabData().pipe(takeUntil(this.ngUnsubscribe)).subscribe((data:OltSummaryTabModel)=>{
        this.oltSummaryTabGridRowData = data;
        if(this.oltSummaryTabGridOptions.api && (this.oltSummryTabService.oltsummmodeldata || this.oltTabSharedService.oltmodeldatachange)){
            this.oltSummaryTabGridOptions.api.setFilterModel(this.oltSummryTabService.oltsummmodeldata);
            console.log("olt filter executed");
            if(this.oltSummryTabService.oltsummmodeldata || this.oltTabSharedService.oltmodeldatachange){
                const countryFilterComponent3 = this.oltSummaryTabGridOptions.api.getFilterInstance("vendor");
                countryFilterComponent3.setModel(this.oltTabSharedService.oltmodeldatachange);
            }
                }   
            },err=>{
                this.oltSummaryTabGridRowData = []
                this.showAlert.showErrorAlert(err);
        })
             
    }
  
  
        //Grid Ready Event
        public notifyGridReadyOLTPort(): void {
        this.setGridColumnDefinition();
    }
    public notifyFilterChange(event){
        this.sharedService.RetainFilter = false;
        this.oltSummryTabService.oltsummmodeldata = this.oltSummaryTabGridOptions.api.getFilterModel();
        const countryFilterComponent = this.oltSummaryTabGridOptions.api.getFilterInstance('vendor');
        const model = countryFilterComponent.getModel();
        this.oltTabSharedService.oltmodeldatachange = model;
    }
    //Init all subject listener
    private initAllSubjectListener(): void {
        this.oltPortListRefreshSubjectListener();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.oltSummaryTabGridOptions.api.showLoadingOverlay();
    }


   //Method to refresh ag-Grid
    private oltPortListRefreshSubjectListener(): void {
        this.oltTabSharedService
        .getOltPortListRefreshSubject()
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe((isHardReset: boolean) => {
            if (isHardReset) {
                this.clearGridData();
                ////this.getCmtsListFromAPI();
            }
        });
    }
    

    //clear existing selection of ag-Grid
    private clearGridData(): void {
        this.storeSelection();
        this.oltSummaryTabGridOptions.api.setRowData([]);
        this.oltSummaryTabGridRowData = [];
    }

        //Store existing selection of ag-Grid
        private storeSelection(): number[] {
          this.selectedRowsOltId.length = 0;
          this.oltSummryTabService.getSelectedRowsOltIds(this.oltSummaryTabGridOptions.api.getSelectedRows(), this.selectedRowsOltId);
          return this.selectedRowsOltId;
      }

    /*method to set standalone button keys*/
      private setEventButtonKeys():void {
        this.buttonKeys = [
            {name: this.CMTS_MODEM_BTN_EXPORT_GEOCODE, tabType: cstmConstants.SUMMARY_CONTS},
            {name: this.CMTS_MODEM_BTN_PERFORM_GEOCODING, tabType: cstmConstants.SUMMARY_CONTS}
        ];
        this.eventKeys = [
        //   {name: this.PORT_TAB_EXPORT_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.SUMMARY_CONTS},
       
        {
            name: this.TABLE_LIST_EXPORT_SELECTED,
            status: cstmConstants.SINGLE_CONTS,
            tabType: cstmConstants.OLT_CONTS
        },
        {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS}
        // {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS}
        ];
      }
   
    //Method to apply filter on ag-Grid
    private applyNameFilter(filterValue: string): void {
        // this.nameFilterInstance.setFilter(filterValue);
        // this.nameFilterInstance.onFilterChanged();
    }

    //Method to get filter text
    // private getNameFilterText(): string {
    //     let filterText: string = "";
    //     let filterModel: any = this.nameFilterInstance.getModel();
    //     if (filterModel) {
    //         filterText = filterModel.filter;
    //     }
    //     return filterText;
    // }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount): void {
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

      //updates row message.
      public modelUpdatedEmitter(e: any): void {
        let rowCount = this.oltSummaryTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //Handle error
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }


    ngOnDestroy() {
        this.sharedService.setFilterForTAB('');
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    public notifyRefreshGrid(event) {
        this.getOltPortListFromAPI();
    }


    private notifyPerformGeocodeONT():void{
        this.oltSummryTabService.getPerformGeocodeONT().subscribe(this.onPerformGeocodeNext.bind(this), this.onError.bind(this));
    }
    
    private notifyExportGeocodeONT():void{
        this.oltSummryTabService.getExportGeocodeONT().subscribe(this.notifyExportGeocodeNext.bind(this), this.onError.bind(this));
    }
    /* On gettting geocode from server */
    private onPerformGeocodeNext(data):void {
        this.showAlert.showSuccessAlert(this.GEOCODING_INITIATED);
    }

    
    /*check if data is null or json data*/
    private notifyExportGeocodeNext(data):void{
        if(data.length == 0){
            this.showAlert.showInfoAlert(this.NO_FAILED_MODEMS);
        }
        else {
            this.exportToCsv(data);
        }
    }

        /*export json data in csv format */
        private exportToCsv(data):void{
            let options: any = {
                fieldSeparator: ',',
                quoteStrings: '"',
                decimalseparator: '.',
                showLabels: true
            };
            new Angular2Csv(data, 'export', options);
        }
    
    //Translation
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.EVENTS = localizationService.instant('EVENTS');
        this.OLT_DIAGNOSTIC_BTN = localizationService.instant('OLT_DIAGNOSTIC_BTN');
        this.PORT_TAB_EXPORT_ALL = localizationService.instant('PORT_TAB_EXPORT_ALL');
        this.PORT_TAB_EXPORT_SELECTED = localizationService.instant('PORT_TAB_EXPORT_SELECTED');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CMTS_MODEM_BTN_EXPORT_GEOCODE = localizationService.instant('CMTS_MODEM_BTN_EXPORT_GEOCODE');
        this.CMTS_MODEM_BTN_PERFORM_GEOCODING = localizationService.instant('CMTS_MODEM_BTN_PERFORM_GEOCODING');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.NO_FAILED_MODEMS = localizationService.instant('NO_FAILED_MODEMS');
        this.GEOCODING_INITIATED =  localizationService.instant('GEOCODING_INITIATED');

    
    }


}
