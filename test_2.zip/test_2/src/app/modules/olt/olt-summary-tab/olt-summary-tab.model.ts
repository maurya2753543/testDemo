/**
 * Created by Vasya Krishnkant.
 */

export class OltSummaryTabModel{
    public oltsId: number;
    public name: string;
    public hostname: string;
    public proxyHostname: string;
    public snmpCommunityString: string;
    public snmpWriteCommunityString: string;
    public docsisVersion: number;
    public manufacture: string;
    public status: string;
    public description: string;
    public upstreamCount: number;
    public modemCount: number;
    public nodeCount: number;
    public accessed: string;
    public container: string;
    public containerId: string;
    public containerPath: string;
    public site: string;
    public siteId: string;
    public config: Object;
    public mactrakFailThreshold: number;
    public mactrakMarginalThreshold: number;
    public rciMonRateDelay: number;
    public rciMonRateControl: number;
    public rciMonRatePercent: number;
    public rci: string;

    constructor(localizationService: any){
    }
}