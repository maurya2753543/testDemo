/**
 * Created by Vatsya Krishnkant on 10/26/2022.
 */
import {Injectable} from "@angular/core";
import {OltSummaryTabModel} from "./olt-summary-tab.model";
import { Observable, throwError} from "rxjs";
import { OLTUrlService } from "../olt.url.service";
import { map ,catchError} from 'rxjs/operators';
import { OLTHttpService } from "../olt.http.service";

@Injectable()
export class OltSummryTabService{
     public oltsummmodeldata: any;

     constructor(private oltUrlService: OLTUrlService,
        private oltHttpService: OLTHttpService) {}
    //Method to get selected rows from grid
    public getSelectedRowsOltIds(oltModels: OltSummaryTabModel[], selectedRowsOltId: number[]): void{
            oltModels.forEach((oltModels: OltSummaryTabModel)=>{
                selectedRowsOltId.push(oltModels.oltsId);
            });
        }

        //Method to restore grid selection
        public restoreSelection(selectedRowsOltId: number[], oltPortTabGridOptionsAPI: any): void{
            if(selectedRowsOltId.length >= 1){
                oltPortTabGridOptionsAPI.forEachNode((node)=>{
                    for(let i = 0; i < selectedRowsOltId.length; i ++){
                        if (node.data.oltsId === selectedRowsOltId[i]) {
                            node.setSelected(true);
                            break;
                        }// End of if
                    }// End of For
                });// End of forEachNode
            }// End of If
        }

        
    /*Method to perform geocode Modem from server*/
    public getPerformGeocodeONT(): Observable<any> {
        return this.oltHttpService
            .getPerformGeocodeONTData()
            .pipe(
                map((res) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    /*Method to getExported geocode Modem from server*/
    public getExportGeocodeONT(): Observable<any> {
        return this.oltHttpService
            .getExportGeocodeONTData()
            .pipe(
                map((res) => {
                    return res;
                }),catchError(this.handleError)
            )
    }

    public handleError(error) {
        return throwError(error);
    }
 }
