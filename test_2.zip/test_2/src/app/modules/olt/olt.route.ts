
import { Routes, RouterModule } from '@angular/router';
import {OltComponent} from "./olt.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: OltComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class OltRoutes{}
