import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import {LocaleDataService} from "../../shared/locale.data.service";
import { ThresholdService } from '../shared/threshold.service';
//import { OLTHttpService } from './olt.http.service';
//import { OLTUrlService } from './olt.url.service';

@Injectable({
  providedIn: 'root'
})
export class OltService {
  private selectedTab: string;
  private localService:any;

  constructor(
    private localeDataService:LocaleDataService,
    //private oltUrlService:OLTUrlService,
    private thresholdService: ThresholdService,
    //private oltHttpService: OLTHttpService
  ) {
    this.localService = this.localeDataService.getLocalizationService();
   }

  getTab(){
    return this.selectedTab;
  }

  setTab(value: string){
      this.selectedTab = value;
  }
  
      //Error handler
    public handleError(error) {
        return throwError(error);
    }
}
