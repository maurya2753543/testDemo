/**
 * Created by yogesh.paisode on 6/8/2017.
 */

export class OltTabModel{
    public elementId: number;
    public name: string;
    public hostname: string;
    public vendor: string;
    public description: string;
    public status: number;
    public readCommunityString: string;
    public writeCommunityString: string;
    public defaultContainerId: number;
    public portCount: number;
    public ontCount: number;
    public containerPath:string
    public defaultContainerName:string;
    public siteName:string;
    public accessed: string;
    public siteId: string;
    public config: {syncEnabled:boolean,timeoutMillis:number};
    constructor(oltData,localizationService: any){
        this.elementId = oltData.elementId
        this.name = oltData.name
        this.hostname = oltData.hostname
        this.vendor = oltData.vendor
        this.description = oltData.description
        this.readCommunityString = oltData.readCommunityString
        this.writeCommunityString = oltData.writeCommunityString
        this.defaultContainerId = oltData.defaultContainerId
        this.portCount = oltData.portCount
        this.ontCount = oltData.ontCount
        this.accessed = oltData.accessed
        this.siteName = oltData.siteName;
        this.siteId = oltData.siteId;
        this.config = oltData.config
        this.defaultContainerName = oltData.containerName;
        this.containerPath = oltData.containerPath
    }
}

export class testConnectionModel {
    public hostname: string;
    public port:number
    public readCommunity:string
    public writeCommunity:string
    public snmpVersion:string

    constructor(dataModel){
        this.hostname = dataModel.hostname
        this.port = dataModel.port
        this.readCommunity = dataModel.readCommunityString
        this.writeCommunity = dataModel.writeCommunityString
        this.snmpVersion = dataModel.snmpVersion
    }
}