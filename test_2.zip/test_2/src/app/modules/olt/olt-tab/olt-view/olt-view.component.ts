import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { OltTabModel,testConnectionModel } from '../olt-tab.model';
import { ContainerDataService } from './../../../container/container.data.service';
import { ContainersSelect } from './../../../shared/dropdown/models/containersSelect.model';
import {map, catchError} from "rxjs/operators";
import {SiteListDataService} from '../../../sites/site-list/site-list.data.service';
import { SitesSelect } from './../../../shared/dropdown/models/sitesSelect.model';
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {
  ALERT_INFO, MAX_STRING_LIMIT,
} from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {ADD_OPERATION, 
  EDIT_OPERATION, 
  OLT_CONTAINER, 
  OLT_SITE, 
  FIRST_SELECT_OPTION
} from "../../olt-tab.constants";
import { OLTHttpService } from '../../olt.http.service';
import {ShowAlert} from "../../../../utilities/showAlert";
// import {ConnectionStatus} from '../../olt-tab-shared.service'
import {OltTabSharedService} from '../../olt-tab-shared.service'
import { LocaleDataService } from 'src/app/shared/locale.data.service';
@Component({
  selector: 'app-olt-view',
  templateUrl: './olt-view.component.html',
  styleUrls: ['./olt-view.component.scss']
})

export class OltViewComponent implements OnInit {
  currentLang: string = '';
  constructor(private fb :  FormBuilder,
   private containerDataService: ContainerDataService,
   private siteListDataService:SiteListDataService,
   private oltHttpService:OLTHttpService,
   private showAlert: ShowAlert,
   private sweetAlert:SweetAlert,
   private localeDataService: LocaleDataService,
   private oltSharedService:OltTabSharedService) { }

  public oltForm;
  public isCloseRightSlider:boolean;
  public isReadOnly=false
  public dataModel: OltTabModel;
  public containerOptions:any;
  public siteOptions:any;
  public saveDisabled=true;
  private REMOVE_OLT:string = "";
  private OLT_TAB_REMOVE_OLT_STRING:string = '';
  public testDisabled = false
  public errorMessages: any = {
    isHostNameEmpty: false,
    isNameEmpty: false,
    isSnmpReadOnlyEmpty: false,
    isSnmpReadWriteEmpty: false,
    isContainerEmpty: false,

    rciMonRateDelayEmpty: false,
    rciMonRatePercentEmpty: false
}
public defaultContainer = FIRST_SELECT_OPTION + OLT_CONTAINER;
public defaultSite = FIRST_SELECT_OPTION + OLT_SITE;
public connectionEstablished = false;
public isAddMode=false;
public defaultTimeoutInMillis = 1000

  ngOnInit(): void {
    if(!this.dataModel){
      this.dataModel = new OltTabModel({
        elementId:null,
        name :null,
        hostname : null,
        vendor : null,
        description :null,
        readCommunityString : null,
        writeCommunityString : null,
        defaultContainerId : null,
        portCount : null,
        ontCount :null,
        accessed :null,
        siteName : null,
        siteId : null,
        config : {syncEnabled:true, timeoutMillis : this.defaultTimeoutInMillis},
        defaultContainerName : null,
        containerPath : null
      },null)
    }
    this.isCloseRightSlider = false
    this.generateForm();
    this.translateLocaleString();
    this.containerDataService.getNodeOnlyContainers()
            .pipe(map((json) => {
                return new ContainersSelect(json);
            }))
            .subscribe(this.setContainerOptions.bind(this));
    this.siteListDataService.getSiteList(true,'HARDWARE')
            .pipe(map((json) => {
                return new SitesSelect(json);
            }))
            .subscribe(this.setSiteOptions.bind(this));

  }


// generate a reactive form for OLT
private generateForm(){
  this.oltForm = this.fb.group({
    hostname: new FormControl('',Validators.required),
    readCommunityString: new FormControl('',Validators.required),
    writeCommunityString: new FormControl('',Validators.required),
    name: new FormControl('',Validators.required),
    siteName: new FormControl(''),
    containerName: new FormControl(''),
    timeoutMillis : new FormControl(this.defaultTimeoutInMillis,[Validators.min(1),Validators.required])
  })
  if(!this.isAddMode){
    this.getContainerPath()
  }
}

private getContainerPath(){
  this.oltHttpService.getContainerPath(this.dataModel.defaultContainerId).subscribe((res : {id:number,containerPath:string})=>{
    this.dataModel.containerPath = res.containerPath
  },err=>{
    this.showAlert.showErrorAlert(err);
  })
}

private setContainerOptions(data: any): void {
  this.containerOptions = data;
}

private setSiteOptions(data: any): void {
  this.siteOptions = data;
}

public modelChange(event){
  this.testDisabled = false
}

// Close the the right slider
  public btnClose_click(){
    this.isCloseRightSlider = true
    this.oltSharedService.sideNavClose.next(true)
  }

  //Sbmit the form
  public onSubmit(){
    let payload = {
      "elementId":this.dataModel.elementId,
      "name": this.dataModel.name,
      "hostname": this.dataModel.hostname,
      "readCommunityString": this.dataModel.readCommunityString,
      "writeCommunityString": this.dataModel.writeCommunityString,
      "defaultContainerId": this.dataModel.defaultContainerId,
      "siteId": this.dataModel.siteId,
      "config": this.dataModel.config
    };
    if(this.isAddMode){
      this.oltHttpService.postAddOlt(payload).subscribe(res=>{
        this.oltForm.reset();
        this.btnClose_click()
      },err=>{
        this.showAlert.showErrorAlert(err);
      })
    }else{
      this.oltHttpService.putEditOlt(payload).subscribe(res=>{
        this.oltForm.reset();
        this.btnClose_click()
      },err=>{
        this.showAlert.showErrorAlert(err);
      })
    }
  }


  public getContainerSelection(dropdownItem) : void {
    if (dropdownItem.value !== "null") {
      this.dataModel.containerPath = dropdownItem.innerText;
      this.dataModel.defaultContainerId = dropdownItem.value;
      this.saveDisabled = false
    }else{
      this.dataModel.containerPath = null
      this.dataModel.defaultContainerId = null
      this.saveDisabled = true
    }
}

public getSiteSelection(dropdownItem) : void {
    if (dropdownItem.value === "-1") {
        this.dataModel.siteName = null;
        this.dataModel.siteId = null;
    }
    else {
        this.dataModel.siteName = dropdownItem.innerText;
        this.dataModel.siteId = dropdownItem.value;
    }
    if(this.oltForm.status.toLowerCase().trim() === 'valid' && this.dataModel.defaultContainerId){
      this.saveDisabled = false
    }
}
   
public testConnection(){
  let testConnection = new testConnectionModel(this.dataModel);
  testConnection.port = 161;
  testConnection.snmpVersion = 'v2c'
  this.oltHttpService.testConnection(testConnection).subscribe(succ=>{
    this.connectionEstablished = true
  },err=>{
    this.connectionEstablished = false
    this.showAlert.showErrorAlert(err);
  })
  // this.connectionEstablished = true
}

public deleteData(){
  let status = this.showAlert.showAlertConfirm();
  this.sweetAlert.showConformationAlert(ALERT_INFO ,this.REMOVE_OLT ,this.OLT_TAB_REMOVE_OLT_STRING ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,(isConfirm)=>{
        if (isConfirm) {   
              this.oltHttpService.deleteOlt(this.dataModel.elementId).subscribe(res=>{
                this.oltForm.reset();
                this.btnClose_click();
              },err=>{
              this.showAlert.showErrorAlert(err);
            });
        }    
      }
  );  
  
}

public editModeEnable(){
 
  this.isReadOnly = false
  // this.isAddMode=true;
  this.saveDisabled = true
  this.oltForm.valueChanges.subscribe(val=>{
    this.saveDisabled = false
  })
}

public syncChange(){
  this.dataModel.config.syncEnabled = !this.dataModel.config.syncEnabled;
  this.saveDisabled = false
}

 //Translation
 private translateLocaleString():void{
  let localizationService = this.localeDataService.getLocalizationService();
  this.OLT_TAB_REMOVE_OLT_STRING = localizationService.instant('OLT_TAB_REMOVE_OLT_STRING');
  this.REMOVE_OLT = localizationService.instant('REMOVE_OLT');
  this.currentLang = localizationService.getBrowserLang();
}


}
