
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import * as FileSaver from 'file-saver';
import * as AppConstants from '../../../../constant/app.constants';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SharedService} from "../../../../shared/shared.service";
import {UrlService} from "../../../../shared/url.service";
import {Logger} from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
// import {CmtsTabDataService} from "../cmts-tab.data.service";
import {ALERT_ERROR} from "../../../../constant/app.constants";
import { Observable } from 'rxjs';
import { OLTHttpService } from '../../olt.http.service';
import { ControlMessagesService } from 'src/app/shared/control.messages.service';

@Component({
  selector: 'app-import-billing',
  templateUrl: './import-billing.component.html',
  styleUrls: ['./import-billing.component.scss']
})
export class ImportBillingComponent implements OnInit {
  public closeSlider: boolean = false
  
  private isValidCSVFile: boolean = false;
  private isValidTxtFile: boolean = false;
  public form: FormGroup;
  private tag: string = "ImportModemComponent ::";
  private IMPORT_MODEM_SUCCESS: string = '';
  private IMPORT_TOPOLOGY_ERROR: string = '';
  private IMPORT_FILE_OTHER_THAN_JSON_INVALID: string = '';
  private IMPORT_FILE_INVALID: string = '';
  private IMPORT_MODEM_ERROR: string = '';
  private EMPTY_CSV_ERROR: string;
  private VALIDATION_SUCCESSFUL: string = '';
private INVALID_CONFIGURATION:string = '';
  private customFields: any[];

  constructor(private urlService: UrlService,
              // private cmtsTabDataService: CmtsTabDataService,
              private fb: FormBuilder,
              private logger: Logger, private showAlert: ShowAlert,
              private sharedService: SharedService,
              private localeDataService: LocaleDataService,
              private oltHttpService: OLTHttpService,
              private controlMessagesService:ControlMessagesService) {
  }

  private buildForm(): FormGroup {
      return this.fb.group(this.getFormProperties());
  }

  private getFormProperties(): any {
      const formatProperties: any = {
          csvFile: this.fb.control(null, Validators.required),
          importConfig: this.fb.control(null, Validators.required), 
          header: this.fb.control(true),
      };
      return formatProperties;
  }


  // Form Properties
  private get csvFile() {
      return this.form.get('csvFile');
  }

  private get importConfig() {
      return this.form.get('importConfig');
  }

  private get header() {
      return this.form.get('header');
  }

  ngOnInit() {
      this.form = this.buildForm();
      this.translateLocaleString();
  }

  fileChangeText(event: any): void {
      const target: any = event.target;
      this.isValidTxtFile = target.value.endsWith('.json');
      if (this.isValidTxtFile) {
          let files: any = target.files;
          if (files.length) {
              this.importConfig.setValue(files[0]);
          }
      } else {
          this.showAlert.showSuccessAlert(this.IMPORT_FILE_OTHER_THAN_JSON_INVALID, true, ALERT_ERROR);
      }
  }

  fileChangeCSV(event: any): void {
      const target: any = event.target;
      this.isValidCSVFile = target.value.endsWith('.csv');
      if (this.isValidCSVFile) {
          let files: any = target.files;
          if (files.length) {
              this.csvFile.setValue(files[0]);
          }
      } else {
          this.showAlert.showSuccessAlert(this.IMPORT_FILE_INVALID, true, ALERT_ERROR);
      }
  }

  private topologyExport(){     
      this.oltHttpService.topologyExportFields().subscribe(this.onExportTopologySuccess.bind(this),this.onError.bind(this));
  }

  private onExportTopologySuccess(response):void{
      let exportFileData: string = JSON.stringify(response,null,"  ");        
      let file = new Blob([exportFileData], { type: 'text/text;charset=utf-8' });           
      FileSaver.saveAs(file.slice(), 'topologyConfig' +  '.json');
  }

  // Cancels out of the modem import editor without submitting the form.
  private onCancel(): void {
      this.closeSlider = true
  }

  // Add imported modems to server on submit.
  private onSubmit(): void {
      let formData = new FormData();
      formData.append('csvFile', this.csvFile.value, this.csvFile.value.name);        
      formData.append('importConfig', this.importConfig.value, this.importConfig.value.name);
      formData.append('isPersisted', this.header.value);
            
      this.oltHttpService.addCSVConfigToServer(formData, this.header.value)
      .subscribe(this.onAddNext.bind(this), this.onError.bind(this));
  }    


  // Handles successful modem import.
  private onAddNext(data: any): void {
    console.log('data..',data,'this.header..',this.header)
    if (data && data.length && data[0].errorCode == 0) {
        if(this.header.value == true){
            this.showAlert.showSuccessAlert(this.IMPORT_MODEM_SUCCESS);
            this.onCancel();
        }
        else{
            this.showAlert.showSuccessAlert(this.VALIDATION_SUCCESSFUL);
        }
    } else {
           let errorMessage: string;
           console.log('data..',data)
        if (data && data.length && data[0]['error'] !== 'EMPTY_LIST' && data[0]['error'] !== 'INVALID_CONFIGURATION') {
            errorMessage = this.IMPORT_TOPOLOGY_ERROR;
        } else {
          if(data && data.length && data[0]['error'] === 'INVALID_CONFIGURATION'){
              errorMessage = this.INVALID_CONFIGURATION
          }else{
              errorMessage = this.EMPTY_CSV_ERROR;
          }
        }

        this.showAlert.showAlertWithExportOLT(data, errorMessage);
        this.onCancel();
    }
  }


  // Handles request errors from submitting modem import.
private onError(error: any): void {
  this.logger.debug(this.tag, "onError(): error data=", error);
  this.showAlert.showErrorAlert(error);
      this.onCancel();
}

  // Sets up localization resources used by this component.
  private translateLocaleString(): void {
      let localizationService = this.localeDataService.getLocalizationService();
      this.EMPTY_CSV_ERROR = localizationService.instant('EMPTY_CSV_ERROR');
      this.IMPORT_TOPOLOGY_ERROR = localizationService.instant('IMPORT_TOPOLOGY_ERROR');
      this.IMPORT_MODEM_SUCCESS = localizationService.instant('IMPORT_MODEM_SUCCESS');
      this.VALIDATION_SUCCESSFUL = localizationService.instant('VALIDATION_SUCCESSFUL');
      this.IMPORT_FILE_INVALID = localizationService.instant('IMPORT_FILE_INVALID');
      this.IMPORT_FILE_OTHER_THAN_JSON_INVALID = localizationService.instant('IMPORT_FILE_OTHER_THAN_JSON_INVALID');
      this.IMPORT_MODEM_ERROR = localizationService.instant('IMPORT_MODEM_ERROR');
      this.INVALID_CONFIGURATION = localizationService.instant('INVALID_CONFIGURATION');
  }
 
}
