/**
 * Created by Vatsya Krishnkant.
 */
import {Injectable} from "@angular/core";

import {EDIT_ICON, EXTERNAL_LINK_ICON} from "../../../constant/app.constants";
import {Subject} from "rxjs";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {TimeFilter} from "../../../shared/time.filter";
import {StatusFilter} from "../../../shared/status.filter";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from "@ngx-translate/core";
import  {OltTabSharedService} from '../olt-tab-shared.service'
import { OLTUrlService } from "../olt.url.service";
//import * as moment from "moment/moment";

@Injectable()
export class OltTabColumnDefinitionService{

    private _HEADER_FIELDS: any = {
        name : {field: "name", name: "Name"},
        status: {field: "status",name: "Status"},
        ipAddress : {field: "hostname", name: "IP Address"},
        vendor : {field: "vendor", name: "Vendor"},
        siteName : {field: "siteName", name: "SiteName"},
        OltPortCount : {field: "portCount", name: "OLT Port Count"},
        ontCount : {field: "ontCount", name: "ONT count"},
        mappedStatus : {field: "mappedStatus", name: "Mapped Status"},
        edit : {field: "edit", name: "Edit"},
        containerName : {field: "defaultContainerName",name:"Container Name"}
    };

    constructor(private localeDataService: LocaleDataService,
        private sharedService : SharedService,
        private translate: TranslateService,
        private oltTabSharedService : OltTabSharedService,
        private urlService:OLTUrlService){
       
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.name.name = this.translate.instant('OLT_TAB_HEADER_NAME');
        this._HEADER_FIELDS.status.name = this.translate.instant('OLT_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.ipAddress.name = this.translate.instant('OLT_TAB_HEADER_HOSTNAME');
        this._HEADER_FIELDS.vendor.name = this.translate.instant('OLT_TAB_HEADER_VENDER');
        this._HEADER_FIELDS.siteName.name = this.translate.instant('OLT_TAB_HEADER_SITENAME');
        this._HEADER_FIELDS.OltPortCount.name = this.translate.instant('OLT_TAB_HEADER_OLT_PORT_COUNT');
        this._HEADER_FIELDS.ontCount.name = this.translate.instant('OLT_TAB_HEADER_ONT_COUNT');
        this._HEADER_FIELDS.mappedStatus.name = this.translate.instant('OLT_TAB_HEADER_MAPPED_STATUS'); 
        this._HEADER_FIELDS.edit.name = this.translate.instant('OLT_TAB_HEADER_EDIT');
        this._HEADER_FIELDS.containerName.name = this.translate.instant('OLT_TAB_HEADER_CONTAINER_NAME');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        this.translateLocaleStr();
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.name.name,headerTooltip: this._HEADER_FIELDS.name.name, field: this._HEADER_FIELDS.name.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.name.name, 70),
                filter: 'text',sort: 'asc',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.status.name,headerTooltip: this._HEADER_FIELDS.status.name, field: this._HEADER_FIELDS.status.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 95),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                filter: StatusFilter.ParentFilter,
                floatingFilterComponent: StatusFilter.ChildFloatingFilter
            },
            {
                headerName: this._HEADER_FIELDS.ipAddress.name,headerTooltip: this._HEADER_FIELDS.ipAddress.name, field: this._HEADER_FIELDS.ipAddress.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.ipAddress.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'},
                cellRenderer: ((param:any)=>{
                    if(!param.value || !param.data) { return "<div></div>"; }
                    let url = this.urlService.getRedirectOLTDiagnosticUrl(param.data.elementId);
                    return "<a class='cursorClass' target='_blank' href='" + url + "'>" + param.value + "</a>";
                })
            },
            {
                headerName: this._HEADER_FIELDS.vendor.name,headerTooltip: this._HEADER_FIELDS.vendor.name, field: this._HEADER_FIELDS.vendor.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.vendor.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.containerName.name,headerTooltip: this._HEADER_FIELDS.containerName.name, field: this._HEADER_FIELDS.containerName.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.containerName.name, 50),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.siteName.name,headerTooltip: this._HEADER_FIELDS.siteName.name, field: this._HEADER_FIELDS.siteName.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.siteName.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.OltPortCount.name,headerTooltip: this._HEADER_FIELDS.OltPortCount.name, field: this._HEADER_FIELDS.OltPortCount.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.OltPortCount.name, 40),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'},
                comparator: gridCustomComparator,
            },
            {
                headerName: this._HEADER_FIELDS.ontCount.name,headerTooltip: this._HEADER_FIELDS.ontCount.name, field: this._HEADER_FIELDS.ontCount.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.ontCount.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.mappedStatus.name,headerTooltip: this._HEADER_FIELDS.mappedStatus.name, field: this._HEADER_FIELDS.mappedStatus.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.mappedStatus.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true, newRowsAction: 'keep'},
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EXTERNAL_LINK_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        console.log('param',param)
                        window.open(window.location.origin + "/pathtrak/diagnosticview/index.html#/olt/mapped-status-summary?olt=" + param.data.elementId );
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            },
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                width:70, minWidth: 70, maxWidth: 150,
				pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                       this.action(param)
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }

        ]
        return columnDef;
    }

    private action(param){
            this.oltTabSharedService.setOltTabModelData(param);
    }

}