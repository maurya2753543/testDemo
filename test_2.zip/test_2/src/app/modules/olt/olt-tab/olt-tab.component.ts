import { Component, OnInit } from '@angular/core';
import {Grid} from "../../../shared/ag-grid.options";

import { ViewChild, ComponentFactoryResolver, ViewContainerRef, OnDestroy} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {OltTabModel} from "../olt-tab/olt-tab.model";
import {Logger} from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {ADD_OPERATION} from "../../olt/olt-tab.constants";
import {LocaleDataService} from "../../../shared/locale.data.service";
import * as cstmConstants from "../../olt/olt-tab.constants";
import {Subject} from 'rxjs/';
import {takeUntil} from 'rxjs/operators';
import {SharedService} from "../../../shared/shared.service";
import {StatusFilter} from "../../../shared/status.filter";
import { SweetAlert } from '../../../utilities/sweetAlert';
import { ALERT_INFO, THRESHOLD_INTERVAL_LABEL } from '../../../constant/app.constants';
import { CommonStrings } from '../../../constant/common.strings';
import { OltTabColumnDefinitionService } from '../olt-tab/olt-tab.column-definition.service';
import { OLTUrlService } from '../olt.url.service';
import { OLTHttpService } from '../olt.http.service';
import {OltViewComponent} from './olt-view/olt-view.component'
import {OltTabSharedService} from '../olt-tab-shared.service'
import { AuthService } from 'src/app/shared/auth.service';
import {OltImportComponent} from './olt-import/olt-import.component';
import {ImportBillingComponent} from './import-billing/import-billing.component'
import { ThresholdService } from '../../shared/threshold.service';
import { ContainerColumnDefinitionService } from '../../container/container-tab/container.column-definition.service';
let vm;

function isExternalFilterPresent() {
    return vm.showSelected;
}

function doesExternalFilterPass(node) {
    return node.data.status.toUpperCase() === vm.currentFilter.toUpperCase();
}

@Component({
  selector: 'app-olt-tab',
  templateUrl: './olt-tab.component.html',
  styleUrls: ['./olt-tab.component.scss']
})
export class OltTabComponent implements OnInit {
  public eventKeys: Object[];
  public viewData: boolean = false;

  public oltTabGridOptions: Grid = new Grid();
  public oltTabGridRowData: any = []

  private selectedRowsOLTIds: number[] = [];
  private nameFilterInstance: any;
  public buttonKeys: Object[];
///  private CMTS_TAB_BTN: string = "";
  private OLT_TAB_BTN: string = "";
  private OLT_DIAGNOSTIC_BTN: string = "";
  private EVENTS: string;
  private OLT_TAB_SYNC_SELECTED: string = "";
  private OLT_TAB_SYNC_ALL = "";
  private TABLE_LIST_EXPORT_SELECTED: string = "";
  private TABLE_LIST_EXPORT_ALL: string = "";
  private BULK_MODIFY_FEATURES: string = "";
  private SET_MACTRAK_THRESHOLD: string= "";
  private RESET_MACTRAK_THRESHOLD: string ="";
  private CONFIG_NDF_NDR: string = "";
  private SYNC_SUCCESS: string = "";
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public gridTabType: string = "OLTExport";
  public showAllLabel: string = '';
  public showAllLabelMob: string = '';
  private TABLE_LIST_SHOWING: string = '';
  private TABLE_LIST_SHOWING_OF: string = '';
  private TABLE_LIST_ROWS: string = "";
  private OLT_BTN_IMPORT_OLT: string = "";
  private OLT_BTN_IMPORT_BILLING:string = "";
  private totalCount: number = 0;
  private showSelected: boolean = false;
  private currentFilter: string;
  private VIEW_EVENTS: string = "";
  //public enableImportModemSlider: boolean = false;
  public enableImportOlt: boolean = false;
  public enableImportCmtsSlider: boolean = false;
  public enableImportNoisetrakSlider: boolean = false;
  public openNdfNdrSliderData: any = null;
  private RESET_MACKTRACK_TITLE: string = "";
  private RESET_MACKTRACK_CONFIRMATION_MSG: string = "";
  private osInfo: any;

  private oltTabModel : OltTabModel

  @ViewChild('targetOltView', {read: ViewContainerRef}) _targetOltView;
  constructor(
    private showAlert: ShowAlert,
    private logger: Logger,
    private componentFactoryResolver: ComponentFactoryResolver,
    private localeDataService: LocaleDataService,
    private sharedService: SharedService,
    private viewContainerRef: ViewContainerRef,
    private sweetAlert: SweetAlert,
    private OltTabColumnDefinitionService: OltTabColumnDefinitionService,
    private oltUrlService:OLTUrlService,
    private authService:AuthService,
    private oltHttpService:OLTHttpService,
    private oltTabSharedService:OltTabSharedService
  ) { 
    vm = this;
        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
            this.setEventButtonKeys();
        });
  }

  ngOnInit(): void {
    this.translateLocaleString();
    this.setEventButtonKeys();
    this.setListeners();
    if(this.sharedService.RetainFilter){
        this.oltTabSharedService.oltmodeldatachange = "";
        this.oltTabSharedService.oltFiltermodel = "";
    }
  }
  
    public notifyActionEmitter($event) {
        console.log('event',$event)
        switch ($event.event.name) {
            case this.OLT_TAB_BTN:
                this.loadAddOltComponent();
                break;
            case this.OLT_BTN_IMPORT_OLT:
                this.importOlt();
                break;
            case this.OLT_BTN_IMPORT_BILLING:
                    this.importBilling();
                    break;
            case this.OLT_DIAGNOSTIC_BTN:
                    this.linkToOLTDiagnostic();
                    break;
            case this.OLT_TAB_SYNC_SELECTED:
                        this.oltSyncSelected();
                        break;
            case this.OLT_TAB_SYNC_ALL:
                        this.oltSyncAll();
                        break;
            default:
                break;
        }
    }

    private importBilling(){
        this.loadimportBillingCOmponent(ImportBillingComponent)
    }

    private oltSyncSelected(){
        this.selectedRowsOLTIds = []
        this.oltTabSharedService.getSelectedRowsOLTIds(this.oltTabGridOptions.api.getSelectedRows(), this.selectedRowsOLTIds);
        this.oltSyncSelectedAPI()

    }

    public oltSyncSelectedAPI(){
        this.oltHttpService.postSyncSelected(this.selectedRowsOLTIds).pipe(takeUntil(this.ngUnsubscribe)).subscribe(succ=>{
            this.onSyncSuccess();
            this.logger.info("OLT Sync Selected Successful..");
        },err=>{
            this.showAlert.showErrorAlert(err);
        })
    }

    public oltSyncAll(){
        this.oltHttpService.postSyncAll().pipe(takeUntil(this.ngUnsubscribe)).subscribe(succ=>{
            this.onSyncSuccess();
            this.logger.info("OLT Sync All Successful..");
        },err=>{
            this.showAlert.showErrorAlert(err);
        })
    }

    private loadimportBillingCOmponent(component){
        this._targetOltView.clear;
        let factory = this.componentFactoryResolver.resolveComponentFactory(component);
        let compRef = this._targetOltView.createComponent(factory)
    }

    private setListeners(){
        this.setEditListener()
        this.setSideNavListerner();
        
    }

    private setSideNavListerner(){
            this.oltTabSharedService.sideNavClose.subscribe(val=>{
                if(val){
                    this.getOltListFromAPI()
                }
            })
        }

    private setEditListener(){
        this.oltTabSharedService.oltTabModelDataChange.pipe(takeUntil(this.ngUnsubscribe)).subscribe(oltData=>{
            this.LoadViewTab(OltViewComponent,oltData,'edit')
        })
    }

        // //Method to get filter text
        // private getNameFilterText(): string {
        //     let filterText: string = "";
        //     let filterModel: any = this.nameFilterInstance.getModel();
        //     if (filterModel) {
        //         filterText = filterModel.filter;
        //     }
        //     return filterText;
        // }
    
    private linkToOLTDiagnostic(): void {
            window.open(window.location.origin + "/pathtrak/diagnosticview/index.html#/olt/main", "_blank");
        }

    private loadAddOltComponent(): void {
            this.LoadViewTab(OltViewComponent,null,'add');
        }
   //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.oltTabGridOptions.api.setColumnDefs(this.OltTabColumnDefinitionService.getColumnDef());
        this.nameFilterInstance = this.oltTabGridOptions.api.getFilterInstance('name');
        // setTimeout(dt=>{
           this.getOltListFromAPI();
        // },1500)
      
    }

    public getOltListFromAPI(){ 
        this.oltHttpService.getOltTabData().pipe(takeUntil(this.ngUnsubscribe)).subscribe((data:OltTabModel)=>{
            console.log(data);
            this.oltTabGridRowData = data;
            if(this.sharedService.getFilterForTAB()){
                this.showSelected = true;
                this.oltTabGridOptions["isExternalFilterPresent"] = isExternalFilterPresent;
                this.oltTabGridOptions["doesExternalFilterPass"] = doesExternalFilterPass;
                this.currentFilter = this.sharedService.getFilterForTAB();
                StatusFilter.setFilter(this.currentFilter);
                this.oltTabGridOptions.api.getFilterInstance('status')
                    .setModel(this.currentFilter);
                this.oltTabGridOptions.api.onFilterChanged()
                this.showSelected = false;
            }
            console.log('this.oltTabSharedService.oltFiltermodel..',this.oltTabSharedService.oltFiltermodel)
            // if(this.oltTabGridOptions.api && (this.oltTabSharedService.oltmodeldatachange)){
            if(this.oltTabGridOptions.api && ( !jQuery.isEmptyObject(this.oltTabSharedService.oltFiltermodel) || this.oltTabSharedService.oltmodeldatachange)){
                console.log('245')
                this.oltTabGridOptions.api.setFilterModel(this.oltTabSharedService.oltFiltermodel);
                if(this.oltTabSharedService.oltFiltermodel || this.oltTabSharedService.oltmodeldatachange){
                    console.log('248')
                    const countryFilterComponent3 = this.oltTabGridOptions.api.getFilterInstance("name");
            countryFilterComponent3.setModel(this.oltTabSharedService.oltmodeldatachange);
                }
            }
        },err=>{
            this.oltTabGridRowData = []
            this.showAlert.showErrorAlert(err);
        })
    }


    //Grid Ready Event
    public notifyGridReadyOLT(): void {
        this.setGridColumnDefinition();
    }
    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.oltTabGridOptions.api.showLoadingOverlay();
    }
//Method to set button keys
private setEventButtonKeys(): void {
    this.eventKeys = [
        {name: this.OLT_TAB_SYNC_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.OLT_CONTS},
        {name: this.OLT_TAB_SYNC_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS},
        // {name: this.VIEW_EVENTS, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.OLT_CONTS},
        // {name: this.BULK_MODIFY_FEATURES, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.OLT_CONTS},
        // {name: this.SET_MACTRAK_THRESHOLD, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.OLT_CONTS},
        // {name: this.RESET_MACTRAK_THRESHOLD, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.OLT_CONTS},
        //{name: this.CONFIG_NDF_NDR, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.CMTS_CONTS},
        {
            name: this.TABLE_LIST_EXPORT_SELECTED,
            status: cstmConstants.SINGLE_CONTS,
            tabType: cstmConstants.OLT_CONTS
        },
        {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS}
    ];
    this.buttonKeys = [
        {name: this.OLT_BTN_IMPORT_BILLING, tabType: cstmConstants.SUMMARY_CONTS},
        {name: this.OLT_TAB_BTN, tabType: cstmConstants.OLT_CONTS},
        {name: this.OLT_BTN_IMPORT_OLT, tabType: cstmConstants.SUMMARY_CONTS},
        {
            name: this.OLT_DIAGNOSTIC_BTN,
            tabType: cstmConstants.OLT_CONTS,
            iconClass: 'fa fa-stethoscope',
            txt: ' '
        }
    ];
    // this.buttonKeys = this.buttonKeys.filter((elem: any) => {
    //     if(this.osInfo != 'LINUX'){
    //         return elem.name != this.OLT_BTN_IMPORT_BILLING
    //     }
    //     return elem;
    // })
}

    //method loads control features slider.
    // private notifyControlFeatures($event) {
    //     this.oltTabSharedService.bulkModifyFlag = true;
    //     this.oltTabSharedService.mactrakThresholdFlag = false;
    //     let data = $event;
    //     let oltIdArr: number[] = [];
    //     for (let i = 0; i < data.length; i++) {
    //         oltIdArr.push(data[i].oltId);
    //     }
    //   this.LoadViewTab(cmtsIdArr);
    // }

    private LoadViewTab(targetComponent: any, data?: any, mode?:string): void {
        this._targetOltView.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        let cmpRef = this._targetOltView.createComponent(factory);
        if(data){
            cmpRef.instance.dataModel = data.data;
        }
        if(mode === 'edit'){
            cmpRef.instance.isReadOnly = true
            cmpRef.instance.isAddMode = false
            cmpRef.instance.connectionEstablished = true 
            cmpRef.instance.testDisabled = true;
            cmpRef.instance.saveDisabled = false
        }else if(mode === 'add'){
            cmpRef.instance.isAddMode = true;
            cmpRef.instance.isReadOnly = false
        }
    }

    private importOlt(): void {
       this.loadImportOLT(OltImportComponent)
    }

    private loadImportOLT(component){
        this._targetOltView.clear();
        let factory = this.componentFactoryResolver.resolveComponentFactory(component);
        let cmRef= this._targetOltView.createComponent(factory);

    }


    private importNoisetrak(): void {
        this.enableImportNoisetrakSlider =true;
    }

    //Method to apply filter on ag-Grid
    private applyNameFilter(filterValue: string): void {
        // this.nameFilterInstance.setFilter(filterValue);
        // this.nameFilterInstance.onFilterChanged();
    }

    //Method to get filter text
    private getNameFilterText(): string {
        let filterText: string = "";
        let filterModel: any = this.nameFilterInstance.getModel();
        if (filterModel) {
            filterText = filterModel.filter;
        }
        return filterText;
    }

    //Method to Add OLT
    private notifyAddOLT(): void {
        let data: any = {operation: ADD_OPERATION, oltTabModel: null};
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount): void {
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }


    //Handle error
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //Show Sweetalert on SYNC success
    private onSyncSuccess(): void {
        this.showAlert.showInfoAlert(this.SYNC_SUCCESS);
    }

    ngOnDestroy() {
        this.sharedService.setFilterForTAB('');
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
    public notifyRefreshGrid(event) {
        this.getOltListFromAPI();
    }

    //Translation
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.OLT_TAB_BTN = localizationService.instant('OLT_TAB_BTN');
        this.OLT_BTN_IMPORT_OLT = localizationService.instant('OLT_BTN_IMPORT_OLT');
        this.OLT_BTN_IMPORT_BILLING = localizationService.instant('OLT_BTN_IMPORT_BILLING');
        
        this.VIEW_EVENTS = localizationService.instant('VIEW_EVENTS');
        this.EVENTS = localizationService.instant('EVENTS');
        this.OLT_DIAGNOSTIC_BTN = localizationService.instant('OLT_DIAGNOSTIC_BTN');
        this.OLT_TAB_SYNC_SELECTED = localizationService.instant('OLT_TAB_SYNC_SELECTED');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.OLT_TAB_SYNC_ALL = localizationService.instant('OLT_TAB_SYNC_ALL');
        this.SYNC_SUCCESS = localizationService.instant('SYNC_SUCCESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.BULK_MODIFY_FEATURES = localizationService.instant('BULK_MODIFY_FEATURES');
        this.SET_MACTRAK_THRESHOLD = localizationService.instant('SET_MACTRAK_THRESHOLD')
        this.RESET_MACTRAK_THRESHOLD = localizationService.instant('RESET_MACTRAK_THRESHOLD')

    //  this.CONFIG_NDF_NDR = localizationService.instant('CONFIG_NDF_NDR');
        this.RESET_MACKTRACK_TITLE = localizationService.instant('RESET_MACKTRAK_TITLE');
        this.RESET_MACKTRACK_CONFIRMATION_MSG = localizationService.instant('RESET_MACKTRACK_CONFIRMATION_MSG')
    }

   public modelUpdatedEmitter(event){
    
    }

    public notifyFilterChange(event){
        this.sharedService.RetainFilter = false;
            this.oltTabSharedService.oltFiltermodel = this.oltTabGridOptions.api.getFilterModel();
            const countryFilterComponent = this.oltTabGridOptions.api.getFilterInstance('name');
            const model = countryFilterComponent.getModel();
            this.oltTabSharedService.oltmodeldatachange = model;
    }
}
