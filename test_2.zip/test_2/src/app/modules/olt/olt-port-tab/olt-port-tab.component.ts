import { Component, OnInit } from '@angular/core';
import {Grid} from "../../../shared/ag-grid.options";

import { ViewChild, ComponentFactoryResolver, ViewContainerRef, OnDestroy} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Logger} from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {ADD_OPERATION} from "../../olt/olt-tab.constants";
import {LocaleDataService} from "../../../shared/locale.data.service";
import * as cstmConstants from "../../olt/olt-tab.constants";
import {Subject} from 'rxjs/';
import {takeUntil} from 'rxjs/operators';
import {SharedService} from "../../../shared/shared.service";
import {StatusFilter} from "../../../shared/status.filter";
import { SweetAlert } from '../../../utilities/sweetAlert';
import { ALERT_INFO } from '../../../constant/app.constants';
import { CommonStrings } from '../../../constant/common.strings';
import { OLTUrlService } from '../olt.url.service';
import { OLTHttpService } from '../olt.http.service';
import { PortTabColumnDefinitionService } from './olt-port.column-definition.service';
import { OltPortTabModel } from './olt-port-tab.model';
import { OltTabSharedService } from '../olt-tab-shared.service';
import { OltPortTabService } from './olt-port-tab.service';

let vm;

function isExternalFilterPresent() {
    return vm.showSelected;
}

function doesExternalFilterPass(node) {
    return node.data.status.toUpperCase() === vm.currentFilter.toUpperCase();
}


@Component({
  selector: 'app-olt-port-tab',
  templateUrl: './olt-port-tab.component.html',
  styleUrls: ['./olt-port-tab.component.scss']
})
export class OltPortTabComponent implements OnInit {
  public eventKeys: Object[];
  public viewData: boolean = false;

  public oltPortTabGridOptions: Grid = new Grid();
  public oltPortTabGridRowData: any;
  public oltfilterchangeData: any;

  private selectedRowsOltId: number[] = [];
  private nameFilterInstance: any;
  public buttonKeys: Object[];
  private OLT_TAB_BTN: string = "";
  private OLT_DIAGNOSTIC_BTN: string = "";
  private EVENTS: string;
  private PORT_TAB_EXPORT_SELECTED: string = "";
  private PORT_TAB_EXPORT_ALL = "";
  private TABLE_LIST_EXPORT_SELECTED: string = "";
  private TABLE_LIST_EXPORT_ALL: string = "";
  private BULK_MODIFY_FEATURES: string = "";
  private SET_MACTRAK_THRESHOLD: string= "";
  private RESET_MACTRAK_THRESHOLD: string ="";
  private CONFIG_NDF_NDR: string = "";
  private SYNC_SUCCESS: string = "";
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public gridTabType: string = "OLTPortExport";
  public showAllLabel: string = '';
  public showAllLabelMob: string = '';
  private TABLE_LIST_SHOWING: string = '';
  private TABLE_LIST_SHOWING_OF: string = '';
  private TABLE_LIST_ROWS: string = "";
  private OLT_BTN_IMPORT_OLT: string = "";
  private OLT_BTN_IMPORT_BILLING:string = "";
  private totalCount: number = 0;
  private showSelected: boolean = false;
  private currentFilter: string;
  private VIEW_EVENTS: string = "";
  public enableImportOlt: boolean = false;
  public enableImportCmtsSlider: boolean = false;
  public enableImportNoisetrakSlider: boolean = false;
  public openNdfNdrSliderData: any = null;
  private RESET_MACKTRACK_TITLE: string = "";
  private RESET_MACKTRACK_CONFIRMATION_MSG: string = "";
  private osInfo: any;

  private oltPortTabModel : OltPortTabModel

  constructor(
    private showAlert: ShowAlert,
    private logger: Logger,
    private componentFactoryResolver: ComponentFactoryResolver,
    private localeDataService: LocaleDataService,
    private sharedService: SharedService,
    private viewContainerRef: ViewContainerRef,
    private sweetAlert: SweetAlert,
    private portTabColumnDefinitionService: PortTabColumnDefinitionService,
    private oltUrlService:OLTUrlService,
    private oltHttpService:OLTHttpService,
    private oltTabSharedService: OltTabSharedService,
    private oltPortTabService: OltPortTabService
  ) { 
      vm = this;
          this.localeDataService.componentCallback.subscribe((response) => {
              this.translateLocaleString();
              this.setEventButtonKeys();
      });
  }

  ngOnInit(): void {
    this.translateLocaleString();
    this.setEventButtonKeys();
    this.initAllSubjectListener();
    if(this.sharedService.RetainFilter){
        this.oltPortTabService.oltporttabretaindata = "";
        this.oltTabSharedService.oltmodeldatachange = "";
    }
  }


    public notifyActionEmitter($event) {
      console.log("EVENT",$event);
        switch ($event.event.name) { 
            case this.OLT_DIAGNOSTIC_BTN:
                this.linkToOltDiagnostic();
                break;    
            // to hide Configure NDF / NDR dropdown action as per XPTUI-767
            // case this.CONFIG_NDF_NDR:
            //     this.notifyConfigNDF_NDR($event.selectedData);
            //     break;
            default:
                break;
        }
    }


    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.oltPortTabGridOptions.api.setColumnDefs(this.portTabColumnDefinitionService.getColumnDef());
        this.nameFilterInstance = this.oltPortTabGridOptions.api.getFilterInstance('name');
        this.getOltPortListFromAPI();
    }


    public getOltPortListFromAPI(){ 
        this.oltHttpService.getOltPortTabData().pipe(takeUntil(this.ngUnsubscribe)).subscribe((data:OltPortTabModel)=>{
        this.oltPortTabGridRowData = data;
        this.totalCount = this.oltPortTabGridRowData.length;
        this.setShowAllLabel(this.oltPortTabGridRowData.length, this.totalCount)
        if(this.oltPortTabGridOptions.api && (this.oltPortTabService.oltporttabretaindata || this.oltTabSharedService.oltmodeldatachange)){
            this.oltPortTabGridOptions.api.setFilterModel(this.oltPortTabService.oltporttabretaindata);
            if(this.oltPortTabService.oltporttabretaindata || this.oltTabSharedService.oltmodeldatachange){
                const countryFilterComponent3 = this.oltPortTabGridOptions.api.getFilterInstance("oltName");
            countryFilterComponent3.setModel(this.oltTabSharedService.oltmodeldatachange);
            }
                }
            },err=>{
                this.oltPortTabGridRowData = []
                this.showAlert.showErrorAlert(err);
        })
                
    }

    //Method to refresh ag-Grid
    private oltPortListRefreshSubjectListener(): void {
        this.oltTabSharedService
            .getOltPortListRefreshSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((isHardReset: boolean) => {
                if (isHardReset) {
                    this.clearGridData();
                    ////this.getCmtsListFromAPI();
                }
            });
    }
    public notifyFilterChange(event){
        this.sharedService.RetainFilter = false;
        this.oltPortTabService.oltporttabretaindata = this.oltPortTabGridOptions.api.getFilterModel();        const countryFilterComponent = this.oltPortTabGridOptions.api.getFilterInstance('oltName');
        const model = countryFilterComponent.getModel();
        this.oltTabSharedService.oltmodeldatachange = model;
    }
    //clear existing selection of ag-Grid
    private clearGridData(): void {
        this.storeSelection();
        //this.oltPortTabGridOptions.api.setRowData([]);
        this.oltPortTabGridRowData = [];
    }

    //Store existing selection of ag-Grid
    private storeSelection(): number[] {
        this.selectedRowsOltId.length = 0;
        this.oltPortTabService.getSelectedRowsOltIds(this.oltPortTabGridOptions.api.getSelectedRows(), this.selectedRowsOltId);
        return this.selectedRowsOltId;
    }

    //Grid Ready Event
    public notifyGridReadyOLTPort(): void {
        this.setGridColumnDefinition();
    }

    //Init all subject listener
    private initAllSubjectListener(): void {
        this.oltPortListRefreshSubjectListener();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.oltPortTabGridOptions.api.showLoadingOverlay();
    }

    //Method to set button keys
    private setEventButtonKeys(): void {
        this.eventKeys = [
            // {
            //     name: this.TABLE_LIST_EXPORT_SELECTED,
            //     status: cstmConstants.SINGLE_CONTS,
            //     tabType: cstmConstants.OLT_CONTS
            // },
           // {name: this.PORT_TAB_EXPORT_SELECTED, status: cstmConstants.SINGLE_CONTS, tabType: cstmConstants.OLT_CONTS},
            //{name: this.PORT_TAB_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS},
            //{name: this.VIEW_EVENTS, status: cstmConstants.ONLY_SINGLE_CONST, tabType: cstmConstants.OLT_CONTS},
           
            // {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS}
            {
                name: this.TABLE_LIST_EXPORT_SELECTED,
                status: cstmConstants.SINGLE_CONTS,
                tabType: cstmConstants.OLT_CONTS
            },
            {name: this.TABLE_LIST_EXPORT_ALL, status: cstmConstants.ALL_CONTS, tabType: cstmConstants.OLT_CONTS}
        ];
        this.buttonKeys = [
            // {
            //     name: this.OLT_DIAGNOSTIC_BTN,
            //     tabType: cstmConstants.OLT_CONTS,
            //     iconClass: 'fa fa-stethoscope',
            //     txt: ' '
            // }
        ];
    }

    private linkToOltDiagnostic(): void {
        console.log("link")
        window.open(window.location.origin + "/pathtrak/diagnosticview/index.html#/olt", "_blank");
    }

    //Method to apply filter on ag-Grid
    private applyNameFilter(filterValue: string): void {
        this.nameFilterInstance.setFilter(filterValue);
        this.nameFilterInstance.onFilterChanged();
    }

    //Method to get filter text
    private getNameFilterText(): string {
        let filterText: string = "";
        let filterModel: any = this.nameFilterInstance.getModel();
        if (filterModel) {
            filterText = filterModel.filter;
        }
        return filterText;
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount): void {
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    // updates row message.
    public modelUpdatedEmitter(e: any): void {
        let rowCount = this.oltPortTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }


    //Handle error
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }


    ngOnDestroy() {
        this.sharedService.setFilterForTAB('');
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    public notifyRefreshGrid(event) {
        this.getOltPortListFromAPI();
    }

  //Translation
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.OLT_TAB_BTN = localizationService.instant('OLT_TAB_BTN');
        this.OLT_BTN_IMPORT_OLT = localizationService.instant('OLT_BTN_IMPORT_OLT');
        this.OLT_BTN_IMPORT_BILLING = localizationService.instant('OLT_BTN_IMPORT_BILLING');
        
        this.VIEW_EVENTS = localizationService.instant('VIEW_EVENTS');
        this.EVENTS = localizationService.instant('EVENTS');
        this.OLT_DIAGNOSTIC_BTN = localizationService.instant('OLT_DIAGNOSTIC_BTN');
        this.PORT_TAB_EXPORT_SELECTED = localizationService.instant('PORT_TAB_EXPORT_SELECTED');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.PORT_TAB_EXPORT_ALL = localizationService.instant('PORT_TAB_EXPORT_ALL');
        this.SYNC_SUCCESS = localizationService.instant('SYNC_SUCCESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.BULK_MODIFY_FEATURES = localizationService.instant('BULK_MODIFY_FEATURES');
        this.SET_MACTRAK_THRESHOLD = localizationService.instant('SET_MACTRAK_THRESHOLD')
        this.RESET_MACTRAK_THRESHOLD = localizationService.instant('RESET_MACTRAK_THRESHOLD')

    //  this.CONFIG_NDF_NDR = localizationService.instant('CONFIG_NDF_NDR');
        this.RESET_MACKTRACK_TITLE = localizationService.instant('RESET_MACKTRAK_TITLE');
        this.RESET_MACKTRACK_CONFIRMATION_MSG = localizationService.instant('RESET_MACKTRACK_CONFIRMATION_MSG')
    }

}
