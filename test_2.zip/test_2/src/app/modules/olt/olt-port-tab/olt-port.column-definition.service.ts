/**
 * Created by Vatsya Krishnkant.
 */
import {Injectable} from "@angular/core";

import {EDIT_ICON, EXTERNAL_LINK_ICON} from "../../../constant/app.constants";
import {Subject} from "rxjs";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {TimeFilter} from "../../../shared/time.filter";
import {StatusFilter} from "../../../shared/status.filter";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from "@ngx-translate/core";
import { OLTUrlService } from "../olt.url.service";
//import * as moment from "moment/moment";

@Injectable()
export class PortTabColumnDefinitionService{

    private _HEADER_FIELDS: any = {
            virtualPortName:{field:"virtualPortName",name:"virtual Port Name"},
            name : {field: "name", name: "OLT Port Name"},
            opticsSerialNumber:{field:"opticsSerialNumber", name:"Optics Serial Number"},
            oltName : {field: "oltName", name: "OLT Name"},
            ontCount : {field: "ontCount", name: "OLT Port Count"},
            viewDiagnostic : {field: "viewDiagnostic", name: "Diagnostic Link"},
            //edit : {field: "edit", name: "Edit"},
    };

    constructor(private localeDataService: LocaleDataService,
        private sharedService : SharedService,
        private translate: TranslateService,
        private urlService: OLTUrlService){
       
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.virtualPortName.name = this.translate.instant('OLT_PORT_TAB_VIRTUAL_PORT_NAME');
        this._HEADER_FIELDS.name.name = this.translate.instant('OLT_PORT_TAB_HEADER_PORT_NAME');
        this._HEADER_FIELDS.opticsSerialNumber.name = this.translate.instant('OLT_PORT_TAB_OPTICS_SERIAL_NUMBER');
        this._HEADER_FIELDS.oltName.name = this.translate.instant('OLT_PORT_TAB_HEADER_OLT_NAME');
        this._HEADER_FIELDS.ontCount.name = this.translate.instant('ONT_COUNT_HEADER_ONT_COUNT');
        this._HEADER_FIELDS.viewDiagnostic.name = this.translate.instant('ONT_TAB_HEADER_ONT_DETAIL');
        //this._HEADER_FIELDS.edit.name = this.translate.instant('OLT_TAB_HEADER_EDIT');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        this.translateLocaleStr();
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.name.name,headerTooltip: this._HEADER_FIELDS.name.name, field: this._HEADER_FIELDS.name.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.name.name, 70),
                filter: 'text',sort: 'asc',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,newRowsAction: 'keep'}
            },
            // {
            //     headerName: this._HEADER_FIELDS.virtualPortName.name,headerTooltip: this._HEADER_FIELDS.virtualPortName.name, field: this._HEADER_FIELDS.virtualPortName.field,
            //     minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.virtualPortName.name, 70),
            //     filter: 'text',
            //     floatingFilterComponentParams:{ suppressFilterButton:true },
            //     comparator: gridCustomComparator,
            //     filterParams: {suppressAndOrCondition: true,newRowsAction: 'keep'}
            // },
            {
                headerName: this._HEADER_FIELDS.virtualPortName.name,headerTooltip:this._HEADER_FIELDS.virtualPortName.name, field: this._HEADER_FIELDS.virtualPortName.field,
                minWidth: 70, 
                // cellStyle : () => {
                //     return { 'text-align': 'center' };
                // },
                filter: 'text',
                comparator: gridCustomComparator,
                // floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true,newRowsAction: 'keep' },
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let url = this.urlService.redirectToOLTPortView(param.data.virtualPortId)
                    return `<a href="${url}" target="_blank">${param.value}</a>`
                })
            },
            {
                headerName: this._HEADER_FIELDS.opticsSerialNumber.name,headerTooltip: this._HEADER_FIELDS.opticsSerialNumber.name, field: this._HEADER_FIELDS.opticsSerialNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.opticsSerialNumber.name, 70),
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.oltName.name,headerTooltip: this._HEADER_FIELDS.oltName.name, field: this._HEADER_FIELDS.oltName.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.oltName.name, 70),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.ontCount.name,headerTooltip: this._HEADER_FIELDS.ontCount.name, field: this._HEADER_FIELDS.ontCount.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.ontCount.name, 60),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,newRowsAction: 'keep'},
                comparator: gridCustomComparator,
            },
            {
                headerName: this._HEADER_FIELDS.viewDiagnostic.name,headerTooltip:this._HEADER_FIELDS.viewDiagnostic.name, field: this._HEADER_FIELDS.viewDiagnostic.field,
                minWidth: 150, maxWidth: 150,
                pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: { suppressAndOrCondition: true },
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EXTERNAL_LINK_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        let url = this.urlService.redirectDiagnosticONTList(param.data.elementId);
                        window.open(url);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            },
           
        ]
        return columnDef;
    }

}