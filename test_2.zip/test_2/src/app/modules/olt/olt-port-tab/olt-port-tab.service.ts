/**
 * Created by Vatsya Krishnkant on 10/26/2022.
 */
import {Injectable} from "@angular/core";
import {OltPortTabModel} from "./olt-port-tab.model";

@Injectable()
export class OltPortTabService{
     public oltporttabretaindata: any;
    //Method to get selected rows from grid
    public getSelectedRowsOltIds(oltModels: OltPortTabModel[], selectedRowsOltId: number[]): void{
        oltModels.forEach((oltModels: OltPortTabModel)=>{
            selectedRowsOltId.push(oltModels.oltsId);
        });
    }

    //Method to restore grid selection
    public restoreSelection(selectedRowsOltId: number[], oltPortTabGridOptionsAPI: any): void{
        if(selectedRowsOltId.length >= 1){
            oltPortTabGridOptionsAPI.forEachNode((node)=>{
                for(let i = 0; i < selectedRowsOltId.length; i ++){
                    if (node.data.oltsId === selectedRowsOltId[i]) {
                        node.setSelected(true);
                        break;
                    }// End of if
                }// End of For
            });// End of forEachNode
        }// End of If
    }
}
