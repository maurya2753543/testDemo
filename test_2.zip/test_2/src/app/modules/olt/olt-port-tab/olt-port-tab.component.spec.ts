import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OltPortTabComponent } from './olt-port-tab.component';

describe('OltPortTabComponent', () => {
  let component: OltPortTabComponent;
  let fixture: ComponentFixture<OltPortTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OltPortTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OltPortTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
