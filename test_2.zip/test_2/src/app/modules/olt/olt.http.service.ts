/*
 * Copyright (c) 2023 Viavi Solutions Inc. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions is strictly prohibited.
 */

/**
 * Created by Vatsya Krishnkant on 10/18/2022.
 */

/* Common HTTP service to call http request from Generic Http Service*/

import {Injectable} from '@angular/core';
import {HttpService} from '../../shared/http.service';
import {OLTUrlService} from './olt.url.service';
import {AuthService} from 'src/app/shared/auth.service';
import {HttpHeaders} from '@angular/common/http';
import {catchError, switchMap, take} from 'rxjs/operators';
import {throwError,Observable} from "rxjs";

@Injectable()
export class OLTHttpService {

    private mock = false;
    private headers: HttpHeaders = new HttpHeaders();

    constructor(private httpService: HttpService,
                private oltUrlService: OLTUrlService,
                private authService: AuthService,
    ) {}

    public getOltTabData() {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            // we use switchMap because if the token expires mid-request, we want to cancel it and send a new one
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.GETWITHHEADERS(this.oltUrlService.getOltTabDataURL(), headers)),
                catchError(err => {
                    return throwError(err);
                }),
                // take one ensures this completes after we get a single response, making cleaning up subscriptions unnecessary
                // this is useful as most http.service requests are treated as a 1-time use Observable
                take(1)
            );
        }

    }


    public postAddOlt(payload) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.postOltUrl(), payload, headers)),
                take(1)
            );
        }
    }

    public testConnection(payload) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.tesConnection(), payload, headers)),
                take(1)
            );
        }
    }

    public putEditOlt(payload) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.PUTWITHHEADER(this.oltUrlService.putEditOltURL(payload.elementId), payload, headers)),
                take(1)
            );
        }
    }

    public deleteOlt(elementId) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.DELETEWITHHEADER(this.oltUrlService.deletOltURL(elementId), headers)),
                take(1)
            );
        }
    }

    public postSyncSelected(params) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.oltSyncSelected(), params, headers)),
                take(1)
            );
        }
    }

    public postSyncAll() {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.oltSyncAll(), {}, headers)),
                take(1)
            );
        }
    }


    // *  API For OLT Port Tab *//
    public getOltPortTabData() {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olt-Port.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.GETWITHHEADERS(this.oltUrlService.getOltPortTabDataURL(), headers)),
                take(1)
            );
        }
    }

    public getContainerPath(id) {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/olts.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.GET(this.oltUrlService.getContainerPath(id))),
                take(1)
            );
        }

    }

    // *  API For ONT SUmmary Tab *//
    public getOltSummaryTabData() {
        if (this.mock) {
            return this.httpService.GET('../../../assets/jsons/ont-summary.json');
        } else {
            return this.authService.getJwtHeaders().pipe(
                switchMap(headers => this.httpService.GETWITHHEADERS(this.oltUrlService.getOltSummaryTabData(), headers, true)),
                take(1)
            );
        }
    }

    public getPerformGeocodeONTData(): Observable<any> {
        return this.httpService.GETTEXT(this.oltUrlService.getPerformGeocodeONTUrl());
    }
    
    public topologyExportFields(): Observable<any> {
        return this.authService.getJwtHeaders().pipe(
            switchMap(headers => this.httpService.GETWITHHEADERS(this.oltUrlService.topologyExportFieldsUrl(), headers, true)),
            take(1)
        );
    }


    public addCSVConfigToServer(data,persist): Observable<any> {
        return this.authService.getJwtHeaders().pipe(
            switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.addCSVConfigToServerURL(persist), data, headers)),
            take(1)
        );
    }    
    public getExportGeocodeONTData(): Observable<any> {
        return this.httpService.GET(this.oltUrlService.getExportGeocodeONTUrl());
    }


    public oltExportFields(): Observable<any> {

      return this.authService.getJwtHeaders().pipe(
        
       switchMap(headers => this.httpService.GETWITHHEADERS(this.oltUrlService.oltExportFieldsUrl(), headers, true)),
        
       take(1)
        
       );
        
      }

        public addCSVConfigToServerOLT(data): Observable<any> {

            return this.authService.getJwtHeaders().pipe(
            
           switchMap(headers => this.httpService.POSTWITHHEADER(this.oltUrlService.addCSVConfigToServerURLOlt(), data, headers)),
            
          take(1)
            
           );
           }
}
