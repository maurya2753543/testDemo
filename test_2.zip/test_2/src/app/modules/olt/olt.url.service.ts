import { Injectable } from '@angular/core';
import { SharedService } from "../../shared/shared.service";

@Injectable()
export class OLTUrlService {
  getPerformGeocodeONTData() {
        throw new Error("Method not implemented.");
  }

    private host:string = "";

    constructor(private sharedService: SharedService) {
      this.host = this.sharedService.getHost()  
    }
    
    public getOltTabDataURL(){
        return this.host + '/pathtrak/api/pon/olt'
    }

    public getRedirectOLTDiagnosticUrl(id){
      return this.host + "/pathtrak/diagnosticview/index.html#/olt/main?id=" + id;
    }

    public  getOltPortTabDataURL(){
        return this.host + '/pathtrak/api/pon/oltport'
    }
    
    public  getOltSummaryTabData(){
      return this.host + '/pathtrak/api/pon/ont/summary'
    }
    public postOltUrl(){
      return this.host + '/pathtrak/api/pon/olt'
    }

    public putEditOltURL(elementId){
      return this.host + '/pathtrak/api/pon/olt/' + elementId
    }

    public deletOltURL(elementId){
      return this.host + '/pathtrak/api/pon/olt/' + elementId
    }

    public oltSyncAll(){
      return this.host + '/pathtrak/api/pon/olt/syncAll' 
    }

    public oltSyncSelected(){
      return this.host + '/pathtrak/api/pon/olt/sync' 
    }

    public tesConnection(){
      return this.host + '/pathtrak/api/olt/identify'
    }

    public getContainerPath(id){
      return this.host + `/pathtrak/api/container/${id}/path`
  }

  /* Return url toperform geocoding from server*/
    public getPerformGeocodeONTUrl():string {
      return this.host +"/pathtrak/api/modems/geocode/restart";
  }

    public topologyExportFieldsUrl():string {
      return this.host +"/pathtrak/api/pon/ponImport/csvParserConfig";
  }

    public addCSVConfigToServerURL(persist):string {
      return this.host +`/pathtrak/api/pon/ponImport/csvCustomParser?isToBePersisted=${persist}&deleteAllOntsAtStart=false&sampleResponse=false`;
  }

  
  /* Return url to get exported modem from server*/
  public getExportGeocodeONTUrl():string {
      return this.host +"/pathtrak/api/modems/geocode/failed";
  }

/* Redirect to OLT PORT Topology view */
  public redirectToOLTPortView(id){
    return this.host + "/pathtrak/pnm/view.html#/oltport?port=" + id
  }

  /* Redirect to OLT PORT Topology view */
  public redirectDiagnosticONTList(id){
    return this.host + "/pathtrak/diagnosticview/index.html#/olt/ont-list?oltPortId=" + id
  }

  public oltExportFieldsUrl():string {

    return this.host +"/pathtrak/api/pon/olt/import/config";
    
    }
    
    
    
    
    public addCSVConfigToServerURLOlt():string {
    
    return this.host +`/pathtrak/api/pon/olt/import`;
    }

}
