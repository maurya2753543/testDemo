import { NgModule } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import {UiSwitchModule} from "ngx-ui-switch";

import { OltComponent } from './olt.component';
import { OltTabComponent } from './olt-tab/olt-tab.component';
import { OltPortTabComponent } from './olt-port-tab/olt-port-tab.component';
import { OltSummaryTabComponent } from './olt-summary-tab/olt-summary-tab.component';
import { OltRoutes } from './olt.route';
import { SharedModule } from "../shared/shared.module";
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';


import { LanguageService } from 'src/app/shared/locale.language.service';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';

import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { AgGridModule } from 'ag-grid-angular';
;
import { LocaleDataService } from 'src/app/shared/locale.data.service';
import { ContainerUrlService } from './../container/container-url.service';
import { ContainerHttpService } from './../container/container-http.service';
import { ContainerDataService } from './../container/container.data.service';
import {SitesHTTPService} from './../sites/sites.http.service';
import {SitesUrlService} from '../sites/sites.url.service';
import {SiteListDataService} from '../sites/site-list/site-list.data.service';
import {SitesHttpServiceMock} from '../sites/sites.http.service.mock';
import {ViewEventsColumnDefinitionService} from "../shared/common-components/listView/viewEvents.column-definition.service";
import { SystemSettingsDataService } from '../system-settings/system-settings.data.service';
import {UndefinedTextToDashPipe} from "../../pipes/undefined-text-to-dash.pipe";
import { OltTabColumnDefinitionService } from './olt-tab/olt-tab.column-definition.service';
import { OLTUrlService } from './olt.url.service';
import { OLTHttpService } from './olt.http.service';
import { OltService } from './olt.service';
import { OltViewComponent } from './olt-tab/olt-view/olt-view.component'
import { PortTabColumnDefinitionService } from './olt-port-tab/olt-port.column-definition.service';
import { OltImportComponent } from './olt-tab/olt-import/olt-import.component';
import { ImportBillingComponent } from './olt-tab/import-billing/import-billing.component';
import { OltPortTabService } from './olt-port-tab/olt-port-tab.service';
import { SummaryTabColumnDefinitionService } from './olt-summary-tab/olt-summary.column-definition.service';
import { OltSummryTabService } from './olt-summary-tab/olt-summary-tab.service';




export function HttpLoaderFactory(http: HttpClient) {
  let lan = navigator.language.split('-')[0];
  const langs = AppConstants.LANGUAGE_LIST_SHORT;
  const isLang = langs && langs.find(lang => lang === lan);
  const lang = (isLang) ? isLang : 'en';
  return new TranslateHttpLoader(http, `./././assets/lang/${lang}/olt-locale-`, ".json");
  
}



@NgModule({
  imports: [
    OltRoutes,
    CommonModule,
    FormsModule,
    SharedModule,
    UiSwitchModule,
    AgGridModule,
    // LocalizationModule.forRoot(),
     ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
      provide: TranslateLoader,
      useFactory: HttpLoaderFactory,
      deps: [HttpClient]
    }}),
  ],
  declarations: [
    OltComponent,
    OltTabComponent,
    OltPortTabComponent,
    OltSummaryTabComponent,
    OltViewComponent,
    OltImportComponent,
    ImportBillingComponent
   // UndefinedTextToDashPipe
  ],
  entryComponents: [
    OltComponent,
    OltTabComponent,
    OltPortTabComponent,
    OltSummaryTabComponent,
    OltViewComponent
  ],
  providers: [
    TranslateService,
    LanguageService,
    LocaleDataService,
    ContainerDataService,
    ContainerHttpService,
    ContainerUrlService,
    SitesHTTPService,
    SitesUrlService,
    SiteListDataService,
    SitesHttpServiceMock,
    SystemSettingsDataService,
    ViewEventsColumnDefinitionService,
    OltTabColumnDefinitionService,
    PortTabColumnDefinitionService,
    SummaryTabColumnDefinitionService,
    OLTUrlService,
    OLTHttpService,
    OltService,
    OltPortTabService,
    OltSummryTabService
 ]
})
export class OltModule { }