/**
 * Created by yogesh.paisode on 6/12/2017.
 */

export const EDIT_OPERATION: string = "edit";
export const ADD_OPERATION: string = "add";
export const SINGLE_CONTS: string = "single";
export const ONLY_SINGLE_CONST:string = "only-single";
export const MULTI_CONTS: string = "multi";
export const ALL_CONTS: string = "all";
export const OLT_CONTS: string = "OLT";
export const SUMMARY_CONTS: string = "SUMMARY-OLT";
//export const NODE_CONTS: string = "NODE-CMTS";
export const PORT_CONTS: string = "PORT-OLT";
export const OLT_CONTAINER: string = "Container";
export const OLT_SITE: string = "Site";
export const FIRST_SELECT_OPTION: string = "-- Select ";
export const MODEM_ALARM_CONTS: string = "MODEM-ALARM";
export const MODEM_WATCH_CONTS: string = "MODEM-WATCH";