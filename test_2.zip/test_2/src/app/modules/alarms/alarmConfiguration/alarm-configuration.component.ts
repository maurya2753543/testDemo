import { Component, OnInit } from "@angular/core";
import { HEADEND_CONTROL_UNIT, HEADEND_STEALTH_MODEM, PORT, RETURN_PATH_MONITOR } from "../../../constant/app.constants";
import { Grid } from '../../../shared/ag-grid.options';
import {ShowAlert} from "../../../utilities/showAlert";
import { AlarmConfigurationDataService } from "./alarm-configuration.data.service";
import { BehaviorSubject } from "rxjs";
import { map, share, mapTo, startWith, distinctUntilChanged } from "rxjs/operators";

// CODE REVIEW : Comments not present on some of methods.
@Component({
    selector: "alarm-config",
    templateUrl: 'alarm-configuration.html'
})
export class AlarmConfigurationComponent implements OnInit {
    private readonly defaultValue = 'SELECT_DEVICE';
    private value = new BehaviorSubject<string>(this.defaultValue);
    public hasValue = this.value.pipe(map(v => v !== this.defaultValue));
    private rpmSelection = RETURN_PATH_MONITOR;
    private hcuSelection = HEADEND_CONTROL_UNIT;
    private hsmSelection = HEADEND_STEALTH_MODEM;
    private alarmNotificationGrid = new Grid();
    private showConfigurationOptions: boolean = true;
    configureEventLabel: string;
    options: Array<any>;
    isVisibleAll: boolean = true;
    public isFormDisabled: boolean = true;
    
    deviceTypes = this.alarmConfigurationDataService.getDeviceTypeList()
        .pipe(map((deviceList) =>
            {
                let list =  deviceList.filter(item => item != 'CM' && item != 'HFC_NODE');
                return  [this.defaultValue, ...list]
            }),
        share());

        
    public isDataLoaded = this.deviceTypes.pipe(mapTo(true),startWith(false),distinctUntilChanged());

    constructor(public alarmConfigurationDataService: AlarmConfigurationDataService, private showAlert: ShowAlert) { }
    
    ngOnInit() {
        this.enableDisableSave();
    }

    /*
     * @name: onError
     * @desc: used to handle error of api response
     * @param: value=> error code from server
     * */
    onError(error: any): void {
        this.showAlert.showErrorAlert(error);
    }

    /*
     * @name: ngModelChange
     * @desc: used to load dropdown selected device component
     * @param: value=> selected device
     * */
    private getLabel(value) {
        this.configureEventLabel = value;
    }

    /*
     * @name: ngModelChange
     * @desc: used to load dropdown selected device component
     * @param: value=> selected device
     * */
    private onDeviceSelect(value) {
        this.value.next(value);
    }

    /*
     * @name: btnSave_Click
     * @desc: event method invoked on click event of save button
     * @return: void
     * */
    public btnSave_Click(): void {
        this.alarmConfigurationDataService.setPostData();
    }

    /*
    * @name: btnCancel_Click
    * @desc: event method invoked on click event of cancel button
    * @return: void
    * */
    public btnCancel_Click(): void {
        this.alarmConfigurationDataService.cancel();
    }

    /*
    * @name: enableDisableSave
    * @desc: used to subscribe enableDisableSave subject to enable/disable save button
    * */
    private enableDisableSave(): void {
        this.alarmConfigurationDataService.enableDisableSave.subscribe((data) => {
            if(data && typeof data.isDisabled != 'undefined' && data.isDisabled != null ) {
                this.isFormDisabled = data.isDisabled;
            }
        })
    }
}