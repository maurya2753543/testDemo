import { Component, Input, Output, EventEmitter } from "@angular/core";
import {LocaleDataService} from "../../../../../shared/locale.data.service";
import {AlarmListDataService} from "../../../alarmList/alarm-list.data.service";
import {ThresholdService} from "../../../../shared/threshold.service";
import {AlarmConfigurationDataService} from "../../alarm-configuration.data.service";
@Component({
    selector: "list-of-events",
    templateUrl: "listEvent.component.html"
})
export class ListEventComponent {

    private selectedListsItem: { key: string, value: string };
    public isLoaded: boolean = false;
    private displayItems:any = [];
    private thresholdList:any;
    private clickeditemdisplay: boolean = false;

    private _eventList: any;
    public get eventlist() { return this._eventList; }

    private selectedDevice:string;
    @Input() public set eventlist(value) {
         this._eventList = value;
    }
    @Input() public set label(value) {
        this.selectedDevice = value;
        this.updateEventList(this._eventList);
   }
    @Output() getValue = new EventEmitter<{ key: string, value: string }>();

    constructor(private localeDataService: LocaleDataService,
                private alarmListDataService : AlarmListDataService,
                private thresholdService: ThresholdService,
                private alarmConfigurationDataService: AlarmConfigurationDataService,) {}

    updateEventList(eventList) {
        if(eventList) {
            this.displayItems = [];
            this.thresholdList = this.alarmListDataService.getThresholdList();
            /* get rpm port sequence similar to cmts us port */
            if(this.selectedDevice.toUpperCase() ==  'RPMPORT'){
                this.eventlist = this.thresholdService.getRpmPortSequence();
            }
            for(let i = 0; i < this.eventlist.length; i++) {
                let key:string = this.eventlist[i];
                this.displayItems.push({"key":key, "value": this.thresholdService.getThresholdIndex(key)});
            }
            this.selectedListsItem = this.displayItems[0];
            this.getValue.emit(this.selectedListsItem);
        }
        this.isLoaded = true;
    }

    /*
     * @name: getClickedItem
     * @desc: used to get clicked list item and send it to component
     * @return: void
     * @params: item(string): selected item
     * */
    getClickedItem(item: { key: string, value: string }): void {
        this.selectedListsItem = item;
        this.getValue.emit(this.selectedListsItem);
        if(item.value =='Node Outage Critical' || item.value == 'Alarm Cleared-Node Outage Threshold 1'||item.value =='Node Outage Marginal'||item.value =='Alarm Cleared-Node Outage Threshold 2')
        {  
          this.alarmConfigurationDataService.showItem.next(false);
        }
        else{
            this.alarmConfigurationDataService.showItem.next(true);
        }
    }

    /*
    * @name: translateLocaleString
    * @desc: Function translates the string into the locale of browser
    * */
    private translateLocaleString(key:string): string {
        let localization = this.localeDataService.getLocalizationService();
        return localization.instant(key);
    }
}