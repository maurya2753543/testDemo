import { Injectable } from "@angular/core";
import { LocaleDataService } from "../../../../../shared/locale.data.service";
import { AlarmConfigurationDataService } from "../../alarm-configuration.data.service";
import {gridCustomComparator} from "../../../../../shared/ag-Grid.comparator";

let vm: any;
/*
* This class is not service, it is a model for Grid-Coloumn-Defination
* beacuse we need seperate object for each alarm-list item & with service, this is not possible
* */
export class AlarmConfigColumnDefinitionService {

    private SEND_EMAIL: string;
    private SEND_SMS: string;
    private FULL_NAME:string;
    private sendSmsCheckboxes: any = [];
    private sendEmailCheckboxes: any = [];
    public callBackFun:any;

    private localeDataService: LocaleDataService;
    private alarmConfigurationDataService: AlarmConfigurationDataService

    constructor(localeDataService: LocaleDataService, alarmConfigurationDataService: AlarmConfigurationDataService) {
        vm = this;
        this.localeDataService = localeDataService;
        this.alarmConfigurationDataService = alarmConfigurationDataService;
        this.translateLocaleString();
    }

    /*
     * @name: getAlarmTableColDefs
     * @desc: used to get column definations
     * */
    public getAlarmTableColDefs(): Array<{}> {
        return [{
            headerName: this.FULL_NAME,
            minWidth: 100,
            field: "fullName",
            filter: "text",
            sort: 'asc',
            comparator: gridCustomComparator,
            headerTooltip: this.FULL_NAME,
            cellStyle: function () { return { 'text-align': 'center' } },
            floatingFilterComponentParams: { suppressFilterButton: true }
        },
        {
            headerName: this.SEND_EMAIL,
            field: "notifyEmail",
            suppressSorting: true,
            minWidth: 100,
            suppressFilter: true,
            suppressMenu:true,
            headerTooltip: this.SEND_EMAIL,
            cellStyle: function () { return { 'text-align': 'center' } },
            floatingFilterComponentParams: { suppressFilterButton: true },
            cellRenderer: function (params) {
                let gui = document.createElement('div');
                if (params.data.isEmailSupported) {
                    gui.innerHTML = "<input type='checkbox'>";
                    let eFilterText = gui.querySelector('input');
                    eFilterText.addEventListener("change", (($event: any) => {
                        params.data.setEmailValue($event.target.checked);
                        vm.callBackFun();
                        vm.alarmConfigurationDataService.enableDisableSaveButton();
                    }));
                    gui.className = "ag-Grid-cursor chk-margin";
                    eFilterText.checked = params.data.notifyEmail;
                    vm.sendEmailCheckboxes.push({ "object": params.data, "checkbox": eFilterText });
                    return gui;
                } else {
                    return gui;
                }
            }
        },
        {
            headerName: this.SEND_SMS,
            field: "notifySMS",
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu:true,
            minWidth: 100,
            headerTooltip: this.SEND_SMS,
            cellStyle: function () { return { 'text-align': 'center' } },
            floatingFilterComponentParams: { suppressFilterButton: true },
            cellRenderer: function (params) {
                let gui = document.createElement('div');
                if (params.data.isSmsSupported) {
                    gui.innerHTML = "<input type='checkbox'>";
                    let eFilterText = gui.querySelector('input');
                    eFilterText.addEventListener("change", (($event: any) => {
                        params.data.setSmsValue($event.target.checked);
                        vm.callBackFun();
                        vm.alarmConfigurationDataService.enableDisableSaveButton();
                    }));
                    gui.className = "ag-Grid-cursor chk-margin";
                    eFilterText.checked = params.data.notifySMS;
                    vm.sendSmsCheckboxes.push({ "object": params.data, "checkbox": eFilterText });
                    return gui;
                } else {
                    return gui;
                }
            }
        }];
    }

    /* Function translates the string into the locale of browser */
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.SEND_EMAIL = localizationService.instant("SEND_EMAIL");
        this.SEND_SMS = localizationService.instant("SEND_SMS");
        this.FULL_NAME = localizationService.instant("FULL_NAME");
    }

    /*
    * @name: getSmsCheckboxes
    * @desc: return all checkboxes references array
    * @return : array
    * */
    public getSmsCheckboxes(): any {
        return this.sendSmsCheckboxes;
    }

    /*
     * @name: getSmsCheckboxes
     * @desc: return all checkboxe's references array
     * @return : array
     * */
    public getEmailCheckboxes(): any {
        return this.sendEmailCheckboxes;
    }

    /*
    * @name: setSmsCheckboxes
    * @desc: set checkboxes references array
    * @param : array
    * */
    public setSmsCheckboxes(arr:any): void {
        this.sendSmsCheckboxes = arr;
    }

    /*
     * @name: setSmsCheckboxes
     * @desc: set checkboxe's references array
     * @param : array
     * */
    public setEmailCheckboxes(arr:any): void {
        this.sendEmailCheckboxes = arr;
    }
}