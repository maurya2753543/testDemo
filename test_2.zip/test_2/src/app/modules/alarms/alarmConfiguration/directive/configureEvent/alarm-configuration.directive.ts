import { Component, Input } from "@angular/core";
import { ALARM_SEVERITY, ALL, AUTO_CLEAR, GENERATE_ALARM, LOG_EVENT, NONE, SEND_NOTIFICATION } from "../../../../../constant/app.constants";
import { Grid } from "../../../../../shared/ag-grid.options";
import { LocaleDataService } from "../../../../../shared/locale.data.service";
import {ShowAlert} from "../../../../../utilities/showAlert";
import { AlarmConfigurationDataService } from "../../alarm-configuration.data.service";
import { AlarmSettings, AlarmSettingsList, UserNotification } from "../../models/alarmsettings.model";
import { AlarmConfigColumnDefinitionService } from "./alarm-config.column-defination";
import {map, catchError} from "rxjs/operators";
let vm: any;
// The original implementation of this component relied on it being destroyed and recreated every time data changed. I've hacked together some
// fixes so it can behave in a more mutable way, but it may need some additional cleanup. A lot of things might be simplified if we directly
// use the ag-grid-component instead of our grid-component wrapper.
@Component({
    selector: "alarm-config-directive",
    templateUrl: "alarm-configuration.directive.html"
})
export class AlarmConfigurationDirective {

    private alarmConfigColumnDefinitionService: AlarmConfigColumnDefinitionService;
    private alarmNotificationGrid = new Grid();
    private showConfigurationOptions: boolean = false;
    private showHideFilter: boolean = false;
    private buttonKeys: any[];
    private userNotifications: any;
    private userNotificationTableData = [];
    private groupFilter;

    private colDefs;
    private isLogEvent: boolean = false;
    private isGenerateAlarm: boolean = false;
    private isSendNotification: boolean = false;
    private showMessage: boolean = false;
    public clickeditemdisplay: boolean =true ;
    private isLogEventVisible: boolean = false;
    private isLogEventReadOnly: boolean = false;
    private isGenerateAlarmVisible: boolean = false;
    private isSendNotificationVisible: boolean = false;
    private isAlarmSeverityVisible: boolean = false;
    public isLoaded: boolean = false;
    private groupOptions: any;
    private isGenerateAlarmReadOnly: boolean = false;
    private isSendNotificationReadOnly: boolean = false;
    private isAutoClearVisible: boolean = false;
    private isAutoClearReadOnly: boolean = false;

    private isOtuEvent: boolean = false;

    @Input() private alarmName: any = { "key": "", "value": "" };
    @Input() private deviceType: string = "";

    private _alarmSettingsList: AlarmSettingsList;
    public get alarmSettingsList() { return this._alarmSettingsList; }
    @Input() public set alarmSettingsList(value: AlarmSettingsList) {
        if (value == null) return;
        this.isLoaded = true;
        this._alarmSettingsList = value;
        this.handleAlarmSetting(value);
        this.userNotifications = value.userNotificationList;
        this.filterBySelectedGroup(this.groupFilter || this.ALL);
    }
    private alarmTableGroup: any;
    private readonly options = this.alarmConfigurationDataService.getUserAlarms()
    .pipe(map(userDetails => {
        let options = userDetails.allGroups.split(",");
        let eventsArray = [];
        for (var i = 0; i < options.length; i++) {
            eventsArray.push({ name: options[i] });
        }
        eventsArray[0].name = this.ALL;
        return eventsArray;
    }))

    private SHOW_FILTER: string;
    private HIDE_FILTER: string;
    private ENABLE_ALL_SEND_EMAIL: string;
    private ENABLE_ALL_SEND_SMS: string;
    private FILTER_GROUP: string;
    private ALL: string;

    private logObject: AlarmSettings;
    private generateAlarmObject: AlarmSettings;
    private sendNotificationObject: AlarmSettings;
    private autoClearObject: AlarmSettings;
    private autoClearModel: boolean;

    private alarmSeverityObject: any;
    private alarmSeverityObjectValue: any;

    constructor(private alarmConfigurationDataService: AlarmConfigurationDataService, private localeDataService: LocaleDataService, private showAlert: ShowAlert) {
        vm = this;
        this.alarmConfigColumnDefinitionService = new AlarmConfigColumnDefinitionService(localeDataService, alarmConfigurationDataService);
        this.translateLocaleString();
        this.buttonKeys = [
            { name: this.ENABLE_ALL_SEND_EMAIL, tabType: 'ALARM_CONFIG', settingDisable: true },
            { name: this.ENABLE_ALL_SEND_SMS, tabType: 'ALARM_CONFIG', settingDisable: true }
        ];
        this.alarmConfigColumnDefinitionService.callBackFun = this.enableDisableButton;
    }

    ngOnInit() {
        //this.alarmConfigurationDataService.getAlarmDetails(this.deviceType , this.alarmName.key).subscribe(this.onNext.bind(this), this.onError.bind(this));
        this.colDefs = this.alarmConfigColumnDefinitionService.getAlarmTableColDefs();
        //this.revertValueSubscribe();
        this.enableDisableSave();
        this.alarmConfigurationDataService.showItem.subscribe((res)=>{
          this.clickeditemdisplay= res;
        });
    }

    /*
    * @name: onSuccess
    * @desc: call from AlarmConfigurationDataService after getting Type of Device List
    * @param: object => AlarmConfig Object
    * */
    /*/onNext(object: any): void {
        let alarmSettingsList: AlarmSettingsList = object;
        this.handleAlarmSetting(alarmSettingsList);
        this.displayData(alarmSettingsList);
        this.alarmConfigurationDataService.getUserAlarms().subscribe(this.getUserList.bind(this), this.onError.bind(this));
    }

    private getUserList( userDetails : UserDetails ) : void {
        let options = userDetails.allGroups.split(",");
        let EventsArray = [];
        for(var i=0;i<options.length;i++){
            EventsArray.push({ name: options[i]});
        }
        EventsArray[0].name = this.ALL;
        this.options = EventsArray;

    }

    private displayData( alarmSettingsList : AlarmSettingsList ) : void {
        this.alarmTableData = alarmSettingsList.userNotificationList;
    }*/

    /*
     * @name: onError
     * @desc: used to handle error of api response
     * @param: value=> error code from server
     * */
    /*onError(error): void {
        this.isLoaded = true;
        this.alarmConfigurationDataService.setLoading(false);
        this.showAlert.showErrorAlert(error);
    }*/

    /*
     * @name: handleAlarmSetting
     * @desc: used to handle success of api responce contains action to be perform on api success
     * @param: value=> data from server
     * */
    private handleAlarmSetting(alarmSetting: AlarmSettingsList): void {
        let settingsByName = alarmSetting.reduce((map, alarmSetting) => {
            map[alarmSetting.name] = alarmSetting;
            return map;
        }, {});

        this.logObject = settingsByName[LOG_EVENT];
        this.isLogEvent = this.logObject && this.logObject.value == 'true';
        this.isLogEventReadOnly = this.logObject && this.logObject.isReadOnly;

        this.generateAlarmObject = settingsByName[GENERATE_ALARM];
        this.isGenerateAlarmVisible = !!this.generateAlarmObject;
        this.alarmSeverityObjectValue = this.generateAlarmObject && this.generateAlarmObject.value;
        this.isGenerateAlarm = this.alarmSeverityObjectValue && this.alarmSeverityObjectValue != NONE;
        this.isGenerateAlarmReadOnly = this.generateAlarmObject && this.generateAlarmObject.isReadOnly;

        if(settingsByName[ALARM_SEVERITY]) {
            this.alarmSeverityObject = settingsByName[ALARM_SEVERITY];
            this.alarmSeverityObjectValue = this.alarmSeverityObject.value || this.alarmSeverityObjectValue;
        }
        else {
            this.alarmSeverityObject = ['WARNING', 'MINOR', 'MAJOR', 'CRITICAL'];
        }
        this.sendNotificationObject = settingsByName[SEND_NOTIFICATION];
        this.isSendNotificationVisible = !!this.sendNotificationObject;
        this.isSendNotificationReadOnly = this.sendNotificationObject && this.sendNotificationObject.isReadOnly;
        this.isSendNotification = this.sendNotificationObject && this.sendNotificationObject.value == 'true';
        this.showConfigurationOptions = this.isSendNotification;

        this.autoClearObject = settingsByName[AUTO_CLEAR];
        this.isAutoClearVisible = !!this.autoClearObject;
        this.autoClearModel = this.autoClearObject && this.autoClearObject.value == 'true';
        this.isAutoClearReadOnly = this.autoClearObject && this.autoClearObject.isReadOnly;

        this.alarmConfigurationDataService.setLoading(false);
    }

    /* flag to show and hide send notification table and button */
    private showOptions(): void {
        this.showConfigurationOptions = this.showConfigurationOptions ? false : true;
    }

    /* flag to show and hide filter option */
    private showhideFilterOption(): void {
        this.showHideFilter = this.showHideFilter ? false : true;
    }

    /*
    * @name: notifyGridReadyAlarmConfig
    * @desc: event handler method invoked when ag-grid is ready
    * */
    private notifyGridReadyAlarmConfig(event): void {
        this.alarmNotificationGrid.api.setColumnDefs(this.colDefs);
        this.alarmNotificationGrid.api.setSideBarVisible(false);
        /* disable button if user data not avaiable else enable */
        if (this.userNotifications && this.userNotifications.length === 0) {
            this.buttonKeys[0].settingDisable = this.buttonKeys[1].settingDisable = true;
        } else {
            this.buttonKeys[0].settingDisable = this.buttonKeys[1].settingDisable = false;
        }
        this.enableDisableButton();
        this.alarmNotificationGrid.api.setRowData(this.userNotificationTableData);
        this.alarmNotificationGrid.api.sizeColumnsToFit();
    }

    /*
     * @name: getSelectedGroup
     * @desc: used to get valued from filter dropdown
     * @param: value=> dropdownselected value
     * */
    private filterBySelectedGroup(value) {
        this.groupFilter = value;
        let filteredTableData = [];
        this.alarmConfigColumnDefinitionService.setSmsCheckboxes([]);
        this.alarmConfigColumnDefinitionService.setEmailCheckboxes([]);
        if (value) {
            if (value == this.ALL) {
                filteredTableData = this.userNotifications;
            } else {
                for (let i = 0; i < this.userNotifications.length; i++) {
                    let userNotification: UserNotification = this.userNotifications[i];
                    if (userNotification.groupList && userNotification.groupList.length > 0) {
                        for (let j = 0; j < userNotification.groupList.length; j++) {
                            if (userNotification.groupList[j] == value) {
                                filteredTableData.push(this.userNotifications[i]);
                                break;
                            }
                        }
                    }
                }
            }
            this.userNotificationTableData = filteredTableData;
            if(this.alarmNotificationGrid.api != null) {
                this.alarmNotificationGrid.api.setRowData(filteredTableData);
            }

            this.enableDisableButton();
        }
    }

    /*
    * @name: translateLocaleString
    * @desc: Function translates the string into the locale of browser
    * */
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.SHOW_FILTER = localizationService.instant("SHOW_FILTER");
        this.HIDE_FILTER = localizationService.instant("HIDE_FILTER");
        this.ENABLE_ALL_SEND_EMAIL = localizationService.instant('ENABLE_ALL_SEND_EMAIL');
        this.ENABLE_ALL_SEND_SMS = localizationService.instant('ENABLE_ALL_SEND_SMS');
        this.FILTER_GROUP = localizationService.instant('FILTER_GROUP');
        this.ALL = localizationService.instant(ALL);
    }

    /*
     * @name: chkLogEventChange
     * @desc: event method invoked on change event of Log Check box
     * */
    private chkLogEventChange($event): void {
        this.logObject.setValue($event);
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
     * @name: chkLogEventChange
     * @desc: event method invoked on change event of Generate Check box
     * */
    private chkGenerateAlarm($event): void {
        let val: any = NONE;
        if ($event) {
            if (this.generateAlarmObject.getValue() == NONE) {
                let serverValue = this.generateAlarmObject.getServerValue();
                if (serverValue && serverValue != NONE) {
                    val = serverValue;
                } else if (serverValue && serverValue == NONE) {
                    val = this.alarmSeverityObject[0];
                }
            }
        }
        this.isAutoClearVisible = this.autoClearObject ? $event : this.isAutoClearVisible;
        this.alarmSeverityObjectValue = val;
        this.generateAlarmObject.setValue(val);
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
     * @name: alarmSeverityChange
     * @desc: event method invoked on change event of Generate Combo box
     * */
    private alarmSeverityChange(value): void {
        this.alarmSeverityObjectValue = value;
        this.generateAlarmObject.setValue(value);
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
     * @name: sendNotificationChange
     * @desc: event method invoked on change event of send Notification Check box
     * */
    private sendNotificationChange(value): void {
        this.sendNotificationObject.setValue(value);
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
    * @name: autoClearChange
    * @desc: event method invoked on change event of Auto Clear Check box
    * */
    private autoClearChange(value): void {
        this.autoClearObject.setValue(value);
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /**
     * @name: revertValueSubscribe
     * @desc: Called when user press cancel key
     */
    private revertValueSubscribe() {
        this.alarmConfigurationDataService.btnCancelSubject_click.subscribe((res) => {
            vm.isLogEvent = vm.logObject && vm.logObject.getValue();
            vm.isGenerateAlarm = vm.generateAlarmObject && vm.generateAlarmObject.getValue() != NONE;
            vm.isSendNotification = vm.SendNotificationObject && vm.SendNotificationObject.getValue()=="true";
            vm.showConfigurationOptions = vm.isSendNotification;
            vm.alarmSeveritObjectValue = vm.generateAlarmObject && vm.generateAlarmObject.getValue();
            if(vm.alarmConfigColumnDefinitionService) {
                let chks: any = vm.alarmConfigColumnDefinitionService.getSmsCheckboxes();
                for (let i = 0; i < chks.length; i++) {
                    chks[i].object.cancel();
                    chks[i].checkbox.checked = chks[i].object.getSmsValue();
                }

                chks = vm.alarmConfigColumnDefinitionService.getEmailCheckboxes();
                for (let i = 0; i < chks.length; i++) {
                    chks[i].object.cancel();
                    chks[i].checkbox.checked = chks[i].object.getEmailValue();
                }
                vm.enableDisableButton();
            }
        });
    }


    private notifyActionEmitter($event) {
        switch ($event.event.name) {
            case this.ENABLE_ALL_SEND_SMS:
                this.notifyEnableSMS();
                break;
            case this.ENABLE_ALL_SEND_EMAIL:
                this.notifyEnableEMAIL();
                break;
            default:
                this.filterBySelectedGroup($event.event.name);
        }
    }

    /*
    * @name: notifyEnableSMS
    * @desc: event listner method onvoked wehn click on 'Enable All SMS' Button
    * */
    private notifyEnableSMS() {
        let chks: any = this.alarmConfigColumnDefinitionService.getSmsCheckboxes();
        let tableData: any = [];
        for (let i = 0; i < chks.length; i++) {
            chks[i].checkbox.checked = true;
            chks[i].object.setSmsValue(true);
        }
        tableData = vm.userNotificationTableData;
        for (let i = 0; i < tableData.length; i++) {
            tableData[i].notifySMS = tableData[i].isSmsSupported ? true : tableData[i].notifySMS;
        }
        this.enableDisableButton();
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
     * @name: notifyEnableEMAIL
     * @desc: event listner method onvoked wehn click on 'Enable All Email' Button
     * */
    private notifyEnableEMAIL() {
        let chks: any = this.alarmConfigColumnDefinitionService.getEmailCheckboxes();
        let tableData: any = [];
        for (let i = 0; i < chks.length; i++) {
            chks[i].checkbox.checked = true;
            chks[i].object.setEmailValue(true);
        }
        tableData = vm.userNotificationTableData;
        for (let i = 0; i < tableData.length; i++) {
            tableData[i].notifyEmail = tableData[i].isEmailSupported ? true : tableData[i].notifyEmail;
        }
        this.enableDisableButton();
        this.alarmConfigurationDataService.enableDisableSaveButton();
    }

    /*
    * @name: enableDisableButton
    * @desc: used to enable/disable button for notify email/sms & it also callback function for checkbox change event
    * */
    private enableDisableButton(): void {
        let tableData = vm.userNotificationTableData;
        let notifySMS: boolean = true, notifyEmail: boolean = true;
        if (tableData && tableData.length > 0) {
            for (let i = 0; i < tableData.length; i++) {
                notifySMS = tableData[i].notifySMS;
                notifySMS = tableData[i].isSmsSupported ? notifySMS : true;
                if (!notifySMS) break;
            }
            for (let i = 0; i < tableData.length; i++) {
                notifyEmail = tableData[i].notifyEmail;
                notifyEmail = tableData[i].isEmailSupported ? notifyEmail : true;
                if (!notifyEmail) break;
            }
        }
        vm.buttonKeys[0].settingDisable = notifyEmail;   //Email
        vm.buttonKeys[1].settingDisable = notifySMS;     //sms
    }

    /*
    * @name: enableDisableSave
    * @desc: used to enableDisableSave enableDisableSave subject to show/hide Toast
    * */
    private enableDisableSave() {
        this.alarmConfigurationDataService.showAlertSubject.subscribe((flag) => {
            // this.formDisabled = data.isDisabled;
            this.showMessage = flag;
        })
    }

}