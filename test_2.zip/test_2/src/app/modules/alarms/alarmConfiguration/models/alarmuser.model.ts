 import {ALL} from "../../../../constant/app.constants";
 /**
 * Created by B.Kasturiwale on 15-06-2017.
 */

export class UserDetails extends Array{

    public allGroups : string = ALL + ",";

    constructor(jsonList){
        super();
        if(jsonList && jsonList.users) {
            for (let i = 0; i < jsonList.users.length; i++) {
                let alarmUser : AlarmUser = new AlarmUser(jsonList.users[i]);
                this.push(alarmUser);
            }
        }

        if(jsonList && jsonList.groups){

            for(let i = 0; i < jsonList.groups.length; i++) {
                for(let j = 0; j < jsonList.groups[i].usersIdList.length; j++) {
                    for(let k = 0; k < this.length; k++) {
                        let alarmUser : AlarmUser = this[k];
                        if(jsonList.groups[i].usersIdList[j] == alarmUser.userId) {
                            alarmUser.alarmGroup = new AlarmGroup(jsonList.groups[i]);
                            break;
                        }
                    }
                }
                this.allGroups += jsonList.groups[i].groupName + ",";    //concat group name in single string
            }
            this.allGroups = this.allGroups.substr(0, this.allGroups.length - 1);  //remove last character from string i.e. ,


        }

    }
}

export class AlarmUser{

    public userId : number;
    public fullName : string;

    public notifyEmail : boolean;
    public notifySMS : boolean;

    public alarmGroup : AlarmGroup;

    public jsonData : any;


    constructor(jsonData){
        this.jsonData = jsonData;
        this.userId = jsonData.userId;
        this.fullName = jsonData.fullName;
        this.notifyEmail = jsonData.notifyEmail;
        this.notifySMS = jsonData.notifySMS;
    }


}

 export class AlarmGroup {

     public groupId: string;
     public groupName: string;
     public userIdList : number[];

     constructor(jsonData) {
         this.groupId = jsonData.groupId;
         this.groupName = jsonData.groupName;
         this.userIdList = jsonData.usersIdList;    
     }

 }
