 import {UserDetails, AlarmUser} from "./alarmuser.model";
 /**
 * Created by B.Kasturiwale on 15-06-2017.
 */

export class AlarmSettingsList extends Array{

    public isComponentValid : boolean = true;
    public userNotificationList : Array<UserNotification> = new Array();

     private userNotificationJSON : any;

    constructor(jsonList){
        super();
        if(jsonList && jsonList.alarmSettingDetails){
            for(let i = 0 ; i < jsonList.alarmSettingDetails.length ; i++){
                let alarmSettings : AlarmSettings = new AlarmSettings(jsonList.alarmSettingDetails[i]);
                this.push(alarmSettings);
            }
        }

        if(jsonList && jsonList.userNotificationResponses){
            this.userNotificationJSON = jsonList.userNotificationResponses;
            for(let i = 0 ; i < jsonList.userNotificationResponses.length ; i++){
                let userNotification : UserNotification = new UserNotification(jsonList.userNotificationResponses[i] , false);
                this.userNotificationList.push(userNotification);
            }
        }
    }

    public updateUserDetails(userDetails : UserDetails) : void {
        for(let i = 0 ; i < userDetails.length ; i++){
            let alarmUser : AlarmUser = userDetails[i];
            let isUpdated : boolean = false;
            for(let j = 0 ; j < this.userNotificationList.length ; j++){
                let userNotification : UserNotification = this.userNotificationList[j];
                if(alarmUser.userId == userNotification.userId){
                    userNotification.update(alarmUser.jsonData);
                    if(alarmUser.alarmGroup) {
                        let groupName = alarmUser.alarmGroup.groupName;
                        userNotification.updateGroup(groupName);
                    }
                    isUpdated = true;
                }
            }
            if(!isUpdated){
                let userNotification : UserNotification = new UserNotification(alarmUser.jsonData , true );
                if(alarmUser.alarmGroup) {
                    let groupName = alarmUser.alarmGroup.groupName;
                    userNotification.updateGroup(groupName);
                }
                this.userNotificationList.push(userNotification);
            }
        }

        this.updateForGroup(userDetails);
    }

    private updateForGroup(userDetails : UserDetails){
        for(let i = 0 ; i < this.userNotificationList.length ; i++){
            let userNotification : UserNotification = this.userNotificationList[i];
            for(let j = 0 ; j < userDetails.length ; j++){
                let alarmUser : AlarmUser = userDetails[j];
                if(alarmUser.alarmGroup && alarmUser.alarmGroup.userIdList && alarmUser.alarmGroup.userIdList.length > 0){
                    for(let k = 0 ; k < alarmUser.alarmGroup.userIdList.length ; k++){
                        let userId = alarmUser.alarmGroup.userIdList[k];
                        if(userId == userNotification.userId){
                            userNotification.updateGroup(alarmUser.alarmGroup.groupName);
                        }
                    }
                }


            }
        }
    }

     public getuserNotificationJSON() : any {
         return this.userNotificationJSON;
     }
}

export class AlarmSettings{

    public value : string = "";
    public serverValue : string = "";

    public name : string = "";
    public defaultValue : string = "";

    public options : SettingsOptions;

    public isReadOnly : boolean = false;
    public isModified : boolean = false;
    public isValid : boolean = true;
    private isOptional:boolean = false;

    constructor(jsonData){


        this.name = jsonData.name;
        this.value = jsonData.value;

        this.defaultValue = jsonData.defaultValue;

        if(jsonData.options){
            this.options = new SettingsOptions(jsonData);
        }

        this.serverValue = jsonData.value;
        this.isReadOnly = jsonData.readOnly;

    }

    public setValue(value:string) : void {
        value += "";
        if(this.value != value){
            this.value = value;
            this.isModified = true;
        }
        if(this.serverValue == value) {
            this.isModified = false;
        }
    }

    public getValue():any {
        return this.value;
    }

    public getServerValue():string {
        return this.serverValue;
    }

    public isOriginalValue() : boolean {
        return (this.serverValue == this.value);
    }

    public setOptional(flag:boolean): void {
        this.isOptional = flag;
    }

    public getOptional(): boolean {
        return this.isOptional;
    }

    //Create a json object
    public getJSON() : string {

        let alarmSetting ={
            "name": this.name,
            "value": this.value,
        }
        this.serverValue = this.value;
        return JSON.stringify(alarmSetting);
    }

    //Reset the value with the value received from server
    public cancel() : void {
        this.value = this.serverValue;
        this.isValid = true;
        this.isModified = false;
    }

    public setSavedValue(){
        this.serverValue = this.value;
        this.isModified = false;
    }
}

 export class SettingsOptions{

     public serverOptions : any;
     public displayOptions : any;

     constructor(jsonData){
         this.serverOptions = jsonData.options.split(",");
         this.displayOptions = jsonData.options.split(",");
         for(let i = 0; i < this.displayOptions.length; i++) {
             this.serverOptions[i] = this.serverOptions[i].trim();
             this.displayOptions[i] = this.displayOptions[i].trim();
         }
     }

 }

 export class UserNotification{

     public userId : number;
     public notifyEmail: boolean = false;
     private serverNotifyEmail: boolean = false;
     public notifySMS : boolean = false;
     private serverNotifySMS: boolean = false;
     public isSmsModified:boolean = false;
     public isEmailModified:boolean = false;

     public isSmsSupported:boolean ;
     public isEmailSupported:boolean ;

     public groupId : string;

     public fullName : string;

     public groupList : string[] = [];


     constructor(jsonData : any , isFromUserList : boolean){

         this.userId = jsonData.userId;

         if(isFromUserList){
             this.fullName = jsonData.fullName;
             this.isSmsSupported = jsonData.notifySMS;
             this.isEmailSupported = jsonData.notifyEmail;
         }else{
             this.notifyEmail = jsonData.notifyEmail;
             this.notifySMS = jsonData.notifySMS;

             this.serverNotifyEmail = this.notifyEmail;
             this.serverNotifySMS = this.notifySMS;
         }
     }

     public update(jsonData ) : void {
         this.fullName = jsonData.fullName;
         this.isSmsSupported = jsonData.notifySMS;
         this.isEmailSupported = jsonData.notifyEmail;
     }

     public updateGroup( groupName : string) : void {
         this.groupList.push(groupName);
     }

     public cancel() : void {
         this.notifySMS = this.serverNotifySMS;
         this.notifyEmail = this.serverNotifyEmail;
         this.isSmsModified = false;
         this.isEmailModified = false;
     }

     public setSavedValue(){
         this.serverNotifySMS = this.notifySMS;
         this.serverNotifyEmail = this.notifyEmail;
     }

     public setSmsValue(flag:boolean): void {
         if(this.notifySMS != flag) {
             this.notifySMS = flag;
             this.isSmsModified = true;
         }
         if(flag == this.serverNotifySMS) {
             this.isSmsModified = false;
         }
     }

     public setEmailValue(flag:boolean): void {
         if(this.notifyEmail != flag) {
             this.notifyEmail = flag;
             this.isEmailModified = true;
         }
         if(flag == this.serverNotifyEmail) {
             this.isEmailModified = false;
         }
     }

     public getSmsValue(): boolean {
         return this.notifySMS;
     }

     public getEmailValue(): boolean {
         return this.notifyEmail;
     }

     public getJSON() : string {

         let alarmSetting ={
             "userId": this.userId,
             "notifyEmail": this.notifyEmail,
             "notifySMS": this.notifySMS
         }
         this.setSavedValue();
         return JSON.stringify(alarmSetting);
     }

 }
