import { Component, Input } from '@angular/core';
import { BehaviorSubject, Observable, Subject, merge } from 'rxjs';
import { AlarmConfigurationDataService } from "../alarm-configuration.data.service";
import { filter, switchMap, mapTo, startWith, map, distinctUntilChanged, publishReplay, refCount, withLatestFrom } from 'rxjs/operators';
import { retry } from 'rxjs-compat/operator/retry';

@Component({
    selector: "alarm-event-config",
    templateUrl: "alarm-event-config.html"
})
export class AlarmEventConfigComponent {
    private deviceType = new BehaviorSubject<string>('');
    private selectedDevice:any;
    @Input('deviceType') public set deviceTypeSetter(value: string) {
        this.selectedDevice = value;
        this.deviceType.next(value);
    }
    
    private lists = this.deviceType.pipe(filter(d => d != null),switchMap(deviceType => this.alarmConfigurationDataService.getAlarmListArray(deviceType)));
    public isListLoaded = this.lists.pipe(mapTo(true),startWith(false));
    public _alarmSelect = new Subject<any>();
    public alarmName = merge(this._alarmSelect.pipe(map(a => a.value)), this.lists.pipe(map(l => l[0]), distinctUntilChanged(), publishReplay(1), refCount()));
    public alarmNameDisplay = merge(this._alarmSelect.pipe(map(a => a.key)), this.lists.pipe(map(l => l[0]), distinctUntilChanged(), publishReplay(1), refCount()));
    public name: string;
    public alarmsSettingsList: any = null;
    public alarmsSettingsList$: any = this.alarmNameDisplay
    .pipe(withLatestFrom(this.deviceType),
    publishReplay(2),
    refCount(),
    switchMap(alarmDevice => this.alarmConfigurationDataService.getAlarmDetails(alarmDevice[1], alarmDevice[0])))

    constructor(private alarmConfigurationDataService: AlarmConfigurationDataService) {}

    ngOnInit(){
        this.alarmsSettingsList$.subscribe(response => {
            this.alarmsSettingsList = response;
        })
        this.alarmConfigurationDataService.deviceAlarmResponseEvents.subscribe(res => {
            if(!this.alarmsSettingsList){
                this.alarmsSettingsList = res['alarms'];
            }
        })
    }

    /**
    *  Triggered when a user selects a new event type from the event list.
    */
    getSelectedValue(data): void {
        this.name = data.value;
        this._alarmSelect.next(data);
        this.alarmConfigurationDataService.showAlertSubject.next(false);
    }
}
