import { Injectable } from "@angular/core";
import { Observable, Subject, empty } from "rxjs";
import { TSMap } from "typescript-map";
import { ShowAlert } from "../../../utilities/showAlert";
import { AlarmHttpService } from "../alarm.http.service";
import { AlarmSettings, AlarmSettingsList, UserNotification } from "./models/alarmsettings.model";
import { UserDetails } from "./models/alarmuser.model";
import { ThresholdService } from '../../shared/threshold.service';
import { map, publishReplay, refCount, take, repeatWhen, combineLatest, scan, startWith, filter, distinctUntilChanged, withLatestFrom, mergeMap, exhaustMap } from "rxjs/operators";

@Injectable()
export class AlarmConfigurationDataService {
    private loading: boolean = false;
    public btnCancelSubject_click: Subject<any> = new Subject<any>();
    public enableDisableSave: Subject<any> = new Subject<any>();
    public showAlertSubject: Subject<any> = new Subject<any>();
    public showItem: Subject<any> = new Subject<any>();

    private deviceList: Observable<any[]>;
    public userAlarms: Observable<UserDetails>;

    constructor(private showAlert: ShowAlert, private alarmHttpService: AlarmHttpService,
        private thresholdService: ThresholdService) { }

    private deviceTypeListRequest = this.alarmHttpService.getDeviceTypeList()
        .pipe(
            map(response => { return response }),
            publishReplay(1),
            refCount()
        )
    /**
     * Returns the list of device names.
     */
    public getDeviceTypeList(): Observable<string[]> {
        if (this.deviceList == null) {
            this.deviceList = this.deviceTypeListRequest
                .pipe(
                    map(deviceTypeList => { return deviceTypeList.elementTypeList }),
                    publishReplay(1),
                    refCount()
                )
        }
        return this.deviceList;
    }

    /**
     * Returns a list of alarm names for the specified device type.
     * @param deviceType The device to get the alarm names for
     */
    public getAlarmListArray(deviceType: string): Observable<any[]> {
        return this.deviceTypeListRequest
            .pipe(
                map(deviceTypeList => {
                    let deviceList = deviceTypeList.elementTypeList;
                    for (let i = 0; i < deviceList.length; i++) {
                        if (deviceList[i] !== deviceType) continue;
                        if (deviceType == 'RPMPort') {
                            let arrROMPORT = [];
                            this.thresholdService.getRpmPortSequence().forEach(rpmSeq => {
                                deviceTypeList.elementTypeEventTypeEnumMap[deviceList[i]].forEach(rpmobj => {
                                    if (rpmobj == rpmSeq) {
                                        arrROMPORT.push(rpmobj)
                                    }
                                });
                            });
                            return arrROMPORT;
                        } else {
                            return deviceTypeList.elementTypeEventTypeEnumMap[deviceList[i]];
                        }
                    }
                    return null;
                })
            )
    }

    /**
     * Get user-group alarms. Still not 100% clear what this is used for, but it is somehow used to populate alarm details
     * from the buildAlarmDetailsRequest with user-specific and group-specific information.
     */
    public getUserAlarms(): Observable<UserDetails> {
        if (this.userAlarms == null) {
            this.userAlarms = this.alarmHttpService.getAlarmTableDetails()
                .pipe(
                    repeatWhen(() => this.btnCancelSubject_click)              // reset on cancel
                    , map((userList) => new UserDetails(userList))        // convert to UserDetails structure
                    , publishReplay(1)                                           // cache results for all subscribers
                    , refCount()
                )  // send user-alarms request

        }

        return this.userAlarms;
    }

    /**
     * Builds a request to the server to get alarm configuratoin details for the specified device type and alarm name.
     */
    private buildAlarmDetailsRequest(deviceType, alarmName): Observable<AlarmSettingsList> {
        return this.alarmHttpService.getAlarmDetails(deviceType, alarmName)
            .pipe(
                repeatWhen(() => this.btnCancelSubject_click)
                , combineLatest(this.getUserAlarms())
                , map((result) => {
                    const alarmList = result[0];
                    const userAlarms = result[1];
                    let alarmSettingsList: AlarmSettingsList = new AlarmSettingsList(alarmList);
                    alarmSettingsList.updateUserDetails(userAlarms);
                    return alarmSettingsList;
                })
                , publishReplay(1)
                , refCount()
            )
    }

    private deviceAlarmRequestEvents = new Subject<{ device: string, alarm: string }>();
    public deviceAlarmResponseEvents = new Subject<{ device: string, alarm: string, alarms: AlarmSettingsList }>();
    public alarmDetailsState: Observable<{ [deviceType: string]: { [alarmName: string]: AlarmSettingsList } }>

    /**
     * Returns the configuration for the specified device and alarm.
     * @param deviceType The device type to get alarm configuration for
     * @param alarmName The alarm subcategory to get the configuration for
     */
    public getAlarmDetails(deviceType: string, alarmName: string): Observable<AlarmSettingsList> {
        if (this.alarmDetailsState == null) {
            // This is sort of an equivalent of a redux "store" (such as ngrx-store) where the state of the alarms map is defined by the stream of alarm request-responses.
            // Here we are caching all requests for alarm details in a dictionary of { deviceType: { alarmName: AlarmSettingsList } }
            (this.alarmDetailsState as any) = this.deviceAlarmResponseEvents
                .pipe(
                    scan((alarmMap, alarmResponse) => {
                        const deviceAlarms = alarmMap[alarmResponse.device];
                        const mergedDeviceAlarms = {};

                        if (deviceAlarms == null) {
                            mergedDeviceAlarms[alarmResponse.device] = {};
                            mergedDeviceAlarms[alarmResponse.device][alarmResponse.alarm] = alarmResponse.alarms;
                        }
                        else { // always overwrite existing device alarm settings with latest from server
                            let alarms = {};
                            alarms[alarmResponse.alarm] = alarmResponse.alarms;
                            mergedDeviceAlarms[alarmResponse.device] = Object.assign({}, deviceAlarms, alarms);
                        }

                        return Object.assign({}, alarmMap, mergedDeviceAlarms);
                    })
                    , startWith({})
                    , publishReplay(1)
                    , refCount()
                )

            // This is sort of the equivalent of ngrx-store's "Effect" plugin. Each time getAlarmDetails is called, it is treated
            // as an "Event" to request the data. That event is then turned into a request - the result of which is pushed onto the stream
            // of deviceAlarmResponseEvents. We use mergeMap because when the request is refreshed (i.e, the user presses the cancel button)
            // we want to update the state with the lateste values.
            this.deviceAlarmRequestEvents
                .pipe(withLatestFrom(this.alarmDetailsState),
                    mergeMap(value => {
                        const request = value[0];
                        const alarmsMap = value[1];

                        if (alarmsMap[request.device] && alarmsMap[request.device][request.alarm])
                            //  return Observable.empty<{ device: string, alarm: string, alarms: AlarmSettingsList }>();
                            return empty();
                        return this.buildAlarmDetailsRequest(request.device, request.alarm)
                            .pipe(
                                map(alarms => ({
                                    device: request.device,
                                    alarm: request.alarm,
                                    alarms: alarms
                                }))
                            )
                    }))
                .subscribe(alarmResponse => this.deviceAlarmResponseEvents.next(alarmResponse));
        }

        this.deviceAlarmRequestEvents.next({ device: deviceType, alarm: alarmName });
        return this.alarmDetailsState
            .pipe(
                filter(alarmMap => alarmMap[deviceType] != null && alarmMap[deviceType][alarmName] != null)
                , map(alarmMap => alarmMap[deviceType][alarmName])
                , distinctUntilChanged()
            )
    }

    /*
     * @name: isLoading
     * @desc: getter of loading flag
     * */
    public isLoading(): boolean {
        return this.loading;
    }

    /*
     * @name: setLoading
     * @desc: setter for loading flag
     * */
    public setLoading(loading: boolean): void {
        this.loading = loading;
    }

    /*
    * @name: setPostData
    * @desc: event listner for Save button click event
    * */
    public setPostData(): void {        
        this.alarmDetailsState.pipe(exhaustMap(alarmSettingsMap => {
            let postData: Array<any> = new Array();
            let alarmName: string = "";
            let alarmChanges: any = [], changes: any = [], userChanges: any = [];
            Object.keys(alarmSettingsMap).forEach(key => {
                let value = alarmSettingsMap[key];
                if (value && Object.keys(value).length > 0) {
                    Object.keys(value).forEach(alarmKey => {
                        let alarmConfig: any = value[alarmKey];
                        alarmName = alarmKey;
                        if (alarmConfig && alarmConfig.length > 0) {

                            //Alarm Setting Data Handling
                            let alarmSettingLength: number = alarmConfig.length;
                            for (let i = 0; i < alarmSettingLength; i++) {
                                let alarmSetting: any = alarmConfig[i];
                                if (alarmSetting && alarmSetting.isModified) {
                                    changes.push(JSON.parse(alarmSetting.getJSON()));
                                }
                            }

                            //Alarm Table Data Handling
                            let alarmTableList: any = alarmConfig.userNotificationList;
                            if (alarmTableList && alarmTableList.length > 0) {
                                let alarmTableLength: number = alarmTableList.length;
                                for (let i = 0; i < alarmTableLength; i++) {
                                    let alarmTable: any = alarmTableList[i];
                                    if (alarmTable && (alarmTable.isEmailModified || alarmTable.isSmsModified)) {
                                        userChanges.push(JSON.parse(alarmTable.getJSON()));
                                    }
                                }
                            }
                            if (changes.length > 0 && userChanges.length > 0) {
                                alarmChanges.push({
                                    "eventType": alarmName,
                                    "alarmSettingDetails": changes,
                                    "userNotificationResponses": userChanges
                                });
                            } else if (changes.length > 0 && userChanges.length == 0) {
                                alarmChanges.push({
                                    "eventType": alarmName,
                                    "alarmSettingDetails": changes
                                });
                            } else if (changes.length == 0 && userChanges.length > 0) {
                                alarmChanges.push({
                                    "eventType": alarmName,
                                    "userNotificationResponses": userChanges
                                });
                            }
                            userChanges = [];
                            changes = [];
                        }
                    });

                    postData = alarmChanges;
                }
            });
           return this.alarmHttpService.postAlarmConfigData(postData)
        })
            ,take(1))
            .subscribe(() => {
                this.enableDisableSave.next({ isDisabled: true, showMessage: true });
                this.showAlertSubject.next(true);
            }, error => {
                this.showAlert.showErrorAlert(error);
            });
    }

    /*
     * @name: setPostData
     * @desc: event listner for Cancel button click event
     * */
    public cancel(): void {
        this.alarmDetailsState
            .pipe(take(1))
            .subscribe(alarmSettingsMap => {
                Object.keys(alarmSettingsMap).forEach(key => {
                    let alarms = alarmSettingsMap[key];
                    if (alarms && Object.keys(alarms).length > 0) {
                        Object.keys(alarms).forEach(alarmKey => {
                            let alarmConfig: AlarmSettingsList = alarms[alarmKey];
                            if (alarmConfig && alarmConfig.length > 0) {

                                //Alarm Setting Data Handling
                                for (let i = 0; i < alarmConfig.length; i++) {
                                    let alarmSetting: AlarmSettings = alarmConfig[i];
                                    if (alarmSetting && alarmSetting.isModified) {
                                        alarmSetting.cancel();
                                    }
                                }

                                //Alarm Table Data Handling
                                let alarmTableList: any = alarmConfig.userNotificationList;
                                if (alarmTableList && alarmTableList.length > 0) {
                                    let alarmTableLength: number = alarmTableList.length;
                                    for (let i = 0; i < alarmTableLength; i++) {
                                        let alarmTable: UserNotification = alarmTableList[i];
                                        if (alarmTable && (alarmTable.isEmailModified || alarmTable.isSmsModified)) {
                                            alarmTable.cancel();
                                        }
                                    }
                                }
                            }
                        });
                    }
                });
                this.btnCancelSubject_click.next(true);
                this.enableDisableSave.next({ isDisabled: true, showMessage: false });
            });
    }

    /*
    * @name: enableDisableSaveButton
    * @desc: used to check Save button should be set as enable/disable
    * */
    public enableDisableSaveButton(): void {
      this.enableDisableSave.next({ isDisabled: true, showMessage: false });
      
        this.alarmDetailsState
            .pipe(take(1))
            .subscribe(alarmSettingsMap => {
                Object.keys(alarmSettingsMap).forEach(value => {
                    let alarms = alarmSettingsMap[value];
                    if (alarms && Object.keys(alarms).length > 0) {
                        Object.keys(alarms).forEach(alarmKey => {
                            let alarmConfig: AlarmSettingsList = alarms[alarmKey];
                            if (alarmConfig && alarmConfig.length > 0) {
                                //Alarm Setting Data Handling                                
                                for (let i = 0; i < alarmConfig.length; i++) {
                                    let alarmSetting: AlarmSettings = alarmConfig[i];                                    
                                    if (alarmSetting && alarmSetting.isModified) {
                                        this.enableDisableSave.next({ isDisabled: false, showMessage: false });
                                        break;
                                    }
                                }

                                //Alarm Table Data Handling
                                let alarmTableList: any = alarmConfig.userNotificationList;
                                if (alarmTableList && alarmTableList.length > 0) {
                                    let alarmTableLength: number = alarmTableList.length;
                                    for (let i = 0; i < alarmTableLength; i++) {
                                        let alarmTable: UserNotification = alarmTableList[i];
                                        if (alarmTable && (alarmTable.isEmailModified || alarmTable.isSmsModified)) {
                                            this.enableDisableSave.next({ isDisabled: false, showMessage: false });
                                            break;
                                        }
                                    }
                                }
                            }
                        });
                    }
                });
            });
    }
}
