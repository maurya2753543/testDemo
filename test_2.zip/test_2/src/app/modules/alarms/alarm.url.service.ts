/*
 * Copyright (c) 2022 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 */

/**
 * Created by narayan.reddy on 23-06-2017.
 */

import { Injectable } from '@angular/core';
import {SharedService} from "../../shared/shared.service";
import { PATHTRAK_PATH ,ALARMS_LIMIT } from "../../constant/app.constants";

@Injectable()
export class AlarmUrlService {

    private host:string = '';

    constructor(private sharedService:SharedService) {
    }

    // obtains host ID
    private getHost():string{
        return this.sharedService.getHost() + PATHTRAK_PATH;
    }


    // obtain data for Alarm sync
    public getSyncAlarmListDataUrl(arr:any[]): string{
        let url = this.getHost() + "alarm/element?";
        url += "limit="+arr[0] ;
        url += "&mostRecentAlarmIsoDate=" + arr[1];
        url += "&totalAlarmsLastReceived=" + arr[2];

        return url;
    }

    // obtain data for Alarm initialization
    public getInitAlarmListDataUrl(): string {
        let url = this.getHost() + "alarm/element?";
        url += "limit=" + ALARMS_LIMIT ;
        return url;
    }

    // obtain list of all Alarms
    public getAllAlarmListDataUrl(arr:Array<any>): string {
        let url = this.getHost() + "alarm/element";
        if(arr[0] || arr[1]) {
            url += "?mostRecentAlarmIsoDate" + arr[0];
            url += "&totalAlarmsLastReceived"+ arr[1];
        }
        return url;
    }

    //returns clear alarm url
    public clearAllAlarmListDataUrl():string {
        let url = this.getHost() + "alarm/clear/all/element?element=1";
        return url;
    }

    //Clears selected Alarms
    public clearAllAlarmListDataByIdUrl():string {
        let url = this.getHost() + "alarm/clear";
        return url;
    }

    //obtain Threshold data
    public getThresholdUrl() {
        return this.getHost() + "settings/threshold";
    }


    //////////////// Start Alarm Configuration API //////////////////////////

    public getDeviceTypeUrl() : string {
        return this.sharedService.getHost() + "/pathtrak/api/alarm/types";
    }

    public getAlarmDetailsUrl(deviceType : string , alarmName : string) : string {
        return this.sharedService.getHost() + "/pathtrak/api/alarm/settings/" + alarmName;
    }

    public getPostAlarmConfigUrl(): string {
        return this.sharedService.getHost() + "/pathtrak/api/alarm/settings";
    }


    public getAlarmTableDetailUrl():string{
        return this.sharedService.getHost() + "/pathtrak/api/alarm/users";
    }
}
