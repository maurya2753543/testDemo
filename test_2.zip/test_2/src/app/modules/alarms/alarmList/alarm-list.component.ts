declare var require: any
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { AlarmListService } from './alarm-list.service';
import { AlarmListDataService } from './alarm-list.data.service';
import { Grid } from "../../../shared/ag-grid.options"
import { CommonStrings } from '../../../constant/common.strings';
import { Logger } from "../../../utilities/logger";
import { SweetAlert } from "../../../utilities/sweetAlert"
import { SeverityFilter } from "./severity.filter";
import { SharedService } from "../../../shared/shared.service";
import { LocaleDataService } from "../../../shared/locale.data.service";
import { WindowService } from '../../../shared/nativeProvider/window.service';
import { takeUntil} from "rxjs/operators";
//import * as moment from "moment/moment";
import { ControlMessagesService } from '../../../shared/control.messages.service';
import { AlarmListColumnDefinitionService } from "./alarm-list.column-definition.service";
import { AgGridConfigurationService } from "../../../shared/agGrid.configuration.service";
import { Observable, Subject , timer} from "rxjs";
//import { timer } from 'rxjs/observable/timer';
import { DocumentService } from "../../../shared/nativeProvider/document.service";
import {
    ALARM_DROPDOWN_OPTION_ACTION, ALARM_DROPDOWN_OPTION_CLEAR, ALARM_DROPDOWN_OPTION_EXPORT,
    ALARMS_LIMIT, ALERT_ERROR, ALERT_WARNING, RESIZE_MAXIMIZE_MODE, RESIZE_MINIMIZE_MODE, PERM_CLEAR_ALARM, REFRESH_ALARM_INTERVAL
    , INTERVAL,INTERVAL_REFRESH
} from "../../../constant/app.constants";
// import { isUndefined } from "util";
import {ShowAlert} from "../../../utilities/showAlert";
import { AuthService } from "../../../shared/auth.service";
import { TranslateService } from '@ngx-translate/core';

// let agGrid = String(require('../../../../../node_modules/ag-grid/dist/styles/ag-grid.css'));
// let agGridThemeFresh = String(require('../../../../../node_modules/ag-grid/dist/styles/theme-fresh.css'));
// let agGridThemeDark = String(require('../../../../../node_modules/ag-grid/dist/styles/theme-dark.css'));

let vm: any;


// CODE REVIEW : Remove console.logs from code.
// CODE REVIEW : Remove unwanted commented code.


@Component({
    selector: 'alarm-list',
    templateUrl: 'alarm-list.html',
})
export class AlarmListComponent implements OnInit {
    public tableData: Array<{}>;
    public alarmListGridOptions: Grid = new Grid();
    private mostRecentAlarmDate: string;
    private totalNumberOfAlarms: number = 0;
    public showAllLabel: string = '';
    public showAllLabelMob: string = '';
    private newAlarmsAvailable: boolean;
    private showAll: boolean = false;
    private alarms: Array<Object>;
    private alarmLength: number;
    private alarmsLastRefreshedTime: string;
    private internalServerErrorCount: number = 0;
    public gridTabType: string = "AlarmsExport";
    /* Localization Strings */
    private CLEAR_ALARM_TITLE: string;
    private CLEAR_ALARM_ALERT_MSG: string;
    private CLEAR_ALL_ALARM_TITLE: string;
    private CLEAR_ALL_ALARM_ALERT_MSG: string;
    private TABLE_LIST_EXPORT_ALL: string;
    private TABLE_LIST_EXPORT_SELECTED: string;
    private ALARM_TAB_SYNC_ALL: string;
    private TABLE_LIST_SHOW_ALL: string;
    private TABLE_LIST_SHOW_LESS: string;
    private TABLE_LIST_REFRESH: string;
    private TABLE_LIST_SHOWING: string;
    private TABLE_LIST_SHOWING_OF: string;
    private TABLE_LIST_ROWS: string;
    public eventKeys: Object[];
    public showAllBtn: Object[];

    public buttonKeys: any;
    
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    private alarmInterval: number = 0;

    private freshedInitiated: boolean = false;
    private CLEAR_ALARM_OPTION_YES:string;
    private CLEAR_ALARM_OPTION_NO:string;

    constructor(private sharedService: SharedService,
        private alarmListDataService: AlarmListDataService,
        private agGridConfigurationService: AgGridConfigurationService,
        private alarmListColumnDefinationService: AlarmListColumnDefinitionService,
        private alarmListService: AlarmListService,
        private localeDataService: LocaleDataService,
        private windowService: WindowService,
        private documentService: DocumentService,
        private authService: AuthService,
        private logger: Logger,
        private sweetAlert: SweetAlert,
        private controlMessagesService: ControlMessagesService,
        private translate: TranslateService,
        private showAlert: ShowAlert) {
        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
            this.getPermissionData();
            this.eventBtnUpdate();
        })
        this.showAllBtn = [];
        this.eventKeys = [];
    }
    
    // function :: on component intialize.
    ngOnInit() {
        this.translateLocaleString();
        this.eventBtnUpdate();
        document.addEventListener("visibilitychange", this.handleVisibilityChange.bind(this), false);
    }
    

    private handleVisibilityChange(): void {
        if (document.hidden) {
            this.ngUnsubscribe.next();
        } else {
            this.alarmListDataService.stopSyncAlarmsListData();
            this.freshedInitiated = false;
            this.setInitListData();  
        }
    }

    // function :: event button update on permission.
    private eventBtnUpdate(): void {
        this.eventKeys = [];
        if (this.sharedService.checkPermissions(PERM_CLEAR_ALARM)) {
            this.eventKeys = [
                { name: this.TABLE_LIST_EXPORT_SELECTED, status: "single", tabType: "ALARM_TAB" },
                { name: this.TABLE_LIST_EXPORT_ALL, status: "all", tabType: "ALARM_TAB" },
                { name: this.CLEAR_ALARM_TITLE, status: "single", tabType: "ALARM_TAB" },
                { name: this.CLEAR_ALL_ALARM_TITLE, status: "all", tabType: "ALARM_TAB" }
            ];
        } else {
            this.eventKeys = [
                { name: this.TABLE_LIST_EXPORT_SELECTED, status: "single", tabType: "ALARM_TAB" },
                { name: this.TABLE_LIST_EXPORT_ALL, status: "all", tabType: "ALARM_TAB" }
            ];
        }
    }

    // function :: get permission data.
    getPermissionData(): void {
        this.authService.permissionsCallback
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((permissionsArr) => {
                this.eventBtnUpdate();
            });
    }
    public notifyFilterChangeALARMLIST(event): void{
        this.alarmListDataService.alarmlistfilterchangedata = this.alarmListGridOptions.api.getFilterModel();
         console.log("filterchange data",this.alarmListDataService.alarmlistfilterchangedata);

    }
    // function :: method call on claer all alarms.
    private setClearAllListData(): any {
        this.alarmListDataService
            .clearAlarmsListData()
            .pipe(
                takeUntil(this.ngUnsubscribe)
            )
            .subscribe(
                this.successClearAllListData.bind(this),
            (error) => {
                this.alarmListDataService.stopSyncAlarmsListData();
                this.onError(error)
            });

    }

    // function :: success of clear all alarm.
    private successClearAllListData(response): void {
        this.alarmListDataService.stopSyncAlarmsListData();
        if (this.showAllBtn.findIndex(x => x["name"] == this.TABLE_LIST_SHOW_ALL) > -1 || this.showAllBtn.length === 0) {
            this.setInitListData()
        } else if (this.showAllBtn.findIndex(x => x["name"] == this.TABLE_LIST_SHOW_LESS) > -1) {
            this.setAllListData([undefined, undefined])
        }
    }

    // function :: notify on dropdown and button action.
    public notifyActionEmitter($event): void {
        switch ($event.event.name) {
            case this.CLEAR_ALARM_TITLE:
                this.notifyClearSelectedAlarm($event.selectedData);
                break;
            case this.CLEAR_ALL_ALARM_TITLE:
                this.notifyClearAllAlarm();
                break;
            case this.TABLE_LIST_SHOW_ALL:
                this.notifyShowAllAlarmEmitter();
                break;
            case this.TABLE_LIST_SHOW_LESS:
                this.notifyShowlessAlarmEmitter();
                break;
            case this.TABLE_LIST_REFRESH:
                this.notifyRefreshAlarmEmitter();
                break;
            default:
        }
    }

    // function :: clear selected alarms list.
    private setClearListData(alarmIDList): any {
        this.alarmListDataService
            .clearAlarmsListDataById(alarmIDList)
            .pipe(takeUntil(this.ngUnsubscribe)
            )
            .subscribe(this.successClearSelected.bind(this), this.onError.bind(this));
    }

    // function :: success of clear slected alarm list.
    private successClearSelected(data): void {
        this.setInitListData();
    }

    // function :: init calling alarm list data.
    private setInitListData(): any {
        this.alarmListDataService
            .getInitAlarmsListData()
            .pipe(
                takeUntil(this.ngUnsubscribe)
            )
            .subscribe(this.successInitListData.bind(this), this.onError.bind(this));
    }

    // function :: success of init call.
    private successInitListData(response): void {
        let resModel: any = response;
        this.mostRecentAlarmDate = resModel.mostRecentAlarmDate;
        this.newAlarmsAvailable = resModel.newAlarmsAvailable;
        this.totalNumberOfAlarms = resModel.totalNumberOfAlarms;
        this.alarms = resModel.alarms;
        this.alarmLength = this.alarms.length;
        this.tableData = this.alarms;
        this.setShowAllLabel(this.alarmLength, this.totalNumberOfAlarms);
        this.alarmsLastRefreshedTime = this.sharedService.getLocaleDate(new Date());
        if (this.totalNumberOfAlarms > this.alarmLength) {
            this.showAll = true;
            this.showAllBtn = [{ name: this.TABLE_LIST_SHOW_ALL, tabType: "ALARM_TAB" }];
        } else if (this.showAll && this.totalNumberOfAlarms < this.alarmLength + 1) {
            this.showAllBtn = [{ name: this.TABLE_LIST_SHOW_LESS, tabType: "ALARM_TAB" }];
        } else {
            this.showAllBtn = [];
        }
        !this.alarmListDataService.getSyncAliveStatus() && this.setSyncTimer();
        this.setUI(this.tableData.length);
    }

    private setUI(length: number): void {
        let width: number = 119;
        if (length === 0) {
            width = 95;
        }
        let doc: any = document.getElementById("dropdownMenuButton");
        if (doc) {
            doc.style.width = width + "px";
        }
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount): void {
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + rowCount + " " + this.TABLE_LIST_SHOWING_OF + " " + totalCount + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e: any): void {
        let rowCount = this.alarmListGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalNumberOfAlarms);
    }

    //Set Sync Timer for alarm list
    private setSyncTimer() {
        
        if (this.freshedInitiated == false) {
            this.alarmListDataService.startSyncAlarmsListData();
            this.alarmListDataService
                .getSyncTimerStatus(INTERVAL)
                .pipe(
                    takeUntil(this.ngUnsubscribe)
                )
                .subscribe((response) => {
                    this.setSyncListData([ALARMS_LIMIT, this.mostRecentAlarmDate, this.totalNumberOfAlarms]);
                }, this.onError.bind(this));
        }else{
            this.alarmListDataService.startSyncAlarmsListData();
            this.alarmListDataService
                .getSyncTimerStatus(REFRESH_ALARM_INTERVAL)
                .pipe(
                    takeUntil(this.ngUnsubscribe)
                )
                .subscribe((response) => {
                    this.setSyncListData([ALARMS_LIMIT, this.mostRecentAlarmDate, this.totalNumberOfAlarms]);
                }, this.onError.bind(this));
        }
    }

    //Handle error
    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
        this.setUI(0);
    }


    // function :: get all data when we receive less nob of rows as compare to total number of rows.
    private setAllListData(params): any {
        this.alarmListDataService
            .getAllAlarmsListData(params)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.successAllListData.bind(this), this.onError.bind(this));
    }

    // function :: success of show all data.
    private successAllListData(response): void {
        let resModel: any = response;
        this.mostRecentAlarmDate = resModel.mostRecentAlarmDate;
        this.newAlarmsAvailable = resModel.newAlarmsAvailable;
        this.totalNumberOfAlarms = resModel.totalNumberOfAlarms;
        this.alarms = resModel.alarms;
        this.alarmLength = this.alarms.length;
        this.tableData = this.alarms;
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + this.alarmLength + " " + this.TABLE_LIST_SHOWING_OF + " " + this.totalNumberOfAlarms + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = this.alarmLength + "/" + this.totalNumberOfAlarms;
        this.alarmsLastRefreshedTime = this.sharedService.getLocaleDate(new Date());
        this.showAllBtn = [{ name: this.TABLE_LIST_SHOW_LESS, tabType: "ALARM_TAB" }];
    }

    // function :: call in every 15 sec's.
    private setSyncListData(params): void {
        this.alarmListDataService
            .getSyncAlarmsListData(params)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((response) => {
                response && response.newAlarmsAvailable && this.SuccessSyncListData(response);
            },
                (error) => {
                    let errorObj = error;
                    if (errorObj.errorCode == null || errorObj.errorCode == 1 || errorObj.errorCode == 503) {
                        this.internalServerErrorCount++;
                        if (this.internalServerErrorCount == 5) {
                            this.logger.debug('error Count', this.internalServerErrorCount);
                            this.alarmListDataService.stopSyncAlarmsListData();
                            this.onError(error);
                        } else {
                            if (errorObj.errorCode == 503) {
                                this.alarmListDataService.stopSyncAlarmsListData();
                                this.onError(error);
                            }
                        }
                    } else {
                        this.internalServerErrorCount = 0;
                        this.onError(error);
                    }
                });
    }

    // function :: success of sync call.
    private SuccessSyncListData(response): void {
        let resModel: any = response;
        this.mostRecentAlarmDate = resModel.mostRecentAlarmDate;
        this.newAlarmsAvailable = resModel.newAlarmsAvailable;
        this.totalNumberOfAlarms = resModel.totalNumberOfAlarms;
        this.alarms = resModel.alarms;
        this.alarmLength = this.alarms.length;
        this.tableData = this.alarms;
        this.showAllLabel = this.TABLE_LIST_SHOWING + " " + this.alarmLength + " " + this.TABLE_LIST_SHOWING_OF + " " + this.totalNumberOfAlarms + " " + this.TABLE_LIST_ROWS;
        this.showAllLabelMob = this.alarmLength + "/" + this.totalNumberOfAlarms;
        this.alarmsLastRefreshedTime = this.sharedService.getLocaleDate(new Date());
        if (this.totalNumberOfAlarms > this.alarmLength) {
            this.showAllBtn = [{ name: this.TABLE_LIST_SHOW_ALL, tabType: "ALARM_TAB" }];
        } else if ((this.showAllBtn.findIndex(x => x["name"] == this.TABLE_LIST_SHOW_ALL) > -1)) {
            this.showAllBtn = [{ name: this.TABLE_LIST_SHOW_LESS, tabType: "ALARM_TAB" }];
        } else {
            this.showAllBtn = [];
        }
    }

    /* function used to call alarm list api after getting threshold response */
    private setThresholdData(): any {
        this.alarmListDataService
            .getThresholdData()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(
                this.successThresholdData.bind(this), (error) => {
                    this.setInitListData();
                    this.onError(error);
                });
                if(this.alarmListGridOptions.api && this.alarmListDataService.alarmlistfilterchangedata){
                    this.alarmListGridOptions.api.setFilterModel(this.alarmListDataService.alarmlistfilterchangedata);            
                    console.log("filter executed",this.alarmListDataService.alarmlistfilterchangedata);
                }     
    }

    // function :: success of threshold data.
    private successThresholdData(response): void {
        this.setInitListData();
    }

    // function :: notify on grid ready.
    public notifyGridReadyAlarm(params:any): void {
        this.setGridColumnDefinition();
        this.setThresholdData();
    }

    // function :: notify on refresh alarm list.
    public notifyRefreshAlarmEmitter(): void {
        //on refresh the Alarm API call will be made withn 15 sec
        this.ngUnsubscribe.next();
        this.alarmListDataService.stopSyncAlarmsListData();
        this.freshedInitiated = true;
        if ((this.showAllBtn.findIndex(x => x["name"] == this.TABLE_LIST_SHOW_ALL) > -1) || this.showAllBtn.length === 0) {
            this.setInitListData()            
        } else if (this.showAllBtn.findIndex(x => x["name"] == this.TABLE_LIST_SHOW_LESS) > -1) {
            this.alarmListDataService.stopSyncAlarmsListData();
            this.setAllListData([this.mostRecentAlarmDate, this.totalNumberOfAlarms])            
        }

        //Trigger on refresh alarm after 5 minutes to normal(30 Sec) the API calls 
        const alarmResumeOnNomalCallTime = timer(INTERVAL_REFRESH);        
        const subscribe = alarmResumeOnNomalCallTime.subscribe(val => {
            this.ngUnsubscribe.next();
            this.alarmListDataService.stopSyncAlarmsListData();
            this.freshedInitiated = false;
            this.setInitListData();            
        });
        
    }

    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showLoadingOverlay();
        this.alarmListColumnDefinationService.translateLocaleStr();
        // this.alarmListGridOptions.api.setSideBarVisible(false);
        this.alarmListGridOptions.api.setColumnDefs(this.alarmListColumnDefinationService.getColumnDef());
        this.getAlarmListFromAPI();
    }

    //function :: shows overlay on grid.
    private showLoadingOverlay(): void {
        this.alarmListGridOptions.api.showLoadingOverlay();
    }

    //Get Alarm list from API
    private getAlarmListFromAPI(): void {
        this.storeSelection();
        // this.cmtsTabDataService.getAllCmtsList().subscribe(this.onCmtsListNext.bind(this), this.onError.bind(this));
    }

    //clear existing selection of ag-Grid
    private clearGridData(): void {
        this.storeSelection();
        this.tableData = [];
        //this.alarmListGridOptions.api.setRowData([]);

    }

    // CODE REVIEW : Remove this function if not required
    //Store existing selection of ag-Grid
    private storeSelection(): void {
        // this.selectedRowsCmtsId.length = 0;
        // this.cmtsTabService.getSelectedRowsCmtsIds(this.cmtsTabGridOptions.api.getSelectedRows(), this.selectedRowsCmtsId);
        // return this.selectedRowsCmtsId;
    }

    // function :: notify clear selected alarm.
    private notifyClearSelectedAlarm(event): void {
        this.sweetAlert.showConformationAlert(ALERT_WARNING, this.CLEAR_ALARM_TITLE, this.CLEAR_ALARM_ALERT_MSG, true, true, this.CLEAR_ALARM_OPTION_YES, this.CLEAR_ALARM_OPTION_NO,
            (isConfirm: boolean) => {
                if (isConfirm) {
                    let alarmIDArray: Array<number> = [];
                    let alarmIDData = event;
                    for (let i = 0; i < alarmIDData.length; i++) {
                        alarmIDArray.push(alarmIDData[i].alarmId);
                    }
                    this.setClearListData(alarmIDArray)
                }
            }
        );
    }

    // function :: notify to show all alarms.
    private notifyShowAllAlarmEmitter(): void {
        this.alarmListGridOptions.api.showLoadingOverlay();
        this.alarmListDataService.stopSyncAlarmsListData();
        this.setAllListData([this.mostRecentAlarmDate, this.totalNumberOfAlarms]);
    }

    // function :: notify to show less alarms.
    private notifyShowlessAlarmEmitter(): void {
        this.alarmListGridOptions.api.showLoadingOverlay();
        this.setInitListData()
    }

    // function :: notify on component destroy.
    ngOnDestroy() {
        this.alarmListDataService.stopSyncAlarmsListData();
    }

    //refresh grid data
    private notifyRefreshGrid(): void {
        this.setInitListData()
    }

    //Clear All Alarm
    private notifyClearAllAlarm(): void {
        this.sweetAlert.showConformationAlert(ALERT_WARNING, this.CLEAR_ALL_ALARM_TITLE, this.CLEAR_ALL_ALARM_ALERT_MSG, true, true, this.CLEAR_ALARM_OPTION_YES, this.CLEAR_ALARM_OPTION_NO,
            (isConfirm: boolean) => {
                if (isConfirm) {
                    this.setClearAllListData();
                }
            }
        );
    }


    /* method to translate required string in selected language */
    private translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.CLEAR_ALARM_TITLE = this.translate.instant('CLEAR_ALARM_TITLE');
        this.CLEAR_ALARM_ALERT_MSG = this.translate.instant('CLEAR_ALARM_ALERT_MSG');
        this.CLEAR_ALL_ALARM_TITLE = this.translate.instant('CLEAR_ALL_ALARM_TITLE');
        this.CLEAR_ALL_ALARM_ALERT_MSG = this.translate.instant('CLEAR_ALL_ALARM_ALERT_MSG');
        this.TABLE_LIST_EXPORT_ALL = this.translate.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = this.translate.instant('TABLE_LIST_EXPORT_SELECTED');
        this.ALARM_TAB_SYNC_ALL = this.translate.instant('CMTS_TAB_SYNC_ALL');
        this.TABLE_LIST_SHOW_ALL = this.translate.instant('TABLE_LIST_SHOW_ALL');
        this.TABLE_LIST_SHOW_LESS = this.translate.instant('TABLE_LIST_SHOW_LESS');
        this.TABLE_LIST_REFRESH = this.translate.instant('TABLE_LIST_REFRESH');
        this.TABLE_LIST_SHOWING = this.translate.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = this.translate.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = this.translate.instant('TABLE_LIST_ROWS');
        this.CLEAR_ALARM_OPTION_YES = localization.instant('CLEAR_ALARM_OPTION_YES');
        this.CLEAR_ALARM_OPTION_NO = localization.instant('CLEAR_ALARM_OPTION_NO');
        SeverityFilter.severity.alarmDefault = CommonStrings.ALARM_LIST_SEVERITY_DEFAULT;
        SeverityFilter.severity.critical = CommonStrings.ALARM_LIST_SEVERITY_CRITICAL;
        SeverityFilter.severity.minor = CommonStrings.ALARM_LIST_SEVERITY_MINOR;
        SeverityFilter.severity.major = CommonStrings.ALARM_LIST_SEVERITY_MAJOR;
        SeverityFilter.severity.warning = CommonStrings.ALARM_LIST_SEVERITY_WARNING;
    }
}
