
import { Injectable } from "@angular/core";
import { CommonStrings } from "../../../constant/common.strings";
import { SeverityFilter } from "./severity.filter";
import { AlarmListService } from "./alarm-list.service";
import {
    ALARM_CRITICAL_PERCENTAGE_COLOR, ALARM_MAJOR_PERCENTAGE_COLOR, ALARM_MINOR_PERCENTAGE_COLOR,
    ALARM_WARNING_PERCENTAGE_COLOR, RANKING_BORDER_BOTTOM
} from "../../../constant/app.constants";
import { HostService } from '../../../shared/host.service';
import { LocaleDataService } from "../../../shared/locale.data.service";
import { SharedService } from "../../../shared/shared.service";
import { Router } from '@angular/router';
import { TimeFilter } from "../../../shared/time.filter";
import { gridCustomComparator } from "../../../shared/ag-Grid.comparator";
//import * as moment from "moment/moment";
import {SweetAlert} from "../../../utilities/sweetAlert";
import {
    ALERT_INFO,
} from "../../../constant/app.constants";
import { TranslateService } from "@ngx-translate/core";

let vm: any;
@Injectable()
export class AlarmListColumnDefinitionService {
    private ALARM_LIST_HEADER_TIME: string;
    private ALARM_LIST_HEADER_SEVERITY: string;
    private ALARM_LIST_HEADER_SOURCE: string;
    private ALARM_LIST_HEADER_EVENT: string;
    private ALARM_LIST_HEADER_ACK_REQ: string;
    private ALARM_LIST_HEADER_ALARM_ID: string;
    private ALARM_LIST_HEADER_ELEMENT_TYPE: string;
    private filterIds: any[] = [{ id: "timeStamp", val: "", fieldComponent: null },
    { id: "alarmSeverity", val: "", fieldComponent: null },
    { id: "source", val: "", fieldComponent: null },
    { id: "eventName", val: "", fieldComponent: null },
    { id: "ack", val: "", fieldComponent: null },
    { id: "alarmId", val: "", fieldComponent: null },
    { id: "elementType", val: "", fieldComponent: null }];

    constructor(private localeDataService: LocaleDataService,
        private alarmListService: AlarmListService,
        private hostService: HostService,
        private router: Router,
        private sharedService: SharedService,
        private translate: TranslateService,
        private sweetAlert:SweetAlert) {
        vm = this;
        this.translateLocaleStr();
    }

    //Getter for filterIds
    public getFilterIds(): any[] {
        return this.filterIds;
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    public translateLocaleStr(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.ALARM_LIST_HEADER_TIME = this.translate.instant('ALARM_LIST_HEADER_TIME');
        this.ALARM_LIST_HEADER_SEVERITY = this.translate.instant('ALARM_LIST_HEADER_SEVERITY');
        this.ALARM_LIST_HEADER_SOURCE = this.translate.instant('ALARM_LIST_HEADER_SOURCE');
        this.ALARM_LIST_HEADER_EVENT = this.translate.instant('ALARM_LIST_HEADER_EVENT');
        this.ALARM_LIST_HEADER_ACK_REQ = this.translate.instant('ALARM_LIST_HEADER_ACK_REQ');
        this.ALARM_LIST_HEADER_ALARM_ID = this.translate.instant('ALARM_LIST_HEADER_ALARM_ID');
        this.ALARM_LIST_HEADER_ELEMENT_TYPE = this.translate.instant('ALARM_LIST_HEADER_ELEMENT_TYPE');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        let columnDef: any[] = [
            {
                headerName: '', maxWidth: 25, checkboxSelection: true,
                pinned: true, sortingOrder: [null],
                field: '', headerCheckboxSelection: true, suppressFilter: true, suppressSizeToFit: true, suppressMenu: true,
                filterParams: { newRowsAction: 'keep' },
                suppressResize: true
            },
            {
                headerName: this.ALARM_LIST_HEADER_TIME, field: this.filterIds[0].id,
                minWidth: 150,
                headerTooltip: this.ALARM_LIST_HEADER_TIME,
                filter: TimeFilter.ParentFilter,
                floatingFilterComponent: TimeFilter.ChildFloatingFilter,
                floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: this.sharedService.dateComparator,
                filterParams: { newRowsAction: 'keep' },
                sort: 'desc',
                cellRenderer: (params: any) => {
                    if(params && params.value){
                        return this.sharedService.getLocaleDate(params.value);
                    }
                }
                , cellStyle: function (params) {
                    return { 'text-align': 'center' };
                }
            },
            {
                headerName: this.ALARM_LIST_HEADER_SEVERITY, field: this.filterIds[1].id,
                minWidth: 140,
                width: 124,
                suppressSizeToFit: true,
                suppressResize: true,
                headerTooltip: this.ALARM_LIST_HEADER_SEVERITY,
                sortingOrder: ['asc', 'desc', null],
                cellClass: 'alarmSeverityClass cellBorder',
                cellStyle: function (params) {
                    let color: string;
                    switch (params.value) {
                        case CommonStrings.ALARM_LIST_SEVERITY_MINOR:
                            color = ALARM_MINOR_PERCENTAGE_COLOR;
                            break;
                        case CommonStrings.ALARM_LIST_SEVERITY_MAJOR:
                            color = ALARM_MAJOR_PERCENTAGE_COLOR;
                            break;
                        case CommonStrings.ALARM_LIST_SEVERITY_CRITICAL:
                            color = ALARM_CRITICAL_PERCENTAGE_COLOR;
                            break;
                        case CommonStrings.ALARM_LIST_SEVERITY_WARNING:
                            color = ALARM_WARNING_PERCENTAGE_COLOR;
                            break;
                    }
                    return { backgroundColor: color, color: "black", 'text-align': 'center', borderBottom: RANKING_BORDER_BOTTOM };
                }, 
                filter: SeverityFilter.ParentFilter,
                floatingFilterComponent: SeverityFilter.ChildFloatingFilter, 
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { newRowsAction: 'keep'}
            },
            {
                headerName: this.ALARM_LIST_HEADER_SOURCE, field: this.filterIds[2].id,
                minWidth: 100,
                headerTooltip: this.ALARM_LIST_HEADER_SOURCE,
                cellRenderer: (params) => {

                    let gui = document.createElement('div');
                    gui.innerHTML = params.value;
                    gui.addEventListener("click", (() => {
                        //this.action(params);
                        this.navigate(params);
                    }));
                    gui.className = "ag-Grid-cursor alarmlist-grid-link hyperlink-color";
                    return gui;


                    // let url:string= this.hostService.getRedirectionUrl()+"/"+ URL_TEXT +"/port/"+params.data.sourceElementId;
                    // return "<span onclick=this.action(params)>"+params.value+"</span>";
                },
                filter: 'text', floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                cellStyle: function (params) {
                    return { 'text-align': 'center', 'color': '#0275d8' };
                }
            },
            {
                headerName: this.ALARM_LIST_HEADER_ELEMENT_TYPE, field: this.filterIds[6].id,
                minWidth: 100,
                headerTooltip: this.ALARM_LIST_HEADER_ELEMENT_TYPE,
                filter: "text", floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},            
                cellStyle: function (params) {
                    return { 'text-align': 'center' };
                }
            },
            {
                headerName: this.ALARM_LIST_HEADER_EVENT, field: this.filterIds[3].id,
                minWidth: 100,
                headerTooltip: this.ALARM_LIST_HEADER_EVENT,
                filter: 'text', floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                cellStyle: function (params) {
                    return { 'text-align': 'center' };
                }
            },
            {
                headerName: this.ALARM_LIST_HEADER_ACK_REQ, field: this.filterIds[4].id,
                minWidth: 100,
                headerTooltip: this.ALARM_LIST_HEADER_ACK_REQ,
                filter: 'text', floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                cellStyle: function (params) {
                    return { 'text-align': 'center' };
                }
            },
            {
                headerName: this.ALARM_LIST_HEADER_ALARM_ID, field: this.filterIds[5].id,
                minWidth: 160,
                headerTooltip: this.ALARM_LIST_HEADER_ALARM_ID,
                filter: "text", floatingFilterComponentParams: { suppressFilterButton: true },
                comparator: gridCustomComparator,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                cellStyle: function (params) {
                    return { 'text-align': 'center' };
                }
            }

        ];
        return columnDef;
    }

    // private action(param) {
    //     this.sharedService.setFilterAlarmForTab(param.value);
    //     this.sharedService.setRedirectTAB(param.data.eventType.split('_')[0].toLocaleLowerCase());
    //     this.router.navigate(['hcu']);
    // }

    private navigate(params) {
        switch (params.data.elementType.toUpperCase()) {
            case "HCU": {
                this.navigateToTab("hcu", "hcu");    
                break;
            };
            case "RPM": {
                this.navigateToTab("rpm", "hcu")    
                break;
            };
            case "RCI": {
                this.navigateToTab("rci", "rci")
                break;
            };
            case "CMTSUSPORT": {
                this.navigateToTab("cmts", "cmts")
                break;
            };
            case "PORT": {
                this.navigateToTab("port", "hcu")    
                break;
            };
            case "HSM": {
                this.navigateToTab("hsm", "hcu")    
                break;
            };
            case "CMTS": {
                this.navigateToTab("cmts", "cmts")    
                break;
            };
            case "NODE": {
                this.navigateToTab("node", "cmts")    
                break;
            };
            case "MODEM": {
                this.navigateToTab("modem", "cmts")
                break;
            };
            case "OTU": {
                this.navigateToTab("otu", "otu")
                break;
            };
            case "RPMPORT": {
                this.navigateToTab("rpm", "hcu")
                break;
            };
            default: {
                break;
            }
        }       
    }

    private navigateToTab(tab: string , module: string){
        this.sharedService.setRedirectTAB(tab);
        let redirectTo: string;
        if (!(tab === "cmts")) {
            tab = tab.concat("s");
        }

        if ((module !== 'otu') as any || (module !== 'cmts')) {
            redirectTo = module;
        } else {
            redirectTo = module.concat("/", tab);
        }

        this.router.navigate([redirectTo]);
    }
   
}
