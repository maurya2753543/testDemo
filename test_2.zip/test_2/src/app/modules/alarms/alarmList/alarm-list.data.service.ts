/**
 * Created by Narayan.Reddy .
 */


import {Injectable , OnInit} from "@angular/core"; /* comments:- Remove unwawnted injections */
import {Observable , Subject, Subscription,throwError,timer} from "rxjs";
import {AlarmListService} from './alarm-list.service';
import {INTERVAL}  from  '../../../constant/app.constants';
import {HttpResponse} from "@angular/common/http";
import {AdminAppError} from "../../../models/error.model";
import {AdminAppResponse} from "../../../models/response.model";


import {AlarmHttpService} from "../alarm.http.service";
import {ThresholdService} from "../../shared/threshold.service";
import { takeWhile, map, catchError, tap } from "rxjs/operators";

@Injectable()
export class AlarmListDataService {

    public componentCallback = new Subject<any>();
    private thresholdList : any;
    public alarmlistfilterchangedata: any;
    private successCounter = 0; /* CODE REVIEW : Specify the type like number */
    private alive: boolean;
    private timer: Observable<number>;
    private interval: number;
    
    constructor(private httpService : AlarmHttpService,
                private alarmListService:AlarmListService,
                private thresholdService: ThresholdService){
        this.interval = INTERVAL;
        this.timer = timer(0, this.interval);
    }

    public getSyncTimerStatus(interval : number ): Observable<any> {    
        this.interval = interval//INTERVAL;
        this.timer = timer(0, this.interval);           
        return this.timer
        .pipe(
            takeWhile(() => this.alive),
            map(() => {
                    return this;
            })

        )
    }

    /*
    *@name getSyncAlarmsListData
    *@desc get alarm list data in every 25 sec.
    *@param urlParams array
    *@return void
    */
    public getSyncAlarmsListData(urlParams): Observable<any> {
        return this.httpService
            .getSyncAlarmListData(urlParams)
            .pipe(
                map((res: any) => {
                    let response = res;
                    this.alarmListService.setAlarmVal(response);
                    if (response.newAlarmsAvailable) {
                        return this.alarmListService.getAlarmData();
                    }
                    this.successCounter = this.successCounter + 1;
                }),
                catchError(this.handleError)
            )
    }

    /*
    *@name stopSyncAlarmsListData
    *@desc stops sync of table list
    *@return void
    */
    public stopSyncAlarmsListData():void{
        this.alive = false;
    }

    /*
     *@name startSyncAlarmsListData
     *@desc start sync of table list
     *@return void
     */
    public startSyncAlarmsListData():void{
        this.alive = true;
    }

    /*
     *@name startSyncAlarmsListData
     *@desc start sync of table list
     *@return void
     */
    public getSyncAliveStatus():any{
        return this.alive;
    }



    //Method to get all CMTS list
    public getInitAlarmsListData(): Observable<any> {
        return this.httpService
            .getInitAlarmList()
            .pipe(map((res: HttpResponse<any>) => {
                this.alarmListService.setAlarmVal(res);
                return this.alarmListService.getAlarmData();
            }), catchError(this.handleError));
    }

    /* CODE REVIEW : Specify the return type */
    //Error handler
    public handleError(error) {
        return throwError(error);
    }

    /*
    *@name getAllAlarmsListData
    *@desc gets all alarms 
    *@param urlParams array
    *@return void
    */
    
    public getAllAlarmsListData(urlParams): Observable<any>{
        return this.httpService
            .getAllAlarmListData(urlParams)
            .pipe(map((res: HttpResponse<any>) => {
                this.alarmListService.setAlarmVal(res);
                return this.alarmListService.getAlarmData();
            }), catchError(this.handleError))
    }
    /*
    *@name clearAlarmsListData
    *@desc clear/deletes all alarms
    *@retun void
    */
    
    public clearAlarmsListData():Observable<any> {
        return this.httpService
            .clearAllAlarmsListData()
            .pipe(map(
            (res) => {
                return true;
            }), catchError(this.handleError))
    }

    /*
    *@name clearAlarmsListDataById
    *@desc clear/deletes  alarms as per ID
    *@retun
    */
    public clearAlarmsListDataById(data:Array<number>) : Observable<any>{
       return this.httpService
           .clearAlarmsListDataById(data)
           .pipe(map(
            (res) => {
                return true;
            }), catchError(this.handleError))
    }

    /*
    *@name getThresholdData
    *@desc http call to get threshold response
    *@return void
    */
    public getThresholdData():Observable<any> {
        return this.httpService.getThresholdData().pipe(map(
            (res) => {
                this.thresholdList = res;
                this.thresholdService.thresholdList = this.thresholdList;
                return this.thresholdList;
            }), catchError(this.handleError))
    }

    public getThresholdList() : any {
        return this.thresholdList;
    }

}
