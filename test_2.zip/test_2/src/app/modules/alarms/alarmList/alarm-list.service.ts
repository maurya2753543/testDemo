
import {Injectable} from "@angular/core";
import {WindowService} from '../../../shared/nativeProvider/window.service';
import {AlarmListModel} from "./alarm-list.model";
import { LocaleDataService } from "../../../shared/locale.data.service";
import { SharedService } from "../../../shared/shared.service";
import {ThresholdService} from "../../shared/threshold.service";

@Injectable()
export class AlarmListService {
    private newAlarmsAvailable : boolean;
    private totalNumberOfAlarms : number;
    private mostRecentAlarmDate : string;
    private modifiedAlarmData:Array<{}>;
    private alarms : Array<{}>;
    private window : Window ;
    private alarmsLastRefreshedTime:string;
    private ALARM_LIST_SEVERITY_CRITICAL:string;
    private ALARM_LIST_SEVERITY_MAJOR:string;
    private ALARM_LIST_SEVERITY_MINOR:string;
    private ALARM_LIST_SEVERITY_WARNING:string;
    private CLEAR_ALARM_OPTION_YES:string;
    private CLEAR_ALARM_OPTION_NO:string;

    constructor(private windowService:WindowService, 
        private localeDataService: LocaleDataService,
        private sharedService : SharedService,
                private thresholdService: ThresholdService) {
        this.window = windowService.getWindow();
        this.translateLocaleString();
    }

    /*
    *@name setAlarmVal
    *@desc sets and processes alarmlist response
    *@param data:Object
    *@return void
    */
    public setAlarmVal(data:any):void{
        this.translateLocaleString();
        if(data.totalNumberOfAlarms) {
            this.newAlarmsAvailable = data.newAlarmsAvailable;
            this.totalNumberOfAlarms = data.totalNumberOfAlarms;
            this.mostRecentAlarmDate = data.mostRecentAlarmDate;
            this.modifiedAlarmData = this.formatData(data.alarms);
            this.alarms = this.modifiedAlarmData;
        }else {
            this.setDefaultValOfAlarm();   
        }
    }

    /* Function to provide alarm severity string as per current language selected */
    private alarmSeverities(alarmSeverity: string): string{

        let alarmSeverityVal: string = alarmSeverity.toUpperCase();
        let alarmSeverityValLocalization: string;
        switch(alarmSeverityVal){
            case "CRITICAL":
                alarmSeverityValLocalization = this.ALARM_LIST_SEVERITY_CRITICAL;
                break;
            case "MAJOR":
                alarmSeverityValLocalization = this.ALARM_LIST_SEVERITY_MAJOR;
                break;
            case "MINOR":
                alarmSeverityValLocalization = this.ALARM_LIST_SEVERITY_MINOR;
                break;
            case "WARNING":
                alarmSeverityValLocalization = this.ALARM_LIST_SEVERITY_WARNING;
                break;
            default:
                break;
        }
        return alarmSeverityValLocalization;
    }

    /*
    *@name formatData
    *@desc convert utc date to full date
    *@param data:Array<{}>
    *@return Array<{}>
    */
    private formatData(data): any[] {
        let alarmList: AlarmListModel[] = [];
        for(let key in data) {
            // data[key].timeStamp = this.sharedService.getLocaleDate(data[key].timeStamp);
            data[key].alarmSeverity = this.alarmSeverities(data[key].alarmSeverity);
            if(data[key].ack == true){
                data[key].ack = this.CLEAR_ALARM_OPTION_YES;
            }else {
                data[key].ack = this.CLEAR_ALARM_OPTION_NO;
            }
            alarmList.push(new AlarmListModel(data[key]));
        }
        return this.processAlarmNames(alarmList);
    }

    private processAlarmNames(alarmList: AlarmListModel[]) : AlarmListModel[] {
        alarmList.forEach((alarm: AlarmListModel) => {
            alarm.eventName = this.thresholdService.getThresholdIndex(alarm.eventType);
        });
        return alarmList;
    }

    /*
    *@name setDefaultValOfAlarm
    *@desc sets default values to response
    *@return void
     */
    private setDefaultValOfAlarm():void{
        this.newAlarmsAvailable = false;
        this.totalNumberOfAlarms = 0;
        this.mostRecentAlarmDate = '';
        this.alarms = [];
    }
   /*
   *@name getAlarmData
   *@desc gets alarms list response
   *@return any
   */
    public getAlarmData():any{
        return {
            "newAlarmsAvailable" : this.newAlarmsAvailable,
            "totalNumberOfAlarms" : this.totalNumberOfAlarms,
            "mostRecentAlarmDate" : this.mostRecentAlarmDate,
            "alarms" : this.alarms,
        };
    }

    /* Function used to set last refreshed time of alarmlist */
    public setAlarmsLastRefresheedTime(): void {
        this.alarmsLastRefreshedTime = this.sharedService.getLocaleDate(new Date());
    }

    /* Function used to gets last refreshed time of alarmlist */
    public getAlarmsLastRefresheedTime(): string {
        return this.alarmsLastRefreshedTime;
    }

    /* Function to translate required string in selected language */
    public translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.ALARM_LIST_SEVERITY_CRITICAL = localization.instant('ALARM_LIST_SEVERITY_CRITICAL');
        this.ALARM_LIST_SEVERITY_MAJOR = localization.instant('ALARM_LIST_SEVERITY_MAJOR');
        this.ALARM_LIST_SEVERITY_MINOR = localization.instant('ALARM_LIST_SEVERITY_MINOR');
        this.ALARM_LIST_SEVERITY_WARNING = localization.instant('ALARM_LIST_SEVERITY_WARNING');
        this.CLEAR_ALARM_OPTION_YES = localization.instant('CLEAR_ALARM_OPTION_YES');
        this.CLEAR_ALARM_OPTION_NO = localization.instant('CLEAR_ALARM_OPTION_NO');
    }
}