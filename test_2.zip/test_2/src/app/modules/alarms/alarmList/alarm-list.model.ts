/**
 * Created by narayan.reddy on 27-07-2017.
 */
export class AlarmListModel{
    public eventName: string;
    public eventType:string;

    private alarmId : number;
    private alarmSeverity : string;
    private ack : boolean;
    private source:string;
    private sourceElementId : number;
    private timeStamp:string;
    private elementType: string;

    constructor(obj: any){
        if(obj){
            this.alarmId = obj.alarmId;
            this.alarmSeverity = obj.alarmSeverity;
            this.ack = obj.ack;
            this.source = obj.source;
            this.sourceElementId = obj.sourceElementId;
            this.eventType = obj.eventType;
            this.timeStamp = obj.timeStamp;
            this.elementType = obj.elementType
        }
    }

}
