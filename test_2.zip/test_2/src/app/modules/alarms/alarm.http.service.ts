/* HTTP Service Class for api calls & data handling*/

import { Injectable } from '@angular/core';

import {AlarmUrlService} from "./alarm.url.service";
import {HttpService} from "../../shared/http.service";
import {Observable} from "rxjs";

@Injectable()
export class AlarmHttpService{
    private selectedTab: string;
    constructor( private urlService: AlarmUrlService, private httpService: HttpService){}

    // alarm refresh data
    public getSyncAlarmListData(urlParams) : any{
        let url:string = this.urlService.getSyncAlarmListDataUrl(urlParams);
        return this.httpService.GET(url);
    }

    // Alarm initialization data
    public getInitAlarmList(): Observable<any>{
        let url:string = this.urlService.getInitAlarmListDataUrl();
        return this.httpService.GET(url);
    }

    // obtain list of all alarms
    public getAllAlarmListData(urlParams):any{
        let url:string = this.urlService.getAllAlarmListDataUrl(urlParams);
        return this.httpService.GET(url);
    }

    // clears all alarms
    public clearAllAlarmsListData() :any{
        /*let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers, withCredentials: true});*/
        let url:string = this.urlService.clearAllAlarmListDataUrl();
        return this.httpService.DELETE(url);
    }

    // clears selected alarms
    public clearAlarmsListDataById( data : any ):any{
        let url:string = this.urlService.clearAllAlarmListDataByIdUrl();
        return this.httpService.DELETEWITHDATA(url , data);
    }

//gets threshhold data
    public getThresholdData():any {
        let url:string  = this.urlService.getThresholdUrl();
        return this.httpService.GET(url);
    }

    /////////////////////////////// Alarm Configuration Method ////////////////////////////
    /* Return to get types of devices units from server*/
    public getDeviceTypeList() {
        return this.httpService.GET(this.urlService.getDeviceTypeUrl());
    }

    /* Return to get alarm details from server*/
    public getAlarmDetails(deviceType : string , alarmName : string) {
        return this.httpService.GET(this.urlService.getAlarmDetailsUrl(deviceType , alarmName));
    }

    public getAlarmTableDetails(){
        return this.httpService.GET(this.urlService.getAlarmTableDetailUrl());
    }

    public postAlarmConfigData(data:any): Observable<any> {
        return this.httpService.POST(this.urlService.getPostAlarmConfigUrl(), data);
    }

    public getTab() {
        return this.selectedTab;
    }

    public setTab(value: string) {
        this.selectedTab = value;
    }

}

