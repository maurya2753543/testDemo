import { Routes, RouterModule } from "@angular/router";
import { AlarmsComponent } from "./alarms.component";

export const AlarmsRoutes: Routes = [{ path: "", component: AlarmsComponent, pathMatch: 'prefix' }];
// export class AlarmsRoutes{}
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);
