import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
/**
 * Created by nikita.dewangan on 02-06-2017.
 */

import { CommonModule,registerLocaleData} from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AgGridModule } from "ag-grid-angular";
import { UiSwitchModule } from "ngx-ui-switch";
//import { Locale, LocaleModule, LocalizationModule } from 'angular2localization';


import { LocaleDataService } from "../../shared/locale.data.service";
import { SharedModule } from "../shared/shared.module";
import { AlarmHttpService } from "./alarm.http.service";
import { AlarmUrlService } from "./alarm.url.service";
import { AlarmConfigurationComponent } from "./alarmConfiguration/alarm-configuration.component";
import { AlarmConfigurationDataService } from "./alarmConfiguration/alarm-configuration.data.service";
import { AlarmEventConfigComponent } from "./alarmConfiguration/alarm-event-config/alarm-event-config";
import { AlarmConfigurationDirective } from "./alarmConfiguration/directive/configureEvent/alarm-configuration.directive";
import { ListEventComponent } from "./alarmConfiguration/directive/list/listEvent.component";
import { AlarmListColumnDefinitionService } from './alarmList/alarm-list.column-definition.service';
import { AlarmListComponent } from "./alarmList/alarm-list.component";
import { AlarmListDataService } from './alarmList/alarm-list.data.service';
import { AlarmListService } from './alarmList/alarm-list.service';
import { AlarmsComponent } from "./alarms.component";
import { AlarmsRoutes } from "./alarms.routes";
import { HttpClient } from '@angular/common/http';
import { LanguageService } from 'src/app/shared/locale.language.service';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/alarms-locale-`, ".json");
  }

import {LicenseManager} from "ag-grid-enterprise";
LicenseManager.setLicenseKey('Viavi__PathTrak_1Devs_150Deployment_8_July_2020__MTU5NDE2MjgwMDAwMA==d04104de1da4af739d72e75962d5b9c6');

@NgModule({
    imports: [RouterModule.forChild(AlarmsRoutes),
        AgGridModule.withComponents([AlarmConfigurationComponent]),
        SharedModule,
        CommonModule,
        FormsModule,
        UiSwitchModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }, 
          isolate: true}),
    ],
    declarations: [
        AlarmsComponent,
        AlarmListComponent,
        AlarmConfigurationComponent,
        AlarmConfigurationDirective,
        AlarmEventConfigComponent,
        ListEventComponent
    ],
    entryComponents: [
        AlarmListComponent,
        AlarmConfigurationComponent,
        AlarmEventConfigComponent,
        AlarmConfigurationDirective
       ],
    providers: [
        LocaleDataService,
        AlarmListService,
        AlarmListDataService,
        AlarmListColumnDefinitionService,
        AlarmHttpService,
        AlarmUrlService,
        AlarmConfigurationDataService,
        TranslateService,
        LanguageService,
    ]
})

export class AlarmsModule  {}
