import { Component, ViewChild, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { LocaleDataService } from "../../shared/locale.data.service";
import * as AppConstants from  '../../constant/app.constants';
import { SharedService } from "../../shared/shared.service";
import { AlarmListComponent } from './alarmList/alarm-list.component';
import {AlarmConfigurationComponent} from "./alarmConfiguration/alarm-configuration.component";
import {AlarmListDataService} from "./alarmList/alarm-list.data.service";
import { AuthService } from "../../shared/auth.service";
import {AlarmConfigurationDataService} from "./alarmConfiguration/alarm-configuration.data.service";
import {ThresholdService} from "../shared/threshold.service";
import { AlarmHttpService } from './alarm.http.service';
import { NavService } from '../../shared/nav.service';
@Component({
    selector: 'alarms-component',
    templateUrl: 'alarms.component.html'
})

export class AlarmsComponent {
    @ViewChild('targetAlarmList', {read: ViewContainerRef}) _targetAlarmList;
    @ViewChild('targetAlarmConfig',{read: ViewContainerRef}) _targetAlarmConfig

    selectedTab = 'alarmList';

    public showMessage:boolean = false;
    private refreshChart:boolean = false;
    private tableData:Array<{}>;
    private IsResizeToScreen: boolean;
    private isAlarmSummaryHidden: boolean = false;
    private isAlarmComponentHidden: boolean = false;
    private previousSelectedSettings: string = '';
    private oldSelectedSettings: Object = {};
    private alarmTabRef:any;
    private alarmConfigRef:any;
    private loadHtml:boolean = false;
    public NAV_LINK_SETTING: string = AppConstants.NAV_LINK_SETTING;

    constructor(public translate : TranslateService,
                public navService: NavService,
                public localeDataService: LocaleDataService,
                private sharedService: SharedService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private viewContainerRef: ViewContainerRef,
                private alarmListDataService: AlarmListDataService,
                private authService: AuthService,
                private thresholdService: ThresholdService,
                private alarmHttpService: AlarmHttpService,
                private alarmConfigurationDataService:AlarmConfigurationDataService) {
        let module = AppConstants.ALARMS_MODULE;
        this.localeDataService.initLanguage(module);
        // this.authService.permissionsCallback.subscribe((data) => {
        //     this.loadHtml = true;
        // });
    }

    ngOnInit() {
        this.enableDisableSave();
        this.selectedTab = this.alarmHttpService.getTab();
        this.translate.onLangChange.subscribe(lang => {
            this.translateLocaleString();
            this.tabClick('alarmList');
            this.alarmHttpService.setTab('alarmList');
        })
    }

    tabClick(value: string): void {
        this.selectedTab = value;
    }

    // private tabClick(value: string): void {
    //     if (this.previousSelectedSettings != value) {
    //         switch (value) {
    //             case "AlarmList":
    //                 this.alarmTabRef = this.createComponentOnClick(AlarmListComponent, this._targetAlarmList, this.alarmTabRef);
    //                 break;
    //             case "AlarmConfig":
    //                 this.alarmConfigRef = this.createComponentOnClick(AlarmConfigurationComponent, this._targetAlarmConfig, this.alarmConfigRef);
    //                 this._targetAlarmList.clear();
    //                 this.alarmTabRef.destroy();
    //                 this.alarmTabRef = null;
    //                 this.alarmConfigurationDataService.enableDisableSave.next({showMessage: false});
    //                 break;
    //         }
    //     }
    //     this.previousSelectedSettings = value;
    // }

    private LoadAlarmListTab(): void{
      const factory = this.componentFactoryResolver.resolveComponentFactory(AlarmListComponent);
      this._targetAlarmList.createComponent(factory);
    }

    private LoadAlarmConfigTab(): void{
        const factory = this.componentFactoryResolver.resolveComponentFactory(AlarmConfigurationComponent);
        this._targetAlarmConfig.createComponent(factory);
        this._targetAlarmList.clear();
    }

    private LoadDiagnosticTab(): void{
        this._targetAlarmList.clear();
    }

    private createComponentOnClick(clickedComponent: any, currentViewContainer: any, currentCompRef: any): void {
        this.oldSelectedSettings['comp'] ? this.oldSelectedSettings['viewRef'].detach() : '';
        if (!currentCompRef) {
            let componentFactory: any = this.componentFactoryResolver.resolveComponentFactory(clickedComponent);
            currentCompRef = currentViewContainer.createComponent(componentFactory);
        } else {
            currentViewContainer.insert(currentCompRef.hostView);
        }
        this.oldSelectedSettings = { 'comp': currentCompRef, 'viewRef': currentViewContainer };
        return currentCompRef;
    }

    checkPermission(linkName: string): boolean{
        return this.sharedService.checkPermissions(linkName);
    }

/*
    * @name: enableDisableSave
    * @desc: used to enableDisableSave enableDisableSave subject to show/hide Toast
    * */
    private enableDisableSave(){
        this.alarmConfigurationDataService.showAlertSubject.subscribe((flag) => {
            // this.formDisabled = data.isDisabled;
            this.showMessage = flag;
            /**
             * TODO: Komal to add comment
             * */
            if(flag) {
                setTimeout(()=>{
                    this.showMessage = false;
                }, 5000);
            }
        })
    }

    /* method to translate required string in selected language */
    private translateLocaleString(): void {
        this.thresholdService.alarmClear = this.translate.instant("PORT_ALARM_CLEARED");
        this.thresholdService.nodeOutage = this.translate.instant("NODE_OUTAGE");
        this.thresholdService.violation = this.translate.instant("PORT_VIOLATION");
        this.thresholdService.threshold = this.translate.instant("THRESHOLD");
        this.thresholdService.thresholdInterval = this.translate.instant("ALARM_LIST_THRESHOLD_INTERVAL_VALUE");
    }

    ngOnDestroy(){
        this.alarmConfigurationDataService.userAlarms = null;
        this.alarmConfigurationDataService.alarmDetailsState = null;
    }
}
