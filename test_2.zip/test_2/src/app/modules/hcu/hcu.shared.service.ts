/**
 * Created by yogesh.paisode on 7/10/2017.
 */
import {Injectable} from "@angular/core";
import {Subject} from "rxjs";
import {RpmDetailsModel} from "./rpm-Tab/models/rpm-details.model";
import {PORTDetailsModel} from './port-tab/model/portDetails.model';
import {BroadcastModel} from './port-tab/model/port-broadcast.model';
import {EventListItems} from "../shared/common-components/models/viewEvents.model";
import {ThresholdModel} from "../shared/common-components/models/threshold.model";
import {MonitoringTabPlanModel} from './monitoring-tab/model/monitoringplan.model';

@Injectable()
export class HCUSharedService{

    private hcuFilterText: string = "";
    private rpmFilterText: string = "";
    private hcuTabModelData:any;    
    private hcuListRefreshSub:Subject<any>;
    private hsmListRefreshSub:Subject<any>; 
    private hcuFormChangeSub:Subject<any>;
    private hsmParentHSMSub:Subject<any>;
    private hsmVirtualHSMSub:Subject<any>;

    private rpmViewSubject:Subject<any>;
    private rpmDetailsModel: RpmDetailsModel;
    public  hcufilterchangedata1: any;
    public  rpmfilterchangedata1: any;
    private portViewSubject:Subject<any>;
    private portViewSubjectHSM:Subject<any>;
    private clearRpmEditComponentSubject:Subject<any>;    
    private portDetailsModelData:PORTDetailsModel;
    private mplanTabModelData:any;
    private monitoringTabPlanModel: MonitoringTabPlanModel;
    private monitoringPlanListRefreshSub:Subject<any>;   
    private clearMonitoringPlanEditComponentSubject:Subject<any>;
    private hcuElementId:number = 0;
    private parentVirtualID:any;
    private virtualHSMID:any;
    private rpmElementId: number = 0;
    public savedstate: any;
    public modeldata: any;
    public modeldata1: any;
    public hcumodeldata: any;
    public rpmmodeldata: any;
    public hsmmodeldata: any;
    private broadcastModel:BroadcastModel;
    private portMonitoringPlanModel:any[] = [];
    private HCUClearSliderSub:Subject<any>;
    private portRefreshListSubject:Subject<any>;
    private PortClearSliderSub:Subject<any>;

    private selectedTab: string;
    public deviceIds:any [];
    public selectedIds:any [];
    
    constructor(){
        this.hcuListRefreshSub = new Subject();
        this.hsmListRefreshSub = new Subject();      
        this.hsmParentHSMSub = new Subject();
        this.hsmVirtualHSMSub = new Subject();
        this.hcuFormChangeSub = new Subject();
        this.rpmViewSubject = new Subject();
        this.rpmDetailsModel = new RpmDetailsModel();        
        this.portViewSubject = new Subject();
        this.portViewSubjectHSM = new Subject();
        this.clearRpmEditComponentSubject = new Subject();
        this.monitoringPlanListRefreshSub = new Subject();
        this.monitoringTabPlanModel= new MonitoringTabPlanModel();
        this.clearMonitoringPlanEditComponentSubject = new Subject();
        this.HCUClearSliderSub = new Subject();
        this.portRefreshListSubject = new Subject();
        this.PortClearSliderSub = new Subject();
    }

    public getPortClearSliderSub():Subject<any> {
        return this.PortClearSliderSub;
    }

    public getPortRefreshListSubject():Subject<any> {
        return this.portRefreshListSubject;
    }

    public getHCUClearSliderSub():Subject<any> {
        return this.HCUClearSliderSub;
    }

    public setPortMonitoringModel(data):void {
        this.portMonitoringPlanModel = data;
    }

    public getPortMonitoringModel():any {
        return this.portMonitoringPlanModel;
    }

    public setBroadcastModel(modelObj:BroadcastModel):void {
        this.broadcastModel = modelObj;
    }

    public getBroadcastModel():any {
        return this.broadcastModel;
    }

    public setHCUElementId(elementId):void {
        this.hcuElementId = elementId;
    }
    public getHCUElementId():number {
        return this.hcuElementId;
    }
    public getRpmElementId(): number{
        return this.rpmElementId;
    }

    public setRpmElementId(rpmElementId: number): void{
        this.rpmElementId = rpmElementId;
    }

    public getClearRpmEditComponentSubject(): Subject<any>{
        return this.clearRpmEditComponentSubject;
    }

    public getPortTabModel():PORTDetailsModel {
        return this.portDetailsModelData;
    }

    public getPortTabModelHSM():PORTDetailsModel {
        return this.portDetailsModelData;
    }

    public setPortTabModel(portTabModelData):void {
        this.portDetailsModelData = portTabModelData;
    }

    public setPortTabModelHSM(portTabModelData):void {
        this.portDetailsModelData = portTabModelData;
    }
    
    public getPortViewSubject():Subject<any> {
        return this.portViewSubject;
    }

    public getPortViewSubjectHSM():Subject<any> {
        return this.portViewSubjectHSM;
    }

    public getRpmDetailsModel(): RpmDetailsModel{
        return this.rpmDetailsModel;
    }   

    public getRpmViewSubject(): Subject<any>{
        return this.rpmViewSubject;
    }

    public getHcuListRefreshSub(): Subject<any> {
        return this.hcuListRefreshSub;
    }

    public getHSMListRefreshSub(): Subject<any> {
        return this.hsmListRefreshSub;
    }

    public getMonitoringPlanDetailsModel(): MonitoringTabPlanModel{
        return this.monitoringTabPlanModel;
    }

    public getMonitoringPlanListRefreshSub(): Subject<any> {
        return this.monitoringPlanListRefreshSub;
    }

    public getClearMonitoringPlanEditComponentSubject(): Subject<any>{
        return this.clearMonitoringPlanEditComponentSubject;
    }

    public getParentHSMDataSub(): Subject<any> {
        return this.hsmParentHSMSub;
    }

    public getVirtualHSMDataSub(): Subject<any> {
        return this.hsmVirtualHSMSub;
    }

    public setParentVirtualID(data){
        this.parentVirtualID = data;
    }

    public setVirtualHSMID(data){
        this.virtualHSMID = data;
    }

    public getParentVirtualID(){
        return this.parentVirtualID;
    }

    public getVirtualHSMID(){
        return this.virtualHSMID;
    }

    public getHcuFormChangeSub():Subject<any> {
        return this.hcuFormChangeSub;
    }

    public setHcuViewModelData(hcuTabModelData):void {
        this.hcuTabModelData = hcuTabModelData;
    }

    public getMplanFormChangeSub():Subject<any> {
        return this.monitoringPlanListRefreshSub;
    }

    public setMplanViewModelData(mplanTabModelData):void {
        this.mplanTabModelData = mplanTabModelData;
    }

    public getHcuViewModelData(): any{
        return this.hcuTabModelData;
    }

    public getHcmFilterText(): string{
        return this.hcuFilterText;
    }

    public getTab() {
        return this.selectedTab;
    }

    public setTab(value: string) {
        this.selectedTab = value;
    }

    public closeSlider(dom: any): void{
        dom.addClass(dom.query("div.right-slider"),"close-right-slider");
        dom.addClass(dom.query("div.right-slider.overlay"),"close-right-slider-overlay");
    }

    //Method to apply filter on ag-Grid
    public applyNameFilter(nameFilterInstance: any, type: string): void{
        if(nameFilterInstance){
            let filterText: string;
            if(type === "hcu"){
                filterText = this.hcuFilterText;
            }else{
                filterText = this.rpmFilterText;
            }
         //   nameFilterInstance.setFilter(filterText);
            nameFilterInstance.onFilterChanged();
        }
    }

    //Method to get filter text
    public getNameFilterText(nameFilterInstance: any, type: string): void{
        if(nameFilterInstance){
            let filterText: string = "";
            let filterModel: any = nameFilterInstance.getModel();
            if(filterModel){
                filterText = filterModel.filter;
            }
            if(type === "hcu"){
                this.hcuFilterText = filterText;
            }else{
                this.rpmFilterText = filterText;
            }
        }// end of If
    }

    public processEventList(eventList: EventListItems[], thresholds: ThresholdModel[]): any[]{
        eventList.forEach((event: EventListItems)=>{
            if(event.eventType.includes("THRESHOLD")){
                for(let i = 0; i < thresholds.length; i ++){
                    if(event.eventType.includes(thresholds[i].name.substring(0,11))){
                        event.eventName = event.eventName.concat(thresholds[i].value);
                    }
                }
            }
        });

        return eventList;
    }
}
