import {Injectable} from '@angular/core';
import {Observable} from "rxjs";
import {map, catchError} from "rxjs/operators";

import {HttpResponse} from "@angular/common/http";
import {HCUHttpService} from "../hcu.http.service";
import {HSMTabModel , HSMTabViewPortModel} from './model/hsmtab.model';
import {HSMTabVirtualOrPhysicalData} from './model/hsmtab.virtual-Physical.model';
import { LocaleDataService } from "./../../../shared/locale.data.service";
import  {LanguageService} from "./../../../shared/locale.language.service";
import {SharedService} from "../../../shared/shared.service";
import {ViewEventsModel} from '../../shared/common-components/models/viewEvents.model';
import { _throw } from 'rxjs/observable/throw';
// passing localization service to hcu tab model.

@Injectable()

export class HSMTabDataService {
    private localService:any;
    public hsmtabfilterchangedata: any;
    constructor(private hcuHttpService:HCUHttpService ,
        private localeDataService:LocaleDataService,
        private sharedService:SharedService,
        private languageService : LanguageService){
        this.localService = this.localeDataService.getLocalizationService();
    }

    //Method to get all HSM TAB list
    public getAllHSMTabList(unit, showAll): Observable<any> {
        return this.hcuHttpService
            .getAllHSMTabList(showAll)
            .pipe(map((hsmTabListDataObj: HttpResponse<any>) => {
                return this.changeHSMTabListResponse(hsmTabListDataObj,unit);
            }),
            catchError(this.handleError))
    }

    //Method to get all View Port list
    public getAllViewPortBCList(hsmId , localizationService): Observable<any> {
        return this.hcuHttpService
            .getAllViewPortBCList(hsmId)
            .pipe(map((hsmTabListDataObj: HttpResponse<any>) => {
                return this.changeHSMTabVeiwPortListResponse(hsmTabListDataObj , localizationService);
            }),
            catchError(this.handleError))
    }

    //Method to REPAIR selected HSM
    public hsmRepair(elementId):Observable<any> {
        return this.hcuHttpService
            .hsmRepair(elementId)
            .pipe(map((repairRes:HttpResponse<any>)=>{
                    return repairRes;
          }),
            catchError(this.handleError))
    }

    //Remove Data from broadcast list
    public removeBroadcastData(elementId):Observable<any> {
        return this.hcuHttpService
            .deleteBroadcastHSM(elementId)
            .pipe(map((deleteHCUResponse:HttpResponse<any>)=>{
                return deleteHCUResponse;
            }),
			catchError(this.handleError))
    }

    //Method to get data of particular HSM node
    public getHSMDetailData(elementId): Observable<any> {
        return this.hcuHttpService
            .getHSMDetailData(elementId)
            .pipe(map((hsmTabListDataObj: HttpResponse<any>) => {
                return new HSMTabVirtualOrPhysicalData(hsmTabListDataObj);
            }),
            catchError(this.handleError))
    }

    //Method to Update selected HSM
    public updateHSMData(data): Observable<any> {
        return this.hcuHttpService
            .updateHSMData(data)
            .pipe(map((hsmTabListDataObj: HttpResponse<any>) => {
                return hsmTabListDataObj;
            }),
            catchError(this.handleError))
    }

    //get port data.
    public getPortDetails(elementId):Observable<any> {
        return this.hcuHttpService
            .getPortDetails(elementId)
            .pipe(map((portDetailsObj:HttpResponse<any>)=>{
                return portDetailsObj;
            }),
            catchError(this.handleError))
    }

    //Method to delete selected HSM
    public deleteHSM(elementId): Observable<any> {       
        return this.hcuHttpService
            .deleteHSM(elementId)
            .pipe(map((hsmTabListDataObj: HttpResponse<any>) => {
                return hsmTabListDataObj;
            }),
            catchError(this.handleError))
    }

    //Method to get events list of selected HSM
    public getEventList(elementID, type): Observable<any> {
        return this.hcuHttpService
            .getEventsListData(elementID, type)
            .pipe(map((eventListDataObj: HttpResponse<any>) => {
                return new ViewEventsModel(eventListDataObj, this.localService);
            }),
            catchError(this.handleError))
    }

    /*Method to get Measurement Unit list from server*/
    public getMeasurementUnit(): Observable<any> {
        return this.hcuHttpService.getMeasurement()
            .pipe(map((measurementUnitData) => {
                return measurementUnitData;
            }),
            catchError(this.handleError))
    }

    //function :: changes hcutab list response.
    private changeHSMTabListResponse(HSMRes ,unit):any {
        let hsmList: HSMTabModel = new HSMTabModel(HSMRes, this.localeDataService.getLocalizationService(), this.sharedService, unit);
        return hsmList;
    }

    //function :: changes hcutab list response.
    private changeHSMTabVeiwPortListResponse(HSMRes , localizationService):any {
        let hsmList: HSMTabViewPortModel = new HSMTabViewPortModel(HSMRes ,localizationService);
        return hsmList;
    }

    //Error handler
    public handleError(error) {
        return _throw(error);
    }
}
