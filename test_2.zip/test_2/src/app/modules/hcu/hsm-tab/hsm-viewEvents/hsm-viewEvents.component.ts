import {Component, Input} from '@angular/core';
import {Grid} from "../../../../shared/ag-grid.options";
import {HSMTabDataService} from '../hsmtab.data.service';
import {ViewEventsColumnDefinitionService} from '../../../shared/common-components/listView/viewEvents.column-definition.service';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {ShowAlert} from "./../../../../utilities/showAlert";
import {SharedService} from "../../../../shared/shared.service";
import {HCUTabDataService} from "../../hcu-tab/hcutab.data.service";
import {HCUSharedService} from "../../hcu.shared.service";
import {HEADEND_STEALTH_MODEM} from "../../../../constant/app.constants";

@Component({
    selector:'hsm-view-events',
    templateUrl:'../../../shared/common-components/listView/listView.component.html'
})

export class ViewEventsComponentHSM {
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata:any;
    private tabType = "HCU_VIEW_EVENT";
    private TABLE_LIST_EXPORT_ALL:string;
    private CLOSE_SLIDER:string;
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    public gridTabType:string = "HSMEventExport";
    private tag:string = "HSM view Event Component";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private HSM_VIEW_EVENTS_HEADER:string = "";
    private eventList: any[];
    public styleForHeaderBtns:string = 'max-width:100%'   // Bug fix XPTUI 621


    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    constructor(private hsmTabDataService:HSMTabDataService,
                private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private ViewEventsColumnDefinitionService:ViewEventsColumnDefinitionService,
                private hcuSharedService: HCUSharedService,
                private sharedService:SharedService,private hcuTabDataService: HCUTabDataService){
        this.translateLocaleString();
        this.setEventButtonKeys();
    }

    //on component initialize
    ngOnInit():void{
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //Method to set button keys
    private setEventButtonKeys():void {

        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'HCU_VIEW_EVENT', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'HCU_VIEW_EVENT', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }

    // function :: method to call close slider
    private btnClose_click():void{
        this.isCloseRightSlider = true;
    }

    //function :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    // function :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.ViewEventsColumnDefinitionService.getColumnDef());
        this.listViewOptions["getRowHeight"] = (params) => {
            return 18 * (Math.floor(params.data.eventType.length / 45) + 2);
        };
        this.childData && this.getViewEventData();
    }

    //sets slider label.
    private setHeaderLabel(childName?):void {
        this.headerTxt = this.HSM_VIEW_EVENTS_HEADER;
        this.headerTxt =childName ?  this.headerTxt + ' - ' + childName : this.headerTxt;
    }

    // function :: get View Event list Data.
    private getViewEventData():void {
        this.setHeaderLabel(this.childData['0'].label);
        this.hsmTabDataService.getEventList(this.childData["0"].elementId, HEADEND_STEALTH_MODEM).subscribe(this.getThresholdsList.bind(this),this.onError.bind(this))
    }

    private getThresholdsList(eventList: any): void{
        this.eventList = eventList;
        this.hcuTabDataService.getThresholdsName().subscribe(this.processEventList.bind(this),this.onError.bind(this));
    }

    private processEventList(thresholds: any): void{
        this.onViewEventSuccess(this.hcuSharedService.processEventList(this.eventList, thresholds));
    }

    private onViewEventSuccess(data:any):void {
        this.rowdata = data;
        this.totalCount = this.rowdata.length;
        this.setShowAllLabel(this.rowdata.length, this.totalCount);
    }


    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
    }

    // function :: notify grid ready event
    public notifyGridReadyViewEvents(params:any){
        this.setGridColDefinition();
    }

    // function :: notify close slider.
    public notifyCloseSlider(params:any){
        this.isCloseRightSlider = true;
    }

    //refresh grid data
    public notifyRefreshGrid($event){
        this.getViewEventData();
    }

    // function :: sets localization data.
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.HSM_VIEW_EVENTS_HEADER = localizationService.instant('HSM_VIEW_EVENTS_HEADER');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }
}