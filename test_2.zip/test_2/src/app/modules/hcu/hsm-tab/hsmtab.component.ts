import {Component, ViewChild, ElementRef,ComponentFactoryResolver, ViewContainerRef} from '@angular/core';
import {Subject} from 'rxjs';

import {Grid} from "../../../shared/ag-grid.options";
import {HSMTabDataService} from './hsmtab.data.service';
import {HSMTabColumnDefinationService} from './hsmtab.column-definition.service';
import {ViewPortHSM} from './hsm-viewPorts/hsm-viewPorts.component';
import {ViewEventsComponentHSM} from './hsm-viewEvents/hsm-viewEvents.component';
import {ViewPhysicalHSMComponentHSM} from './hsm-viewPhysicalHSM/hsm-viewPhysicalHSM.component';
import {ViewVirtualHSMComponentHSM} from './hsm-viewVirtualHSM/hsm-viewVirtualHSM.component';
import {HsmTabSharedService} from './hsm.service';
import {PortViewComponent} from '../port-tab/port-view/port-view.component';
import {HCUSharedService} from "../hcu.shared.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import { Logger } from "./../../../utilities/logger";
import {ShowAlert} from "./../../../utilities/showAlert";
import {SINGLE_CONTS, ONLY_SINGLE_CONST, ALL, HSM_TAB, PAGE_LIMIT} from "../hcu.constants"
import {HCUTabDataService} from "../hcu-tab/hcutab.data.service";
import {ImportLabelModel} from "../importLabel.model";
import {NAV_LINK_HCU} from "../../../constant/app.constants";
import {SharedService} from '../../../shared/shared.service';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector:'hsmtab-component',
    templateUrl:'hsmtab.component.html'
})

export class HSMTabComponent {
    hsmTabGridOptions: Grid = new Grid();
    public rowdata;
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    private hcuFilterInstance: any;
    private formData = new FormData();
    private tag:string = "HSMComponent";
    public gridTabType:string = "HSMExport";
    private HSM_TAB_ACTION_REPAIR = "";
    private HSM_TAB_ACTION_VIEW_PORT_BROADCAST = "";
    private HSM_TAB_ACTION_IMPORT_LABELS = "";
    private HSM_TAB_ACTION_VIEW_EVENTS = "";
    private HSM_TAB_ACTION_REMOVE_BROADCAST = "";
    private TABLE_LIST_EXPORT_ALL:string;
    private TABLE_LIST_EXPORT_SELECTED:string;
    private HCU_REPAIR_SUCCESS:string;
    public refreshBtnFlag:boolean;
    private measurementUnit:any = "";
    private showAll:boolean = true;
    private SHOW_ALL:string = "";
    private TABLE_LIST_SHOW_LESS:string = "";
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    private showAllBtn: Object[] = [];
    public obj = {};

    @ViewChild('fileInput') fileInput:ElementRef;
    @ViewChild('targetView', { read: ViewContainerRef }) _targetView;

    private ngUnsubscribe:Subject<void> = new Subject<void>();

    constructor(private hsmTabDataService:HSMTabDataService,
                private hsmTabColumnDefinationService:HSMTabColumnDefinationService,
                private hsmTabSharedService:HsmTabSharedService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private localeDataService: LocaleDataService,
                private translate : TranslateService,
                private logger: Logger,
                private showAlert: ShowAlert,
                private sharedService:SharedService,
                private hcuSharedService: HCUSharedService,
                private hcuTabDataService: HCUTabDataService){
                    this.translate.onLangChange.subscribe((response) => {
                this.translateLocaleString();
                this.setEventButtonKeys();
            });
    }

    ngOnInit():void {
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.hsmTabViewPhysicalHSMSubjectListener();
        this.hsmTabViewVirtualHSMSubjectListener();
        this.HSMListRefreshListener();
        this.HSMParentVirtualListener();
        this.HSMVirtualParentListener();
        this.portViewSUbjectListener();
        if(this.sharedService.RetainFilter){
            this.hsmTabDataService.hsmtabfilterchangedata = "";
            this.hcuSharedService.modeldata = "";
        }
    }

    //on success of getMeasurementUnit call .
    private onNext(data: any): void {
        this.measurementUnit = data.value;
        this.getHSMTabData(this.measurementUnit.toLowerCase());
    }

    //Method call on HSM list Refresh
    private HSMListRefreshListener():void {
        //this.getHSMTabData(this.measurementUnit);
        
        this.hcuSharedService.getHSMListRefreshSub().subscribe((res)=>{
            this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
        })
            }

    //this method call on view port subject subscribes from physical HSM view
    private portViewSUbjectListener():void {
        this.hcuSharedService.getPortViewSubjectHSM().subscribe((res)=>{
            this.LoadNodeHSM();
        })
    }

    //this method call on view virtual HSM subject subscribes from physical HSM view
    private HSMVirtualParentListener():void{
        this.hcuSharedService.getVirtualHSMDataSub().subscribe((res)=>{
            this.LoadVirtualHSM(this.rowdata[this.rowdata.findIndex(x => x["elementId"]== this.hcuSharedService.getVirtualHSMID())]);
        })
    }

    //this method call on view parent HSM subject subscribes from virtual HSM view
    private HSMParentVirtualListener():void{
        this.hcuSharedService.getParentHSMDataSub().subscribe((res)=>{
            this.LoadPhysicalHSM(this.rowdata[this.rowdata.findIndex(x => x["elementId"]== this.hcuSharedService.getParentVirtualID())]);
        })
    }

    //Subject listener for Form change
    private hsmTabViewPhysicalHSMSubjectListener(): void{
        this.hsmTabSharedService
            .getHsmTabViewPhysicalHSMSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((formData: any)=>{
                        this.LoadPhysicalHSM(formData.cmtsTabModel);
        });
    }

    /**
     * Overwrites obj1's values with obj2's and adds obj2's if non existent in obj1
     * @param obj1
     * @param obj2
     * @returns obj3 a new object based on obj1 and obj2
     */
    private merge_options(obj1,obj2):{}{
    var obj3 = {};
    for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
    for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
    return obj3;
}

    //Subject listener for Form change
    private hsmTabViewVirtualHSMSubjectListener(): void{
        this.hsmTabSharedService
            .getHsmTabViewVirtualHSMSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((formData: any)=>{
                        this.LoadVirtualHSM(formData.cmtsTabModel);
        });
    }

    //Method to load Physical HSM components
    private LoadPhysicalHSM(response): void{
        this.createComponentPerSlide(ViewPhysicalHSMComponentHSM, response);
    }

    //Method to load Node components
    private LoadNodeHSM(): void{
        this.createComponentPerSlide(PortViewComponent);
    }

    //Method to load Virtual components
    private LoadVirtualHSM(response): void{
        this.createComponentPerSlide(ViewVirtualHSMComponentHSM, response);
    }

    //Method to call while creating components
    private createComponentPerSlide(componentOBJ , componentData?){
        this._targetView.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(componentOBJ);
        if(componentData) {
            this._targetView.createComponent(factory).instance.childData = componentData;
        } else {
            this._targetView.createComponent(factory);
        }
    }

    //Method to call whaen filters change
    public notifyFilterChangeHSM(e: any): void{
        this.sharedService.RetainFilter = false;
        //this.hcuSharedService.getNameFilterText(this.hcuFilterInstance, "hcu");
        this.hsmTabDataService.hsmtabfilterchangedata = this.hsmTabGridOptions.api.getFilterModel();
        const countryFilterComponent = this.hsmTabGridOptions.api.getFilterInstance('hcuLabel');
        const model = countryFilterComponent.getModel();
        this.hcuSharedService.modeldata = model;
        this.hsmTabDataService.hsmtabfilterchangedata = this.hsmTabGridOptions.api.getFilterModel();
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.eventKeys = [
            {name:this.HSM_TAB_ACTION_REPAIR,status:ONLY_SINGLE_CONST, tabType:HSM_TAB, disable:false, KEY : NAV_LINK_HCU},
            {name:this.HSM_TAB_ACTION_VIEW_PORT_BROADCAST,status:ONLY_SINGLE_CONST, tabType:HSM_TAB,disable:false, KEY : NAV_LINK_HCU},
            {name:this.HSM_TAB_ACTION_VIEW_EVENTS,status:ONLY_SINGLE_CONST,disable:false,},
            {name: this.TABLE_LIST_EXPORT_SELECTED, status: SINGLE_CONTS, tabType: HSM_TAB },
            {name:this.TABLE_LIST_EXPORT_ALL,status:ALL, tabType:HSM_TAB},
        ];
        this.buttonKeys = [
            {name:this.HSM_TAB_ACTION_IMPORT_LABELS , tabType:HSM_TAB,disable:false, KEY : NAV_LINK_HCU},
        ];
        this.refreshBtnFlag = true;
    }

    //function :: makes api call to get hsm data.
    private getHSMTabData(unit):void {
        if(this.hsmTabGridOptions.api){
            if (this.sharedService.getFilterAlarmForTAB().length > 0) {
                this.hsmTabGridOptions.api.getFilterInstance('label').setFilter(this.sharedService.getFilterAlarmForTAB());
                this.sharedService.setFilterAlarmForTab("");
            } else {
                this.hcuSharedService.applyNameFilter(this.hcuFilterInstance,"hcu");
            }
            this.hsmTabDataService
                .getAllHSMTabList(unit, this.showAll)
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.onHSMTabDataSuccess.bind(this),this.onError.bind(this));
        }
        if(this.hsmTabGridOptions.api && (this.hsmTabDataService.hsmtabfilterchangedata || this.hcuSharedService.modeldata ))
        {
            //this.hsmTabGridOptions.api.setFilterModel(this.hcuSharedService.hcufilterchangedata1);
              if(this.hsmTabDataService.hsmtabfilterchangedata){
                this.hsmTabGridOptions.api.setFilterModel(this.hsmTabDataService.hsmtabfilterchangedata);
              }
                
            (this.hcuSharedService.modeldata || this.hsmTabDataService.hsmtabfilterchangedata)
            {
            const countryFilterComponent1 = this.hsmTabGridOptions.api.getFilterInstance('hcuLabel');
            countryFilterComponent1.setModel(this.hcuSharedService.modeldata);
            }
            
            
            // const countryFilterComponent2 = this.hsmTabGridOptions.api.getFilterInstance("hcuLabel");
            // countryFilterComponent2.setModel(this.hcuSharedService.rpmmodeldata);
            // console.log("rpm model fetched");
            
            
            
            //this.hsmTabGridOptions.api.setFilterModel(this.hcuSharedService.rpmfilterchangedata1);
            // console.log("filter executed",this.hsmTabDataService.hsmtabfilterchangedata);
            // console.log("filter executed2",this.hcuSharedService.hcufilterchangedata1);
            //console.log("filter executed",this.hcuSharedService.rpmfilterchangedata1);
            // const countryFilterComponent2 = this.hsmTabGridOptions.api.getFilterInstance("hcuLabel");
            // countryFilterComponent2.setModel(this.hcuSharedService.rpmmodeldata);
             
        }

    }

    private onHSMTabDataSuccess(data:any):void {
        this.rowdata = data;
        this.totalCount = data.totalCount;
        this.setShowAllLabel(data.length, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.hsmTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //method showall ports
    private notifyShowAll():void {
        this.action(true);
        this.setShowLessBtn();
    }

    //methods notifies show less
    private notifyShowLess():void {
        this.action(false);
        this.setShowAllBtn();
    }

    //method gets porttab list
    private action(showall:boolean):void {
        this.showLoadingOverlay();
        this.showAll = showall;
        this.getHSMTabData(this.measurementUnit.toLowerCase());
    }

    //method set showAll btn
    private setShowAllBtn():void {
        this.showAllBtn = [{name: this.SHOW_ALL, tabType:'PORT_TAB'}];
    }

    //method set showless btn
    private setShowLessBtn():void {
        this.showAllBtn = [{name: this.TABLE_LIST_SHOW_LESS, tabType:'PORT_TAB'}];
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        let errorResponse = this.showAlert.getErrorCode(error);
        if(errorResponse.errorCode === 3){
            this.hsmTabGridOptions.api.setColumnDefs(this.hsmTabColumnDefinationService.getColumnDef(""));
            this.rowdata = [];
        }

    }

    //function :: notifies that grid is ready.
    public notifyGridReadyHSM(params:any):void {
        this.setGridColDefinition();
    }

    //function :: notifies that actions.
    public notifyActionEmitter($event){
        switch($event.event.name) {
            case this.HSM_TAB_ACTION_REPAIR:
                this.notifyRepair($event.selectedData[0]);
                break;
            case this.HSM_TAB_ACTION_VIEW_PORT_BROADCAST:
                this.notifyViewPortsInBC($event.selectedData);
                break;
            case this.HSM_TAB_ACTION_IMPORT_LABELS:
                this.notifyImportLabels();
                break;
            case this.HSM_TAB_ACTION_VIEW_EVENTS:
                this.notifyViewEvent($event.selectedData);
                break;
            case this.SHOW_ALL:
                this.notifyShowAll();
                break;
            case this.TABLE_LIST_SHOW_LESS:
                this.notifyShowLess();
                break;
            default:
        }
    }

    //function :: notifies to repair error node.
    private notifyRepair(data):void{
        this.hsmTabDataService
            .hsmRepair(data.elementId)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.onRepairSuccess.bind(this), this.onError.bind(this))
    }

    //function :: on repair scusses
    private onRepairSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.HCU_REPAIR_SUCCESS);
        this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
    }

    //function :: notifies to show broadcast list.
    private notifyViewPortsInBC(data):void{
        this.createComponentPerSlide(ViewPortHSM, data);
    }

    //function :: notifies to import buttons.
    private notifyImportLabels():void{
        this.fileInput.nativeElement.click();
    }

    //function :: notifies to show view events.
    private notifyViewEvent(data):void{
        this.createComponentPerSlide(ViewEventsComponentHSM, data);
    }

    //function get callled when input type file selects different file.
    public fileChange(event:any):void {
        this.formData = null;
        if(!this.formData){
            this.formData = new FormData();
        }
        let files: any = event.target.files;
        if(files.length) {
            let file;
            file = files[0];
            this.formData.append('file', file, file.name);
            this.hcuTabDataService
                .importLabels(this.formData, "hsm")
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.handleImportLabelResponse.bind(this),this.onError.bind(this))
        }

    }

    public clearFile(): void{
        let fileInput:any = document.getElementById("fileInput")
        fileInput.value = null;
    }

    //function :: handle import lable response.
    private handleImportLabelResponse(response: ImportLabelModel): void{
        this.fileInput.nativeElement.value = "";
        this.showAlert.showSuccessAlert(response.getMessage(this.localeDataService.getLocalizationService()));
        this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
    }

    // function :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.hsmTabDataService.getMeasurementUnit().subscribe((res)=>{
            let val:string = res.value.toLowerCase() === "dbuv" ? "dBμV": res.value.toLowerCase() === "dbmv" ? "dBmV" : res.value.toLowerCase() === "dbm" ? "dBm": "";
            this.hsmTabGridOptions.api.setColumnDefs(this.hsmTabColumnDefinationService.getColumnDef(val));
            this.hcuFilterInstance = this.hsmTabGridOptions.api.getFilterInstance('hcuLabel');
            if(this.hcuSharedService.getHcmFilterText().length > 0){
                this.showAll = true;
            }
            this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
        }, this.onError.bind(this));

    }

    //function :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.hsmTabGridOptions.api.showLoadingOverlay();
    }

    //refresh grid data
    public notifyRefreshGrid($event):void{
        this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
    }

    /* Method get called when we come in HSM tab after switch the tab */
    public onTabSwitch(): void{
        this.getHSMTabData(this.measurementUnit.toLowerCase());
        this.setGridColDefinition();
    }


    //localization.
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.HSM_TAB_ACTION_REPAIR = localizationService.instant('HCU_HSM_TAB_REPAIR');
        this.HSM_TAB_ACTION_VIEW_PORT_BROADCAST = localizationService.instant('HCU_HSM_TAB_VIEW_PORT_BROADCAST');
        this.HSM_TAB_ACTION_IMPORT_LABELS = localizationService.instant('HCU_HSM_TAB_IMPORT_LABELS');
        this.HSM_TAB_ACTION_VIEW_EVENTS = localizationService.instant('HCU_HSM_TAB_VIEW_EVENTS');
        this.HSM_TAB_ACTION_REMOVE_BROADCAST = localizationService.instant('HCU_HSM_TAB_REMOVE_BROADCAST');
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.TABLE_LIST_EXPORT_SELECTED = localizationService.instant('TABLE_LIST_EXPORT_SELECTED');
        this.HCU_REPAIR_SUCCESS = localizationService.instant('HCU_REPAIR_SUCCESS');
        this.SHOW_ALL = localizationService.instant('SHOW_ALL');
        this.TABLE_LIST_SHOW_LESS = localizationService.instant('TABLE_LIST_SHOW_LESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }
}