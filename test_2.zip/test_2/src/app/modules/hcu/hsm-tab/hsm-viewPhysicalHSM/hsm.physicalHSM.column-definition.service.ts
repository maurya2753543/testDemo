/**
 * Created by narayan.reddy on 31-07-2017.
 */
import {Injectable} from '@angular/core';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {gridCustomComparator} from "../../../../shared/ag-Grid.comparator";
@Injectable()

export class HSMTabPhysicalColumnDefinationService {

    private YES:string;
    private NO:string;
    constructor(private localeDataService:LocaleDataService,){
        this.translateLocaleStr();
    }

    //Header fields with field name and display name.
    private _VIRTUAL_HEADER_FIELDS: any = {
        virtualHsmLabel : {field: "virtualHsmLabel", name: "Virtual HSM"},
        attachedHcuLabel : {field: "attachedHcuLabel", name: "HCU It's Attached To"}

    };

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this._VIRTUAL_HEADER_FIELDS.virtualHsmLabel.name = localizationService.instant('HSM_PHYSICAL_HEADER_VIRTUAL_HSM');
        this._VIRTUAL_HEADER_FIELDS.attachedHcuLabel.name = localizationService.instant('HSM_PHYSICAL_HEADER_HCU_ATTACH');
        this._NODE_HEADER_FIELDS.label.name = localizationService.instant('HCU_NODE');
        this._NODE_HEADER_FIELDS.inFieldViewBroadcast.name = localizationService.instant('HCU_PORT_TAB_IN_BROADCAST');
        this.NO = localizationService.instant('NO');
        this.YES = localizationService.instant('YES');
    }

    /*
     *@name getColumnDefVirtual
     *@desc Get column def for virtual-list data-grid
     *@return array[any]
     */
    public getColumnDefVirtual(): any[] {
        let columnDef: any[] = [
            {
                headerName: '',
                width: 21,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: false,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,

            },
            {
                headerName: this._VIRTUAL_HEADER_FIELDS.virtualHsmLabel.name,
                headerTooltip: this._VIRTUAL_HEADER_FIELDS.virtualHsmLabel.name,
                field: this._VIRTUAL_HEADER_FIELDS.virtualHsmLabel.field,
                minWidth: 200,filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true}
            },
            {
                headerName: this._VIRTUAL_HEADER_FIELDS.attachedHcuLabel.name,
                headerTooltip: this._VIRTUAL_HEADER_FIELDS.attachedHcuLabel.name,
                field: this._VIRTUAL_HEADER_FIELDS.attachedHcuLabel.field,
                comparator: gridCustomComparator,
                minWidth: 200,filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true}
            }
        ];
        return columnDef;
    };


    //Header fields with field name and display name.
    private _NODE_HEADER_FIELDS: any = {
        label : {field: "label", name: "Node"},
        inFieldViewBroadcast : {field: "inFieldViewBroadcast", name: "In Broadcast"},
    };

    /*
     *@name getColumnDefVirtual
     *@desc Get column def for virtual-list data-grid
     *@return array[any]
     */
    public getColumnDefNode(): any[] {
        let columnDef: any[] = [
            {
                headerName: '',
                width: 21,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: false,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
            },
            {
                headerName: this._NODE_HEADER_FIELDS.label.name,
                headerTooltip: this._NODE_HEADER_FIELDS.label.name,
                field: this._NODE_HEADER_FIELDS.label.field,
                minWidth: 200,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true}
            },
            {
                headerName: this._NODE_HEADER_FIELDS.inFieldViewBroadcast.name,
                headerTooltip: this._NODE_HEADER_FIELDS.inFieldViewBroadcast.name,
                field: this._NODE_HEADER_FIELDS.inFieldViewBroadcast.field,
                comparator: gridCustomComparator,
                minWidth: 200,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true},
            }
        ];
        return columnDef;
    };

}
