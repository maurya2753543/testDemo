/**
 * Created by narayan.reddy on 10-07-2017.
 */
import {Component, Input} from '@angular/core';
import {Grid} from "../../../../shared/ag-grid.options";
import {HSMTabDataService} from '../hsmtab.data.service';
import {ShowAlert} from "./../../../../utilities/showAlert";
import {HSMTabColumnDefinationService} from '../hsmtab.column-definition.service';
import {HSMTabPhysicalColumnDefinationService} from './hsm.physicalHSM.column-definition.service';
import {HSMTabPhysicalHSMData ,HSMTabEditHSMData, HSMTabPhysicalNodeModel} from '../model/hsmtab.virtual-Physical.model';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {HCUSharedService} from "../../hcu.shared.service";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {AgGridConfigurationService} from "../../../../shared/agGrid.configuration.service";
import {SharedService} from "../../../../shared/shared.service";
import {
    ALERT_INFO, ALERT_SUCCESS,
} from "../../../../constant/app.constants";
import {
    CommonStrings
} from "../../../../constant/common.strings";
import {EDIT_OPERATION} from '../../hcu.constants';

@Component({
    selector:'hsm-view',
    templateUrl:'hsm-viewPhysicalHSM.component.html'
})

export class ViewPhysicalHSMComponentHSM {
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    private hsmNodetGridOptions: Grid = new Grid();
    private hsmVirtualHSMGridOptions:Grid = new Grid();
    private virtualHSMrowdata:any;
    private NODErowdata:any;
    private VirtualHsmTabType = "HSM_VIEW_VIRTUAL";
    private NodeTabType = "HSM_VIEW_NODE";
    private eventKeys: Object[] ;
    private buttonKeys: Object[] ;
    private tag:string = "HSM view Event Component";
    private modifiedChildData:any;
    private formDisable:boolean;
    private HSM_DELETED_SUCCESS:string;
    private HSM_ALERT_DELETE_HSM:string;
    private HSM_SELECT_NODE_TXT:string;
    private HSM_SELECT_HCU_TXT:string;

    private measurementUnit : string;
    private measurementUnitTxt : string;
    private UNITS_SIG_LVL_DBM : string = "dBm";
    private UNITS_SIG_LVL_DBUV : string = "dBuV";
    private telemetryMaxValue : number;
    private telemetryMinValue : number;
    private actualMinVal:number;
    private HSM_EDIT_SUCCESS: string = "";

    private DOT: string = "";

    private showAllLabel:string = '';
    private showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;

    private totalCount1:number = 0;
    private showAllLabel1:string = '';
    private showAllLabelMob1:string = '';


    constructor(private hsmTabDataService:HSMTabDataService,
                private showAlert: ShowAlert,
                private sweetAlert:SweetAlert,
                private hcuSharedService:HCUSharedService,
                private localeDataService:LocaleDataService,
                private sharedService:SharedService,
                private hsmTabColumnDefinationService:HSMTabColumnDefinationService,
                private agGridConfigurationService:AgGridConfigurationService,
                private physicalColumnDefinationService:HSMTabPhysicalColumnDefinationService){
        this.hsmVirtualHSMGridOptions.rowSelection = "single";
        this.hsmNodetGridOptions.rowSelection = "single";
        this.translateLocaleString();
        //this.modifiedChildData = new HSMTabPhysicalHSMData([]);
    }

    ngOnInit(){
        this.getLocalizeDOT();
        this.closeSlidersSubjectListener();
        this.hsmTabDataService.getMeasurementUnit().subscribe(this.onNext.bind(this), this.onError.bind(this));
    }

    private getLocalizeDOT() : void {
        this.DOT = this.sharedService.getLocalizeDot();
    }

    //methods used to close slider when usersGroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.closeSlider();
        })
    }

    //function :: calls on success of getMeasurementUnit subscribes
    private onNext(data: any): void {
        this.measurementUnit = data.value.toLowerCase();
        this.setDefaultFrqValue(this.measurementUnit.toLowerCase());
        this.initHSMData();
    }

    //set default frequency value
    private setDefaultFrqValue(Unit):void{
        let maxVal:number = 50.00 , minVal:number = 20.00, txt:string = "dBmV", actualMin:number = 20.00,actualMax:number = 50.00;
        switch (Unit)
        {
            // convert to dBuv
            case this.UNITS_SIG_LVL_DBUV.toLowerCase():
                maxVal = 110;
                minVal = 80;
                txt = "dBμV";
                actualMin = 80;
                actualMax = 110;
                break;
            // convert to dBm
            case this.UNITS_SIG_LVL_DBM.toLowerCase():
                maxVal = 1.2;
                minVal = -28.8;
                txt = "dBm";
                actualMin = 0;
                actualMax = 1.2;
                break;
            // convert to dBmV
            default:
                break;
        }
        this.telemetryMaxValue = maxVal;
        this.telemetryMinValue = minVal;
        this.measurementUnitTxt = txt;
        this.actualMinVal = actualMin;

    }

    //HSM data initializing
    private initHSMData() : void {
        this.childData  && this.getPhysicalHSMData();
        this.formDisable = true;
    }

    //get Physical HSM Data.
    private getPhysicalHSMData():void{
        this.hsmTabDataService
            .getHSMDetailData(this.childData.elementId)
            .subscribe((res) =>{
                this.isCloseRightSlider = false;
                this.modifiedChildData = new HSMTabPhysicalHSMData(this.merge_options(this.childData, res));
                this.modifiedChildData.telemetryLevel = this.sharedService.toUserSelectedSigLvlUnits(this.modifiedChildData.telemetryLevel , this.measurementUnit).toFixed(2);

                this.modifiedChildData.telemetryLevel = this.sharedService.replaceDefaultDotWithLocalizeDot(this.modifiedChildData.telemetryLevel, this.DOT);
                this.modifiedChildData.telemetryFreq = this.sharedService.replaceDefaultDotWithLocalizeDot(this.modifiedChildData.telemetryFreq, this.DOT);

                },(error)=>{
                this.closeSlider();
                this.onError(error)
            }
            );
    }

    //function :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.HSM_DELETED_SUCCESS = localizationService.instant("HSM_DELETED_SUCCESS");
        this.HSM_ALERT_DELETE_HSM = localizationService.instant("HSM_ALERT_DELETE_HSM");
        this.HSM_SELECT_HCU_TXT = localizationService.instant("HSM_SELECT_HCU_TXT");
        this.HSM_SELECT_NODE_TXT = localizationService.instant("HSM_SELECT_NODE_TXT");
        this.HSM_EDIT_SUCCESS = localizationService.instant('HSM_EDIT_SUCCESS');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

     /**
     * Overwrites obj1's values with obj2's and adds obj2's if non existent in obj1
     * @param obj1
     * @param obj2
     * @returns obj3 a new object based on obj1 and obj2
     */
    private merge_options(obj1,obj2):{}{
        var obj3 = {};
        for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
        for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
        return obj3;
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
    }

    // go to physical HSM
    private goToVirtualHSM():void{
        var data = this.agGridConfigurationService.getSelectedRows(this.hsmVirtualHSMGridOptions);
        if(data.length > 0 && data.length === 1){
            this.hcuSharedService.setVirtualHSMID(this.agGridConfigurationService.getSelectedRows(this.hsmVirtualHSMGridOptions)[0]["virtualHsmElementId"]);
            this.hcuSharedService.getVirtualHSMDataSub().next();
            this.closeSlider();
        } else {
            this.showAlert.showInfoAlert(this.HSM_SELECT_HCU_TXT);
        }
    }

	// go to selected Node
    private goToSelectedNode():void{
        var data = this.agGridConfigurationService.getSelectedRows(this.hsmNodetGridOptions);
        if(data.length > 0 && data.length === 1){
            let response:any = this.agGridConfigurationService.getSelectedRows(this.hsmNodetGridOptions)[0];
            this.hsmTabDataService.getPortDetails(response.elementId).subscribe((response)=>{
                let data: any = {operation: EDIT_OPERATION, portTabModel: response};
                this.hcuSharedService.setPortTabModelHSM(data);
                this.hcuSharedService.getPortViewSubjectHSM().next(data);
                this.closeSlider();
            },(error)=>{
                this.showAlert.showErrorAlert(error);
            });
        } else {
            this.showAlert.showInfoAlert(this.HSM_SELECT_NODE_TXT);
        }
    }
	// get Virtual HSM data
    private getVirtualData():void {
            this.virtualHSMrowdata = this.modifiedChildData.virtualHsmList;
            this.totalCount = this.virtualHSMrowdata.length;
            this.setShowAllLabel(this.virtualHSMrowdata.length, this.totalCount);
    }
	// get node data
    private getNodeData():void {
        this.NODErowdata = new HSMTabPhysicalNodeModel(this.modifiedChildData.nodeList , this.localeDataService.getLocalizationService());
            this.totalCount1 = this.NODErowdata.length;
            this.setShowAllLabel(this.NODErowdata.length, this.totalCount1);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    private setShowAllLabel1(rowCount, totalCount):void {
        this.showAllLabel1 = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob1 = rowCount + "/" + totalCount;
    }


    //updates row message.
    private modelUpdatedEmitter(e:any):void {
        if(this.virtualHSMrowdata) {
            let rowCount = this.hsmVirtualHSMGridOptions.api.getDisplayedRowCount();
            this.setShowAllLabel(rowCount, this.totalCount);
        }
        if( this.NODErowdata ){
            let rowCount1 = this.hsmNodetGridOptions.api.getDisplayedRowCount();
            this.setShowAllLabel1(rowCount1, this.totalCount1);
        }

    }
	// delete selected HSM data
    private deleteHSM():void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.HSM_ALERT_DELETE_HSM ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.hsmTabDataService
                        .deleteHSM(this.childData.elementId)
                        .subscribe((res) =>{
                            this.showAlert.showInfoAlert(this.HSM_DELETED_SUCCESS);
                            this.hcuSharedService.getHSMListRefreshSub().next();
                            this.closeSlider();
                        },this.onError.bind(this));
                }
            }
        );
    }

    //used for closing right slider.
    private closeSlider():void{
        this.isCloseRightSlider = true;
    }

    // function :: sets grid columns.
    private setGridColDefinitionVirtual():void {
        this.hsmVirtualHSMGridOptions.api.setColumnDefs(this.physicalColumnDefinationService.getColumnDefVirtual());
        this.getVirtualData();
    }

    // function :: sets grid columns.
    private setGridColDefinitionNode():void {
        this.hsmNodetGridOptions.api.setColumnDefs(this.physicalColumnDefinationService.getColumnDefNode());
        this.getNodeData();
    }

    // function :: sets default value for level.
    private setDefaultValLevel(val ,maxVal, minVal):void{
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(val, this.DOT);
        let valLevel: string = this.setDefaultVal(parseFloat(localizeDotToDefaultDot), maxVal, minVal, this.actualMinVal, 2).toString();
        this.modifiedChildData.telemetryLevel = this.sharedService.replaceDefaultDotWithLocalizeDot(valLevel, this.DOT);
    }


    // function :: common set default value function.
    private setDefaultVal(val ,maxVal, minVal, defaultVal, decimalNob):any{
        var nextVal;
        if((val >= minVal && val <= maxVal && val != null)){
            nextVal = val;
        }else if(val > maxVal){
            nextVal = maxVal;
        } else {
            nextVal = defaultVal;
        }
        return parseFloat(nextVal).toFixed(decimalNob);
    }

    //@method :: Restrict TPC in range
    private processTelemetryLevel(): void{
        this.processTelemetryLevelValue();
        this.setDefaultValLevel(this.modifiedChildData.telemetryLevel , this.telemetryMaxValue, this.telemetryMinValue);
    }

    private processTelemetryLevelValue(): void{
        this.modifiedChildData.telemetryLevel = this.sharedService.processNumber(this.modifiedChildData.telemetryLevel, this.DOT);
    }

    //@method :: Restrict TPC in range
    private processFrequency(): void{
        this.processFrequencyValue();
        this.setDefaultValFrq(this.modifiedChildData.telemetryFreq , 1000.00 , 5.000);
    }

    private processFrequencyValue(): void{
        this.modifiedChildData.telemetryFreq = this.sharedService.processNumber(this.modifiedChildData.telemetryFreq, this.DOT);
    }

    // function :: sets default value for frequency.
    private setDefaultValFrq(val ,maxVal, minVal):void{
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(val, this.DOT);
        let valFrequency: string = this.setDefaultVal(parseFloat(localizeDotToDefaultDot), maxVal, minVal, 5.000, 3);
        this.modifiedChildData.telemetryFreq = this.sharedService.replaceDefaultDotWithLocalizeDot(valFrequency, this.DOT);
    }

    // function :: notify grid ready event for virtual
    private notifyGridReadyVirtualHSM():void{
        this.setGridColDefinitionVirtual();
    }

    // function :: notify grid ready event for node
    private notifyGridReadyNodeHSM():void{
        this.setGridColDefinitionNode();
    }

    // function :: saving HSM data on form submit.
    private saveData(data):void{
        let requestData = new HSMTabEditHSMData(data);

        requestData.telemetryLevel = parseFloat(this.sharedService.replaceLocalizeDotWithDefaultDot(requestData.telemetryLevel, this.DOT));
        requestData.telemetryFreq = parseFloat(this.sharedService.replaceLocalizeDotWithDefaultDot(requestData.telemetryFreq, this.DOT));

        requestData.telemetryLevel = this.sharedService.toStandardSigLvlUnits(requestData.telemetryLevel, this.measurementUnit);
        this.hsmTabDataService
            .updateHSMData(requestData)
            .subscribe((res) =>{
                this.showSuccessAlert(this.HSM_EDIT_SUCCESS);
            },(error)=>{
                this.onError(error)
            });

    }

    //@method :: Show success sweet alert
    private showSuccessAlert(successMsg: string): void{
        this.sweetAlert.showAlert(ALERT_SUCCESS, successMsg,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
            (isConfirm)=>{
                if(isConfirm){
                    this.hcuSharedService.getHSMListRefreshSub().next();
                    this.closeSlider();
                }
            });
    }

    // function :: form enable and disable flag.
    private toggleEdit():void{
        this.formDisable = !this.formDisable;
    }
}
