import {Injectable} from '@angular/core';
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {EDIT_ICON} from "../../../constant/app.constants";
import {EDIT_OPERATION} from "../hcu.constants";
import {HsmTabSharedService} from "./hsm.service";
import {Subject} from "rxjs";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {StatusFilter} from "../../../shared/status.filter";
import {TimeFilter} from "../../../shared/time.filter";
import {SharedService} from "../../../shared/shared.service";
import {FloatFilter} from "../../../shared/float.filter";
import {LanguageService} from "../../../shared/locale.language.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from '@ngx-translate/core';

@Injectable()

export class HSMTabColumnDefinationService {

    private NO:string;
    private _HEADER_FIELDS: any = {
        status : {field: "status", name: "Status"},
        label : {field: "label", name: "HSM"},
        hcuLabel : {field: "hcuLabel", name: "HCU"},
        virtual : {field: "virtual", name: "Is Virtual"},
        virtualParentHsmLabel : {field: "virtualParentHsmLabel", name: "Physical HSM"},
        serialNumber : {field: "serialNumber", name: "Serial Number"},
        modelNumber : {field: "modelNumber", name: "Type"},
        telemetryFreq : {field: "telemetryFreq", name: "Telemetry Frequency(MHz)"},
        telemetryLevel : {field: "telemetryLevel", name: "Telemetry Level(dBm)"},
        firmwareRev : {field: "firmwareRev", name: "Firmware Package"},
        edit : {field: "edit", name: "HSM_TAB_HEADER_EDIT"},
        port : {field: "name", name: "HSM_PORT_HEADER"},
        hsm : {field: "hsmName", name: "HCU_HSM_TAB_HEADER_LABEL"},
        rpm : {field: "rpmName", name: "HCU_RPM_TAB_HEADER_RPM"},
        hcu : {field: "hcuName", name: "HCU_RPM_TAB_HEADER_HCU"},
        startDate: {field: "startTime", name: "HSM_TAB_HEADER_START_DATE"},
        timeRemaining: {field: "timeRemaining", name: "HSM_TAB_HEADER_TIME_REMAINING"}
    };

    private hsmTabFormChangeSubject: Subject<any>;
    private hsmTabViewPhysicalHSMSubject: Subject<any>;
    private hsmTabViewVirtualHSMSubject: Subject<any>;


    constructor(private localeDataService:LocaleDataService,
                private translate : TranslateService,
                private hsmTabSharedService:HsmTabSharedService,
                private sharedService:SharedService,
                private languageService : LanguageService){
                    this.translateLocaleStr();
        this.hsmTabFormChangeSubject = this.hsmTabSharedService.getHsmTabFormChangeSubject();
        this.hsmTabViewPhysicalHSMSubject = this.hsmTabSharedService.getHsmTabViewPhysicalHSMSubject();
        this.hsmTabViewVirtualHSMSubject = this.hsmTabSharedService.getHsmTabViewVirtualHSMSubject();
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.status.name = this.translate.instant('HCU_HSM_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.label.name = this.translate.instant('HCU_HSM_TAB_HEADER_LABEL');
        this._HEADER_FIELDS.hcuLabel.name = this.translate.instant('HCU_HSM_TAB_HEADER_HCULABEL');
        this._HEADER_FIELDS.virtual.name = this.translate.instant('HCU_HSM_TAB_HEADER_VIRTUAL');
        this._HEADER_FIELDS.virtualParentHsmLabel.name = this.translate.instant('HCU_HSM_TAB_HEADER_PHYSICAL');
        this._HEADER_FIELDS.serialNumber.name = this.translate.instant('HCU_HSM_TAB_SERIAL_NUMBER');
        this._HEADER_FIELDS.modelNumber.name = this.translate.instant('HCU_HSM_TAB_HEADER_TYPE');
        this._HEADER_FIELDS.telemetryFreq.name = this.translate.instant('HCU_HSM_TAB_TELEMETRY_FRQ');
        this._HEADER_FIELDS.telemetryLevel.name = this.translate.instant('HCU_HSM_TAB_BODY_TELEMETRY_LEVEL');
        this._HEADER_FIELDS.firmwareRev.name = this.translate.instant('HCU_HSM_TAB_HEADER_FIRMWARE_PACKAGE');
        this._HEADER_FIELDS.edit.name = this.translate.instant('HCU_HSM_TAB_EDIT');
        this._HEADER_FIELDS.port.name = this.translate.instant('HSM_PORT_HEADER');
        this._HEADER_FIELDS.hsm.name = this.translate.instant('HCU_HSM_TAB_HEADER_LABEL');
        this._HEADER_FIELDS.rpm.name = this.translate.instant('HCU_RPM_TAB_HEADER_RPM');
        this._HEADER_FIELDS.hcu.name = this.translate.instant('HCU_RPM_TAB_HEADER_HCU');
        this._HEADER_FIELDS.startDate.name = this.translate.instant('HSM_TAB_HEADER_START_DATE');
        this._HEADER_FIELDS.timeRemaining.name = this.translate.instant('HSM_TAB_HEADER_TIME_REMAINING');
        this.NO = this.translate.instant('NO');

    }

        /*
     *@name getColumnDef
     *@desc Get column def for hsm tab data-grid
     *@return array[any]
     */
    public getColumnDef(unit): any[] {
        let unitVal = unit;
        let lang: string = this.languageService.getCurrentLanguage();
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.status.name,headerTooltip: this._HEADER_FIELDS.status.name, field: this._HEADER_FIELDS.status.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 90),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: StatusFilter.ParentFilter,floatingFilterComponent: StatusFilter.ChildFloatingFilter,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.label.name,headerTooltip: this._HEADER_FIELDS.label.name, field: this._HEADER_FIELDS.label.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.label.name, 80),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.hcuLabel.name,headerTooltip: this._HEADER_FIELDS.hcuLabel.name, field: this._HEADER_FIELDS.hcuLabel.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.hcuLabel.name, 80),
                suppressSizeToFit: true,
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                    sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.virtual.name,headerTooltip: this._HEADER_FIELDS.virtual.name, field: this._HEADER_FIELDS.virtual.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.virtual.name, 30),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.virtualParentHsmLabel.name,headerTooltip: this._HEADER_FIELDS.virtualParentHsmLabel.name, field: this._HEADER_FIELDS.virtualParentHsmLabel.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.virtualParentHsmLabel.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.serialNumber.name,headerTooltip: this._HEADER_FIELDS.serialNumber.name, field: this._HEADER_FIELDS.serialNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serialNumber.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.modelNumber.name,headerTooltip: this._HEADER_FIELDS.modelNumber.name, field: this._HEADER_FIELDS.modelNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modelNumber.name, 50),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.telemetryFreq.name,headerTooltip: this._HEADER_FIELDS.telemetryFreq.name, field: this._HEADER_FIELDS.telemetryFreq.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.telemetryFreq.name, 40), floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                filter: FloatFilter.ParentFilter,floatingFilterComponent: FloatFilter.ChildFloatingFilter,
                cellRenderer: ((param:any)=>{
                    let value: string = this.sharedService.toDecimal(param.data.telemetryFreq,  "1.3");

                    return "<span>".concat(value, "</span>");
                })
            },
            {
                headerName: this._HEADER_FIELDS.telemetryLevel.name + "( "+unitVal+" )",headerTooltip: this._HEADER_FIELDS.telemetryLevel.name+ "( "+unitVal+" )", field: this._HEADER_FIELDS.telemetryLevel.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.telemetryLevel.name, 100),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                filter: FloatFilter.ParentFilter,floatingFilterComponent: FloatFilter.ChildFloatingFilter,
                cellRenderer: ((param:any)=>{
                    let value: string = this.sharedService.toDecimal(param.data.telemetryLevel,  "1.2");
                    return "<span>".concat(value, "</span>");
                })
            },
            {
                headerName: this._HEADER_FIELDS.firmwareRev.name,headerTooltip: this._HEADER_FIELDS.firmwareRev.name, field: this._HEADER_FIELDS.firmwareRev.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareRev.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                minWidth: 70, maxWidth: 150,
				pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }

        ];
        return columnDef;
    }

    public getViewPortColumnDef(): any[] {
        let columnDef: any[] = [
            {
                headerName: '',
                width: 21,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: false,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.port.name,headerTooltip: this._HEADER_FIELDS.port.name, field: this._HEADER_FIELDS.port.field,
                minWidth: 100, filter: 'agTextColumnFilter',sort: 'asc',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep',
                suppressAndOrCondition: true,}
            },
            {
                headerName: this._HEADER_FIELDS.hsm.name,headerTooltip: this._HEADER_FIELDS.hsm.name, field: this._HEADER_FIELDS.hsm.field,
                minWidth: 100, filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.rpm.name,headerTooltip: this._HEADER_FIELDS.rpm.name, field: this._HEADER_FIELDS.rpm.field,
                minWidth: 100, filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.hcu.name,headerTooltip: this._HEADER_FIELDS.hcu.name, field: this._HEADER_FIELDS.hcu.field,
                minWidth: 100, filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.startDate.name,headerTooltip: this._HEADER_FIELDS.startDate.name, field: this._HEADER_FIELDS.startDate.field,
                minWidth: 200,
                filter: TimeFilter.ParentFilter,
                floatingFilterComponent: TimeFilter.ChildFloatingFilter,
                comparator: this.sharedService.dateComparator,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                cellRenderer:(params:any)=>{
                    return  this.sharedService.getLocaleDate(params.value);
                }
            },
            {
                headerName: this._HEADER_FIELDS.timeRemaining.name,headerTooltip: this._HEADER_FIELDS.timeRemaining.name, field: this._HEADER_FIELDS.timeRemaining.field,
                minWidth: 100, filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'},
                cellRenderer: (params:any)=> {
                    return params.value;
                }

            },
        ];
        return columnDef;
    }

    //@method :: callback action for clear icon click
    private action(param: any): void{
        let data: any = {operation: EDIT_OPERATION, cmtsTabModel: param.data};
        if(param.data.virtual === this.NO){
            this.hsmTabSharedService.setViewPhysicalHSMData(data);
            this.hsmTabViewPhysicalHSMSubject.next(data);
        } else {
            this.hsmTabSharedService.setViewVirtualHSMData(data);
            this.hsmTabViewVirtualHSMSubject.next(data);
        }

    }
}
