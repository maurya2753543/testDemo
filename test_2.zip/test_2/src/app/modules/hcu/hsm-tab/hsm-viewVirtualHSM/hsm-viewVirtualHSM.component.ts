/**
 * Created by narayan.reddy on 12-07-2017.
 */
import {Component, Input} from '@angular/core';
import {HSMTabPhysicalHSMData , HSMTabEditHSMData} from '../model/hsmtab.virtual-Physical.model';
import {HSMTabDataService} from '../hsmtab.data.service';
import {ShowAlert} from "./../../../../utilities/showAlert";
import {HCUSharedService} from "../../hcu.shared.service";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {SharedService} from "../../../../shared/shared.service";
import {
    ALERT_INFO, ALERT_SUCCESS,
} from "../../../../constant/app.constants";
import {
    CommonStrings
} from "../../../../constant/common.strings";


@Component({
    selector:'hsm-view',
    templateUrl:'hsm-viewVirtualHSM.component.html'
})

export class ViewVirtualHSMComponentHSM {
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    private gridTabType = "HSM_VIEW_VIRTUAL";
    private NodeTabType = "HSM_VIEW_NODE";
    private eventKeys: Object[] ;
    private buttonKeys: Object[] ;
    private tag:string = "HSM view Virtual Component";
    private modifiedChildData:any;
    private formDisable:boolean;
    private HSM_DELETED_SUCCESS:string;
    private HSM_ALERT_DELETE_HSM:string;
    private telemetryLevelTXT:string;
    private HSM_EDIT_SUCCESS: string = "";
    private measurementUnit:any;
    private DOT: string = "";

    constructor(private hsmTabDataService:HSMTabDataService,
                private showAlert: ShowAlert,
                private sweetAlert:SweetAlert,
                private sharedService:SharedService,
                private localeDataService:LocaleDataService,
                private hcuSharedService:HCUSharedService
    ){
        this.translateLocaleString();
    }

    //function :: on component initializes
    ngOnInit():void{
        this.getLocalizeDOT();
        this.closeSlidersSubjectListener();
        this.childData && this.getVirtualData();
        this.formDisable = true;
    }

    private getLocalizeDOT() : void {
        this.DOT = this.sharedService.getLocalizeDot();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.closeSlider();
        })
    }

    //function ::get Virtual HSM data
    private getVirtualData():void{
        this.hsmTabDataService.getMeasurementUnit().subscribe((res)=>{
            this.measurementUnit = res.value.toLowerCase();
            this.telemetryLevelTXT = res.value.toLowerCase() === "dbuv" ? "dBμV": res.value.toLowerCase() === "dbmv" ? "dBmV" : res.value.toLowerCase() === "dbm" ? "dBm": "";
            let resVal = res.value;
            this.hsmTabDataService
                .getHSMDetailData(this.childData.elementId)
                .subscribe((res) =>{
                    this.isCloseRightSlider = false;
                    this.modifiedChildData = new HSMTabPhysicalHSMData(this.merge_options(this.childData, res));
                    this.modifiedChildData.telemetryLevel = this.sharedService.toUserSelectedSigLvlUnits(this.modifiedChildData.telemetryLevel , resVal.toLowerCase()).toFixed(2);

                    this.modifiedChildData.telemetryLevel = this.sharedService.replaceDefaultDotWithLocalizeDot(this.modifiedChildData.telemetryLevel, this.DOT);
                    this.modifiedChildData.telemetryFreq = this.sharedService.replaceDefaultDotWithLocalizeDot(this.modifiedChildData.telemetryFreq, this.DOT);

                },(error)=>{
                    this.closeSlider();
                    this.onError(error)
                });
        }, this.onError.bind(this));

    }

    //function :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.HSM_DELETED_SUCCESS = localizationService.instant("HSM_DELETED_SUCCESS");
        this.HSM_ALERT_DELETE_HSM = localizationService.instant("HSM_ALERT_DELETE_HSM");
        this.HSM_EDIT_SUCCESS = localizationService.instant('HSM_EDIT_SUCCESS');
    }

    /**
     * Overwrites obj1's values with obj2's and adds obj2's if non existent in obj1
     * @param obj1
     * @param obj2
     * @returns obj3 a new object based on obj1 and obj2
     */
    private merge_options(obj1,obj2):{}{
        var obj3 = {};
        for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
        for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
        return obj3;
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
    }

    //function :: method to close right slider
    private closeSlider():void{
        this.isCloseRightSlider = true;
    }

    //function :: delete HSM
    private deleteHSM():void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.HSM_ALERT_DELETE_HSM ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.hsmTabDataService
                        .deleteHSM(this.childData.elementId)
                        .subscribe((res) =>{
                            this.showAlert.showInfoAlert(this.HSM_DELETED_SUCCESS);
                            this.hcuSharedService.getHSMListRefreshSub().next();
                            this.closeSlider();
                        },this.onError.bind(this));
                }
            }
        );
    }

    //function :: call Parent HSM
    private goToParentHSM(data):void{
        this.hcuSharedService.setParentVirtualID(data);
        this.hcuSharedService.getParentHSMDataSub().next();
        this.closeSlider();
    }

    //function :: to save HSM  DATA
    private saveData(data):void{
        let requestData = new HSMTabEditHSMData(data);
        requestData.telemetryLevel = parseFloat(this.sharedService.replaceLocalizeDotWithDefaultDot(requestData.telemetryLevel, this.DOT));
        requestData.telemetryFreq = parseFloat(this.sharedService.replaceLocalizeDotWithDefaultDot(requestData.telemetryFreq, this.DOT));
        requestData.telemetryLevel = this.sharedService.toStandardSigLvlUnits(requestData.telemetryLevel, this.measurementUnit);
        this.hsmTabDataService
            .updateHSMData(new HSMTabEditHSMData(requestData))
            .subscribe((res) =>{
                this.showSuccessAlert(this.HSM_EDIT_SUCCESS);
            },this.onError.bind(this));
    }

    //@method :: Show success sweet alert
    private showSuccessAlert(successMsg: string): void{
        this.sweetAlert.showAlert(ALERT_SUCCESS, successMsg,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
            (isConfirm)=>{
                if(isConfirm){
                    this.hcuSharedService.getHSMListRefreshSub().next();
                    this.closeSlider();
                }
            });
    }

    //function :: Form disable and enable.
    private toggleEdit():void{
        this.formDisable = !this.formDisable;
    }

}
