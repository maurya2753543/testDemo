/**
 * Created by narayan.reddy on 10-07-2017.
 */

import {Injectable} from "@angular/core";
import {Subject} from "rxjs";

@Injectable()
export class HsmTabSharedService{

    //----HSM Tab----
    private hsmTabFormChangeSubject: Subject<any>;
    private hsmTabViewPhysicalHSMSubject: Subject<any>;
    private hsmTabViewVirtualHSMSubject: Subject<any>;
    private hsmTabModelData: any;
    private physicalHSMModelData: any;
    private virtualHSMModelData: any;

    constructor(){
        this.initSubjects();
    }

    public getHsmTabFormChangeSubject(): Subject<any>{
        return this.hsmTabFormChangeSubject;
    }

    public getHsmTabViewPhysicalHSMSubject(): Subject<any>{
        return this.hsmTabViewPhysicalHSMSubject;
    }

    public getHsmTabViewVirtualHSMSubject(): Subject<any>{
        return this.hsmTabViewVirtualHSMSubject;
    }

    private initSubjects(): void{
        this.hsmTabFormChangeSubject = new Subject();
        this.hsmTabViewPhysicalHSMSubject = new Subject();
        this.hsmTabViewVirtualHSMSubject = new Subject();
    }

    public setViewPhysicalHSMData(physicalHsmModelData: any): void{
        this.physicalHSMModelData = physicalHsmModelData;
    }

    public setViewVirtualHSMData(virtualHsmModelData: any): void{
        this.virtualHSMModelData = virtualHsmModelData;
    }

    public setHsmTabModelData(hsmTabModelData: any): void{
        this.hsmTabModelData = hsmTabModelData;
    }
}
