/**
 * Created by narayan.reddy on 31-07-2017.
 */

import {ONLINE} from "../../hcu.constants";

export class HSMTabModel extends Array {
    public isShowAll:boolean;
    public totalCount:number;
    constructor(jsonData, localizationService:any, sharedService:any, unit:any){
        super();

        if(jsonData.hsmList){
            for(let i=0; i<jsonData.hsmList.length; i++) {
                let hcuData: HSMTabListItems = new HSMTabListItems(jsonData.hsmList[i], localizationService,sharedService, unit);
                this.push(hcuData);
            }
            this.totalCount = jsonData.totalCount;
            this.isShowAll = (jsonData.hsmList.length == jsonData.totalCount) ? false : true;
        }
    }
}


export class HSMTabViewPortModel extends Array {
    constructor(jsonData ,localizationService){
        super();

        if(jsonData){
            for(let i=0; i<jsonData.length; i++) {
                let hcuData: HSMTabViewPortListItems = new HSMTabViewPortListItems(jsonData[i] , localizationService);
                this.push(hcuData);
            }
        }
    }
}

export class HSMTabListItems {
    public elementId:number;
    public status:string;
    public label:string;
    public hcuId:number;
    public hcuLabel:string;
    public serialNumber:string;
    public modelNumber:string;
    public slotNumber:number;
    public firmwareRev:string;
    public virtual:boolean;
    public virtualParentHsmLabel:any;
    public telemetryFreq:number;
    public telemetryLevel:number;
    constructor(HSMList, localizationService, sharedService, unit) {
        if (HSMList) {
            this.elementId = HSMList.elementId;
            this.status = (HSMList.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()) : localizationService.instant(HSMList.status.toUpperCase());
            this.status = this.status.toUpperCase();
            this.label = HSMList.label;
            this.hcuId = HSMList.hcuId;
            this.hcuLabel = HSMList.hcuLabel;
            this.label = HSMList.label;
            this.serialNumber = HSMList.serialNumber;
            this.modelNumber = HSMList.modelNumber;
            this.slotNumber = HSMList.slotNumber;
            this.firmwareRev = HSMList.firmwareRev;
            this.virtual = (HSMList.virtual) ? localizationService.instant('YES') : localizationService.instant('NO');
            this.virtualParentHsmLabel = HSMList.virtualParentHsmLabel;
            this.telemetryFreq = HSMList.telemetryFreq.toFixed(3);
            this.telemetryLevel = parseFloat(sharedService.toUserSelectedSigLvlUnits(HSMList.telemetryLevel, unit).toFixed(2));

        }
    }
}

export class HSMTabViewPortListItems {
    public id:number;
    public type:string;
    public name:string;
    public broadcastEnabled:boolean;
    public links:Array<{}>;
    public hsmId:number;
    public hsmName:string;
    public rpmId:number;
    public rpmName:string;
    public hcuId:number;
    public hcuName:string;
    public startTime:string;
    public stopTime:string;
    public startFrequency:number;
    public stopFrequency:number;
    public dwellTime:number;
    public timeRemaining:any;
    constructor(HSMViewPortList , localizationService) {
        if (HSMViewPortList) {
            this.id = HSMViewPortList.id;
            this.type = HSMViewPortList.type;
            this.name = HSMViewPortList.name;
            this.broadcastEnabled = HSMViewPortList.broadcastEnabled;
            this.links = HSMViewPortList.links;
            this.hsmId = HSMViewPortList.hsmId;
            this.hsmName = HSMViewPortList.hsmName;
            this.rpmId = HSMViewPortList.rpmId;
            this.rpmName = HSMViewPortList.rpmName;
            this.hcuId = HSMViewPortList.hcuId;
            this.hcuName = HSMViewPortList.hcuName;
            this.startTime = HSMViewPortList.startTime;
            this.stopTime = HSMViewPortList.stopTime;
            this.startFrequency = HSMViewPortList.startFrequency;
            this.stopFrequency = HSMViewPortList.stopFrequency;
            this.dwellTime = HSMViewPortList.dwellTime;
            this.timeRemaining = this.getRemainingTime(this.stopTime ,localizationService);
        }
    }

    private getRemainingTime(stoptime ,localizationService):any{
        let date1:any = new Date();
        let date2:any = Date.parse(stoptime);
        let hours:any = Math.abs(date2 - date1) / 36e5;
        return Math.floor(hours) + " " +localizationService.instant('HOURS_LABEL');
    }
}

