/**
 * Created by narayan.reddy on 31-07-2017.
 */

export class HSMTabVirtualOrPhysicalData {
    private alarmsEnabled:boolean;
    private broadcastEnabled:boolean;
    private created:string;
    private elementId:number;
    private enabled:boolean;
    private firmwareRev:string;
    private label:string;
    private location:string;
    private modelNumber:string;
    private modified:string;
    private nodeList:any;
    private notes:string;
    private olVersion:number;
    private parentAlarmsEnabled:boolean;
    private serialNumber:string;
    private telemetryFreq:number;
    private telemetryLevel:number;
    private virtual:boolean;
    private virtualHsmList:any;
    private virtualParentHsmLabel:string;
    private virtualParentHsmUid:number;
    constructor(HSMData) {
        if (HSMData) {
        this.alarmsEnabled = HSMData.alarmsEnabled;
        this.broadcastEnabled = HSMData.broadcastEnabled;
        this.created = HSMData.created;
        this.elementId = HSMData.elementId;
        this.enabled = HSMData.enabled;
        this.firmwareRev = HSMData.firmwareRev;
        this.label = HSMData.label;
        this.location = HSMData.location;
        this.modelNumber = HSMData.modelNumber;
        this.modified = HSMData.modified;
        this.nodeList = HSMData.nodeList;
        this.notes = HSMData.notes;
        this.olVersion = HSMData.olVersion;
        this.parentAlarmsEnabled = HSMData.parentAlarmsEnabled;
        this.serialNumber = HSMData.serialNumber;
        this.telemetryFreq = HSMData.telemetryFreq;
        this.telemetryLevel = HSMData.telemetryLevel;
        this.virtual = HSMData.virtual;
        this.virtualHsmList = HSMData.virtualHsmList;
        this.virtualParentHsmLabel = HSMData.virtualParentHsmLabel;
        this.virtualParentHsmUid = HSMData.virtualParentHsmUid;
        }
    }
}

export class HSMTabPhysicalHSMData {
    public alarmsEnabled:boolean;
    public broadcastEnabled:boolean;
    public created:string;
    public elementId:number;
    public enabled:boolean;
    public firmwareRev:string;
    public hcuId:number;
    public hcuLabel:string;
    public label:string;
    public location:string;
    public modelNumber:string;
    public modified:string;
    public nodeList:any;
    public notes:string;
    public olVersion:number;
    public parentAlarmsEnabled:boolean;
    public serialNumber:string;
    public slotNumber:any;
    public status:any;
    public telemetryFreq:number;
    public telemetryLevel:number;
    public virtual:boolean;
    public virtualHsmList:any;
    public virtualParentHsmLabel:string;
    public virtualParentHsmUid:number;
    constructor(HSMData) {
        if (HSMData) {
            this.alarmsEnabled = HSMData.alarmsEnabled || false;
            this.broadcastEnabled = HSMData.broadcastEnabled || false;
            this.created = HSMData.created || '';
            this.elementId = HSMData.elementId || 0;
            this.enabled = HSMData.enabled || false;
            this.firmwareRev = HSMData.firmwareRev || '';
            this.hcuId = HSMData.hcuId || 0;
            this.hcuLabel = HSMData.firmwareRev || '';
            this.label = HSMData.label || '';
            this.location = HSMData.location || '';
            this.modelNumber = HSMData.modelNumber || '';
            this.modified = HSMData.modified || '';
            this.nodeList = HSMData.nodeList || [];
            this.notes = HSMData.notes || '';
            this.olVersion = HSMData.olVersion || 0;
            this.parentAlarmsEnabled = HSMData.parentAlarmsEnabled || false;
            this.serialNumber = HSMData.serialNumber || '';
            this.slotNumber = HSMData.slotNumber || 0;
            this.status = HSMData.status || 0;
            this.telemetryFreq = HSMData.telemetryFreq || 0;
            this.telemetryLevel = HSMData.telemetryLevel || 0;
            this.virtual = HSMData.virtual || false;
            this.virtualHsmList = HSMData.virtualHsmList || [];
            this.virtualParentHsmLabel = HSMData.virtualParentHsmLabel || '';
            this.virtualParentHsmUid = HSMData.virtualParentHsmUid || 0;
        }
    }

}

export class HSMTabEditHSMData {
    public elementId: number;
    public created:string;
    public modified:string;
    public label:string;
    public location:string;
    public notes:string;
    public olVersion: number;
    public enabled: boolean;
    public alarmsEnabled: boolean;
    public parentAlarmsEnabled:boolean;
    public serialNumber:string;
    public modelNumber:string;
    public firmwareRev:string;
    public virtualParentHsmLabel:any;
    public virtualParentHsmUid: number;
    public telemetryFreq:number;
    public telemetryLevel:number;
    public broadcastEnabled:boolean;
    public virtual:boolean;

    constructor(HSMData) {
        if (HSMData) {
            this.alarmsEnabled = HSMData.alarmsEnabled;
            this.broadcastEnabled = HSMData.broadcastEnabled;
            this.created = HSMData.created;
            this.elementId = HSMData.elementId;
            this.enabled = HSMData.enabled;
            this.firmwareRev = HSMData.firmwareRev;
            this.label = HSMData.label;
            this.location = HSMData.location;
            this.modelNumber = HSMData.modelNumber;
            this.modified = HSMData.modified;
            this.notes = HSMData.notes;
            this.olVersion = HSMData.olVersion;
            this.parentAlarmsEnabled = HSMData.parentAlarmsEnabled;
            this.serialNumber = HSMData.serialNumber;
            this.telemetryFreq = HSMData.telemetryFreq;
            this.telemetryLevel = HSMData.telemetryLevel;
            this.virtual = HSMData.virtual;
            this.virtualParentHsmLabel = HSMData.virtualParentHsmLabel;
            this.virtualParentHsmUid = HSMData.virtualParentHsmUid;
        }
    }

}

export class HSMTabPhysicalNodeModel extends Array {
    constructor(jsonData ,localizationService){
        super();

        if(jsonData){
            for(let i=0; i<jsonData.length; i++) {
                let hsmData: HSMTabPhysicalNodeListItem = new HSMTabPhysicalNodeListItem(jsonData[i] , localizationService);
                this.push(hsmData);
            }
        }
    }
}

export class HSMTabPhysicalNodeListItem {
    public elementId:any;
    public label:string;
    public inFieldViewBroadcast:string;

    constructor(HSMTabPhysicalNodeList, localizationService) {
        if (HSMTabPhysicalNodeList) {
            this.elementId = HSMTabPhysicalNodeList.elementId;
            this.label = HSMTabPhysicalNodeList.label;
            this.inFieldViewBroadcast = (HSMTabPhysicalNodeList.inFieldViewBroadcast) ? localizationService.instant('YES') : localizationService.instant('NO');
        }
    }
}
