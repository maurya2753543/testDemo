/**
 * Created by narayan.reddy on 07-07-2017.
 */
import {Component, Input} from '@angular/core';
import {Grid} from "../../../../shared/ag-grid.options";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {HSMTabDataService} from '../hsmtab.data.service';
import {HSMTabColumnDefinationService} from '../hsmtab.column-definition.service';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {HSM_TAB} from "../../hcu.constants";
import {AgGridConfigurationService} from "../../../../shared/agGrid.configuration.service"
import {
    ALERT_INFO, MAX_STRING_LIMIT,
} from "../../../../constant/app.constants";
import {
    CommonStrings
} from "../../../../constant/common.strings";
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'hsm-viewPorts',
    templateUrl:'hsm-viewPorts.component.html'

})

export class ViewPortHSM {
    public isCloseRightSlider:boolean;
    private hsmViewPortGridOptions: Grid = new Grid();
    public rowdata: any;
    @Input('childData') childData: any;
    public buttonKeys: Object[] ;
    public headerTxt:string;
    private footerTxt:string;
    private headerBtn:Object[];
    private footerBtn:Object[];
    private tag:string = "HSM view port Component";
    private HSM_TAB_ACTION_REMOVE_BROADCAST:string;
    private HSM_HEADER_TXT:string;
    private HSM_FOOTER_TXT:string;
    private CLOSE_SLIDER:string;
    private HSM_REMOVE_BROADCAST_TXT:string;
    private ALERT_DELETE_VIEW_BROADCAST_TEXT:string;
    public gridTabType:string = "HSMPortExport";
    public refreshBtnFlag:boolean = false;

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;

    constructor(private hsmTabDataService:HSMTabDataService,
                private showAlert:ShowAlert,
                private sweetAlert:SweetAlert,
                private localeDataService: LocaleDataService,
                private agGridConfigurationService:AgGridConfigurationService,
                private hsmTabColumnDefinationService:HSMTabColumnDefinationService,
                private sharedService:SharedService){
        this.translateLocaleString();
        this.hsmViewPortGridOptions.rowSelection = "single";
}

    ngOnInit(){
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.headerTxt = this.HSM_HEADER_TXT;
        this.footerTxt = this.HSM_FOOTER_TXT;
        this.buttonKeys = [{name:this.CLOSE_SLIDER , tabType:HSM_TAB, iconClass: 'fa fa-times' , txt:' '},];
        this.refreshBtnFlag = true;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.notifyCloseSlidertHSM();
        })
    }

    private getViewPortData(elementID):void {
        this.hsmTabDataService.getAllViewPortBCList(elementID , this.localeDataService.getLocalizationService()).subscribe((res) =>{
            this.rowdata = res;
            this.totalCount = this.rowdata.length;
            this.setShowAllLabel(this.rowdata.length, this.totalCount);
        },this.onError.bind(this))
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    private modelUpdatedEmitter(e:any):void {
        let rowCount = this.hsmViewPortGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //function :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.hsmViewPortGridOptions.api.showLoadingOverlay();
    }

    // function :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.hsmViewPortGridOptions.api.setColumnDefs(this.hsmTabColumnDefinationService.getViewPortColumnDef());
        this.headerTxt = this.headerTxt + ' - ' + this.childData['0'].label;
        this.getViewPortData(this.childData[0].elementId);
    }

    private btnClose_click(){
        this.isCloseRightSlider = true;
    }

    private notifyGridReadyViewPortHSM(){
        this.setGridColDefinition();
    }

    private notifyRemoveBroadcastHSM($event){
        var data = this.agGridConfigurationService.getSelectedRows(this.hsmViewPortGridOptions);
        if(data.length > 0 && data.length === 1){
            this.removeConfirmation(data[0].id);
        } else {
            this.showAlert.showInfoAlert(this.HSM_REMOVE_BROADCAST_TXT);
        }
    }

    private removeConfirmation(elementId){
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.ALERT_DELETE_VIEW_BROADCAST_TEXT ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.removeBroadcastData(elementId);
                }
            }
        );
    }

    private removeBroadcastData(Id){
        this.hsmTabDataService.removeBroadcastData(Id).subscribe(
            (res:any) => {
                if(!res){
                    this.getViewPortData(this.childData[0].elementId);
                }
            },this.onError.bind(this));

    }

    //function called on error of import modem api.
    private onError(error:any):void {
        /*
           Timeout require to show second sweet alert after first (type confirmation) at a single
           point of time.
           If we try to show second sweet alert in the middle of removal process
           of first sweet alert (type confirmation),then it will not show second sweet alert,
           as removal process will remove second sweet alert also.
           Sweet alert does not provides any event notifying sweet alert is completely removed.
           This issue can be reproducible only on fast connection.
       */
        setTimeout(() => {
            this.showAlert.showErrorAlert(error);
        }, 80);
    }


    private notifyCloseSlidertHSM(){
        this.isCloseRightSlider = true;
    }

    //refreshes slider
    private notifyRefreshGrid():void {
        this.getViewPortData(this.childData[0].elementId);
    }

    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.HSM_TAB_ACTION_REMOVE_BROADCAST = localizationService.instant('HCU_HSM_TAB_REMOVE_BROADCAST');
        this.HSM_HEADER_TXT = localizationService.instant('HSM_HEADER_TXT');
        this.HSM_FOOTER_TXT = localizationService.instant('HSM_FOOTER_TXT');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.HSM_REMOVE_BROADCAST_TXT = localizationService.instant('HSM_REMOVE_BROADCAST_TXT');
        this.ALERT_DELETE_VIEW_BROADCAST_TEXT = localizationService.instant('ALERT_DELETE_VIEW_BROADCAST_TEXT');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }



}