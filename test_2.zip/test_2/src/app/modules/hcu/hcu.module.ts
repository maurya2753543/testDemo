import {NgModule} from '@angular/core';
import {FormsModule} from "@angular/forms";

//modules
import {AgGridModule} from "ag-grid-angular";
import { CommonModule } from '@angular/common';
//import { LocaleModule, LocalizationModule } from 'angular2localization';
import {LocaleDataService} from "../../shared/locale.data.service";
import { SharedModule } from "../shared/shared.module";
import {HcuRoutes} from "./hcu.routes";
import { TranslateService, TranslateModule,TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { RouterModule } from '@angular/router';

//components
import {HCUTabComponent} from "./hcu-tab/hcutab.component";
import {RPMTabComponent} from "./rpm-Tab/rpmtab.component";
import {PORTTabComponent} from './port-tab/porttab.component';
import {HSMTabComponent} from './hsm-tab/hsmtab.component';
import {MonitoringTabComponent} from './monitoring-tab/monitoringtab.component';
import {MonitoringPlanViewComponent} from './monitoring-tab/monitoringplan-view/monitoringplan-view.component';
import {HCUComponent} from "./hcu.component";
import {HCUViewComponent} from './hcu-tab/hcu-view/hcu-view.component';
import {AddVirtualHSM} from './hcu-tab/hcu-addVirtualHSM/hcu-addvirtualhsm.component';
import {ViewPortHSM} from './hsm-tab/hsm-viewPorts/hsm-viewPorts.component';
import {HCUViewEvent} from './hcu-tab/hcu-viewEvents/hcu-viewevent.component';
import {ViewEventsComponentHSM} from './hsm-tab/hsm-viewEvents/hsm-viewEvents.component';
import {ViewPhysicalHSMComponentHSM} from './hsm-tab/hsm-viewPhysicalHSM/hsm-viewPhysicalHSM.component';
import {ViewVirtualHSMComponentHSM} from './hsm-tab/hsm-viewVirtualHSM/hsm-viewVirtualHSM.component';
import {ViewEventsComponentRPM} from "./rpm-Tab/rpm-view-events/rpm-view-events.component";
import {PORTViewEvent} from "./port-tab/port-viewEvents/port-viewEvent.component";
import {PORTMactrakChannel} from "./port-tab/port-mactrakChannels/port-mactrakChannels.component";
import {HCUMactrakChannel} from "./hcu-tab/hcu-mactrakChannels/hcu-mactrakchannels.component";
import {MonitoringPlanComponent} from "./port-tab/port-monitoringPlan/port-monitoringPlan.component";
import {FirmwareUpgradeHCU} from "./hcu-tab/hcu-firmwareUpgrade/hcu-firmwareUpgrade.component";
import {PortViewComponent} from "./port-tab/port-view/port-view.component";
import {PortBroadcastComponent} from './port-tab/port-broadcast/port-broadcast.component';

//services
import {HCUUrlService} from './hcu.url.service';
import {HCUHttpService} from './hcu.http.service';
import {RPMTabDataService} from "./rpm-Tab/rpmtab.data.service";
import {RpmTabService} from "./rpm-Tab/rpmtab.service";
import {HCUTabDataService} from './hcu-tab/hcutab.data.service';
import {HSMTabDataService} from './hsm-tab/hsmtab.data.service';
import {MonitoringTabDataService} from './monitoring-tab/monitoringtab.data.service';
import {PORTTabDataService} from './port-tab/porttab.data.service';
import {HsmTabSharedService} from './hsm-tab/hsm.service';
import { ContainerDataService } from '../container/container.data.service';
import { ContainerHttpService } from './../container/container-http.service';
import { ContainerUrlService } from './../container/container-url.service';
import {SitesHTTPService} from './../sites/sites.http.service';
import {SitesUrlService} from '../sites/sites.url.service';
import {SiteListDataService} from '../sites/site-list/site-list.data.service';

//coulmn definition services
import {HCUTabColumnDefinationService} from './hcu-tab/hcutab.column-definition.service';
import {HSMTabColumnDefinationService} from './hsm-tab/hsmtab.column-definition.service';
import {PORTTabColumnDefinationService} from './port-tab/porttab.column-definition.service';
import {RPMTabColumnDefinitionService} from "./rpm-Tab/rpmtab.column-definition.service";
import {MonitoringPlanTabColumnDefinitionService} from './monitoring-tab/monitoringtab.column-definition.service';
import {HCUSharedService} from "./hcu.shared.service";
import {ViewEventsColumnDefinitionService} from "../shared/common-components/listView/viewEvents.column-definition.service";
import {AddVirtualHSMColumnDefinationService} from './hcu-tab/hcu-addVirtualHSM/hcu-addvirtualhsm.column-definition';
import {DeployLicenseComponent} from "./rpm-Tab/rpm-deploy-license/deployLicense.component";
import {DeployLicenseColumnDefinitionService} from "./rpm-Tab/rpm-deploy-license/deploy-license.column-definition.service";
import {RpmViewComponent} from "./rpm-Tab/rpm-view/rpm-view.component";
import {RpmOptionNamePipe} from "./rpm-Tab/rpm-view/rpm-option-name.pipe";
import {FirmwareUpgradeColumnDefinationService} from "./hcu-tab/hcu-firmwareUpgrade/hcu-firmwareUpgrade.column-definition";
import {MACTrakChannelsColumnDefinitionService} from '../shared/common-components/listView/mactrakChannels.column-definition.service';
import {HSMTabPhysicalColumnDefinationService} from "./hsm-tab/hsm-viewPhysicalHSM/hsm.physicalHSM.column-definition.service";
import {SitesHttpServiceMock} from '../sites/sites.http.service.mock';
import { HttpClient } from '@angular/common/http';
import { LanguageService } from 'src/app/shared/locale.language.service';
import * as AppConstants from './../../constant/app.constants';
import { CmtsTabSharedService } from '../cmts/cmts-tab.shared.service';
import { HcuBulkEditMacktrakComponent } from './hcu-tab/hcu-bulk-edit-macktrak/hcu-bulk-edit-macktrak.component';
import { CmtsTabDataService } from '../cmts/cmts-tab/cmts-tab.data.service';
import { CMTSHttpService } from '../cmts/cmts.http.service';
import { CMTSUrlService } from '../cmts/cmts.url.service';
import CmtsControlFeatureConfigService from '../cmts/cmts-tab/cmts-control-features/cmtsControlFeature.configuration.service';
import { MultiRangeSliderService } from '../shared/multi-range/multi-range.service';
import { SystemSettingsDataService } from '../system-settings/system-settings.data.service';
import { SystemSettingsHttpService } from '../system-settings/system-settings.http.service';
import { SystemSettingsUrlService } from '../system-settings/system-settings.url.service';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/hcu-locale-`, ".json");
  }


@NgModule({
    imports: [
        FormsModule,
        AgGridModule.withComponents([HCUComponent]),
        HcuRoutes,
        CommonModule,
        // LocaleModule.forRoot(),
        // LocalizationModule.forRoot(),
        SharedModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),
        ],
    declarations: [
        HCUComponent,
        HCUTabComponent,
        RPMTabComponent,
        PORTTabComponent,
        HSMTabComponent,
        MonitoringTabComponent,
        HCUViewComponent,
        MonitoringPlanViewComponent,
        AddVirtualHSM,
        ViewPortHSM,
        HCUViewEvent,
        ViewEventsComponentHSM,
        ViewPhysicalHSMComponentHSM,
        ViewVirtualHSMComponentHSM,
        ViewEventsComponentRPM,
        PORTViewEvent,
        PORTMactrakChannel,
        DeployLicenseComponent,
        RpmViewComponent,
        HCUMactrakChannel,
        MonitoringPlanComponent,
        FirmwareUpgradeHCU,
        RpmOptionNamePipe,
        PortViewComponent,
        PortBroadcastComponent,
        HcuBulkEditMacktrakComponent
        ],
    entryComponents: [
        HCUTabComponent,
        RPMTabComponent,
        PORTTabComponent,
        HSMTabComponent,
        MonitoringTabComponent,
        HCUViewComponent,
        MonitoringPlanViewComponent,
        AddVirtualHSM,
        ViewPortHSM,
        HCUViewEvent,
        ViewEventsComponentHSM,
        ViewPhysicalHSMComponentHSM,
        ViewVirtualHSMComponentHSM,
        ViewEventsComponentRPM,
        PORTViewEvent,
        PORTMactrakChannel,
        HCUMactrakChannel,
        DeployLicenseComponent,
        RpmViewComponent,
        MonitoringPlanComponent,
        FirmwareUpgradeHCU,
        PortViewComponent,
        PortBroadcastComponent,
        HcuBulkEditMacktrakComponent
        ],
    // exports: [HCUComponent],
    providers: [
        RPMTabDataService,
        RpmTabService,
        RPMTabColumnDefinitionService,
        LocaleDataService,
        HCUUrlService,
        HCUHttpService,
        HCUSharedService,
        HCUTabDataService,
        HCUTabColumnDefinationService,
        HSMTabDataService,
        MonitoringTabDataService,
        HSMTabColumnDefinationService,
        MonitoringPlanTabColumnDefinitionService,
        PORTTabDataService,
        PORTTabColumnDefinationService,
        HsmTabSharedService,
        ViewEventsColumnDefinitionService,
        HsmTabSharedService,
        AddVirtualHSMColumnDefinationService,
        DeployLicenseColumnDefinitionService,
        FirmwareUpgradeColumnDefinationService,
        MACTrakChannelsColumnDefinitionService,
        HSMTabPhysicalColumnDefinationService,
        ContainerDataService,
        ContainerHttpService,
        ContainerUrlService,
        SitesHTTPService,
        SitesUrlService,
        SiteListDataService,
        SitesHttpServiceMock,
        TranslateService,
        LanguageService,
        CmtsTabSharedService,
        CmtsTabDataService,
        CMTSHttpService,
        CMTSUrlService,
        CmtsControlFeatureConfigService,
        MultiRangeSliderService,
        SystemSettingsDataService,
        SystemSettingsHttpService,
        SystemSettingsUrlService
        ]
})
export class HCUModule {
}
