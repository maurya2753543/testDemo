/**
 * Created by prayoosh.rawane on 6/30/2017.
 */

import { Injectable } from '@angular/core';
import { PATHTRAK_PATH } from "../../constant/app.constants";
import { SharedService } from "../../shared/shared.service";

@Injectable()

export class HCUUrlService {

     private host:string = "";

    constructor(private sharedService: SharedService){
        this.setHost();
    }

    private setHost(): void{
        this.host = this.sharedService.getHost();
    }

    private getHost() : string{
        return this.host + PATHTRAK_PATH;
    }

    /*---------HCU tab urls starts------------------*/

    /* Return url to get HCU tab list from server */
    public getHCUTabListUrl(): string {
        return this.getHost() + 'hcu';
    }

    /* Return url to get HCU tab list from server */
    public getEventListUrl(element_id: any, type: string): string {
        return this.getHost() + 'event/element/type/' + type+ '/id/' + element_id;
    }

    // import label url
    public getHCUImportLabelUrl(type: string):string {
        return this.getHost() + type +'/import/label';
    }
    
    // hcu reboot url
    public getHCURebootUrl():string {
        return this.getHost() + "hcu/reboot";
    }

    public verifyHCUUrl(hostName:any):string {
        return this.getHost() + 'hcu/verify?hostname=' + hostName;
    }

    public getAddHCUUrl():string {
        return this.getHost() + 'hcu';
    }

    public getRestoreHCUUrl():string {
        return this.getHost() + "hcu/restore";
    }

    public getSyncClockHCUUrl(elementId):string {
        return this.getHost() + "hcu/" + elementId +"/syncclock";
    }

    public getRepairHCUUrl(elementId):string {
        return this.getHost() + "hcu/" + elementId +"/repair";
    }

    public getRepairHSMUrl(elementId):string {
        return this.getHost() + "hsm/" + elementId +"/repair";
    }

    public getHCUDetailsUrl(elementId):string {
        return this.getHost() + "hcu/" + elementId;
    }

    public getEditHCUUrl():string {
        return this.getHost() + 'hcu';
    }

    public getEditHSMUrl():string {
        return this.getHost() + 'hsm';
    }

    public getDeleteHCUUrl(elementId):string {
        return this.getHost() + "hcu/" + elementId;
    }

    public getDeleteBroadcastHSMUrl(elementId):string {
        return this.getHost() + "broadcast/type/port/id/" + elementId;
    }

    public getPingHCUUrl(elementId):string {
        return this.getHost() + "hcu/" + elementId +"/ping";
    }

    public getPhysicalHSMUrl():string {
        return this.getHost() + "hsm/physicalHsm";
    }

    public getCreateVirtualHSMUrl():string {
        return this.getHost() + "hsm/virtual"
    }

    public getFirmwareUpgradeListUrl():string {
        return this.getHost() + "hcu/firmware";
    }

    public checkNewFirmwareReleaseUrl():string {
        return this.getHost() + "hcu/firmware/checklatest";
    }

    public downloadUpgradedFirmwareUrl():string {
        return this.getHost() + "hcu/firmware/download";
    }

    public getLatestFirmwarePackageUrl():string {
        return this.getHost() + "hcu/firmware/latest";
    }

    public getDeleteFirmwarePackageUrl(PACKAGE_VERSION:any):string {
        return this.getHost() + "hcu/firmware?packageVersion="+PACKAGE_VERSION;
    }

    public upgradeFirmwareHCUrl(PACKAGE_VERSION:any):string {
        return this.getHost() + "hcu/firmware?packageVersion="+PACKAGE_VERSION;
    }

    public getMACTrakChannelsUrl(elementId):string {
        return this.getHost() + 'mactrakAvailability/' + elementId;
    }

    public getUCDScanUrl():string {
        return this.getHost() + 'ucd';
    }

    public getMeasurementUrl():string {
        return this.getHost() + "settings/measurementunit";
    }

    public getMacktrakThresholdUrl():string {
        return this.getHost() + "deviceSettings/hcu";
    }   

    public updateMACTrakBulkThresholdUrl(): any{
        return this.getHost() + "deviceSettings/bulkUpdate/"; 
    }

    /*---------HCU tab urls ENDS------------------*/

    /*---------RPM tab urls starts------------------*/

    // returns url to get rpm tab data
    public getRPMUrl(elementId: string):string {
        return this.getHost() + "rpm" + elementId ;
    }

    // returns url to get rpm tab data
    public getRPMEventListUrl(elementId: number, type):string {
        return this.getHost() + "event/element/type/" + type+ "/id/" + elementId ;
    }

    // returns url to get rpm tab data
    public getUploadLicenseUrl():string {
        return this.getHost() + "rpm/license/deploy";
    }

    // returns url to get rpm details data
    public getRpmDetailsUrl():string {
        // TODO :: change this url to actual rpm tab api url.
        //return this.host + PATHTRAK_PATH + "cmts?dt=" + this.getDate();
        return "../app/modules/hcu/rpm-tab/json/rpmDetails.json";
    }


    /*---------RPM tab urls ENDs------------------*/

    /*---------PORT tab urls starts------------------*/

    // returns url to get port tab data
    public getPORTTabListUrl():string {
        return this.getHost() + "rpmport";
    }

    public getPortDetailsUrl(elementId):string {
        return this.getHost() + "rpmport/" + elementId;
    }

    public getEditPortUrl():string {
        return this.getHost() + 'rpmport';
    }

    public getBroadcastUrl(elementId):string {
        return this.getHost() + 'broadcast/type/port/id/' + elementId;
    }

    public getMonitoringPlanUrl(portId):string {
       return this.getHost() + 'features/monitoringplan/' + portId + '/settings';
    }

    public getMonitoringExportPlanUrl(portId):string {
        return this.getHost() + 'features/monitoringplan/export/' + portId;
    }

    public getMonitoringImportPlanUrl():string {
        return this.getHost() + 'features/monitoringplan/import';
    }

    public getMonitoringPlanPasteUrl():string {
        return this.getHost() + 'features/monitoringplan/paste';
    }

    public getThresholdLabelsUrl():string {
        return this.getHost() + 'settings/thresholds';
    }

    public getPortRepairUrl(portId):string {
        return this.getHost() + 'rpmport/' + portId + '/repair'
    }

    public getUserDefinedUrl():string {
        return this.getHost() + 'settings/userDefined';
    }
    /*---------PORT tab urls ENDs------------------*/

    /*---------HSM tab urls starts------------------*/

    // returns url to get hsm tab data
    public getHSMTabListUrl():string {
        // TODO :: change this url to actual hsm tab api url.
        return this.getHost() + "hsm";
    }

    // returns url to get broadcast list data
    public getAllViewPortBCListUrl(hsmId):string {
        return this.getHost() + "broadcast/type/hsm/id/" + hsmId;
    }

    // returns url to get hsm tab data
    public getHSMDetailDataUrl(elementId):string {
        // TODO :: change this url to actual hsm tab api url.
        return this.getHost() + "hsm/" + elementId;
    }

    // returns url to get hsm tab data
    public deleteHSMUrl(elementId):string {
        // TODO :: change this url to actual hsm tab api url.
        return this.getHost() + "hsm/" + elementId;
    }

    /*---------HSM tab urls ENDs------------------*/
    // returns url to get rpm tab data
    public getHSMImportLabelsUrl():string {
        // TODO :: change this url to actual HSM tab api url.
        return this.getHost() + "cmts" ;
    }

    /*---------Monitoring Tab urls starts------------------*/
    public getMonitoringPlanTabUrl():string {
        return this.getHost() + "features/monitoringplan/all";
    }

    public updateMplanNameUrl():string {
        return this.getHost() + "features/monitoringplan";
    }

    public getMonitoringPlanDownloadUrl(elementId):string {
        return this.getHost() + "features/monitoringplan/export/id/" + elementId;
    }    
     /*---------Monitoring Tab urls ENDs------------------*/
   

}
