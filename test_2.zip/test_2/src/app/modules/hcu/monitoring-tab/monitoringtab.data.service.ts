import { Injectable } from "@angular/core";
import {HttpResponse} from "@angular/common/http";
import {HCUHttpService} from "../hcu.http.service";
import { Observable } from "rxjs";
import {map, catchError} from "rxjs/operators";
import { _throw } from 'rxjs/observable/throw';
import { MonitoringTabPlanModel } from "./model/monitoringplan.model";

@Injectable()

export class MonitoringTabDataService {

    public monitoringtabfilterchangedata: any;
    constructor(private hcuHttpService:HCUHttpService){
    }

    //@method :: get all MonitoringPlan list from API
    public getMonitoringPlanDetails(): Observable<any>{
       return this.hcuHttpService.getMonitoringPlanDetails()
        .pipe(map((response) => {           
            return response;
        }),
        catchError(this.handleError));
    }

    //@method :: update MonitoringPlan Name to server
    public updateMonitoringPlanName(data: MonitoringTabPlanModel): Observable<any> {
        return this.hcuHttpService
            .updateMplanName(data)
            .pipe(map((response: HttpResponse<any>) => {
                return response;
            }),
            catchError(this.handleError))
    }

    //@method :: download specific MonitoringPlan details  from API
    public getMonitoringPlanDownload(elementId): Observable<any>{
        return this.hcuHttpService.getMonitoringPlanDownload(elementId)
         .pipe(map((response) => {        
            return response;
         }),
         catchError(this.handleError));
     }
     
    //Error handler
    public handleError(error) {
        return _throw(error);
    }
}