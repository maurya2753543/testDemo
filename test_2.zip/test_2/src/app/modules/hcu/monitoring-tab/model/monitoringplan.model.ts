import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";


export class MonitoringTabPlanModel{
    
    public id: string;
    public name: string;
    public cmtsUsPortCount: string;
    public rpmPortCount: string;

    setData(obj: any, localizationService: any){
        if(obj){            
            this.id = obj.id;
            this.name = obj.name;
            this.cmtsUsPortCount = obj.cmtsUsPortCount;
            this.rpmPortCount = obj.rpmPortCount;
        }
    }

}