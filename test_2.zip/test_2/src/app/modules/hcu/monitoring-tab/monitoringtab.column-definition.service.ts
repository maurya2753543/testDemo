import { Injectable } from "@angular/core";
import { LocaleDataService } from "src/app/shared/locale.data.service";
import { TranslateService } from '@ngx-translate/core';
import {SharedService} from "../../../shared/shared.service";
import {LanguageService} from "../../../shared/locale.language.service";
import {EDIT_ICON, DOWNLOAD_ICON} from "../../../constant/app.constants";
import { gridCustomComparator } from "src/app/shared/ag-Grid.comparator";
import {MonitoringTabDataService} from "../monitoring-tab/monitoringtab.data.service";
//import {MonitoringTabDataService} from './monitoringtab.data.service';
import {ShowAlert} from "./../../../utilities/showAlert";
import {EDIT_OPERATION} from '../hcu.constants';
import {HCUSharedService} from '../hcu.shared.service'; 
import { Subject, Subscription } from "rxjs";
import { MonitoringTabPlanModel } from "./model/monitoringplan.model";
import {saveAs as importedSaveAs} from "file-saver";
import { Logger } from "../../../utilities/logger";
//import { HeadersInterceptor } from "src/app/shared/headers.interceptors";


@Injectable()

export class MonitoringPlanTabColumnDefinitionService {

    private tag:string = "MonitoringPlanTabComponent";
    private fileName:string;
    private mplanViewSubject:Subject<any>;
    subscription: Subscription;
  //Header fields with field name and display name.
    private _HEADER_FIELDS: any = {
        portname : {field: "name", name: "MPLAN_TAB_HEADER_NAME"},
        rpmPortCount : {field: "rpmPortCount", name: "MPLAN_TAB_HEADER_RPM_PORT_COUNT"},
        cmtsUsPortCount : {field: "cmtsUsPortCount", name: "MPLAN_TAB_HEADER_CMTS_PORT_COUNT"},
        lastUpdated : {field: "lastUpdated", name: "MPLAN_TAB_HEADER_LATEST_UPDATED_TIME"},
        link : {field: "link", name: "MPLAN_TAB_HEADER_LINK"},
        edit : {field: "edit", name: "MPLAN_TAB_HEADER_EDIT"},
        
    };

    constructor(private localeDataService:LocaleDataService,
        private translate : TranslateService,
        private monitoringTabDataService:MonitoringTabDataService,
        private hcuSharedService:HCUSharedService,
        private showAlert:ShowAlert,
        private sharedService:SharedService,
        private languageService : LanguageService,
        private logger:Logger
        //,private headerInterceptor:HeadersInterceptor
        ){
          this.translateLocaleStr();
          this.mplanViewSubject = hcuSharedService.getMonitoringPlanListRefreshSub();
        }

        private translateLocaleStr(): void{
          this._HEADER_FIELDS.portname.name = this.translate.instant('MPLAN_TAB_HEADER_NAME');
          this._HEADER_FIELDS.rpmPortCount.name = this.translate.instant('MPLAN_TAB_HEADER_RPM_PORT_COUNT');
          this._HEADER_FIELDS.cmtsUsPortCount.name = this.translate.instant('MPLAN_TAB_HEADER_CMTS_PORT_COUNT');
          this._HEADER_FIELDS.lastUpdated.name = this.translate.instant('MPLAN_TAB_HEADER_LATEST_UPDATED_TIME');
          this._HEADER_FIELDS.link.name = this.translate.instant('MPLAN_TAB_HEADER_LINK');
          this._HEADER_FIELDS.edit.name = this.translate.instant('MPLAN_TAB_HEADER_EDIT');
      }
      
     public getColumnDef(): any[] {
         let columnDef: any[] = [
             {
                 headerName: '',
                 maxWidth: 25,
                 checkboxSelection: true,
                 pinned: true,
                 sortingOrder: [null],
                 field: '',
                 headerCheckboxSelection: true,
                 suppressFilter: true,
                 suppressSizeToFit: true,
                 suppressMenu: true,
                 filterParams: {newRowsAction: 'keep'},
                 suppressResize: true
                 
             },
             {
                 headerName: this._HEADER_FIELDS.portname.name,
                 headerTooltip: this._HEADER_FIELDS.portname.name, 
                 field: this._HEADER_FIELDS.portname.field,
                 width: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.portname.name, 300),
                 floatingFilterComponentParams:{ suppressFilterButton:true },
                 filter: 'agTextColumnFilter',
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
             },
             {
                 headerName: this._HEADER_FIELDS.rpmPortCount.name,
                 headerTooltip: this._HEADER_FIELDS.rpmPortCount.name, 
                 field: this._HEADER_FIELDS.rpmPortCount.field,
                 width : this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rpmPortCount.name, 200),
                 floatingFilterComponentParams:{ suppressFilterButton:true },
                 filter: 'agTextColumnFilter',
                 filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}, 
                 sort: 'desc'
             },
             {
                 headerName: this._HEADER_FIELDS.cmtsUsPortCount.name,
                 headerTooltip: this._HEADER_FIELDS.cmtsUsPortCount.name,
                 field: this._HEADER_FIELDS.cmtsUsPortCount.field,
                 width: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.cmtsUsPortCount.name, 200),
                 filter: 'agTextColumnFilter',
                 floatingFilterComponentParams:{ suppressFilterButton:true },
                 comparator: gridCustomComparator,
                 filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                 sort: 'desc'
             },
             {
                headerName: this._HEADER_FIELDS.lastUpdated.name,
                headerTooltip: this._HEADER_FIELDS.lastUpdated.name,
                field: this._HEADER_FIELDS.lastUpdated.field,
                width: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.lastUpdated.name, 200),
                filter: 'agTextColumnFilter',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                //sort: 'desc',
                cellRenderer: ((param:any)=>{
                    return new Date(param.value).toLocaleString();
                })
            },
             {
                 headerName: this._HEADER_FIELDS.link.name,
                 headerTooltip: this._HEADER_FIELDS.link.name,
                 field: this._HEADER_FIELDS.link.field,
                 width: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.link.name, 100),
                 floatingFilterComponentParams:{ suppressFilterButton:true },
                 pinned: this.sharedService.isPinned(),
                 comparator: gridCustomComparator,
                 cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                 cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = DOWNLOAD_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.actionDownload(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
             },
             {
                 headerName: this._HEADER_FIELDS.edit.name,
                 headerTooltip: this._HEADER_FIELDS.edit.name,
                 field: this._HEADER_FIELDS.edit.field,
                 width: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.edit.name, 120), 
                // suppressSizeToFit: true,
                 pinned: this.sharedService.isPinned(),
                 floatingFilterComponentParams:{ suppressFilterButton:true },
                 comparator: gridCustomComparator,                 
                 //  suppressMenu: true,
                 cellStyle : () => {
                     return { 'text-align': 'center' };
                 },                
                 cellRenderer: ((param:any)=>{
                     let gui = document.createElement('div');
                     gui.innerHTML = EDIT_ICON;
                     let eFilterText = gui.querySelector('i');
                     eFilterText.addEventListener("click", (()=>{
                         this.action(param);
                     }));
                     gui.className = "ag-Grid-cursor";
                     return gui;
                 })
 
             }
 
         ]
         return columnDef;
     }
 

  //method  is used to get details of single monitoring Plan on view icon click.
private action(param):void {
    this.mplanViewSubject.next(<MonitoringTabPlanModel>param.data);
}

 //method :: sets Monitoring Plan model data in hcu shared service.
//  private onPlanDetailsSuccess(response):void {
//     let data: any = {operation: EDIT_OPERATION, MonitoringTabPlanModel: response};
//     this.hcuSharedService.setMplanViewModelData(data);
//     this.hcuSharedService.getMplanFormChangeSub().next(data);
// }

//method :: shows error alert.
private onError(error):void {
    this.showAlert.showErrorAlert(error);
    this.logger.debug(this.tag, "onError(): error data=", error);
}

private actionDownload(param): void {
    this.monitoringTabDataService.getMonitoringPlanDownload(param.data.id).subscribe((data)=>{
       this.onDataSuccess(param,data);
    },this.onError.bind(this));   
}

//function :: on success of export monitoring and downoads csv.
private onDataSuccess(param,blob):void {
    importedSaveAs(blob, param.data.name+'.csv');
}
}



