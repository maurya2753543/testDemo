import { Component, Input, OnDestroy } from "@angular/core";
import { LocaleDataService } from "src/app/shared/locale.data.service";
import { SharedService } from "src/app/shared/shared.service";
import { ShowAlert } from "src/app/utilities/showAlert";
import { SweetAlert } from "src/app/utilities/sweetAlert";
import { HCUSharedService } from "../../hcu.shared.service";
import { MonitoringTabPlanModel } from '../model/monitoringplan.model';
import { MonitoringTabDataService } from "../monitoringtab.data.service";
import { ALERT_SUCCESS} from "../../../../constant/app.constants";
import { CommonStrings } from "../../../../constant/common.strings";

@Component({
    selector: 'monitoringplan-view',
    templateUrl: 'monitoringplan-view.component.html'
})
export class MonitoringPlanViewComponent{

    public isCloseRightSlider:boolean = false;
    public isReadOnlyRPM: boolean = true;
    private name:string;
    private dataModel: any;
    private MPLAN_EDIT_SUCCESS: string = "";

    @Input('childData') childData: any;
    public monitoringTabPlanModel: MonitoringTabPlanModel;

    constructor(private hcuSharedService: HCUSharedService,
        private monitoringTabDataService: MonitoringTabDataService,
        private showAlert: ShowAlert,
        private sharedService: SharedService,
        private sweetAlert: SweetAlert,
        private localeDataService: LocaleDataService){
            this.monitoringTabPlanModel = hcuSharedService.getMonitoringPlanDetailsModel();
        }

ngOnInit(){
    this.translateLocaleString();
    this.closeSlidersSubjectListener();
    this.isCloseRightSlider = false;
    this.setData();
}

//@method :: set data to local model
private setData(): void{
    this.dataModel = this.childData;
    this.setMonitoringPlanData(this.dataModel);
}

private setMonitoringPlanData(response: any): void{
    this.monitoringTabPlanModel.setData(response,this.localeDataService.getLocalizationService());
}

//@method :: close UI side panel
public closeSlider(refreshList: boolean) : void {
    this.isCloseRightSlider = true;
    this.hcuSharedService.getClearMonitoringPlanEditComponentSubject().next(refreshList);
}

//@method :: change to read-write mode
public toggleEdit(): void{
    this.isReadOnlyRPM = false;
}

//@method :: Restrict label text to 100 character
public processLabel(): void{
    this.monitoringTabPlanModel.name = this.sharedService.restrictTo100(this.monitoringTabPlanModel.name);
}

//@method :: Save the changes
public onSubmit(): void{
    this.name = this.monitoringTabPlanModel.name;
    this.monitoringTabDataService.updateMonitoringPlanName(this.monitoringTabPlanModel).subscribe(()=>{
        this.showSuccessAlert(this.MPLAN_EDIT_SUCCESS);
    },this.onError.bind(this));
}

private showSuccessAlert(successMsg: string): void{
    this.sweetAlert.showAlert(ALERT_SUCCESS, successMsg,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
        (isConfirm)=>{
            if(isConfirm){
                this.closeSlider(true);
            }
        });
}

//Handle error
private onError(error): void{
    this.monitoringTabPlanModel ? this.monitoringTabPlanModel.name = this.name : '';
    //Delay is require to show second sweet alert
    //as we can not show two sweet alert at a time
    //wait for 2ms to let 1st sweet alert to removed.
    setTimeout(() => {
        this.showAlert.showErrorAlert(error);
    }, 200);
}

//methods used to close slider when slider opens.
private closeSlidersSubjectListener():void {
    this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
        if(res) this.closeSlider(true);
       
    })
}

//@method :: used for localization
private translateLocaleString():void {
    let localizationService = this.localeDataService.getLocalizationService();
    this.MPLAN_EDIT_SUCCESS = localizationService.instant('MPLAN_EDIT_SUCCESS');
}

}