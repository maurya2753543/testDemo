import {Component, ElementRef, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import { Grid } from '../../../shared/ag-grid.options';
import {HCUSharedService} from "../hcu.shared.service";
import {HCUTabDataService} from "../hcu-tab/hcutab.data.service";
import { TranslateService } from '@ngx-translate/core';
import {MonitoringPlanTabColumnDefinitionService} from "./monitoringtab.column-definition.service";
import {MonitoringTabDataService} from './monitoringtab.data.service';
import { Logger } from "./../../../utilities/logger";
import {ShowAlert} from "./../../../utilities/showAlert";
import {NAV_LINK_HCU} from "../../../constant/app.constants";
import { MonitoringPlanViewComponent } from './monitoringplan-view/monitoringplan-view.component';
import { takeUntil } from 'rxjs/operators';
import { Observable, of, Subject } from 'rxjs';

@Component({
    selector:'monitoringtab-component',
    templateUrl:'monitoringtab.component.html'
})

export class MonitoringTabComponent{
    monitoringplanTabGridOptions: Grid = new Grid();
    public rowdata;
    public eventKeys: Object[] ;
    public buttonKeys: Observable<Object[]>;
    private hcuFilterInstance: any;
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    public refreshBtnFlag:boolean;
    private totalCount:number = 0;
    private tag:string = "MonitoringPlanComponent";
    public gridTabType:string = "MonitoringExport";
    private _MONITORING_PLAN_TAB: string = "MONITORING_PLAN_TAB";

    private TABLE_LIST_EXPORT_ALL:string;
    private TABLE_LIST_EXPORT_SELECTED:string;
    private SHOW_ALL:string = "";
    private TABLE_LIST_SHOW_LESS:string = "";    
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private EXPORT_SELECTED_TEXT: string = "";
    private EXPORT_ALL_TEXT: string = "";
    private ngUnsubscribe:Subject<void> = new Subject<void>();

    @ViewChild('fileInput') fileInput:ElementRef;
    @ViewChild('targetMonitoringPlanSlider', { read: ViewContainerRef }) _targetMonitoringPlanSlider;

    constructor(
        private hcuSharedService: HCUSharedService,
        private hcuTabDataService: HCUTabDataService,
        private logger: Logger,
        private showAlert: ShowAlert,
        private monitoringTabDataService: MonitoringTabDataService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private translate : TranslateService,
        private monitoringPlanTabColumnDefinitionService: MonitoringPlanTabColumnDefinitionService,){
    //         this.translate.onLangChange.subscribe((response) => {
    //     this.translateLocaleString();
    //     this.setEventButtonKeys();
    // });
}

ngOnInit():void {
    this.translateLocaleString();
    this.setEventButtonKeys();    
    this.monitoringPlanListRefreshListener();   
    this.formChangeViewListener();
    this.clearMonitoringPlanEditComponentSubjectListener();
}

private formChangeViewListener() {
    this.hcuSharedService.getMonitoringPlanListRefreshSub().subscribe((res)=>{
        this.LoadViewMonitoringName(res);
    })
}

//Method call on Monitor list Refresh
private monitoringPlanListRefreshListener():void {  
    this.hcuSharedService.getMonitoringPlanListRefreshSub().subscribe((res)=>{
        this.getPlanDetails();
    })
}

public getPlanDetails(){
    this.monitoringTabDataService.getMonitoringPlanDetails().subscribe((data)=>{
        this.onFetchSuccess(data);
    },this.onError.bind(this));
    if(this.monitoringplanTabGridOptions.api && this.monitoringTabDataService.monitoringtabfilterchangedata){
        this.monitoringplanTabGridOptions.api.setFilterModel(this.monitoringTabDataService.monitoringtabfilterchangedata);
        console.log("filter executed",this.monitoringTabDataService.monitoringtabfilterchangedata);
         
    }
}

 //on success of getMonitoringPlanDetails call .
 private onFetchSuccess(data: any): void {
     this.rowdata = data;
     this.totalCount = data.length;
     this.setShowAllLabel(data.length, this.totalCount);
}

//function called on error of import modem api.
private onError(error:any):void {
    this.logger.debug(this.tag, "onError(): error data=", error);
    this.showAlert.showErrorAlert(error);
}

private LoadViewMonitoringName(response: any): void{  
    this.createComponentPerSlide(MonitoringPlanViewComponent, response);
}

//Method to call while creating components
private createComponentPerSlide(componentOBJ , componentData?){
    this._targetMonitoringPlanSlider.clear();
    const factory = this.componentFactoryResolver.resolveComponentFactory(componentOBJ);
   if(componentData) {
        this._targetMonitoringPlanSlider.createComponent(factory).instance.childData = componentData;
     } else {
        this._targetMonitoringPlanSlider.createComponent(factory);
    }
}

 //@listener :: clear component after slider close
 private clearMonitoringPlanEditComponentSubjectListener(): void{
    this.hcuSharedService
        .getClearMonitoringPlanEditComponentSubject()
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe((refreshList: boolean)=>{
        this._targetMonitoringPlanSlider.clear();
        this.refreshAgGrid(refreshList);
    });
}

 //@method :: refresh ag-Grid list
 private refreshAgGrid(refreshList: boolean): void{
    if(refreshList){
        this.getPlanDetails();
    }
}

    public notifyGridReadyMonitoringPlan(params:any):void {
        this.setGridColDefinition();
    }

    private setGridColDefinition():void {
        this.showGridLoadingOverly();
        this.monitoringplanTabGridOptions.api.setColumnDefs(this.monitoringPlanTabColumnDefinitionService.getColumnDef());
        this.getPlanDetails();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.monitoringplanTabGridOptions.api.showLoadingOverlay();
    }

     //Method to call whaen filters change
     public notifyFilterChangePlan(e: any): void{
       this.hcuSharedService.getNameFilterText(this.hcuFilterInstance, "hcu");
       this.monitoringTabDataService.monitoringtabfilterchangedata = this.monitoringplanTabGridOptions.api.getFilterModel();
         console.log("filterchange data",this.monitoringTabDataService.monitoringtabfilterchangedata);
    }

    //refresh
    public notifyRefreshGrid() {
        this.getPlanDetails();
    }

    public notifyActionEmitter($event){
        // switch ($event.event.name) {
        //     case this.TEST_CONNECTION:
        //         this.notifyTestConnectionHCU($event.selectedData[0]);
        //         break;
        //     case this.SYNC_CLOCK:
        //         this.notifySyncHCU($event.selectedData[0]);
        //         break;
        //     case this.SHOW_ALL:
        //         this.notifyShowAll();
        //         break;
        //     case this.TABLE_LIST_SHOW_LESS:
        //         this.notifyShowLess();
        //         break;
        //     default:
        // }
    }

  //updates row message.
  public modelUpdatedEmitter(e:any):void {
     let rowCount = this.monitoringplanTabGridOptions.api.getDisplayedRowCount();
     this.setShowAllLabel(rowCount, this.totalCount);
}

 //method sets showalllabel.
 private setShowAllLabel(rowCount, totalCount):void {
    this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
    this.showAllLabelMob = rowCount + "/" + totalCount;
}

private setEventButtonKeys():void {
    this.eventKeys = [
        {name: this.TABLE_LIST_EXPORT_SELECTED,status:'single', tabType: this._MONITORING_PLAN_TAB},
        {name: this.TABLE_LIST_EXPORT_ALL,status:'all', tabType: this._MONITORING_PLAN_TAB},
    ];
 this.buttonKeys = of([]);
    this.refreshBtnFlag = true;
}

//localization.
private translateLocaleString():void{
    this.TABLE_LIST_EXPORT_ALL = this.translate.instant('TABLE_LIST_EXPORT_ALL');
    this.TABLE_LIST_EXPORT_SELECTED = this.translate.instant('TABLE_LIST_EXPORT_SELECTED');
    this.SHOW_ALL = this.translate.instant('SHOW_ALL');
    this.TABLE_LIST_SHOW_LESS = this.translate.instant('TABLE_LIST_SHOW_LESS');
    this.TABLE_LIST_SHOWING = this.translate.instant('TABLE_LIST_SHOWING');
    this.TABLE_LIST_SHOWING_OF = this.translate.instant('TABLE_LIST_SHOWING_OF');
    this.TABLE_LIST_ROWS = this.translate.instant('TABLE_LIST_ROWS');
}


}