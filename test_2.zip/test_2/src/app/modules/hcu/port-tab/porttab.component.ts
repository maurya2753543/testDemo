import {Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, ElementRef, OnInit} from '@angular/core';

import { Grid } from "../../../shared/ag-grid.options";
import { TranslateService } from '@ngx-translate/core';
import { PORTTabDataService } from './porttab.data.service';
import { PORTTabColumnDefinationService } from './porttab.column-definition.service';
import {HCUSharedService} from "../hcu.shared.service";
import {PORTViewEvent} from './port-viewEvents/port-viewEvent.component';
import {PORTMactrakChannel} from './port-mactrakChannels/port-mactrakChannels.component';
import {MonitoringPlanComponent} from './port-monitoringPlan/port-monitoringPlan.component';
import {PortViewComponent} from './port-view/port-view.component';
import {PORTDetailsModel} from './model/portDetails.model';
import { Logger } from "./../../../utilities/logger";
import {ShowAlert} from "./../../../utilities/showAlert";
import { LocaleDataService } from "./../../../shared/locale.data.service";
import {PortBroadcastComponent} from './port-broadcast/port-broadcast.component';
import {BroadcastModel} from './model/port-broadcast.model';
import { SweetAlert } from '../../../utilities/sweetAlert';
import {ImportLabelModel} from "../importLabel.model";
import {HCUTabDataService} from "../hcu-tab/hcutab.data.service";
import {Subject} from "rxjs";
import {MonitoringPlanModel} from './model/port-monitoringPlan.model';
import {
    ALERT_INFO,
    PERM_ADMINISTER_FIELD_VIEW_BROADCAST,
    NAV_LINK_HCU,
    PERM_ADMINISTER_PATHTRAK_PORTS,
    SUB_FORM_LANGUAGE_LIST_SHORT, ALERT_ERROR, ALERT_SUCCESS
} from "../../../constant/app.constants";
import { CommonStrings } from '../../../constant/common.strings';
import {ViewPortHSM} from '../hsm-tab/hsm-viewPorts/hsm-viewPorts.component';
import {AgGridConfigurationService} from "../../../shared/agGrid.configuration.service";
import {PAGE_LIMIT} from "../hcu.constants";
import {SharedService} from "../../../shared/shared.service";
import {LanguageService} from "../../../shared/locale.language.service";
import { SeverityFilter } from "./severity.filter";
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'porttab-component',
    templateUrl: 'porttab.component.html'
})

export class PORTTabComponent implements OnInit {
    public portTabGridOptions: Grid = new Grid();
    public rowdata :any;
    private hcuFilterInstance: any;
    public eventKeys: Object[] = [];
    public buttonKeys: Object[] = [];
    public gridResizeVal:number;
    public SPECTRUM: string;
    public QAMTRAK: string;
    public HEATMAP: string;
    private tag:string = "PORTTabComponent";
    private ADD_TO_BROADCAST:string = "";
    private REMOVE_FROM_BROADCAST:string = "";
    private VIEW_IN_BROADCAST:string = "";
    private VIEW_MACTRAK_CHANNELS:string = "";
    private REPAIR:string = "";
    private COPY_MONITORING:string = "";
    private VIEW_MONITORING:string = "";
    private SELECT_ALL:string = "";
    private VIEW_EVENTS:string = "";
    private PASTE_MONITORING:string = "";
    private IMPORT_LABELS:string = "";
    private TREE_TABLE_VIEW: string = "";
    private NORMAL_TABLE_VIEW: string = "";
    private GRID_EXPORT_ALL:string = "";
    private GRID_EXPORT_SELECTED:string = "";
    private copyPortId:number = null;
    private pastePortIds:Array<number> = [];
    private PORT_MONITORING_PASTE_SUCCESS:string = "";
    private PORT_COPY_MONITORIN_INFO_MSG:string = "";
    private HCU_REPAIR_SUCCESS:string = "";
    private PORT_ADD_NODE_BC_SUCCESS:string = "";
    private PORT_REMOVED_FROM_BROADCAST_SUCCESS:string = "";
    private ngUnsubscribe:Subject<void> = new Subject<void>();
    private formData = new FormData();
    private monitoringPlanModel:MonitoringPlanModel = new MonitoringPlanModel({});
    private MONITORING_PASTE_ON_SAME_MSG:string = "";
    public refreshBtnFlag: boolean;
    private oldPortId:number;
    private currentValue:number;
    private PORT_BROADCAST_CONFORMATION_TITLE:string = "";
    private PORT_203_BROADCAST_CONFORMATION_MSG:string = "";
    private YES:string = "";
    private NO:string = "";
    private PORT_NOT_IN_BROADCAST_MSG:string = "";
    private PORT_IN_BROADCAST_MSG:string = "";
    private PORT_MONITORING_COPY_SUCCESS_MSG:string = "";
    public gridTabType:string = "PORTExport";
    private SHOW_ALL: string = "Show All";
    private showAll:boolean = true;
    private TABLE_LIST_SHOW_LESS:string = "";
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private rpmFilterInstance: any;
    private rowCount:number;
    private totalCount:number = 0;
    private showAllBtn: Object[] = [];
    private Ok:string = '';
    private Error : string = '';
 
    @ViewChild('fileInput') fileInput: ElementRef;
    @ViewChild('targetSliderView', { read: ViewContainerRef }) _targetSliderView;
    dataApi: any;
    constructor(private portTabDataService: PORTTabDataService,
                private portTabColumnDefinationService: PORTTabColumnDefinationService,
                private languageService: LanguageService,
                private hcuSharedService: HCUSharedService,
                private hcuTabDataService: HCUTabDataService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private logger: Logger,private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private sweetAlert:SweetAlert,
                private sharedService: SharedService,
                private agGridConfigurationService: AgGridConfigurationService,
                public  translate: TranslateService){
                    this.translate.onLangChange.subscribe((response) => {
                this.translateLocaleString();
                this.setEventButtonKeys();
            //    this.portViewSUbjectListener();
            //    this.portRefreshListSubject();
            //    this.getPortClearSliderSubListener();
            });
    }

    ngOnInit() {
        this.translateLocaleString();
        this.setEventButtonKeys();
         this.portViewSUbjectListener();
        this.portRefreshListSubject();
         this.getPortClearSliderSubListener();
        this.portTabGridOptions.suppressAggFuncInHeader = true;
        this.portTabGridOptions.groupMultiAutoColumn = true;
        this.portTabGridOptions.enableRangeSelection = true;
    }

    //method :: call clear slider when slider closed.
    private getPortClearSliderSubListener():void {
        this.hcuSharedService.getPortClearSliderSub().subscribe((res)=>{
            if(res) this.clearSlider();
        })
    }

    //method :: refresh ports list in subject listen.
    private portRefreshListSubject():void {
        this.hcuSharedService.getPortRefreshListSubject().subscribe((res)=>{
            this.getPORTTabListData();
        })
    }

    //method :: opens slider on click on view icon.
    private portViewSUbjectListener():void {
        this.hcuSharedService.getPortViewSubject().subscribe((res)=>{
            this.loadSlider('PORT_VIEW');
        })
    }

    //method showall ports
    private notifyShowAll():void {
        this.action(true);
        this.setShowLessBtn();
    }

    //methods notifies show less
    private notifyShowLess():void {
        this.action(false);
        this.setShowAllBtn();
    }

    //method gets porttab list
    private action(showall:boolean):void {
        this.showLoadingOverlay();
        this.showAll = showall;
        this.getPORTTabListData();
    }

    //method :: sets row data on get port list success.
    private onPORTTabListData(data:any):void {
        this.dataApi=data;        
        this.rowdata = data;
        this.rowCount = data.length;
        this.totalCount = data.totalCount;
        this.setShowAllLabel(this.rowCount, this.totalCount);
        if(data.isShowAll) {
            this.setShowAllBtn();
        }

        if(this.rowCount > PAGE_LIMIT){
            this.setShowLessBtn();
        }

    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //method set showAll btn
    private setShowAllBtn():void {
        this.showAllBtn = [{name: this.SHOW_ALL, tabType:'PORT_TAB'}];
    }

    //method set showless btn
    private setShowLessBtn():void {
        this.showAllBtn = [{name: this.TABLE_LIST_SHOW_LESS, tabType:'PORT_TAB'}];
    }

    /*
     *@name groupTabEvent
     *@desc Events related to group tab (USER).
     *@return void
     */
    public notifyActionEmitter($event) {
        switch($event.event.name) {
            case this.ADD_TO_BROADCAST:
                this.notifyAddNodetoBC($event.selectedData[0]);
                break;
            case this.REMOVE_FROM_BROADCAST:
                this.notifyRemoveNodeFormBC($event.selectedData[0]);
                break;
            case this.REPAIR:
                this.notifyRepair($event.selectedData[0]);
                break;
            case this.COPY_MONITORING:
                this.notifyCopyMonitoringPlan($event.selectedData[0]);
                break;
            case this.PASTE_MONITORING:
                this.notifyPasteMonitoringPlan($event.selectedData);
                break;
            case this.IMPORT_LABELS:
                this.notifyImportLabels();
                break;
            case this.TREE_TABLE_VIEW:
                this.notifyToggleTableView(false);
                break;
            case this.NORMAL_TABLE_VIEW:
                this.notifyToggleTableView(true);
                break;
            case this.VIEW_IN_BROADCAST:
                this.notifyEditNodeInBroadcast($event.selectedData[0]);
                break;
            case this.VIEW_MACTRAK_CHANNELS:
                this.notifyShowListMACTrakChannels($event.selectedData[0]);
                break;
            case this.VIEW_MONITORING:
                this.notifyEditMonitoringPlan($event.selectedData[0]);
                break;
            case this.VIEW_EVENTS:
                this.notifyViewEvent($event.selectedData[0]);
                break;
            case this.SHOW_ALL:
                this.notifyShowAll();
                break;
            case this.TABLE_LIST_SHOW_LESS:
                this.notifyShowLess();
                break;
            default:
        }
    }

    //method :: notifies filter changes event.
    public notifyFilterChangePORT(e: any): void{
        this.hcuSharedService.getNameFilterText(this.hcuFilterInstance, "hcu");
        this.hcuSharedService.getNameFilterText(this.rpmFilterInstance, "rpm");
        this.changeSelection();
        const countryFilterComponent = this.portTabGridOptions.api.getFilterInstance('hcu_label');
        const model = countryFilterComponent.getModel();
        this.hcuSharedService.modeldata = model;
        const countryFilterComponent1 = this.portTabGridOptions.api.getFilterInstance('rpm_label');
        const model1 = countryFilterComponent1.getModel();
        this.hcuSharedService.modeldata1 = model1;
        this.portTabDataService.porttabfilterchangedata = this.portTabGridOptions.api.getFilterModel();
    }

    private changeSelection(): any{
        let filteredSelected: any[] = [];
        let isDirty: boolean = false;
        this.portTabGridOptions.api.forEachNodeAfterFilter((node) => {
            if(node.selected){
                filteredSelected.push(node.data.elementId);
            }
        });

        this.portTabGridOptions.api.getSelectedNodes().forEach((node) => {
            isDirty = false;
            if(filteredSelected.length > 0){
                for(let i = 0; i < filteredSelected.length; i ++){
                    if(filteredSelected[i] === node.data.elementId){
                        isDirty = true;
                        break;
                    }
                }
            }
            if(!isDirty){
                node.setSelected(false);
            }
        });
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.portTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.eventKeys = [
            {name:this.ADD_TO_BROADCAST ,status:'only-single', tabType:'PORT_TAB', disable:false, KEY : PERM_ADMINISTER_FIELD_VIEW_BROADCAST},
            {name:this.REMOVE_FROM_BROADCAST,status:'only-single', tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_FIELD_VIEW_BROADCAST},
            {name:this.VIEW_IN_BROADCAST ,status:'only-single', tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_FIELD_VIEW_BROADCAST},
            {name:this.VIEW_MACTRAK_CHANNELS ,status:'only-single', tabType:'PORT_TAB',disable:false, KEY : NAV_LINK_HCU},
            {name:this.REPAIR,status:'only-single', tabType:'PORT_TAB',disable:false, KEY : NAV_LINK_HCU},
            {name:this.COPY_MONITORING ,status:'single', tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_PATHTRAK_PORTS},
            {name:this.VIEW_MONITORING ,status:'only-single', tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_PATHTRAK_PORTS},
            {name:this.SELECT_ALL ,status:'all', tabType:'PORT_TAB'},
            {name:this.PASTE_MONITORING,status:'single', tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_PATHTRAK_PORTS},
            {name:this.VIEW_EVENTS ,status:'only-single', tabType:'PORT_TAB',disable:false},
            {name: this.GRID_EXPORT_SELECTED, status: 'single', tabType: 'PORT_TAB',disable:false},
            {name:this.GRID_EXPORT_ALL,status:'all', tabType:'PORT_TAB'},
        ];
        this.toggleButtons(this.TREE_TABLE_VIEW);
        this.refreshBtnFlag = true;
    }

    //method :: notify that grid is ready.
    public notifyGridReadyPORT(params:any){
        this.setGridColDefinition();
    }

    //method :: repairs port
    private notifyRepair(selectedData){
        this.portTabDataService.portRepair(selectedData.elementId).subscribe(this.onPortRepairSucces.bind(this), this.onError.bind(this));
    }

    //method :: on reapir success.
    private onPortRepairSucces(data:any):void {
        this.showAlert.showSuccessAlert("HCU_REPAIR_SUCCESS");
        this.getPORTTabListData();
    }

    //method :: notify that grid is ready.
    private notifyAddNodetoBC(selectedData){
        if(selectedData.broadcast == this.NO) {
            this.currentValue = selectedData.elementId;
            this.portTabDataService.enableBroadcastOnPort(selectedData.elementId, {}).subscribe(this.onAddNodetoBC.bind(this) ,this.onError.bind(this));
        }else {
            this.showAlert.showInfoAlert(this.PORT_IN_BROADCAST_MSG);
        }

    }

    //method :: shows alert on add node to broadcast success.
    private onAddNodetoBC(data:any):void {
        this.oldPortId = this.currentValue;
        this.showAlert.showSuccessAlert(this.PORT_ADD_NODE_BC_SUCCESS);
        this.getPORTTabListData();
    }

    //method :: notify that grid is ready.
    private notifyRemoveNodeFormBC(selectedData){
        if(selectedData.broadcast == this.YES) {
            this.portTabDataService.removeBroadcastOnPort(selectedData.elementId).subscribe((response)=>{
                this.showAlert.showSuccessAlert(this.PORT_REMOVED_FROM_BROADCAST_SUCCESS);
                this.getPORTTabListData();
            },this.onError.bind(this))
        }else {
            this.showAlert.showInfoAlert(this.PORT_NOT_IN_BROADCAST_MSG);
        }
    }

    //method :: notify that grid is ready.
    private notifyEditNodeInBroadcast(selectedData){
        this.portTabDataService.getBroadcastStatusForPort(selectedData.elementId).subscribe(this.onEditNodeInBroadcastSuccess.bind(this) ,this.onError.bind(this));

    }

    //method :: sets broadcast data in shared service.
    private onEditNodeInBroadcastSuccess(data:any):void {
        if(data.broadcastEnabled) {
            let modelObj:BroadcastModel = new BroadcastModel(data);
            this.hcuSharedService.setBroadcastModel(modelObj);
            this.loadSlider('VIEW_PORT_IN_BROADCAST');
        }else {
            this.showAlert.showInfoAlert(this.PORT_NOT_IN_BROADCAST_MSG);
        }
    }


    //method :: notify that grid is ready.
    private notifyCopyMonitoringPlan(selectedData){
        this.copyPortId = selectedData.elementId;
        this.showAlert.showSuccessAlert(this.PORT_MONITORING_COPY_SUCCESS_MSG);
    }

    //method:: notifies view event.
    private notifyViewEvent(selectedData){
        this.loadSlider('PORT_VIEW_EVENTS', selectedData);
    }

    //method :: notify that grid is ready.
    private notifyPasteMonitoringPlan(selectedData){
        let rowData = [];
        this.portTabGridOptions.api.forEachNodeAfterFilter(node => {
      rowData.push(node.data);
    });
    selectedData = rowData;
        let dataSelected : any[] = [];
        for(let i= 0; i < selectedData.length ; i++) {
            if(selectedData[i] && selectedData[i].elementId) dataSelected.push(selectedData[i]);
        }
        if(this.copyPortId != null) {
            this.portIdsArray(dataSelected);
            let obj:any = {
                "copyPortId":this.copyPortId,
                "pastePortIds":this.pastePortIds
            }
            if(this.pastePortIds.length) {
                this.portTabDataService.pasteMonitoringPlan(obj).subscribe(this.onPasteMonitoringSuccess.bind(this), this.onError.bind(this));
            }else {
                this.showAlert.showInfoAlert(this.MONITORING_PASTE_ON_SAME_MSG);
            }
        }else {
            this.showAlert.showInfoAlert(this.PORT_COPY_MONITORIN_INFO_MSG);
        }

    }

    //method :: on paste monitoring success.
    private onPasteMonitoringSuccess(data:any[]):void {
        this.pastePortIds = [];
        let msg = this.monitoringPlanModel.getPasteMonitoringErrorCount(data, this.localeDataService.getLocalizationService());
        let type: string = ALERT_SUCCESS;
        data.forEach((item: any) => {
            if (item.status.includes("ERROR")) {
                type = ALERT_ERROR;
            }
        });
        this.showAlert.showSuccessAlert(msg, false, type);
    }

    //method :: creates porIds list for paste monitoring.
    private portIdsArray(data:any):void {
        for(var i=0; i<data.length; i++) {
             //if(this.copyPortId != data[i].elementId) {
                this.pastePortIds.push(data[i].elementId)
            }
        //}
    }

    //method :: notify that grid is ready.
    private notifyShowListMACTrakChannels(selectedData){
        this.loadSlider('PORT_MACTRACK_CHANNELS',selectedData);
    }

    //method get callled when input type file selects different file.
    public fileChange(event: any): void {
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let files: any = event.target.files;
        if (files.length) {
            let file;
            file = files[0];
            this.formData.append('file', file, file.name);
            this.hcuTabDataService
                .importLabels(this.formData, "rpmport")
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.handleImportLabelResponse.bind(this)
                    ,this.onError.bind(this));
        }
    }

    public clearFile(): void{
        let fileInput:any = document.getElementById("fileInput")
        fileInput.value = null;
    }

    //method :: onsuccess of import labels.
    private handleImportLabelResponse(response: ImportLabelModel): void{
        this.fileInput.nativeElement.value = "";
        this.showAlert.showSuccessAlert(response.getMessage(this.localeDataService.getLocalizationService()));
        this.getPORTTabListData();
    }

    //method :: notify that grid is ready.
    private notifyEditMonitoringPlan(selectedData){
        this.portTabDataService.getMonitoringPlanSettings(selectedData.elementId).subscribe(this.onEditMonitoringPlanSuccess.bind(this) ,this.onError.bind(this))
    }

    //method :: sets data in shared service on edit monitoring success.
    private onEditMonitoringPlanSuccess(data:any):void {
      if(data && this.dataApi){
           let selectedElement= this.dataApi.filter((ele)=>data.elementId==ele.elementId);
            if(selectedElement){
                data.monitoringPlanName=selectedElement[0].monitoringPlanName;  
            } 
        }
        this.hcuSharedService.setPortMonitoringModel(data);
        this.loadSlider('VIEW_MONITORING_PLAN');
    }

    //method :: notifies click of import label button.
    private notifyImportLabels(){
        this.fileInput.nativeElement.click();
    }

    private notifyToggleTableView(isNormalView: boolean): void{
        this.portTabGridOptions.api.deselectAll();
        this.portTabGridOptions.api.setColumnDefs(null);
        this.portTabGridOptions.api.setColumnDefs(isNormalView ? this.portTabColumnDefinationService.getTableColumnDef() : this.portTabColumnDefinationService.getTreeColumnDef());
        this.getFilterInstances();
        this.toggleButtons(isNormalView ? this.TREE_TABLE_VIEW : this.NORMAL_TABLE_VIEW);
        this.sharedService.checkWhichView = isNormalView;
        this.changeSortOrder(isNormalView);
        if(this.portTabGridOptions.api){
            this.setFilter();
        }
    }

    //method :: makes api to get port data.
    public getPORTTabListData(): void {
        if(this.portTabGridOptions.api){
            this.setFilter();
            this.portTabDataService.getAllPORTTabList(this.showAll).subscribe(this.onPORTTabListData.bind(this), this.onError.bind(this));
        }
        // if( this.portTabDataService.porttabfilterchangedata.length == 0 && this.hcuSharedService.modeldata == null && this.hcuSharedService.modeldata1 == null)
        // {
        //     this.notifyToggleTableView(false);
        // }
        if(this.portTabGridOptions.api &&(Object.keys(this.portTabDataService.porttabfilterchangedata).length!=0|| this.hcuSharedService.modeldata || this.hcuSharedService.modeldata1|| this.sharedService.checkWhichView)){
            if(Object.keys(this.portTabDataService.porttabfilterchangedata).length!=0){
            this.notifyToggleTableView(true);
                this.portTabGridOptions.api.setFilterModel(this.portTabDataService.porttabfilterchangedata);
            }
            if(Object.keys(this.portTabDataService.porttabfilterchangedata).length!=0||this.hcuSharedService.modeldata ||this.hcuSharedService.modeldata1) 
                {
                    //this.portTabGridOptions.api.setColumnDefs(this.portTabColumnDefinationService.getTableColumnDef());
                    this.notifyToggleTableView(true);
                    //this.portTabGridOptions.api.setFilterModel(this.portTabDataService.porttabfilterchangedata);
                    const countryFilterComponent3 = this.portTabGridOptions.api.getFilterInstance('hcu_label');
                countryFilterComponent3.setModel(this.hcuSharedService.modeldata);
                const countryFilterComponent2 = this.portTabGridOptions.api.getFilterInstance('rpm_label');
                countryFilterComponent2.setModel(this.hcuSharedService.modeldata1);
                }
               
            
        }
        else{
            this.notifyToggleTableView(false);
        }

    }

    private setFilter(): void{
        if(this.sharedService.getFilterForTAB().length > 0) {
            this.portTabGridOptions.api.getFilterInstance('rpm_label').setFilter(this.sharedService.getFilterForTAB());
            this.sharedService.setFilterForTAB("");
        }else if(this.sharedService.getFilterAlarmForTAB().length > 0){
            this.portTabGridOptions.api.getFilterInstance('portNumber').setFilter(this.sharedService.getFilterAlarmForTAB());
            this.sharedService.setFilterAlarmForTab("");
        } else {
            this.hcuSharedService.applyNameFilter(this.hcuFilterInstance, "hcu");
            this.hcuSharedService.applyNameFilter(this.rpmFilterInstance, "rpm");
        }
    }

    private changeSortOrder(isNormalView: boolean): void{
        const columns: any[] = [
            {colId: 'slotNumber', sort: 'asc'},
            {colId: 'portNumber', sort: 'asc'}
        ];
        if(isNormalView){
            columns.unshift({colId: 'hcu_label', sort: 'asc'});
            this.portTabGridOptions.api.setSortModel(columns);
        }else{
            columns.unshift({colId: 'ag-Grid-AutoColumn-hcu_label', sort: 'asc'});
            this.portTabGridOptions.api.setSortModel(columns);
        }
    }


    //need to call on grid expand.
    public notifyColumnGroupOpened(): void{
        this.gridResizeVal = Math.random();
    }

    private toggleButtons(buttonName: string): void{
        this.buttonKeys = [
            {name: buttonName ,tabType:'PORT_TAB'},
            {name:this.IMPORT_LABELS ,tabType:'PORT_TAB',disable:false, KEY : PERM_ADMINISTER_PATHTRAK_PORTS},
        ];
    }

    private resizeColumns(): void{
        let lang = this.languageService.getCurrentLanguage().toLowerCase();
        if(window.innerWidth >= 1362 && lang.startsWith('zh')){
            //Timeout is require to delay resizing of the grid.
            //Fix is for chines only
            setTimeout(() => {
                this.portTabGridOptions.api.sizeColumnsToFit();
            }, 1000);
        }
    }


    //method :: sets column definition to grid.
    private setGridColDefinition(){
        this.resizeColumns();
        window.onresize = () => {
            this.resizeColumns();
        };
        this.showLoadingOverlay();
        this.portTabColumnDefinationService.setData();
        this.notifyToggleTableView(this.sharedService.checkWhichView);
        this.portTabGridOptions["getRowHeight"] = (params) => {
            let level;
            let thresholdLength = 45;
            let rowHeight = 22;
            let hcuLength;
            if(params.node.key && params.node.key.length){
                hcuLength = params.node.key.length;
                level = Math.floor(hcuLength / thresholdLength);
                return ((window.innerWidth >= 750) ? (rowHeight/2) * (level + 2) : rowHeight * (level + 1));
            }
            else{
                return rowHeight;
            }
        }
        
        this.getFilterInstances();
        if(this.hcuSharedService.getHcmFilterText().length > 0){
            this.showAll = true;
        }
        this.getPORTTabListData();
        this.agGridConfigurationService.afterSortChanged(this.portTabGridOptions);

    }
    

    private getFilterInstances(): void{
        this.hcuFilterInstance = this.portTabGridOptions.api.getFilterInstance('hcu_label');
        this.rpmFilterInstance = this.portTabGridOptions.api.getFilterInstance('rpm_label');
    }

    //method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.portTabGridOptions.api.showLoadingOverlay();
    }

    //refresh grid data
    public notifyRefreshGrid($event){
        this.getPORTTabListData();
    }

    //method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.translate;
        this.ADD_TO_BROADCAST = this.translate.instant('HCU_PORT_TAB_ADD_TO_BROADCAST');
        this.REMOVE_FROM_BROADCAST = localizationService.instant('HCU_PORT_TAB_REMOVE_FROM_BROADCAST');
        this.VIEW_IN_BROADCAST = localizationService.instant('HCU_PORT_TAB_VIEW_IN_BROADCAST');
        this.VIEW_MACTRAK_CHANNELS = localizationService.instant('HCU_PORT_TAB_VIEW_MACTRAK_CHANNELS');
        this.REPAIR = localizationService.instant('HCU_PORT_TAB_REPAIR');
        this.COPY_MONITORING = localizationService.instant('HCU_PORT_TAB_COPY_MONITORING');
        this.VIEW_MONITORING = localizationService.instant('HCU_PORT_TAB_VIEW_MONITORING');
        this.SELECT_ALL = localizationService.instant('GRID_SECTION.GRID_SELECT_ALL');
        this.VIEW_EVENTS = localizationService.instant('HCU_PORT_TAB_VIEW_EVENTS');
        this.PASTE_MONITORING = localizationService.instant('HCU_PORT_TAB_PASTE_MONITORING');
        this.IMPORT_LABELS = localizationService.instant('HCU_PORT_TAB_IMPORT_LABELS');
        this.TREE_TABLE_VIEW = localizationService.instant('HCU_PORT_TAB_TREE_TABLE_VIEW');
        this.NORMAL_TABLE_VIEW = localizationService.instant('HCU_PORT_TAB_NORMAL_TABLE_VIEW');
        this.GRID_EXPORT_ALL = localizationService.instant('GRID_SECTION.GRID_EXPORT_ALL');
        this.GRID_EXPORT_SELECTED = localizationService.instant('GRID_SECTION.GRID_EXPORT_SELECTED');
        this.PORT_MONITORING_PASTE_SUCCESS = localizationService.instant('PORT_MONITORING_PASTE_SUCCESS');
        this.PORT_COPY_MONITORIN_INFO_MSG = localizationService.instant('PORT_COPY_MONITORIN_INFO_MSG');
        this.HCU_REPAIR_SUCCESS = localizationService.instant("HCU_REPAIR_SUCCESS");
        this.PORT_ADD_NODE_BC_SUCCESS = localizationService.instant("PORT_ADD_NODE_BC_SUCCESS");
        this.PORT_REMOVED_FROM_BROADCAST_SUCCESS = localizationService.instant("PORT_REMOVED_FROM_BROADCAST_SUCCESS")
        this.MONITORING_PASTE_ON_SAME_MSG = localizationService.instant('MONITORING_PASTE_ON_SAME_MSG');
        this.PORT_203_BROADCAST_CONFORMATION_MSG = localizationService.instant('PORT_203_BROADCAST_CONFORMATION_MSG');
        this.PORT_BROADCAST_CONFORMATION_TITLE = localizationService.instant('PORT_BROADCAST_CONFORMATION_TITLE');
        this.YES = localizationService.instant('YES');
        this.NO = localizationService.instant('NO');
        this.PORT_IN_BROADCAST_MSG = localizationService.instant('PORT_IN_BROADCAST_MSG');
        this.PORT_NOT_IN_BROADCAST_MSG = localizationService.instant('PORT_NOT_IN_BROADCAST_MSG');
        this.PORT_MONITORING_COPY_SUCCESS_MSG = localizationService.instant('PORT_MONITORING_COPY_SUCCESS_MSG');
        this.SHOW_ALL =  localizationService.instant('SHOW_ALL');
        this.TABLE_LIST_SHOW_LESS = localizationService.instant('TABLE_LIST_SHOW_LESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');

        this.SPECTRUM = localizationService.instant('SPECTRUM');
        this.QAMTRAK = localizationService.instant('QAMTRAK');
        this.HEATMAP = localizationService.instant('HEATMAP');
        this.Ok = localizationService.instant('Ok');
        this.Error = localizationService.instant('Error');
        
        SeverityFilter.severity.alarmDefault = CommonStrings.ALARM_LIST_SEVERITY_DEFAULT;
        SeverityFilter.severity.critical = CommonStrings.ALARM_LIST_SEVERITY_CRITICAL;
        SeverityFilter.severity.minor = CommonStrings.ALARM_LIST_SEVERITY_MINOR;
        SeverityFilter.severity.major = CommonStrings.ALARM_LIST_SEVERITY_MAJOR;
        SeverityFilter.severity.warning = CommonStrings.ALARM_LIST_SEVERITY_WARNING;
        SeverityFilter.severity.good = CommonStrings.ALARM_LIST_SEVERITY_GOOD;

    }

    //Method to clear other components
    private loadSlider(HCUSlider: string , data?:any ): void {
        switch (HCUSlider) {
            case 'PORT_VIEW':
                this.createComponentOnClick(PortViewComponent);
                break;
            case 'PORT_MACTRACK_CHANNELS':
                this.createComponentOnClick(PORTMactrakChannel, data);
                break;
            case 'VIEW_PORT_IN_BROADCAST':
                this.createComponentOnClick(PortBroadcastComponent);
                break;
            case 'PORT_VIEW_EVENTS':
                this.createComponentOnClick(PORTViewEvent, data);
                break;
            case 'VIEW_MONITORING_PLAN':
                this.createComponentOnClick(MonitoringPlanComponent, data);
                break;
            case 'View_HSM_LIST':
                this.createComponentOnClick(ViewPortHSM, data);
            default:
                break;
        }
    }

    //method :: creates component on click.
    private createComponentOnClick(targetComponent: any, data?:any): void {
        this.clearSlider();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        let cmpRef =  this._targetSliderView.createComponent(factory);
        cmpRef.instance.childData = data;
    }

    //method :: clear slider target.
    private clearSlider():void {
        this._targetSliderView.clear();
    }

    //method :: on error shows alert.
    private onError(error:any):void {
        //showing hsm list on 203 error code.
        if(error.errorCode == 203) {
            this.sweetAlert.showAlert(ALERT_ERROR,this.PORT_203_BROADCAST_CONFORMATION_MSG,this.Error,this.Ok,null, this.callbackFunction);

        }else {
            this.logger.debug(this.tag, "onError(): error data=", error);
            this.showAlert.showErrorAlert(error);
        }
    }

    private callbackFunction(resultval){
        
    }

    //method :: shows list of ports which are in broadcast.
    private showHSMList():void {
        if(this.oldPortId) {
            this.portTabDataService.getBroadcastStatusForPort(this.oldPortId).subscribe((res)=>{
                let data:any = [{
                    elementId:res.hsmId
                }];
            this.loadSlider('View_HSM_LIST', data);
            },this.onError.bind(this));
        }else {
            this.portTabDataService.getBroadcastStatusForPort(this.currentValue).subscribe((res)=>{
                let arr:any = res.links[1].url.split('/');
                let hsmId = parseInt(arr[arr.length - 1]);
                let data:any = [{
                    elementId:hsmId
                }]
                this.loadSlider('View_HSM_LIST', data);
            },this.onError.bind(this));
        }
    }

    /* Method get called when we come in PORT tab after switch the tab */
    public onTabSwitch(): void{
        this.getPORTTabListData();
        this.resizeColumns();
    }


}
