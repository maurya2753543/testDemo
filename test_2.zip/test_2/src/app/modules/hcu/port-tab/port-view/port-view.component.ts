import {Component} from '@angular/core';
import {HCUSharedService} from '../../hcu.shared.service';
import {PORTDetailsModel, UserDefinedModel} from '../model/portDetails.model';
import {PORTTabDataService} from '../porttab.data.service';
import {ShowAlert} from "./../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import { LocaleDataService } from "./../../../../shared/locale.data.service";
import { Logger } from "../../../../utilities/logger";
import {
    ALERT_SUCCESS,ALERT_INFO
} from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'port-view',
    templateUrl:'port-view.component.html'
})

export class PortViewComponent {

    public portDetailsModel:PORTDetailsModel;
    public isCloseRightSlider:boolean = false;
    public isReadonly:boolean = true;
    private tag:string = "PortViewComponent";
    private PORT_EDIT_SUCCESS:string = "";
    public inFieldViewBroadcastDisplay:any = "";
    private YES:String = "";
    private NO:string = "";
    public parentAlarmsEnabled:boolean = true;
    public parentThresholdsEnabled:boolean = true;
    public userDefinedModel:UserDefinedModel = new UserDefinedModel({});
    private DOT: string = "";
    private statusData:string;

    constructor(private hcuSharedService:HCUSharedService,
                private portTabDataService:PORTTabDataService,
                private showAlert:ShowAlert,private sweetAlert:SweetAlert,
                private localeDataService:LocaleDataService,
                private logger:Logger, private sharedService:SharedService){
                    this.translateLocaleString();
    }

    ngOnInit(){
        this.portDetailsModel= new PORTDetailsModel({},this.localeDataService.getLocalizationService());
        this.getLocalizeDOT();
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.PortViewSubjectListener();
        this.getUserDefined();
        this.setFormData(this.hcuSharedService.getPortTabModel());
    }

    private getLocalizeDOT() : void {
        this.DOT = this.sharedService.getLocalizeDot();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //method gets userdefined values.
    private getUserDefined():void {
        this.portTabDataService.userDefined().subscribe((res)=>{
            this.userDefinedModel = res;
        },this.onError.bind(this));
    }

    //function:: subscribes portviewsubject
    private PortViewSubjectListener():void{
        this.hcuSharedService.getPortViewSubject().subscribe((res)=>{
            this.setFormData(res);
        })
    }

    //function:: sets response to form.
    private setFormData(formData):void {
        this.setPortModelData(formData.portTabModel);
    }

    //function :: sets data to portmodel
    private setPortModelData(portModelObj):void {
        if(portModelObj) {
            this.portDetailsModel = new PORTDetailsModel(portModelObj,this.localeDataService.getLocalizationService());
            this.portDetailsModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(this.portDetailsModel.attenuation, this.DOT);
            this.portDetailsModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(this.portDetailsModel.testPointComp, this.DOT);

            this.parentAlarmsEnabled = portModelObj.parentAlarmsEnabled;
            this.parentThresholdsEnabled = portModelObj.parentThresholdsEnabled;
            this.inFieldViewBroadcastDisplay = (portModelObj.inFieldViewBroadcast == true) ? this.YES : this.NO ;
        }
    }

    //function :: changes read only to edit mode.
    private toggleEdit():void {
        this.isReadonly = false;
    }

    // function:: closes slider.
    public btnClose_click():void {
        this.isCloseRightSlider = true;
        this.hcuSharedService.getPortClearSliderSub().next(true);
    }


    //function :: saves/put port details.
    private savePort():void {
        this.parseValues();
        this.portTabDataService.editPort(this.portDetailsModel).subscribe(this.onEditPortSuccess.bind(this) ,this.onError.bind(this))
    }

    private parseValues(): void{
        this.statusData = this.portDetailsModel.status;
        delete this.portDetailsModel.status;

        let tpc: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.portDetailsModel.testPointComp, this.DOT);
        this.portDetailsModel.testPointComp = parseFloat(tpc);

        let attenuation: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.portDetailsModel.attenuation, this.DOT);
        this.portDetailsModel.attenuation = parseFloat(attenuation);
    }

    //on edit port success.
    private onEditPortSuccess(data:any):void {
        this.sweetAlert.showAlert(ALERT_SUCCESS, this.PORT_EDIT_SUCCESS ,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
        (isConfirm)=>{
            this.btnClose_click();
            this.hcuSharedService.getPortRefreshListSubject().next(true);
        })
        this.logger.debug(this.tag, "onEditPortSuccess: success data=", data);
    }

    //function :: on error
    private onError(error):void {
        this.portDetailsModel ? this.portDetailsModel.status = this.statusData :'';
        this.showAlert.showErrorAlert(error);
        this.logger.debug(this.tag, "onError(): error data=", error);
    }

    //@method :: Restrict TPC in range
    public processTPC(): void{
        this.processTpcValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.portDetailsModel.testPointComp, this.DOT);
        //Process value for MIN MAX
        let tpc: string = this.sharedService.processTpcMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.portDetailsModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(tpc, this.DOT);
    }

    public processTpcValue(): void{
        this.portDetailsModel.testPointComp = this.sharedService.processNumber(this.portDetailsModel.testPointComp, this.DOT);
    }

    //@method :: Restrict Attenuation in range
    public processAttenuation(): void{
        this.processAttenuationValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.portDetailsModel.attenuation, this.DOT);
        //Process value for MIN MAX
        let attenuation: string = this.sharedService.processAttenuationMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.portDetailsModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(attenuation, this.DOT);
    }

    public processAttenuationValue(): void{
        this.portDetailsModel.attenuation = this.sharedService.processNumber(this.portDetailsModel.attenuation, this.DOT);
    }

    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.PORT_EDIT_SUCCESS = localizationService.instant('PORT_EDIT_SUCCESS');
        this.YES = localizationService.instant('YES');
        this.NO = localizationService.instant('NO');
    }
}
