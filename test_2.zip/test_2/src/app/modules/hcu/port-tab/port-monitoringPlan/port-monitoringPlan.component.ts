import {Component, ViewChild ,Input, ElementRef} from '@angular/core';
import {PORTTabDataService} from '../porttab.data.service';
import {HCUSharedService} from '../../hcu.shared.service';
import {MonitoringPlanModel, ThresholdLabels} from '../model/port-monitoringPlan.model';
import {saveAs as importedSaveAs} from "file-saver";
import {ShowAlert} from "./../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import { LocaleDataService } from "./../../../../shared/locale.data.service";
import { Logger } from "../../../../utilities/logger";
import {
    ALERT_SUCCESS,ALERT_INFO
} from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {SharedService} from "../../../../shared/shared.service";
import {MonitoringTabPlanModel} from "../../monitoring-tab/model/monitoringplan.model";


@Component({
    selector:'port-monitoringplan',
    templateUrl:'port-monitoringPlan.component.html'
})

export class MonitoringPlanComponent {
    @ViewChild('fileInput') fileInput: ElementRef;
    public isCloseRightSlider:boolean = false;
    public isImportDisabled:boolean = true;
    public isReadOnly:boolean = true;
    public monitoringPlanModel:MonitoringPlanModel;
    public thresholdLabelsModel:ThresholdLabels;
    private formData = new FormData();
    public passEvent: any;

    private tag:string = "MonitoringPlanComponent";
    private MONITORING_PLAN_SAVE_SUCCESS_MSG:string = "";
    private MONITORING_PLAN_IMPORT_SUCCESS_MSG:string = "";
    private MONITORING_PLAN_IMPORT_USED_EXISTING_MSG:string = "";
    customMonitoringPlanName:string = "";
    constructor(private portTabDataService:PORTTabDataService,
                private hcuSharedService:HCUSharedService,
                private showAlert:ShowAlert,private sweetAlert:SweetAlert,
                private localeDataService:LocaleDataService,
                private logger:Logger, private sharedService:SharedService){
                
        this.translateLocalString();     
        this.isCloseRightSlider = false;
        this.getMonitoringPlanSettings();
        this.thresholdLabelsModel = new ThresholdLabels({});
    }

    ngOnInit() {
        this.closeSlidersSubjectListener();
        this.portTabDataService.getThresholdLabels().subscribe(this.thresholdLabelsSuccess.bind(this), this.onError.bind(this))
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //function :: assigns data to threshold model on threshold api success.
    private thresholdLabelsSuccess(data:any):void {
        this.thresholdLabelsModel = data;
    }

    //function :: gets monitoring plan setting from shared service.
    private getMonitoringPlanSettings():void {
        this.monitoringPlanModel = this.hcuSharedService.getPortMonitoringModel();
     }
    public btnClose_click(){
        this.isCloseRightSlider = true;
        this.hcuSharedService.getPortClearSliderSub().next(true);
    }

    //toggles to edit mode.
    private toggleEdit():void {
        this.isReadOnly = false;
    }

    //function :: put/edit call to save monitorings changes.
    private saveMonitoringPlan():void {
      //  this.hcuSharedService.setPortNameMonitoringModel(this.monitoringPlanModel);
        this.portTabDataService.putMonitoringPlanSettings(this.monitoringPlanModel).subscribe(this.onSaveMonitoringPlanSuccess.bind(this) ,this.onError.bind(this));
    }

    //function :: on save monitoring success.
    private onSaveMonitoringPlanSuccess():void {
        this.showMonitoringPopUp(this.MONITORING_PLAN_SAVE_SUCCESS_MSG)
    }

    //function :: api call to get monitoring plan csv.
    public exportMonitoringPlan():void {
        console.log("export ",this.monitoringPlanModel.elementId )
        this.portTabDataService.exportMonitoringPlan(this.monitoringPlanModel.elementId).subscribe(this.onExportMonitoringPlan.bind(this),this.onError.bind(this));
    }

    //function :: on success of export monitoring and downoads csv.
    private onExportMonitoringPlan(blob):void {
        importedSaveAs(blob, this.monitoringPlanModel.monitoringPlanName);
    }

    public selectMonitoringPlan():void {
        this.fileInput.nativeElement.click();
    }

    public fileChange(event):void {
        this.passEvent = event;
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let files: any = event.target.files;
        this.isImportDisabled= false;
        this.customMonitoringPlanName = files[0].name.split('?')[0].split('.')[0];
    }

    public importMonitoringPlan():void{
        let files: any = this.passEvent.target.files;
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let filetoupload= <File>files[0];
        let filename: string = this.customMonitoringPlanName;
        let fileExtension: string = filetoupload.name.split('?')[0].split('.').pop();
        if (files.length) {
            let file;
            file = files[0];
            this.formData.append('file', filetoupload,filename+'.'+fileExtension);
            let monPlanSettings = '{ "elementId": "' + this.monitoringPlanModel.elementId.toString() + '", "monitoringPlanName": "'+ filename +'" }';
            this.formData.append('monPlanSettings', monPlanSettings);
          this.portTabDataService.importMonitoringPlan(this.formData).subscribe(this.onImportSuccess.bind(this),this.onError.bind(this));
        }
      }

    public clearFile(): void{
        let fileInput:any = document.getElementById("portMonitoringPlanFileInput");
        fileInput.value = null;
    }

    private onImportSuccess(data):void {
        var monitoringTabPlanModel = new MonitoringTabPlanModel();
        monitoringTabPlanModel.setData(data,this.localeDataService.getLocalizationService())
        if(monitoringTabPlanModel.name)
            this.showMonitoringPopUp(this.MONITORING_PLAN_IMPORT_USED_EXISTING_MSG + monitoringTabPlanModel.name);
        else
            this.showMonitoringPopUp(this.MONITORING_PLAN_IMPORT_SUCCESS_MSG);
        this.isImportDisabled=true;
    }

    //function :: shows monitoring popup and refreshes porttab list.
    private showMonitoringPopUp(message):void {
        this.sweetAlert.showAlert(ALERT_SUCCESS, message ,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
        (isConfirm)=>{
            this.btnClose_click();
            this.hcuSharedService.getPortRefreshListSubject().next(true);
        })
    }

    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
        this.logger.debug(this.tag, "onError(): error data=", error);
    }

    private translateLocalString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.MONITORING_PLAN_IMPORT_SUCCESS_MSG = localizationService.instant('MONITORING_PLAN_IMPORT_SUCCESS_MSG');
        this.MONITORING_PLAN_SAVE_SUCCESS_MSG = localizationService.instant('MONITORING_PLAN_SAVE_SUCCESS_MSG');
        this.MONITORING_PLAN_IMPORT_USED_EXISTING_MSG = localizationService.instant('MONITORING_PLAN_IMPORT_USED_EXISTING_MSG');

    }
}