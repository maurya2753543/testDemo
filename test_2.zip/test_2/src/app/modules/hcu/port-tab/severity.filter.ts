/**
 * Created by yogesh.paisode on 4/6/2017.
 */

/*ag-Grid custom filter for severity column*/

import {CommonStrings} from "../../../constant/common.strings";

let isCreated : boolean = false;
function isNumeric(n) {
    return true;
}

let parentFilter : any = function NumberFilter() {};
let severity: any = {
    minor: CommonStrings.ALARM_LIST_SEVERITY_MINOR,
    major: CommonStrings.ALARM_LIST_SEVERITY_MAJOR,
    critical: CommonStrings.ALARM_LIST_SEVERITY_CRITICAL,
    warning: CommonStrings.ALARM_LIST_SEVERITY_WARNING,
    good: CommonStrings.ALARM_LIST_SEVERITY_GOOD,
    alarmDefault: CommonStrings.ALARM_LIST_SEVERITY_DEFAULT
};



var CRITICAL = "critical";
var MAJOR = "major";
var MINOR = "minor";
var WARNING = "warning";
var GOOD = "good";

var keyLog;



let severityFilter: any;

function getUI(){
    return ` <div class="dropdown severity_drop" >
            <button class="btn btn-secondary dropdown-toggle form-control filter-drop-down" 
                    type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    id="dropdownCustom"
                    style="width: 135px;height: 50%;text-align-last:center;"
                    aria-haspopup="true" aria-expanded="false">
                `+severity.alarmDefault+`
            </button>
            <div class="dropdown-menu severity" id="dropList" aria-labelledby="dropdownMenuButton" style="min-width: 0px;width: 135px;color: white;">
                <input type="checkbox" name="critical" id="criticalVal" style="width: auto; height: auto;margin-left: 3px;"/> `+severity.critical+` <br>
                <input type="checkbox" name="major" id="majorVal" style="width: auto; height: auto;margin-left: 3px;"/> `+severity.major+` <br>
                <input type="checkbox" name="minor" id="minorVal" style="width: auto; height: auto;margin-left: 3px;"/> `+severity.minor+` <br>
                <input type="checkbox" name="warning"  id="warningVal" style="width: auto; height: auto;margin-left: 3px;"/> `+severity.warning+` <br>
                <input type="checkbox" name="good"  id="goodVal" style="width: auto; height: auto;margin-left: 3px;"/> `+severity.good+` <br>
            </div>
        </div>`;
}

parentFilter.prototype.init = function (params) {
    this.valueGetter = params.valueGetter;
    this.filterText = null;
    this.params = params;
    this.setupGui();
};
parentFilter.prototype.setupGui = function () {
    this.gui = document.createElement('div');
    this.gui.innerHTML = getUI();
    var that = this;
    this.onFilterChanged = function() {
        that.extractFilterText();
        that.params.filterChangedCallback();
    };
    
    that.eFilterText = "";

    this.gui.querySelector('div > div > div > input[name="critical"]').addEventListener('change',  (e) => {
        notifyChangeSetGui(that, e.target.checked, CRITICAL)
    });

    this.gui.querySelector('div > div > div > input[name="major"]').addEventListener('change',  (e) => {
        notifyChangeSetGui(that, e.target.checked, MAJOR)
    });

    this.gui.querySelector('div > div > div > input[name="minor"]').addEventListener('change',  (e) => {
        notifyChangeSetGui(that, e.target.checked, MINOR)
    });

    this.gui.querySelector('div > div > div > input[name="warning"]').addEventListener('change',  (e) => {
        notifyChangeSetGui(that, e.target.checked, WARNING)
    });
    this.gui.querySelector('div > div > div > input[name="good"]').addEventListener('change',  (e) => {
        notifyChangeSetGui(that, e.target.checked, GOOD)
    });
};

function notifyChangeSetGui(that, isChecked, key){
    that.eFilterText = "";
    for (let i = 0; i < keyLog.length; i ++){
        if(keyLog[i].key === key){
            keyLog[i].isSelected = isChecked;
        }
        if(keyLog[i].isSelected){
            that.eFilterText = that.eFilterText + keyLog[i].name;
        }
    }
    that.onFilterChanged();
}


parentFilter.prototype.extractFilterText = function () {
    this.filterText = this.eFilterText;
};

parentFilter.prototype.getGui = function () {
    return this.gui;
};

parentFilter.prototype.doesFilterPass = function (params) {
    var valueGetter = this.valueGetter;
    var value = valueGetter(params);
    var filterValue = this.filterText+"";
    switch(value){
        case 0:
            value = severity.good;
            break;
        case 2:
            value = severity.warning;
            break;
        case 3:
            value = severity.minor;
            break;
        case 4:
            value = severity.major;
            break;
        case 5:
            value = severity.critical;
            break;
    }
    if (this.isFilterActive()){
        return filterValue.includes(value);
    }
};

parentFilter.prototype.isFilterActive = function () {
    return  this.filterText !== null &&
        this.filterText !== undefined &&
        this.filterText !== ''
};

parentFilter.prototype.getModel = function () {
    return this.isFilterActive() ? 0 : null;
};

parentFilter.prototype.setModel = function (model) {
    this.eFilterText = model;
    this.extractFilterText();
};

parentFilter.prototype.customMethodForTakingValueFromFloatingFilter = function(value) {
    this.eFilterText = value;
    this.onFilterChanged();
};

parentFilter.prototype.destroy = function () {
    this.eFilterText && this.eFilterText.removeEventListener("input", this.onFilterChanged);
};

let filter : any = function NumberFloatingFilter() {}

filter.prototype.init = function (params) {
    keyLog = [
        {
            key: CRITICAL,
            isSelected: false,
            name: severity.critical
        },
        {
            key: MAJOR,
            isSelected: false,
            name: severity.major
        },
        {
            key: MINOR,
            isSelected: false,
            name: severity.minor
        },
        {
            key: WARNING,
            isSelected: false,
            name: severity.warning  
        },
        {
            key: GOOD,
            isSelected: false,
            name: severity.good
        }
    ];
   // this.onFloatingFilterChanged = params.onFloatingFilterChanged;
    this.eGui = document.createElement('div');
    this.eGui.innerHTML = getUI();
    this.currentValue = null;
    //this.eFilterInput = this.eGui.querySelector('select[name="filter"]');
    var that = this;
    function onInputBoxChanged(e, name){
        //that.currentValue = that.eFilterInput.value;
        that.customMethodForTakingValueFromFloatingFilter(that.currentValue);
    }
    //this.eFilterInput.addEventListener('change', onInputBoxChanged);

    this.eGui.querySelector('div > div > div > input[name="critical"]').addEventListener('change', (e) => {
        notifyChange(that, e.target.checked, CRITICAL)
    });

    this.eGui.querySelector('div > div > div > input[name="major"]').addEventListener('change', (e) => {
        notifyChange(that, e.target.checked, MAJOR)
    });

    this.eGui.querySelector('div > div > div > input[name="minor"]').addEventListener('change', (e) => {
        notifyChange(that, e.target.checked, MINOR)
    });

    this.eGui.querySelector('div > div > div > input[name="warning"]').addEventListener('change', (e) => {
        notifyChange(that, e.target.checked, WARNING)
    });

    this.eGui.querySelector('div > div > div > input[name="good"]').addEventListener('change', (e) => {
        notifyChange(that, e.target.checked, GOOD)
    });

    function notifyChange(that, isChecked, key){
        that.currentValue = "";
        for (let i = 0; i < keyLog.length; i ++){
            if(keyLog[i].key === key){
                keyLog[i].isSelected = isChecked;
            }
            if(keyLog[i].isSelected){
                that.currentValue = that.currentValue + keyLog[i].name;
            }
        }
    
        params.parentFilterInstance(function(instance) {
            // instance.onFloatingFilterChanged('contains',that.currentValue);
            instance.customMethodForTakingValueFromFloatingFilter(that.currentValue);
            
        });
       // that.onFloatingFilterChanged(that.currentValue);
    }
};

filter.prototype.onParentModelChanged = function (parentModel) {
    this.currentValue = parentModel;
};

filter.prototype.getGui = function () {
    return this.eGui;
};

export class SeverityFilter{
    public static ChildFloatingFilter = filter;
    public static ParentFilter = parentFilter;
    public static severity = severity;

    public static getSeverityFilter(): any{
        return severityFilter;
    }
}
