interface FrequencyRange {
    value: string;
    range: string;
}

export class BroadcastModel {
    public id: number;
    public type: string;
    public name: string;
    public broadcastEnabled: boolean
    public links: any;
    public hsmId: number;
    public hsmName: string;
    public rpmId: number;
    public rpmName: string;
    public hcuId: number;
    public hcuName: string;
    public startTime: string;
    public stopTime: string;
    public startFrequency: number;
    public stopFrequency: number;
    public dwellTime: number;
    public dwellTimeOptions: any;
    public frequencyRangeOptions: FrequencyRange[];

    private date = new Date();

    constructor(BroadcastModel) {
        if (BroadcastModel) {
            this.id = BroadcastModel.id;
            this.type = BroadcastModel.type;
            this.name = BroadcastModel.name;
            this.broadcastEnabled = BroadcastModel.broadcastEnabled;
            this.links = BroadcastModel.links;
            this.hsmId = BroadcastModel.hsmId;
            this.hsmName = BroadcastModel.hsmName
            this.rpmId = BroadcastModel.rpmId;
            this.rpmName = BroadcastModel.rpmName;
            this.hcuId = BroadcastModel.hcuId;
            this.hcuName = BroadcastModel.hcuName;
            this.startTime = BroadcastModel.startTime;
            this.stopTime = BroadcastModel.stopTime;
            this.startFrequency = BroadcastModel.startFrequency
            this.stopFrequency = BroadcastModel.stopFrequency
            this.dwellTime = BroadcastModel.dwellTime;
            this.dwellTimeOptions = BroadcastModel.dwellTimeOptions;
            this.frequencyRangeOptions = BroadcastModel.frequencyRangeOptions.map(range => <FrequencyRange> { value: range.split('-').pop(), range: range });
        }
    }

    public calculateRemainingHours(stopTime):number {
        let milliseconds = Date.parse(stopTime) - this.date.getTime();
        let timeRemaining:any = Math.floor(milliseconds / (1000*60*60));
        return timeRemaining;
    }
}