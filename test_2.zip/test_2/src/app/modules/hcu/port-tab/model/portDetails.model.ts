import {ONLINE} from "../../hcu.constants";
export class PORTDetailsModel {
    public elementId:number;
    public status:string;
    public created:string;
    public modified:string;
    public label:string;
    public location:string;
    public notes:string;
    public olVersion:number;
    public enabled: boolean;
    public alarmsEnabled: boolean;
    public parentAlarmsEnabled:boolean;
    public thresholdsEnabled:boolean;
    public parentThresholdsEnabled:boolean;
    public testPointComp:number|string;
    public attenuation:number|string;
    public upstreamNodeName:string;
    public fiberNodeName:string;
    public cmtsHostName:string;
    public portSearchMetaData_1:string;
    public portSearchMetaData_2:string;
    public portSearchMetaData_3:string;
    public portSearchMetaData_4:string;
    public portSearchMetaData_5:string;
    public portNumber:number;
    public inFieldViewBroadcast:boolean;
    public parentType:string;
    public alarmNetworkSeverity:number;

    constructor(portModelObj,localizationService){
        if(portModelObj) {
            this.elementId = portModelObj.elementId ? portModelObj.elementId : null;
            this.status = portModelObj.status ? (portModelObj.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()).toUpperCase() : localizationService.instant(portModelObj.status.toUpperCase()).toUpperCase():null;
            this.created = portModelObj.created ? portModelObj.created : null;
            this.modified = portModelObj.modified ? portModelObj.modified : null;
            this.label = portModelObj.label ? portModelObj.label : null;
            this.location = portModelObj.location ? portModelObj.location : null;
            this.notes = portModelObj.notes ? portModelObj.notes : null;
            this.olVersion = portModelObj.olVersion ? portModelObj.olVersion : null;
            this.enabled = portModelObj.enabled ? portModelObj.enabled : null;
            this.alarmsEnabled = portModelObj.alarmsEnabled ? portModelObj.alarmsEnabled : null;
            this.parentAlarmsEnabled = portModelObj.parentAlarmsEnabled ? portModelObj.parentAlarmsEnabled : null;
            this.thresholdsEnabled = portModelObj.thresholdsEnabled ? portModelObj.thresholdsEnabled : null;
            this.parentThresholdsEnabled = portModelObj.parentThresholdsEnabled ? portModelObj.parentThresholdsEnabled : null;
            this.testPointComp = typeof(portModelObj.testPointComp) !== 'undefined' ? portModelObj.testPointComp : null;
            this.attenuation = typeof(portModelObj.attenuation) !== 'undefined' ? portModelObj.attenuation : null;
            this.upstreamNodeName = portModelObj.upstreamNodeName ? portModelObj.upstreamNodeName : null;
            this.fiberNodeName = portModelObj.fiberNodeName ? portModelObj.fiberNodeName : null;
            this.cmtsHostName = portModelObj.cmtsHostName ? portModelObj.cmtsHostName : null;
            this.portSearchMetaData_1 = portModelObj.portSearchMetaData_1 ? portModelObj.portSearchMetaData_1 : null;
            this.portSearchMetaData_2 = portModelObj.portSearchMetaData_2 ? portModelObj.portSearchMetaData_2 : null;
            this.portSearchMetaData_3 = portModelObj.portSearchMetaData_3 ? portModelObj.portSearchMetaData_3 : null;
            this.portSearchMetaData_4 = portModelObj.portSearchMetaData_4 ? portModelObj.portSearchMetaData_4 : null;
            this.portSearchMetaData_5 = portModelObj.portSearchMetaData_5 ? portModelObj.portSearchMetaData_5 : null;
            this.portNumber = portModelObj.portNumber ? portModelObj.portNumber : null;
            this.inFieldViewBroadcast = portModelObj.inFieldViewBroadcast ? portModelObj.inFieldViewBroadcast : null;
            this.parentType = portModelObj.parentType ? portModelObj.parentType : null;
            this.alarmNetworkSeverity = portModelObj.alarmNetworkSeverity ? portModelObj.alarmNetworkSeverity : null;
        }
    }

    public changeStatusField(portModelObj):any {
        if(portModelObj){
            for(var i=0; i<portModelObj.length;i++) {
                portModelObj[i].status = (portModelObj[i].status == 'OK')? 'ONLINE': portModelObj[i].status;
            }
        }else {

        }
        return portModelObj;
    }

}

export class UserDefinedModel {
    public userDefined_1:string;
    public userDefined_2:string;
    public userDefined_3:string;
    public userDefined_4:string;
    public userDefined_5:string;

    constructor(userDefinedObj:any){
        if(userDefinedObj) {
            for(var i=0; i< userDefinedObj.length; i++) {
                switch (userDefinedObj[i].name) {
                    case "USER_DEFINED_1":
                        this.userDefined_1 = userDefinedObj[i].value;
                        break;
                    case "USER_DEFINED_2":
                        this.userDefined_2 = userDefinedObj[i].value;
                        break;
                    case "USER_DEFINED_3":
                        this.userDefined_3 = userDefinedObj[i].value;
                        break;
                    case "USER_DEFINED_4":
                        this.userDefined_4 = userDefinedObj[i].value;
                        break;
                    case "USER_DEFINED_5":
                        this.userDefined_5 = userDefinedObj[i].value;
                        break;
                }
            }
        }
    }
}


