export class MonitoringPlanModel {
    public elementId:number
    public monitoringEnabled: boolean;
    public thresold1Latched: boolean;
    public thresold2Latched: boolean;
    public thresold3Latched: boolean;
    public thresold4Latched: boolean;
    public thresold5Latched: boolean;
    public lastUpdateDate: string;
    public monitoringPlanName: string;

    private errorCount:number;
    private pasteMonitoringMsg:string = "";
    constructor(modelData){
        if(modelData) {
            this.elementId = modelData.elementId;
            this.monitoringPlanName = modelData.monitoringPlanName;
            this.monitoringEnabled = modelData.monitoringEnabled;
            this.thresold1Latched = modelData.thresold1Latched;
            this.thresold2Latched = modelData.thresold2Latched;
            this.thresold3Latched = modelData.thresold3Latched;
            this.thresold4Latched = modelData.thresold4Latched;
            this.thresold5Latched = modelData.thresold5Latched
            this.lastUpdateDate = modelData.lastUpdateDate;
        }
        
    }

    public getPasteMonitoringErrorCount(obj:any, localizationService):any {
        this.errorCount = 0;
        for(var i=0; i<obj.length; i++) {
            if( obj[i].status != "SUCCESSFUL") {
                this.errorCount++;
            }
        }

        if(this.errorCount) {
            this.pasteMonitoringMsg = localizationService.instant('MONITORING_PASTE_ROW_FAILED_MSG') + this.errorCount + ' '+ localizationService.instant('PORTS')
        }else {
            this.pasteMonitoringMsg = localizationService.instant('MONITORING_PASTE_SUCCESS_MSG');
        }
        return this.pasteMonitoringMsg;
    }

}

export class ThresholdLabels {
    public thresholdLabel1:string;
    public thresholdLabel2:string;
    public thresholdLabel3:string;
    public thresholdLabel4:string;

    constructor(jsonRes) {
        if(jsonRes) {
            for(var i=0; i<jsonRes.length; i++) {
                switch (jsonRes[i].name) {
                    case "THRESHOLD_1_NAME":
                        this.thresholdLabel1 = jsonRes[i].value;
                        break;
                    case "THRESHOLD_2_NAME":
                        this.thresholdLabel2 = jsonRes[i].value;
                        break;
                    case "THRESHOLD_3_NAME":
                        this.thresholdLabel3 = jsonRes[i].value;
                        break;
                    case "THRESHOLD_4_NAME":
                        this.thresholdLabel4 = jsonRes[i].value;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
