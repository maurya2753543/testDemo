import {ONLINE} from "../../hcu.constants";

export class PortTabModel extends Array {
    public isShowAll:boolean;
    public totalCount:number;
    constructor(jsonData, localizationService:any){
        super();
        
        if(jsonData.portList){
            let portData: PortTabListItems;
            for(let i=0; i<jsonData.portList.length; i++) {
                portData = new PortTabListItems(jsonData.portList[i], localizationService);
                this.push(portData); 
            }
            this.totalCount = jsonData.totalCount;
            this.isShowAll = (jsonData.portList.length == jsonData.totalCount) ? false : true;
        }
    }
}

export class PortTabListItems {
    public elementId:number;
    public status:string;
    public label:string;
    public hcu_label:string;
    public serialNumber:string;
    public slotNumber:number;
    public portNumber:number;
    public monitoringPlanName:string;
    public testPointComp:number;
    public attenuation:number;
    public broadcast:string;
    public rpm_label:string;
    public alarmNetworkSeverity: number;

    constructor(portList, localizationService) {
        if(portList) {
            this.elementId = portList.elementId;
            this.status = (portList.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()).toUpperCase() : localizationService.instant(portList.status.toUpperCase()).toUpperCase();
            this.status = this.status.toUpperCase();
            this.label = portList.label;
            this.hcu_label = portList.hcu_label;
            this.serialNumber = portList.serialNumber;
            this.slotNumber = portList.slotNumber;
            this.portNumber = portList.portNumber;
            this.monitoringPlanName = portList.monitoringPlanName;
            this.testPointComp = portList.testPointComp;
            this.attenuation = portList.attenuation;
            this.rpm_label = portList.rpm_label;
            this.alarmNetworkSeverity = portList.alarmNetworkSeverity;
            if(portList.broadcast != undefined) {
                this.broadcast = (portList.broadcast == true) ? localizationService.instant('YES') : localizationService.instant('NO');
            }
        }
        
    }
}
