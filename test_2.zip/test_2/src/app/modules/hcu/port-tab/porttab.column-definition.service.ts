import {Injectable} from '@angular/core';
import { CommonStrings } from "../../../constant/common.strings";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {EDIT_ICON, ELEMENT_ANALYSIS, ESCAPE_CHAR} from "../../../constant/app.constants";
import {HCUSharedService} from '../hcu.shared.service';
import {PORTTabDataService} from './porttab.data.service';
import {EDIT_OPERATION} from '../hcu.constants';
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ShowAlert} from "./../../../utilities/showAlert";
import {SharedService} from "../../../shared/shared.service";
import {LanguageService} from "../../../shared/locale.language.service";
import {FloatFilter} from "../../../shared/float.filter";
import {StatusFilter} from "../../../shared/status.filter";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from '@ngx-translate/core';
import {
    ALARM_CRITICAL_PERCENTAGE_COLOR, ALARM_MAJOR_PERCENTAGE_COLOR, ALARM_MINOR_PERCENTAGE_COLOR,
    ALARM_WARNING_PERCENTAGE_COLOR, RANKING_BORDER_BOTTOM, ALARM_GOOD_PERCENTAGE_COLOR
} from "../../../constant/app.constants";
import { SeverityFilter } from "./severity.filter";
import { param } from 'jquery';

@Injectable()

export class PORTTabColumnDefinationService {

    private CHECKBOX_COLUMN: any;
    private GROUP_1: any;
    private GROUP_2: any;
    private slot: any;
    private GROUP_3: any;
    private EDIT_COLUMN: any;
    private alarmStatus: any;

    constructor(private hcuSharedService:HCUSharedService,
                private portTabDataService:PORTTabDataService,
                private localeDataService:LocaleDataService,
                private translate : TranslateService,
                private sharedService : SharedService,
                private languageService : LanguageService,
                private showAlert:ShowAlert){
                    this.translateLocaleStr();
    }

    private _HEADER_FIELDS: any = {
        status : {field: "status", name: "Status"},
        alarmStatus : {field: "alarmNetworkSeverity", name: "Alarm Status"},
        port : {field: "label", name: "Port"},
        hcu : {field: "hcu_label", name: "HCU"},
        rpm : {field: "rpm_label", name: "RPM"},
        slot : {field: "slotNumber", name: "Slot"},
        serialNumber : {field: "serialNumber", name: "Serial Number"},
        portNumber : {field: "portNumber", name: "Port Number"},
        testPointComp : {field: "testPointComp", name: "Test Point Compesation(dB)"},
        attenuation : {field: "attenuation", name: "Attenuation(dB)"},
        monitoringPlanName:{field: "monitoringPlanName", name: "Monitoring Plan"},
        portInBroadcast:{field: "broadcast", name: "Port in Broadcast"},
        edit : {field: "edit", name: "View"}
    };

    private translateLocaleStr(): void{
        this._HEADER_FIELDS.status.name = this.translate.instant('HCU_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.alarmStatus.name = this.translate.instant('HCU_TAB_HEADER_ALARM_STATUS');
        this._HEADER_FIELDS.port.name = this.translate.instant('PORT_HEADER_PORT');
        this._HEADER_FIELDS.hcu.name = this.translate.instant('PORT_HEADER_HCU');
        this._HEADER_FIELDS.rpm.name = this.translate.instant('PORT_HEADER_RPM');
        this._HEADER_FIELDS.slot.name = this.translate.instant('PORT_HEADER_SLOT');
        this._HEADER_FIELDS.serialNumber.name = this.translate.instant('HCU_TAB_HEADER_SERIAL_NUMBER');
        this._HEADER_FIELDS.portNumber.name = this.translate.instant('PORT_HEADER_PORT_NUMBER');
        this._HEADER_FIELDS.testPointComp.name = this.translate.instant('HCU_TEST_POINT_COMPENSATION');
        this._HEADER_FIELDS.attenuation.name = this.translate.instant('HCU_ATTENUATION');
        this._HEADER_FIELDS.monitoringPlanName.name = this.translate.instant('PORT_HEADER_MONITORING_PLAN');
        this._HEADER_FIELDS.edit.name = this.translate.instant('HCU_TAB_HEADER_EDIT');
        this._HEADER_FIELDS.portInBroadcast.name = this.translate.instant('PORT_TAB_HEADER_PORT_IN_BROADCAST');
    }

    /*
*@name getColumnDefy
    *@desc Get column def for port tab data-grid
    *@return array[any]
    */
    public setData(): void{
        let lang: string = this.languageService.getCurrentLanguage();
        let digits: string = '1.1-2';
        let rpmName: string = this.getEscapeChar();
        let parentStatus;
        this.CHECKBOX_COLUMN = [{
            headerName: '',
            maxWidth: 25,
            checkboxSelection: function (param) {
                return param.data ? true : false;
            },
            pinned: true,
            sortingOrder: [null],
            field: '',
            headerCheckboxSelection: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressMenu: true,
            filterParams: {newRowsAction: 'keep'},
            suppressResize: true
        }];
        /*-------------*/
        this.GROUP_2 =  [{
            headerName: this._HEADER_FIELDS.hcu.name,
            headerTooltip: this._HEADER_FIELDS.hcu.name,
            field: this._HEADER_FIELDS.hcu.field,
            minWidth: 284,
            filter: 'agTextColumnFilter',
            floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator, 
            rowGroup: true,
            hide: false,
            filterParams: {newRowsAction: 'keep'},
        },{
            headerName: this._HEADER_FIELDS.rpm.name,
            headerTooltip: this._HEADER_FIELDS.rpm.name,
            field: this._HEADER_FIELDS.rpm.field,
            minWidth: 170,
            width: 170,
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator, rowGroup: true,hide: false,
            filterParams: {newRowsAction: 'keep'},
        }];
        /*-------------*/
        this.GROUP_1 = [{
            headerName: this._HEADER_FIELDS.status.name,headerTooltip: this._HEADER_FIELDS.status.name, field: this._HEADER_FIELDS.status.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 80),
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filter: StatusFilter.ParentFilter,floatingFilterComponent: StatusFilter.ChildFloatingFilter,
            filterParams: {newRowsAction: 'keep'},
            },
            {
            headerName: this._HEADER_FIELDS.port.name,
            headerTooltip: this._HEADER_FIELDS.port.name,
            field: this._HEADER_FIELDS.port.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.port.name, 200),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator,
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'},
            cellRenderer: ((param:any)=>{
                if(!param.value || !param.data) { return; }
                let url = this.portAction(param);
                return "<a class='cursorClass' target='_blank' href='"+ url +"'>"+ param.value +"</a>";
            })
        }];
        /*--------------*/
        this.alarmStatus = {
            headerName: this._HEADER_FIELDS.alarmStatus.name,
            field: this._HEADER_FIELDS.alarmStatus.field,
            minWidth: 130,
            width: 130,
            suppressSizeToFit: true,
            suppressResize: true,
            headerTooltip: this._HEADER_FIELDS.alarmStatus.name,
            sortingOrder: ['asc', 'desc', null],
            cellClass: 'alarmSeverityClass cellBorder',
            valueGetter: this.alarmValueGetter,
            cellStyle: function (params) {
                let color: string;
                if(params.node.allLeafChildren){
                    let arr : Array<number> = [];
                    params.node.allLeafChildren.forEach(element => {
                        arr.push(element.data.alarmNetworkSeverity)
                    });
                    let max = Math.max(...arr);
                    switch (max) {
                        case 0:
                            color = ALARM_GOOD_PERCENTAGE_COLOR;
                            break;
                        case 2:
                            color = ALARM_WARNING_PERCENTAGE_COLOR;
                            break;
                        case 3:
                            color = ALARM_MINOR_PERCENTAGE_COLOR;
                            break;
                        case 4:
                            color = ALARM_MAJOR_PERCENTAGE_COLOR;
                            break;
                        case 5:
                            color = ALARM_CRITICAL_PERCENTAGE_COLOR;
                            break;
                    }
                    return { backgroundColor: color, color: "black", 'text-align': 'center', borderBottom: RANKING_BORDER_BOTTOM };
                }
                switch (params.data.alarmNetworkSeverity) {
                    case 0:
                        color = ALARM_GOOD_PERCENTAGE_COLOR;
                        break;
                    case 2:
                        color = ALARM_WARNING_PERCENTAGE_COLOR;
                        break;
                    case 3:
                        color = ALARM_MINOR_PERCENTAGE_COLOR;
                        break;
                    case 4:
                        color = ALARM_MAJOR_PERCENTAGE_COLOR;
                        break;
                    case 5:
                        color = ALARM_CRITICAL_PERCENTAGE_COLOR;
                        break;
                }
                return { backgroundColor: color, color: "black", 'text-align': 'center', borderBottom: RANKING_BORDER_BOTTOM };
            },
            filter: SeverityFilter.ParentFilter,
            floatingFilterComponent: SeverityFilter.ChildFloatingFilter,
            floatingFilterComponentParams: { suppressFilterButton: true },
            filterParams: { newRowsAction: 'keep' }
        }
        /*-------------*/
        this.slot = {
            headerName: this._HEADER_FIELDS.slot.name,
            headerTooltip: this._HEADER_FIELDS.slot.name,
            field: this._HEADER_FIELDS.slot.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.slot.name, 70),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'},
        };
        this.GROUP_3 = [{
            headerName: this._HEADER_FIELDS.serialNumber.name,headerTooltip: this._HEADER_FIELDS.serialNumber.name, field: this._HEADER_FIELDS.serialNumber.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serialNumber.name, 30),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator,
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'}
        },{
            headerName: this._HEADER_FIELDS.portNumber.name,headerTooltip: this._HEADER_FIELDS.portNumber.name, field: this._HEADER_FIELDS.portNumber.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.portNumber.name, 50),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'},
        },{
            headerName: this._HEADER_FIELDS.testPointComp.name,headerTooltip: this._HEADER_FIELDS.testPointComp.name, field: this._HEADER_FIELDS.testPointComp.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.testPointComp.name, 40),
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'},
            filter: FloatFilter.ParentFilter,floatingFilterComponent: FloatFilter.ChildFloatingFilter,
            cellRenderer: ((param:any)=>{
                if(param.data && typeof param.data != "undefined") {
                    let value: string = this.sharedService.toDecimal(param.data.testPointComp,digits).toString();
                    return "<span>".concat(value, "</span>");
                }
            })
        },{
            headerName: this._HEADER_FIELDS.attenuation.name,
            headerTooltip: this._HEADER_FIELDS.attenuation.name,
            field: this._HEADER_FIELDS.attenuation.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.attenuation.name, 20),
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'},
            filter: FloatFilter.ParentFilter,floatingFilterComponent: FloatFilter.ChildFloatingFilter,
            cellRenderer: ((param:any)=>{
                if(param.data && typeof param.data != "undefined") {
                    let value: string = this.sharedService.toDecimal(param.data.attenuation,  digits).toString();
                    return "<span>".concat(value, "</span>");
                }
            })
        },{
            headerName: this._HEADER_FIELDS.monitoringPlanName.name,
            headerTooltip: this._HEADER_FIELDS.monitoringPlanName.name,
            field: this._HEADER_FIELDS.monitoringPlanName.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.monitoringPlanName.name, 20),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator,
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'}
        }, {
            headerName: this._HEADER_FIELDS.portInBroadcast.name,
            headerTooltip: this._HEADER_FIELDS.portInBroadcast.name,
            field: this._HEADER_FIELDS.portInBroadcast.field,
            minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.portInBroadcast.name, 20),
            filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
            comparator: gridCustomComparator,
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'}
        }];
        /*-------------*/
        this.EDIT_COLUMN = [{
            headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
            minWidth: 70, maxWidth: 100,
            width: 70,
            pinned: this.sharedService.isPinned(),
            sortingOrder: [null],
            suppressSorting : true,
            cellStyle : () => {
                return { 'text-align': 'center' };
            },
            filter: 'agTextColumnFilter',
            comparator: gridCustomComparator,
            floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'},
            suppressMenu: true,
            cellRenderer: ((param:any)=>{
                if(!param.data){
                    return;
                }
                let gui = document.createElement('div');
                gui.innerHTML = EDIT_ICON;
                let eFilterText = gui.querySelector('i');
                eFilterText.addEventListener("click", (()=>{
                    this.action(param);
                }));
                gui.className = "ag-Grid-cursor";
                return gui;
            })

        }];
        /*-------------*/
    }

    private getEscapeChar(): string{
        let rpmName: string = this._HEADER_FIELDS.rpm.name;
        for(let i = 0; i < 19; i ++){
            rpmName = rpmName + ESCAPE_CHAR;
        }
        return rpmName;
    }
    alarmValueGetter(params){
        let value: string;
        if(params.node.allLeafChildren){
            let arr : Array<number> = [];
            params.node.allLeafChildren.forEach(element => {
                arr.push(element.data.alarmNetworkSeverity)
            });
            let max = Math.max(...arr);
            switch (max) {
                case 0:
                    value = CommonStrings.ALARM_LIST_SEVERITY_GOOD;
                    break;
                case 2:
                    value = CommonStrings.ALARM_LIST_SEVERITY_WARNING;
                    break;
                case 3:
                    value = CommonStrings.ALARM_LIST_SEVERITY_MINOR;
                    break;
                case 4:
                    value = CommonStrings.ALARM_LIST_SEVERITY_MAJOR;
                    break;
                case 5:
                    value = CommonStrings.ALARM_LIST_SEVERITY_CRITICAL;
                    break;
            }
            return value;
        }
        switch (params.data.alarmNetworkSeverity) {
            case 0:
                value = CommonStrings.ALARM_LIST_SEVERITY_GOOD;
                break;
            case 2:
                value = CommonStrings.ALARM_LIST_SEVERITY_WARNING;
                break;
            case 3:
                value = CommonStrings.ALARM_LIST_SEVERITY_MINOR;
                break;
            case 4:
                value = CommonStrings.ALARM_LIST_SEVERITY_MAJOR;
                break;
            case 5:
                value = CommonStrings.ALARM_LIST_SEVERITY_CRITICAL;
                break;
        }
        return value;
    }
    public getTableColumnDef(): any[] {
        this.toggleTreeMode(false);
        let columnDef: any[] = [
            ...this.CHECKBOX_COLUMN,
            ...this.GROUP_1,
            ...[this.alarmStatus],
            ...this.GROUP_2,
            ...[this.slot],
            ...this.GROUP_3,
            ...this.EDIT_COLUMN
        ]
        return columnDef;
    }

    public getTreeColumnDef(): any[]{
        this.toggleTreeMode(true);
        const slot: any = SharedService.getDeepCopy(this.slot);
        this.setSlotAdditionalData(slot);
        let columnDef: any[] = [
            ...this.CHECKBOX_COLUMN,
            ...this.GROUP_2,
            ...[this.alarmStatus],
            ...[slot],
            ...this.GROUP_1,
            ...this.GROUP_3,
            ...this.EDIT_COLUMN
        ]
        return columnDef;
    }

    private setSlotAdditionalData(slot: any): void {
        slot['aggFunc'] = 'first';
        slot['valueFormatter'] = (params) => {
            if (params.node.field != this._HEADER_FIELDS.rpm.field) {
                return ''
            }
        };
    }

    private toggleTreeMode(isEnable: boolean): void{
        this.GROUP_2[0].rowGroup = this.GROUP_2[0].hide = isEnable;
        this.GROUP_2[1].rowGroup = this.GROUP_2[1].hide = isEnable;
    }

    private action(param):void {
        this.portTabDataService.getPortDetails(param.data.elementId).subscribe((response)=>{
            let data: any = {operation: EDIT_OPERATION, portTabModel: response};
            this.hcuSharedService.setPortTabModel(data);
            this.hcuSharedService.getPortViewSubject().next(data);
        },(error)=>{
            this.showAlert.showErrorAlert(error);
        })

    }
    private portAction(param: any): string {
        return this.sharedService.getHost() + ELEMENT_ANALYSIS + param.data.elementId;
    }
}
