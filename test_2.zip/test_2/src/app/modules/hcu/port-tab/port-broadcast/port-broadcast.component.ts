import {Component} from '@angular/core';
import {HCUSharedService} from '../../hcu.shared.service';
import {BroadcastModel} from '../model/port-broadcast.model';
import {PORTTabDataService} from '../porttab.data.service';
import { Logger } from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { ALERT_SUCCESS,ALERT_INFO } from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'port-broadcast',
    templateUrl:'port-broadcast.component.html'
})

export class PortBroadcastComponent {

    public isCloseRightSlider:boolean = false;
    public isReadOnly:boolean = true;
    public broadcastModelObj:BroadcastModel;
    public timeRemaining:number;
    private tag:string = "PortBroadcastComponent";
    constructor(private hcuSharedService:HCUSharedService,
                private portTabDataService:PORTTabDataService,
                private logger: Logger,private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private sweetAlert:SweetAlert,
                private sharedService:SharedService){
        this.getBroadcastModel();
    }

    ngOnInit(){
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //function :: get modelobj from hcu shared service.
    private getBroadcastModel():void {
        this.broadcastModelObj = this.hcuSharedService.getBroadcastModel();
        this.timeRemaining = this.broadcastModelObj.calculateRemainingHours(this.broadcastModelObj.stopTime);
    }

    //function :: saves/puts broadcast model to server.
    private save():void {
        this.portTabDataService.enableBroadcastOnPort(this.broadcastModelObj.id, this.broadcastModelObj).subscribe(this.onSaveSuccess.bind(this), this.onError.bind(this));
    }

    public onstopFreqChange(stopFreq:any):void {
        this.broadcastModelObj.stopFrequency = parseInt(stopFreq);
    }

    public onDwellChange(dwellTime):void {
        this.broadcastModelObj.dwellTime = parseInt(dwellTime);
    }

    private onSaveSuccess(data:any):void {
        this.logger.debug(this.tag, "onSaveSuccess(): edit port success data=", data);
        this.sweetAlert.showAlert(ALERT_SUCCESS, "Port in Broadcast saved successfully.",CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
        (isConfirm)=>{
            this.btnClose_click();
            this.hcuSharedService.getPortRefreshListSubject().next(true);
        })
    }

    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }
    //function :: toggles between view and edit mode.
    private toggleEdit():void {
        this.isReadOnly = false;
    }

    //function:: closes slider.
    public btnClose_click():void {
        this.isCloseRightSlider = true;
        this.hcuSharedService.getPortClearSliderSub().next(true);
    }
}
