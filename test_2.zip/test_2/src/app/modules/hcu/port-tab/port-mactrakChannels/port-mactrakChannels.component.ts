import {Component, Input} from '@angular/core';

import {Grid} from "../../../../shared/ag-grid.options";
import {HCUTabDataService} from '../../hcu-tab/hcutab.data.service';
import {MACTrakChannelsColumnDefinitionService} from '../../../shared/common-components/listView/mactrakChannels.column-definition.service';
import { Logger } from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import {HCUSharedService} from '../../hcu.shared.service';
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'port-macktrakChannel',
     templateUrl:'../../../shared/common-components/listView/listView.component.html'
})

export class PORTMactrakChannel {

    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata=[];
    private tabType = "PORT_MACKTRAK_CHANNEL";
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    private tag:string = "MACTrak Channels Component";
    private TABLE_LIST_EXPORT_ALL:string = "";
    private CLOSE_SLIDER:string = "";
    public gridTabType:string = "PORTMactrackChannelExport";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private PORT_MACTRAK_CHANNELS_HEADER:string = "";

    public styleForHeaderBtns:string = 'max-width:100%'  // Bug fix XPTUI 621


    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;

    constructor(private hcuTabDataService:HCUTabDataService,
                private mactrakChannelsColumnDefinitionService:MACTrakChannelsColumnDefinitionService,
                private logger: Logger,private showAlert: ShowAlert,private sharedService:SharedService,
                private localeDataService: LocaleDataService, private hcuSharedService:HCUSharedService){
                    this.translateLocalString();
        this.setEventButtonKeys();
    }

    ngOnInit(){
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.notifyCloseSlider("dummy can be ignored later");
        })
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'PORT_MACKTRAK_CHANNEL', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'PORT_MACKTRAK_CHANNEL', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }

    //sets slider label.
    private setHeaderLabel(childName?):void {
        this.headerTxt = this.PORT_MACTRAK_CHANNELS_HEADER;
        this.headerTxt =childName ?  this.headerTxt + ' - ' + childName : this.headerTxt;
    }
    
    private btnClose_click(){
        this.isCloseRightSlider = true;
    }

    //method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    // method :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.mactrakChannelsColumnDefinitionService.getColumnDef());
        this.childData && this.getMACTrakChannels();
    }

    //method :: gets mactrack channels for elementId.
    private getMACTrakChannels():void {
        this.setHeaderLabel(this.childData.label);
        this.hcuTabDataService.viewMACTrakChannels(this.childData.elementId).subscribe(this.onViewEventSuccess.bind(this) ,this.onError.bind(this));
    }

    private onViewEventSuccess(data:any):void {
        this.rowdata = data;
        this.totalCount = this.rowdata.length;
        this.setShowAllLabel(this.rowdata.length, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }


    // method :: notifies grid is ready.
    public notifyGridReadyViewEvents(params:any){
        this.setGridColDefinition();
    }

    //slider close.
    public notifyCloseSlider(params:any){
        this.isCloseRightSlider = true;
        this.hcuSharedService.getPortClearSliderSub().next(true);
    }

    //refrsh list
    public notifyRefreshGrid(params:any):void {
        this.getMACTrakChannels();
    }

    //method called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //translate acco. lang
    private translateLocalString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.PORT_MACTRAK_CHANNELS_HEADER = localizationService.instant('PORT_MACTRAK_CHANNELS_HEADER');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

}