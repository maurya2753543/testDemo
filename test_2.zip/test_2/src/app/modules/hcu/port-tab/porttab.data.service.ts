import {Injectable} from '@angular/core';
import {Observable, } from "rxjs";
import { throwError } from 'rxjs';
import {HttpResponse} from "@angular/common/http";
import {map, catchError} from "rxjs/operators";
import {HCUHttpService} from "../hcu.http.service";
import {MonitoringPlanModel, ThresholdLabels} from './model/port-monitoringPlan.model';
import {PortTabModel} from './model/porttab.model';
import { LocaleDataService } from "./../../../shared/locale.data.service";
import {UserDefinedModel} from './model/portDetails.model';
import  {LanguageService} from "./../../../shared/locale.language.service";


@Injectable()

export class PORTTabDataService {
    private localizationService:any;
    public porttabfilterchangedata: any;
    constructor(private hcuHttpService:HCUHttpService,
                private localeDataService:LocaleDataService,
                private languageService : LanguageService){
                    this.localizationService = this.localeDataService.getLocalizationService();
                }

    //Method to get all RPM PORT list
    public getAllPORTTabList(showAll:boolean): Observable<any> {
        return this.hcuHttpService
            .getAllPORTTabList(showAll)
            .pipe(map((portTabListDataObj: HttpResponse<any>) => {
                return new PortTabModel(portTabListDataObj, this.localizationService);
            }),
            catchError(this.handleError))
    }

    public getPortDetails(elementId):Observable<any> {
        return this.hcuHttpService
                .getPortDetails(elementId)
                .pipe(map((portDetailsObj:HttpResponse<any>)=>{
                    return portDetailsObj;
                }),
                catchError(this.handleError))
    }

    public editPort(data:any):Observable<any> {
        return this.hcuHttpService
                .editPort(data)
                .pipe(map((editPortRes:HttpResponse<any>)=>{
                    return editPortRes;
                    
                }))
    }

    public getBroadcastStatusForPort(elementId):Observable<any> {
        return this.hcuHttpService
                .getBroadcastStatusForPort(elementId)
                .pipe(map((broadcastRes:HttpResponse<any>)=>{
                    return broadcastRes;
                }))
    }

    public enableBroadcastOnPort(elementId, data):Observable<any> {
        return this.hcuHttpService
                .enableBroadcastOnPort(elementId, data)
                .pipe(map((broadcastRes:HttpResponse<any>)=>{
                    if(broadcastRes.status) return true;
                }))
    }

    public removeBroadcastOnPort(elementId):Observable<any> {
        return this.hcuHttpService
                .removeBroadcastOnPort(elementId)
               .pipe(map((removeBroadcast:HttpResponse<any>)=>{
                if(removeBroadcast)
                    return true;
            }))
    }

    public getMonitoringPlanSettings(portId):Observable<any> {
        return this.hcuHttpService
                .getMonitoringPlanSettings(portId)
                .pipe(map((monitoringSetting:HttpResponse<any>)=>{
                    return new MonitoringPlanModel(monitoringSetting);
                }),
            catchError(this.handleError))
    }

    public putMonitoringPlanSettings(data):Observable<any> {
        return this.hcuHttpService
                .putMonitoringPlanSettings(data)
                .pipe(map((monitoringSetting:HttpResponse<any>)=>{
                    return monitoringSetting;
                }),
                catchError(this.handleError))
    }

    public exportMonitoringPlan(portId):Observable<any> {
        return this.hcuHttpService
                .exportMonitoringPlan(portId)
                .pipe(map((exportData)=>{
                    return exportData;
                }))
    }

    public importMonitoringPlan(formData):Observable<any> {
        return this.hcuHttpService
                .importMonitoringPlan(formData)
                .pipe(
                    function(res){ return  res},
                //     map(
                //         (importRes:any)=>{
                //          console.log(importRes)
                //     console.log('formData ->', formData)
                //     if(importRes.status == 200) return true;
                // }
                // ),
                catchError(this.handleError))
    }

    public pasteMonitoringPlan(data):Observable<any> {
        return this.hcuHttpService
                .pasteMonitoringPlan(data)
                .pipe(map((res:HttpResponse<any>)=>{
                    return res;
                }))
    }

    public getThresholdLabels():Observable<any> {
        return this.hcuHttpService
                .getThresholdLabels()
                .pipe(map((thresholdRes:HttpResponse<any>)=>{
                    return new ThresholdLabels(thresholdRes);
                }))
    }

    public portRepair(portId):Observable<any> {
        return this.hcuHttpService
                .portRepair(portId)
                .pipe(map((repairRes)=>{
                    if(repairRes.status == 200) return 200;
                }),
                catchError(this.handleError))
    }


    public userDefined():Observable<any> {
        return this.hcuHttpService
                .getUserDefined()
                .pipe(map((res)=>{
                    return new UserDefinedModel(res);
                }))
    }

    //Error handler
    public handleError(error) {
        return throwError(error);
    }
}
