
import { Routes, RouterModule } from '@angular/router';
import {HCUComponent} from "./hcu.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: HCUComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

 export class HcuRoutes{}
// export const routing: ModuleWithProviders = RouterModule.forChild(routes);

//export const HcuRoutes: Routes = [{ path: "", component: HCUComponent, pathMatch: 'prefix' }];
