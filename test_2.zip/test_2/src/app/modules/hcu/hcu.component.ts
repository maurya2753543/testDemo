import {Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, OnInit, OnDestroy} from '@angular/core';
import {RPMTabComponent} from "./rpm-Tab/rpmtab.component";
import {HCUTabComponent} from "./hcu-tab/hcutab.component";
import {PORTTabComponent} from './port-tab/porttab.component';
import {HSMTabComponent} from './hsm-tab/hsmtab.component';
import {Router, ActivatedRoute, Data} from '@angular/router';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import {LocaleDataService} from "../../shared/locale.data.service";
import {HCUSharedService} from "./hcu.shared.service";
import {HCU_MODULE} from "../../constant/app.constants";
import {StatusFilter} from "../../shared/status.filter";
import {SharedService} from "../../shared/shared.service";
import { TranslateService } from '@ngx-translate/core';
import {NAV_LINK_HCU,NAV_LINK_CMTS,PERM_ADMINISTER_PATHTRAK_PORTS} from "../../constant/app.constants";
import { NavService } from '../../shared/nav.service';

@Component({
    selector: 'huc-component',
    templateUrl: 'hcu.component.html'
})

export class HCUComponent implements OnDestroy {
    public loadComponent:boolean;
    private HCUTabRef:any;
    private RPMTabRef:any;
    private PORTTabRef:any;
    private HSMTabRef:any;
    private oldSelectedSettings: Object = {};
    NAV_LINK_HCU: string = NAV_LINK_HCU;
    NAV_LINK_CMTS: string = NAV_LINK_CMTS;
    PERM_ADMINISTER_PATHTRAK_PORTS:string =PERM_ADMINISTER_PATHTRAK_PORTS;
    permList: any = [NAV_LINK_HCU,NAV_LINK_CMTS,PERM_ADMINISTER_PATHTRAK_PORTS];
    public selectedTab : string;
    // @ViewChild('targetRPM', {read: ViewContainerRef}) _targetRPM;
    // @ViewChild('targetHCU', {read: ViewContainerRef}) _targetHCU;
    // @ViewChild('targetPORT', {read: ViewContainerRef}) _targetPORT;
    // @ViewChild('targetHSM', {read: ViewContainerRef}) _targetHSM;
    constructor(private componentFactoryResolver: ComponentFactoryResolver,
                private route: ActivatedRoute,
                public navService: NavService,
                private router: Router,
                private sharedService:SharedService,
                private viewContainerRef: ViewContainerRef,
                // public locale: LocaleService,
                // public localization: LocalizationService,
                public localeDataService:LocaleDataService,
                private hcuSharedService:HCUSharedService,
                public translate : TranslateService) {
                  // super(locale, localization);
                  let module = HCU_MODULE;
                    this.localeDataService.initLanguage(module);
    }

    ngOnInit() {
        if(this.sharedService.getRedirectTAB()) {
            this.getTranslated(this.sharedService.getRedirectTAB(), true);
            if(this.hcuSharedService.getTab() && this.sharedService.getRedirectTAB()){
                this.LoadTab(this.sharedService.getRedirectTAB())
                this.sharedService.setRedirectTAB('');
            }
        }else {
            if(this.hcuSharedService.getTab()){
                this.translateLocaleString();
                this.selectedTab = 'port';
            } else {
                this.getTranslated('port', false);
            }
        }
    }

    checkMonitoringTabPermission(){
        return this.sharedService.checkMplanPermissions(this.permList);
    }

    getTranslated(tabValue: string, bool?: boolean){
        this.translate.onLangChange.subscribe(lang => {
            this.translateLocaleString();
            this.LoadTab(tabValue);
            this.hcuSharedService.setTab(tabValue);
        })
    }

    private navigateToURL(url){
        this.router.navigate([url]);
    }

    //function used to load tabs of HCU section.
    public LoadTab(tab:string):void {
        let selectedTab = this.sharedService.getRedirectTAB();
        this.selectedTab = tab.toLocaleLowerCase();
        if(selectedTab && selectedTab.length > 0){
            this.selectedTab = selectedTab;
            this.sharedService.setRedirectTAB("");
        }
        // switch (this.selectedTab) {
        //     case 'hcu':
        //         // document.querySelector('#hcu').classList.add('in active');
        //         break;
        //     case 'rpm':
        //         // document.querySelector('#rpm').classList.add('in active');
        //         break;
        //     case 'port':
        //         // document.querySelector('#port').classList.add('in active');
        //         break;
        //     case 'hsm':
        //         // document.querySelector('#hsm').classList.add('in active');
        //         break;
        //     default:
        //         break;
        // }
    }

    /* Function used to create component on settings section link click */
    // private createComponentOnClick(clickedComponent: any, currentViewContainer: any, currentCompRef: any): void{
    //     this.oldSelectedSettings['comp'] ? this.oldSelectedSettings['viewRef'].detach() : '';
    //     if(!currentCompRef){
    //         let componentFactory: any = this.componentFactoryResolver.resolveComponentFactory(clickedComponent);
    //         currentCompRef = currentViewContainer.createComponent(componentFactory);
    //     }else{
    //         currentViewContainer.insert(currentCompRef.hostView);
    //     }
    //     this.oldSelectedSettings = {'comp' : currentCompRef, 'viewRef' : currentViewContainer};
    //     return currentCompRef;
    // }

    //function :: used for localization
    private translateLocaleString(): void {
        // let localizationService = this.localeDataService.getLocalizationService();

        StatusFilter.setSeverity(
            {
                default: this.translate.instant('DEFAULT'),
                online: this.translate.instant('ONLINE'),
                offline: this.translate.instant('OFFLINE'),
                busy: this.translate.instant('BUSY'),
                error: this.translate.instant('ERROR'),
                disabled: this.translate.instant('DISABLED'),
                unavailable: this.translate.instant('UNAVAILABLE')
            }
        );
        StatusFilter.setCMTSVisibility(false);
        StatusFilter.setRCIVisibility(false);
    }

    ngOnDestroy(): void {
        this.hcuSharedService.modeldata = null;
    }
}
