import {Injectable} from '@angular/core';
import {Observable} from "rxjs";
import {map, catchError} from "rxjs/operators";
import {HttpResponse} from "@angular/common/http";
import {HCUHttpService} from "../hcu.http.service";
import {HCUTabModel} from './model/hcutab.model';
import {ImportLabelModel} from "../importLabel.model";
import { LocaleDataService } from "./../../../shared/locale.data.service";// passing localization service to hcu tab model.
import {MactrakChannelsModel} from '../../shared/common-components/models/mactrakchannels.model';
import {ViewEventsModel} from '../../shared/common-components/models/viewEvents.model';
import {ThresholdModel} from "../../shared/common-components/models/threshold.model";
import { _throw } from 'rxjs/observable/throw';

@Injectable()

export class HCUTabDataService {
    private localService:any;
    public hcufilterchangedata: any;
    constructor(private hcuHttpService:HCUHttpService, private localeDataService:LocaleDataService){
        this.localService = this.localeDataService.getLocalizationService();
    }

    //Method to get all CMTS list
    public getAllHcuTabList(showall:boolean): Observable<any> {
        return this.hcuHttpService
            .getAllHcuTabList(showall)
            .pipe(map((hcuTabListDataObj: HttpResponse<any>) => {
                return this.changeHCUTabListResponse(hcuTabListDataObj);
            }),
            catchError(this.handleError))
    }

    //Method to get HCU EVENTS list
    public getEventListData(elementID: any, type: string): Observable<any> {
        return this.hcuHttpService
            .getEventsListData(elementID, type)
            .pipe(map((eventListDataObj: HttpResponse<any>) => {
                return new ViewEventsModel(eventListDataObj, this.localService);
            }),
            catchError(this.handleError))
    }

    //function :: uploads file to server.
    public importLabels(file:any, type: string):Observable<any> {
        return this.hcuHttpService
                .hcuImportLabels(file, type)
               .pipe(map((obj:HttpResponse<any>) =>{
                return new ImportLabelModel(obj);
            }),
            catchError(this.handleError))
    }

    public hcuReboot(hcuIds: number[]):Observable<any> {
        return this.hcuHttpService
                .hcuReboot(hcuIds)
                .pipe(map((rebootRes:HttpResponse<any>)=>{                   
                        return rebootRes;   
                }),
                catchError(this.handleError))
    }

    public hcuVerify(hostName):Observable<any> {   
        return this.hcuHttpService
                .hcuVerify(hostName)
               .pipe(map((hcuVerifyObj:HttpResponse<any>)=>{
                        return hcuVerifyObj;
            }),
            catchError(this.handleError))
    }

    public addHCU(hcuDataObj):Observable<any> {
        return this.hcuHttpService
                .addHCU(hcuDataObj)
                .pipe(map((addHCURes:HttpResponse<any>) =>{
                        return addHCURes;
                }),
                catchError(this.handleError))
    }

    public hcuRestore(hcuIds: number[]):Observable<any> {      
        return this.hcuHttpService
                .hcuRestore(hcuIds)
                .pipe(map((restoreRes:HttpResponse<any>)=>{
                          return restoreRes;
                }),
                catchError(this.handleError))
    }
    public hcuSyncClock(elementId):Observable<any> {
        return this.hcuHttpService
                .hcuSyncClock(elementId)
                .pipe(map((syncClockRes:HttpResponse<any>)=>{                    
                        return syncClockRes;                    
                }),
                catchError(this.handleError))
    }

    public hcuRepair(elementId):Observable<any> {
        return this.hcuHttpService
                .hcuRepair(elementId)
                .pipe(map((repairRes:HttpResponse<any>)=>{                   
                        return repairRes;
                }),
                catchError(this.handleError))
    }

    public getHCUDetails(elementId):Observable<any> {
        return this.hcuHttpService
                .getHCUDetails(elementId)
                .pipe(map((hcuDetailsObj:HttpResponse<any>)=>{
                    return hcuDetailsObj;
                }),
                catchError(this.handleError))
    }

    public editHCU(data):Observable<any> {
        return this.hcuHttpService
                .editHCU(data)
               .pipe(map((hcuEditRes:HttpResponse<any>)=>{
               return hcuEditRes;
            }),
            catchError(this.handleError))
    }

    public deleteHCU(elementId):Observable<any> {
        return this.hcuHttpService
                .deleteHCU(elementId)
                .pipe(map((deleteHCUResponse:HttpResponse<any>)=>{
                   return deleteHCUResponse;
                }),
                catchError(this.handleError))
    }

    public testConnectionHCU(elementId):Observable<any> {
        return this.hcuHttpService
                .testConnectionHCU(elementId)
                .pipe(map((testConnRes)=>{
                    return testConnRes;
                }),
                catchError(this.handleError))
    }

    public getPhysicalHSMs():Observable<any> {
        return this.hcuHttpService
                .getPhysicalHSMs()
                .pipe(map((phyHSMObj)=>{
                    return phyHSMObj;
                }),
                catchError(this.handleError))
    }

    public createVirtualHSM(obj:any):Observable<any> {
        return this.hcuHttpService
                .createVirtualHSM(obj)
                .pipe(map((resObj:HttpResponse<any>)=>{
                    return resObj;
                }),
                catchError(this.handleError))
    }

    public getFirmwareUpgradeList():Observable<any> {
        return this.hcuHttpService
            .getFirmwareUpgradeList()
            .pipe(map((hcuDetailsObj:HttpResponse<any>)=>{
                return hcuDetailsObj;
            }),
            catchError(this.handleError))
    }

    public checkNewFirmwareRelease():Observable<any> {
        return this.hcuHttpService
            .checkNewFirmwareRelease()
            .pipe(map((hcuDetailsObj:HttpResponse<any>)=>{
                return hcuDetailsObj;
            }),
            catchError(this.handleError))
    }

    public downloadUpgradedFirmware():Observable<any> {
        return this.hcuHttpService
            .downloadUpgradedFirmware()
            .pipe(map((response:HttpResponse<any>)=>{
                return response;
            }),
            catchError(this.handleError))
    }

    public getLatestFirmwarePackage():Observable<any> {
        return this.hcuHttpService
            .getLatestFirmwarePackage()
            .pipe(map((hcuDetailsObj:HttpResponse<any>)=>{
                return hcuDetailsObj;
            }),
            catchError(this.handleError))
    }

    public deleteFirmwarePackage(PackageVersion):Observable<any> {
        return this.hcuHttpService
            .deleteFirmwarePackage(PackageVersion)
            .pipe(map((deleteFirmwareUpgradeResponse:HttpResponse<any>)=>{
                return deleteFirmwareUpgradeResponse;
            }),
            catchError(this.handleError))
    }

    public upgradeFirmwareHCU(PackageVersion, HCUList):Observable<any> {
        return this.hcuHttpService
            .upgradeFirmwareHCU(PackageVersion, HCUList)
            .pipe(map((firmwareUpgradeResponse:HttpResponse<any>)=>{
                return firmwareUpgradeResponse;
            }),
            catchError(this.handleError))
    }

    public viewMACTrakChannels(elementId):Observable<any> {
        return this.hcuHttpService
                .viewMACTrakChannels(elementId)
                .pipe(map((resObj:HttpResponse<any>)=>{
                    return this.changeMACTrakChannelResponse(resObj);
                }),
                catchError(this.handleError))
    }

    public getThresholdsName(): Observable<any>{
        return this.hcuHttpService
            .getThresholdLabels()
           .pipe( map((resObj: any[])=>{
            return this.processThresholdsName(resObj);
        }),
        catchError(this.handleError))
    }

    private processThresholdsName(res: any[]): ThresholdModel[]{
        let thresholdModels: ThresholdModel[] = [];
        res.forEach((obj: any)=>{
            thresholdModels.push(obj);
        });
        return thresholdModels;
    }

    //function :: changes hcutab list response.
    private changeHCUTabListResponse(HCURes):any {
        let hcuList: HCUTabModel = new HCUTabModel(HCURes, this.localService);
        return hcuList;
    }

    private changeMACTrakChannelResponse(res):any {
        let mactrakchannels:MactrakChannelsModel = new MactrakChannelsModel(res, this.localService);
        return mactrakchannels;
    }

    public performUCDScan(hcuIds):Observable<any> {
        return this.hcuHttpService
                .performUCDScan(hcuIds)
                .pipe(map((ucdScanRes:HttpResponse<any>) =>{
                    return ucdScanRes;
                }),
                catchError(this.handleError))
    }

    //Error handler
    public handleError(error) {
        return _throw(error);
    }

    public getMacktrakThreshold():Observable<any>{
        return this.hcuHttpService.getMacktrakThreshold().pipe(map((thresholdObj:Response)=>{
            return thresholdObj;
        }),
        catchError(this.handleError));        
    }

    public updateMACTrakBulkThreshold(deviceIds, newStressedThreshold, newFailThreshold):Observable<any>{
        return this.hcuHttpService.updateMACTrakBulkThreshold(deviceIds, newStressedThreshold, newFailThreshold).pipe(map((thresholdObj:Response)=>{
            return thresholdObj;
        }),
        catchError(this.handleError));        
    }
}
