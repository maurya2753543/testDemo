import {SiteListModel} from '../../../sites/models/site-list.model';
import {Component} from '@angular/core';

import {HCUTabDataService} from '../hcutab.data.service';
import {HcuViewModel} from '../model/hcu-view.model';
import {Logger} from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {ALERT_SUCCESS,ALERT_INFO, NAV_LINK_HCU} from "../../../../constant/app.constants";
import {CommonStrings} from  '../../../../constant/common.strings';
import {HCUSharedService} from "../../hcu.shared.service";
import {ADD_OPERATION, EDIT_OPERATION,ONLINE, HCU_CONTAINER, HCU_SITE, FIRST_SELECT_OPTION} from '../../hcu.constants';
import {SharedService} from "../../../../shared/shared.service";
import { ContainerDataService } from './../../../container/container.data.service';
import {SiteListDataService} from '../../../sites/site-list/site-list.data.service';
import { ContainersSelect } from '../../../shared/dropdown/models/containersSelect.model';
import { SitesSelect } from '../../../shared/dropdown/models/sitesSelect.model';
import {map} from "rxjs/operators";

@Component({
    selector:'hcu-view',
    templateUrl:'hcu-view.component.html'
})

export class HCUViewComponent {
    public dataModel:HcuViewModel = new HcuViewModel({});
    public isCloseRightSlider:boolean;
    public isHCUVerified:boolean = false;
    public isReadOnly:boolean = false;
    private isConnectBtnDisabled:boolean = true;
    public isAddbtnDisabled:boolean = true;
    private currentOperation:string = "";
    public isAddHidden:boolean = true;
    private isEditHidden:boolean = true;
    public isDeleteHidden:boolean = false;
    public isAddOperation:boolean = false;
    public isEditOperation:boolean = false;
    public isEditDisabled:boolean = true;
    private HCU_ADD_SUCCESS:string = "";
    private HCU_EDIT_SUCCESS:string = "";
    private HCU_DELETE_SUCCESS:string = "";
    private HCU_DELETE_CONFORMATION_TITLE:string = "";
    private HCU_DELETE_CONFORMATION_MESSAGE:string = "";
    private DOT: string = "";
    private statusData:string = '';
    private displayModifiedDate:string = '';
    private containerOptions: any;
    private siteOptions: any;
    private tag:string = "HCUViewComponent";
    private defaultContainer = FIRST_SELECT_OPTION + HCU_CONTAINER;
    private defaultSite = FIRST_SELECT_OPTION + HCU_SITE;
    public errorMessages: any = {
        "isIpAddressEmpty": false,
        "isContainerEmpty": false
    };
    constructor(private hcuTabDataService:HCUTabDataService,private logger: Logger,
                private showAlert: ShowAlert,private localeDataService: LocaleDataService,
                private sweetAlert:SweetAlert, private hcuSharedService:HCUSharedService,
                private sharedService:SharedService, private containerDataService:ContainerDataService,
                private siteListDataService:SiteListDataService){
                }

    ngOnInit(){
        this.getLocalizeDOT();
        this.translateLocaleString();
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.formChangeSubListener();
        this.containerDataService.getNodeOnlyContainers()
            .pipe(map((json) => {
                return new ContainersSelect(json);
            }))
            .subscribe(this.setContainerOptions.bind(this));
        this.siteListDataService.getSiteList(true,'HARDWARE')
            .pipe(map((json) => {
                return new SitesSelect(json);
            }))
            .subscribe(this.setSiteOptions.bind(this));
        this.setFormData(this.hcuSharedService.getHcuViewModelData());
    }

    private setContainerOptions(data: any): void {
        //Removed setting of default value here because dropdown component handles that
        //and default is set using defaultContainer on component html.
        this.containerOptions = data;
    }

    private setSiteOptions(data: any): void {
        //Removed setting of default value here because dropdown component handles that
        //and default is set using defaultSite on component html.
        this.siteOptions = data;
    }

    public ipAddressEmpty(): void{
        if(this.dataModel.inetAddress.length === 0){
            this.errorMessages.isIpAddressEmpty = true;
        }else{
            this.errorMessages.isIpAddressEmpty = false;
        }
    }

    private getLocalizeDOT() : void {
        this.DOT = this.sharedService.getLocalizeDot();
    }

    private getContainerSelection(dropdownItem) : void {
        this.dataModel.container = dropdownItem.innerText;
        this.dataModel.containerId = dropdownItem.value;
        this.errorMessages.isContainerEmpty = dropdownItem.value === 'null' ? true : Number(dropdownItem.value) < 1;
        this.onRequiredFieldChange();
    }

    private getSiteSelection(dropdownItem) : void {
        if (dropdownItem.value === "-1") {
            this.dataModel.site = null;
            this.dataModel.siteId = null;
        }
        else {
            this.dataModel.site = dropdownItem.innerText;
            this.dataModel.siteId = dropdownItem.value;
        }
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //method :: sets formdata
    private setFormData(formData:any):void{
        if(formData) {
            this.currentOperation = formData.operation;
            this.validateOperation(this.currentOperation);
            if(formData.label != '' && formData.container != null) this.isAddbtnDisabled = false;
            formData.container =
            this.setHcuModelData(formData.HcuViewModel);
        }
    }

    //Method to set operation type
    private validateOperation(operation: string): void{
        if(operation === EDIT_OPERATION){
            this.isEditOperation = true;
            this.isAddOperation = false;
            this.isReadOnly = true;
            this.isEditDisabled = false;
        }else if(operation === ADD_OPERATION){
            this.isAddOperation = true;
            this.isEditOperation = false;
        }
    }

    //method :: after click opens editable content.
    private toggleEdit():void {
        this.isEditDisabled = true;
        this.isDeleteHidden = true;
        this.isAddbtnDisabled = false;
    }

    //method :: closes slider.
    public btnClose_click(){
        this.isCloseRightSlider = true;
        this.hcuSharedService.getHCUClearSliderSub().next(true);
    }

    //method :: verifies hcu.
    private verifyHCU():void {
        this.hcuTabDataService.hcuVerify(this.dataModel.inetAddress).subscribe(this.onVerifySuccess.bind(this),this.onError.bind(this))
    }

    //method :: sets response to data model.
    private onVerifySuccess(response:any):void {
        this.isHCUVerified = true;
        this.isReadOnly = true;
        this.isAddHidden = false;
        if(response.label != '' && response.defaultContainerName != null) this.isAddbtnDisabled = false;
        this.setHcuModelData(response);
        this.logger.debug(this.tag, "onVerifySuccess(): verify HCU success data=", response);
    }

    //method :: submits form on submit button click.
    public onSubmit():void {
        this.parseValues();
        this.hcuTabDataService.addHCU(this.dataModel).subscribe(this.onSubmitSuccess.bind(this),this.onError.bind(this));
    }

    //method :: clears form on success.
    private onSubmitSuccess(data:any):void {
        this.clearForm(this.HCU_ADD_SUCCESS);
        this.logger.debug(this.tag, "onSubmitSuccess(): Add HCU success data=", data);
    }

    //method :: puts edited hcu data to server.
    private saveHCU():void {
        this.parseValues();
        this.hcuTabDataService.editHCU(this.dataModel).subscribe(this.onSaveHCUSuccess.bind(this),this.onError.bind(this));
    }

    private parseValues(): void{
        this.statusData = this.dataModel.status;
        delete this.dataModel.status;

        let tpc: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.dataModel.testPointComp, this.DOT);
        this.dataModel.testPointComp = parseFloat(tpc);

        let attenuation: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.dataModel.attenuation, this.DOT);
        this.dataModel.attenuation = parseFloat(attenuation);
    }

    //methods :: clears form on save success
    private onSaveHCUSuccess(data:any):void{
        this.clearForm(this.HCU_EDIT_SUCCESS);
        this.logger.debug(this.tag, "onSaveHCUSuccess(): Save HCU success data=", data);
    }

    //methods :: shows conformation popup for delete
    private deleteHCU():void {
        this.sweetAlert.showConformationAlert(ALERT_INFO ,this.HCU_DELETE_CONFORMATION_TITLE ,this.HCU_DELETE_CONFORMATION_MESSAGE ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.hcuTabDataService.deleteHCU(this.dataModel.elementId).subscribe(this.onDeleteSuccess.bind(this) ,this.onError.bind(this))
                }
            }
        );
    }

    //method :: clears form on delete success and closes slider.
    private onDeleteSuccess(data:any):void {
        this.clearForm(this.HCU_DELETE_SUCCESS);
        this.logger.debug(this.tag, "onDeleteSuccess(): Delete HCU success data=", data);
    }

    //method :: clears form, closes slider and refeshes hcu list.
    private clearForm(successMsg):void {
        this.sweetAlert.showAlert(ALERT_SUCCESS, successMsg,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
        (isConfirm)=>{
            this.btnClose_click();
            this.hcuSharedService.getHcuListRefreshSub().next();
        });
    }

    //method :: sets hcumodel data
    private setHcuModelData(hcuModel):void {
        let localizationService = this.localeDataService.getLocalizationService();
        if(hcuModel) {
            this.dataModel.elementId = hcuModel.elementId;
            this.dataModel.label = hcuModel.label;
            this.dataModel.status = hcuModel.status ? (hcuModel.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()) : localizationService.instant(hcuModel.status.toUpperCase()) : hcuModel.status;
            this.dataModel.location = hcuModel.location;
            this.dataModel.notes = hcuModel.notes;
            this.dataModel.inetAddress = hcuModel.inetAddress;
            this.dataModel.serialNumber = hcuModel.serialNumber;
            this.dataModel.type = hcuModel.type;
            this.dataModel.sbcModel = hcuModel.sbcModel;
            this.dataModel.ramSize = hcuModel.ramSize;
            this.dataModel.firmwareRev = hcuModel.firmwareRev;
            this.dataModel.firmwarePackageRev = hcuModel.firmwarePackageRev;
            this.dataModel.setTestPointCompForAllPorts = hcuModel.setTestPointCompForAllPorts;
            this.dataModel.testPointComp = hcuModel.testPointComp;
            this.dataModel.setAttenuationForAllPorts = hcuModel.setAttenuationForAllPorts;
            this.dataModel.attenuation = hcuModel.attenuation;
            this.dataModel.olVersion = hcuModel.olVersion;
            this.dataModel.alarmsEnabled = hcuModel.alarmsEnabled;
            this.dataModel.thresholdsEnabled = hcuModel.thresholdsEnabled;
            // this.dataModel.snmpEnabled = hcuModel.snmpEnabled;
            this.dataModel.created = hcuModel.created;
            this.dataModel.modified = hcuModel.modified;
            this.dataModel.container = hcuModel.defaultContainerName;
            this.dataModel.containerId = hcuModel.containerId;
            this.dataModel.site = hcuModel.siteName;
            this.dataModel.siteId = hcuModel.siteId;
            this.dataModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(this.dataModel.attenuation, this.DOT);
            this.dataModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(this.dataModel.testPointComp, this.DOT);
            this.dataModel.mactrakFailThreshold = hcuModel.mactrakFailThreshold;
            this.dataModel.mactrakMarginalThreshold = hcuModel.mactrakMarginalThreshold;
        }
    }

    //method :: enable/disable connect button on change of input event.
    public updateHostName(event):void {
        if(event != "") {
            this.isConnectBtnDisabled = false;
        }else {
            this.isConnectBtnDisabled = true;
        }
    }

    //method :: on model change of label.
    private onRequiredFieldChange():void {
        this.isAddbtnDisabled = !this.dataModel.label || !this.dataModel.container || this.errorMessages.isContainerEmpty;
    }

    //method :: listens in change of form data.
    private  formChangeSubListener() {
        this.hcuSharedService.getHcuFormChangeSub().subscribe((data)=>{
            this.setFormData(data);
        })
    }

    //method :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.HCU_ADD_SUCCESS = localizationService.instant('HCU_ADD_SUCCESS');
        this.HCU_EDIT_SUCCESS = localizationService.instant('HCU_EDIT_SUCCESS');
        this.HCU_DELETE_SUCCESS = localizationService.instant('HCU_DELETE_SUCCESS');
        this.HCU_DELETE_CONFORMATION_TITLE = localizationService.instant('HCU_DELETE_CONFORMATION_TITLE');
        this.HCU_DELETE_CONFORMATION_MESSAGE = localizationService.instant('HCU_DELETE_CONFORMATION_MESSAGE');
    }

    //method :: checks test point min/max limit
    public processTPC(): void{
        this.processTpcValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.dataModel.testPointComp, this.DOT);
        //Process value for MIN MAX
        let tpc: string = this.sharedService.processTpcMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.dataModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(tpc, this.DOT);
    }

    public processTpcValue(): void{
        this.dataModel.testPointComp = this.sharedService.processNumber(this.dataModel.testPointComp, this.DOT);
    }

    //@method :: Restrict Attenuation in range
    public processAttenuation(): void{
        this.processAttenuationValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.dataModel.attenuation, this.DOT);
        //Process value for MIN MAX
        let attenuation: string = this.sharedService.processAttenuationMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.dataModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(attenuation, this.DOT);
    }

    public processAttenuationValue(): void{
        this.dataModel.attenuation = this.sharedService.processNumber(this.dataModel.attenuation, this.DOT);
    }

    //method called on error of import modem api.
    private onError(error:any):void {
        this.dataModel ? this.dataModel.status = this.statusData :'';
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //method :: to check hcu permission
    private checkHCUPermission():any{
        return this.sharedService.checkPermissions(NAV_LINK_HCU);
    }
}
