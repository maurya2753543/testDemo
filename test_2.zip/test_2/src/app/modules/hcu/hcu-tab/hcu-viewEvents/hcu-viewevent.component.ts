import {Component, Input} from '@angular/core';

import {Grid} from "../../../../shared/ag-grid.options";
import {HCUTabDataService} from '../hcutab.data.service';
import {ViewEventsColumnDefinitionService} from '../../../shared/common-components/listView/viewEvents.column-definition.service';
import { Logger } from "./../../../../utilities/logger";
import {ShowAlert} from "./../../../../utilities/showAlert";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {HCUSharedService} from '../../hcu.shared.service';
import {SharedService} from "../../../../shared/shared.service";
import {HEADEND_CONTROL_UNIT} from "../../../../constant/app.constants";

@Component({
    selector:'hcu-viewevent',
     templateUrl:'../../../shared/common-components/listView/listView.component.html'
})

export class HCUViewEvent {

    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata=[];
    @Input('childData') childData: any;
    private tabType = "HSU_VIEW_EVENT";
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    private tag:string = "HCU View Event Component";
    private TABLE_LIST_EXPORT_ALL:string;
    private CLOSE_SLIDER:string;
    public gridTabType:string = "HCUEventExport";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private HCU_VIEW_EVENTS_HEADER:string = "";
    private eventList: any[];
    public styleForHeaderBtns:string = 'max-width:100%'
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    constructor(private hcuTabDataService:HCUTabDataService,
                private localeDataService: LocaleDataService,
                private ViewEventsColumnDefinitionService:ViewEventsColumnDefinitionService,
                private logger: Logger,private showAlert: ShowAlert,
                private hcuSharedService:HCUSharedService,
                private sharedService:SharedService){
        this.translateLocaleString();
        this.setEventButtonKeys();
    }

    ngOnInit(){
        this.isCloseRightSlider = false;
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    private translateLocaleString(){
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.HCU_VIEW_EVENTS_HEADER = localizationService.instant('HCU_VIEW_EVENTS_HEADER');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.headerTxt = this.HCU_VIEW_EVENTS_HEADER;
        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'HSU_VIEW_EVENT', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'HSU_VIEW_EVENT', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }

    //sets slider label.
    private setHeaderLabel(childName?):void {
        this.headerTxt = this.HCU_VIEW_EVENTS_HEADER;
        this.headerTxt =childName ?  this.headerTxt + ' - ' + childName : this.headerTxt;
    }
    
    private btnClose_click(){
        this.isCloseRightSlider = true;
    }

    //function :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    // function :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.ViewEventsColumnDefinitionService.getColumnDef());
        this.listViewOptions["getRowHeight"] = (params) => {
            return 18 * (Math.floor(params.data.eventType.length / 45) + 2);
        }
        this.childData && this.getViewEventData();
    }

    private getViewEventData():void {
        this.setHeaderLabel(this.childData['0'].label);
        this.hcuTabDataService.getEventListData(this.childData["0"].elementId, HEADEND_CONTROL_UNIT).subscribe(this.getThresholdsList.bind(this),this.onError.bind(this));
    }

    private getThresholdsList(eventList: any): void{
        this.eventList = eventList;
        this.hcuTabDataService.getThresholdsName().subscribe(this.processEventList.bind(this),this.onError.bind(this));
    }

    private processEventList(thresholds: any): void{
        this.onViewEventSuccess(this.hcuSharedService.processEventList(this.eventList, thresholds));
    }

    private onViewEventSuccess(data:any):void {
        this.rowdata = data;
        this.totalCount = data.length;
        this.setShowAllLabel(data.length, this.totalCount);
        this.logger.debug(this.tag, "onViewEventSuccess(): View Events success response=", data);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    public notifyGridReadyViewEvents(params:any){
        this.setGridColDefinition();
    }

    public notifyCloseSlider(params:any){
        this.isCloseRightSlider = true;
        this.hcuSharedService.getHCUClearSliderSub().next(true);
    }

    //refresh
    public notifyRefreshGrid(params:any){
        this.getViewEventData();
    }
    
    //function called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }
}