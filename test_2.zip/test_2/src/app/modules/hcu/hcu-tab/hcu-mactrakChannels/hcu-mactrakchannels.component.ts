import {Component, Input} from '@angular/core';

import {Grid} from "../../../../shared/ag-grid.options";
import {HCUTabDataService} from '../hcutab.data.service';
import {MACTrakChannelsColumnDefinitionService} from '../../../shared/common-components/listView/mactrakChannels.column-definition.service';
import { Logger } from "./../../../../utilities/logger";
import {ShowAlert} from "./../../../../utilities/showAlert";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {HCUSharedService} from "../../hcu.shared.service";
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'port-macktrakChannel',
     templateUrl:'../../../shared/common-components/listView/listView.component.html'
})

export class HCUMactrakChannel {
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata=[];
    private tabType = "HSM_MACKTRACK_CHANNEL";
    public eventKeys: Object[] ;
    public buttonKeys: Object[] ;
    private tag:string = "MACTrak Channels Component";
    private TABLE_LIST_EXPORT_ALL:string = "";
    private CLOSE_SLIDER:string = "";
    public gridTabType:string = "HCUMactrackChannelExport";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private HCU_MACTRAK_CHANNELS_HEADER:string = "";
    public styleForHeaderBtns:string = 'max-width:100%'   // Bug fix XPTUI 621

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;

    constructor(private hcuTabDataService:HCUTabDataService,
                private mactrakChannelsColumnDefinitionService:MACTrakChannelsColumnDefinitionService,
                private logger: Logger,private showAlert: ShowAlert,
                private localeDataService:LocaleDataService,
                private hcuSharedService:HCUSharedService,
                private sharedService:SharedService){
                    this.translateLocaleString();
                    this.setEventButtonKeys();
        
    }

    ngOnInit(){
        this.isCloseRightSlider = false;
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }


    //method :: translate local strings accrding to lang.
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.HCU_MACTRAK_CHANNELS_HEADER = localizationService.instant('HCU_MACTRAK_CHANNELS_HEADER');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //Method to set button keys
    private setEventButtonKeys():void {
        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'HSM_MACKTRACK_CHANNEL', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'HSM_MACKTRACK_CHANNEL', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }
    
    //method :: closes slider on close click.
    private btnClose_click():void{
        this.isCloseRightSlider = true;
    }

    //method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    // method :: sets grid columns.
    private setGridColDefinition():void {
      
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.mactrakChannelsColumnDefinitionService.getColumnDef());
        this.childData && this.getMACTrackChannelsData();
        this.listViewOptions["getRowHeight"] = (params) => {
            let level;
            let thresholdLength = 35;
            let rowHeight = 22;
            let hcuLength;
            if(params.data.hcu && params.data.hcu.length){
                hcuLength = params.data.hcu.length;
                if(hcuLength < thresholdLength) return rowHeight;
                else {
                    level = Math.floor(hcuLength / thresholdLength);
                    return rowHeight * level + 1;
                }
            }
            else{
                return rowHeight;
            }
        }
    }

    //sets slider label.
    private setHeaderLabel(childName?):void {
        this.headerTxt = this.HCU_MACTRAK_CHANNELS_HEADER;
        this.headerTxt =childName ?  this.headerTxt + ' - ' + childName : this.headerTxt;
    }

    //method :: gets mactrak channels data for hcuId.
    private getMACTrackChannelsData():void {
        this.setHeaderLabel(this.childData.label);
        this.hcuTabDataService.viewMACTrakChannels(this.childData.elementId).subscribe(this.onMactrakChannelsSuccess.bind(this) ,this.onError.bind(this));
    }

    //method :: sets rowdata to on mactrak channels success response.
    private onMactrakChannelsSuccess(data:any):void {
        this.rowdata = data;
        this.totalCount = this.rowdata.length;
        this.setShowAllLabel(this.rowdata.length, this.totalCount);
        this.logger.debug(this.tag, "onMactrakChannelsSuccess(): MACTrak channels success data=", data);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //method:: notifies grid ready.
    public notifyGridReadyViewEvents(params:any):void{
        this.setGridColDefinition();
    }

    //method :: closes slider.
    public notifyCloseSlider(params:any):void{
        this.isCloseRightSlider = true;
        this.hcuSharedService.getHCUClearSliderSub().next(true);
    }

    //refrsh list
    public notifyRefreshGrid(params:any):void {
        this.getMACTrackChannelsData();
    }

    //method called on error of import modem api.
    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
        this.logger.debug(this.tag, "onError(): error data=", error);
    }
    
}