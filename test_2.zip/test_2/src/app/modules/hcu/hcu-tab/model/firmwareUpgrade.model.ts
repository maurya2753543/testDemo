/**
 * Created by narayan.reddy on 20-07-2017.
 */
export interface FirmwareUpgradeModel {
    packageVersion:string;
    buildDate: string;
    releaseNotes: string;
    downloadDate: string;
    downloading: boolean;
    fileCorrupted: boolean
}
