export class HcuViewModel {

    public elementId:number;
    public label:string;
    public status:string;
    public location:string;
    public notes:string;
    public inetAddress:string;
    public serialNumber:string;
    public type:string;
    public sbcModel:string;
    public ramSize:number;
    public firmwareRev:string;
    public firmwarePackageRev:string;
    public setTestPointCompForAllPorts:boolean;
    public testPointComp: number|string;
    public attenuation: number|string;
    public setAttenuationForAllPorts:boolean;
    public olVersion:number;
    public container:string;
    public containerId: any;
    public site:string;
    public siteId: any;
    
    public alarmsEnabled:boolean = null;
    public thresholdsEnabled:boolean = null ;
    public snmpEnabled:boolean = null ;
    public created:string = null ;
    public modified:string = null;
    public mactrakFailThreshold: number;
    public mactrakMarginalThreshold: number;

    constructor(hcuDataObj:any){
        if(hcuDataObj) {
            this.elementId  = hcuDataObj.elementId ? hcuDataObj.elementId: null;
            this.label  = hcuDataObj.label ? hcuDataObj.label: null ;
            this.location = hcuDataObj.location ? hcuDataObj.location: null;
            this.notes  = hcuDataObj.notes ? hcuDataObj.notes: null;
            this.inetAddress  = hcuDataObj.inetAddress ? hcuDataObj.inetAddress: null;
            this.serialNumber  = hcuDataObj.serialNumber ? hcuDataObj.serialNumber: null;
            this.type  = hcuDataObj.type ? hcuDataObj.type: null;
            this.sbcModel  = hcuDataObj.sbcModel ? hcuDataObj.sbcModel: null;
            this.ramSize  = hcuDataObj.ramSize ? hcuDataObj.ramSize: null;
            this.firmwareRev  = hcuDataObj.firmwareRev ? hcuDataObj.firmwareRev: null;
            this.firmwarePackageRev  = hcuDataObj.firmwarePackageRev ? hcuDataObj.firmwarePackageRev: null;
            this.setTestPointCompForAllPorts  = hcuDataObj.setTestPointCompForAllPorts ? hcuDataObj.setTestPointCompForAllPorts: null;
            this.testPointComp  = hcuDataObj.testPointComp ? hcuDataObj.testPointComp: null;
            this.setAttenuationForAllPorts  = hcuDataObj.setAttenuationForAllPorts ? hcuDataObj.setAttenuationForAllPorts : null;
            this.attenuation  = hcuDataObj.attenuation ? hcuDataObj.attenuation: null;
            this.olVersion  = hcuDataObj.olVersion ? hcuDataObj.olVersion: null; 
            this.status = hcuDataObj.status ? hcuDataObj.status: null;
            this.alarmsEnabled  = hcuDataObj.alarmsEnabled || this.alarmsEnabled;
            this.thresholdsEnabled  = hcuDataObj.thresholdsEnabled || this.thresholdsEnabled;
            this.snmpEnabled  = hcuDataObj.snmpEnabled || this.snmpEnabled;
            this.created  = hcuDataObj.created || this.created;
            this.modified  = hcuDataObj.modified || this.modified;
            this.container = hcuDataObj.container || this.container;
            this.containerId = hcuDataObj.containerId || this.containerId;
            this.site = hcuDataObj.site || this.site;
            this.siteId = hcuDataObj.siteId || this.siteId;
        }

    }

}