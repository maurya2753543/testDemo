import {ONLINE} from "../../hcu.constants";

export class HCUTabModel extends Array {
    public isShowAll:boolean;
    public totalCount:number;
    constructor(jsonData, localizationService:any){
        super();

        if(jsonData.hcuList){
            for(let i=0; i<jsonData.hcuList.length; i++) {
                let hcuData: HCUTabListItems = new HCUTabListItems(jsonData.hcuList[i], localizationService);
                this.push(hcuData); 
            }
            this.totalCount = jsonData.totalCount;
            this.isShowAll = (jsonData.hcuList.length == jsonData.totalCount) ? false : true;
        }
    }
}

export class HCUTabListItems {
    public elementId:number;
    public firmwarePackageRev:string;
    public firmwareUpgradeAvailable:any;
    public firmwareVersion:string;
    public hsmPresent:boolean;
    public inetAddress:string;
    public label:string;
    public location:string; 
    public numberOfRpms:number;
    public ramSize:number;
    public sbcModel:string;
    public serialNumber:string;
    public status:string;
    public type:string;
    public container:string;
    public site:string;
    constructor(HCUList, localizationService) {
        if (HCUList) {
            this.elementId = HCUList.elementId;
            this.firmwarePackageRev = HCUList.firmwarePackageRev;
            this.firmwareUpgradeAvailable = (HCUList.firmwareUpgradeAvailable == false)? localizationService.instant('NO'): localizationService.instant('YES');
            this.firmwareVersion = HCUList.firmwareVersion;
            this.hsmPresent = HCUList.hsmPresent;
            this.inetAddress = HCUList.inetAddress;
            this.label = HCUList.label;
            this.location = HCUList.location;
            this.numberOfRpms = HCUList.numberOfRpms;
            this.ramSize = HCUList.ramSize;
            this.sbcModel = HCUList.sbcModel;
            this.serialNumber = HCUList.serialNumber;
            this.container = HCUList.defaultContainerName;
            this.site = HCUList.siteName;
            if(HCUList.status){
                this.status = (HCUList.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()) : localizationService.instant(HCUList.status.toUpperCase());
            }
            this.type = HCUList.type;
        }
    }
}
