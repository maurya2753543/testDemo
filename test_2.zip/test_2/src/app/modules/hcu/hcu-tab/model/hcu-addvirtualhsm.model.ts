export class VirtulaHSMModel {

    public label: string;
    public location: string;
    public notes: string;
    public physicalHsmHcuId: number; // hcuId physical
    public vhsmParentHcuId: number; // clicked hcu from list.

    constructor(modelObj) {
        if (modelObj) {
            this.label = modelObj.label ? modelObj.label : "";
            this.location = modelObj.location ? modelObj.location : "";
            this.notes = modelObj.notes ? modelObj.notes : "";
            this.physicalHsmHcuId = modelObj.physicalHsmHcuId ? modelObj.physicalHsmHcuId : null;
            this.vhsmParentHcuId = modelObj.vhsmParentHcuId ? modelObj.vhsmParentHcuId : null;
        }

    }

}



