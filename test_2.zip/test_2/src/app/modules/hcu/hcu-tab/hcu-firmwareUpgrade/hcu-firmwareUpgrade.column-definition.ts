/**
 * Created by narayan.reddy on 18-07-2017.
 */

import {Injectable} from '@angular/core';

import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SharedService} from "../../../../shared/shared.service";
import {TimeFilter} from "../../../../shared/time.filter";
import {gridCustomComparator} from "../../../../shared/ag-Grid.comparator";

@Injectable()

export class FirmwareUpgradeColumnDefinationService {

    //Header fields with field name and display name.
    private _HEADER_FIELDS: any = {
        version : {field: "packageVersion", name: "VERSION"},
        buildDate : {field: "buildDate", name: "BUILDDATE"},
        releaseNotes : {field: "releaseNotes", name: "RELEASENOTES"},
        label : {field: "label", name: "HCU_TAB_HEADER_LABEL"},
        type : {field: "type", name: "HCU_TAB_HEADER_TYPE"},
        inetAddress : {field: "inetAddress", name: "HCU_TAB_HEADER_IP_ADDRESS"},
        serialNumber : {field: "serialNumber", name: "HCU_TAB_HEADER_SERIAL_NUMBER"},
        firmwarePackageRev : {field: "firmwarePackageRev", name: "HCU_TAB_HEADER_FIRMWARE_PACKAGE"},
        firmwareUpgradeAvailable : {field: "firmwareUpgradeAvailable", name: "HCU_TAB_HEADER_FIRMWARE_UPGRADE_AVAILABLE"},
        errorCode : {field: "errorCode", name: "HCU_ERROR"},

    };

    constructor(private localeDataService:LocaleDataService,
                private sharedService : SharedService){
        this.translateLocaleStr();
    }


    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();

        this._HEADER_FIELDS.version.name = localizationService.instant('HCU_VERSION');
        this._HEADER_FIELDS.buildDate.name = localizationService.instant('HCU_BUILDDATE');
        this._HEADER_FIELDS.releaseNotes.name = localizationService.instant('HCU_RELEASENOTES');
        this._HEADER_FIELDS.label.name = localizationService.instant('HCU_TAB_HEADER_LABEL');
        this._HEADER_FIELDS.type.name = localizationService.instant('HCU_TAB_HEADER_TYPE');
        this._HEADER_FIELDS.inetAddress.name = localizationService.instant('HCU_TAB_HEADER_IP_ADDRESS');
        this._HEADER_FIELDS.serialNumber.name = localizationService.instant('HCU_TAB_HEADER_SERIAL_NUMBER');
        this._HEADER_FIELDS.firmwarePackageRev.name = localizationService.instant('HCU_TAB_HEADER_FIRMWARE_PACKAGE');
        this._HEADER_FIELDS.firmwareUpgradeAvailable.name = localizationService.instant('HCU_TAB_HEADER_FIRMWARE_UPGRADE_AVAILABLE');
        this._HEADER_FIELDS.errorCode.name = localizationService.instant('ERROR');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        //TODO:: handle status ok to online.
        let columnDef:any[] = [
            {
                headerName: '',
                width: 21,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: false,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                cellStyle: (params:any) => {
                    let backgroundColor:any;
                    if (params.data.fileCorrupted) {
                        backgroundColor = {'background-color': 'red'};
                    }
                    return backgroundColor;
                }
            },
            {
                headerName: this._HEADER_FIELDS.version.name,
                headerTooltip: this._HEADER_FIELDS.version.name,
                field: this._HEADER_FIELDS.version.field,
                minWidth: 100,
                floatingFilterComponentParams: {suppressFilterButton: true},
                //sort: 'desc',
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                sortingOrder: ['desc', 'asc', null],
                filterParams: {newRowsAction: 'keep'},
                cellStyle: (params:any) => {
                    let backgroundColor:any;
                    if (params.data.fileCorrupted) {
                        backgroundColor = {'background-color': 'red'};
                    }
                    return backgroundColor;
                }
            },
            {
                headerName: this._HEADER_FIELDS.buildDate.name,
                headerTooltip: this._HEADER_FIELDS.buildDate.name,
                field: this._HEADER_FIELDS.buildDate.field,
                minWidth: 200,
                floatingFilterComponentParams: {suppressFilterButton: true},
                comparator: this.sharedService.dateComparator,
                filterParams: {newRowsAction: 'keep'},
                filter: TimeFilter.ParentFilter,
                floatingFilterComponent: TimeFilter.ChildFloatingFilter,
                cellRenderer: (params:any)=> {
                    let LocalizeDateFormat = this.sharedService.getLocaleDate(params.value);
                    return LocalizeDateFormat;
                },
                cellStyle: (params:any) => {
                    let backgroundColor:any;
                    if (params.data.fileCorrupted) {
                        backgroundColor = {'background-color': 'red'};
                    }
                    return backgroundColor;
                }
            },
            {
                headerName: this._HEADER_FIELDS.releaseNotes.name,
                headerTooltip: this._HEADER_FIELDS.releaseNotes.name,
                field: this._HEADER_FIELDS.releaseNotes.field,
                minWidth: 500,
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponentParams: {suppressFilterButton: true},
                filterParams: {newRowsAction: 'keep'},
                cellStyle: (params:any) => {
                    let backgroundColor:any;
                    if (params.data.fileCorrupted) {
                        backgroundColor = {'background-color': 'red'};
                    }
                    return backgroundColor;
                }
            },

        ];
        return columnDef;
    }


    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getHCUTABColumnDef(): any[] {
        //TODO:: handle status ok to online.
        let columnDef: any[] = [
            {
                headerName: this._HEADER_FIELDS.label.name,headerTooltip: this._HEADER_FIELDS.label.name, field: this._HEADER_FIELDS.label.field,
                minWidth: 200, filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}, sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.type.name,headerTooltip: this._HEADER_FIELDS.type.name, field: this._HEADER_FIELDS.type.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.type.name, 90),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.inetAddress.name,headerTooltip: this._HEADER_FIELDS.inetAddress.name, field: this._HEADER_FIELDS.inetAddress.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.inetAddress.name, 50),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.serialNumber.name,headerTooltip: this._HEADER_FIELDS.serialNumber.name, field: this._HEADER_FIELDS.serialNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serialNumber.name, 50),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwarePackageRev.name,headerTooltip: this._HEADER_FIELDS.firmwarePackageRev.name, field: this._HEADER_FIELDS.firmwarePackageRev.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwarePackageRev.name, 50),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwareUpgradeAvailable.name,headerTooltip: this._HEADER_FIELDS.firmwareUpgradeAvailable.name, field: this._HEADER_FIELDS.firmwareUpgradeAvailable.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareUpgradeAvailable.name, 50),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ];
        return columnDef;
    }

    /*
     *@name getHCUTABColumnDefError
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getHCUTABColumnDefError(): any[] {
        //TODO:: handle status ok to online.
        let columnDef: any[] = [
            {
                headerName: this._HEADER_FIELDS.errorCode.name,headerTooltip: this._HEADER_FIELDS.errorCode.name, field: this._HEADER_FIELDS.errorCode.field,
                minWidth: 500,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'},
                cellStyle : function(params) {
                    return {
                        'color': 'red'
                    };
                }
            },
            {
                headerName: this._HEADER_FIELDS.label.name,headerTooltip: this._HEADER_FIELDS.label.name, field: this._HEADER_FIELDS.label.field,
                minWidth: 200, filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}, sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.type.name,headerTooltip: this._HEADER_FIELDS.type.name, field: this._HEADER_FIELDS.type.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.type.name, 90),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.inetAddress.name,headerTooltip: this._HEADER_FIELDS.inetAddress.name, field: this._HEADER_FIELDS.inetAddress.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.inetAddress.name, 90),filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.serialNumber.name,headerTooltip: this._HEADER_FIELDS.serialNumber.name, field: this._HEADER_FIELDS.serialNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareUpgradeAvailable.name, 90),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwarePackageRev.name,headerTooltip: this._HEADER_FIELDS.firmwarePackageRev.name, field: this._HEADER_FIELDS.firmwarePackageRev.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwarePackageRev.name, 90),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwareUpgradeAvailable.name,headerTooltip: this._HEADER_FIELDS.firmwareUpgradeAvailable.name, field: this._HEADER_FIELDS.firmwareUpgradeAvailable.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareUpgradeAvailable.name, 90),
                filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            }

        ];
        return columnDef;
    }
}