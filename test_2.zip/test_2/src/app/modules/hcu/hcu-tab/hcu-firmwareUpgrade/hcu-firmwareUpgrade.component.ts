/**
 * Created by narayan.reddy on 18-07-2017.
 */
import {Component, Input} from '@angular/core';

import {Logger} from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import { Grid } from "../../../../shared/ag-grid.options";
import {AgGridConfigurationService} from "../../../../shared/agGrid.configuration.service"
import {FirmwareUpgradeColumnDefinationService} from "./hcu-firmwareUpgrade.column-definition";
import { HCUTabDataService } from '../hcutab.data.service';
import {FirmwareUpgradeModel} from "../model/firmwareUpgrade.model";
import {HCUSharedService} from "../../hcu.shared.service";
import {ControlMessagesService} from '../../../../shared/control.messages.service';

import {
    ALERT_INFO, MAX_STRING_LIMIT,
} from "../../../../constant/app.constants";
import {
    CommonStrings
} from "../../../../constant/common.strings";
import {SharedService} from "../../../../shared/shared.service";

let vm:any;

@Component({
    selector:'hcu-firmwareUpgrade',
    templateUrl:'hcu-firmwareUpgrade.component.html'
})

export class FirmwareUpgradeHCU {
    firmwareUpgradeGridOption: Grid = new Grid();
    HCUGridOption: Grid = new Grid();
    HCUGridOptionError: Grid = new Grid();
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean = false;
    public latestFirPackInterval:any;
    public selectedData:any = [];
    public headerTxt:string;
    public corruptedStatus:boolean = false;
    public rowData:any;
    private errorRowData:Array<FirmwareUpgradeModel>;
    public errorRowDataList:any;
    public rowDataHCU:any;
    private tabType:string = "FIRMWARE_UPGRADE_HCU";
    public latestDownloadingDate:string;
    public latestPackageVersion:string;
    private callLatestFirmwareUpgrade:boolean;
    public DELETE_PACKAGE :string;
    public CHECK_NEW_FIRMWARE_RELEASE :string;
    public SELECTED_HCU_TXT:string;
    public UPGRADE_SUBMIT_TEXT:string;
    private UPGRADE_CONFIRMATION_MESSAGE_FALSE:string;
    private UPGRADE_CONFIRMATION_MESSAGE_TRUE:string;
    private SELECTED_HCU_SUCCESS_UPGRADE:string;
    private SELECTED_HCU_FAILS_UPGRADE:string;
    private SELECT_ANY_ONE_FIRMWARE:string;
    private ALERT_DELETE_PACKAGE_TEXT:string;
    private HCU_ENTER_FIRMWARE_CONFIRM_TXT:string;
    private HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_PRE:string;
    private HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_POST:string;
    private gridHeaderTxtColor:string;
    public deleteBtnStatus:boolean;
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    private latestFirmwareData:any;
    private totalCount1:number = 0;
    public showAllLabel1:string = '';
    public showAllLabelMob1:string = '';

    private totalCount2:number = 0;
    public checkForNewFirm:boolean;

    constructor(private hcuTabDataService:HCUTabDataService,
                private showAlert:ShowAlert,
                private sweetAlert:SweetAlert,
                private hcuSharedService:HCUSharedService,
                private agGridConfigurationService:AgGridConfigurationService,
                private localeDataService:LocaleDataService,
                private controlMessagesService:ControlMessagesService ,
                private columnDefinationService:FirmwareUpgradeColumnDefinationService,
                private sharedService:SharedService) {
        this.translateLocaleString();
        this.isCloseRightSlider = false;
        vm = this;
    }


    ngOnInit(){
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }


    public btnClose_click():void{
        this.isCloseRightSlider = true;
        this.checkForNewFirm = false;
        clearInterval(this.latestFirPackInterval);
        this.hcuSharedService.getHcuListRefreshSub().next();
        this.hcuSharedService.getHCUClearSliderSub().next(true);
    }

    //method:: conformation popup before delete.
    private DeleteConfirmation(packageVersion):void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.ALERT_DELETE_PACKAGE_TEXT ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                        this.deleteFirmwarePackage(packageVersion);
                }
            }
        );
    }

    //method :: delets firmware package
    private deleteFirmwarePackage(packageVersion):void{
        this.hcuTabDataService.deleteFirmwarePackage(packageVersion).subscribe(
            (res:any) => {
                this.deleteBtnStatus = false;
                if(res){
                    this.showAlert.showInfoAlert(this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_PRE + packageVersion + this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_POST);
                    if(this.corruptedStatus){
                        this.corruptedStatus = false;
                    }
                    this.getFirmwareData();
                }
            }, (error)=>{
                this.deleteBtnStatus = false;
                this.onError(error)
            });
    }

    private showConfirmation(packageVersion): void{
        /*
          Timeout require to show second sweet alert after first (type confirmation) at a single
          point of time.
          If we try to show second sweet alert in the middle of removal process
          of first sweet alert (type confirmation),then it will not show second sweet alert,
          as removal process will remove second sweet alert also.
          Sweet alert does not provides any event notifying sweet alert is completely removed.
          This issue can be reproducible only on fast connection.
      */
        setTimeout(() => {
            this.showAlert.showInfoAlert(this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_PRE + packageVersion + this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_POST);
        }, 80);
    }

    //method :: delets pkg
    public deletePackage():void{
        this.deleteBtnStatus = true;
        var data = this.selectedData;
        if(data.length > 0 && data.length === 1){
            this.DeleteConfirmation(data[0].packageVersion);
        } else {
            this.showAlert.showInfoAlert(this.HCU_ENTER_FIRMWARE_CONFIRM_TXT);
        }
    }



    //function :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.headerTxt = localizationService.instant("HCU_SELECT_FIRMWARE_PACKAGE");
        this.DELETE_PACKAGE = localizationService.instant("HCU_DELETE_PACKAGE");
        this.CHECK_NEW_FIRMWARE_RELEASE = localizationService.instant("HCU_CHECK_NEW_FIRMWARE_RELEASE");
        this.SELECTED_HCU_TXT = localizationService.instant("HCU_SELECTED_HCU_TXT");
        this.UPGRADE_SUBMIT_TEXT = localizationService.instant("HCU_UPGRADE_SUBMIT_TEXT");
        this.UPGRADE_CONFIRMATION_MESSAGE_FALSE = localizationService.instant("HCU_UPGRADE_CONFIRMATION_MESSAGE_FALSE");
        this.UPGRADE_CONFIRMATION_MESSAGE_TRUE = localizationService.instant("HCU_UPGRADE_CONFIRMATION_MESSAGE_TRUE");
        this.SELECTED_HCU_SUCCESS_UPGRADE =  localizationService.instant("HCU_SELECTED_HCU_SUCCESS_UPGRADE");
        this.SELECTED_HCU_FAILS_UPGRADE =  localizationService.instant("HCU_SELECTED_HCU_FAILS_UPGRADE");
        this.SELECT_ANY_ONE_FIRMWARE =  localizationService.instant("HCU_SELECT_ANY_ONE_FIRMWARE");
        this.ALERT_DELETE_PACKAGE_TEXT = localizationService.instant("ALERT_DELETE_PACKAGE_TEXT");
        this.HCU_ENTER_FIRMWARE_CONFIRM_TXT = localizationService.instant("HCU_ENTER_FIRMWARE_CONFIRM_TXT");
        this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_PRE = localizationService.instant("HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_PRE");
        this.HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_POST = localizationService.instant("HCU_ENTER_FIRMWARE_DELETE_CONFIRM_TXT_POST");
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //refresh
    private notifyRefreshGrid():void{

    }

    //methods sets column definition on grid ready.
    public notifyHCUGridReady(params:any):void{
        this.HCUGridOption.api.showLoadingOverlay();
        this.HCUGridOption.api.setColumnDefs(this.columnDefinationService.getHCUTABColumnDef());
        this.rowDataHCU = this.childData;
        this.totalCount1 = this.rowDataHCU.length;
        this.setShowAllLabelHCU(this.rowDataHCU.length, this.totalCount1);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    private setShowAllLabelHCU(rowCount, totalCount):void {
        this.showAllLabel1 = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob1 = rowCount + "/" + totalCount;
    }

    private setShowAllLabelError(rowCount, totalCount):void {
        this.showAllLabel1 = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob1 = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.firmwareUpgradeGridOption.api.getDisplayedRowCount();
        let rowCount1 = this.HCUGridOption.api.getDisplayedRowCount();
        if(this.errorRowData) {
            let rowCount2 = this.HCUGridOptionError.api.getDisplayedRowCount();
            this.setShowAllLabelError(rowCount2, this.totalCount2);
        }
        this.setShowAllLabel(rowCount, this.totalCount);
        this.setShowAllLabelHCU(rowCount1, this.totalCount1);
    }

    //refresh
    public notifyGridReady(params:any):void{
        this.setGridColumnDefinition();
    }

    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.firmwareUpgradeGridOption.api.setColumnDefs(this.columnDefinationService.getColumnDef());
        this.firmwareUpgradeGridOption.rowSelection = "single";
        this.firmwareUpgradeGridOption.enableSorting = true;
        this.getFirmwareData();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.firmwareUpgradeGridOption.api.showLoadingOverlay();
    }

    //function :: makes api call to get firmware data.
    private getFirmwareData(): void {
        this.hcuTabDataService.getFirmwareUpgradeList().subscribe(
            (res:Array<FirmwareUpgradeModel>) => {
                this.selectedData = [];
                if(res.length > 0){
                    // 20-Mar-2018 : Sorting removed from Version as default sorted data is on date.
                    // res.sort(function (a, b) {
                    //     var keyA = a.packageVersion,
                    //         keyB = b.packageVersion;
                    //     if (keyA > keyB) return -1;
                    //     if (keyA < keyB) return 1;
                    //     return 0;
                    // });
                    this.latestDownloadingDate = res[0].downloadDate;
                    this.latestPackageVersion = res[0].packageVersion;
                }
                this.rowData = res;
                this.totalCount = this.rowData.length;
                this.setShowAllLabel(this.rowData.length, this.totalCount);
                this.firmwareUpgradeGridOption.api.hideOverlay();
                this.checkForNewFirm = false;
            },this.onError.bind(this));
    }

    //function :: makes api call to get firmware data.
    public checkNewFirmwareRelease(): void {
        this.checkForNewFirm = true;
                this.hcuTabDataService.checkNewFirmwareRelease().subscribe(
                    (res:any) => {
                        res ? this.showCheckFirmwareTrueNotification() : this.showCheckFirmwareFalseNotification();
                    }, this.onError.bind(this));
    }

    //method :: shows conformation popup for false notification.
    private showCheckFirmwareFalseNotification():void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.UPGRADE_CONFIRMATION_MESSAGE_FALSE ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.hcuTabDataService.getFirmwareUpgradeList().subscribe(
                        (FirmwareData:Array<FirmwareUpgradeModel>) => {
                            this.latestFirmwareData = FirmwareData;
                            this.downloadUpgradedFirmware();
                        }, this.onError.bind(this));
                }else{
                    this.checkForNewFirm = false;
                }
            }
        );
    }

    //method :: shows conformation popup for true notification.
    private showCheckFirmwareTrueNotification():void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,"" ,this.UPGRADE_CONFIRMATION_MESSAGE_TRUE ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.hcuTabDataService.getFirmwareUpgradeList().subscribe(
                        (FirmwareData:Array<FirmwareUpgradeModel>) => {
                            this.latestFirmwareData = FirmwareData;
                            this.hcuTabDataService.downloadUpgradedFirmware().subscribe(
                                (res:any) => {
                                    this.getLatestFirmwarePackage();
                                    this.latestFirPackInterval = setInterval(() => {
                                        this.getLatestFirmwarePackage()
                                    }, 400);
                                }, this.onError.bind(this));

                        }, this.onError.bind(this));
                }
            }
        );
    }

    //method :: downloads firmware
    private downloadUpgradedFirmware():void{
        this.hcuTabDataService.downloadUpgradedFirmware().subscribe(
            (res:any) => {
                this.getLatestFirmwarePackage(true);
                this.latestFirPackInterval = setInterval(() => {
                    this.getLatestFirmwarePackage(true);
                }, 400);
            },this.onError.bind(this));
        vm.callLatestFirmwareUpgrade = false;
    }


    private upgradeFirmwarePackageDetails():void{
        this.firmwareUpgradeGridOption.api.showLoadingOverlay();
        this.getFirmwareData();
    }

    //method :: gets latest firmware
    private getLatestFirmwarePackage(oldPackageDownload?):void{
        this.hcuTabDataService.getLatestFirmwarePackage().subscribe(
            (res:any) => {
                if(((res["packageVersion"] !== null && this.latestFirmwareData.findIndex(x => x["packageVersion"] === res["packageVersion"]) === -1) || oldPackageDownload )&& this.latestFirPackInterval.runCount !== -1){
                    clearInterval(this.latestFirPackInterval);
                    this.upgradeFirmwarePackageDetails();
                }
            },(error)=>{
                clearInterval(this.latestFirPackInterval);
                this.onError(error);
            });
    }

    //method :: upgrades firmware
    public UpgradeFirmware():void{
        var data = this.selectedData;
        if (data.length > 0 && data.length === 1) {
            for(var i = 0; i< this.childData.length;i++){
                if(this.childData[i].firmwareUpgradeAvailable === 'No'){
                    this.childData[i].firmwareUpgradeAvailable = false;
                } else {
                    this.childData[i].firmwareUpgradeAvailable = true;
                }

                if(this.childData[i].status.toUpperCase() === this.localeDataService.getLocalizationService().instant('HCU_ONLINE').toUpperCase()){
                    this.childData[i].status = "OK";
                }

            }
            this.upgradeSelectedHCUs(data, this.childData);
        } else {
            this.showAlert.showInfoAlert(this.SELECT_ANY_ONE_FIRMWARE);
        }

    }

    //method :: upgrades selected hcus
    private upgradeSelectedHCUs(data , HCUdata):void{
        this.hcuTabDataService.upgradeFirmwareHCU(data[0].packageVersion , HCUdata).subscribe(
            (res:any) => {
                res.length === 0 ? this.upgradeSuccessFlow() : this.upgradeSelectedHCUError(res);
            }, this.onError.bind(this));
    }

    private upgradeSuccessFlow(){
        this.showAlert.showInfoAlert(this.SELECTED_HCU_SUCCESS_UPGRADE);
        this.btnClose_click();
        this.hcuSharedService.getHcuListRefreshSub().next()
    }

    //method :: selected hcu error upgrade
    private upgradeSelectedHCUError(data):void{
        this.errorRowDataList = [];
        var errorRowDataList = [];
        for(let i=0;i<data.length;i++){
            data[i].hcuResponse.errorCode = this.controlMessagesService.getMsg(data[i].errorCode);
            errorRowDataList.push(data[i].hcuResponse);
        }
        this.errorRowDataList = errorRowDataList;
        this.hcuSharedService.getHcuListRefreshSub().next();
    }

    //method :; notifies hcu error grid ready
    private notifyHCUErrorGridReady():void{
        this.HCUGridOptionError.api.showLoadingOverlay();
        this.HCUGridOptionError.api.setColumnDefs(this.columnDefinationService.getHCUTABColumnDefError());
        this.errorRowData = this.errorRowDataList;
        this.totalCount2 = this.errorRowData.length;
        this.setShowAllLabelError(this.errorRowData.length, this.totalCount2);
        this.gridHeaderTxtColor = 'errorTxt';
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.checkForNewFirm = false;
        this.showAlert.showErrorAlert(error);
    }

    //for single selection
    public notifySingleRowselected($event){
        let data:any = $event;
        this.selectedData = data;
        if(data.length > 0){
            this.corruptedStatus = data[0]["fileCorrupted"];
        } else {
            this.corruptedStatus = false;
        }

    }


}