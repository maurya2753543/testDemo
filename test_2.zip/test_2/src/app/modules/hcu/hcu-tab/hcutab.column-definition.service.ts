import {Injectable} from '@angular/core';
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {EDIT_ICON} from "../../../constant/app.constants";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {EDIT_OPERATION} from '../hcu.constants';
import {HCUSharedService} from '../hcu.shared.service'; 
import {HCUTabDataService} from './hcutab.data.service';
import {ShowAlert} from "./../../../utilities/showAlert";
import {StatusFilter} from "../../../shared/status.filter";
import {SharedService} from "../../../shared/shared.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from '@ngx-translate/core';
@Injectable()

export class HCUTabColumnDefinationService {

    //Header fields with field name and display name. 
    private _HEADER_FIELDS: any = {
        status : {field: "status", name: "HCU_TAB_HEADER_STATUS"},
        label : {field: "label", name: "HCU_TAB_HEADER_LABEL"},
        location : {field: "location", name: "HCU_TAB_HEADER_LOCATION"},
        type : {field: "type", name: "HCU_TAB_HEADER_TYPE"},
        inetAddress : {field: "inetAddress", name: "HCU_TAB_HEADER_IP_ADDRESS"},
        serialNumber : {field: "serialNumber", name: "HCU_TAB_HEADER_SERIAL_NUMBER"},
        numberOfRpms : {field: "numberOfRpms", name: "HCU_TAB_HEADER_NUMBER_OF_RPM"},
        sbcModel : {field: "sbcModel", name: "HCU_TAB_HEADER_SBC_MODEL"},
        ramSize : {field: "ramSize", name: "HCU_TAB_HEADER_RAM_SIZE"},
        firmwarePackageRev : {field: "firmwarePackageRev", name: "HCU_TAB_HEADER_FIRMWARE_PACKAGE"},
        firmwareVersion : {field: "firmwareVersion", name:"HCU_TAB_HEADER_FIRMWARE_VERSION"},
        firmwareUpgradeAvailable : {field: "firmwareUpgradeAvailable", name: "HCU_TAB_HEADER_FIRMWARE_UPGRADE_AVAILABLE"},
        edit : {field: "edit", name: "HCU_TAB_HEADER_EDIT"},
        container: {field: "container", name: "HCU_TAB_HEADER_CONTAINER"},
        site: {field: "site", name: "HCU_TAB_HEADER_SITE"}
    };

    constructor(private localeDataService:LocaleDataService,
                private hcuSharedService:HCUSharedService,
                private hcuTabDataService:HCUTabDataService,
                private showAlert:ShowAlert,
                private sharedService : SharedService,
                public translate : TranslateService){ 
                this.translateLocaleStr();
    }
    
     /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.status.name = this.translate.instant('HCU_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.label.name = this.translate.instant('HCU_TAB_HEADER_LABEL');
        this._HEADER_FIELDS.location.name = this.translate.instant('HCU_TAB_HEADER_LOCATION');
        this._HEADER_FIELDS.type.name = this.translate.instant('HCU_TAB_HEADER_TYPE');
        this._HEADER_FIELDS.inetAddress.name = this.translate.instant('HCU_TAB_HEADER_IP_ADDRESS');
        this._HEADER_FIELDS.serialNumber.name = this.translate.instant('HCU_TAB_HEADER_SERIAL_NUMBER');
        this._HEADER_FIELDS.numberOfRpms.name = this.translate.instant('HCU_TAB_HEADER_NUMBER_OF_RPM');
        this._HEADER_FIELDS.sbcModel.name = this.translate.instant('HCU_TAB_HEADER_SBC_MODEL');
        this._HEADER_FIELDS.ramSize.name = this.translate.instant('HCU_TAB_HEADER_RAM_SIZE');
        this._HEADER_FIELDS.firmwarePackageRev.name = this.translate.instant('HCU_TAB_HEADER_FIRMWARE_PACKAGE');
        this._HEADER_FIELDS.firmwareVersion.name = this.translate.instant('HCU_TAB_HEADER_FIRMWARE_VERSION');
        this._HEADER_FIELDS.firmwareUpgradeAvailable.name = this.translate.instant('HCU_TAB_HEADER_FIRMWARE_UPGRADE_AVAILABLE');
        this._HEADER_FIELDS.edit.name = this.translate.instant('HCU_TAB_HEADER_EDIT');
        this._HEADER_FIELDS.container.name = this.translate.instant('HCU_TAB_HEADER_CONTAINER');
        this._HEADER_FIELDS.site.name = this.translate.instant('HCU_TAB_HEADER_SITE');
    }

    public getWidthOfText(txt: string, factor : number): number {
        // Create a dummy canvas (render invisible with css)
        let c = document.createElement('canvas');
        // Get the context of the dummy canvas
        let ctx = c.getContext('2d');
        // Set the context.font to the font that you are using
        ctx.font = '14px' + ' "Helvetica Neue", Helvetica, Arial, sans-serif';
        // Measure the string
        // !!! <CRUCIAL> !!!
        //let length: string = (ctx.measureText(txt).width + 30) + "";
        let length: number = (ctx.measureText(txt).width + factor);
        // !!! </CRUCIAL> !!!
        // Return width
        return length;
        }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        //TODO:: handle status ok to online.
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                suppressResize: true
                
            },
            {
                headerName: this._HEADER_FIELDS.status.name,
                headerTooltip: this._HEADER_FIELDS.status.name, 
                field: this._HEADER_FIELDS.status.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 90),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: StatusFilter.ParentFilter,
                floatingFilterComponent: StatusFilter.ChildFloatingFilter,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.label.name,
                headerTooltip: this._HEADER_FIELDS.label.name, 
                field: this._HEADER_FIELDS.label.field,
                minWidth : 290,
                maxWidth : 450,
                suppressSizeToFit: true,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}, 
                sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.location.name,headerTooltip: this._HEADER_FIELDS.location.name, field: this._HEADER_FIELDS.location.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.location.name, 120),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.type.name,headerTooltip: this._HEADER_FIELDS.type.name, field: this._HEADER_FIELDS.type.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.type.name, 50),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.inetAddress.name,headerTooltip: this._HEADER_FIELDS.inetAddress.name, field: this._HEADER_FIELDS.inetAddress.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.inetAddress.name, 40),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.serialNumber.name,headerTooltip: this._HEADER_FIELDS.serialNumber.name, field: this._HEADER_FIELDS.serialNumber.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serialNumber.name, 50),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.numberOfRpms.name,headerTooltip: this._HEADER_FIELDS.numberOfRpms.name, field: this._HEADER_FIELDS.numberOfRpms.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.numberOfRpms.name, 60),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.sbcModel.name,headerTooltip: this._HEADER_FIELDS.sbcModel.name, field: this._HEADER_FIELDS.sbcModel.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.sbcModel.name, 50),                
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.ramSize.name,headerTooltip: this._HEADER_FIELDS.ramSize.name, field: this._HEADER_FIELDS.ramSize.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.ramSize.name, 50),                
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
            },
            {
                headerName: this._HEADER_FIELDS.firmwarePackageRev.name,headerTooltip: this._HEADER_FIELDS.firmwarePackageRev.name, field: this._HEADER_FIELDS.firmwarePackageRev.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwarePackageRev.name, 50),                
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwareVersion.name,headerTooltip: this._HEADER_FIELDS.firmwareVersion.name, field: this._HEADER_FIELDS.firmwareVersion.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareVersion.name, 50),
                filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.firmwareUpgradeAvailable.name,headerTooltip: this._HEADER_FIELDS.firmwareUpgradeAvailable.name, field: this._HEADER_FIELDS.firmwareUpgradeAvailable.field,
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwareUpgradeAvailable.name, 50),
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this._HEADER_FIELDS.container.name,
                headerTooltip: this._HEADER_FIELDS.container.name, 
                field: this._HEADER_FIELDS.container.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.container.name, 80),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}, 
                sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.site.name,
                headerTooltip: this._HEADER_FIELDS.site.name, 
                field: this._HEADER_FIELDS.site.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.site.name, 80),
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}, 
                sort: 'asc'
            },
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                minWidth: 70, maxWidth: 150,
                pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }

        ]
        return columnDef;
    }

    //method  is used to get details of single hcu on view icon click.
    private action(param):void {
        this.hcuTabDataService.getHCUDetails(param.data.elementId).subscribe(this.onHCUDetailsSuccess.bind(this),this.onError.bind(this));
    }

    //method :: sets hcu model data in hcu shared service.
    private onHCUDetailsSuccess(response):void {
        let data: any = {operation: EDIT_OPERATION, HcuViewModel: response};
        this.hcuSharedService.setHcuViewModelData(data);
        this.hcuSharedService.getHcuFormChangeSub().next(data);
    }

    //method :: shows error alert.
    private onError(error):void {
        this.showAlert.showErrorAlert(error);
    }
}