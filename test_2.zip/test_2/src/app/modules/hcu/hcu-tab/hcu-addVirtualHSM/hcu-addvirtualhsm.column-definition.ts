import {Injectable} from '@angular/core';

import {LocaleDataService} from "../../../../shared/locale.data.service";
import {gridCustomComparator} from "../../../../shared/ag-Grid.comparator";

@Injectable()

export class AddVirtualHSMColumnDefinationService {
    
    private gridOptions:any;
    private selectedRow:any;
    private  _HEADER_FIELDS: any = {
        phyHSM : {field: "label", name: "ADD_VHSM_HEADER_PHYSICAL"},
        attachedHcu : {field: "hcuLabel", name: "ADD_VHSM_HEADER_ATTACHED_HCU"}
    }
    constructor(private localeDataService:LocaleDataService){
        this.translateLocaleString();
    }
    
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this._HEADER_FIELDS.phyHSM.name = localizationService.instant("ADD_VHSM_HEADER_PHYSICAL");
        this._HEADER_FIELDS.attachedHcu.name = localizationService.instant("ADD_VHSM_HEADER_ATTACHED_HCU");
    }
    


    //method returns column defination.
    public getColumnDef(): any[] {
        let columnDef: any[] = [
            {
                headerName: '',
                width: 21,
                pinned: true,
                sortingOrder: [null],
                field: '',
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = "<input type='radio' id='HSM' name='virtualHSM'>";
                    let eFilterText = gui.querySelector('input');
                    eFilterText.addEventListener("click", (()=>{
                        this.action(param);
                    }));
                    gui.className = "ag-Grid-cursor"; 
                    return gui;
                })
            },
            {
                headerName: this._HEADER_FIELDS.phyHSM.name,headerTooltip: this._HEADER_FIELDS.phyHSM.name, field: this._HEADER_FIELDS.phyHSM.field,
                minWidth: 100, maxWidth: 150,filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true}
            },
            {
                headerName: this._HEADER_FIELDS.attachedHcu.name,headerTooltip: this._HEADER_FIELDS.attachedHcu.name, field: this._HEADER_FIELDS.attachedHcu.field,
                minWidth: 200, filter: 'agTextColumnFilter',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {suppressAndOrCondition: true}
            },
        ]

        return columnDef;
    }

    //methods selects current row on click of radio button
    private action(param):void {
        this.gridOptions.api.forEachNode((node) => {
                if (node.data.hcuId == param.data.hcuId) {
                    node.setSelected(true);
                    this.selectedRow = node;
                }
        })
    }

    //method sets grid options.
    public setGridOptions(options):any {
        this.gridOptions = options;
    }
}