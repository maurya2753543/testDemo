import {Component} from '@angular/core';

import {Logger} from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {AddVirtualHSMColumnDefinationService} from './hcu-addvirtualhsm.column-definition';
import { Grid } from "../../../../shared/ag-grid.options";
import {HCUTabDataService} from '../hcutab.data.service';
import {VirtulaHSMModel} from '../model/hcu-addvirtualhsm.model';
import {HCUSharedService} from '../../hcu.shared.service';
import {
    ALERT_SUCCESS, ALERT_INFO
} from "../../../../constant/app.constants";
import { CommonStrings } from '../../../../constant/common.strings';
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector:'hcu-addVirtualHSM',
    templateUrl:'hcu-addvirtualhsm.component.html'
})

export class AddVirtualHSM {
    public virtualHSMGridOptions: Grid = new Grid();
    public dataModel:VirtulaHSMModel = new VirtulaHSMModel({});
    public isCloseRightSlider:boolean = false;
    public eventKeys:any;
    public buttonKeys:any;
    public rowData:any;
    public tabType:string = "HCU_TAB";
    public isAddDisabled:boolean = true;
    private ADD_VIRTUAL_HSM_SUCCESS:string = "";
    private tag:string = "AddVirtualHSM";
    public isphyHsmHcuIdNull:boolean = false;

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    constructor( private addVirtualHSMColumnDefinationService:AddVirtualHSMColumnDefinationService,
                private showAlert: ShowAlert,private sharedService:SharedService,
                private localeDataService: LocaleDataService,
                private sweetAlert:SweetAlert, private logger:Logger,
                private hcuTabDataService:HCUTabDataService, private hcuSharedService:HCUSharedService){
                    this.isCloseRightSlider = false;
                    this.virtualHSMGridOptions.rowSelection = 'single';
    }

    ngOnInit(){
        this.setEventButtonKeys();
        this.translateLocaleString();
        this.closeSlidersSubjectListener();
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.btnClose_click();
        })
    }

    //method :: notify when  grid is ready.
    public notifyGridReadyAddVirtualHcu(params:any):void {
        this.addVirtualHSMColumnDefinationService.setGridOptions(this.virtualHSMGridOptions);
        this.virtualHSMGridOptions.api.setColumnDefs(this.addVirtualHSMColumnDefinationService.getColumnDef());
        this.showGridLoadingOverly();
        this.getPhysicalHSM();
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.virtualHSMGridOptions.api.showLoadingOverlay();
    }
    // method :: api call to get physicalhsm.
    private getPhysicalHSM():void {
        this.hcuTabDataService.getPhysicalHSMs().subscribe(this.onPhysicalHSMSuccess.bind(this),this.onError.bind(this))
    }

    //method :: sets row data to grid after success.
    private onPhysicalHSMSuccess(data:any):void {
        this.rowData = data;
        this.totalCount = this.rowData.length;
        this.setShowAllLabel(this.rowData.length, this.totalCount);

    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.virtualHSMGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //Method to set button keys
    private setEventButtonKeys(): void {
        this.eventKeys = [];
        this.buttonKeys = [];

    }

    //getting single row data
    public notifySingleRowselected($event):void{
        this.dataModel.physicalHsmHcuId = ($event.length)? $event[0].hcuId : null;
        if(this.dataModel.physicalHsmHcuId != null && this.dataModel.label != "") {
            this.isAddDisabled = false;
            this.isphyHsmHcuIdNull = false;
        }else {
            this.isAddDisabled = true;
            this.isphyHsmHcuIdNull = true;
        }
    }

    
    //method :: closes the slider.
    public btnClose_click():void{
        this.isCloseRightSlider = true;
        this.hcuSharedService.getHCUClearSliderSub().next(true);
    }

    //method :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.ADD_VIRTUAL_HSM_SUCCESS = localizationService.instant("ALERT_MESSAGES.HCU_SECTION.HCU_TAB.ADD_VIRTUAL_HSM_SUCCESS");
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //refresh
    public notifyRefreshGrid():void{
        this.getPhysicalHSM();
    }

    //method :: makes api call to post/add virtual hsm
    public addVirtualHSM():void {
        this.dataModel.vhsmParentHcuId = this.hcuSharedService.getHCUElementId();
        this.hcuTabDataService.createVirtualHSM(this.dataModel).subscribe(this.onCreateVHSM.bind(this) ,this.onError.bind(this))
    }

    //method :: shows success popup on create virtual hsm success.
    private onCreateVHSM(data:any):void {
        this.sweetAlert.showConformationAlert(ALERT_SUCCESS , CommonStrings.ALERT_SUCCESS_TITLE , this.ADD_VIRTUAL_HSM_SUCCESS ,false ,true,CommonStrings.OK ,null,
            (isConfirm)=>{
                this.btnClose_click();
            }
        )
    }

    //method ::  disables the add button if label is empty.
    public updateLabelName(event):void {
        if(event != "" && this.dataModel.physicalHsmHcuId != null) {
            this.isAddDisabled = false;
            this.isphyHsmHcuIdNull = false;
        }else {
            this.isAddDisabled = true;
            this.isphyHsmHcuIdNull = true;
        }
    }

    //method called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

}