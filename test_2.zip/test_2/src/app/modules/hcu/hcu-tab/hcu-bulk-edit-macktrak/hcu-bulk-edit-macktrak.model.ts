/**
 * @ Author: Vrishabh Mishra
 * @ Create Time: 2019-05-30 12:54:54
 */

export interface BulkEditMacktrakModel {
    cmtsFeatures: Object[];
    cmtsIds: number[];
}