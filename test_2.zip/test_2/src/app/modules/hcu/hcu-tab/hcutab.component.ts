import {Component, ViewChild, ComponentFactoryResolver, ViewContainerRef, ElementRef, OnDestroy} from '@angular/core';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { Grid } from "../../../shared/ag-grid.options";
import { HCUTabDataService } from './hcutab.data.service';
import { HCUTabColumnDefinationService } from './hcutab.column-definition.service';
import { HCUViewComponent } from './hcu-view/hcu-view.component';
import {AddVirtualHSM} from './hcu-addVirtualHSM/hcu-addvirtualhsm.component';
import * as HCUConstants from '../hcu.constants';
import {HCUMactrakChannel} from './hcu-mactrakChannels/hcu-mactrakchannels.component';
import {HCUViewEvent} from './hcu-viewEvents/hcu-viewevent.component';
import { Logger } from "./../../../utilities/logger";
import {ShowAlert} from "./../../../utilities/showAlert";
import { LocaleDataService } from "./../../../shared/locale.data.service";
import { HCUSharedService } from "../hcu.shared.service";
import {FirmwareUpgradeHCU} from './hcu-firmwareUpgrade/hcu-firmwareUpgrade.component';
import { SweetAlert } from '../../../utilities/sweetAlert'; 
import {ALERT_INFO, PERM_REBOOT_HCU,NAV_LINK_HCU} from "../../../constant/app.constants";
import { CommonStrings } from '../../../constant/common.strings';
import { SharedService } from "./../../../shared/shared.service";
import {ImportLabelModel} from "../importLabel.model";
import {AuthService} from "../../../shared/auth.service";
import {StatusFilter} from "../../../shared/status.filter";
import { CmtsTabSharedService } from '../../cmts/cmts-tab.shared.service';
import { HcuBulkEditMacktrakComponent } from './hcu-bulk-edit-macktrak/hcu-bulk-edit-macktrak.component';
import { CMTSHttpService } from '../../cmts/cmts.http.service';
import { ComponentResolver } from 'ag-grid/dist/lib/components/framework/componentResolver';

let vm;

function isExternalFilterPresent() {
    return vm.showSelected;
}

function doesExternalFilterPass(node) {
    return node.data.status.toUpperCase() === vm.currentFilter.toUpperCase();
}

@Component({
    selector: 'hcutab-component',
    templateUrl: 'hcutab.component.html'
})

export class HCUTabComponent implements OnDestroy {
    public hcuTabGridOptions: Grid = new Grid();
    public rowdata: any;
    public eventKeys: Object[];
    public buttonKeys: Object[];
    private hcuFilterInstance: any;
    private formData = new FormData();
    private tag: string = "HCUComponent";
    private HCU_REBOOT_SUCCESS: string = "";
    private HCU_SYNC_SUCCESS: string = "";
    private HCU_RESTORE_SUCCESS: string = "";
    private HCU_REPAIR_SUCCESS: string = "";
    private TEST_CONNECTION_SUCCESS: string = "";
    private HCU_REBOOT_CONFIRM_MSG:string = "";
    private HCU_RESTORE_CONFIRM_MSG:string = "";
    private HCU_REBOOT_TITLE:string = "";
    private HCU_RESTORE_TITLE:string = "";
    private VIRTUAL_HSM_TITLE:string = "";
    private VIRTUAL_HSM_OTHERTHAN_200_MSG:string = "";
    private VIRTUAL_HSM_WITH_HCU_MSG:string = "";
    public gridTabType:string = "HCUExport";
    private ADD_VIRTUAL_HSM:string = "";
    private TEST_CONNECTION:string = "";
    private SYNC_CLOCK:string = "";
    private REBOOT:string = "";
    private RESTORE:string = "";
    private REPAIR:string = "";
    private VIEW_EVENTS:string = "";
    private VIEW_MACKTRACK_CHANNELS:string = "";
    private FIRMWARE_UPGRADE:string = "";
    private ADD_HCU:string = "";
    private IMPORT_LABELS:string = "";
    private GRID_EXPORT_ALL:string = "";
    private GRID_EXPORT_SELECTED:string = "";
    private GRID_REFRESH:string = "";

    public refreshBtnFlag: boolean;
    private SHOW_ALL: string = "Show All";
    private showAll:boolean = true;
    private TABLE_LIST_SHOW_LESS:string = "";
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    private showAllBtn: Object[] = [];
    private showSelected: boolean = false;
    private currentFilter: string;
    private SET_MACTRAK_THRESHOLD: string= "";
    private RESET_MACTRAK_THRESHOLD: string ="";
    private RESET_MACKTRACK_CONFIRMATION_MSG: string = "";
    private RESET_MACKTRACK_TITLE: string = "";

    @ViewChild('fileInput') fileInput: ElementRef;
    @ViewChild('targetHCUSlider', { read: ViewContainerRef }) _targetHCUSlider;
    private ngUnsubscribe:Subject<void> = new Subject<void>();


    constructor(private hcuTabDataService: HCUTabDataService,
                private hcuTabColumnDefinationService: HCUTabColumnDefinationService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private logger: Logger,
                private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private authService:AuthService,
                private hcuSharedService: HCUSharedService,
                private sweetAlert: SweetAlert,
                private sharedService: SharedService,
                public translate : TranslateService,
                private cmtsTabSharedService: CmtsTabSharedService,
                private cmtsHttpService: CMTSHttpService) {
       vm = this;
       this.translateLocaleString();
    }

    ngOnInit(){
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.formChangeSubListener();
        this.getPermissionData();
        this.HCUClearSliderSubListener();
        this.HCUListRefreshListener();
        if(this.sharedService.RetainFilter){
            this.hcuTabDataService.hcufilterchangedata = "";
            this.hcuSharedService.modeldata = "";

        }

    }

    ngOnDestroy(): void {
        this.sharedService.setFilterForTAB('');
    }

    private HCUListRefreshListener():void {
        this.hcuSharedService.getHcuListRefreshSub().subscribe((res)=>{
            this.getHCUTabData();
        })
    }

    private HCUClearSliderSubListener():void {
        this.hcuSharedService.getHCUClearSliderSub().subscribe((res)=>{
            if(res) {
                this.clearSlider();
            }
        })
    }

    private formChangeSubListener() {
        this.hcuSharedService
            .getHcuFormChangeSub()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(() => {
            this.loadSlider('HCU_VIEW');
        })
    }

    //function :: makes api call to get hcu tab data.
    public getHCUTabData(): void {
        if(this.hcuTabGridOptions.api){
            if(this.sharedService.getFilterForTAB().length > 0){
                this.showSelected = true;
                this.hcuTabGridOptions["isExternalFilterPresent"] = isExternalFilterPresent;
                this.hcuTabGridOptions["doesExternalFilterPass"] = doesExternalFilterPass;
                this.currentFilter = this.sharedService.getFilterForTAB();
                StatusFilter.setFilter(this.currentFilter);
                this.hcuTabGridOptions.api.getFilterInstance('status')
                    .setModel(this.currentFilter);
                this.hcuTabGridOptions.api.onFilterChanged();
                this.showSelected = false;
            }else if(this.sharedService.getFilterForTabAlert().length > 0){
                let filter: string = this.sharedService.getFilterForTabAlert();
                if (filter.toLowerCase() === 'yes' || filter.toLowerCase() === 'no') {
                    const localizationService: any = this.localeDataService.getLocalizationService();
                    filter = localizationService.instant(filter.toUpperCase());
                }
                this.hcuTabGridOptions.api.getFilterInstance('firmwareUpgradeAvailable')
                    .setFilter(filter);
                this.sharedService.setFilterForTabAlert("");
            } else if(this.sharedService.getFilterAlarmForTAB().length > 0){
                this.hcuTabGridOptions.api.getFilterInstance('label').setFilter(this.sharedService.getFilterAlarmForTAB());
                this.sharedService.setFilterAlarmForTab("");
            } else {
                this.hcuSharedService.applyNameFilter(this.hcuFilterInstance,"hcu");
            }
            this.hcuTabDataService
                .getAllHcuTabList(this.showAll).pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.onGetHCUTabDataNext.bind(this), this.onError.bind(this));
        }
            if(this.hcuTabGridOptions.api && ( !jQuery.isEmptyObject(this.hcuTabDataService.hcufilterchangedata) || this.hcuSharedService.modeldata )){
                if(this.hcuTabDataService.hcufilterchangedata){
                this.hcuTabGridOptions.api.setFilterModel(this.hcuTabDataService.hcufilterchangedata);
                }
            if(this.hcuSharedService.modeldata || this.hcuTabDataService.hcufilterchangedata){
                const countryFilterComponent2 = this.hcuTabGridOptions.api.getFilterInstance("label");
                countryFilterComponent2.setModel(this.hcuSharedService.modeldata);
            }
           
                
        }

    }

    //function :: sets rowdata to grid.
    private onGetHCUTabDataNext(data:any):void {
        this.rowdata = data;
        this.totalCount = data.totalCount;
        this.setShowAllLabel(data.length, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.hcuTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //method showall ports
    private notifyShowAll():void {
        this.action(true);
        this.setShowLessBtn();
    }

    //methods notifies show less
    private notifyShowLess():void {
        this.action(false);
        this.setShowAllBtn();
    }

    //method gets hcutab data.
    private action(showall:boolean):void {
        this.showGridLoadingOverly();
        this.showAll = showall;
        this.getHCUTabData();
    }

    //method set showAll btn
    private setShowAllBtn():void {
        this.showAllBtn = [{name: this.SHOW_ALL, tabType:'PORT_TAB'}];
        
    }

    //method set showless btn
    private setShowLessBtn():void {
        this.showAllBtn = [{name: this.TABLE_LIST_SHOW_LESS, tabType:'PORT_TAB'}];
        
    }

    //Method to set button keys
    private setEventButtonKeys(): void {
        this.eventKeys = [
            { name: this.ADD_VIRTUAL_HSM, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB,disable:false, KEY : NAV_LINK_HCU },
            { name: this.TEST_CONNECTION, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB,disable:false},
            { name: this.SYNC_CLOCK, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB,disable:false, KEY : NAV_LINK_HCU  },
            { name: this.REBOOT, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB,disable:false, KEY : PERM_REBOOT_HCU },
            { name: this.RESTORE, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB,disable:false, KEY : NAV_LINK_HCU  },
            { name: this.REPAIR, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB, disable:false, KEY : NAV_LINK_HCU  },
            { name: this.VIEW_EVENTS, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB,disable:false},
            { name: this.VIEW_MACKTRACK_CHANNELS, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB,disable:false, KEY : NAV_LINK_HCU  },
            { name: this.SET_MACTRAK_THRESHOLD, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB},
            { name: this.RESET_MACTRAK_THRESHOLD, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB},
            { name: this.FIRMWARE_UPGRADE, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB,disable:false, KEY : NAV_LINK_HCU  },
            { name: this.GRID_EXPORT_SELECTED, status: HCUConstants.SINGLE_CONTS, tabType: HCUConstants.HCU_TAB,},
            { name: this.GRID_EXPORT_ALL, status: HCUConstants.ALL, tabType: HCUConstants.HCU_TAB,},
        ];


        this.buttonKeys = [
            { name: this.ADD_HCU, tabType: HCUConstants.HCU_TAB, disable:false ,KEY:NAV_LINK_HCU},
            { name: this.IMPORT_LABELS, tabType: HCUConstants.HCU_TAB,disable:false ,KEY:NAV_LINK_HCU },
        ];
        this.refreshBtnFlag = true;
    }

    private getPermissionData(){
                // if(this.sharedService.checkPermissions(PERM_REBOOT_HCU)){
                //     this.eventKeys.splice(3,0,{ name: this.REBOOT, status: HCUConstants.ONLY_SINGLE_CONST, tabType: HCUConstants.HCU_TAB });
                // }
    }

    public notifyActionEmitter($event){

        switch ($event.event.name) {
            case this.TEST_CONNECTION:
                this.notifyTestConnectionHCU($event.selectedData[0]);
                break;
            case this.SYNC_CLOCK:
                this.notifySyncHCU($event.selectedData[0]);
                break;
            case this.REBOOT:
                this.notifyRebootHCU($event);
                break;
            case this.RESTORE:
                this.notifyRestoreHCU($event);
                break;
            case this.REPAIR:
                this.notifyRepairHCU($event.selectedData[0]);
                break;
            case this.VIEW_MACKTRACK_CHANNELS:
                this.notifyViewChannelHCU($event.selectedData[0]);
                break;
            case this.SET_MACTRAK_THRESHOLD:              
                this.notifyControlFeaturesMacktrak($event.selectedData);
                break;
            case this.RESET_MACTRAK_THRESHOLD:
                    this.notifyControlFeaturesMacktrakReset($event.selectedData);
                    break;    
            case this.FIRMWARE_UPGRADE:
                this.notifyFUpgradeHCU($event.selectedData);
                break;
            case this.ADD_VIRTUAL_HSM:
                this.notifyAddVirtualHCU($event.selectedData[0]);
                break;
            case this.ADD_HCU:
                this.notifyAddHCU();
                break;
            case this.IMPORT_LABELS:
                this.notifyImportLblHCU();
                break;
            case this.VIEW_EVENTS:
                this.notifyViewEvent($event.selectedData);
                break;
            case this.SHOW_ALL:
                this.notifyShowAll();
                break;
            case this.TABLE_LIST_SHOW_LESS:
                this.notifyShowLess();
                break;
            default:
        }
    }

    private handleError(error: any) {
        return Promise.reject(error.message || error);
    }

    // function :: notify that grid is ready.
    public notifyGridReadyHCU(params:any): void {
        this.setGridColumnDefinition();
    }

    //method calls after filter change.
    public notifyFilterChangeHCU(e: any): void {
        this.sharedService.RetainFilter = false;
        const countryFilterComponent = this.hcuTabGridOptions.api.getFilterInstance('label');
        const model = countryFilterComponent.getModel();
        this.hcuSharedService.modeldata = model;
        // this.hcuSharedService.modeldata2 = model;
        this.hcuTabDataService.hcufilterchangedata = this.hcuTabGridOptions.api.getFilterModel();
    }

    //Method to set column definitions
    private setGridColumnDefinition(): void {
        this.showGridLoadingOverly();
        this.hcuTabGridOptions.api.setColumnDefs(this.hcuTabColumnDefinationService.getColumnDef());
        //this.hcuTabDataService.filterchangedata = this.hcuTabGridOptions.api.getFilterModel();
        this.hcuFilterInstance = this.hcuTabGridOptions.api.getFilterInstance('label');
        //this.hcuTabGridOptions.api.onFilterChanged();
        this.hcuTabGridOptions["getRowHeight"] = (params) => {
            let level;
            let thresholdLength = 35;
            let rowHeight = 22;
            let hcuLength;
            if(params.data.label && params.data.label.length){
                hcuLength = params.data.label.length;
                if(hcuLength < thresholdLength) return rowHeight;
                else {
                    level = Math.floor(hcuLength / thresholdLength);
                    return rowHeight * level + 1;
                }              
            }
            else{
                return rowHeight;
            }
        }

        if(this.hcuSharedService.getHcmFilterText().length > 0){
            this.showAll = true;
        }
        this.getHCUTabData();
    }

    //method loads view events slider.
    private notifyViewEvent($event) {
        this.loadSlider('HCU_VIEW_EVENTS', $event);

    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.hcuTabGridOptions.api.showLoadingOverlay();
    }

    // function :: notify that grid is ready.
    private notifyTestConnectionHCU($event): void {
        this.hcuTabDataService
            .testConnectionHCU($event.elementId)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.onTestConnectionSuccess.bind(this),this.onError.bind(this));
    }

    //function :: shows alert on test connection success.
    private onTestConnectionSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.TEST_CONNECTION_SUCCESS);
    }

    // function :: notify that grid is ready.
    private notifySyncHCU($event): void {
        this.hcuTabDataService
            .hcuSyncClock($event.elementId)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.onSyncHCUSuccess.bind(this), this.onError.bind(this));
    }
    //function :: on success of sync api.
    private onSyncHCUSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.HCU_SYNC_SUCCESS);
    }

    // function :: notify that grid is ready.
    private notifyRebootHCU($event): void {
        this.sweetAlert.showConformationAlert(ALERT_INFO, this.HCU_REBOOT_TITLE, this.HCU_REBOOT_CONFIRM_MSG, true, true, CommonStrings.OK, CommonStrings.CANCEL,
            (isConfirm) => {
                if (isConfirm) {
                    this.hcuTabDataService
                        .hcuReboot(this.getHcuIds($event.selectedData))
                        .pipe(takeUntil(this.ngUnsubscribe))
                        .subscribe(this.onRebootSuccess.bind(this) ,this.onError.bind(this));
                }
            }
        );
    }

    private getHcuIds(selectedData: any[]): number[] {
        const hcuIds: number[] = [];
        selectedData.forEach((data: any) => {
            hcuIds.push(data.elementId);
        });
        return hcuIds;
    }

    // function :: notify that grid is ready.
    private notifyRestoreHCU($event): void {
        this.sweetAlert.showConformationAlert(ALERT_INFO, this.HCU_RESTORE_TITLE, this.HCU_RESTORE_CONFIRM_MSG, true, true, CommonStrings.OK, CommonStrings.CANCEL,
            (isConfirm) => {
                if (isConfirm) {
                    this.hcuTabDataService
                        .hcuRestore(this.getHcuIds($event.selectedData))
                        .pipe(takeUntil(this.ngUnsubscribe))
                        .subscribe(this.onRestoreSuccess.bind(this), this.onError.bind(this));
                }
            }
        );
    }
    //function :: on reboot scusses
    private onRebootSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.HCU_REBOOT_SUCCESS);
    }
    //function :: on resotore scusses
    private onRestoreSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.HCU_RESTORE_SUCCESS);
    }

    // function :: notify that grid is ready.
    private notifyRepairHCU($event): void {
            this.hcuTabDataService
                .hcuRepair($event.elementId)
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.onRepairSuccess.bind(this), this.onError.bind(this))
    }
    //function :: on repair scusses
    private onRepairSuccess(data:any):void {
        this.showAlert.showSuccessAlert(this.HCU_REPAIR_SUCCESS);
        this.getHCUTabData();
    }

    // function :: notify that grid is ready.
    private notifyViewChannelHCU(selectedData): void {
        this.loadSlider('HCU_MACTRACK_CHANNELS', selectedData);
    }

    private notifyControlFeaturesMacktrak($event){
        this.cmtsTabSharedService.mactrakThresholdFlag = true;
        this.cmtsTabSharedService.bulkModifyFlag = false;
        this.cmtsTabSharedService.selectedCmts = $event;
        let data = $event;
                    let hcuIdArr: any[] = [];
                    let deviceIds: any[] = [];
                    for (let i = 0; i < data.length; i++) {
                        hcuIdArr.push({
                            'id':data[i].elementId,
                            'label': data[i].label
                        });
                        deviceIds.push(
                            data[i].elementId
                        )
        }
        this.hcuSharedService.selectedIds = deviceIds;
        this.hcuSharedService.deviceIds = hcuIdArr;
        this.loadSlider('BULK_EDIT_MACKTRACK_THRESHOLD' , $event);
        //this.LoadViewTab(CmtsControlFeaturesComponent);
    }

    private notifyControlFeaturesMacktrakReset($event){       
        this.sweetAlert.showConformationAlert(ALERT_INFO ,  this.RESET_MACKTRACK_TITLE  , this.RESET_MACKTRACK_CONFIRMATION_MSG  ,true , true, CommonStrings.RESET, CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) { 
                    let data = $event;
                    console.log('$event',$event)
                    let hcuIdArr: number[] = [];
                    for (let i = 0; i < data.length; i++) {
                        hcuIdArr.push(data[i].elementId);
                    }
                    console.log('hcuIdArr',hcuIdArr)
                    var attributeList = ["QP_MARGINAL_THRESHOLD", "QP_FAIL_THRESHOLD"]
                    this.cmtsHttpService.deleteMACTrakThreshold(hcuIdArr,attributeList).subscribe(res =>{})
                }
            }
        ); 
    }

    // function :: notify that grid is ready.
    private notifyFUpgradeHCU($event): void {
        this.loadSlider('HCU_FIRMWARE_UPGRADE' , $event);
    }

    // function :: notify that grid is ready.
    private notifyAddVirtualHCU($event): void {
        if ($event.type == "HCU200" || $event.type == "HCU204") {
            if($event.hsmPresent) {
                this.showInfoAlert(this.VIRTUAL_HSM_TITLE, this.VIRTUAL_HSM_WITH_HCU_MSG);
            }else {
                this.loadSlider('HCU_ADD_VIRTUAL_HSM');
                this.hcuSharedService.setHCUElementId($event.elementId);
            }
            
        } else {
            this.showInfoAlert(this.VIRTUAL_HSM_TITLE, this.VIRTUAL_HSM_OTHERTHAN_200_MSG);
        }
    }

    //function :: shows sweetalert for information.
    private showInfoAlert(Title, Message):void {
        this.sweetAlert.showConformationAlert(ALERT_INFO , Title , Message ,false ,true,CommonStrings.OK ,null,
            (isConfirm)=>{}
        )
    }

    // function :: notify that grid is ready.
    private notifyAddHCU(): void {
        let data: any = { operation: HCUConstants.ADD_OPERATION, cmtsTabModel: null };
        this.hcuSharedService.setHcuViewModelData(data);
        this.loadSlider('HCU_VIEW');
    }

    // function :: notify that grid is ready.
    private notifyImportLblHCU(): void {
        this.fileInput.nativeElement.click();
    }

    //refresh
    public notifyRefreshGrid() {
        this.getHCUTabData();
    }

    //function get callled when input type file selects different file.
    public fileChange(event: any): void {
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let files: any = event.target.files;
        if (files.length) {
            let file;
            file = files[0];
            this.formData.append('file', file);
            this.hcuTabDataService
                .importLabels(this.formData, "hcu")
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.onImportLabelSuccess.bind(this) ,this.onError.bind(this));
        }
    }

    public clearFile(): void{
        let fileInput:any = document.getElementById("fileInput")
        fileInput.value = null;
    }
    // mnethods clears file and get hcudata on import label success.
    private onImportLabelSuccess(data:ImportLabelModel):void {
        this.fileInput.nativeElement.value = "";
        this.showAlert.showSuccessAlert(data.getMessage(this.localeDataService.getLocalizationService()));
        this.getHCUTabData();
    }

    //function called on error of import modem api.
    private onError(error:any):void {
        this.logger.debug(this.tag, "onError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //function :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.translate;
        this.HCU_REBOOT_SUCCESS = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.REBOOT_SUCCESS');
        this.HCU_REPAIR_SUCCESS = localizationService.instant('HCU_REPAIR_SUCCESS');
        this.HCU_RESTORE_SUCCESS = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.RESTORE_SUCCESS');
        this.HCU_SYNC_SUCCESS = localizationService.instant('HCU_SYNC_SUCCESS');
        this.TEST_CONNECTION_SUCCESS = localizationService.instant('TEST_CONNECTION_SUCCESS');
        this.HCU_REBOOT_CONFIRM_MSG = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.REBOOT_CONFIRM_MSG');
        this.HCU_RESTORE_CONFIRM_MSG = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.RESTORE_CONFIRM_MSG');
        this.HCU_REBOOT_TITLE = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.HCU_REBOOT_TITLE');
        this.HCU_RESTORE_TITLE = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.HCU_RESTORE_TITLE');
        this.VIRTUAL_HSM_TITLE = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.VIRTUAL_HSM_TITLE');
        this.VIRTUAL_HSM_OTHERTHAN_200_MSG = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.VIRTUAL_HSM_OTHERTHAN_200_MSG');
        this.VIRTUAL_HSM_WITH_HCU_MSG = localizationService.instant('ALERT_MESSAGES.HCU_SECTION.HCU_TAB.VIRTUAL_HSM_WITH_HCU_MSG');

        this.ADD_VIRTUAL_HSM = localizationService.instant('HCU_ADD_VIRTUAL_HSM');
        this.TEST_CONNECTION = localizationService.instant('HCU_TEST_CONNECTION');
        this.SYNC_CLOCK = localizationService.instant('HCU_SYNC_CLOCK');
        this.REBOOT = localizationService.instant('HCU_REBOOT');
        this.RESTORE = localizationService.instant('HCU_RESTORE');
        this.REPAIR = localizationService.instant('HCU_REPAIR');
        this.VIEW_EVENTS = localizationService.instant('HCU_VIEW_EVENTS');
        this.VIEW_MACKTRACK_CHANNELS = localizationService.instant('HCU_VIEW_MACTRAK_CHANNELS');
        this.SET_MACTRAK_THRESHOLD = localizationService.instant('SET_MACTRAK_THRESHOLD');
        this.RESET_MACTRAK_THRESHOLD = localizationService.instant('RESET_MACTRAK_THRESHOLD');

        this.FIRMWARE_UPGRADE = localizationService.instant('HCU_FIRMWARE_UPGRADE');
        this.ADD_HCU = localizationService.instant('HCU_ADD_HCU');
        this.IMPORT_LABELS = localizationService.instant('HCU_IMPORT_LABELS');
        this.GRID_EXPORT_ALL = localizationService.instant('GRID_SECTION.GRID_EXPORT_ALL');
        this.GRID_EXPORT_SELECTED = localizationService.instant('GRID_SECTION.GRID_EXPORT_SELECTED');
        this.GRID_REFRESH = localizationService.instant('GRID_SECTION.GRID_REFRESH');
        this.SHOW_ALL = localizationService.instant('SHOW_ALL');
        this.TABLE_LIST_SHOW_LESS = localizationService.instant('TABLE_LIST_SHOW_LESS');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.RESET_MACKTRACK_TITLE = localizationService.instant('RESET_MACKTRAK_TITLE');
        this.RESET_MACKTRACK_CONFIRMATION_MSG = localizationService.instant('RESET_MACKTRACK_CONFIRMATION_MSG');

    }


    //Method to clear other components
    private loadSlider(HCUSlider: string , data?:any ): void {
        switch (HCUSlider) {
            case 'HCU_VIEW':
                this.createComponentOnClick(HCUViewComponent);
                break;
            case 'HCU_ADD_VIRTUAL_HSM':
                this.createComponentOnClick(AddVirtualHSM);
                break;
            case 'HCU_MACTRACK_CHANNELS':
                this.createComponentOnClick(HCUMactrakChannel, data);
                break;
            case 'HCU_VIEW_EVENTS':
                this.createComponentOnClick(HCUViewEvent, data);
                break;
            case 'HCU_FIRMWARE_UPGRADE':
                this.createComponentOnClick(FirmwareUpgradeHCU, data);
                break;
            case 'BULK_EDIT_MACKTRACK_THRESHOLD':
                this.createComponentOnClick(HcuBulkEditMacktrakComponent, data);
                break;
            default:
                break;
        }
    }

    //function :: creates component on click.
    private createComponentOnClick(targetComponent: any, data?:any): void {
        this.clearSlider();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        let cmpRef =  this._targetHCUSlider.createComponent(factory);
        cmpRef.instance.childData = data;
    }
    
    //methods clear slider.
    private clearSlider():void {
        this._targetHCUSlider.clear();
    }

    /* Method get called when we come in HCU tab after switch the tab */
    public onTabSwitch(): void{
        this.getHCUTabData();
    }


}
