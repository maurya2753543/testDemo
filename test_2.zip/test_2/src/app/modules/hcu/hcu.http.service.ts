/**
 * Created by Prayoosh.Rawane on 6/30/2017.
 */

import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/http.service";
import {HCUUrlService} from "./hcu.url.service";
import {Observable} from "rxjs";
import {RpmDetailsModel} from "./rpm-Tab/models/rpm-details.model";
import {LIMIT} from "./hcu.constants";
import { MonitoringTabPlanModel } from "./monitoring-tab/model/monitoringplan.model";

@Injectable()
export class HCUHttpService{

    constructor(private httpService: HttpService, private hcuUrlService: HCUUrlService){

    }

    /*---------HCU tab http services starts------------------*/

    public getAllHcuTabList(showAll:boolean): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getHCUTabListUrl().concat(showAll ? "" : LIMIT));
    }

    public getEventsListData(elementID: any, type: string): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getEventListUrl(elementID, type));
    }

    public hcuImportLabels(file: any, type: string):Observable<any> {
        return this.httpService.POSTFILEDATA(this.hcuUrlService.getHCUImportLabelUrl(type), file);
    }

    public hcuReboot(elementId):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getHCURebootUrl(), elementId);
    }

    public hcuVerify(hostName:any):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.verifyHCUUrl(hostName), {});
    }

    public addHCU(hcuDataObj): Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getAddHCUUrl(),hcuDataObj);
    }

    public hcuRestore(hcuIds):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getRestoreHCUUrl(), hcuIds);
    }
    public hcuSyncClock(elementId):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getSyncClockHCUUrl(elementId), {});
    }
    public hcuRepair(elementId):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getRepairHCUUrl(elementId), {});
    }

    public hsmRepair(elementId):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getRepairHSMUrl(elementId), {});
    }

    public getHCUDetails(elementId):Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getHCUDetailsUrl(elementId));
    }

    public editHCU(data:any):Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getEditHCUUrl(), data)
    }

    public deleteHCU(elementId):Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.getDeleteHCUUrl(elementId));
    }

    public deleteBroadcastHSM(elementId):Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.getDeleteBroadcastHSMUrl(elementId));
    }

    public testConnectionHCU(elementID):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getPingHCUUrl(elementID),{});
    }

    public getPhysicalHSMs():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getPhysicalHSMUrl());
    }

    public createVirtualHSM(virtualHSMObj:any):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getCreateVirtualHSMUrl(),virtualHSMObj);
    }

    public getFirmwareUpgradeList():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getFirmwareUpgradeListUrl());
    }

    public checkNewFirmwareRelease():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.checkNewFirmwareReleaseUrl());
    }

    public downloadUpgradedFirmware():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.downloadUpgradedFirmwareUrl());
    }

    public getLatestFirmwarePackage():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getLatestFirmwarePackageUrl());
    }

    public deleteFirmwarePackage(packageVersion):Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.getDeleteFirmwarePackageUrl(packageVersion));
    }

    public upgradeFirmwareHCU(packageVersion, HCUObject):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.upgradeFirmwareHCUrl(packageVersion), HCUObject);
    }

    public viewMACTrakChannels(elementId):Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getMACTrakChannelsUrl(elementId));
    }

    public performUCDScan(hcuIds:any):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getUCDScanUrl(),hcuIds);
    }

    /* Return to get measurement units from server*/
    public getMeasurement() : Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getMeasurementUrl());
    }

    public getMacktrakThreshold(): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getMacktrakThresholdUrl());
    }

    public updateMACTrakBulkThreshold(deviceIds :number[], newStressedThreshold, newFailThreshold) : Observable<any>  {
        var data = {
             "deviceIds": deviceIds,
             "settings": {
                "QP_MARGINAL_THRESHOLD": newStressedThreshold,
                "QP_FAIL_THRESHOLD": newFailThreshold
            }
         }
        return this.httpService.POST(this.hcuUrlService.updateMACTrakBulkThresholdUrl(),data);
    }  


    /*---------HCU tab http services ends------------------*/

    /*---------RPM tab http services starts------------------*/

    public getAllRPMTabList(showAll: boolean): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getRPMUrl("").concat(showAll ? "" : LIMIT));
    }

    public getRPMEventList(elementId: number, type): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getRPMEventListUrl(elementId, type));
    }

    public uploadLicense(file: any): Observable<any> {
        return this.httpService.POSTFILEDATA(this.hcuUrlService.getUploadLicenseUrl(), file);
    }

    public getRpmDetails(elementId: number): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getRPMUrl("/".concat(elementId.toString())));
    }

    public repairRPM(elementId: number): Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getRPMUrl("/".concat(elementId.toString() , "/repair")), elementId);
    }

    public deleteRPM(elementId: number): Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.getRPMUrl("/".concat(elementId.toString())));
    }

    public updateRPM(data: RpmDetailsModel): Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getRPMUrl(""), data);
    }

    /*---------RPM tab http services ends------------------*/

    /*---------PORT tab http services starts------------------*/

    public getAllPORTTabList(showAll: boolean): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getPORTTabListUrl().concat(showAll ? "" : LIMIT));
    }

    public getPortDetails(elementId):Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getPortDetailsUrl(elementId));
    }

    public editPort(data:any):Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getEditPortUrl(), data);
    }

    public getBroadcastStatusForPort(elementId):Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getBroadcastUrl(elementId));
    }

    public enableBroadcastOnPort(elementId, data:any):Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getBroadcastUrl(elementId), data);
    }

    public removeBroadcastOnPort(elementId):Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.getBroadcastUrl(elementId));
    }

    public getMonitoringPlanSettings(portId):Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getMonitoringPlanUrl(portId));
    }

    public putMonitoringPlanSettings(data):Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getMonitoringPlanUrl(data.elementId), data);
    }

    public exportMonitoringPlan(portId):Observable<any> {
        return this.httpService.GETBLOB(this.hcuUrlService.getMonitoringExportPlanUrl(portId));
    }

    public importMonitoringPlan(formData):Observable<any> {
        return this.httpService.POSTFILEDATA(this.hcuUrlService.getMonitoringImportPlanUrl(), formData);
    }

    public pasteMonitoringPlan(data):Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getMonitoringPlanPasteUrl(), data);
    }

    public getThresholdLabels():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getThresholdLabelsUrl());
    }

    public portRepair(portId):Observable<any> {
        return this.httpService.POST(this.hcuUrlService.getPortRepairUrl(portId),{});
    }

    public getUserDefined():Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getUserDefinedUrl());
    }
    /*---------PORT tab http services ends------------------*/

    /*---------HSM tab http services starts------------------*/

    public getAllHSMTabList(showAll:boolean): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getHSMTabListUrl().concat(showAll ? "" : LIMIT));
    }

    public getAllViewPortBCList(hsmID): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getAllViewPortBCListUrl(hsmID));
    }

    public getHSMDetailData(elementId): Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getHSMDetailDataUrl(elementId));
    }

    public updateHSMData(data): Observable<any> {
        return this.httpService.PUT(this.hcuUrlService.getEditHSMUrl(), data);
    }

    public deleteHSM(elementId): Observable<any> {
        return this.httpService.DELETE(this.hcuUrlService.deleteHSMUrl(elementId));
    }

    public hsmImportLabels(file):Observable<any> {
        //TODO:: http service for import labels needs to add.
        //
        return this.httpService.GET(this.hcuUrlService.getHSMImportLabelsUrl())
    }

    /*---------HSM tab http services ends------------------*/


     /*---------Monitoring Tab http services starts------------------*/

    public getMonitoringPlanDetails() : Observable<any> {
        return this.httpService.GET(this.hcuUrlService.getMonitoringPlanTabUrl());
    }

    public updateMplanName(data: MonitoringTabPlanModel): Observable<any> {
        return this.httpService.POST(this.hcuUrlService.updateMplanNameUrl(), data);
    }

    public getMonitoringPlanDownload(elementId) : Observable<any> {
        return this.httpService.GETBLOB(this.hcuUrlService.getMonitoringPlanDownloadUrl(elementId));
    }    
/*---------Monitoring Tab http services ends------------------*/




}
