import {Injectable} from '@angular/core';
import {Observable} from "rxjs";
import {HttpResponse} from "@angular/common/http";
import {map, catchError} from "rxjs/operators";
import {HCUHttpService} from "../hcu.http.service";
import {RpmModel} from "./models/rpm.model";
import {UploadLicenseModel} from "./models/upload-license.model";
import {RpmDetailsModel} from "./models/rpm-details.model";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ViewEventsModel} from '../../shared/common-components/models/viewEvents.model';
import { _throw } from 'rxjs/observable/throw';

@Injectable()

export class RPMTabDataService {

    private rpmList: RpmModel[] = [];
    private uploadLicenseList: any[] = [];
    private localService: any;
    public rpmtabfilterchangedata: any;

    constructor(private hcuHttpService:HCUHttpService, private localeDataService: LocaleDataService){
        this.localService = this.localeDataService.getLocalizationService();
    }

    //@method :: get all CMTS list from API
    public getAllRpmTabList(showAll: boolean): Observable<any> {
        return this.hcuHttpService
            .getAllRPMTabList(showAll)
            .pipe(map((rpmTabListDataObj) => {
                return this.processRPMList(rpmTabListDataObj);
            }),
            catchError(this.handleError))
    }

    //@method :: get all RPM list from API
    public getRpmEventList(elementId: number, type): Observable<any> {
        return this.hcuHttpService
            .getRPMEventList(elementId, type)
            .pipe(map((rpmEventListDataObj) => {
                return this.processRPMEventList(rpmEventListDataObj);
            }),
            catchError(this.handleError))
    }


    //@method :: get all RPM list from API
    public uploadLicense(file: any): Observable<any> {
        return this.hcuHttpService
            .uploadLicense(file)
            .pipe(map((rpmEventListDataObj) => {
                return this.processUploadLicense(rpmEventListDataObj);
            }),
            catchError(this.handleError))
    }

    //@method :: get all RPM list from API
    public getRpmDetails(elementId: number): Observable<any> {
        return this.hcuHttpService
            .getRpmDetails(elementId)
            .pipe(map((rpmEventListDataObj: HttpResponse<any>) => {
                return rpmEventListDataObj;
            }),
            catchError(this.handleError))
    }

    //@method :: get all RPM list from API
    public rpmRepair(elementId: number): Observable<any> {
        console.log("rpm repair",elementId);
        return this.hcuHttpService
            .repairRPM(elementId)
            .pipe(map((response: HttpResponse<any>) => {
                return response;
            }),
            catchError(this.handleError))
    }

    //@method :: get all RPM list from API
    public deleteRPM(elementId: number): Observable<any> {
        return this.hcuHttpService
            .deleteRPM(elementId)
            .pipe(map((response: HttpResponse<any>) => {
                return response;
            }),
            catchError(this.handleError))
    }

    //@method :: get all RPM list from API
    public updateRPM(data: RpmDetailsModel): Observable<any> {
        return this.hcuHttpService
            .updateRPM(data)
            .pipe(map((response: HttpResponse<any>) => {
                return response;
            }),
            catchError(this.handleError))
    }


    //@method :: process deploy license api response into models
    private processUploadLicense(response: any[]): any[]{
        this.uploadLicenseList.length = 0;
        response.forEach((obj: any)=>{
            this.uploadLicenseList.push(new UploadLicenseModel(obj, this.localService));
        });
        return this.uploadLicenseList;
    }

    private processRPMEventList(response: any[]): any[]{
        return new ViewEventsModel(response, this.localService);
    }

    //@method :: process deploy license api response into models
    private processRPMList(response: any[]): any{
        this.rpmList.length = 0;
        response["rpmList"].forEach((obj: any)=>{
            this.rpmList.push(new RpmModel(obj, this.localService));
        });
        return {"rpmModels": this.rpmList, isShowAll: ! (this.rpmList.length === response["totalCount"]), totalCount:response['totalCount']};
    }

    //Error handler
    public handleError(error) {
        return _throw(error);
    }
}
