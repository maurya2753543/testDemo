import {Injectable} from "@angular/core";

@Injectable()
export class RpmTabService {
    private newAlarmsAvailable : boolean;
    private totalNumberOfAlarms : number;
    private mostRecentAlarmDate : string;
    private alarms : Array<{}>;

   /*
   *@name getAlarmData
   *@desc gets alarms list response
   *@return any
   */
    public getAlarmData():any{
        return {
            "newAlarmsAvailable" : this.newAlarmsAvailable,
            "totalNumberOfAlarms" : this.totalNumberOfAlarms,
            "mostRecentAlarmDate" : this.mostRecentAlarmDate,
            "alarms" : this.alarms,
            
        };
    }
}