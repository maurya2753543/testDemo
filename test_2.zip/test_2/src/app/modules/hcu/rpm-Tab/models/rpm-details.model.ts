/*
 * Created by yogesh.paisode on 7/18/2017.
 */
import {ONLINE} from "../../hcu.constants";
export class RpmDetailsModel{

    public elementId: number;
    public created: string;
    public status:string;
    public modified: string;
    public label: string;
    public location: string;
    public notes: string;
    public olVersion: number;
    public alarmsEnabled: boolean;
    public thresholdsEnabled: boolean;
    public parentAlarmsEnabled: boolean;
    public parentThresholdsEnabled: boolean;
    public slotNumber: number;
    public serialNumber: string;
    public modelNumber: string;
    public minFrequency: number;
    public maxFrequency: number;
    public firmwareRev: string;
    public calibrationDate: string;
    public calibrationDueDate: string;
    public testPointComp: number|string;
    public attenuation: number|string;
    public rpmOptionList: any; //Todo :: replace with proper type
    public setTestPointCompForAllPorts: boolean;
    public setAttenuationForAllPorts: boolean;

    //@method :: set data
    public setData(obj: any , localizationService): void{
        this.elementId  = obj.elementId;
        this.status = obj.status ? (obj.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()).toUpperCase() : localizationService.instant(obj.status.toUpperCase()).toUpperCase():null;
        this.created  = obj.created;
        this.modified  = obj.modified;
        this.label  = obj.label;
        this.location  = obj.location;
        this.notes  = obj.notes;
        this.olVersion  = obj.olVersion;
        this.alarmsEnabled  = obj.alarmsEnabled;
        this.thresholdsEnabled  = obj.thresholdsEnabled;
        this.parentAlarmsEnabled  = obj.parentAlarmsEnabled;
        this.parentThresholdsEnabled  = obj.parentThresholdsEnabled;
        this.slotNumber  = obj.slotNumber;
        this.serialNumber  = obj.serialNumber;
        this.modelNumber  = obj.modelNumber;
        this.minFrequency  = obj.minFrequency;
        this.maxFrequency  = obj.maxFrequency;
        this.firmwareRev  = obj.firmwareRev;
        this.calibrationDate  = obj.calibrationDate;
        this.calibrationDueDate  = obj.calibrationDueDate;
        this.testPointComp  = obj.testPointComp;
        this.attenuation  = obj.attenuation;
        this.rpmOptionList  = obj.rpmOptionList;
        this.setTestPointCompForAllPorts  = obj.setTestPointCompForAllPorts;
        this.setAttenuationForAllPorts  = obj.setAttenuationForAllPorts;
    }

    //@method :: reset data
    public resetData(): void{
        this.elementId  = 0;
        this.created  = "";
        this.modified  = "";
        this.label  = "";
        this.location  = "";
        this.notes  = "";
        this.olVersion  = 0;
        this.alarmsEnabled  = false;
        this.thresholdsEnabled  = false;
        this.parentAlarmsEnabled  = false;
        this.parentThresholdsEnabled  = false;
        this.slotNumber  = 0;
        this.serialNumber  = "";
        this.modelNumber  = "";
        this.minFrequency  = 0;
        this.maxFrequency  = 0;
        this.firmwareRev  = "";
        this.calibrationDate  = "";
        this.calibrationDueDate  = "";
        this.testPointComp  = 0.0;
        this.attenuation  = 0;
        this.rpmOptionList  = null;
        this.setTestPointCompForAllPorts  = false;
        this.setAttenuationForAllPorts  = false;
    }
}