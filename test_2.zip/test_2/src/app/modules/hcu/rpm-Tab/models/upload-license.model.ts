/**
 * Created by yogesh.paisode on 7/17/2017.
 */
import {N_A, ONLINE} from "../../hcu.constants";

export class UploadLicenseModel{

    public rpmLicenseStatusEnum: string;
    public elementId: number;
    public status: string;
    public label: string;
    public hcu_label: string;
    public serialNumber: string;
    public modelNumber: string;
    public slotNumber: number;
    public firmwareRev: string;

    public qamTrak: string = N_A;
    public macTrak: string = N_A;
    public macTrakMonitoring: string = N_A;
    private _KEYS: string[] = ["QAMTrak", "MACTrak", "MACTrak_Monitoring"];
    private rpmOptionList: any;
    
    constructor(obj: any, localizationService: any){
        this.rpmLicenseStatusEnum = obj.rpmLicenseStatusEnum;
        obj = obj["rpmResponse"];
        this.elementId = obj.elementId;
        this.status = localizationService.instant(this.rpmLicenseStatusEnum.toUpperCase());
        this.label = obj.label;
        this.hcu_label = obj.hcu_label;

        this.serialNumber = obj.serialNumber;
        this.modelNumber = obj.modelNumber;
        this.slotNumber = obj.slotNumber;
        this.firmwareRev = obj.firmwareRev;
        this.rpmOptionList = obj.rpmOptionList;
        this.processApp();
    }

    //@method :: process name from keys
    private processApp(): void{
        if(this.rpmOptionList){
            this._KEYS.forEach((obj: string)=>{
                for(let i = 0; i < this.rpmOptionList.length; i ++){
                    if(this.rpmOptionList[i]["rpmOptionName"].toLowerCase() === obj.toLowerCase()){
                        let type: string = this.rpmOptionList[i]["rpmOptionType"];
                        switch (obj){
                            case this._KEYS[0] :
                                this.qamTrak = type;
                                break;
                            case this._KEYS[1] :
                                this.macTrak = type;
                                break;
                            case this._KEYS[2] :
                                this.macTrakMonitoring = type;
                                break;
                        } // End of Switch
                    }// End of If
                }// End of For Loop
            });// End of For Each
        }
    }// End of Method
}