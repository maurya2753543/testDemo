/*
 * Created by yogesh.paisode on 7/12/2017.
 */
import {N_A, ONLINE} from "../../hcu.constants";

export class RpmModel{

    public elementId: number;
    public status: string;
    public label: string;
    public hcu_label: string;
    public serialNumber: string;
    public modelNumber: string;
    public slotNumber: number;
    public firmwareRev: string;
    public rpmOptionList: any[];
    public qamTrak: string = N_A;
    private macTrak: string = N_A;
    private macTrakMonitoring: string = N_A;
    private _KEYS: string[] = ["QAMTrak", "MACTrak", "MACTrak_Monitoring"];

    constructor(obj: any, localizationService: any){
        if(obj){
            this.elementId = obj.elementId;
            this.status = (obj.status.toLowerCase() === "ok") ? localizationService.instant(ONLINE.toUpperCase()) : localizationService.instant(obj.status.toUpperCase());
            this.status = this.status.toUpperCase();
            this.label = obj.label;
            this.hcu_label = obj.hcu_label;
            this.serialNumber = obj.serialNumber;
            this.modelNumber = obj.modelNumber;
            this.slotNumber = obj.slotNumber;
            this.firmwareRev = obj.firmwareRev;
            this.rpmOptionList = obj.rpmOptionList;
            this.processApp(localizationService);
        }
    }

    //@method :: process names from keys
    private processApp(localizationService: any): void{
        if(this.rpmOptionList){
            this._KEYS.forEach((obj: string)=>{
                for(let i = 0; i < this.rpmOptionList.length; i ++){
                    if(this.rpmOptionList[i]["rpmOptionName"].toLowerCase() === obj.toLowerCase()){
                        let type: string = localizationService.instant(this.rpmOptionList[i]["rpmOptionType"].toUpperCase());
                        switch (obj){
                            case this._KEYS[0] :
                                this.qamTrak = type;
                                break;
                            case this._KEYS[1] :
                                this.macTrak = type;
                                break;
                            case this._KEYS[2] :
                                this.macTrakMonitoring = type;
                                break;
                        } // End of Switch
                    }// End of If
                }// End of For Loop
            });// End of For Each
        }
    }// End of Method
}