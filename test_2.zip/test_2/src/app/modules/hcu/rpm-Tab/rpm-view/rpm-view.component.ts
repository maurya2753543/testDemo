/**
 * Created by yogesh.paisode on 7/17/2017.
 */
import {Component, Input, OnDestroy} from "@angular/core";

import {HCUSharedService} from "../../hcu.shared.service";
import {RpmDetailsModel} from "../models/rpm-details.model";
import {RPMTabDataService} from "../rpmtab.data.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {SharedService} from "../../../../shared/shared.service";
import {CommonStrings} from "../../../../constant/common.strings";
import {ALERT_INFO, ALERT_SUCCESS} from "../../../../constant/app.constants";
import {SweetAlert} from "../../../../utilities/sweetAlert";
import {LocaleDataService} from "../../../../shared/locale.data.service";

@Component({
    selector: 'rpm-view',
    templateUrl: 'rpm-view.component.html'
})
export class RpmViewComponent implements OnDestroy{
    public isReadOnlyRPM: boolean = true;
    private dataModel: any;
    public rpmDetailsModel: RpmDetailsModel;

    private RPM_EDIT_SUCCESS: string = "";
    private RPM_DELETE_SUCCESS: string = "";
    private RPM_DELETE_CONFORMATION_TITLE: string = "";
    private RPM_DELETE_CONFORMATION_MESSAGE: string = "";
    private attenuationStep: number = 10;
    private _RPM3000: string = "RPM3000";
    public isCloseRightSlider:boolean = false;
    private DOT: string = "";
    private statusData:string;

    @Input('childData') childData: any;

    constructor(private hcuSharedService: HCUSharedService,
                private rpmTabDataService: RPMTabDataService,
                private showAlert: ShowAlert,
                private sharedService: SharedService,
                private sweetAlert: SweetAlert,
                private localeDataService: LocaleDataService){
        this.rpmDetailsModel = hcuSharedService.getRpmDetailsModel();
    }

    ngOnInit(){
        this.getLocalizeDOT();
        this.translateLocaleString();
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
        this.setData();
    }

    private getLocalizeDOT() : void {
        this.DOT = this.sharedService.getLocalizeDot();
    }


    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.closeSlider(true);
        })
    }

    ngOnDestroy() {
        this.rpmDetailsModel.resetData();
    }

    //@method :: set data to local model
    private setData(): void{
        this.dataModel = this.childData;
        if(this.dataModel.modelNumber.toLowerCase() === this._RPM3000.toLowerCase()){
            this.attenuationStep = 1;
        }
        this.setRpmData(this.dataModel);
    }

    //@method :: ser RPM model
    private setRpmData(response: any): void{
        this.rpmDetailsModel.setData(response,this.localeDataService.getLocalizationService());

        this.rpmDetailsModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(this.rpmDetailsModel.attenuation, this.DOT);
        this.rpmDetailsModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(this.rpmDetailsModel.testPointComp, this.DOT);
    }

    //@method :: delete RPM
    public deleteData(): void{
        this.sweetAlert.showConformationAlert(ALERT_INFO ,this.RPM_DELETE_CONFORMATION_TITLE ,this.RPM_DELETE_CONFORMATION_MESSAGE ,true ,true,CommonStrings.OK ,CommonStrings.CANCEL,
            (isConfirm)=>{
                if (isConfirm) {
                    this.rpmTabDataService.deleteRPM(this.rpmDetailsModel.elementId).subscribe(()=>{
                        this.showSuccessAlert(this.RPM_DELETE_SUCCESS);
                    }, this.onError.bind(this));
                }
            }
        );
    }

    //@method :: Save the changes
    public onSubmit(): void{
        this.statusData = this.rpmDetailsModel.status;
        delete this.rpmDetailsModel.status;

        let tpc: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.rpmDetailsModel.testPointComp, this.DOT);
        this.rpmDetailsModel.testPointComp = parseFloat(tpc);

        let attenuation: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.rpmDetailsModel.attenuation, this.DOT);
        this.rpmDetailsModel.attenuation = parseFloat(attenuation);

        this.rpmTabDataService.updateRPM(this.rpmDetailsModel).subscribe(()=>{
            this.showSuccessAlert(this.RPM_EDIT_SUCCESS);
        },this.onError.bind(this));
    }

    //@method :: Show success sweet alert
    private showSuccessAlert(successMsg: string): void{
        this.sweetAlert.showAlert(ALERT_SUCCESS, successMsg,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
            (isConfirm)=>{
                if(isConfirm){
                    this.closeSlider(true);
                }
            });
    }

    //@method :: change to read-write mode
    public toggleEdit(): void{
        this.isReadOnlyRPM = false;
    }

    //Handle error
    private onError(error): void{
        this.rpmDetailsModel ? this.rpmDetailsModel.status = this.statusData : '';
        //Delay is require to show second sweet alert
        //as we can not show two sweet alert at a time
        //wait for 2ms to let 1st sweet alert to removed.
        setTimeout(() => {
            this.showAlert.showErrorAlert(error);
        }, 200);
    }

    //@method :: Restrict label text to 100 character
    public processLabel(): void{
        this.rpmDetailsModel.label = this.sharedService.restrictTo100(this.rpmDetailsModel.label);
    }

    //@method :: Restrict TPC in range
    private processTPC(): void{
        this.processTpcValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.rpmDetailsModel.testPointComp, this.DOT);
        //Process value for MIN MAX
        let tpc: string = this.sharedService.processTpcMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.rpmDetailsModel.testPointComp = this.sharedService.replaceDefaultDotWithLocalizeDot(tpc, this.DOT);
    }

    private processTpcValue(): void{
        this.rpmDetailsModel.testPointComp = this.sharedService.processNumber(this.rpmDetailsModel.testPointComp, this.DOT);
    }


    //@method :: Restrict Attenuation in range
    private processAttenuation(): void{
        this.processAttenuationValue();
        //Restore default dot "."
        let localizeDotToDefaultDot: string = this.sharedService.replaceLocalizeDotWithDefaultDot(this.rpmDetailsModel.attenuation, this.DOT);
        //Process value for MIN MAX
        let attenuation: string = this.sharedService.processAttenuationMaxMin(parseFloat(localizeDotToDefaultDot)).toString();
        //Convert DOT to Localized DOT
        this.rpmDetailsModel.attenuation = this.sharedService.replaceDefaultDotWithLocalizeDot(attenuation, this.DOT);
    }

    private processAttenuationValue(): void{
        this.rpmDetailsModel.attenuation = this.sharedService.processNumber(this.rpmDetailsModel.attenuation, this.DOT);
    }

    //@method :: close UI side panel
    public closeSlider(refreshList: boolean) : void {
        this.isCloseRightSlider = true;
        this.hcuSharedService.getClearRpmEditComponentSubject().next(refreshList);
    }

    //@method :: used for localization
    private translateLocaleString():void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.RPM_EDIT_SUCCESS = localizationService.instant('RPM_EDIT_SUCCESS');
        this.RPM_DELETE_SUCCESS = localizationService.instant('RPM_DELETE_SUCCESS');
        this.RPM_DELETE_CONFORMATION_TITLE = localizationService.instant('RPM_DELETE_CONFORMATION_TITLE');
        this.RPM_DELETE_CONFORMATION_MESSAGE = localizationService.instant('RPM_DELETE_CONFORMATION_MESSAGE');
    }
}
