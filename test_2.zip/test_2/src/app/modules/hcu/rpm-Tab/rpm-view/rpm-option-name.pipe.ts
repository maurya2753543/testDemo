import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'rpmOptionNamePipe'})
export class RpmOptionNamePipe implements PipeTransform {
    transform(name: any): any {
        if (!name) return name;
        return this.processName(name);
    }

    //@method :: process keys to values
    private processName(rpmOptionName: string): string{
        let name;
        switch (rpmOptionName){
            case "Spectrum_Viewer" :
                name = "Spectrum Viewer&trade;";
                break;
            case "QAMTrak" :
                name = "QAMTrak&trade;";
                break;
            case "MACTrak" :
                name = "MACTrak&trade;";
                break;
            case "MACTrak_Monitoring" :
                name = "MACTrak&trade; Monitoring";
                break;
            default :
                name = "--";
        }
        return name;
    }
}