import {Component, ComponentFactoryResolver, ElementRef, ViewChild, ViewContainerRef} from '@angular/core';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { Grid } from "../../../shared/ag-grid.options"
import { RPMTabDataService } from './rpmtab.data.service';
import { RPMTabColumnDefinitionService } from "./rpmtab.column-definition.service";
import {HCUSharedService} from "../hcu.shared.service";
import {ViewEventsComponentRPM} from "./rpm-view-events/rpm-view-events.component";
import {DeployLicenseComponent} from "./rpm-deploy-license/deployLicense.component";
import {RpmViewComponent} from "./rpm-view/rpm-view.component";
import {ShowAlert} from "../../../utilities/showAlert";
import {RpmModel} from "./models/rpm.model";
import {HCUTabDataService} from "../hcu-tab/hcutab.data.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ImportLabelModel} from "../importLabel.model";
import {AgGridConfigurationService} from "../../../shared/agGrid.configuration.service";
import {PAGE_LIMIT} from "../hcu.constants";
import {NAV_LINK_HCU} from "../../../constant/app.constants";
import {SharedService} from '../../../shared/shared.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'rpmtab-component',
    templateUrl: 'rpmtab.component.html'
})

export class RPMTabComponent {
    public rpmTabGridOptions: Grid = new Grid();
    public rowdata: RpmModel[];
    public eventKeys: Object[];
    private hcuFilterInstance: any;
    private rpmFilterInstance: any;
    public buttonKeys: Object[];
    public refreshBtnFlag:boolean;
    private formData = new FormData();
    public gridTabType:string = "RPMExport";
    private REPAIR_TEXT: string = "";
    private VIEW_EVENT_TEXT: string = "";
    private EXPORT_SELECTED_TEXT: string = "";
    private EXPORT_ALL_TEXT: string = "";
    private IMPORT_LABELS_TEXT: string = "";
    private DEPLOY_LICENSE_TEXT: string = "";
    private REPAIRED_SUCCESS: string = "";
    private SHOW_LESS:string = "";
    private SHOW_ALL: string = "Show All";
    private showAll: boolean = true;
    private DEFAULT_BUTTONS: any[];
    private _RPM_TAB: string = "RPM_TAB";
    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    private showAllBtn: Object[] = [];

    @ViewChild('rpmView', { read: ViewContainerRef }) _rpmViewEvents;
    @ViewChild('fileInput') fileInput: ElementRef;

    private ngUnsubscribe:Subject<void> = new Subject<void>();

    constructor(private rpmTabColumnDefinitionService: RPMTabColumnDefinitionService,
                private rpmTabDataService: RPMTabDataService,
                private hcuSharedService: HCUSharedService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private hcuTabDataService: HCUTabDataService,
                private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private sharedService:SharedService,
                private translate : TranslateService,
                private agGridConfigurationService: AgGridConfigurationService) {
                    this.translate.onLangChange.subscribe((response) => {
                        this.translateLocaleString();
                    });
                }

    ngOnInit(){
        this.rpmViewSubjectListener();
        this.clearRpmEditComponentSubjectListener();
        this.translateLocaleString();
        if(this.sharedService.RetainFilter){
            this.rpmTabDataService.rpmtabfilterchangedata = "";
            this.hcuSharedService.modeldata = "";
            this.hcuSharedService.modeldata1 = "";
        }
    }

    //@method :: set button keys
    private setEventButtonKeys():void {
        this.eventKeys = [
            {name: this.REPAIR_TEXT,status:'only-single', tabType: this._RPM_TAB, disable:false, KEY : NAV_LINK_HCU},
            {name: this.VIEW_EVENT_TEXT,status:'only-single', tabType: this._RPM_TAB},
            {name: this.EXPORT_SELECTED_TEXT,status:'single', tabType: this._RPM_TAB},
            {name: this.EXPORT_ALL_TEXT,status:'all', tabType: this._RPM_TAB},
        ];
        this.buttonKeys = this.getDeepCopy(this.DEFAULT_BUTTONS);
        this.refreshBtnFlag = true;
    }

    //@method :: register event emitter
    public notifyActionEmitter($event) : void{
        switch ($event.event.name) {
            case this.REPAIR_TEXT:
                this.notifyRepair($event.selectedData[0]);
                break;
            case this.IMPORT_LABELS_TEXT:
                this.notifyImportLabel();
                break;
            case this.DEPLOY_LICENSE_TEXT:
                this.notifyDeployLicense();
                break;
            case this.VIEW_EVENT_TEXT:
                this.notifyViewEvent();
                break;
            case this.SHOW_ALL:
                this.notifyShowAllEvent();
                break;
            case this.SHOW_LESS:
                this.notifyShowLessEvent();
                break;
            default:
        }
    }

    //@event :: Filter changed
    public notifyFilterChangeRPM(e: any): void{
        this.sharedService.RetainFilter = false;
        const countryFilterComponent = this.rpmTabGridOptions.api.getFilterInstance('hcu_label');
        const rpmmodel = countryFilterComponent.getModel();
        this.hcuSharedService.modeldata = rpmmodel;
        const countryFilterComponent1 = this.rpmTabGridOptions.api.getFilterInstance('label');
        const rpmmodel1 = countryFilterComponent1.getModel();
        this.hcuSharedService.modeldata1 = rpmmodel1;
        
        // this.hcuSharedService.getNameFilterText(this.hcuFilterInstance, "hcu");
        // this.hcuSharedService.getNameFilterText(this.rpmFilterInstance, "rpm");
        this.rpmTabDataService.rpmtabfilterchangedata = this.rpmTabGridOptions.api.getFilterModel();
        //this.hcuSharedService.rpmfilterchangedata1 = this.rpmTabGridOptions.api.getFilterModel();
        // const countryFilterComponent = this.rpmTabGridOptions.api.getFilterInstance('hcu');
        // const model = countryFilterComponent.getModel();
        // this.hcuSharedService.modeldata = model;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.rpmTabGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //@listener :: UI changed event listener
    private rpmViewSubjectListener(): void{
        this.hcuSharedService
            .getRpmViewSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((rpmMode: RpmModel)=>{
            this.getRPMDetails(rpmMode);
        });
    }

    private getRPMDetails(rpmMode: RpmModel): void{
        this.rpmTabDataService.getRpmDetails(rpmMode.elementId).subscribe(this.setRpmData.bind(this),this.onError.bind(this));
    }

    //@method :: ser RPM model
    private setRpmData(response: any): void{
        this.createComponentOnClick(RpmViewComponent, response);
    }

    //@method :: makes api call to get rpm data.
    public getRPMTabData():void {
        if(this.rpmTabGridOptions.api){
            if (this.sharedService.getFilterAlarmForTAB().length > 0) {
                this.rpmTabGridOptions.api.getFilterInstance('label').setFilter(this.sharedService.getFilterAlarmForTAB());
                this.sharedService.setFilterAlarmForTab("");
            } else {
                 //this.hcuSharedService.applyNameFilter(this.hcuFilterInstance, "hcu");
                  //this.hcuSharedService.applyNameFilter(this.rpmFilterInstance, "rpm");
            }
            this.rpmTabDataService
                .getAllRpmTabList(this.showAll)
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.setRowData.bind(this),this.onError.bind(this));
        }
        if(this.rpmTabGridOptions.api &&(this.rpmTabDataService.rpmtabfilterchangedata || this.hcuSharedService.modeldata || this.hcuSharedService.modeldata1)){
            if(this.rpmTabDataService.rpmtabfilterchangedata){
                this.rpmTabGridOptions.api.setFilterModel(this.rpmTabDataService.rpmtabfilterchangedata);
          }

            if(this.hcuSharedService.modeldata  || this.rpmTabDataService.rpmtabfilterchangedata) 
            {
                const countryFilterComponent2 = this.rpmTabGridOptions.api.getFilterInstance("hcu_label");
            countryFilterComponent2.setModel(this.hcuSharedService.modeldata);
            
            }
            if(this.rpmTabDataService.rpmtabfilterchangedata ||this.hcuSharedService.modeldata1 )
            {
                
            const countryFilterComponent3 = this.rpmTabGridOptions.api.getFilterInstance("label");
            countryFilterComponent3.setModel(this.hcuSharedService.modeldata1);
            }
                    
                }
    }
    
    //@method :: Set ag-Grid row data
    private setRowData(data: any): void{
        let rowVal = [];
        data.rpmModels.forEach((rpmModel: RpmModel)=>{
            rowVal.push(rpmModel);
        });
        this.totalCount = data.totalCount;
        this.setShowAllLabel(data.rpmModels.length, this.totalCount);
        this.rowdata = rowVal;
        this.rowdata.length > 0 && this.rpmTabGridOptions.api.hideOverlay();
        if(data.isShowAll) {
            this.setShowAllBtn();
        }

        if(data.rpmModels.length > PAGE_LIMIT){
            this.setShowLessBtn();
        }
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //@method :: set showAll btn
    private setShowAllBtn():void {
        let newButtons: any[] = [];
        newButtons.push({name: this.SHOW_ALL, tabType: this._RPM_TAB});
        this.showAllBtn = newButtons;
    }

    //@method :: set showLess btn
    private setShowLessBtn():void {
        let newButtons: any[] = [];
        newButtons.push({name: this.SHOW_LESS, tabType: this._RPM_TAB});
        this.showAllBtn = newButtons;
    }

    //@method :: get Deep copy
    private getDeepCopy(obj: any): any{
        return JSON.parse(JSON.stringify(obj));
    }

    //@method :: notify grid is ready.
    public notifyGridReadyRPM(params:any): void{
        this.setGridColDefinition();
    }

    //@event :: API call to repair selected RPM
    private notifyRepair(data:any): void{
        this.rpmTabDataService
            .rpmRepair(data.elementId)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe(this.handleRepairResponse.bind(this),
            this.onError.bind(this));
    }

    //@method :: Handle repair response
    private handleRepairResponse(response: any): void{
        this.getRPMTabData();
        this.showAlert.showSuccessAlert(this.REPAIRED_SUCCESS);
    }

    //@event :: Show all
    private notifyShowAllEvent(): void{
        this.action(true);
        this.setShowLessBtn();
    }

    private action(showAll: boolean): void{
        this.showLoadingOverlay();
        this.showAll = showAll;
        this.getRPMTabData();
    }

    //@event :: Show less
    private notifyShowLessEvent():void {
        this.action(false);
        this.setShowAllBtn();
    }

    //@event :: Trigger OS selection directory
    private notifyImportLabel(): void{
        this.fileInput.nativeElement.click();
    }

    //@method :: get called when input type file selects different file.
    public fileChange(event: any): void {
        this.formData = new FormData();
        let files: any = event.target.files;
        if (files.length) {
            let file;
            file = files[0];
            this.formData.append('file', file, file.name);
            this.hcuTabDataService
                .importLabels(this.formData, "rpm")
                .pipe(takeUntil(this.ngUnsubscribe))
                .subscribe(this.handleImportLabelResponse.bind(this)
                ,this.onError.bind(this));
        }
    }

    public clearFile(): void{
        let fileInput:any = document.getElementById("fileInput")
        fileInput.value = null;
    }


    //@method :: Handle API respons for import label
    private handleImportLabelResponse(response: ImportLabelModel): void{
        this.fileInput.nativeElement.value = "";
        this.showAlert.showSuccessAlert(response.getMessage(this.localeDataService.getLocalizationService()));
        this.getRPMTabData();
    }

    //@method :: Open Deploy license slider
    private notifyDeployLicense(): void{
        this.createComponentOnClick(DeployLicenseComponent);
    }

    //@method :: Cal view event
    private notifyViewEvent(): void{
        let rows: any = this.rpmTabGridOptions.api.getSelectedNodes();
        if(rows && rows[0]){
            this.hcuSharedService.setRpmElementId(rows[0].data.elementId);
            this.createComponentOnClick(ViewEventsComponentRPM, rows[0].data);
        }
    }

    //@method :: sets column definition to grid.
    private setGridColDefinition(){
        this.showLoadingOverlay();
        this.rpmTabGridOptions.api.setColumnDefs(this.rpmTabColumnDefinitionService.getColumnDef());
        this.hcuFilterInstance = this.rpmTabGridOptions.api.getFilterInstance('hcu_label');
        this.rpmFilterInstance = this.rpmTabGridOptions.api.getFilterInstance('label');
        if(this.hcuSharedService.getHcmFilterText().length > 0){
            this.showAll = true;
        }
        this.getRPMTabData();
        this.rpmTabGridOptions.api.setSortModel([
            {colId: 'hcu_label', sort: 'asc'},
            {colId: 'slotNumber', sort: 'asc'}
        ]);
        this.agGridConfigurationService.afterSortChanged(this.rpmTabGridOptions);
    }

    //@method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.rpmTabGridOptions.api.showLoadingOverlay();
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }

    //refresh
    public notifyRefreshGrid(): void{
        this.getRPMTabData();
    }

    //@method :: creates component on click.
    private createComponentOnClick(targetComponent:any, data?: any):void {
        this.clearComponent();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        this._rpmViewEvents.createComponent(factory).instance.childData = data
    }

    //@method :: Clear component from memory
    private clearComponent(): void{
        this._rpmViewEvents.clear();
    }

    //@listener :: clear component after slider close
    private clearRpmEditComponentSubjectListener(): void{
        this.hcuSharedService
            .getClearRpmEditComponentSubject()
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe((refreshList: boolean)=>{
            this.clearComponent();
            this.refreshAgGrid(refreshList);
        });
    }

    //@method :: refresh ag-Grid list
    private refreshAgGrid(refreshList: boolean): void{
        if(refreshList){
            this.getRPMTabData();
        }
    }

    /* Method get called when we come in RPM tab after switch the tab */
    public onTabSwitch(): void{
        this.getRPMTabData();
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        this.REPAIR_TEXT  = this.translate.instant('HCU_REPAIR');
        this.EXPORT_ALL_TEXT = this.translate.instant('GRID_SECTION.GRID_EXPORT_ALL');
        this.EXPORT_SELECTED_TEXT = this.translate.instant('GRID_SECTION.GRID_EXPORT_SELECTED');
        this.VIEW_EVENT_TEXT = this.translate.instant('HCU_VIEW_EVENTS');
        this.IMPORT_LABELS_TEXT = this.translate.instant('HCU_IMPORT_LABELS');
        this.DEPLOY_LICENSE_TEXT = this.translate.instant('HCU_RPM_TAB_DEPLOY_LICENSE');
        this.REPAIRED_SUCCESS = this.translate.instant('REPAIRED_SUCCESSFULLY');
        this.SHOW_ALL =  this.translate.instant('SHOW_ALL');
        this.SHOW_LESS = this.translate.instant('TABLE_LIST_SHOW_LESS');
        this.TABLE_LIST_SHOWING = this.translate.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = this.translate.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = this.translate.instant('TABLE_LIST_ROWS');
        this.DEFAULT_BUTTONS = [
            {name: this.IMPORT_LABELS_TEXT , tabType: this._RPM_TAB, disable:false, KEY : NAV_LINK_HCU},
            {name: this.DEPLOY_LICENSE_TEXT, tabType: this._RPM_TAB, disable:false, KEY : NAV_LINK_HCU}
        ];
        this.setEventButtonKeys();
    }
}
