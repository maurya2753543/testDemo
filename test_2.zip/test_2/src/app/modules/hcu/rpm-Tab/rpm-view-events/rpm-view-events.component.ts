/**
 * Created by yogesh.paisode on 7/13/2017.
 */
import {Component, Input} from "@angular/core";

import {Grid} from "../../../../shared/ag-grid.options";
import {RPMTabDataService} from '../rpmtab.data.service';
import {ViewEventsColumnDefinitionService} from "../../../shared/common-components/listView/viewEvents.column-definition.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {HCUSharedService} from "../../hcu.shared.service";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SharedService} from "../../../../shared/shared.service";
import {HCUTabDataService} from "../../hcu-tab/hcutab.data.service";
import {RETURN_PATH_MONITOR} from "../../../../constant/app.constants";

@Component({
    selector: 'rpm-view-events',
    templateUrl: '../../../shared/common-components/listView/listView.component.html'
})
export class ViewEventsComponentRPM{
    @Input('childData') childData: any;
    public isCloseRightSlider:boolean;
    public listViewOptions: Grid = new Grid();
    public rowdata:any;
    public buttonKeys: Object[];
    public eventKeys: Object[];
    private TABLE_LIST_EXPORT_ALL:string = "";
    private CLOSE_SLIDER:string = "";
    public gridTabType:string = "RPMEventExport";
    public refreshBtnFlag:boolean = false;
    public headerTxt:string = "";
    private RPM_VIEW_EVENTS_HEADER:string = "";
    private eventList: any[];
    public styleForHeaderBtns:string = 'max-width:100%'  // Bug fix XPTUI 621


    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    constructor(private rpmTabDataService:RPMTabDataService,
                private hcuSharedService: HCUSharedService,
                private viewEventsColumnDefinitionService:ViewEventsColumnDefinitionService,
                private showAlert: ShowAlert, private localeDataService:LocaleDataService,
                private sharedService:SharedService,private hcuTabDataService: HCUTabDataService){

                this.translateLocaleString();
                this.setEventButtonKeys();
    }

    ngOnInit(){
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.notifyCloseSlider("dummy can be ignored later");
        })
    }

    //@method :: translate to local string
    private translateLocaleString(){
        let localizationService = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_EXPORT_ALL = localizationService.instant('TABLE_LIST_EXPORT_ALL');
        this.CLOSE_SLIDER = localizationService.instant('CLOSE_SLIDER');
        this.RPM_VIEW_EVENTS_HEADER = localizationService.instant('RPM_VIEW_EVENTS_HEADER');
        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
    }

    //@method :: set button keys
    private setEventButtonKeys():void {
        this.buttonKeys = [
            {name:this.TABLE_LIST_EXPORT_ALL, tabType:'HCU_VIEW_EVENT', disable:true},
            {name:this.CLOSE_SLIDER , tabType:'HCU_VIEW_EVENT', iconClass: 'fa fa-times' , txt:' '}
        ];
        this.refreshBtnFlag = true;
    }

    //@method :: close slider
    private btnClose_click(){
        this.isCloseRightSlider = true;
    }

    //@method ::  shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    //@method ::  sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.viewEventsColumnDefinitionService.getColumnDef());
        this.listViewOptions["getRowHeight"] = (params) => {
            return 18 * (Math.floor(params.data.eventType.length / 45) + 2);
        }
        this.childData && this.getViewEventData();
    }

    //sets slider label.
    private setHeaderLabel(childName?):void {
        this.headerTxt = this.RPM_VIEW_EVENTS_HEADER;
        this.headerTxt =childName ?  this.headerTxt + ' - ' + childName : this.headerTxt;
    }

    //@method :: Call view event API
    private getViewEventData():void {
        this.setHeaderLabel(this.childData.label);
        this.rpmTabDataService.getRpmEventList(this.childData.elementId, RETURN_PATH_MONITOR).subscribe(this.getThresholdsList.bind(this),this.onError.bind(this));
    }

    private getThresholdsList(eventList: any): void{
        this.eventList = eventList;
        this.hcuTabDataService.getThresholdsName().subscribe(this.processEventList.bind(this),this.onError.bind(this));
    }

    private processEventList(thresholds: any): void{
        this.addRows(this.hcuSharedService.processEventList(this.eventList, thresholds));
    }

    //@method :: ser ag-Grid rows
    private addRows(response: any): void{
        this.rowdata = response;
        this.totalCount = this.rowdata.length;
        this.setShowAllLabel(this.rowdata.length, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.listViewOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //@event :: grid ready event
    public notifyGridReadyViewEvents(params:any){
        this.setGridColDefinition();
    }

    //@method :: close slider
    public notifyCloseSlider(params:any){
        this.hcuSharedService.getClearRpmEditComponentSubject().next(false);
        this.isCloseRightSlider = true;
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }

    //refresh
    public notifyRefreshGrid(params:any){
        this.getViewEventData();
    }
}