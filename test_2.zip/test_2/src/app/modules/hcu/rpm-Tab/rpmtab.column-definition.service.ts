import {Injectable} from '@angular/core';

import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {EDIT_ICON} from "../../../constant/app.constants";
import {StatusFilter} from "../../../shared/status.filter";
import {HCUSharedService} from "../hcu.shared.service";
import {Subject} from "rxjs";
import {RpmModel} from "./models/rpm.model";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import { TranslateService } from '@ngx-translate/core';

@Injectable()

export class RPMTabColumnDefinitionService {
    private rpmViewSubject:Subject<any>;
    private _HEADER_FIELDS: any = {
        status : {field: "status", name: ""},
        rpm : {field: "label", name: ""},
        hcu : {field: "hcu_label", name: ""},
        slot : {field: "slotNumber", name: ""},
        serialNumber : {field: "serialNumber", name: ""},
        type : {field: "modelNumber", name: ""},
        firmwarePackge : {field: "firmwareRev", name: ""},
        qamTrak : {field: "qamTrak", name: ""},
        macTrak : {field: "macTrak", name: ""},
        macTrakMonitoring : {field: "macTrakMonitoring", name: ""},
        edit : {field: "edit", name: ""}
    };

    constructor(private hcuSharedService: HCUSharedService, 
        private localeDataService: LocaleDataService,
        private translate : TranslateService,
        private sharedService : SharedService){
        this.rpmViewSubject = hcuSharedService.getRpmViewSubject();
        // this.localeDataService.componentCallback.subscribe((response) => {
        //     this.translateLocaleStr();
        //                 });
        this.translateLocaleStr();
    }

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        this._HEADER_FIELDS.status.name = this.translate.instant('HCU_RPM_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.rpm.name = this.translate.instant('HCU_RPM_TAB_HEADER_RPM');
        this._HEADER_FIELDS.hcu.name = this.translate.instant('HCU_RPM_TAB_HEADER_HCU');
        this._HEADER_FIELDS.slot.name = this.translate.instant('HCU_RPM_TAB_HEADER_SLOT');
        this._HEADER_FIELDS.serialNumber.name = this.translate.instant('HCU_RPM_TAB_HEADER_SERIAL_NUMBER');
        this._HEADER_FIELDS.type.name = this.translate.instant('HCU_RPM_TAB_HEADER_TYPE');
        this._HEADER_FIELDS.firmwarePackge.name = this.translate.instant('HCU_RPM_TAB_FIRMWARE_PKG');
        this._HEADER_FIELDS.qamTrak.name = this.translate.instant('HCU_RPM_TAB_HEADER_QAM_TRAK');
        this._HEADER_FIELDS.macTrak.name = this.translate.instant('HCU_RPM_TAB_HEADER_MAC_TRAK');
        this._HEADER_FIELDS.macTrakMonitoring.name = this.translate.instant('HCU_RPM_TAB_MAC_TRAK_MONITORING');
        this._HEADER_FIELDS.edit.name = this.translate.instant('HCU_RPM_TAB_EDIT');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
    */
    public getColumnDef(): any[] {
        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: this._HEADER_FIELDS.status.name,
                headerTooltip: this._HEADER_FIELDS.status.name,
                field: this._HEADER_FIELDS.status.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.status.name, 90),
                filter: StatusFilter.ParentFilter,
                floatingFilterComponent: StatusFilter.ChildFloatingFilter,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'}
            },
            this.getColumns(this._HEADER_FIELDS.rpm.name, this._HEADER_FIELDS.rpm.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.rpm.name, 90), "text"),
            this.getColumns(this._HEADER_FIELDS.hcu.name, this._HEADER_FIELDS.hcu.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.hcu.name, 90), "text",'',true),
            this.getColumns(this._HEADER_FIELDS.slot.name, this._HEADER_FIELDS.slot.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.slot.name, 60), "number"),
            this.getColumns(this._HEADER_FIELDS.serialNumber.name, this._HEADER_FIELDS.serialNumber.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.serialNumber.name, 40), 'text'),
            this.getColumns(this._HEADER_FIELDS.type.name, this._HEADER_FIELDS.type.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.type.name, 30), "text"),
            this.getColumns(this._HEADER_FIELDS.firmwarePackge.name, this._HEADER_FIELDS.firmwarePackge.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.firmwarePackge.name, 50), "text"),
            this.getColumns(this._HEADER_FIELDS.qamTrak.name, this._HEADER_FIELDS.qamTrak.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.qamTrak.name, 30), "text"),
            this.getColumns(this._HEADER_FIELDS.macTrak.name, this._HEADER_FIELDS.macTrak.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.macTrak.name, 30), "text"),
            this.getColumns(this._HEADER_FIELDS.macTrakMonitoring.name, this._HEADER_FIELDS.macTrakMonitoring.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.macTrakMonitoring.name, 50), "text"),
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                minWidth: 70, maxWidth: 150,
                pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'agTextColumnFilter',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                    this.action(param);
                }));
                gui.className = "ag-Grid-cursor";
                return gui;
                })
            }
        ]
        return columnDef;
    }

    //@method :: get column definition
    private getColumns(headerName: string, field: string, minWidth: number, filter: string, sort?:string, suppressSizeToFit?:boolean): any{
        return {
            headerName: headerName,
            headerTooltip: headerName.replace("&trade;",""),
            field: field,
            minWidth: minWidth,
            suppressSizeToFit:suppressSizeToFit,
            filter: filter,
            comparator: gridCustomComparator,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'},
            sort:sort
        }
    }

    //@method :: callback action for clear icon click
    private action(param: any): void{
        this.rpmViewSubject.next(<RpmModel>param.data);
    }
}