/**
 * Created by yogesh.paisode on 7/13/2017.
 */
import {Component} from "@angular/core";

import {Grid} from "../../../../shared/ag-grid.options";
import {DeployLicenseColumnDefinitionService} from "./deploy-license.column-definition.service";
import {RPMTabDataService} from "../rpmtab.data.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {HCUSharedService} from "../../hcu.shared.service";
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector: 'deploy-license',
    templateUrl: 'deploy-license.component.html'
})
export class DeployLicenseComponent{
    private formData = new FormData();

    public listViewOptions: Grid = new Grid();
    public rowdata = null;
    private files: any;
    public uploadDisabled: boolean = true;
    public isCloseRightSlider:boolean = false;

    constructor(private deployLicenseColumnDefinitionService: DeployLicenseColumnDefinitionService,
                private rpmTabDataService: RPMTabDataService,
                private showAlert: ShowAlert,
                private hcuSharedService: HCUSharedService,
                private sharedService:SharedService){
    }

    ngOnInit() {
        this.closeSlidersSubjectListener();
        this.isCloseRightSlider = false;
    }

    //methods used to close slider when usersgroup slier opens.
    private closeSlidersSubjectListener():void {
        this.sharedService.getCloseSlidersSubject().subscribe((res)=>{
            if(res) this.closeSlider();
        })
    }

    //@method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.listViewOptions.api.showLoadingOverlay();
    }

    //@method :: sets grid columns.
    private setGridColDefinition():void {
        this.showLoadingOverlay();
        this.listViewOptions.api.setColumnDefs(this.deployLicenseColumnDefinitionService.getColumnDef());
        this.listViewOptions["getRowHeight"] = (params) => {
            return 18 * (Math.floor(params.data.status.length / 45) + 2);
        }
    }

    //@event :: grid ready event
    public notifyGridReadyViewEvents(params:any): void{
        this.setGridColDefinition();
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }

    //@method :: get called when input type file selects different file.
    public getFileInfo(event: any): void{
        this.files = event.target.files;
        if (this.files && this.files.length >= 1) {
            this.uploadDisabled = false;
        }else{
            this.uploadDisabled = true;
        }
    }

    //@method :: get called when input type file selects different file.
    public fileChange(): void {
        this.formData = null;
        if (this.files && this.files.length) {
            let file;
            file = this.files[0];
            this.formData = new FormData();
            this.formData.append('file', file, file.name);
            this.rpmTabDataService.uploadLicense(this.formData).subscribe(this.processResponse.bind(this), (error) => {
                this.showAlert.showErrorAlert(error);
            })
        }
    }

    public clearFile(): void{
        let fileInput:any = document.getElementById("deployLicenseFileInput")
        fileInput.value = null;
    }

    //@method :: clear file data
    private processResponse(response: any): void{
        this.rowdata = [];
        this.rowdata = response;
    }

    //@method :: close slider
    public closeSlider(): void{
        this.isCloseRightSlider = true;
        this.hcuSharedService.getClearRpmEditComponentSubject().next(true);
    }
}