/**
 * Created by yogesh.paisode on 7/17/2017.
 * */

import {Injectable} from "@angular/core";

import {LocaleDataService} from "../../../../shared/locale.data.service";
import {gridCustomComparator} from "../../../../shared/ag-Grid.comparator";

@Injectable()
export class DeployLicenseColumnDefinitionService{

    private _HEADER_FIELDS: any = {
        serialNumber : {field: "serialNumber", name: ""},
        status : {field: "status", name: ""},
        rpm : {field: "label", name: ""},
        hcu : {field: "hcu_label", name: ""},
        sent : {field: "slotNumber", name: ""},
        type : {field: "modelNumber", name: ""},
        qamTrak : {field: "qamTrak", name: ""},
        macTrak : {field: "macTrak", name: ""},
        macTrakMonitoring : {field: "macTrakMonitoring", name: ""}
    };

    constructor(private localeDataService: LocaleDataService){
        this.translateLocaleStr();
    }

    /*
   *@name translateLocaleStr
   *@desc Get Localize strings
   *@return void
   */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();

        this._HEADER_FIELDS.status.name = localizationService.instant('HCU_RPM_TAB_HEADER_STATUS');
        this._HEADER_FIELDS.rpm.name = localizationService.instant('HCU_RPM_TAB_HEADER_RPM');
        this._HEADER_FIELDS.sent.name = localizationService.instant('HCU_RPM_TAB_HEADER_SLOT');
        this._HEADER_FIELDS.hcu.name = localizationService.instant('HCU_RPM_TAB_HEADER_HCU');
        this._HEADER_FIELDS.serialNumber.name = localizationService.instant('HCU_RPM_TAB_HEADER_SERIAL_NUMBER');
        this._HEADER_FIELDS.type.name = localizationService.instant('HCU_RPM_TAB_HEADER_TYPE');
        this._HEADER_FIELDS.qamTrak.name = localizationService.instant('HCU_RPM_TAB_HEADER_QAM_TRAK');
        this._HEADER_FIELDS.macTrak.name = localizationService.instant('HCU_RPM_TAB_HEADER_MAC_TRAK');
        this._HEADER_FIELDS.macTrakMonitoring.name = localizationService.instant('HCU_RPM_TAB_MAC_TRAK_MONITORING');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        let columnDef: any[] = [
            this.getColumns(this._HEADER_FIELDS.serialNumber.name, this._HEADER_FIELDS.serialNumber.field, 180, "number"),
            {
                headerName: this._HEADER_FIELDS.status.name,
                headerTooltip: this._HEADER_FIELDS.status.name,
                field: this._HEADER_FIELDS.status.field,
                minWidth: 250,
                filter: "text",
                comparator: gridCustomComparator,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                cellStyle: {
                    'white-space': 'normal'
                }
            },
            this.getColumns(this._HEADER_FIELDS.rpm.name, this._HEADER_FIELDS.rpm.field, 150, "text"),
            this.getColumns(this._HEADER_FIELDS.hcu.name, this._HEADER_FIELDS.hcu.field, 150, "text"),
            this.getColumns(this._HEADER_FIELDS.sent.name, this._HEADER_FIELDS.sent.field, 90, "number"),
            this.getColumns(this._HEADER_FIELDS.type.name, this._HEADER_FIELDS.type.field, 150, "text"),
            this.getColumns(this._HEADER_FIELDS.qamTrak.name, this._HEADER_FIELDS.qamTrak.field, 150, "text"),
            this.getColumns(this._HEADER_FIELDS.macTrak.name, this._HEADER_FIELDS.macTrak.field, 150, "text"),
            this.getColumns(this._HEADER_FIELDS.macTrakMonitoring.name, this._HEADER_FIELDS.macTrakMonitoring.field, 200, "text"),
        ]
        return columnDef;
    }

    //@method :: get column definition for each
    private getColumns(headerName: string, field: string, minWidth: number, filter: string): any{
        return {
            headerName: headerName,
            headerTooltip: headerName.replace("&trade;",""),
            field: field,
            minWidth: minWidth,
            filter: filter,
            comparator: gridCustomComparator,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'}
        }
    }
}
