export class ImportLabelModel{
    public sucessCount: number;
    public emptyLabelCount: number;
    public elementNotFoundCount: number;
    public noChangeInElementCount: number;
    public elementOfflineCount: number;
    public skippedLineCount: number;
    public virtualHsmCount: number;
    public encodingError: boolean;
    public invalidFile: boolean;

    constructor(obj: any){
        if(obj){
            this.sucessCount = obj.sucessCount;
            this.emptyLabelCount = obj.emptyLabelCount;
            this.elementNotFoundCount = obj.elementNotFoundCount;
            this.noChangeInElementCount = obj.noChangeInElementCount;
            this.elementOfflineCount = obj.elementOfflineCount;
            this.skippedLineCount = obj.skippedLineCount;
            this.virtualHsmCount = obj.virtualHsmCount;
            this.encodingError = obj.encodingError;
            this.invalidFile = obj.invalidFile;
        }
    }

    public getMessage(localizationService: any): string{
        let message: string = "";

        if(this.noChangeInElementCount > 0){
            message = message.concat(this.noChangeInElementCount.toString().concat(localizationService.instant('HCU_IMPORT_LABEL_NO_ROWS_CHANGE')), "\n");
        }

        if(this.sucessCount > 0){
            message = message.concat(this.sucessCount.toString().concat(localizationService.instant('HCU_IMPORT_LABEL_EDIT_SUCCESS')), "\n");
        }

        //elementNotFoundCount
        if(this.elementNotFoundCount > 0){
            message = message.concat(this.elementNotFoundCount.toString().concat(localizationService.instant('ELEMENT_NOT_FOUND_COUNT')), "\n");
        }

        //emptyLabelCount
        if(this.emptyLabelCount > 0){
            message = message.concat(this.emptyLabelCount.toString().concat(localizationService.instant('EMPTY_LABEL_COUNT')), "\n");
        }

        //elementOfflineCount
        if(this.elementOfflineCount > 0){
            message = message.concat(this.elementOfflineCount.toString().concat(localizationService.instant('ELEMENT_OFFLINE_COUNT')), "\n");
        }

        //skippedLineCount
        if(this.skippedLineCount > 0){
            message = message.concat(this.skippedLineCount.toString().concat(localizationService.instant('SKIPPED_LINE_COUNT')), "\n");
        }

        //virtualHsmCount
        if(this.virtualHsmCount > 0){
            message = message.concat(this.virtualHsmCount.toString().concat(localizationService.instant('VIRTUAL_HSM_COUNT')), "\n");
        }

        //encodingError
        if(this.encodingError){
            message = message.concat("".concat(localizationService.instant('ENCODING_ERROR')), "\n");
        }

        //invalidFile
        if(this.invalidFile){
            message = message.concat("".concat(localizationService.instant('INVALID_FILE')), "\n");
        }

        return message;
    }
}