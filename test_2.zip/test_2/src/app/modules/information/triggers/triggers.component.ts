import {Component} from "@angular/core";
import {TriggersService} from "./triggers.service";

@Component({
    selector:"triggers",
    templateUrl:"triggers.component.html"
})
export class TriggersComponent {
    constructor(
        private triggersService:TriggersService
    ) { }

    public getTriggerCmtsSync() {
        this.triggersService.getTriggerCmtsSync();
    }

    public getTriggerDSCollection() {
        this.triggersService.getTriggerDSCollection();
    }

    public getTriggerPreEqCollection() {
        this.triggersService.getTriggerPreEqCollection();
    }

    public getTriggerQoeCmCollection() {
        this.triggersService.getTriggerQoeCmCollection();
    }

    public getTriggerQoeCmtsCollection() {
        this.triggersService.getTriggerQoeCmtsCollection();
    }

    public getTriggerNodeRankingCollection() {
        this.triggersService.getTriggerNodeRankingCollection();
    }

    public onTabSwitch(): void { }
}