import {Injectable} from "@angular/core";
import {InformationHttpService} from "../information.http.service";
import {Observable} from "rxjs";

@Injectable()
export class TriggersDataService {
    constructor(private informationHttpService:InformationHttpService) { }

    public getTriggerCmtsSync(): Observable<any> {
        return this.informationHttpService.getTriggerCmtsSync();
    }

    public getTriggerDSCollection(): Observable<any> {
        return this.informationHttpService.getTriggerDSCollection();
    }

    public getTriggerPreEqCollection(): Observable<any> {
        return this.informationHttpService.getTriggerPreEqCollection();
    }

    public getTriggerQoeCmCollection(): Observable<any> {
        return this.informationHttpService.getTriggerQoeCmCollection();
    }

    public getTriggerQoeCmtsCollection(): Observable<any> {
        return this.informationHttpService.getTriggerQoeCmtsCollection();
    }

    public getTriggerNodeRankingCollection(): Observable<any> {
        return this.informationHttpService.getTriggerNodeRankingCollection();
    }
}
