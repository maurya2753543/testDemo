import { Observable } from 'rxjs';
import {Injectable} from "@angular/core";
import {ShowAlert} from "../../../utilities/showAlert";
import {TriggersDataService} from "./triggers.data.service";
import { Logger } from '../../../utilities/logger';
//import { LocalizationService } from 'angular2localization';
import { LocaleDataService } from './../../../shared/locale.data.service';
import { filter, map, take } from 'rxjs/operators';

@Injectable()
export class TriggersService {
    private successMessage: string;
    private localizationService;

    constructor(
        private logger:Logger,
        private showAlert:ShowAlert,
        private triggersDataService:TriggersDataService,
        private localeDataService: LocaleDataService
    ) {
        this.localizationService = this.localeDataService.getLocalizationService();
        // this.localizationService = this.localeDataService.isReady
        //     .pipe(
        //         filter(ready => ready),
        //         map(r => this.localeDataService.getLocalizationService())
        //     )
    }

    public getTriggerCmtsSync() {
        this.successMessage = this.localizationService.instant("TRIGGER_CMTS_SYNC") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerCmtsSync());
    }

    public getTriggerDSCollection() {
        this.successMessage = this.localizationService.instant("TRIGGER_DS_COLLECTION") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerDSCollection());
    }

    public getTriggerPreEqCollection() {
        this.successMessage = this.localizationService.instant("TRIGGER_PRE_EQ_COLLECTION") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerPreEqCollection());
    }

    public getTriggerQoeCmCollection() {
        this.successMessage = this.localizationService.instant("TRIGGER_QOE_CM_COLLECTION") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerQoeCmCollection());
    }

    public getTriggerQoeCmtsCollection() {
        this.successMessage = this.localizationService.instant("TRIGGER_QOE_CMTS_COLLECTION") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerQoeCmtsCollection());
    }

    public getTriggerNodeRankingCollection() {
        this.successMessage = this.localizationService.instant("TRIGGER_NODE_RANKING_COLLECTION") + this.localizationService.instant("TRIGGERED")
        this.completeRequest(this.triggersDataService.getTriggerNodeRankingCollection());
    }

    private completeRequest(request: Observable<any>) {
        request
            .pipe(
                take(1)
            )
            .subscribe(r => {
                this.showAlert.showSuccessAlert(this.successMessage);
            }, err => {
                this.logger.error("onError():  error data=", err);
                this.showAlert.showErrorAlert(err);
            });
    }
}