
import { Routes, RouterModule } from '@angular/router';
import {InformationComponent} from "./information.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: 'license', component: InformationComponent },
    { path: 'logs', component: InformationComponent },
    { path: '', component: InformationComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class InfoRoutes{}
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);

