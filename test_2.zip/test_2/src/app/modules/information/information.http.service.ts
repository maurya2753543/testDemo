/**
 * Created by narayan.reddy on 23-06-2017.
 */

/* HTTP Service Class for api calls & data handling*/

import { Injectable } from "@angular/core";
import { InformationUrlService } from "./information.url.service";
import {HttpService} from "../../shared/http.service";
import { Observable,throwError } from "rxjs";
import { HttpParams } from "@angular/common/http";
import {
  DELETE_LOG_FILE_ACTION,
  PURGE_LIST_ACTION,
} from "../../constant/app.constants";
import { AuthService } from "src/app/shared/auth.service";
import {catchError, switchMap, take} from 'rxjs/operators';
@Injectable()
export class InformationHttpService {
  constructor(
    private httpService: HttpService,
    private urlService: InformationUrlService,
    private authService: AuthService
  ) {}

  // get basic info
  public getLogList(action: string): Observable<any> {
    let url: string = this.urlService.getLogLisUrl();
    if (action === PURGE_LIST_ACTION) {
      url = this.urlService.getPurgeLisUrl();
    } else if (action === DELETE_LOG_FILE_ACTION) {
      url = this.urlService.getDeleteZipFoldeUrl();
    }
    return this.httpService.GET(url);
  }

  // get basic info
  public getInfoUrlData(): Observable<any> {
    return this.httpService.GET(this.urlService.getInformationUrl());
  }

  // get license info
  public getLicenseInfoData(): Observable<any> {
    return this.httpService.GET(this.urlService.getLicenseInfoUrl());
  }

  // get license logs
  public getLicenseLogData(): Observable<any> {
    return this.httpService.GET(this.urlService.getLicenseLogUrl());
  }

  // get export logs
  public getExportLogData(): Observable<any> {
    return this.httpService.GETBLOB(this.urlService.getExportLogUrl());
  }

  // get diagnostic summary
  public getDiagnosticSummaryData(): Observable<any> {
    return this.httpService.GET(this.urlService.getDiagnosticSummaryUrl());
  }

  // get DownstreamUsage Accordion info
  public getDiagnosticDownstreamUsageData(): Observable<any> {
    return this.httpService.GET(this.urlService.getDownstreamUsageUrl());
  }

  // get RAM CPU Usage Accordion info
  public getRAMCPUUsageOneDayData(): Observable<any> {
    return this.httpService.GET(this.urlService.getRamCpuUsageOneDayUrl());
  }

  public getRAMCPUUsageSevendaysData(): Observable<any> {
    return this.httpService.GET(this.urlService.getRamCpuUsageSevenDaysUrl());
  }

  // get HCU Collection Usage Accordion info
  public getHCUCollectionsageData(): Observable<any> {
    return this.httpService.GET(this.urlService.getHCUCollectionUrl());
  }

  //get RCI Collection Usage Accordion info
  public getRciCollectionData(): Observable<any> {
    return this.httpService.GET(
      this.urlService.getVirtualSpectrumCollectionUrl()
    );
  }

  // get QoE CMTS Accordion info
  public getQoeCMTSCollectionData(): Observable<any> {
    return this.httpService.GET(this.urlService.getQoeCMTSCollectionUrl());
  }

  // get QoE CM Accordion info
  public getQoeCMCollectionData(): Observable<any> {
    return this.httpService.GET(this.urlService.getQoeCMCollectionUrl());
  }

  // get DownstreamUsage Accordion info
  public getDiagnosticPNMPreEqUsageData(): Observable<any> {
    return this.httpService.GET(this.urlService.getPNMPreEqUsageUrl());
  }

  // post Import License Data
  public postImportLicenseData(data): Observable<any> {
    return this.httpService.POSTFILEDATA(
      this.urlService.postImportLicenseUrl(),
      data
    );
  }

  // post Download License Data
  public getDownloadLicenseData(): Observable<any> {
    return this.httpService.GETDownloadLicense(
      this.urlService.getDownloadLicenseUrl()
    );
  }

  public getTriggerCmtsSync(): Observable<any> {
    return this.httpService.GET(this.urlService.getTriggerCmtsSyncUrl());
  }

  public getTriggerDSCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getTriggerDSCollectionUrl());
  }

  public getTriggerPreEqCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getTriggerPreEqCollectionUrl());
  }

  public getTriggerQoeCmCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getTriggerQoeCmCollectionUrl());
  }

  public getTriggerQoeCmtsCollection(): Observable<any> {
    return this.httpService.GET(
      this.urlService.getTriggerQoeCmtsCollectionUrl()
    );
  }

  public getTriggerNodeRankingCollection(): Observable<any> {
    return this.httpService.GET(
      this.urlService.getTriggerNodeRankingCollectionUrl()
    );
  }
  public getFeaturesNameCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getFeatureNamesUrl());
  }
  public getUsersCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getUsersUrl());
  }
  public getUsersStatsCollection(params: HttpParams): Observable<any> {
    return this.httpService.GET(this.urlService.getUserStatsUrl(params));
  }
  public getDeviceTypeCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getDeviceCollectionTypesUrl());
  }

  public getCmtsCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getCmtsUrl());
  }

  public getHcuCollection(): Observable<any> {
    return this.httpService.GET(this.urlService.getHcuUrl());
  }
  public getUserDetail(userId: number): Observable<any> {
    return this.httpService.GET(this.urlService.getUserDetailUrl(userId));
  }
  public updateData(
    deviceId,
    collectionId,
    duration,
    dateFormat
  ): Observable<any> {
    return this.httpService.GET(
      this.urlService.getUpdateDataUrl(
        deviceId,
        collectionId,
        duration,
        dateFormat
      )
    );
  }

  public getUserFeatureNames():Observable<any>{
    return this.httpService.GET(this.urlService.getUserFeaturesUrl())

  }
  public getUsersActivitySummaryData(params: HttpParams): Observable<any> {
    return this.httpService.GET(this.urlService.getUserActivitySummaryUrl(params));
  }

  public getOLTDetails(){
      // Return OLTs. Need token for authorization
       return this.authService.getJwtHeaders().pipe(
        switchMap(headers => this.httpService.GETWITHHEADERS(this.urlService.getOltTabDataURL(), headers)),
        catchError(err => {
            return throwError(err);
        }),
        take(1)
    );
  }
}
