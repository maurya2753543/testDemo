import {Component} from "@angular/core";

import {Logger} from "../../../utilities/logger";
import {ShowAlert} from "../../../utilities/showAlert";
import {DiagnosticDataService} from "./diagnostic.data.service";
import {Grid} from "../../../shared/ag-grid.options";
import {DiagnosticColumnDefinitionService} from "./diagnostic.column-definition.service";
import {DIAGNOSTIC_BLANK_ARR} from "../../../constant/app.constants";
import {SharedService} from "../../../shared/shared.service";

@Component({
    selector: "diagnostic",
    templateUrl: "diagnostic.component.html"
})

export class DiagnosticComponent {
    diagnosticSummaryrowdata: Array<any>;
    RamUsagerowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    CpuUsagerowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    hcuCollectionrowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    qoECmtsUsagerowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    qoECmUsagerowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    downstreamRowdata: Array<any> = DIAGNOSTIC_BLANK_ARR;
    preEqRowData: Array<any> = DIAGNOSTIC_BLANK_ARR;
    rciCollectionRowData: Array<any> = DIAGNOSTIC_BLANK_ARR;

    diagnosticSummaryTabGridOptions: Grid = new Grid();
    RamUsageTabGridOptions: Grid = new Grid();
    CpuUsageTabGridOptions: Grid = new Grid();
    qoECMTSCollectionTabGridOptions: Grid = new Grid();
    qoECMCollectionTabGridOptions: Grid = new Grid();
    hcuCollectionTabGridOptions: Grid = new Grid();
    downstreamCollectionTabGridOptions: Grid = new Grid();
    preEqTabGridOptions: Grid = new Grid();
    rciCollectionTabGridOptions: Grid = new Grid();

    private tag: string = 'DiagnosticComponent ::';

    showLoading: boolean = true;

    isChevronTwoToggle: boolean = true;
    isChevronThreeToggle: boolean = true;
    isChevronFourToggle: boolean = true;
    isChevronFiveToggle: boolean = true;
    isChevronSixToggle: boolean = true;
    isChevronSevenToggle: boolean = true;
    isChevronEightToggle: boolean = true;

    refreshBtnFlag: boolean = false;
    latestUsageDate: string;
    peakRAMUsageDate: string;
    peakCPUUsageDate: string;

    constructor(private diagnosticDataService: DiagnosticDataService,
                private showAlert: ShowAlert, private logger: Logger,
                private sharedService: SharedService,
                private diagnosticColumnDefinitionService: DiagnosticColumnDefinitionService) {
    }

    ngOnInit() {
        this.refreshBtnFlag = true;
    }

    //method to call API on accordion open
    manageAccordion(num: number, optional?: any): void {
        this.refreshBtnFlag = true;
        switch (num) {
            case 2 :this.showGridLoadingOverly(this.RamUsageTabGridOptions);
                    this.showGridLoadingOverly(this.CpuUsageTabGridOptions);
                    if (this.isChevronTwoToggle == false) {
                        this.diagnosticDataService.getRAMCPUUsageOneDay().subscribe(this.onRAMCPUUsageOneDayRes.bind(this), this.onApiError.bind(this));
                        this.diagnosticDataService.getRAMCPUUsageSevenDays().subscribe(this.onRAMCPUUsageSevenDaysRes.bind(this), this.onApiError.bind(this));
                    }
                break;
            case 3 :this.showGridLoadingOverly(this.hcuCollectionTabGridOptions);
                    this.isChevronThreeToggle == false?
                        this.diagnosticDataService.getHCUCollectionUsage().subscribe(this.onHCUCollectionUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;
            case 4 :this.showGridLoadingOverly(this.qoECMTSCollectionTabGridOptions);
                    this.isChevronFourToggle == false?
                        this.diagnosticDataService.getQoECmtsCollection().subscribe(this.onQoeCMTSUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;
            case 5 :this.showGridLoadingOverly(this.qoECMCollectionTabGridOptions);
                    this.isChevronFiveToggle == false?
                        this.diagnosticDataService.getQoECmCollection().subscribe(this.onQoeCMUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;
            case 6 :this.showGridLoadingOverly(this.preEqTabGridOptions);
                    this.isChevronSixToggle == false?
                        this.diagnosticDataService.getPNMPreEqUsage().subscribe(this.onPNMPreEqUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;
            case 7 :this.showGridLoadingOverly(this.downstreamCollectionTabGridOptions);
                    this.isChevronSevenToggle == false?
                        this.diagnosticDataService.getDiagnosticDownstreamUsage().subscribe(this.onDiagnosticDownstreamUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;
            case 8 :this.showGridLoadingOverly(this.rciCollectionTabGridOptions);
                    this.isChevronEightToggle == false?
                        this.diagnosticDataService.getRciCollectionUsage().subscribe(this.onRCICollectionUsageRes.bind(this), this.onApiError.bind(this)):'';
                break;

        }
    }

    /* Method get called when we come in diagnostic after switch the tab */
    public onTabSwitch(isApiReq ?: boolean): void {        
        this.diagnosticDataService.getDiagnosticSummary().subscribe(this.onDiagnosticSummaryRes.bind(this), this.onApiError.bind(this));
    }

    //refresh grid datanotifyRefreshGrid
     notifyRefreshGrid(num, $event?): void {
        this.manageAccordion(num)
    }

    // notify Diagnostic Summary grid is ready.
    notifyGridDiagnosticSummary(num): void { 
        
   // this.showGridLoadingOverly(this.diagnosticSummaryTabGridOptions);
        this.diagnosticSummaryTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getDiagnosticSummmaryColumnDef());
        this.diagnosticDataService.getDiagnosticSummary().subscribe(
            {
                next: this.onDiagnosticSummaryRes.bind(this),
                error: this.onApiError.bind(this)
             });
    }

    // notify that RAM Usage grid is ready.
    notifyGridReadyRamUsage(event): void {
        this.RamUsageTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getRamUsageColumnDef());
    }

    // notify that CPU Usage grid is ready.
    notifyGridReadyCpuUsage(event): void {
        this.CpuUsageTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getCpuUsageColumnDef());
    }

    // notify HCU Collection grid is ready.
    notifyGridReadyHcuCollection(event): void {
        this.hcuCollectionTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getHCUCollectionColumnDef());
    }

    //notify RCI Collection grid is ready.
     notifyGridReadyRciCollection(event): void {
        this.rciCollectionTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getRciCollectionColumnDef());
    }

    // notify qoE CMTS Collection grid is ready.
    notifyGridReadyQoECMTSCollection(event): void {
        this.qoECMTSCollectionTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getDownstreamCollectionColumnDef());
    }

    // notify qoE CMCollection grid is ready.
    notifyGridReadyQoECMCollection(event): void {
        this.qoECMCollectionTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getDownstreamCollectionColumnDef());
    }

    // notify Downstream Collection grid is ready.
    notifyGridReadyDownstreamCollection(event): void {
        this.downstreamCollectionTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getDownstreamCollectionColumnDef());
    }

    // notify PreEq Data grid is ready.
    notifyGridReadyPreEqData(event): void {
        this.preEqTabGridOptions.api.setColumnDefs(this.diagnosticColumnDefinitionService.getDownstreamCollectionColumnDef());
    }

    //Show ag-Grid overlay
    showGridLoadingOverly(gridOption): void {
        gridOption.api.showLoadingOverlay();
    }

    //Hide ag-Grid overlay
    hideGridOverly(gridOption): void {
        gridOption.api.hideOverlay();
    }

    /* Function invoked on success of onRAMCPUUsageRes response */
    private onRAMCPUUsageOneDayRes(response) {
    }

    private onRAMCPUUsageSevenDaysRes(response) {
        this.RamUsagerowdata = this.diagnosticDataService.getRAMUsageList();
        this.CpuUsagerowdata = this.diagnosticDataService.getCPUUsageList();
        this.latestUsageDate = this.sharedService.getLocaleDate(response['os']['logTime']);
        this.peakRAMUsageDate = this.sharedService.getLocaleDate(response['os']['ramMaxTime']);
        this.peakCPUUsageDate = this.sharedService.getLocaleDate(response['os']['cpuUsageMaxTime']);
        this.hideGridOverly(this.RamUsageTabGridOptions);
        this.hideGridOverly(this.CpuUsageTabGridOptions);
    }

    /* Function invoked on success of onHCUCollectionUsageRes response */
    private onHCUCollectionUsageRes(response) {
        this.hcuCollectionrowdata = response;
        this.hideGridOverly(this.hcuCollectionTabGridOptions);
    }

    /* Function invoked on success of onRCICollectionUsageRes response */
    private onRCICollectionUsageRes(response) {
        this.rciCollectionRowData = response;
        this.hideGridOverly(this.rciCollectionTabGridOptions);
    }

    /* Function invoked on success of onQoeCMTSUsageRes response */
    private onQoeCMTSUsageRes(response) {
        this.qoECmtsUsagerowdata = response;
        this.hideGridOverly(this.qoECMTSCollectionTabGridOptions);
    }

    /* Function invoked on success of onQoeCMUsageRes response */
    private onQoeCMUsageRes(response) {
        this.qoECmUsagerowdata = response;
        this.hideGridOverly(this.qoECMCollectionTabGridOptions);
    }

    /* Function invoked on success of diagnostic summary response */
    onDiagnosticSummaryRes(response) {
        console.log('onDiagnosticSummaryRes------------->>>',response)
        this.diagnosticSummaryrowdata = response.diagSummary();
        this.hideGridOverly(this.diagnosticSummaryTabGridOptions);
    }

    /* Function invoked on success of Downstream usage diagnostic api response */
    private onDiagnosticDownstreamUsageRes(response) {
        this.downstreamRowdata = response;
        this.hideGridOverly(this.downstreamCollectionTabGridOptions);
    }

    /* Function invoked on success of Downstream usage diagnostic api response */
    private onPNMPreEqUsageRes(response) {
        this.preEqRowData = response;
        this.hideGridOverly(this.preEqTabGridOptions);
    }

    /* Function invoked on error in api */
    private onApiError(error: any): void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showLoading = false;
        this.showAlert.showErrorAlert(error);
    }

}