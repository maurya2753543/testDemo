import { map,catchError } from 'rxjs/operators';
/**
 * Created by nikita.dewangan on 07-08-2017.
 */

import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {InformationHttpService} from "../information.http.service";
import {HttpResponse} from "@angular/common/http";
import {
    DiagnosticDownstreamList
} from "../models/diag-common.model";
import {SharedService} from "../../../shared/shared.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {DiagnosticSummary} from "../models/dia-summ.model";
import {DiagnosticRamUsageModel} from "../models/dia-ramUsage.model";
import {LanguageService} from "../../../shared/locale.language.service";
import {DiagnosticHCUModel} from "../models/diag-hcu.model";
import {DiagnosticCpuUsageModel} from "../models/dia-cpuUsage.model";


@Injectable()
export class DiagnosticDataService {

    private diagnosticRAMUsage:any;
    private diagnosticCPUUsage:any;
    private language : string ;
    private currentBrowser:string;

    private ramUsageList = [];
    private cpuUsageList = [];

    constructor(private informationHttpService:InformationHttpService,
                private localizationService:LocaleDataService,
                private languageService:LanguageService,
                private sharedService:SharedService){
        this.language = this.languageService.getCurrentLanguage();
        this.currentBrowser = this.languageService.getCurrentBrowser();
    }

    // get diagnostic summary
    public getDiagnosticSummary() : Observable<any>{
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getDiagnosticSummaryData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticSummary : DiagnosticSummary = new DiagnosticSummary(data, this.sharedService,localizationService,  this.languageService);
                    return diagnosticSummary;
                }, error => {
                    return error;
                })

        )
    }


    // get Downstream Diagnostic usage
    public getDiagnosticDownstreamUsage(): Observable<any> {
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getDiagnosticDownstreamUsageData().pipe(
            map(
                (data: HttpResponse<any>) => {
                     let diagnosticDownstreamUsage :DiagnosticDownstreamList = new DiagnosticDownstreamList(data, this.sharedService,localizationService, this.currentBrowser);
                    return diagnosticDownstreamUsage;
                }, error => {
                    return error;
                })
        )

    }

    // get RAM CPU usage
    public getRAMCPUUsageOneDay(): Observable<any> {
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getRAMCPUUsageOneDayData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    this.ramUsageList = [];
                    this.cpuUsageList = [];
                    if(!this.diagnosticRAMUsage) {
                        this.diagnosticRAMUsage = new DiagnosticRamUsageModel();
                        this.diagnosticCPUUsage = new DiagnosticCpuUsageModel();
                    }
                    this.diagnosticRAMUsage.addElementsToList(data, this.ramUsageList , localizationService ,  this.language,1,this.sharedService);
                    this.diagnosticCPUUsage.addElementsToList(data, this.cpuUsageList , localizationService , this.language,1,this.sharedService);
                    return this.ramUsageList;
                }, error => {
                    return error;
                })

        )

    }

    public getRAMCPUUsageSevenDays(): Observable<any> {
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getRAMCPUUsageSevendaysData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    if(!this.diagnosticRAMUsage) {
                        this.diagnosticRAMUsage = new DiagnosticRamUsageModel();
                        this.diagnosticCPUUsage = new DiagnosticCpuUsageModel();
                    }
                    this.diagnosticRAMUsage.addElementsToList(data, this.ramUsageList , localizationService ,  this.language,7,this.sharedService);
                    this.diagnosticCPUUsage.addElementsToList(data, this.cpuUsageList , localizationService ,  this.language,7,this.sharedService);
                    return data;
                }, error => {
                    return error;
                })

        )

    }

    // get HCU collection usage
    public getHCUCollectionUsage() : Observable<any>{
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getHCUCollectionsageData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticDownstreamUsage :DiagnosticHCUModel = new DiagnosticHCUModel(data, this.sharedService,localizationService, this.currentBrowser);
                    return diagnosticDownstreamUsage;
                }, error => {
                    return error;
                })

        )

    }

    //get RCI Collection usage
    public getRciCollectionUsage() : Observable<any>{
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getRciCollectionData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticRciUsage: DiagnosticDownstreamList = new DiagnosticDownstreamList(data, this.sharedService,localizationService, this.currentBrowser);
                    return diagnosticRciUsage;
                }, error => {
                    return error;
                })

        )

    }

    // get Qoe CMTS collection usage
    public getQoECmtsCollection() : Observable<any>{
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getQoeCMTSCollectionData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticDownstreamUsage :DiagnosticDownstreamList = new DiagnosticDownstreamList(data, this.sharedService,localizationService, this.currentBrowser);
                    return diagnosticDownstreamUsage;
                }, error => {
                    return error;
                })

        )

    }

    // get QoE CM collection usage
    public getQoECmCollection() : Observable<any>{
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getQoeCMCollectionData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticDownstreamUsage:DiagnosticDownstreamList = new DiagnosticDownstreamList(data, this.sharedService,localizationService, this.currentBrowser);
                    return diagnosticDownstreamUsage;
                }, error => {
                    return error;
                })

        )

    }

    // get PNM PreEq  usage
    public getPNMPreEqUsage(): Observable<any> {
        let localizationService = this.localizationService.getLocalizationService();
        return this.informationHttpService.getDiagnosticPNMPreEqUsageData().pipe(
            map(
                (data: HttpResponse<any>) => {
                    let diagnosticDownstreamUsage :DiagnosticDownstreamList = new DiagnosticDownstreamList(data, this.sharedService, localizationService, this.currentBrowser);
                    return diagnosticDownstreamUsage;
                }, error => {
                    return error;
                })

        )

    }

    public getRAMUsageList() : any {
        return this.ramUsageList;
    }

    public getCPUUsageList() : any {
        return this.cpuUsageList;
    }



}
