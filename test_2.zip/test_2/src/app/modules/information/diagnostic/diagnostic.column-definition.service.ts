/**
 * Created by nikita.dewangan on 10-08-2017.
 */

import {Injectable} from "@angular/core";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import {TranslateService} from "@ngx-translate/core";

@Injectable()
export class DiagnosticColumnDefinitionService {

    constructor(private localeDataService: TranslateService) {
    }

    private _HEADER_FIELDS: any = {
        xptTomcat: {field: "tomcat", name: "DIAGNOSTIC_XPT_TOMCAT"},
        summaryName: {field: "name", name: ""},

        feature: {field: "name", name: "DIAGNOSTIC_FEATURE"},
        allocatedSpace: {field: "Allocated", name: "DIAGNOSTIC_ALLOCATED_SPACE"},
        estimatedUsage: {field: "Estimated", name: "DIAGNOSTIC_ESTIMATED_USAGE"},

        ramUsage: {field: "name", name: "DIAGNOSTIC_RAM_USAGE"},

        ptTomcat: {field: "tomcat", name: "DIAGNOSTIC_PT_TOMCAT"},
        OS: {field: "os", name: "DIAGNOSTIC_OS"},

        cpuUsage: {field: "name", name: "DIAGNOSTIC_CPU_USAGE"},

        timHHMMSS: {field: "serverDuration_ms", name: "DIAGNOSTIC_TIME_HHMMSS"},
        hcu: {field: "hcuCount", name: "DIAGNOSTIC_HCU"},
        spectrumPorts: {field: "spectralPortCount", name: "DIAGNOSTIC_SPECTRUM_PORTS"},
        macTrakPorts: {field: "mactrakPortCount", name: "DIAGNOSTIC_MACTRAK_PORTS"},

        nodes: {field: "nodeCount", name: "DIAGNOSTIC_NODES"},
    };




    /*
     *@name getDiagnosticSummmaryColumnDef
     *@desc Get column def for info diagnostic Summary data-grid
     *@return array[any]
     */
    public getDiagnosticSummmaryColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: this._HEADER_FIELDS.summaryName.name ? localizationService.instant(this._HEADER_FIELDS.summaryName.name) : '',
                headerTooltip: this._HEADER_FIELDS.summaryName.name ? localizationService.instant(this._HEADER_FIELDS.summaryName.name) : '', 
                field: this._HEADER_FIELDS.summaryName.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.xptTomcat.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.xptTomcat.name), field: this._HEADER_FIELDS.xptTomcat.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.OS.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.OS.name), field: this._HEADER_FIELDS.OS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }


    /*
     *@name getRamUsageColumnDef
     *@desc Get column def for info diagnostic RAM Usage data-grid
     *@return array[any]
     */
    public getRamUsageColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.ramUsage.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.ramUsage.name), field: this._HEADER_FIELDS.ramUsage.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.xptTomcat.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.ptTomcat.name), field: this._HEADER_FIELDS.ptTomcat.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName:localizationService.instant( this._HEADER_FIELDS.OS.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.OS.name), field: this._HEADER_FIELDS.OS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }

    /*
     *@name getCpuUsageColumnDef
     *@desc Get column def for info diagnostic CPU Usage data-grid
     *@return array[any]
     */
    public getCpuUsageColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.cpuUsage.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.cpuUsage.name), field: this._HEADER_FIELDS.cpuUsage.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.xptTomcat.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.ptTomcat.name), field: this._HEADER_FIELDS.ptTomcat.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName:localizationService.instant( this._HEADER_FIELDS.OS.name),headerTooltip:localizationService.instant(this._HEADER_FIELDS.OS.name), field: this._HEADER_FIELDS.OS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }

    /*
     *@name getHCUCollectionColumnDef
     *@desc Get column def for info diagnostic HCU Collection data-grid
     *@return array[any]
     */
    public getHCUCollectionColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: '',field: 'name',
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name), field: this._HEADER_FIELDS.timHHMMSS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.hcu.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.hcu.name), field: this._HEADER_FIELDS.hcu.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.spectrumPorts.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.spectrumPorts.name), field: this._HEADER_FIELDS.spectrumPorts.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.macTrakPorts.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.macTrakPorts.name), field: this._HEADER_FIELDS.macTrakPorts.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }

    /*
     *@name getDownstreamCollectionColumnDef
     *@desc Get column def for info diagnostic downstream , QoECMTS , QoeCM , PNMPreEq data-grid
     *@return array[any]
     */
    public getDownstreamCollectionColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: '',field: 'name',
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name), field: this._HEADER_FIELDS.timHHMMSS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.nodes.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.nodes.name), field: this._HEADER_FIELDS.nodes.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }

    /*
     *@name getRciCollectionColumnDef
     *@desc Get column def for info diagnostic RCI Collection data-grid
     *@return array[any]
     */
    public getRciCollectionColumnDef(): any[] {
        let localizationService = this.localeDataService;

        let columnDef: any[] = [
            {
                headerName: '',field: 'name',
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.timHHMMSS.name), field: this._HEADER_FIELDS.timHHMMSS.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant( this._HEADER_FIELDS.nodes.name),headerTooltip:localizationService.instant( this._HEADER_FIELDS.nodes.name), field: this._HEADER_FIELDS.nodes.field,
                minWidth: 100,filter: 'text',floatingFilterComponentParams:{ suppressFilterButton:true },
                comparator: gridCustomComparator,
                filterParams: {newRowsAction: 'keep'}
            },
        ]
        return columnDef;
    }

}