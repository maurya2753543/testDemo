import {SharedService} from "../../../shared/shared.service";
/**
 * Created by B.Kasturiwale on 18-08-2017.
 */
export class DiagnosticSummary{

    public ram =[];
    public gridRows = [];
    private index:number;

    constructor(jsonList, sharedService : SharedService, localizationService ?: any, languageService ?:any){

        let index = 0;
        let colKeys:any = [];
        let rowKeys:any = [];

        Object.keys(jsonList).forEach((currentKey)=> {

            colKeys.push(currentKey);

            if(index > 0){

                Object.keys(jsonList[currentKey]).forEach((currentKey)=> {
                    if(rowKeys.indexOf(currentKey) == -1)
                        rowKeys.push(currentKey);
                });
            }
            index++;
        });
        for(let i = 0; i < rowKeys.length; i++) {
            let obj = {};
            let key = 'name';
            obj[key] = localizationService.instant(rowKeys[i]);
            for(let j = 0; j < colKeys.length; j++) {
                switch(rowKeys[i]){
                    case "cpuUsage":
                        if(jsonList[colKeys[j]][rowKeys[i]] != undefined){
                            obj[colKeys[j]] = sharedService.toDecimal(jsonList[colKeys[j]][rowKeys[i]] , '1.2-2').toString()+ " %";
                        }
                        break;
                    case "ramUsage":
                        if(jsonList[colKeys[j]][rowKeys[i]] != undefined){
                            obj[colKeys[j]] = this.ram[j] + " (" + sharedService.toDecimal (jsonList[colKeys[j]][rowKeys[i]] , '1.2-2').toString() + " %)";
                        }
                        break;
                    case "ram":  this.index = i;
                                 if(jsonList[colKeys[j]][rowKeys[i]] != undefined){
                                    obj[colKeys[j]] =  sharedService.toDecimal(jsonList[colKeys[j]][rowKeys[i]] / 1073741824 ,'1.2-2').toString()+ " GB ";
                                    this.ram[j] = obj[colKeys[j]]
                                 }
                        break;
                    case "uptime": obj[colKeys[j]] =  this.convertSecondsToDays(jsonList[colKeys[j]][rowKeys[i]] , localizationService);
                        break;

                    default :  obj[colKeys[j]] = sharedService.toDecimal(jsonList[colKeys[j]][rowKeys[i]], '1.2-2' );
                        break;
                }
            }
            this.gridRows.push(obj);
        }

    }

    private convertSecondsToDays(value, localizationService):any {

        let digit = value / 86400;
        let days  = Math.trunc(digit);
        let hours = Math.trunc((digit % 1) * 24);
        let convertedValue ;
        days == 0? convertedValue = hours + " " + localizationService.instant('hours') : convertedValue = days + " " +localizationService.instant('days')+ " " + hours + " " + localizationService.instant('hours');
        return convertedValue;
    }

    public diagSummary(){
        this.gridRows.splice(this.index,1);
        return this.gridRows;
    }

}

