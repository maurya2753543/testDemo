import { TranslateService } from '@ngx-translate/core';
import { SharedService } from 'src/app/shared/shared.service';
//import { TranslatePipe } from 'angular2localization';
/**
 * Created by nikita.dewangan on 22-08-2017.
 */

//import {LocalizationService} from "angular2localization/angular2localization";

export class DiagnosticCpuUsageModel{

    constructor(){}

    public addElementsToList(jsonList, gridRows : any , localizationService : TranslateService,  language : string ,days:number,sharedService:SharedService){
        let colKeys:any = [];
        let rowKeys:any = [];
        let decimal : string = '1.2-2';

        Object.keys(jsonList).forEach((currentKey)=> {
            colKeys.push(currentKey);
        });

        rowKeys.push("cpuUsageMax","cpuUsageAvg");

        for(let i = 0; i < rowKeys.length; i++) {
            let obj = {};

            let key= 'name';
            if(days ==1){
                obj[key] = localizationService.instant(rowKeys[i]) + localizationService.instant('Day');
            }else{
                obj[key] = localizationService.instant(rowKeys[i]) +  localizationService.instant('Week');
            }

            for(let j = 0; j < colKeys.length; j++) {
                switch(rowKeys[i]){
                    case "cpuUsageMax":
                        obj[colKeys[j]] =  sharedService.toDecimal(jsonList[colKeys[j]][rowKeys[i]],  decimal ).toString()+ " %";
                        break;
                    case "cpuUsageAvg":
                        obj[colKeys[j]] = sharedService.toDecimal (jsonList[colKeys[j]][rowKeys[i]] , decimal ).toString() + " %";
                        break;
                }
            }
            if( gridRows.indexOf(obj[key]) == -1)
                gridRows.push(obj);

        }

    }
}

