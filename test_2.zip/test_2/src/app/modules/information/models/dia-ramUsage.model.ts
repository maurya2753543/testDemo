import { TranslateService } from '@ngx-translate/core';
import { SharedService } from 'src/app/shared/shared.service';
/**
 * Created by nikita.dewangan on 21-08-2017.
 */

//import {LocalizationService} from "angular2localization/angular2localization";

export class DiagnosticRamUsageModel{

    constructor(){}

    public addElementsToList(jsonList, gridRows : any , localizationService : TranslateService, language : string,days:number,sharedService:SharedService
    ){
        let index = 0;
        let colKeys:any = [];
        let rowKeys:any = [];
        let dateRamCPUUsage = [];
        let decimal : string = '1.2-2';
        let convertToGB : number = 1073741824;

        Object.keys(jsonList).forEach((currentKey)=> {
            colKeys.push(currentKey);
        });

        rowKeys.push("ramMax","ramAvg");

        for(let i = 0; i < rowKeys.length; i++) {
            let obj = {};

            let key= 'name';
            if(days ==1){
               obj[key] = localizationService.instant(rowKeys[i]) + localizationService.instant('Day');
            }else{
                obj[key] = localizationService.instant(rowKeys[i]) +  localizationService.instant('Week');
            }


            for(let j = 0; j < colKeys.length; j++) {
                switch(rowKeys[i]){
                    case "ramMax":
                        obj[colKeys[j]] =  sharedService.toDecimal(jsonList[colKeys[j]][rowKeys[i]] / convertToGB ,  decimal ).toString()+ " GB";
                        break;
                    case "ramAvg":
                        obj[colKeys[j]] = sharedService.toDecimal (jsonList[colKeys[j]][rowKeys[i]] / convertToGB,  decimal ).toString() + " GB";
                        break;
                }
            }
             gridRows.push(obj);

        }


    }

}

