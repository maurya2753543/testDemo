import {SharedService} from "../../../shared/shared.service";
/**
 * Created by nikita.dewangan on 07-08-2017.
 */

// model for downstream , QoECMTS , QoeCM , PNMPreEq accordion
export class DiagnosticDownstreamList extends Array{

    constructor(jsonList : any , sharedService : SharedService, localizationService : any, browser:any){
        super();
        Object.keys(jsonList).forEach((currentKey)=> {
            let diagnosticDownstreamModel : DownstreamList = new DownstreamList(jsonList[currentKey] , currentKey , sharedService,localizationService,browser);
            this.push(diagnosticDownstreamModel);
        });
    }

}

 class DownstreamList{

    public startTime : string ;
    public duration_ms : number;
    private serverDuration_ms : string;
    public nodeCount : number;
    public name:string;

    constructor(jsonData , name : string , sharedService : SharedService,localizationService, browser:any){
        this.name = localizationService.instant(name);
        this.startTime = sharedService.getLocaleDate(jsonData.startTime);
        this.duration_ms = jsonData.duration_ms;
        this.nodeCount = jsonData.nodeCount;
        this.serverDuration_ms =  this.milliSecToHHmmssConv(this.duration_ms);
    }

     private milliSecToHHmmssConv(duration){
         let milliseconds : number = parseInt((duration % 1000).toString());
         let seconds : number = parseInt(((duration / 1000) % 60).toString());
         let minutes : number = parseInt(((duration / (1000 * 60)) % 60).toString());
         let hours : number = parseInt(((duration / (1000 * 60 * 60)) % 24).toString());

         return this.formatTime(hours) + ":" + this.formatTime(minutes) + ":" + this.formatTime(seconds) + "." + milliseconds;
     }

     private formatTime(variable) {
        return (variable < 10) ? "0" + variable : "" + variable;
     }
}

