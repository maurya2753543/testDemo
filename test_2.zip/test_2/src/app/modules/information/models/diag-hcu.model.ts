/**
 * Created by nikita.dewangan on 21-08-2017.
 */

import {SharedService} from "../../../shared/shared.service";

export class DiagnosticHCUModel extends Array{

    constructor(jsonList : any , sharedService : SharedService, localizationService : any, browser:any){
        super();
        Object.keys(jsonList).forEach((currentKey)=> {
            let HCUResponseModel : HCUList = new HCUList(jsonList[currentKey] , currentKey , sharedService,localizationService,browser);
            this.push(HCUResponseModel);
        });
    }

}

class HCUList{

    public startTime : string ;
    private duration_ms : string;
    public hcuCount : number;
    private spectralPortCount : number;
    public mactrakPortCount : number;
    public name:string;
    private serverDuration_ms : string;

    constructor(jsonData , name : string , sharedService : SharedService,localizationService, browser:any){

        this.name = localizationService.instant(name);
        this.startTime = sharedService.getLocaleDate(jsonData.startTime);
        this.duration_ms = jsonData.duration_ms;
        this.hcuCount = jsonData.hcuCount;
        this.spectralPortCount = jsonData.spectralPortCount;
        this.mactrakPortCount = jsonData.mactrakPortCount;
        this.serverDuration_ms = this.milliSecToHHmmssConv(this.duration_ms);
    }

    private milliSecToHHmmssConv(duration){
        let milliseconds : number = Number((duration % 1000));
        let seconds : number = Number((duration / 1000) % 60);
        let minutes : number = Number((duration / (1000 * 60)) % 60);
        let hours : number = Number((duration / (1000 * 60 * 60)) % 24);

        return this.formatTime(hours) + ":" + this.formatTime(minutes) + ":" + this.formatTime(seconds) + "." + milliseconds;
    }

    private formatTime(variable) {
        return (variable < 10) ? "0" + variable.toFixed(0) : "" + variable.toFixed(0);
    }
}