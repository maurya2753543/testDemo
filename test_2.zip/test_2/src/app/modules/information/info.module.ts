import { UserStatsComponent } from "./UserStats/UserStats";

/**
 * Created by nikita.dewangan on 01-06-2017.
 */

import { NgModule } from "@angular/core";
// import { Locale } from "angular2localization";
// import { LocaleModule, LocalizationModule } from "angular2localization";
import { CommonModule, DatePipe } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { InformationComponent } from "./information.component";
import { InformationHttpService } from "./information.http.service";
import { InformationUrlService } from "./information.url.service";
import { InfoRoutes } from "./info.routes";
import { LocaleDataService } from "../../shared/locale.data.service";
import { SweetAlert } from "../../utilities/sweetAlert";
import { Logger } from "../../utilities/logger";
import { SharedModule } from "../shared/shared.module";

import { LicenseInformationComponent } from "./license-information/license-information.component";
import { BasicInformationComponent } from "./basic-information/basic-information.component";
import { DiagnosticComponent } from "./diagnostic/diagnostic.component";
import { TriggersComponent } from "./triggers/triggers.component";
import {BasicInfoDataService} from "./basic-information/basic-information-data.service";
import {LicenseInfoDataService} from "./license-information/license-information.data.service";
import {DiagnosticDataService} from "./diagnostic/diagnostic.data.service";
import {DiagnosticColumnDefinitionService} from "./diagnostic/diagnostic.column-definition.service";
import {TriggersDataService} from "./triggers/triggers.data.service";
import { TriggersService } from "./triggers/triggers.service";
import {LogComponent} from "./log/log.component";
import {LogDataService} from "./log/log-data.service";
import {LogConfigurationService} from "./log/log.configuration.service";
import { DataStatsComponent } from "./data-stats/data-stats.component";
import { MyDatePickerModule } from "mydatepicker";
// import { AngularDateTimePickerModule } from "angular2-datetimepicker";
import { HighchartsChartModule } from 'highcharts-angular';
// import { HighchartsStatic } from "angular2-highcharts/dist/HighchartsService";
import {UserStatsConfigService} from "./UserStats/userStats.configuration.service";
import {UserDataService} from "./UserStats/user-data.service";
import { ActivitySummaryComponent } from "./activity-summary/activity-summary.component";
import {ActivitySummaryService} from "./activity-summary/activity-summary.data.service";
import { LanguageService } from 'src/app/shared/locale.language.service';
import { HttpClient } from "@angular/common/http";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import * as AppConstants from './../../constant/app.constants';

declare var require: any;

export function highchartsFactory() {
  const hc = require("highcharts");
  return hc;
}
export function HttpLoaderFactory(http: HttpClient) {
  let lan = navigator.language.split('-')[0];
  const langs = AppConstants.LANGUAGE_LIST_SHORT;
  const isLang = langs && langs.find(lang => lang === lan);
  const lang = (isLang) ? isLang : 'en';
  return new TranslateHttpLoader(http, `./././assets/lang/${lang}/info-locale-`, ".json");
}
@NgModule({
  imports: [
    InfoRoutes,
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    // AngularDateTimePickerModule,
    MyDatePickerModule,
    HighchartsChartModule,  
    TranslateModule.forRoot({
      loader: {
      provide: TranslateLoader,
      useFactory: HttpLoaderFactory,
      deps: [HttpClient]
    }}),
    // LocaleModule.forRoot(), // New instance of LocaleDataService.
    // LocalizationModule.forRoot(), // New instance of LocalizationService.
    
  ],
  declarations: [
    InformationComponent,
    LicenseInformationComponent,
    BasicInformationComponent,
    DiagnosticComponent,
    TriggersComponent,
    LogComponent,
    UserStatsComponent,
    DataStatsComponent,
    ActivitySummaryComponent
  ],
  providers: [
    LocaleDataService,
    Logger,
    SweetAlert,
    InformationHttpService,
    InformationUrlService,
    BasicInfoDataService,
    LicenseInfoDataService,
    DiagnosticDataService,
    DiagnosticColumnDefinitionService,
    TriggersService,
    TriggersDataService,
    LogDataService,
    LogConfigurationService,
    DatePipe,
    UserStatsConfigService,
    UserDataService,
    // { provide: HighchartsStatic, useFactory: highchartsFactory },
    ActivitySummaryService,
    TranslateService,
    LanguageService
  ],
  entryComponents: [
    LicenseInformationComponent,
    BasicInformationComponent,
    DiagnosticComponent,
    TriggersComponent,
    LogComponent,
    UserStatsComponent,
    DataStatsComponent,
    ActivitySummaryComponent
  ],
})
export class InfoModule{}
