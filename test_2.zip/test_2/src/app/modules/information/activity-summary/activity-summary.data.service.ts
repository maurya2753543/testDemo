import { InformationHttpService } from './../information.http.service';
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import {map, catchError} from "rxjs/operators";

import { HttpResponse } from "@angular/common/http";

@Injectable()
    export class ActivitySummaryService{

        constructor( private informationHttpService:InformationHttpService){

        }
        public getUserSummaryData(params:any){
            return this.informationHttpService.getUsersActivitySummaryData(params)
            .pipe(map(
              (data: HttpResponse<any>) => {
                return this.processData(data);
              },
              (error) => {
                return error;
              }
            ))


        }
    processData(xyz:any) {
        return xyz;
       
    }
        

    }
    
