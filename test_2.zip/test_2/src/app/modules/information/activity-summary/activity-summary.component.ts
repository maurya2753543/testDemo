//import { TranslatePipe } from 'angular2localization';
import { Component, ViewEncapsulation, HostListener} from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { LocaleDataService } from "../../../shared/locale.data.service";
import {LogDataService} from "../log/log-data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {UserStatsConfigService} from "../UserStats/userStats.configuration.service";
import { InformationUrlService } from "../information.url.service";
import { InformationHttpService } from "../information.http.service";
import {UserDataService} from "../UserStats/user-data.service";
import { DatePipe } from "@angular/common";
import { IMyDateModel, IMyDate, IMyDpOptions } from "mydatepicker";
import { feature } from "../UserStats/user.model";
import {ActivitySummaryService} from "./activity-summary.data.service";
import * as Highcharts from 'highcharts';
import { format } from "url";
import {LANGUAGE_LIST_SHORT} from "./../../../constant/app.constants"
import { map } from 'rxjs/operators';
declare var require: any;
const noData = require("highcharts/modules/no-data-to-display.js");
noData(Highcharts);
// Highcharts.setOptions({
//   global: {
//       useUTC: false
//   }
// });
interface DaysValue {
  value: number;
  days: string;
}

@Component({
    selector: 'activity-summary',
    templateUrl: 'activity-summary.component.html',
    encapsulation: ViewEncapsulation.None
})

export class  ActivitySummaryComponent{
  private arr_Translated = [];
  dateFormat: string;
  public selDate: IMyDate = { year: 0, month: 0, day: 0 };
  sevenDayDuration: string;
  fifthteenDayDuration: string;
  thirtyDayDuration: string;
  DAYS: DaysValue[] = [];
  yAxisTitle: string;
  xAxisTitle: string;
  noDataText: string;
  tooltipFeatureName:string;
  tooltipDate:string;
  tooltipCount:string;
  shortMonths:Array<string>;
  months:Array<string>;
  weekdays:Array<string>;
  showLegend:boolean = false;
  date: Date = new Date();
  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: "yyyy-mm-dd",
    disableSince: {year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1}
  };
  

  locale: string = "en";
  feature_name: string = "0";
  duration = 7;
  features: feature[] = [];
  public activitySummaryForm: FormGroup;

  private preFormData: Object = {};
  activityChart: any;
  options:any;

  constructor(
    private localeDataService: LocaleDataService,
    private logDataService: LogDataService,
    private showAlert: ShowAlert,
    private userStatsConfigService: UserStatsConfigService,
        private informationUrlService: InformationUrlService,
        private informationService: InformationHttpService,
        private userDataService: UserDataService,
        private datePipe: DatePipe,
        private formBuilder: FormBuilder,
        private activitySummaryDataService:ActivitySummaryService
      ) {}

      Highcharts: typeof Highcharts = Highcharts;
      ngOnInit(){
        let lan = navigator.language.toLocaleLowerCase().split('-')[0];
        if(lan.includes('zh')){
          this.locale = 'zh-cn';
        }
        if(LANGUAGE_LIST_SHORT.includes(lan))
        {
         this.locale=lan;
         console.log(lan);
        }
        else{
             this.locale=='en';
           console.log("else")
           }
        this.translateLocaleString();
        this.initForm();
        this.DAYS = [
          { value: 7, days: this.sevenDayDuration },
          { value: 15, days: this.fifthteenDayDuration },
          { value: 30, days: this.thirtyDayDuration },
        ];
        this.getFeatureName();
        this.myDatePickerOptions = {
          allowSelectionOnlyInCurrentMonth: false,
          dateFormat: this.dateFormat,
          showTodayBtn: false,
          showClearDateBtn: false,
          disableSince : {year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1}
        };
        this.setChartOptions()

      }

      @HostListener('window:resize', ['$event'])
      onResize(event) {
        this.activityChart.redraw();
        this.activityChart.reflow();
      }

      setChartOptions(){
        this.options = {
          chart: {
            type: 'line',
            zoomType: 'xy',
            renderTo: "container",
        },
        exporting: {
          scale: 1,
          buttons: {
            contextButton: {
              menuItems: ["printChart", "downloadJPEG", "downloadPDF"],
            },
          },
        },
        title: {
        text: null,
      },
        credits: {
          enabled: false,
        },
        lang: {
          noData: this.noDataText,
        },
        legend:{
          enabled:false,
          align: 'right',
          verticalAlign: 'middle',
          layout: 'vertical',
        },
        xAxis: {
            type: 'datetime',
            tickInterval:24 * 3600 * 1000,
            //startOnTick: true,
            title: {
              text: this.xAxisTitle,
            },
            minRange: 24 * 3600 * 1000,
        },
        yAxis: {
          title: {
            text: this.yAxisTitle,
          },
        },
        plotOptions: {
          series: {
            dataLabels: {
              enabled: false,
            },
            pointInterval: 24 * 3600 * 1000 ,
                    },
        },
        tooltip: {
            valueSuffix: ''
        },
        series: []
        }


        //this.activityChart = Highcharts.chart(this.options);
      }
      initForm(){
        let d: Date = new Date();
        this.activitySummaryForm = this.formBuilder.group({
          date: [
            {
              date: {
                year: d.getFullYear(),
                month: d.getMonth() + 1,
                day: d.getDate(),
              },
              jsdate: d,
            },
          ],
          duration: 7,
          feature_name: "0",
        });

      }

      onSubmit(value: any) {
        event.preventDefault();
        this.activityChart.showLoading();
        this.activityChart.hideNoData();
        let formValue = Object.assign({}, this.activitySummaryForm.value);
        formValue.date = this.customeDateFormat(formValue.date);
        this.getUserSummary(formValue);
        while(this.activityChart.series.length > 0)
        this.activityChart.series[0].remove(true);
        this.activityChart.legend.update({
          enabled:false
        })

      }
      getUserSummary(params: any) {
        this.activitySummaryDataService
          .getUserSummaryData(params)
          .subscribe(this.onData.bind(this), this.onError.bind(this));
      }
      toggleLegend(){
        this.activityChart.legend.update(this.activityChart.legend.options.enabled ? {
          enabled: false,
        } : {
            enabled: true
          });
      }
      private onData(data): void {
        let localizationService = this.localeDataService.getLocalizationService();
        let activityDate = [];
        let groupedFeatures;
        if (data.length != 0) {
          data.forEach(element => {
            element.userActionSummaryList.forEach(list => {
              let milliseconds = new Date(element.date).getTime();
              let customDate = new Date(milliseconds - (milliseconds%(1000*60*60*24)));
              let obj = {
                x:customDate,
                feature:list.feature,
                y:list.totalActionCount,
                dt : customDate.toLocaleDateString(this.locale, {year: 'numeric', month: 'short', day: 'numeric' })
              }

              activityDate.push(obj)
            });

          });
          groupedFeatures = activityDate.reduce(function (r, a) {
            r[a.feature] = r[a.feature] || [];
            r[a.feature].push(a);
            return r;
        }, Object.create(null));

        for (const [key, value] of Object.entries(groupedFeatures)) {
          this.activityChart.addSeries({
            name:key,
            data:value,
            tooltip: {
              headerFormat: this.tooltipFeatureName +":" + "<b>"+  localizationService.instant(key) + "</b>" + "<br/>",
              pointFormat:
                this.tooltipDate + ":" + "<b> {point.dt} </b> <br/> " + this.tooltipCount + ":" + " <b> {point.y} </b>",
            },
          })

        }
        this.activityChart.hideLoading();
        } else {
          this.activityChart.hideLoading();
          this.activityChart.showNoData();
         //this.isLoading = false;
        }
      }
      
      private onError(error: any): void {
        this.activityChart.hideLoading();
        this.showAlert.showErrorAlert(error);
      }

      customeDateFormat(date) {
        var jsdateTemp = new Date(date.jsdate);
        var date_timezone = new Date(
          jsdateTemp.getTime() - jsdateTemp.getTimezoneOffset() * 60000
        );
        let substr = new Date(date_timezone).toISOString();
        return (
          substr.substr(0, substr.indexOf("T")) +
          "T" +"05:00:00.000+0000"
        );
      }

      saveChart(chartInstance){
        this.activityChart = chartInstance;
      }

    getFeatureName() {
      let localizationService = this.localeDataService.getLocalizationService();
      this.informationService
        .getUserFeatureNames()
        .pipe(map((response) => response))
        .subscribe((data: string[]) => {
          for (let f in data) {
            this.arr_Translated.push({
              name: localizationService.instant(data[f]),
              value: data[f],
            });
            for(let j in this.arr_Translated ){
              if(this.arr_Translated[j].value === "cleared element alarms"){
                this.arr_Translated[j].name = localizationService.instant("Cleared Hardware Alarms");
              }
              if(this.arr_Translated[j].value === "Cleared multiple alarms"){
                this.arr_Translated[j].name = localizationService.instant("Cleared Multiple Alarms");
              }
              if(this.arr_Translated[j].value === "Cleared network alarms"){
                this.arr_Translated[j].name = localizationService.instant("Cleared Network Alarms");
              }
              if(this.arr_Translated[j].value === "User change password"){
                this.arr_Translated[j].name = localizationService.instant("User Change Password");
              }
              if(this.arr_Translated[j].value === "Starting OLT Port-mapping session"){
                this.arr_Translated[j].name = localizationService.instant("Starting OLT Port-Mapping Session");
              }
            }
          }
          this.features = this.arr_Translated.sort((a, b) =>
            a.name.localeCompare(b.name)
          );
        });
    }

    resetFieldsToDefault(){
      this.initForm();

    }
    private translateLocaleString(): void {
      let localizationService = this.localeDataService.getLocalizationService();
      this.fifthteenDayDuration = localizationService.instant("FIFTHTEEN_DAYS");
      this.thirtyDayDuration = localizationService.instant("THIRTY_DAYS");
      this.sevenDayDuration = localizationService.instant("SEVEN_DAYS");
      this.dateFormat = localizationService.instant("DATE_FORMAT");
      this.yAxisTitle = localizationService.instant("COUNTS");
      this.xAxisTitle = localizationService.instant("Days");
      this.noDataText = localizationService.instant("DATA_CHART_NODATA");
      this.shortMonths = localizationService
      .instant("SHORTMONTH")
      .replace(/\s/g, "")
      .split(",");
    this.months = localizationService
      .instant("MONTH")
      .replace(/\s/g, "")
      .split(",");
    this.weekdays = localizationService
      .instant("DAY")
      .replace(/\s/g, "")
      .split(",");
      this.tooltipFeatureName = localizationService.instant("FEATURE_NAME");
      this.tooltipDate=localizationService.instant("DATA_CHART_DATE");
      this.tooltipCount=localizationService.instant("COUNTS");
      Highcharts.setOptions({
        lang: {
          loading: localizationService.instant("DATA_CHART_LOADING"),
          months: this.months,
          weekdays: this.weekdays,
          shortMonths: this.shortMonths,
          printChart: localizationService.instant("CHART_PRINT_CHART"),
          downloadJPEG: localizationService.instant("CHART_DOWNLOAD_JPEG"),
          downloadPDF: localizationService.instant("CHART_DOWNLOAD_PDF"),
          downloadSVG:localizationService.instant("CHART_DOWNLOAD_SVG"),
          downloadPNG:localizationService.instant("CHART_DOWNLOAD_PNG")
        },
      });

    }

    /* Method get called when we come in data after switch the tab */
  public onTabSwitch(): void {
    //To implement if any changes on tabSwitch required
  }

}
