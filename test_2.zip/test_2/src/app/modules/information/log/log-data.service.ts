import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import { map } from 'rxjs/operators';
import {HttpResponse} from "@angular/common/http";

import {InformationHttpService} from "../information.http.service";
import {LogModel} from "./log.model";
import {DELETE_LOG_FILE_ACTION, LIST_ACTION} from "../../../constant/app.constants";

@Injectable()
export class LogDataService {

    constructor(private informationHttpService:InformationHttpService){}

    public getInfo(action: string) : Observable<any>{
        return this.informationHttpService.getLogList(action).pipe(map(
            (data) => {
                if(action === LIST_ACTION){
                    return this.processData(data);
                }
                return true;
            }, error => {
                return error;
            }))
    }

    private processData(data: any[]): LogModel[]{
        let logModels: LogModel[] = [];
        data.forEach((obj: any)=>{
            logModels.push(new LogModel(obj));
        });
        return logModels;
    }

}
