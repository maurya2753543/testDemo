export class LogModel{
    public dateTime: string;
    public category: string;
    public logLevel: string;
    public logLocation: string;
    public details: string;

    constructor(data: any){
        this.dateTime = data.dateTime;
        this.category = data.category;
        this.logLevel = data.logLevel;
        this.logLocation = data.logLocation;
        this.details = data.details;
    }
}