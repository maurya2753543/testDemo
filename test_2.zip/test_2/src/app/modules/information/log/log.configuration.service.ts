import {Injectable} from "@angular/core";

import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {TimeFilter} from "../../../shared/time.filter";

@Injectable()
export class LogConfigurationService{

    private _HEADER_FIELDS: any = {
        dateTime : {field: "dateTime", name: ""},
        category : {field: "category", name: ""},
        logLevel : {field: "logLevel", name: ""},
        logLocation : {field: "logLocation", name: ""},
        details : {field: "details", name: ""}
    };

    constructor(private localeDataService: LocaleDataService,
                private sharedService : SharedService){}

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();
        this._HEADER_FIELDS.dateTime.name = localizationService.instant('DATE_TIME');
        this._HEADER_FIELDS.category.name = localizationService.instant('CATEGORY');
        this._HEADER_FIELDS.logLevel.name = localizationService.instant('LOG_LEVEL');
        this._HEADER_FIELDS.logLocation.name = localizationService.instant('LOG_LOCATION');
        this._HEADER_FIELDS.details.name = localizationService.instant('DETAILS');
    }


    /*
    *@name getColumnDef
    *@desc Get column def for alarm-list data-grid
    *@return array[any]
   */
    public getColumnDef(): any[] {
        this.translateLocaleStr();

        let columnDef: any[] = [
            this.getColumns(this._HEADER_FIELDS.dateTime.name,
                this._HEADER_FIELDS.dateTime.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.dateTime.name, 120), "text"),

            this.getColumns(this._HEADER_FIELDS.logLevel.name,
                this._HEADER_FIELDS.logLevel.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.logLevel.name, 50), "text"),


            this.getColumns(this._HEADER_FIELDS.logLocation.name,
                this._HEADER_FIELDS.logLocation.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.logLocation.name, 120), "text"),


            this.getColumns(this._HEADER_FIELDS.details.name,
                this._HEADER_FIELDS.details.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.details.name, 280), "text")

        ];

        return columnDef;
    }

    //@method :: get column definition
    private getColumns(headerName: string, field: string, minWidth: number, filter: string): any{
        let def: any = {
            headerName: headerName,
            field: field,
            filter: filter,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {suppressAndOrCondition: true,
                newRowsAction: 'keep'},
            sortable: true,
            resizable:true
        }
        if(!(field === this._HEADER_FIELDS.logLocation.name || field === this._HEADER_FIELDS.details.name)){
            def["width"] = minWidth;
        }
        if(field === this._HEADER_FIELDS.dateTime.field){
            def["cellRenderer"] = (params:any)=>{
                return this.sharedService.getLocaleDate(params.value);
            };
            def["comparator"] = this.sharedService.dateComparator;
            def["filter"] = TimeFilter.ParentFilter;
            def["floatingFilterComponent"] = TimeFilter.ChildFloatingFilter;
        }else{
            def["comparator"] = gridCustomComparator;
        }

        if(field === this._HEADER_FIELDS.details.field){
            def["cellStyle"] = { "white-space": "normal" };
        }

        return def;
    }
}