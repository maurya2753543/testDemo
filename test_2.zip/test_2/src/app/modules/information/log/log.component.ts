import {Component} from "@angular/core";

import {LocaleDataService} from "../../../shared/locale.data.service";
import {Grid} from "../../../shared/ag-grid.options";
import {LogDataService} from "./log-data.service";
import {LogModel} from "./log.model";
import {LogConfigurationService} from "./log.configuration.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {DELETE_LOG_FILE_ACTION, LIST_ACTION, PURGE_LIST_ACTION, PERM_ADMINISTER_PATHTRAK_SERVERS} from "../../../constant/app.constants";
import {InformationUrlService} from "../information.url.service";
import {SharedService} from "../../../shared/shared.service";

@Component({
  templateUrl: "log.component.html",
  selector: "log",
  styleUrls:["./log.component.scss"]
})
export class LogComponent{

    buttonKeys: Object[];
    gridOptions: Grid = new Grid();
    private gridApi: any;
    private GRID_TAB_TYPE:string;
    gridTabType:any;

    private PURGE_TABLE: string;
    private EXPORT_TABLE: string;
    private EXPORT_DETAILS: string;
    private DELETE_ZIP: string;
    private PURGE_TABLE_CONFIRM_MESSAGE: string;
    private DELETE_TABLE_CONFIRM_MESSAGE: string;
    private LAUNCH_KIBANA: string ;
    private action: string;
    rowdata: LogModel[];

    private LAUNCH_KIBANA_BTN:string;
    private EXPORT_TABLE_BTN:string;
    private EXPORT_DETAILS_BTN:string;
    private DELETE_ZIP_BTN:string;

    constructor(private localeDataService: LocaleDataService,
                private logDataService: LogDataService,
                private showAlert: ShowAlert,
                private logConfigurationService: LogConfigurationService,
                private sharedService: SharedService,
                private informationUrlService: InformationUrlService){}

    ngOnInit() {
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.action = LIST_ACTION;
    }

    //Method to set button keys
    setEventButtonKeys():void {
        if (this.sharedService.checkPermissions(PERM_ADMINISTER_PATHTRAK_SERVERS)) {
            this.buttonKeys = [
                // {name: this.PURGE_TABLE , tabType: "info"},
                {name: this.LAUNCH_KIBANA , tabType: "info",label:this.LAUNCH_KIBANA_BTN},
                {name: this.EXPORT_TABLE , tabType: "info",label:this.EXPORT_TABLE_BTN},
                {name: this.EXPORT_DETAILS, tabType: "info",label:this.EXPORT_TABLE_BTN},
                {name: this.DELETE_ZIP , tabType: "info",label:this.DELETE_ZIP_BTN}
            ];
        } else {
            this.buttonKeys = [
                {name: this.PURGE_TABLE , tabType: "info"},
                {name: this.EXPORT_TABLE , tabType: "info"},
                {name: this.DELETE_ZIP , tabType: "info"},
                {name: this.LAUNCH_KIBANA , tabType: "info"}
            ];
        }
    }

    public onTabSwitch(isApiReq ?: boolean): void {
        this.notifyRefreshGrid();
    }

    private getData(action: string): void{
        if(!(action === DELETE_LOG_FILE_ACTION)){
            // this.showGridLoading();
        }
        this.logDataService.getInfo(action).subscribe(this.onData.bind(this), this.onError.bind(this));
    }

    private onData(data: LogModel[]|boolean): void{
        if(typeof data === "boolean"){
            if(this.action === PURGE_LIST_ACTION){
                this.showNoData();
            }
        }else{
            if(data.length){
                this.setData(data);
                // this.hideGridLoading();
            }else {
                this.showNoData();
            }
        }
    }

    // private showGridLoading(): void{
    //     this.gridApi.showLoadingOverlay();
    // }

    // private showGridNoDataAvilable(): void{
    //     this.gridApi.showNoRowsOverlay();
    // }

    // private hideGridLoading(): void{
    //     this.gridApi.hideOverlay();
    // }

    private setData(data: LogModel[]): void{
        this.rowdata = data;
    }

    // notifyGridReady(): void{
    //     this.gridApi = this.gridOptions.api;
    //     this.setColDef();
    // }

    // setColDef(): void{
    //     this.gridApi.setColumnDefs(this.logConfigurationService.getColumnDef());
    //     this.getData(this.action);
    //     this.gridOptions["getRowHeight"] = (params) => {
    //         let messageWidthCalc = Math.floor(params.data.details.length / 45);
    //         return ((window.innerWidth >= 750) ? 11 * (messageWidthCalc + 2) : 22 * (messageWidthCalc + 1)) ;
    //     }        
    // }

    notifyActionEmitter(event) {
        switch(event.name) {
            case this.PURGE_TABLE:
                this.purgeTableConfirmation();
                break;
            case this.EXPORT_TABLE:
                this.exportZipFiles();
                break;
            case this.EXPORT_DETAILS:
                this.exportDetailsZipFiles();
                break;
            case this.DELETE_ZIP:
                this.deleteLogFiles();
                break;
            case this.LAUNCH_KIBANA:
                this.redirectKibana();
                break;
            default:
        }
    }

    private redirectKibana():void{
        window.open(this.informationUrlService.getKibanaUrl(),'_blank');
    }

    private exportZipFiles(): void{
        window.open(this.informationUrlService.getGetZipFileUrl(),'_blank');
    }

    private exportDetailsZipFiles(): void{
        window.open(this.informationUrlService.getGetDetailsZipFileUrl(),'_blank');
    }

    private deleteLogFiles(): void{
        this.showAlert.showCustomWarningAlertConfirm("", this.DELETE_TABLE_CONFIRM_MESSAGE , (isConfirm: boolean)=>{
            if(isConfirm){
                this.action = DELETE_LOG_FILE_ACTION;
                this.getData(this.action);
            }
        });
    }

    private purgeTableConfirmation(): void{
        this.showAlert.showCustomWarningAlertConfirm("", this.PURGE_TABLE_CONFIRM_MESSAGE , (isConfirm: boolean)=>{
            if(isConfirm){
                this.action = PURGE_LIST_ACTION;
                this.getData(this.action);
            }
        });
    }

    notifyRefreshGrid(): void{
        this.action = LIST_ACTION;
        this.getData(this.action);
    }

    private showNoData(): void{
        // this.showGridNoDataAvilable();
        this.setData([]);
    }

    //Handle error
    private onError(error: any): void{
        if(this.action === LIST_ACTION){
           this.showNoData();
        }
        this.showAlert.showErrorAlert(error);
    }

    //Translation
    private translateLocaleString():void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.GRID_TAB_TYPE = localizationService.instant('GRID_TAB_TYPE');
        this.PURGE_TABLE = localizationService.instant('PURGE_TABLE');
        this.EXPORT_TABLE = localizationService.instant('EXPORT_TABLE');
        this.EXPORT_DETAILS = localizationService.instant('EXPORT_DETAILS');
        this.DELETE_ZIP = localizationService.instant('DELETE_ZIP');
        this.PURGE_TABLE_CONFIRM_MESSAGE = localizationService.instant('PURGE_TABLE_CONFIRM_MESSAGE');
        this.DELETE_TABLE_CONFIRM_MESSAGE = localizationService.instant('DELETE_TABLE_CONFIRM_MESSAGE');
        this.LAUNCH_KIBANA = localizationService.instant('LAUNCH_KIBANA');
        this.LAUNCH_KIBANA_BTN = localizationService.instant('LAUNCH_KIBANA_BTN');
        this.EXPORT_TABLE_BTN = localizationService.instant('EXPORT_TABLE_BTN');
        this.DELETE_ZIP_BTN = localizationService.instant('DELETE_ZIP_BTN');
    }
}