/**
 * Created by nikita.dewangan on 07-08-2017.
 */


import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import { map ,catchError} from 'rxjs/operators';
import {InformationHttpService} from "../information.http.service";
import {HttpResponse} from "@angular/common/http";

@Injectable()
export class BasicInfoDataService {

    constructor(private informationHttpService:InformationHttpService){}

    // get basic Info
    public getInformationData() : Observable<any>{

        return this.informationHttpService.getInfoUrlData()
        .pipe(map(
            (data: HttpResponse<any>) => {
                let basicInfo = data;
                return basicInfo;
            }, error => {
                return error;
            }))
    }
}
