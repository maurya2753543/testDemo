import {Component} from "@angular/core";

import {BasicInfoDataService} from "./basic-information-data.service";
import {ShowAlert} from "../../../utilities/showAlert";
@Component({
    selector:"basic-information",
    templateUrl:"basic-information.component.html"
})
export class BasicInformationComponent{
    public version:string;
    public build: string;
    public buildNumber: number;
    
    constructor(private basicInfoDataService:BasicInfoDataService,
                private showAlert: ShowAlert){
    }

    ngOnInit(){
        this.getInformationAPIRequest();
    }

    private onInfoSuccessRes(response){
        this.version = response.version;
        this.build = response.buildDate;
        this.buildNumber = response.buildNumber;
    }

    /* Method get called when we come in info after switch the tab */
    public onTabSwitch(): void{
       this.getInformationAPIRequest();
    }

    private onApiError(error){
        this.showAlert.showErrorAlert(error);
    }

    private getInformationAPIRequest():void{
        this.basicInfoDataService.getInformationData().subscribe(this.onInfoSuccessRes.bind(this), this.onApiError.bind(this));
    }
}