import { UserStatsComponent } from "./UserStats/UserStats";
/**
 * Created by nikita.dewangan on 26-05-2017.
 */

import {
  Component,
  ComponentFactoryResolver,
  ViewContainerRef,
  ViewChild,
  ViewChildren,
  QueryList,
  ElementRef,
} from "@angular/core";


import { LocaleDataService } from "../../shared/locale.data.service";
import {
  INFO_MODULE,
  PERM_ADMINISTER_PATHTRAK_SERVERS,
} from "../../constant/app.constants";
import { LicenseInformationComponent } from "./license-information/license-information.component";
import { BasicInformationComponent } from "./basic-information/basic-information.component";
import { DiagnosticComponent } from "./diagnostic/diagnostic.component";
import { SharedService } from "../../shared/shared.service";
import { TriggersComponent } from "./triggers/triggers.component";
import {LogComponent} from "./log/log.component";
import { Router } from "@angular/router";
import { DataStatsComponent } from "./data-stats/data-stats.component";
import { ActivitySummaryComponent } from "./activity-summary/activity-summary.component";
import { TranslateService } from "@ngx-translate/core";
import { NavService } from '../../shared/nav.service';

@Component({
  selector: "information-component",
  templateUrl: "information.component.html",
})
export class InformationComponent {
  public loadComponent: boolean;
  selectedTab: string;
  private url: string;
  constructor(
    public localeDataService: LocaleDataService,
    private sharedService: SharedService,
    public navService: NavService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private viewContainerRef: ViewContainerRef,
    private router: Router,
    private translate : TranslateService
  ) {
    //super(locale, localization);
    SharedService.isLogModule = true;
    let module = INFO_MODULE;
    this.localeDataService.initLanguage(
      module
    ); /* To set the current browser's language */
    //console.log(this.translate.instant('LOGOUT_TEXT'),'translate');
  }

  @ViewChild("targetref", { read: ViewContainerRef }) _targetRef : ElementRef
  @ViewChild("myTestDiv") myTestDiv : ElementRef

  //QueryList<ViewContainerRef>;

  private basicTabRef: any;   
  private licenseTabRef: any;
  private diagnosticTabRef: any;
  private triggersTabRef: any;
  private logTabRef: any;
  private userstatsRef: any;
  private oldSelectedSettings: Object = {};
  private serverPermission: boolean;
  private dataTabRef: any;
  private activitySumRef:any

  ngOnInit() {
    // console.log(this._targetRef,'_targetRef');

    console.log(this.translate.instant('LOGOUT_TEXT'),'translate');
    setTimeout(() => {
      console.log(this.myTestDiv,'myTestDiv');
      console.log(this._targetRef,'_targetRef');

      
      this.setSelectedTab();
    }, 500);
    this.loadComponent = true;


    // this.localeDataService.componentCallback.subscribe((response) => {
    //   this.loadComponent = true;
    //   this.setSelectedTab();

    // });
  }

  getServerPermission(): boolean {
    return this.sharedService.checkPermissions(
      PERM_ADMINISTER_PATHTRAK_SERVERS
    );
  }

  /* Method to switch tabs */
  private LoadTab(tabName: string): void {
    this.serverPermission = this.sharedService.checkPermissions(
      PERM_ADMINISTER_PATHTRAK_SERVERS
    );
    if (
      !(
        !this.serverPermission &&
        (tabName.toLocaleLowerCase() === "license" ||
          tabName.toLocaleLowerCase() === "userstats" ||
          tabName.toLocaleLowerCase() === "data"||
          tabName.toLocaleLowerCase() === "activitysummary"||
          tabName.toLocaleLowerCase() === "triggers"
          )
      )
    ) 
    {
      let selectedTab = this.sharedService.getRedirectTAB();
      // console.log(selectedTab,'1');
      
      this.selectedTab = tabName.toLowerCase();
      // console.log(this.selectedTab,'2');


      if (selectedTab && selectedTab.length > 0) {
        this.selectedTab = selectedTab;
        this.sharedService.setRedirectTAB("");
      }
      switch (this.selectedTab) {
        case "basic":
          // console.log(this._targetRef,'_targetRef')
          this.basicTabRef !== this.oldSelectedSettings["comp"] &&
          this.basicTabRef
            ? this.basicTabRef.instance.onTabSwitch(true)
            : "";
setTimeout(() => {
  this.basicTabRef = this.createComponentOnClick(
    BasicInformationComponent,
    this._targetRef,
    this.basicTabRef
  );
}, 500);
          
          break;

        case "license":
          this.licenseTabRef !== this.oldSelectedSettings["comp"] &&
          this.licenseTabRef
            ? this.licenseTabRef.instance.onTabSwitch(true)
            : "";
          this.licenseTabRef = this.createComponentOnClick(
            LicenseInformationComponent,
            this._targetRef,
            this.licenseTabRef
          );
          break;

        case "diagnostic":
          this.diagnosticTabRef !== this.oldSelectedSettings["comp"] &&
          this.diagnosticTabRef
            ? this.diagnosticTabRef.instance.onTabSwitch(true)
            : "";
          this.diagnosticTabRef = this.createComponentOnClick(
            DiagnosticComponent,
            this._targetRef,
            this.diagnosticTabRef
          );
          break;

        case "triggers":
          this.triggersTabRef !== this.oldSelectedSettings["comp"] &&
          this.triggersTabRef
            ? this.triggersTabRef.instance.onTabSwitch(true)
            : "";
          this.triggersTabRef = this.createComponentOnClick(
            TriggersComponent,
            this._targetRef,
            this.triggersTabRef
          );
          break;
        case "logs":
          console.log(this.oldSelectedSettings);
          this.logTabRef !== this.oldSelectedSettings["comp"] && this.logTabRef
            ? this.logTabRef.instance.onTabSwitch(true)
            : "";
          this.logTabRef = this.createComponentOnClick(
            LogComponent,
            this._targetRef,
            this.logTabRef
          );
          break;
        case "userstats":
          this.userstatsRef !== this.oldSelectedSettings["comp"] &&
          this.userstatsRef
            ? this.userstatsRef.instance.onTabSwitch(true)
            : "";
          this.userstatsRef = this.createComponentOnClick(
            UserStatsComponent,
            this._targetRef,
            this.userstatsRef
          );
          break;
        case "data":
          this.dataTabRef !== this.oldSelectedSettings["comp"] && this.dataTabRef
            ? this.dataTabRef.instance.onTabSwitch(true)
            : "";
          this.dataTabRef = this.createComponentOnClick(
            DataStatsComponent,
            this._targetRef,
            this.dataTabRef
          );
          break;
          case "activitysummary":
            this.activitySumRef !== this.oldSelectedSettings["comp"] &&
            this.activitySumRef
              ? this.activitySumRef.instance.onTabSwitch(true)
              : "";
            this.activitySumRef = this.createComponentOnClick(
              ActivitySummaryComponent,
              this._targetRef,
              this.activitySumRef
            );
            break;

        default: {
          //TO DO: Show error for tab loading
          //console.log("Invalid choice");
          break;
        }
      }
    }
  }

  private setSelectedTab(): void {
    const currentUrl: string = this.router.url;
    this.url = currentUrl.replace("/info/", "");
    if (this.url.includes("license")) {
      // Delay require to load license tab.
      setTimeout(() => {
        this.LoadTab("license");
      }, 300);
    } else if (this.url.includes("logs")) {
      // Delay require to load log tab.
      setTimeout(() => {
        this.LoadTab("logs");
      }, 300);
    } else {
      this.LoadTab("basic");
    }
  }

  /* Function used to create component on tab click */
  private createComponentOnClick(
    clickedComponent: any,
    currentViewContainer: any,
    currentCompRef: any
  ): void {
    console.log("1")
    this.oldSelectedSettings["comp"]
      ? this.oldSelectedSettings["viewRef"].detach()
      : "";
      console.log("2")
    if (!currentCompRef) {
      let componentFactory: any = this.componentFactoryResolver.resolveComponentFactory(
        clickedComponent
      );
      console.log("3")
      currentCompRef = currentViewContainer.createComponent(componentFactory);
      console.log('check')
    } else {
      console.log("4")
      currentViewContainer.insert(currentCompRef.hostView);
    }
    this.oldSelectedSettings = {
      comp: currentCompRef,
      viewRef: currentViewContainer,
    };
    console.log("5")
    return currentCompRef;
  }
}
