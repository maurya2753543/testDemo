
import {Component} from "@angular/core";
import * as FileSaver from 'file-saver';

import {LicenseInfoDataService} from "./license-information.data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {Logger} from "../../../utilities/logger";
import {SharedService} from "../../../shared/shared.service";
import {ControlMessagesService} from "../../../shared/control.messages.service";
import {LocaleDataService} from "../../../shared/locale.data.service";

@Component({
    selector:"license-information",
    templateUrl:"license-information.component.html"
})

export class LicenseInformationComponent{

    public licenseInfo:any;
    tag: string = 'LicenseComponent ::';
    showLoading: boolean = true;
    toggleFeatureCounts: boolean = false;
    private formData = new FormData();
    private storedFile: any = null;
    licenseLogToggle:boolean = false;
    licenseLogResponse:any;
    disableUploadLicense:boolean = true;
    licenseErrorResponse:string ;
    licenseSuccessResponseToggle:boolean = false;
    showPostLoader:Array<boolean> = [false,false];
    waitingForLicenseLog:boolean = false;


    constructor( private sharedService:SharedService ,
                 private licenseInfoDataService:LicenseInfoDataService,
                 private showAlert: ShowAlert,
                 private controlMessagesService:ControlMessagesService,
                 private localeDataService: LocaleDataService,
                 private logger: Logger){
    }

    ngOnInit(){
        this.licenseAPICAlls();
    }

    /* Method get called when we come in license after switch the tab */
    public onTabSwitch(): void{
        this.licenseAPICAlls();
    }


    /*Function to make API call for license Post requests*/
    private licenseAPICAlls():void{
        this.licenseInfoDataService.getLicenseInformation().subscribe(this.onLicenseInfoSuccessRes.bind(this), this.onApiError.bind(this));
    }

    /* Function invoked on success of license info api response */
    private onLicenseInfoSuccessRes(response):void{
        this.licenseInfo = response;
        this.showLoading = false;
    }

    //function get callled when input type file selects different file.
    private fileChange(event:any):void {
        this.formData = new FormData();
        let files: any = event.target.files;
        if(files.length) {

            let file;
            this.storedFile = files[0];
            this.disableUploadLicense = false;
        }else{
            this.disableUploadLicense = true;
        }
        this.formData.append('file', this.storedFile, this.storedFile.name);
    }

    private clearFile(): void{
        let fileInput:any = document.getElementById("fileInput")
        fileInput.value = null;
    }

    // import license API call
    private uploadLicense():void{
        this.showPostLoader[1] = true;
        this.licenseInfoDataService.importLicenseData(this.formData).subscribe(this.onUploadLicenseSuccessRes.bind(this), this.onLicensePostError.bind(this));
    }

    private showhideBtnToggle(){
        this.toggleFeatureCounts = !this.toggleFeatureCounts;
    }

    // upload license success response
    private onUploadLicenseSuccessRes(successMessage):void{
        let localizationService = this.localeDataService.getLocalizationService();
        this.showPostLoader[1] = false;
        this.licenseLogToggle = true;
        this.licenseSuccessResponseToggle = true;
        if(successMessage){
            this.licenseErrorResponse = successMessage
        }
        else {
            this.licenseErrorResponse = localizationService.instant('LICENSE_SUCCESSFULLY_PROCESSED') ;
        }
        this.licenseInfoDataService.getLicenseLog().subscribe(this.onLicenseLogSuccessRes.bind(this), this.onLicenseLogError.bind(this));
    }

    /* Function invoked on success of export log api response */
    private onExportLogSuccessRes(response):void{
        this.waitingForLicenseLog = false;
        let exportFileData: string = response;        
        let file = new Blob([exportFileData], { type: 'text/text;charset=utf-8' });     
        FileSaver.saveAs(file, 'xpertrak-license-' + this.dateTimeInEDTFormat() + '.txt');
    }

    /*method to obtain date in yyyyMMMdd hhMMss to append to exported Log File*/
    private dateTimeInEDTFormat():string{
        return this.sharedService.getEDTDateTime(new Date);
    }

    /* method to export Log file*/
    private exportLog():void{
        this.waitingForLicenseLog = true;
        this.licenseInfoDataService.getLExportLog().subscribe(this.onExportLogSuccessRes.bind(this), this.onLExportLogError.bind(this));
    }

    /* Function invoked on success of license log api response */
    private onLicenseLogSuccessRes(response):void{
        this.licenseLogToggle = true;
        this.licenseLogResponse = response;
    }

    private onLExportLogError(): void {
        this.waitingForLicenseLog = false;
        this.onApiError.bind(this);
    }

    /* Function invoked on error in api */
    private onApiError(error:any):void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showLoading = false;
        // this.licenseErrorResponse = error;
        this.showAlert.showErrorAlert(error);
    }

    /* Function invoked on license post error api response */
    private onLicensePostError(error){
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showLoading = false;
        this.showPostLoader = [false, false];
        if(error && !error.status){
            error.status = 4; //Large File Upload Error
        }
        this.showAlert.showErrorAlert(error);
        let errorResponse = this.showAlert.getErrorCode(error);
        let errorMessage:string = this.controlMessagesService.getMsg(errorResponse);
        this.licenseErrorResponse = errorMessage;
        this.licenseSuccessResponseToggle = false;
        this.licenseInfoDataService.getLicenseLog().subscribe(this.onLicenseLogSuccessRes.bind(this), this.onLicenseLogError.bind(this));
    }

    private onLicenseLogError(response):void{
    }
}