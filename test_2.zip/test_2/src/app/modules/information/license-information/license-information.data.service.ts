/**
 * Created by nikita.dewangan on 07-08-2017.
 */

import {Injectable} from "@angular/core";

import {InformationHttpService} from "../information.http.service";
import {HttpResponse} from "@angular/common/http";
import {Observable,Subject} from "rxjs";
import {map, catchError, publishReplay, refCount, tap, repeatWhen} from "rxjs/operators";


@Injectable()
export class LicenseInfoDataService {
    private licenseInfo:any;

    constructor(private informationHttpService:InformationHttpService){
    }

    private onLicenseChange = new Subject();

    // get basic Info
    public getLicenseInformation() : Observable<any>{
        return this.informationHttpService.getLicenseInfoData()
            .pipe(repeatWhen(() => this.onLicenseChange),
            map(
            (data: HttpResponse<any>) => {
                this.licenseInfo = data;
                return this.licenseInfo;
            }, error => {
                return error;
            }))
    }

    // get license logs
    public getLicenseLog() : Observable<any>{
        return this.informationHttpService.getLicenseLogData().pipe(map(
            (data: HttpResponse<any>) => {
                let licenseInfoLog = data['_body'];
                return licenseInfoLog;
            }, error => {
                return error;
            }))
    }


    // get Export log
    public getLExportLog() : Observable<any>{
        return this.informationHttpService.getExportLogData().pipe(map(
                (data: HttpResponse<any>) => {
                    return data;
                }, error => {
                    return error;
                })
        )
    }

    // post Download License
    public getDownloadLicenseData(): Observable<any> {
        return this.informationHttpService
            .getDownloadLicenseData()
            .pipe(map((data: HttpResponse<any>) => {
                return  data['_body'];
            }, error => {
                return error;
            }))

    }

    // post Import License
    public importLicenseData(data): Observable<any> {
        return this.informationHttpService
            .postImportLicenseData(data)
            .pipe(map((response) => {
                return  response;
            }, error => {
                return error;
            }),
            tap(()=> this.onLicenseChange.next()))

    }
}