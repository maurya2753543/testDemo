
export class User {
  public accountEnabled: boolean;
  public allPermissionsAndVisibilityEnabled: boolean;


  public email: string;
  public fullName: string;
  public id: number;
  public permissionTypes: any;
  public selected:boolean;
  public sms:string;
  private userName: string;

 
}
