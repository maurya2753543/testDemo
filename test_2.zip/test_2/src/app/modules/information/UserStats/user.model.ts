import { InformationHttpService } from "../information.http.service";
import { EncryptDecryptUtils } from "../../../utilities/encryption-decryption.utils";
import { map } from "rxjs/operators";
// import { LocaleDataService } from "../../../shared/locale.data.service";

export class UserModel {
  public userId: number;
  public userName: string;
  public timestamp: string;
  public feature: string;
  public targetId: number;
  private _informationHttpService: InformationHttpService;

  constructor(
    data: any,
    informationHttpService: InformationHttpService,
    localeDataService: any
  ) {
    let localizationService = localeDataService.getLocalizationService();

    this.timestamp = data.timestamp;
    this.userId = data.userId;

    this.feature = localizationService.instant(data.feature);
    this.targetId = data.targetId;
    this._informationHttpService = informationHttpService;
    if (data.userId < 1) {
      this.userName = ""; //data.details;
    } else {
      //this.userName=(string)this.userId;
      // this need to be corrected
      //let _username= this.getUserName(data.userId);
      //console.log(_username);
      //this.userName=_username;
      //this.userName= ( _username!=null ?_username:" ");
    }
  }

  public getUserName(userId: number) {
    this._informationHttpService
      .getUserDetail(userId)
      .pipe(map((response) => {
        console.log(response);
        response.json();
      }))
      .subscribe((data) => {
        console.log("user", data);
        return this.decrytedValue(data);
      });
  }

  decrytedValue(data) {
    for (let f in data) {
      let decrypt_value = EncryptDecryptUtils.getDecrytedValue(
        data[f].fullName
      );
      return decrypt_value;
    }
  }
}

export class feature
{
  public name:string;
  public value:string
}
