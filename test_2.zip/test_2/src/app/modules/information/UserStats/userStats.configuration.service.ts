import {Injectable} from "@angular/core";

import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import {TimeFilter} from "../../../shared/time.filter";

@Injectable()
export class UserStatsConfigService{

    private _HEADER_FIELDS: any = {
        timestamp : {field: "timestamp", name: ""},
        userName : {field: "userName", name: ""},
        feature : {field: "feature", name: ""},
        targetId : {field: "targetId", name: ""},
    };

    constructor(private localeDataService: LocaleDataService,
                private sharedService : SharedService){}

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();
        this._HEADER_FIELDS.timestamp.name = localizationService.instant('Timestamp');
        this._HEADER_FIELDS.userName.name = localizationService.instant('User');
        this._HEADER_FIELDS.feature.name = localizationService.instant('Feature');
        this._HEADER_FIELDS.targetId.name = localizationService.instant('Element ID');
    }


    /*
    *@name getColumnDef
    *@desc Get column def for alarm-list data-grid
    *@return array[any]
   */
    public getColumnDef(): any[] {
        this.translateLocaleStr();

        let columnDef: any[] = [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                suppressResize: true
            },
            this.getColumns(this._HEADER_FIELDS.timestamp.name,
                this._HEADER_FIELDS.timestamp.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.timestamp.name, 200), "text"),

            this.getColumns(this._HEADER_FIELDS.feature.name,
                this._HEADER_FIELDS.feature.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.feature.name, 150), "text"),


            this.getColumns(this._HEADER_FIELDS.userName.name,
                this._HEADER_FIELDS.userName.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.userName.name, 120), "text"),


            this.getColumns(this._HEADER_FIELDS.targetId.name,
                this._HEADER_FIELDS.targetId.field,
                this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.targetId.name, 120), "text")

        ];

        return columnDef;
    }

    //@method :: get column definition
    private getColumns(headerName: string, field: string, minWidth: number, filter: string): any{
        let def: any = {
            headerName: headerName,
            field: field,
            minWidth: minWidth,
            width: minWidth,
            filter: filter,            
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {suppressAndOrCondition: true}
        }
        // if(!(field === this._HEADER_FIELDS.logLocation.name || field === this._HEADER_FIELDS.details.name)){
        //     def["width"] = minWidth;
        // }
        if(field === this._HEADER_FIELDS.timestamp.field){
            def["cellRenderer"] = (params:any)=>{
                return this.sharedService.getLocaleDate(params.value);
            };
            def["comparator"] = this.sharedService.dateComparator;
            def["filter"] = TimeFilter.ParentFilter;
            def["floatingFilterComponent"] = TimeFilter.ChildFloatingFilter;
        }else{
            def["comparator"] = gridCustomComparator;
        }

        // if(field === this._HEADER_FIELDS.details.field){
        //     def["cellStyle"] = { "white-space": "normal" };
        // }

        return def;
    }
}