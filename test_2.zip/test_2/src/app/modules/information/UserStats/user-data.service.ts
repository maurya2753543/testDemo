import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';
import { HttpResponse } from "@angular/common/http";

import { InformationHttpService } from "../information.http.service";
import {
  DELETE_LOG_FILE_ACTION,
  LIST_ACTION,
} from "../../../constant/app.constants";
import {UserModel} from "./user.model";
import { LocaleDataService } from "../../../shared/locale.data.service";

@Injectable()
export class UserDataService {
  constructor(
    private informationHttpService: InformationHttpService,
    private localeDataService: LocaleDataService
  ) {}

  public getInfo(params: any): Observable<any> {
    //this.informationService.getUsersStatsCollection(params)
    return this.informationHttpService.getUsersStatsCollection(params).pipe(map(
      (data) => {
        return this.processData(data);
      },
      (error) => {
        return error;
      }
    ))
  }

  private processData(data: any[]): UserModel[] {
    let userModel: UserModel[] = [];
    data.forEach((obj: any) => {
      userModel.push(
        new UserModel(obj, this.informationHttpService, this.localeDataService)
      );
    });
    return userModel;
  }
}
