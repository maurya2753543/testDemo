import { TranslateService } from '@ngx-translate/core';

import { DatePipe } from "@angular/common";
import { FormGroup, NgForm, FormControl, FormBuilder } from "@angular/forms";
//import {IMyDpOptions,IMyOptions, IMyDateModel, IMyDate} from 'mydatepicker';
import { EncryptDecryptUtils } from "./../../../utilities/encryption-decryption.utils";
import { HttpParams } from "@angular/common/http";
import { map } from 'rxjs/operators';
import { InformationHttpService } from "./../information.http.service";
import { Component, Output } from "@angular/core";
import { LocaleDataService } from "../../../shared/locale.data.service";
import {LogDataService} from "../log/log-data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {LogConfigurationService} from "../log/log.configuration.service";
import { InformationUrlService } from "../information.url.service";
// import { DatePicker } from "angular2-datetimepicker";
import { Grid } from "../../../shared/ag-grid.options";
import {UserModel, feature } from "./user.model";
import {UserStatsConfigService} from "./userStats.configuration.service";
import { Subject } from "rxjs";
//import { HttpResponse } from "@angular/common/http";
import {UserDataService} from "./user-data.service";
import { commonUtils } from "./../../../utilities/commonUtils";
// import { Locale, TranslatePipe } from "angular2localization";
// import { LocaleModule, LocalizationModule } from "angular2localization";
import {LANGUAGE_LIST_SHORT} from "./../../../constant/app.constants"
import { IMyDpOptions, IMyDate, IMyOptions, IMyDateModel } from "mydatepicker";
// import { isDefaultChangeDetectionStrategy } from "@angular/core/src/change_detection/constants";
import {User} from "./usr.model";
interface DaysValue {
  value: number;
  days: string;
}

@Component({
  selector: "user-stats",
  templateUrl: "UserStats.html",
})
export class UserStatsComponent {
  @Output() user_stats_flag: boolean = true;
  features: feature[] = [];
  arr_Translated = [];
  users: any = [];
  buttonKeys: Object[];
  eventKeys: Object[];
  gridOptions: Grid = new Grid();
  private gridApi: any;
  gridTabType: string = "User_Stats_Export";

  private PURGE_TABLE: string;
  private TABLE_LIST_EXPORT_ALL: string;
  private TABLE_LIST_EXPORT_SELECTED: string;
  private DELETE_ZIP: string;
  private PURGE_TABLE_CONFIRM_MESSAGE: string;
  private DELETE_TABLE_CONFIRM_MESSAGE: string;
  private action: string;
  rowdata: UserModel[];
  private params: HttpParams = new HttpParams();
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private distUserNames_grid: User[] = [];
  private refFlag: boolean = false;
  private updateCount: number = 0;
  private preFormData: Object = {};
  oneDayDuration: string;
  threeDayDuration: string;
  fiveDayDuration: string;
  sevenDayDuration: string;

  DAYS: DaysValue[] = [];
  date: Date = new Date();
  date_defined: boolean = false;
  dateFormat: string;
  selDate: IMyDate = { year: 0, month: 0, day: 0 };

  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: "yyyy-mm-dd",
  };
  locale: string = "en";
  feature_name: string = "0";
  user_id = 0;
  duration = 1440;

  public userStatsForm: FormGroup;

  // userStatsForm = new FormGroup({
  //   date: new FormControl(),
  //   duration: new FormControl(),
  //   feature_name: new FormControl(""),
  //   user_id: new FormControl(""),
  // });

  constructor(
    private localeDataService: LocaleDataService,
    private logDataService: LogDataService,
    private showAlert: ShowAlert,
    private userStatsConfigService: UserStatsConfigService,
    private informationUrlService: InformationUrlService,
    private informationService: InformationHttpService,
    private userDataService: UserDataService,
    private datePipe: DatePipe,
    private formBuilder: FormBuilder,
    private translate:TranslateService
  ) {}
  ngOnInit() {
    let lan = navigator.language.toLocaleLowerCase().split('-')[0];

    if(lan.includes('zh')){
      this.locale = 'zh-cn';
    }
    //if(lan=='zh'||lan=='de'||lan=='es'||lan=='fr'||lan=='ja'||lan=='en'||lan=='pt')
      //this.locale=lan;
    
    //else{
     // this.locale=='en';
    //}
    if(LANGUAGE_LIST_SHORT.includes(lan))
    {
      this.locale=lan;
      console.log(lan);
    }
    else{
      this.locale=='en';
      console.log("else")
    }

    this.getUser();
    this.getFeatureName();
    this.translateLocaleString();
    this.setEventButtonKeys();
    this.setData([]);
    this.initForm();
    this.DAYS = [
      { value: 1440, days: this.oneDayDuration },
      { value: 4320, days: this.threeDayDuration },
      { value: 7200, days: this.fiveDayDuration },
      { value: 10080, days: this.sevenDayDuration },
    ];
    this.myDatePickerOptions = {
      dateFormat: this.dateFormat,
      allowSelectionOnlyInCurrentMonth: false,
      showTodayBtn: false,
      showClearDateBtn: false,
      disableSince: {
        year: this.date.getFullYear(),
        month: this.date.getMonth() + 1,
        day: this.date.getDate() + 1,
      },
      enableDays:[{year: 2022, month: 9, day: 30}, {year: 2022, month: 9, day: 29}]
    };
  }

  initForm() {
    let d: Date = new Date();
    this.userStatsForm = this.formBuilder.group({
      date: [
        {
          date: {
            year: d.getFullYear(),
            month: d.getMonth() + 1,
            day: d.getDate(),
          },
          jsdate: d,
        },
      ],
      duration: 1440,
      feature_name: "0",
      user_id: "0",
    });
  }

  public onUserSelected(event) {
    this.refFlag = false;
  }
  public onFeatureSelected(event) {
    this.refFlag = false;
  }
  public onDurationSelected(event) {
    this.refFlag = false;
  }
  onDateChanged(event: IMyDateModel) {
    this.refFlag = false;
  }

  //Method to set button keys
  private setEventButtonKeys(): void {
    this.buttonKeys = [];
    this.eventKeys = [
      {
        name: this.TABLE_LIST_EXPORT_SELECTED,
        status: "single",
        tabType: "USER_STAT_TAB",
      },
      {
        name: this.TABLE_LIST_EXPORT_ALL,
        status: "all",
        tabType: "USER_STAT_TAB",
      },
    ];
  }
  getUser() {
    this.informationService
      .getUsersCollection()
      .pipe(map((response) => response))
      .subscribe((data) => {
        console.log("username====",data);
        
        this.decrytedValue(data);
      });
  }

  getFeatureName() {
    
    this.informationService
      .getFeaturesNameCollection()
      .pipe(map((response) => response))
      .subscribe((data: string[]) => {
        for (let f in data) {
          this.arr_Translated.push({
            name: this.translate.instant(data[f]),
            value: data[f],  
          });
          console.log("features",this.arr_Translated);
          for(let j in this.arr_Translated ){
            if(this.arr_Translated[j].value === "cleared element alarms"){
              this.arr_Translated[j].name = this.translate.instant("Cleared Hardware Alarms");
            }
            if(this.arr_Translated[j].value === "Cleared multiple alarms"){
              this.arr_Translated[j].name = this.translate.instant("Cleared Multiple Alarms");
            }
            if(this.arr_Translated[j].value === "Cleared network alarms"){
              this.arr_Translated[j].name = this.translate.instant("Cleared Network Alarms");
            }
            if(this.arr_Translated[j].value === "User change password"){
              this.arr_Translated[j].name = this.translate.instant("User Change Password");
            }
            if(this.arr_Translated[j].value === "Starting OLT Port-mapping session"){
              this.arr_Translated[j].name = this.translate.instant("Starting OLT Port-Mapping Session");
            }
          }
      }
        this.features = this.arr_Translated.sort((a, b) =>
          a.name.localeCompare(b.name)
        );
      });
  }

  decrytedValue(data) {
    console.log("inside decrypt", data);
    for (let f in data) {
      let decrypt_value = EncryptDecryptUtils.getDecrytedValue(
        data[f].fullName
      );
      data[f].fullName = decrypt_value;
      this.users.push(data[f]);
      commonUtils.sortingData(this.users);
    }
  }

  onTabSwitch(): void {
    //this.notifyRefreshGrid();
  }
  isToday(date) {
    let dt = new Date();
    let timeFormat = {};
    let activeDate = date.date;
    // timeFormat = {
    //   hh: (dt.getHours() < 10 ? "0" : "") + dt.getHours(),
    //   mm: (dt.getMinutes() < 10 ? "0" : "") + dt.getMinutes(),
    //   ss: (dt.getSeconds() < 10 ? "0" : "") + dt.getSeconds(),
    // };
    if (
      activeDate.year == dt.getUTCFullYear() &&
      activeDate.month == dt.getUTCMonth() + 1 &&
      activeDate.day == dt.getUTCDate()
    ) {
      timeFormat = {
        hh: (dt.getUTCHours() < 10 ? "0" : "") + dt.getUTCHours(),
        mm: (dt.getUTCMinutes() < 10 ? "0" : "") + dt.getUTCMinutes(),
        ss: (dt.getUTCSeconds() < 10 ? "0" : "") + dt.getUTCSeconds(),
      };
    } else {
      timeFormat = {
        hh: "23",
        mm: "59",
        ss: "59",
      };
    }
    return timeFormat;
  }
  customeDateFormat(date) {
    let processedDate = this.isToday(date);
    var jsdateTemp = new Date(date.jsdate);
    var date_timezone = new Date(
      jsdateTemp.getTime() - jsdateTemp.getTimezoneOffset() * 60000
    );
    let substr = new Date(date_timezone).toISOString();
    return (
      substr.substr(0, substr.indexOf("T")) +
      "T" +
      processedDate["hh"] +
      ":" +
      processedDate["mm"] +
      ":" +
      processedDate["ss"] +
      "Z"
    );
  }

  onSubmit(value: any) {
    event.preventDefault();
    let formValue = Object.assign({}, this.userStatsForm.value);
    this.refFlag = true;
    if (this.updateCount === 0) {
      this.preFormData = Object.assign({}, this.userStatsForm.value);
    }
    if (this.refFlag == true) {
      this.preFormData = Object.assign({}, this.userStatsForm.value);
    }
    formValue.date = this.customeDateFormat(formValue.date);
    console.log("Date: " + formValue.date.toString());
    this.getUserStatsFromAPI(formValue);
    this.showGridLoading();
    this.updateCount = 1;
  }
  resetFieldsToDefault() {
    this.initForm();
    this.refFlag = false;
  }
  getUserStatsFromAPI(params: any) {
    this.userDataService
      .getInfo(params)
      .subscribe(this.onData.bind(this), this.onError.bind(this));
  }

  private onData(data): void {
    if (data.length != 0) {
      this.setData(data);
      for (let f in data) {
       // let localizationService = this.localeDataService.getLocalizationService();
        this.translate.instant(data[f].feature);
      }
      //this.hideGridLoading();
    } else {
      this.showNoData();
    }
  }

  notifyRefreshGrid(event): void {
    this.hideGridLoading();
    let formValue;
    if (this.updateCount > 0) {
      if (this.refFlag == true) {
        formValue = Object.assign({}, this.userStatsForm.value);
        formValue.date = this.customeDateFormat(formValue.date);
      } else {
        formValue = Object.assign({}, this.preFormData);
        formValue.date = this.customeDateFormat(formValue.date);
      }
      this.getUserStatsFromAPI(formValue);
    } else {
      this.gridApi.showNoRowsOverlay();
    }
  }

  private showGridLoading(): void {
    this.gridApi.showLoadingOverlay();
  }

  private showGridNoDataAvilable(): void {
    this.gridApi.showNoRowsOverlay();
  }

  private hideGridLoading(): void {
    this.gridApi.hideOverlay();
  }

  private setData(data: UserModel[]): void {
    this.mapUserModel(data);
    this.rowdata = data;
  }

  private mapUserModel(data: UserModel[]) {
    //1. distinct users ids
    let distUsrsIds = this.fetchDistinctUserId(data);

    //2.  populate user Names Array
    this.distUserNames_grid = this.getDistUserNames(distUsrsIds);
    //3. Map User Names in UserModel

    this.distUserNames_grid = this.distUserNames_grid.filter(
      (x) => x != undefined
    );

    data.map((x) => {
      x.userName = x.userId > 0 ? this.getUserName(x.userId) : "";
    });

    this.rowdata = data;
  }

  getUserName(userId: number): string {
    let idx = this.distUserNames_grid.findIndex((x) => x.id == userId);
    let name = "";
    if (idx != -1 && this.distUserNames_grid[idx] != undefined) {
      name = this.distUserNames_grid[idx].fullName;
      if (name != undefined) return name;
    }
    return name;
  }
  private getDistUserNames(distUsrsIds: number[]): User[] {
    // inner join of total users and distUsrsIds and get matched distinct users from total users
    let usr: User[] = this.users;
    let results1: User[] = [];
    let results = distUsrsIds.forEach((item1) => {
      results1.push(usr[usr.findIndex((x) => x.id == item1)]);
    });
    return results1;
  }

  private fetchDistinctUserId(data: UserModel[]): number[] {
   // return [...new Set(data.map((item) => item.userId))];
   return Array.from(new Set(data.map((item) => item.userId)));
  }

  notifyGridReady(event): void {
    this.gridApi = this.gridOptions.api;
    this.setColDef();
    this.gridApi.sizeColumnsToFit();
    // this.gridApi.setDomLayout("normal");
  }

  private setColDef(): void {
    this.showGridNoDataAvilable();
    this.gridApi.setColumnDefs(this.userStatsConfigService.getColumnDef());
    this.gridOptions["getRowHeight"] = 85;
    // this.gridApi.setDomLayout("normal");
    //   this.gridOptions["getRowHeight"] = (params) => {
    //     let messageWidthCalc = Math.floor(params.data.details.length / 45);
    //     return ((window.innerWidth >= 750) ? 11 * (messageWidthCalc + 2) : 22 * (messageWidthCalc + 1)) ;
    // }
    //this.getUserStatsFromAPI(this.params);
    this.showGridNoDataAvilable();
  }

  notifyActionEmitter($event) {
    // switch($event.event.name) {
    //     case this.PURGE_TABLE:
    //         this.purgeTableConfirmation();
    //         break;
    //     case this.EXPORT_TABLE:
    //         this.exportZipFiles();
    //         break;
    //     case this.DELETE_ZIP:
    //         this.deleteLogFiles();
    //         break;
    //     default:
    // }
  }

  private showNoData(): void {
    this.showGridNoDataAvilable();
    this.setData([]);
  }

  //Handle error
  private onError(error: any): void {
    console.log(error);
    this.showAlert.showErrorAlert(error);
  }

  private translateLocaleString(): void {
    //let localizationService = this.localeDataService.getLocalizationService();
    this.TABLE_LIST_EXPORT_ALL = this.translate.instant(
      "TABLE_LIST_EXPORT_ALL"
    );
    this.TABLE_LIST_EXPORT_SELECTED = this.translate.instant(
      "TABLE_LIST_EXPORT_SELECTED"
    );

    this.oneDayDuration = this.translate.instant("ONE_DAY");
    this.threeDayDuration = this.translate.instant("THREE_DAYS");
    this.fiveDayDuration =this.translate.instant("FIVE_DAYS");
    this.sevenDayDuration = this.translate.instant("SEVEN_DAYS");
    this.dateFormat = this.translate.instant("DATE_FORMAT");
  }
}
