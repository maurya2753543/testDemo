/*
 * Copyright (c) 2023 Viavi Solutions Inc. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions is strictly prohibited.
 */

//import { URLSearchParams } from "@angular/http";
/**
 * Created by narayan.reddy on 23-06-2017.
 */

import {Injectable} from "@angular/core";
import {SharedService} from "../../shared/shared.service";
import {DIAGNOSTIC_PATH, LICENSE_PATH, PATHTRAK_PATH, TRIGGER_PATH,} from "../../constant/app.constants";

@Injectable()
export class InformationUrlService {
  constructor(private sharedService: SharedService) {}

  // obtains host ID
  private getHost(): string {
    return this.sharedService.getHost() + PATHTRAK_PATH;
  }
  public getLogLisUrl(): string {
    return this.getHost() + "log";
  }

  public getPurgeLisUrl(): string {
    return this.getHost() + "log/delete";
  }

  public getDeleteZipFoldeUrl(): string {
    return this.getHost() + "log/zip/delete";
  }

  public getGetZipFileUrl(): string {
    return this.getHost() + "log/zip";
  }

  public getGetDetailsZipFileUrl(): string {
    return this.getHost() + "log/zip?allStatsRequest=true";
  }

  // obtain basic information component
  public getInformationUrl(): string {
    return this.getHost() + "server/properties";
  }

  // obtain license info
  public getLicenseInfoUrl(): string {
    return this.getHost() + LICENSE_PATH;
  }

  // obtain license log
  public getLicenseLogUrl(): string {
    return this.getHost() + LICENSE_PATH + "/log";
  }

  // obtain license info
  public getExportLogUrl(): string {
    return this.getHost() + LICENSE_PATH + "/export/log";
  }

  // obtain diagnostic summary
  public getDiagnosticSummaryUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/resourceusage";
  }

  public getDownstreamUsageUrl(): string {
    return (
      this.getHost() + DIAGNOSTIC_PATH + "/downstream/datacollection/summary"
    );
  }

  public getVirtualSpectrumCollectionUrl(): string {
    return (
      this.getHost() + DIAGNOSTIC_PATH + "/virtualspectrumcollection/summary"
    );
  }

  public getRamCpuUsageOneDayUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/resourceusage/summary?days=1";
  }

  public getRamCpuUsageSevenDaysUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/resourceusage/summary?days=";
  }

  public getHCUCollectionUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/hcu/datacollection/summary";
  }

  public getQoeCMTSCollectionUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/qoecmts/datacollection/summary";
  }

  public getQoeCMCollectionUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/qoecm/datacollection/summary";
  }

  public getPNMPreEqUsageUrl(): string {
    return this.getHost() + DIAGNOSTIC_PATH + "/preeq/datacollection/summary";
  }

  public getDownloadLicenseUrl(): string {
    return this.getHost() + LICENSE_PATH + "/export/license";
  }

  public postImportLicenseUrl(): string {
    return this.getHost() + LICENSE_PATH + "/import/license";
  }

  public getTriggerCmtsSyncUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/cmts/sync";
  }

  public getTriggerDSCollectionUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/ds";
  }

  public getTriggerPreEqCollectionUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/preeq";
  }

  public getTriggerQoeCmCollectionUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/qoe/cm";
  }

  public getTriggerQoeCmtsCollectionUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/qoe/cmts";
  }

  public getTriggerNodeRankingCollectionUrl(): string {
    return this.getHost() + TRIGGER_PATH + "/ranking";
  }
  public getFeatureNamesUrl(): string {
    return this.getHost() + "userActionLog/featureNames";
  }
  public getUsersUrl(): string {
    return this.getHost() + "user";
  }


  public getUserFeaturesUrl():string{

    
    return this.getHost() + "userActionLog/featureNames";
  }

  public getUserStatsUrl(params): string {
    if (params.feature_name === "0") {
      return (
        this.getHost() +
        "userActionLog/filter?&datetime=" +
        params.date +
        "&duration=" +
        params.duration +
        "&limit=100000&targetId=0&userId=" +
        params.user_id
      );
    } else {
      return (
        this.getHost() +
        "userActionLog/filter?&datetime=" +
        params.date +
        "&duration=" +
        params.duration +
        "&feature=" +
        params.feature_name +
        "&limit=100000&targetId=0&userId=" +
        params.user_id
      );
    }
  }
  public getDeviceCollectionTypesUrl(): string {
    
    return this.getHost() + "diagnostic/devicecollectionstats/types";
  }

  public getCmtsUrl(): string {
    return this.getHost() + "cmts";
  }

  public getUpdateDataUrl(
    deviceId,
    collectionId,
    duration,
    formatDate
  ): string {
    
    return (
      this.getHost() +
      "diagnostic/devicecollectionstats?deviceId=" +
      deviceId +
      "&duration=" +
      duration +
      "&limit=100000&typeCollectionId=" +
      collectionId +
      "&datetime=" +
      formatDate
    );
  }
  public getHcuUrl(): string {
   
    return this.getHost() + "hcu";
  }
  public getUserDetailUrl(userId: number): string {
    return this.getHost() + "user/" + userId;
  }


  public getUserActivitySummaryUrl(params):string{

    if (params.feature_name === "0") {
      return (
        this.getHost() +
        "useractionsummary/filter?datetime=" +
        params.date +
        "&duration=" +
        params.duration 
      );
    } else {
     
      return (
        this.getHost() +
        "useractionsummary/filter?&datetime=" +
        params.date +
        "&duration=" +
        params.duration +
        "&feature=" +
        params.feature_name 
      );
    }
    
  }

  public getKibanaUrl() : string{
    return this.sharedService.getHost() + '/kibana/app/discover';
  }

  public getOltTabDataURL(){
    return this.sharedService.getHost() + '/pathtrak/api/pon/olt';
}

}
