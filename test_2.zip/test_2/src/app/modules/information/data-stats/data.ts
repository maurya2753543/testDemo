export class Data{
    constructor(
        public duration: string,
        public typeApi: string,
        public deviceAPI: string
    ){}
}