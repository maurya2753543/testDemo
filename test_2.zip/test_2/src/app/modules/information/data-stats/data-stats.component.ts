import { Component, OnInit, HostListener, ViewChild, ElementRef } from "@angular/core";
import { IMyDpOptions, IMyOptions, IMyDateModel, IMyDate } from "mydatepicker";
import { InformationHttpService } from "./../information.http.service";
import { LocaleDataService } from "../../../shared/locale.data.service";
import {map, catchError} from "rxjs/operators";

import * as Highcharts from "highcharts";
import {LANGUAGE_LIST_SHORT} from "./../../../constant/app.constants"
import { AuthService } from "src/app/shared/auth.service";
declare var require: any;
const heatmap = require("highcharts/modules/heatmap.js");
heatmap(Highcharts);
const noData = require("highcharts/modules/no-data-to-display.js");
noData(Highcharts);
require("highcharts/modules/exporting.src")(Highcharts);
require("highcharts/modules/offline-exporting.src")(Highcharts);
require("highcharts/modules/boost.js")(Highcharts);
@Component({
  selector: "data-stats",
  templateUrl: "data-stats.component.html",
})
export class DataStatsComponent {

  chartData: any = [];
  chart: any;
  options: any;
  deviceName: any;
  deviceCollMap: any = new Map();
  typeCollection: any = [];
  deviceId: any = 0;
  collectionId: any = 0;
  durationId: any = 1;
  public effectiveDate: any;
  deviceCollection: any = { cmtscoll: [], hcucoll: [], oltcoll:[] };
  // Priyanka changes : added flagReset
  flagReset: boolean = true;
  flagTypeHcu: boolean;
  flagTypeCmts: boolean;
  flagTypeOLT: boolean;
  flagHcu: boolean;
  flagCmts: boolean;
  flagOLT:boolean;
  duration: string = "1";
  type_name: string;
  device_name: string;
  allDevices: string;
  typeDefault: string;
  oneDayDuration: string;
  threeDayDuration: string;
  fiveDayDuration: string;
  sevenDayDuration: string;
  yAxisTitle: string;
  xAxisTitle: string;
  noDataText: string;
  shortMonths: any = [];
  months: any = [];
  weekdays: any = [];
  tooltipDate: string;
  tooltipDevice: string;
  tooltipTime: string;
  tooltipSuccess: string;
  successTrue: string;
  successFalse: string;
 
  stops: any = [];
  dataClasses: any = [];

  days = [];
  // date:Date;
  datePickerOptions: any;
  datepickerForm: any;
  public locale: string;

  //Calender Configuration
  date: any = new Date();

  private today = new Date();

  settings = {
    bigBanner: true,
    timePicker: true,
    minDate: this.today,
    format: "yyyy-MM-ddThh:mm:sssZ",
    defaultOpen: false,
    closeOnSelect: true,
  };

  // Calendar Date Picker
  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: "yyyy-mm-dd",
  };

  public model: Object = {};
  themeDark: boolean = false;
  collectionName: string;
  qoeCm: string;
  preEqCmts: string;
  cmtsDownstream: string;
  oltSync: string;
  dateFormat: string;
  min: string;
  lblMsg: string;
  customHeight: number;
  isExpanded:boolean = false;
  @ViewChild('chartWrapper') chartWrapper : ElementRef;
  constructor(
    private informationService: InformationHttpService,
    private localeDataService: LocaleDataService
  ) {
    this.options = {
      chart: { type: "heatmap" },
    };
  }

  Highcharts: typeof Highcharts = Highcharts;

  
  //Save chart instance for update and use
  saveChart(chartInstance) {
    if (!this.chart) {
      this.chart = chartInstance;
      this.chart.options.exporting.sourceWidth = this.chart.chartWidth;
      this.chart.options.exporting.sourceHeight = this.chart.chartHeight;
      this.chart.redraw();
    this.chart.reflow();
    }
  }

  //Adjust Heatmap Chart on window resize
  @HostListener("window:resize", ["$event"])
  onResize(event) {
    this.chart.redraw();
      this.chart.reflow();
     // this.chart.maximize();
     this.chart.screen.getPrimaryDisplay();
      this.chart.requestFullscreen();
      this.chart.mozRequestFullScreen ();
      this.chart.webkitExitFullscreen ();
      this.chart.msRequestFullscreen();

    // if (this.chart !== undefined) {
    //   if (event.target.innerWidth >= 400) {
    //     console.log('rezise called---->', event.target.innerWidth)
    //     this.chart.setSize(
    //       event.target.innerWidth - 115,
    //       event.target.innerHeight - 200,
    //       false
    //     );
    //   } else {
    //     this.chart.setSize(
    //       event.target.innerWidth - 50,
    //       event.target.innerHeight - 200,
    //       false
    //     );
    //   }
    // }
  }

  //To update chart values
  async updateChart(data) {
    //console.log("updateChart======",data);
    var dataArray = [];
    try {
      await this.getMeAPromise(dataArray, data);
      this.chart.hideLoading();
      this.chart.series[0].setData(dataArray, true);
      this.chart.redraw();
      this.chart.reflow();
    } catch (err) {
      console.log("Error", err);
    }
    //To update chart values
  }

  async getMeAPromise(dataArray, data) {
    var color: any;
    let map = new Map();
    var labelId: any;
    let mySet = new Set();
    var formattedDate = this.tooltipDate;
    var formattedDevice = this.tooltipDevice;
    var formattedTime = this.tooltipTime;
    var formattedSuccess = this.tooltipSuccess;
    var min = this.min;
    this.chart.tooltip.options.formatter = function () {
      var chart = this.series.chart,
        index = this.y;
      return (
        formattedDate +
        ": " +
        "<b>" +
        "" +
        Highcharts.dateFormat("%A %b %d, %Y %H:%M", this.point.x) +
        "</span><br/>" +
        "<br/>" +
        "</b>" +
        formattedDevice +
        ": " +
        chart.yAxis[0].categories[index] +
        "<br/>" +
        "</b>" +
        formattedTime +
        ": " +
        this.point.z +
        " " +
        min +
        " <br/>" +
        "</b><br/>" +
        formattedSuccess +
        ": " +
        this.point.success +
        "  <br/>" +
        "</b><br/>"
      );
    };

    //Get unique deviceId from list of array data
    var uniquedeviceId = await this.mapIdTodeviceName(data);
    //Get unique categories Set (deviceId if no deviceName)
    mySet = await this.getCategories(uniquedeviceId, mySet);
    let array = Array.from(mySet);
    this.customHeight = array.length;
    await this.colorAxisAdjust();
    if (
      this.collectionName === this.qoeCm ||
      this.collectionName === this.preEqCmts ||
      this.collectionName === this.cmtsDownstream
    ) {
      this.chart.xAxis[0].options.tickInterval = 4 * 3600 * 1000;
      this.chart.series[0].options.colsize = 6 * 24 * 36 * 1000;
    } else {
      this.chart.xAxis[0].options.tickInterval = 3600 * 1000;
      this.chart.series[0].options.colsize = 24 * 36 * 1000;
    }
    //update categories on y axis
    this.chart.yAxis[0].update(
      {
        categories: array,
      },
      false
    );
    this.deviceName = -1;

    //Array mapping
    for (let index = 0; index < data.length; index++) {
      //We are putting 0,1,2,3,4,5.... for corresponding categories on y-axis- mapping these to categories
      var deviceMap = await this.mapCategoryId(
        data[index].elementId,
        uniquedeviceId,
        map
      );

      for (const [key, value] of deviceMap.entries()) {
        if (data[index].elementId === key) {
          labelId = value;
        }
      }


      if (this.collectionName === this.oltSync) {
        color = await this.getColorCode(
          data[index],
          parseFloat((data[index].duration).toString()),
          60,
          360
        );
      }
      else if (this.collectionName === this.qoeCm) {
        color = await this.getColorCode(
          data[index],
          parseFloat((data[index].duration / 60).toString()),
          120,
          240
        );
      } else if (this.collectionName === this.preEqCmts) {
        color = await this.getColorCode(
          data[index],
          parseFloat((data[index].duration / 60).toString()),
          240,
          480
        );
      } else if (this.collectionName === this.cmtsDownstream) {
        color = await this.getColorCode(
          data[index],
          parseFloat((data[index].duration / 60).toString()),
          720,
          1440
        );
      }
      else {
        color = await this.getColorCodeCollectionSecondType(
          data[index],
          parseFloat((data[index].totalTime / 60).toString()),
          5,
          10,
          15,
          30,
          45
        );
      }
      if(this.collectionName === this.oltSync){
        dataArray.push({
          x: new Date(data[index].startTime).getTime(),
          y: labelId,
          z: parseFloat((data[index].duration).toString()).toFixed(2),
          color: color,
          success: data[index].success,
          error: data[index].errorReason,
        });
      }
     else {dataArray.push({
        x: new Date(data[index].startTime).getTime(),
        y: labelId,
        z: parseFloat((data[index].duration / 60).toString()).toFixed(2),
        color: color,
        success: data[index].success,
        error: data[index].errorReason,
      });
    }
    }
    return dataArray;
  }

  colorAxisAdjust() {
    if (this.collectionName === this.qoeCm) {
      this.dataClasses = [
        {
          to: 120,
          color: "#006400",
        },
        {
          from: 120,
          to: 240,
          color: "#3cb371",
        },
        {
          from: 240,
          color: "#FF0000",
        },
      ];
    } else if (this.collectionName === this.preEqCmts) {
      this.dataClasses = [
        {
          to: 240,
          color: "#006400",
        },
        {
          from: 240,
          to: 480,
          color: "#3cb371",
        },
        {
          from: 480,
          color: "#FF0000",
        },
      ];
    } else if (this.collectionName === this.cmtsDownstream) {
      this.dataClasses = [
        {
          to: 720,
          color: "#006400",
        },
        {
          from: 720,
          to: 1440,
          color: "#3cb371",
        },
        {
          from: 1440,
          color: "#FF0000",
        },
      ];
    }
    else if(this.collectionName === this.oltSync){
      this.dataClasses = [
        {
          to: 60,
          color: "#006400",
        },
        {
          from: 60,
          to: 360,
          color: "#3cb371",
        },
        {
          from: 360,
          color: "#FF0000",
        },
      ];
    }
    else {
      this.dataClasses = [
        {
          to: 5,
          color: "#006400",
        },
        {
          from: 5,
          to: 10,
          color: "#3cb371",
        },
        {
          from: 10,
          to: 15,
          color: "#90EE90",
        },
        {
          from: 15,
          to: 30,
          color: "#FFFF00",
        },
        {
          from: 30,
          to: 45,
          color: "#FFA500",
        },
        {
          from: 45,
          color: "#FF0000",
        },
        {
          name: this.lblMsg,
          color: "#0000FF",
        },
      ];
    }
    this.chart.legend.destroy();

    this.chart.colorAxis[0].update({
      dataClasses: this.dataClasses,
      showInLegend: true,
    });
  }

  getColorCode(data, totalTime, timeA, timeB) {
    console.log("+++",data, totalTime, timeA, timeB)
    if (data.success) {
      data.success = this.successTrue;
    } else {
      data.success = this.successFalse;
    }
    if (totalTime < timeA) {
      return "#006400";
    } else if (totalTime < timeB) {
      return "#3cb371";
    } else {
      return "#FF0000";
    }
  }

  getColorCodeCollectionSecondType(data, totalTime, timeA, timeB, timeC, timeD, timeE) {
    if (data.success) {
      data.success = this.successTrue;
      if (parseFloat((data.duration / 60).toString()) < timeA) {
        return "#006400";
      }
      else if (parseFloat((data.duration / 60).toString()) < timeB) {
        return "#3cb371";
      } else if (parseFloat((data.duration / 60).toString()) < timeC) {
        return "#90EE90";
      }
      else if (parseFloat((data.totalTime / 60).toString()) < timeD) {
        return "#FFFF00";
      } else if (parseFloat((data.totalTime / 60).toString()) < timeE) {
        return "#FFA500";
      }
      else if (parseFloat((data.totalTime / 60).toString()) > timeE) {
        return "#FF0000";
      }
    }
    else {
      data.success = this.successFalse;
      if (data.errorReason === null) {
       } else {
        return "#0000FF";
      }
    }
  }

  getCategories(uniquedeviceId, mySet) {
    for (let indexId = 0; indexId < uniquedeviceId.length; indexId++) {
      for (const [key, value] of this.deviceCollMap.entries()) {
        if (this.deviceCollMap.has(uniquedeviceId[indexId])) {
          if (uniquedeviceId[indexId] === key) {
            mySet.add(value);
          }
        } else {
          mySet.add(uniquedeviceId[indexId]);
        }
      }
    }
    return mySet;
  }

  mapCategoryId(data, uniquedeviceId, map) {
    for (let indexId = 0; indexId < uniquedeviceId.length; indexId++) {
      if (data === uniquedeviceId[indexId]) {
        this.deviceName = this.deviceName + 1;
        map.set(data, this.deviceName);
        uniquedeviceId.splice(indexId, 1);
      }
    }
    return map;
  }

  mapIdTodeviceName(data) {
    var lookup = {};
    var items = data;
    var result = [];
    for (var item, i = 0; (item = items[i++]); ) {
      var deviceId = item.elementId;
      if (!(deviceId in lookup)) {
        lookup[deviceId] = 1;
        result.push(deviceId);
      }
    }
    return result;
  }

  ngOnInit() {
    this.translateLocaleString();
    let darkThemeCookie = localStorage.getItem("isDarkTheme");
    if (darkThemeCookie) {
      this.themeDark = true;
    } else {
      this.themeDark = false;
    }
    this.myDatePickerOptions = {
      allowSelectionOnlyInCurrentMonth: false,
      dateFormat: this.dateFormat,
      showTodayBtn: false,
      allowDeselectDate: false,
      showClearDateBtn: false,
      disableSince: {
        year: this.today.getFullYear(),
        month: this.today.getMonth() + 1,
        day: this.today.getDate() + 1,
      },
    };
    //To push data from csv , we may have to change using api and way of pushing data
    this.model = {
      date: {
        year: this.today.getFullYear(),
        month: this.today.getMonth() + 1,
        day: this.today.getDate(),
      },
    };

    //Locale
    let lan = navigator.language.toLocaleLowerCase().split('-')[0];
    if(lan.includes('zh')){
      this.locale = 'zh-cn';
    }
    if(LANGUAGE_LIST_SHORT.includes(lan))
    {
      this.locale=lan;
      console.log(lan);
    }
    else{
      this.locale=='en';
      console.log("else")
    }
    //initialize options for chart

    var min = this.min;

    this.options = {
      exporting: {
        scale: 1,
        buttons: {
          contextButton: {
            menuItems: ["printChart", "downloadJPEG", "downloadPDF"],
          },
        },
        chartOptions: {
          // specific options for the exported image
          plotOptions: {
            series: {
              dataLabels: {
                enabled: false,
              },
            },
          },
        },
        fallbackToExportServer: false,
      },
      chart: {
        type: "heatmap",
        renderTo: "container",
        // width:"1200",
        spacingLeft: 0,
        zoomType: "xy",
        animation: false,
      },
      credits: {
        enabled: false,
      },
      lang: {
        noData: this.noDataText,
      },
      title: {
        text: null,
      },
      xAxis: {
        ordinal:false,
        type: "datetime",
        tickInterval: 3600 * 1000,
        minRange: 24 * 3600 * 1000,
        title: {
          text: this.xAxisTitle,
        },

      },      

      yAxis: {
        title: {
          text: this.yAxisTitle,
        },
        lineWidth: 1,
      },
      colorAxis: {
        visible: true,
        showInLegend: false,
      },
      legend: {
        align: "right",
        layout: "vertical",
        margin: 2,
        verticalAlign: "middle",
        labelFormatter: function () {
          if (this.from === undefined && this.to !== undefined) {
            return "< " + this.to + " " + min;
          }
          if (this.to === undefined && this.from !== undefined) {
            return "> " + this.from + " " + min;
          }
          if (this.from !== undefined && this.to !== undefined) {
            return this.from + " - " + this.to + " " + min;
          } else {
            return this.name;
          }
        },
      },
      boost: {
        useGPUTranslations: true,
      },
      series: [
        {
          cursor: "pointer",
          //boostThreshold: 0,
          borderWidth: 0,
          colorByPoint: true,
          colsize: 24 * 36 * 1000, // one day
          tooltip: {
            headerFormat: "Total Time<br/>",
            pointFormat:
              "{point.x:%e %b, %Y} {point.y} Device <b>{point.z} min</b>",
          },
          turboThreshold: Number.MAX_VALUE,
          data: [],
        },
      ],
    };
   // console.log("this.options",this.options);

    this.datePickerOptions = {
      dateFormat: "dd-mm-yyyy",
    };

    this.informationService
      .getDeviceTypeCollection()
      .pipe(map((response) => response))
      .subscribe((data) => {
        let localizationService = this.localeDataService.getLocalizationService();
        var localisedData = [];
        for (let f in data) {
          var keys = Object.keys(data);
          for (var j = 0; j < keys.length; j++) {
            var key = localizationService.instant(keys[j]);
            this.setCollectionTypeNameToCompare(keys[j], key);
            localisedData[key] = data[keys[j]];
          }
          this.typeCollection = Object.entries(localisedData).map(
            ([key, value]) => ({
              key,
              value,
            })
          );
          this.typeCollection.sort(function (x, y) {
            let a = x.value,
              b = y.value;
            return a == b ? 0 : a < b ? -1 : 1;
          });
        }
      });

    this.informationService
      .getCmtsCollection()
      .pipe(map((response) => response))
      .subscribe((data) => {
        if (data == null || data == "") {
          this.flagCmts = true;
        } else {
          let tempArr = [];
          data.forEach((v, k) => {
            tempArr = JSON.parse(JSON.stringify(data));
            this.deviceCollMap.set(v.cmtsId, v.name);
          });
          tempArr = tempArr.sort(function (a, b) {
            return a - b;
          });
          this.deviceCollection["cmtscoll"] = tempArr;
          this.deviceCollection["cmtscoll"].sort(function (x, y) {
            let a = x.name.toUpperCase(),
              b = y.name.toUpperCase();
            return a == b ? 0 : a > b ? 1 : -1;
          });
          console.log("this.deviceCollMap",this.deviceCollMap)
          this.flagCmts = false;
        }
      });

    this.informationService
      .getHcuCollection()
      .pipe(map((response) => response))
      .subscribe((data) => {
        if (data == null || data == "") {
          this.flagHcu = true;
        } else {
          let tempArr = [];
          data.hcuList.forEach((v, k) => {
            tempArr = JSON.parse(JSON.stringify(data.hcuList));
            this.deviceCollMap.set(v.elementId, v.label);
          });
          this.deviceCollection["hcucoll"] = tempArr;
          this.deviceCollection["hcucoll"].sort(function (x, y) {
            let a = x.label.toUpperCase(),
              b = y.label.toUpperCase();
            return a == b ? 0 : a > b ? 1 : -1;
          });
          this.flagHcu = false;
        }
      });

      this.informationService.getOLTDetails()
      .subscribe((data) => {
        if (data == null || data == "") {
          this.flagOLT = true;
        } else {
          let tempArr = [];
          data.forEach((v, k) => {
            tempArr = JSON.parse(JSON.stringify(data));
            this.deviceCollMap.set(v.elementId, v.name);
          });
          tempArr = tempArr.sort(function (a, b) {
            return a - b;
          });
          this.deviceCollection["oltcoll"] = tempArr;
          this.deviceCollection["oltcoll"].sort(function (x, y) {
            let a = x.name.toUpperCase(),
              b = y.name.toUpperCase();
            return a == b ? 0 : a > b ? 1 : -1;
          });
          this.flagOLT = false;
        }
      });

    //Set initial Types
    this.device_name = this.allDevices;
    this.type_name = this.typeDefault;
    this.days = [
      { num: "1", val: this.oneDayDuration },
      { num: "3", val: this.threeDayDuration },
      { num: "5", val: this.fiveDayDuration },
      { num: "7", val: this.sevenDayDuration },
    ];
  }
  ngAfterViewInit(){
    this.chart.redraw();
    this.chart.reflow();
    // this.chartWrapper.nativeElement.parentElement.style.height = document.getElementById('container').offsetHeight + 'px';
  }
  toggleChartHeight(){
    if(!this.isExpanded){
      if(this.customHeight > 30){
        this.chartWrapper.nativeElement.style.height = (this.customHeight * 20)+ 'px';
        this.isExpanded = true;
      }
    }else{
      this.chartWrapper.nativeElement.style.height = document.getElementById('container').parentElement.offsetHeight + 'px';
      this.isExpanded = false;
    }
    this.chart.redraw();
    this.chart.reflow();

  }
  setCollectionTypeNameToCompare(keyName, localizedName) {
    if (keyName === "QOE_CM_COLLECTION") {
      this.qoeCm = localizedName;
    } else if (keyName === "PRE_EQ_CMTS_COLLECTION") {
      this.preEqCmts = localizedName;
    } else if (keyName === "CMTS_DOWNSTREAM_COLLECTION") {
      this.cmtsDownstream = localizedName;
    }else if (keyName.trim() === 'OLT_SYNC'){
      this.oltSync = localizedName
    }
  }

  onTypeSelect(event) {
    this.collectionId = event.target.value;
  }

  onDeviceSelect(event) {
    if (event.target.selectedOptions[0].parentElement.label === "HCU") {
      this.flagTypeHcu = false;
      this.flagTypeCmts = true;
      this.flagTypeOLT = true
    }

    if (event.target.selectedOptions[0].parentElement.label === "CMTS") {
      this.flagTypeHcu = true;
      this.flagTypeCmts = false;
      this.flagTypeOLT = true
    }
    if (event.target.selectedOptions[0].parentElement.label === "OLT") {
      this.flagTypeHcu = true;
      this.flagTypeCmts = true;
      this.flagTypeOLT = false
    }

    if (event.target.value === this.allDevices) {
      this.deviceId = "0";
    } else {
      this.deviceId = event.target.value;
    }
  }

  private translateLocaleString(): void {
    let localizationService = this.localeDataService.getLocalizationService();
    this.allDevices = localizationService.instant("DEVICE_NAME_DEFAULT");
    this.typeDefault = localizationService.instant("TYPE_NAME_DEFAULT");
    this.oneDayDuration = localizationService.instant("ONE_DAY");
    this.threeDayDuration = localizationService.instant("THREE_DAYS");
    this.fiveDayDuration = localizationService.instant("FIVE_DAYS");
    this.sevenDayDuration = localizationService.instant("SEVEN_DAYS");
    this.yAxisTitle = localizationService.instant("DATA_CHART_YAXIS");
    this.xAxisTitle = localizationService.instant("DATA_CHART_XAXIS");
    this.noDataText = localizationService.instant("DATA_CHART_NODATA");
    this.shortMonths = localizationService
      .instant("SHORTMONTH")
      .replace(/\s/g, "")
      .split(",");
    this.months = localizationService
      .instant("MONTH")
      .replace(/\s/g, "")
      .split(",");
    this.weekdays = localizationService
      .instant("DAY")
      .replace(/\s/g, "")
      .split(",");
    this.tooltipDate = localizationService.instant("DATA_CHART_DATE");
    this.tooltipDevice = localizationService.instant("DATA_CHART_DEVICE");
    this.tooltipTime = localizationService.instant("DATA_CHART_TIME");
    this.tooltipSuccess = localizationService.instant("DATA_CHART_SUCCESS");
    this.successTrue = localizationService.instant("DATA_CHART_YES");
    this.successFalse = localizationService.instant("DATA_CHART_NO");
    this.dateFormat = localizationService.instant("DATE_FORMAT");
    this.min = localizationService.instant("MINUTE");
    this.lblMsg = localizationService.instant("EXTRA_LABEL");

    // TImezoning setting for Global timezone on X-axis
    const timezone = new Date().getTimezoneOffset();
    
    Highcharts.setOptions({
      lang: {
        loading: localizationService.instant("DATA_CHART_LOADING"),
        months: this.months,
        weekdays: this.weekdays,
        shortMonths: this.shortMonths,
        resetZoom: localizationService.instant("RESET_ZOOM"),
        printChart: localizationService.instant("CHART_PRINT_CHART"),
        downloadJPEG: localizationService.instant("CHART_DOWNLOAD_JPEG"),
        downloadPDF: localizationService.instant("CHART_DOWNLOAD_PDF"),
      },
      //enabling option for X-axis time plotting
      time: {
        timezoneOffset: timezone
    }   
    });
  }

  /* Method get called when we come in data after switch the tab */
  public onTabSwitch(): void {
    //To implement if any changes on tabSwitch required
  }

  onDurationSelect(event) {
    this.durationId = event.target.value;
  }

  private getKeyByValue(arr, value) {
    var indexKey;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].value === value) {
        indexKey = arr[i].key;
        return indexKey;
      }
    }
  }

  onOptionsSelected(event) {
    console.log("event..",event)
    this.collectionId = event;
    this.collectionName = this.getKeyByValue(
      this.typeCollection,
      parseInt(this.collectionId)
    );

    if (
      event == "1" ||
      event == "2" ||
      event == "3" ||
      event == "4" ||
      event == "5" ||
      event == "6"
    ) {
      this.flagReset = false;

      if (this.device_name != null || this.device_name != this.allDevices) {
        if (this.flagTypeCmts == false && this.flagTypeHcu == true && this.flagTypeOLT == true) {
          this.device_name = this.device_name;
        } else {
          this.device_name = this.allDevices;
          this.deviceId = "0";
        }
      } else {
        this.device_name = this.allDevices;
        this.deviceId = "0";
      }
      this.flagTypeHcu = true;
      this.flagTypeCmts = false;
      this.flagTypeOLT=true
    } else if (event == "7" || event == "8") {
      this.flagReset = false;

      if (this.device_name != null || this.device_name != this.allDevices) {
        if (this.flagTypeHcu == false && this.flagTypeCmts == true && this.flagTypeOLT == true) {
          this.device_name = this.device_name;
        } else {
          this.device_name = this.allDevices;
          this.deviceId = "0";
          
        }
      } else {
        this.device_name = this.allDevices;
        this.deviceId = "0";
      }
      this.flagTypeHcu = false;
      this.flagTypeCmts = true;
      this.flagTypeOLT = true
    }else if(event == "9"){
      this.flagReset = false;

      if (this.device_name != null || this.device_name != this.allDevices) {
        if (this.flagTypeHcu == true && this.flagTypeCmts == true && this.flagTypeOLT == false) {
          this.device_name = this.device_name;
        } else {
          this.device_name = this.allDevices;
          this.deviceId = "0";

        }
      } else {
        this.device_name = this.allDevices;
        this.deviceId = "0";
      }
      this.flagTypeHcu = true;
      this.flagTypeCmts = true;
      this.flagTypeOLT = false
    } else {
      this.flagTypeHcu = false;
      this.flagTypeCmts = false;
      this.flagTypeOLT = false;
      this.flagReset = true;
    }
  }

  onSubmit(dataform: any) {}

  checkTimeFormat(fdate) {
    let dt = new Date();
    let activeDate = new Date(fdate);
    var localISOTime = (new Date(Date.now())).toISOString().slice(0, -1);
    if (
      activeDate.getUTCFullYear() == dt.getUTCFullYear() &&
      activeDate.getUTCMonth() == dt.getUTCMonth() &&
      activeDate.getUTCDate() == dt.getUTCDate()
    ) {
      return localISOTime+'Z';
    } else {
      let y = new Date(this.date).getUTCFullYear();
      let m: any = new Date(this.date).getUTCMonth() + 1;
      let d: any = new Date(this.date).getUTCDate();
      if (d < 10) d = "0" + d;
      else d = d;

      if (m < 10) m = "0" + m;
      else m = m;

      let fullDate = y + "-" + m + "-" + d;
      let substr = new Date(this.date).toISOString();
      let sub1 = substr.split("T")[1];
      return fullDate + sub1.replace(sub1, "T23:59:59Z");
    }
  }

  updateData(dataform: any) {
  //  this.chart.showLoading();
    var formatDate = this.checkTimeFormat(this.date);
    this.informationService
      .updateData(this.deviceId, this.collectionId, this.durationId, formatDate)
      .pipe(map((response) => response))
      .subscribe((data) => {
        if (data == null || data == "") {
          this.updateChart(data);
        } else {
          this.updateChart(data);
        }
      });
  }

  resetToDefaultValue() {
    this.flagTypeHcu = false;
    this.flagTypeCmts = false;
    this.flagTypeOLT = false
    this.flagReset = true;
    this.duration = this.days[0].num;
    this.type_name = this.typeDefault;
    this.device_name = this.allDevices;
    this.date = new Date();
    this.model = {
      jsdate: new Date(),
      date: {
        year: this.date.getFullYear(),
        month: this.date.getMonth() + 1,
        day: this.date.getDate(),
      },
    };
  }

  onDateChanged(event) {
    this.date = event.jsdate;
  }

  onChange(event) {}
}
