
export const ALARM_GOOD_PERCENTAGE_COLOR: string = '#88dd73';//#88dd73
export const ALARM_MINOR_PERCENTAGE_COLOR: string ='#fdff6b'; //#fdff6b
export const ALARM_MAJOR_PERCENTAGE_COLOR: string = '#ffba00'; //#ffcc00
export const ALARM_CRITICAL_PERCENTAGE_COLOR: string = '#fe504f';
export const ALARM_WARNING_PERCENTAGE_COLOR: string ='#00c1c1';//#01ffff

