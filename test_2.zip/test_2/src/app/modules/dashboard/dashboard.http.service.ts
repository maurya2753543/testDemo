/**
 * Created by narayan.reddy on 23-06-2017.
 */


/* HTTP Service Class for api calls & data handling*/

import { Injectable } from '@angular/core';
import {DashboardUrlService} from "./dashboard.url.service";
import {HttpService} from "../../shared/http.service";
import {Observable} from "rxjs";
import { AuthService } from 'src/app/shared/auth.service';
import { switchMap, take } from 'rxjs/operators';

@Injectable()
export class DashboardHttpService {

    constructor(private urlService:DashboardUrlService, private httpService: HttpService,
        private authService : AuthService) {
    }

    // Alarm getDashboardAlertData data
    public getDashboardAlertData() : Observable<any>{
        let url = this.urlService.getDashboardAlertUrl();
        return this.httpService.GET(url);
    }

    // Alarm getDashboardAlertData data
    public getCMTSData() : Observable<any>{
        let url = this.urlService.getCMTSDataUrl();
        return this.httpService.GET(url);
    }

    // Alarm getDashboardAlertData data
    public getHCUData() : Observable<any>{
        let url = this.urlService.getHCUDataUrl();
        return this.httpService.GET(url);
    }

    // Alarm Summary
    public getAlarmSummaryData() : Observable<any>{
        let url = this.urlService.getAlarmSummaryUrlDevice();
        return this.httpService.GET(url);
    }

    // RCI Summary
    public getRCIData() : Observable<any> {
        let url = this.urlService.getRCIDataUrl();
        return this.httpService.GET(url);
    }

    // OTU Summary
    public getOtuData() : Observable<any> {
        let url = this.urlService.getOtuDataUrl();
        return this.httpService.GET(url);
    }

    public getOltData(): Observable<any> {
        return this.authService.getJwtHeaders().pipe(
            switchMap(headers => this.httpService.GETWITHHEADERS(this.urlService.getOltDataUrl(), headers, true)),
            take(1)
        );
    }

    public getOntData(): Observable<any> {
        return this.authService.getJwtHeaders().pipe(
            switchMap(headers => this.httpService.GETWITHHEADERS(this.urlService.getOntDataUrl(), headers, true)),
            take(1)
        );
    }

    

}
