import { TranslateService } from '@ngx-translate/core';
/**
 * Created by narayan.reddy on 18-08-2017.
 */

import {Injectable} from "@angular/core";
import {Observable,of} from "rxjs";
import {HttpResponse} from "@angular/common/http";
import {DashboardHttpService} from "./dashboard.http.service";
import {DashboardAlertModel, RCISummaryData, CMTSSummaryData, HCUSummaryData, OtuSummaryData, OltSummaryData} from "./models/dashboard.model";
import {PieChartModel} from "./models/pie-chart.model";
import { LocaleDataService } from "./../../shared/locale.data.service";
//import { LocalizationService } from "angular2localization";
import { map, combineLatest } from "rxjs/operators";

@Injectable()
export class DashboardDataService {
    private localizationService: Observable<any>;
    constructor(private httpService : DashboardHttpService,
                private localeDataService:LocaleDataService){

        this.localizationService = this.localeDataService.currentLanguage
            .pipe(map(l => this.localeDataService.getLocalizationService()));
    }

    /*
     *@name getDashboardAlertData
     *@desc get alert data of dashboard.
     *@return Observable
     */
    public getDashboardAlertData(): Observable<DashboardAlertModel> {
        return this.httpService
            .getDashboardAlertData()
            .pipe(
            map((res) => {
                let data = res;
                let alerts
                if(data != undefined && data.length > 0){
                    alerts = new DashboardAlertModel(data, this.localeDataService);
                }
                console.log('alerts..',alerts)
                return alerts;
            }));
    }

    /**
     * Gets HCU, HSM, RPM and other HCU-related data for the dashboard.
     * @return Observable<HCUSummaryData>
     */
     public getHCUSummaryData(): Observable<HCUSummaryData> {
        return this.httpService
            .getHCUData()
            .pipe(
            map((res) => new HCUSummaryData(res, this.localeDataService.getLocalizationService() )));
    }

    /**
     * Gets CMTS and modem summary details for dashboard.
     * @return Observable<CMTSSummaryData>
     */
    public getCMTSSummaryData(): Observable<CMTSSummaryData> {
        return this.httpService
            .getCMTSData()
            .pipe(
            map((res:[HttpResponse<any>, any]) => new CMTSSummaryData(res, this.localeDataService.getLocalizationService())));
    }

    /**
     * Gets summary data for the current status of RCI devices.
     *
     * @name getRCISummaryData
     */
    public getRCISummaryData(): Observable<RCISummaryData> {
        return this.httpService
            .getRCIData()
            .pipe(
            map((res:[HttpResponse<any>, any]) => new RCISummaryData(res,this.localeDataService.getLocalizationService() )));
    }

    /**
     * Gets summary and status data for all OTU devices.
     */
    public getOtuSummaryData(): Observable<OtuSummaryData> {
        return this.httpService
            .getOtuData()
            .pipe(
            map((args:[HttpResponse<any>, TranslateService]) => new OtuSummaryData(args,this.localeDataService.getLocalizationService() )));
    }

    /**
     * Gets summary and status data for all OLT devices.
     */
    public getOltSummaryData(): Observable<OltSummaryData> {
        return this.httpService
            .getOltData()
            .pipe(
            map((args:[HttpResponse<any>, TranslateService]) => new OltSummaryData(args,this.localeDataService.getLocalizationService() )));
    }

    /**
     * Gets summary and status data for all ONT devices.
     */
    public getOntSummaryData(): Observable<OltSummaryData> {
        return this.httpService
            .getOntData()
            .pipe(
            map((args:[HttpResponse<any>, TranslateService]) => new OltSummaryData(args,this.localeDataService.getLocalizationService() )));
    }

    /*
     *@name getAlarmSummaryData
     *@desc get Alarm Summary data of dashboard.
     *@return Observable
     */
    public getAlarmSummaryData(): Observable<PieChartModel> {
        return this.httpService
            .getAlarmSummaryData()
            .pipe(
            map((res:[HttpResponse<PieChartModel>, any]) => new PieChartModel(res ,this.localeDataService.getLocalizationService())));
    }
}
