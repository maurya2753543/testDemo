/**
 * Created by nikita.dewangan on 26-05-2017.
 */

import { Component } from '@angular/core';
import { Logger } from "../../utilities/logger";
//import { Subject } from 'rxjs/Subject';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { ShowAlert } from "../../utilities/showAlert";
import { DashboardDataService } from './dashboard.data.service';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import { DASHBOARD_MODULE, ALERT_INFO } from "../../constant/app.constants";
import { LocaleDataService } from "../../shared/locale.data.service";
import { PieChartModel } from "./models/pie-chart.model";
import { Router } from '@angular/router';
import { SharedService } from "../../shared/shared.service";
import { SweetAlert } from "../../utilities/sweetAlert";
import {
    CommonStrings
} from "../../constant/common.strings";
import { RCISummaryData, CMTSSummaryData, HCUSummaryData } from './models/dashboard.model';
import { map, merge, filter, catchError, publishReplay, refCount, take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { NavService } from '../../shared/nav.service';
//import {  } from 'rxjs/BehaviorSubject';

@Component({
    selector: 'dashboard-Component',
    templateUrl: 'dashboard.component.html',
})
export class DashboardComponent {

    tag: string = "DashboardComponent ::";
    alertList: Observable<any[]>;
    detaillist: any = ["hcu", "cmts", "rci", "otu","olt", "hcuDetails", "cmtsDetails",  "modemDetails" ,"oltDetails"];
    selectedAlert = new BehaviorSubject<any>(null);

    public deviceDataList: Observable<any>;
    currentAlert: Observable<any>;
    public hasAlerts: Observable<boolean>;
    redirectUrl: Observable<string>;
    public alarmSummaryData: Observable<PieChartModel>;
    public closedContainerIds: Array<number> = [];

    private AUTHORIZATION_ERROR: Observable<string>;

    constructor(private dashboardDataService: DashboardDataService
       , public navService: NavService

        , private sweetAlert: SweetAlert
        , private router: Router, private sharedService: SharedService

        , private logger: Logger
        , public localeDataService: LocaleDataService
        , private showAlert: ShowAlert,
        public translate: TranslateService
    ) {
        let module = DASHBOARD_MODULE;
        this.localeDataService.initLanguage(module);
        //console.log(this.translate.instant('LOGOUT_TEXT'),'translate');

        /* To set the current browser's language */

    }

    ngOnInit() {
        this.initDashboardData();
    }

    private initDashboardData() {
        this.alertList = this.getAlertList();
        this.deviceDataList = this.getDeviceDataList();
        this.alarmSummaryData = this.dashboardDataService.getAlarmSummaryData();
        this.closedContainerIds = this.sharedService.getClosedContainerArr();

        this.currentAlert = this.alertList.pipe(map(list => list[0]),merge(this.selectedAlert.pipe(filter(a => a != null))));

        this.hasAlerts = this.alertList.pipe(map(a => a?.length > 0));

        this.redirectUrl = this.selectedAlert
            .pipe(filter(alert => alert != null),
                map(notification => {
                    if (notification.permissionKey && this.sharedService.checkPermissions(notification.permissionKey)) {
                        return notification.url;
                    }

                    return '';
                }));

        this.AUTHORIZATION_ERROR = this.localeDataService.currentLanguage
            .pipe(map(l => this.localeDataService.getLocalizationService().instant('AUTHORIZATION_ERROR')));

        this.watchSelectedAlert();

    }
    private getAlertList(): Observable<any[]> {
        // multiple things subscribe to alertList (currentAlert, hasAlerts, etc) so we share to prevent multiple requests.
        return this.dashboardDataService
            .getDashboardAlertData()
            .pipe(catchError(err => {
                this.onError(err);
                return [];
            }),
                // caches the value and re-provides (replays) it for subscribers that are created after the first subscriber gets a value
                // Because subscribers are created when we use an async pipe in the html, and some of the async pipes (such as currentAlert) are not rendered
                // until "hasAlerts" is true, we do this so that when those elements are rendered, we both get a value and do not send an additional request.
                publishReplay(1),
                refCount(),
                take(1));
    }

    private getDeviceDataList(): Observable<any[]> {
        return combineLatest([ // request all device summary data         
            this.dashboardDataService.getHCUSummaryData(),           
            this.dashboardDataService.getCMTSSummaryData(),
            this.dashboardDataService.getRCISummaryData(),
            this.dashboardDataService.getOltSummaryData(),
          //  this.dashboardDataService.getOntSummaryData(),
            this.dashboardDataService.getOtuSummaryData(),
            this.localeDataService.getLocalizationService().get('ALARM_LIST_SEVERITY_GOOD')  
        ])
            .pipe(map((results: any[]) => { // structure data into something more easily used by the templates               
                console.log('results...',results)
                return this.detaillist.map(category => {
                    let summary = results.find(summary => summary[category]);
                    if (summary == null) return null;                    
                    return {
                        name: category,
                        data: summary[category]
                    };
                });
            }),
                catchError(err => {
                    this.onError(err)
                    return [];
                }));
    }

    private getAlarmSummaryData(): Observable<PieChartModel> {
        return this.dashboardDataService
            .getAlarmSummaryData()
    }

    private watchSelectedAlert(): void {

        combineLatest(this.selectedAlert.pipe(filter(notification => notification != null)), this.AUTHORIZATION_ERROR)
            .subscribe((action: [any, string]) => {
                let notification = action[0];
                let authError = action[1];
                if (notification.tab) {
                    this.sharedService.setRedirectTAB(notification.tab);
                }
                if (notification.filter) {
                    this.sharedService.setFilterForTabAlert(notification.filter);
                }
                if (notification.url) {
                    if (notification.permissionKey && this.sharedService.checkPermissions(notification.permissionKey)) {
                        this.router.navigate([notification.url]);
                    } else {
                        this.sweetAlert.showConformationAlert(ALERT_INFO, "", authError, true, true, CommonStrings.OK, CommonStrings.CANCEL,
                            (isConfirm) => {
                                if (isConfirm) {

                                }
                            }
                        );
                    }
                }
            });
    }

    private changeSelectAlert(notification) { this.selectedAlert.next(notification); }

    private onError(error): void {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }
}
