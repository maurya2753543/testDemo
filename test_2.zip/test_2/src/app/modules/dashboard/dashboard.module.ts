import {NgModule} from '@angular/core';
import {DashboardComponent} from "./dashboard.component";
import {DashboardRoutes} from "./dashboard.routes";
import { CommonModule } from '@angular/common';
//import { LocaleModule, LocalizationModule } from 'angular2localization';
import {TranslateModule, TranslateService, TranslateLoader} from '@ngx-translate/core';
import {LocaleDataService} from "../../shared/locale.data.service";
import { SharedModule } from "../shared/shared.module";
import {DashboardUrlService} from "./dashboard.url.service";
import {DashboardHttpService} from './dashboard.http.service';
import {DashboardDataService} from './dashboard.data.service';


import { LanguageService } from 'src/app/shared/locale.language.service';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as AppConstants from './../../constant/app.constants';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/dashboard-locale-`, ".json");
  }
  

@NgModule({
    imports: [
        DashboardRoutes,
        CommonModule,
        SharedModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),      
    ],
    declarations: [
        DashboardComponent
    ],
    entryComponents: [
        DashboardComponent
    ],
    // exports: [HCUComponent],
    providers: [

      DashboardHttpService,
      DashboardUrlService,
      DashboardDataService,
      TranslateService,
      LanguageService,
      LocaleDataService,


    ]
})

export class DashboardModule {
}
