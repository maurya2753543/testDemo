import {ALARM_GOOD_PERCENTAGE_COLOR, ALARM_MINOR_PERCENTAGE_COLOR, ALARM_MAJOR_PERCENTAGE_COLOR,
    ALARM_CRITICAL_PERCENTAGE_COLOR, ALARM_WARNING_PERCENTAGE_COLOR} from '../dashboard.constants'

/* Model to handle pie-chart data */
export class PieChartModel extends Array{
    constructor(pieChartData, localizationService:any){
        super();

        if(Object.keys(pieChartData).length > 0){
            Object.keys(pieChartData).forEach((currentKey, index) => {
                let singlePieObj: PieData = new PieData(currentKey, pieChartData[currentKey], localizationService);
                this.push(singlePieObj);
            });
        }
    }
}

/* Model for single pie data */
export class PieData {
    public name: string;
    public y: number;
    public color: string;

    constructor(dataKey: string, dataVal: number, localizationService: any) {
        this.constructPieData(dataKey,dataVal,localizationService)
    }

    public async constructPieData(dataKey: string, dataVal: number, localizationService: any){
        await localizationService.get([
            'ALARM_LIST_SEVERITY_GOOD',
            'ALARM_LIST_SEVERITY_CRITICAL',
            'ALARM_LIST_SEVERITY_MAJOR',
            'ALARM_LIST_SEVERITY_MINOR',
            'ALARM_LIST_SEVERITY_WARNING'
        ]).subscribe(val=>{
            if (dataKey) {
                this.y = dataVal;
                switch(dataKey){
                    case "goodCount":
                        this.color = ALARM_GOOD_PERCENTAGE_COLOR;
                        this.name = val['ALARM_LIST_SEVERITY_GOOD'];
                        break;
                    case "criticalCount":
                        this.color = ALARM_CRITICAL_PERCENTAGE_COLOR;
                        this.name = val['ALARM_LIST_SEVERITY_CRITICAL'];
                        break;
                    case "majorCount":
                        this.color = ALARM_MAJOR_PERCENTAGE_COLOR;
                        this.name = val['ALARM_LIST_SEVERITY_MAJOR'];
                        break;
                    case "minorCount":
                        this.color = ALARM_MINOR_PERCENTAGE_COLOR;
                        this.name = val['ALARM_LIST_SEVERITY_MINOR'];
                        break;
                    case "warningCount":
                        this.color = ALARM_WARNING_PERCENTAGE_COLOR;
                        this.name = val['ALARM_LIST_SEVERITY_WARNING'];
                        break;
                }
                return {'color': this.color,'name' : this.name ,y:this.y}
            }
        })
    }
}
