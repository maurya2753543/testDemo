import { TranslateService } from '@ngx-translate/core';
/**
 * Created by narayan.reddy on 18-08-2017.
 */
import * as appConst from '../../../constant/app.constants';
import {
    DASHBOARD_KEY_NODE_MODEMS,
    DASHBOARD_KEY_NODE_MODEMS_WITH_DOCSIS
} from "../../../constant/app.constants";
//import { LocalizationService } from 'angular2localization';

/**
 * Contains model data for a single row of a BoxComponent.
 */
export interface DashboardBoxEntry {
    key: string;
    txt: string;
    value: number;
    class: string;
    url: string;
    tab: string;
}

class LinkEntry implements DashboardBoxEntry {
    public txt: string;
    public tab: string;
    public class = '';
    public filter = '';
    public permissionError: string;

    constructor(public url: string, public key: string, public value: number, localizationService: TranslateService, public permissionKey = '') {
        localizationService.get([key,this.permissionKey]).subscribe(val=>{
            this.txt = val[key];
            this.tab = url;
            if(this.permissionKey!="")
            this.permissionError = val[this.permissionKey];  
        })
    }
}

class NonLinkEntry implements DashboardBoxEntry {
    public url: string = null;
    public tab: string = null;
    public class = appConst.DASHBOARD_KEY_MODEMTXT;

    constructor(public key: string, public txt: string, public value: number) {}
}

/*Class to handle error model for modules*/
export class DashboardAlertModel extends Array {
    constructor(list, localizationService:any){
        super();

        if(list){
            for(let i=0; i<list.length; i++) {
                let DashboardAlertData: DashboardAlertListItems = new DashboardAlertListItems(list[i], localizationService);
                DashboardAlertData.txt ? this.push(DashboardAlertData):'';
            }
        }
    }
}

export class DashboardAlertListItems {
    public txt:string;
    public url:string;
    public tab:string;
    public filter:string;
    public permissionKey:string;
    private ignoreType = [appConst.DASHBOARD_KEY_FUA , ];
    constructor(data, localizationService) {
        if (data) {
            let notificationType = data.notificationType;
            let count = data.count;
            let days = data.days;
            if(this.ignoreType.indexOf(notificationType) > -1){
                if(count > 0){
                    this.txt = this.determineTranslation(localizationService, notificationType, null, null);
                    this.url = appConst.DASHBOARD_KEY_HCU;
                    this.tab = appConst.DASHBOARD_KEY_HCU;
                    this.filter = localizationService.localization.instant("YES");
                    this.permissionKey = "ADMINISTER_PATHTRAK_CMTS";
                }

            } else {
                this.txt = this.determineTranslation(localizationService, notificationType, count, days) ;
                this.url = appConst.DASHBOARD_KEY_INFO;
                this.tab = appConst.DASHBOARD_KEY_INFO_LIC;
                this.permissionKey = "ADMINISTER_PATHTRAK_SERVERS";
            }

        }
    }

    private determineTranslation(localizationService: any, notificationType: string, count:number, days: number): string {
        if(count != null && days != null) {
            //Must use days and count in translation.. There must be two translation resources
            let afterCount = localizationService.localization.instant(notificationType + "_AFTER_COUNT");
            let afterDays = localizationService.localization.instant(notificationType + "_AFTER_DAYS");
            return count + afterCount + days + afterDays;
        }
        if(count != null) {
            return localizationService.localization.instant(notificationType) + " : " + count;
        }
        if(days != null) {
            return localizationService.localization.instant(notificationType) + " : " + days;
        }
        return localizationService.localization.instant(notificationType);
    }
}

export class HCUSummaryData {
    public hcu: LinkEntry[];
    public hcuDetails: DashboardBoxEntry[];

    private readonly url = appConst.DASHBOARD_KEY_HCU;

    constructor(hcuSummary, localizationService: TranslateService) {
        // HCU Summary
        localizationService.get([
            appConst.DASHBOARD_KEY_RPM3,
            appConst.DASHBOARD_KEY_RPM12,
            appConst.DASHBOARD_KEY_HSM,
            appConst.DASHBOARD_KEY_VIRTUAL_HSM,
            appConst.DASHBOARD_KEY_PORT
        ]
        ).subscribe(val=>{

            let online = new LinkEntry(this.url, appConst.DASHBOARD_KEY_TOTAL, hcuSummary.total, localizationService);
            let offline = new LinkEntry(this.url, appConst.DASHBOARD_KEY_OFFLINE, hcuSummary.offline, localizationService);
            offline.class = offline.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
            offline.filter = appConst.DASHBOARD_KEY_OFFLINE;
    
            let error = new LinkEntry(this.url, appConst.DASHBOARD_KEY_ERROR, hcuSummary.error, localizationService);
            error.class = error.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
            error.filter = appConst.DASHBOARD_KEY_ERROR;
    
            this.hcu = [online, offline, error];
    
            // HCU Details
            let rpm3 = new NonLinkEntry(appConst.DASHBOARD_KEY_RPM3, val[appConst.DASHBOARD_KEY_RPM3], hcuSummary.rpm3k);
            let rpm12 = new NonLinkEntry(appConst.DASHBOARD_KEY_RPM12,val[appConst.DASHBOARD_KEY_RPM12], hcuSummary.rpm12k);
            rpm3.tab = rpm12.tab = appConst.DASHBOARD_KEY_RPM;
    
            let hsm = new NonLinkEntry(appConst.DASHBOARD_KEY_HSM,val[appConst.DASHBOARD_KEY_HSM],hcuSummary.hsm);
            let vHsm = new NonLinkEntry(appConst.DASHBOARD_KEY_VIRTUAL_HSM,val[appConst.DASHBOARD_KEY_VIRTUAL_HSM], hcuSummary.virtualHsm);
            hsm.tab = vHsm.tab = appConst.DASHBOARD_KEY_HSM;
    
            let port = new NonLinkEntry(appConst.DASHBOARD_KEY_PORT, val[appConst.DASHBOARD_KEY_PORT],hcuSummary.port);
            port.tab = appConst.DASHBOARD_KEY_PORT;
            
            this.hcuDetails = [rpm3, rpm12, port, hsm, vHsm];
        })
        
    }
}

export class CMTSSummaryData {
    public cmts: LinkEntry[];
    public cmtsDetails: DashboardBoxEntry[];
    public modemDetails: NonLinkEntry[];

    private readonly url = appConst.DASHBOARD_KEY_CMTS;
    private readonly permissionKey = 'ADMINISTER_PATHTRAK_CMTS';

    constructor (cmtsSummary, localizationService: TranslateService) {
        // CMTS Summary
        localizationService.stream([appConst.DASHBOARD_KEY_TOTAL,appConst.CMTS_KEY_UNAVAILABLE]).subscribe(val=>{
            let online = new LinkEntry(this.url, appConst.DASHBOARD_KEY_TOTAL, cmtsSummary.total, localizationService, this.permissionKey);
            let unavailable = new LinkEntry(this.url, val[appConst.CMTS_KEY_UNAVAILABLE], cmtsSummary.offline,localizationService);
            unavailable.class = unavailable.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
            unavailable.filter = appConst.CMTS_KEY_UNAVAILABLE;
    
            let error = new LinkEntry(this.url, appConst.DASHBOARD_KEY_ERROR, cmtsSummary.error, localizationService, this.permissionKey);
            error.class = error.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
            error.filter = appConst.DASHBOARD_KEY_ERROR;
    
            this.cmts = [online, unavailable, error];
        });


        // CMTS Details
        let nodes = new NonLinkEntry( appConst.DASHBOARD_KEY_NODE,localizationService.instant(appConst.DASHBOARD_KEY_NODE),cmtsSummary.node);
        nodes.tab = appConst.DASHBOARD_KEY_NODE;
        localizationService.stream([appConst.DASHBOARD_KEY_CMTS_MODEMS,appConst.DASHBOARD_KEY_NODE_MODEMS, appConst.DASHBOARD_KEY_NODE_MODEMS_WITH_DOCSIS]).subscribe(val=>{
            let modems = new NonLinkEntry(appConst.DASHBOARD_KEY_CMTS_MODEMS, val[appConst.DASHBOARD_KEY_CMTS_MODEMS], cmtsSummary.cmtsModems);
            let nodeModems = new NonLinkEntry(appConst.DASHBOARD_KEY_NODE_MODEMS, val[appConst.DASHBOARD_KEY_NODE_MODEMS], cmtsSummary.nodeModems);
            let nodeModemsWithDocsis = new NonLinkEntry(appConst.DASHBOARD_KEY_NODE_MODEMS_WITH_DOCSIS,  val[appConst.DASHBOARD_KEY_NODE_MODEMS_WITH_DOCSIS], cmtsSummary.nodeModemsWithDocsis);
    
            this.cmtsDetails = [nodes, modems, nodeModems, nodeModemsWithDocsis];
    
            // Modem Details
            this.modemDetails = [
                new NonLinkEntry(appConst.DASHBOARD_KEY_DOCSIS2, localizationService.instant(appConst.DASHBOARD_KEY_DOCSIS2), cmtsSummary.docsis2),
                new NonLinkEntry(appConst.DASHBOARD_KEY_DOCSIS3, localizationService.instant(appConst.DASHBOARD_KEY_DOCSIS3), cmtsSummary.docsis30),
                new NonLinkEntry(appConst.DASHBOARD_KEY_DOCSIS31, localizationService.instant(appConst.DASHBOARD_KEY_DOCSIS31), cmtsSummary.docsis31),
                new NonLinkEntry(appConst.DASHBOARD_KEY_GEOCODE, localizationService.instant(appConst.DASHBOARD_KEY_GEOCODE), cmtsSummary.geocode),
                new NonLinkEntry(appConst.DASHBOARD_KEY_DOWNLOADSPECTRUM, localizationService.instant(appConst.DASHBOARD_KEY_DOWNLOADSPECTRUM), cmtsSummary.downstreamSpectrum),
                new NonLinkEntry(appConst.DASHBOARD_KEY_PREEQ, localizationService.instant(appConst.DASHBOARD_KEY_PREEQ), cmtsSummary.preEq),
            ];
        })
    }
}

export class RCISummaryData {
    public rci : LinkEntry[];

    private readonly url = appConst.DASHBOARD_KEY_RCI;
    private readonly permissionKey = 'ADMINISTER_PATHTRAK_CMTS';
    constructor(summaryStatus, localizationService: TranslateService) {
        let online = new LinkEntry(this.url, appConst.DASHBOARD_KEY_TOTAL, summaryStatus.total, localizationService,this.permissionKey);
        let offline = new LinkEntry(this.url, appConst.DASHBOARD_KEY_OFFLINE, summaryStatus.offline, localizationService, this.permissionKey);
        let error = new LinkEntry(this.url, appConst.DASHBOARD_KEY_ERROR, summaryStatus.error, localizationService, this.permissionKey);

        offline.class = offline.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
        error.class = error.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;

        offline.filter = appConst.DASHBOARD_KEY_OFFLINE;
        error.filter = appConst.DASHBOARD_KEY_ERROR; 

        this.rci = [online, offline, error];
    }
}

export class OltSummaryData {
    public olt : LinkEntry[];
    public oltDetails: DashboardBoxEntry[];
    
    private readonly url = appConst.DASHBOARD_KEY_OLT;
    private readonly permissionKey = 'ADMIN_PON';
    constructor(summaryStatus, localizationService: TranslateService) {

        localizationService.get([appConst.DASHBOARD_KEY_ONTS,appConst.DASHBOARD_KEY_PORTS]).subscribe(val=>{
            let online = new LinkEntry(this.url, appConst.DASHBOARD_KEY_TOTAL, summaryStatus.total, localizationService,this.permissionKey);
            let offline = new LinkEntry(this.url, appConst.DASHBOARD_KEY_UNAVAILABLE, summaryStatus.offline, localizationService, this.permissionKey);
            let error = new LinkEntry(this.url, appConst.DASHBOARD_KEY_ERROR, summaryStatus.error, localizationService, this.permissionKey);
    
            offline.class = offline.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
            error.class = error.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
    
            offline.filter = appConst.DASHBOARD_KEY_OFFLINE;
            error.filter = appConst.DASHBOARD_KEY_ERROR; 
    
            this.olt = [online, offline, error];
    
            //OLT detail section
    
            let onts = new NonLinkEntry(this.url, val[appConst.DASHBOARD_KEY_ONTS], summaryStatus.onts);
            let ports = new NonLinkEntry(this.url,val[appConst.DASHBOARD_KEY_PORTS], summaryStatus.ports);
            this.oltDetails = [onts,ports];
        })

    }
}

export class OtuSummaryData {
    public otu : LinkEntry[];

    private readonly url = appConst.DASHBOARD_KEY_OTU;
    private readonly permissionKey = 'ADMINISTER_OTU';
    constructor(summaryStatus, localizationService: TranslateService) {
        let online = new LinkEntry(this.url, appConst.DASHBOARD_KEY_TOTAL, summaryStatus.total, localizationService,this.permissionKey);
        let offline = new LinkEntry(this.url, appConst.DASHBOARD_KEY_OFFLINE, summaryStatus.offline, localizationService, this.permissionKey);
        let error = new LinkEntry(this.url, appConst.DASHBOARD_KEY_ERROR, summaryStatus.error, localizationService, this.permissionKey);

        offline.class = offline.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;
        error.class = error.value > 0 ? appConst.DASHBOARD_KEY_ERRORTXT : appConst.DASHBOARD_KEY_SUCCESSTXT;

        offline.filter = appConst.DASHBOARD_KEY_OFFLINE;
        error.filter = appConst.DASHBOARD_KEY_ERROR; 

        this.otu = [online, offline, error];
    }
}
