/**
 * Created by narayan.reddy on 23-06-2017.
 */

import { Injectable } from '@angular/core';
import {SharedService} from "../../shared/shared.service";
import { PATHTRAK_PATH } from "../../constant/app.constants";
import { AuthService } from 'src/app/shared/auth.service';
import { switchMap } from 'rxjs/operators';

@Injectable()
export class DashboardUrlService {
    private host:string = '';
    httpService: any;

    constructor(private sharedService:SharedService,
        private authService :AuthService) {
    }

    // obtains host ID
    private getHost():string {
        return this.sharedService.getHost() + PATHTRAK_PATH;
    }

    // obtain data for Alarm summary
    public getDashboardAlertUrl():string {
        return this.getHost() + "alert";
    }

    // obtain data for HCU Details
    public getHCUDataUrl():string {
        return this.getHost() + "summary/hcu";
    }

    // obtain data for Alarm Summary
    public getAlarmSummaryUrlDevice():string {
        return this.getHost() + "summary/alarm/device";
    }

    // obtain data for CMTS Data
    public getCMTSDataUrl():string {
        return this.getHost() + "summary/cmts";
    }

    // obtain summary data for RCIs
    public getRCIDataUrl(): string {
        return this.getHost() + "summary/rci";
    }

    // obtain summary data for OTUs
    public getOtuDataUrl(): string {
        return this.getHost() + "summary/otu";
    }

    public getOltDataUrl(): string { 
        return this.getHost() + "pon/olt/summary"
    }

    public getOntDataUrl(): string { 
        return this.getHost() + "pon/ont/summary"
    }
}
