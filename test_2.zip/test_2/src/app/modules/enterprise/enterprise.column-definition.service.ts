import { Injectable } from "@angular/core";
import { LocaleDataService } from "../../shared/locale.data.service";
import { DisabledFilter } from "../shared/grid/disabled.filter";
import { SharedService } from "../../shared/shared.service";

import { EnterpriseService } from "./enterprise.service";
import { EDIT_ICON } from "../../constant/app.constants";
import {gridCustomComparator} from "../../shared/ag-Grid.comparator";


@Injectable()
export class EnterpriseColumnDefinitionService {

    constructor(private localeDataService: LocaleDataService,
        private enterpriseService: EnterpriseService,
        private sharedService: SharedService
    ) { }
   
    private regionGridColDef: any;
    private systemGridColDef: any;
    private NO_OF_SYSTEM: string;
    private REGION: string;
    private EDIT: string;
    private NAME: string;
    private SYSTEM_URL: string;
    private NOTES: string;

    // returning region grid column defination
    public getRegionGridColDef(): any {
        this.translateRegionLocaleStrings();
        this.regionGridColDef = [
            {
                headerName: '',
                width:21,
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { newRowsAction: 'keep' },
                suppressResize: true

            },
            {
                headerName: this.REGION,
                field: "name",
                filter: "text",
                comparator: gridCustomComparator,
                minWidth: this.sharedService.getHeaderTemplate(this.REGION, 90),
                sort: 'asc',
                floatingFilterComponentParams: { suppressFilterButton: true },
                headerTooltip: this.REGION,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this.NO_OF_SYSTEM,
                field: "numberOfSystems",
                filter: "number",
                minWidth:this.sharedService.getHeaderTemplate(this.NO_OF_SYSTEM, 90),
                floatingFilterComponentParams: { suppressFilterButton: true },
                headerTooltip: this.NO_OF_SYSTEM,
                filterParams: { newRowsAction: 'keep' }
            },

            {
                headerName: this.EDIT,
                minWidth: this.sharedService.getHeaderTemplate(this.EDIT, 90),
                pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                headerTooltip: this.EDIT,
                suppressSorting: true,
                cellStyle: () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { newRowsAction: 'keep' },
                suppressMenu: true,
                cellRenderer: ((param: any) => {
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (() => {
                        this.action(param.data);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }
        ];
        return this.regionGridColDef;
    }

    // returning system grid column defination
    public getSystemGridColDef() {
        this.translateSystemsLocaleStrings();
        this.systemGridColDef = [
            {
                headerName: '',
                width:21,
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { newRowsAction: 'keep' },
                suppressResize: true
            },

            {
                headerName: this.NAME, field: "name",
                filter: "text",
                comparator: gridCustomComparator,
                minWidth: this.sharedService.getHeaderTemplate(this.NAME, 90),
                headerTooltip: this.NAME,
                sort: 'asc',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: {suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this.SYSTEM_URL, field: "systemUrl",
                filter: "text",
                comparator: gridCustomComparator,
                minWidth: this.sharedService.getHeaderTemplate(this.SYSTEM_URL, 90),
                headerTooltip: this.SYSTEM_URL,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: this.NOTES, field: "linkComment",
                filter: "text",
                comparator: gridCustomComparator,
                minWidth: this.sharedService.getHeaderTemplate(this.NOTES, 90),
                headerTooltip:this.NOTES,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            }, {
                headerName: this.REGION, field: "regionName",
                filter: "text",
                comparator: gridCustomComparator,
                minWidth: this.sharedService.getHeaderTemplate(this.REGION, 90),
                headerTooltip: this.REGION,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: {suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            }, {
                headerName: this.EDIT,
                minWidth: 100,
                pinned: this.sharedService.isPinned(),
                headerTooltip: this.EDIT,
                sortingOrder: [null],
                cellStyle: () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { newRowsAction: 'keep' },
                suppressMenu: true,
                cellRenderer: ((param: any) => {
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (() => {
                        this.editSystemAction(param.data);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }

        ];
        return this.systemGridColDef;
    }


    // @method :: callback action for clear icon click
    private action(param: any): void {
        console.log('Region edit clicked')
        this.enterpriseService.showEditSlider(param);
    }

    private editSystemAction(param: any) {
        console.log('edit clicked', param)
        this.enterpriseService.showSystemEditSlider(param);
    }

    //translate locale strings
    private translateRegionLocaleStrings(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.REGION = localizationService.instant("REGION");
        this.EDIT = localizationService.instant("EDIT");
        this.NO_OF_SYSTEM = localizationService.instant("NO_OF_SYSTEM");
    }
    private translateSystemsLocaleStrings(): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.NAME = localizationService.instant("NAME");
        this.SYSTEM_URL = localizationService.instant("SYSTEM_URL");
        this.NOTES = localizationService.instant("NOTES");
    }

}