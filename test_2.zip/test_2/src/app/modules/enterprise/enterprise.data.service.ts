import { Observable, Subject, throwError } from 'rxjs';
import { Injectable } from "@angular/core";
import { EnterpriseHttpService } from "./enterprise.http.service";
import { RegionList, RegionSytemsList } from "./models/enterprise.model";
import { EnterpriseSettingsList, EnterpriseSettings } from "./models/settings.model";
import {
    DAILY_MINOR_THRESHOLD, DAILY_CRITICAL_THRESHOLD,
    MONTHLY_CRITICAL_THRESHOLD, MONTHLY_MINOR_THRESHOLD, MONTHLY_MACTRAK_MINOR_THRESHOLD,
    DAILY_MACTRAK_MINOR_THRESHOLD, DAILY_MACTRAK_CRITICAL_THRESHOLD,
    MONTHLY_MACTRAK_CRITICAL_THRESHOLD
} from "../../constant/app.constants";
import { NumberInputComponent } from "./directive/number-input/number-input.component";
import { map, catchError } from 'rxjs/operators';
import {ShowAlert} from "../../utilities/showAlert";

@Injectable()

export class EnterpriseDataService {
    selectedTab: string;
    private settingsList: EnterpriseSettingsList;
    public regiontabfilterchangedata: any;
    public systemtabfilterchangedata: any;
    public regionmodeldata: any;
    public regionmodeldata2: any;
    private numberInputMap = new Map<string, NumberInputComponent>();
    public revertValue: Subject<any> = new Subject<any>();
    public settingSaved: Subject<any> = new Subject<any>();

    public enableDisableSave: Subject<any> = new Subject<any>();

    constructor(private enterpriseHttpService: EnterpriseHttpService,
        private showAlert: ShowAlert) {

    }

    public getTab(){
		return this.selectedTab;
	}

	public setTab(value: string){
		this.selectedTab = value;
	}

    public getRegionList(): Observable<any> {
        let regionList: RegionList;
        return this.enterpriseHttpService.getRegionList()
            .pipe(map((regionList) => {
                regionList = new RegionList(regionList);
                return regionList;
            }),
            catchError(this.handleError)
            )
    }


    public getRegionDetails(): Observable<any> {      
        let regionSytemsList: RegionSytemsList;
        return this.enterpriseHttpService.getRegionDetails()
            .pipe(map((systemList) => {
                regionSytemsList = new RegionSytemsList(systemList);
                return regionSytemsList;
            }),
            catchError(this.handleError))
    }

    public addRegion(data): Observable<any> {
        return this.enterpriseHttpService.addRegion(data)
            .pipe(map((response: any) => {
                return response;
            }),
            catchError(this.handleError))
    }

    public editRegion(data: Object, regionId: number): Observable<any> {
        return this.enterpriseHttpService.editRegion(data, regionId)
            .pipe(map((response) => {
                return response;
            }),
            catchError(this.handleError))
    }

    public deleteRegion(regionId): Observable<any> {
        return this.enterpriseHttpService
            .deleteRegion(regionId)
            .pipe(map((res: any) => {
                return res;
            }),
            catchError(this.handleError))
    }

    public addSystem(data): Observable<any> {
        return this.enterpriseHttpService
            .addSystem(data)
            .pipe(map((res: any) => {
                return res;
            }),
            catchError(this.handleError))
    }

    public editSystem(data: Object, systemId: number): Observable<any> {
        return this.enterpriseHttpService
            .editSystem(data, systemId)
            .pipe(map((response: any) => {
                return response;
            }),
            catchError(this.handleError))
    }

    public deleteSystem(systemId: number): Observable<any> {
        return this.enterpriseHttpService
            .deleteSystem(systemId)
            .pipe(map((response: any) => {
                return response;
            }),
            catchError(this.handleError))
    }

    public checkForValidSystemUrl(url): Observable<any> {
        return this.enterpriseHttpService
            .checkForValidSystemUrl(url)
            .pipe(map((response) => {
                return response;
            }),
            catchError(this.handleError))
    }

    public getSettingsList(): Observable<any> {
        return this.enterpriseHttpService
            .getEnterpriseSettings()
            .pipe(map((settings: any) => {
                this.settingsList = new EnterpriseSettingsList(settings);
                return this.settingsList;
            }),
            catchError(this.handleError))
    }


    /**
     * This method is called for saving the settings changed by the user
     */
    public onSubmit(): void {
        let updatedData: any = [];
        for (let i = 0; i < this.settingsList.length; i++) {
            if (this.settingsList[i].isModified) {
                updatedData.push(JSON.parse(this.settingsList[i].getJSON()));
            }
        }

        this.enterpriseHttpService.updateSettings(updatedData).subscribe(this.onAddNext.bind(this));
    }


    /**
     *  Call back method after user has set the updated value to the server
     *  Now we need to update the server value stored locally at our end
     * @param data
     */
    private onAddNext(data): void {

        this.enableDisableSave.next({ isDisabled: true, showMessage: true });
        this.settingSaved.next(true);
        if (this.settingsList && this.settingsList.length > 0) {
            for (let j = 0; j < this.settingsList.length; j++) {
                let settings: EnterpriseSettings = this.settingsList[j];
                if (settings.isModified) {
                    settings.setSavedValue();
                }
            }
        }
    }
    /**
    * This method is used for enabling / disabling the state of the save button
    */
    public disableSave() {
        this.enableDisableSave.next({ isDisabled: false, showMessage: false });
        if (this.settingsList && this.settingsList.length > 0) {
            for (let j = 0; j < this.settingsList.length; j++) {
                let setting: EnterpriseSettings = this.settingsList[j];
                if (!setting.isValid) {
                    this.enableDisableSave.next({ isDisabled: true, showMessage: false });
                    break;
                }
            }
        }
    }

    public setNumberInputComponent(fieldName: string, numberInputComponent: NumberInputComponent) {
        switch (fieldName) {
            case DAILY_MINOR_THRESHOLD:
            case DAILY_CRITICAL_THRESHOLD:
            case MONTHLY_MINOR_THRESHOLD:
            case MONTHLY_CRITICAL_THRESHOLD:
            case DAILY_MACTRAK_MINOR_THRESHOLD:
            case DAILY_MACTRAK_CRITICAL_THRESHOLD:
            case MONTHLY_MACTRAK_MINOR_THRESHOLD:
            case MONTHLY_MACTRAK_CRITICAL_THRESHOLD:
                this.numberInputMap.set(fieldName, numberInputComponent);
                break;
        }


    }
    public getComparatorNumberInputComponent(fieldName: string): NumberInputComponent {
        return this.numberInputMap.get(fieldName);
    }

    /**
   * When user press cancel button to revert user made changes
   */
    public onCancel(): void {

        if (this.settingsList && this.settingsList.length > 0) {
            this.settingsList.isComponentValid = true;
            for (let j = 0; j < this.settingsList.length; j++) {
                let enterpriseSetting: EnterpriseSettings = this.settingsList[j];
                if (enterpriseSetting.isModified) {
                    enterpriseSetting.cancel();
                    this.revertValue.next(true);
                }
            }
        }
        this.enableDisableSave.next({ isDisabled: true, showMessage: false });
    }
    //Error handler
    public handleError(error) {
        
        return throwError(error);
    }
}