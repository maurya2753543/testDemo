

export class RegionList extends Array {
    constructor(jsonData) {
        super();
        if (jsonData) {
            for (let i = 0; i < jsonData.length; i++) {
                let region: Region = new Region(jsonData[i]);
                this.push(region);
            }
        }
    }
}

export class Region {
    private regionId : number;
    private name: string;
    private numberOfSystems: number;

    constructor(jsonData) {
        this.regionId = jsonData.regionId;
        this.name = jsonData.name;
        this.numberOfSystems = jsonData.numberOfSystems;
    }

}

export class RegionSytemsList extends Array {
   
    constructor(jsonData) {
        super();
        
        if (jsonData) {
            for(let i=0;i<jsonData.length;i++){
                let system : SystemDetail = new SystemDetail(jsonData[i]); 
                this.push(system);
            }
        }
    } 
}    

export class SystemDetail {
    private name : string;
    private systemUrl: string;
    private linkComment: string;
    private regionName: string;
    private systemId: number;
    private regionId: number
    private selectedRegion: any
    constructor(jsonData) {
        this.systemId = jsonData.systemId;
        this.name = jsonData.name;
        this.systemUrl = jsonData.systemUrl;
        this.linkComment = jsonData.linkComment;
        this.regionName = jsonData.regionName;
        this.regionId = jsonData.regionId;
        this.selectedRegion = jsonData.selectedRegion;
    }
    public postData(){
        let systemsObj={
            "systemId" : this.systemId,
            "name" :this.name,
            "linkComment" : this.linkComment,
            "systemUrl" : this.systemUrl,
            "regionId" : this.selectedRegion.regionId,
            "regionName" :this.selectedRegion.name
        }
        return systemsObj;
    }
}

