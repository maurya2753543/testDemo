/**
  * This class holds the array for the particular setting
   */
 export class EnterpriseSettingsList extends Array{

    public isComponentValid : boolean = true;

    constructor(jsonList){
        super();
        if(jsonList){
            for(let i = 0 ; i < jsonList.length ; i++){
                let generalSettings : EnterpriseSettings= new EnterpriseSettings(jsonList[i]);
                this.push(generalSettings);
            }
        }
    }
}

 /**
  * This class holds the value for particular setting
  */
 export class EnterpriseSettings{
    /** Value of the settings which can be modified by the server*/
    protected value : string = "";

    /** Valued of the settings from the server which is modified only when user saves updated value to server*/
    protected serverValue : string = "";


    public ptDb : boolean;
    public name : string = "";
    public defaultValue : string = "";
    public rangeType : boolean;

    public options : SettingsOptions;

    public units : string ;
    //Temporary
    public notes : string;
    public rangeStart : string;
    public rangeStop : string;
    public resolution : string;

   /** This field is used to identify whether resolution is whole number or decimal number */
    public isFloatValue : boolean = false;

    /** This field is used to identify whether user entered value is modified or is same */
    public isModified : boolean = false;

     /** This field is used to identify whether user entered value is valid or not */
    public isValid : boolean = true;

    /** This field is used to identify whether field is optional or not */
    private isOptional:boolean = false;



    constructor(jsonData){

        this.ptDb = jsonData.ptDb;
        this.name = jsonData.name;
        this.value = jsonData.value;

        this.defaultValue = jsonData.defaultValue;
        this.rangeType = jsonData.rangeType;

        if(jsonData.options){
            this.options = new SettingsOptions(jsonData);
        }

        this.units = jsonData.units;
        this.notes = jsonData.notes;
        this.rangeStart = jsonData.rangeStart;
        this.rangeStop = jsonData.rangeStop;
        this.resolution = jsonData.resolution;

        this.serverValue = jsonData.value;
        this.checkIfFloat();
        

    }

     /**
      * Checks whether resolution is whole or decimal and detects isFloat value
       */
    private checkIfFloat() : void {
        if(Number(this.resolution)){
            try{
                let resolutionFloat = parseFloat(this.resolution);
                if(resolutionFloat < 1){
                    this.isFloatValue = true;
                }
                if(!this.isFloatValue){
                    this.convertToInt();
                }else{
                    this.value = this.getFloatValue(this.value);
                    this.serverValue = this.getFloatValue(this.serverValue);
                    this.defaultValue = this.getFloatValue(this.defaultValue);
                }
            }catch(exception){
                console.error("Error in parse Float calculation");
            }
        }
    }

     /**
      * If the entered value has resolution as whole number then
      * we need to convert all numbers to integer
       */
    private convertToInt() : void {
        this.value = this.getIntValue(this.value);
        this.serverValue = this.getIntValue(this.serverValue);
        this.defaultValue = this.getIntValue(this.defaultValue);
        this.rangeStart = this.getIntValue(this.rangeStart);
        this.rangeStop = this.getIntValue(this.rangeStop);
        this.resolution = this.getIntValue(this.resolution);
    }

   private getIntValue(value : string) : string {
        return ""+parseInt(value);
    }

    private getFloatValue(value : string) : string {
        return "" + parseFloat(value).toFixed(1);
    }

    public setValue(value:string) : void {
        if(this.value != value){
            this.value = value;
            this.isModified = true;
        }
    }

    public getValue():string {
        return this.value;
    }

    public getServerValue():string {
        return this.serverValue;
    }

    public isOriginalValue() : boolean {
        return (this.serverValue == this.value);
    }

    public setOptional(flag:boolean): void {
        this.isOptional = flag;
    }

    public getOptional(): boolean {
        return this.isOptional;
    }

    //Create a json object to send to the server
    public getJSON() : string {
        let generalSetting ={
            "ptDb": this.ptDb,
            "name": this.name,
            "value": this.value,
        }

        return JSON.stringify(generalSetting);
    }

 /** Reset the value with the value received from server */
    public cancel() : void {
        this.value = this.serverValue;
        this.isValid = true;
    }

    /** Update the server value once the value on the server are updated by user */
    public setSavedValue() : void {
        this.serverValue = this.value;
        this.isModified = false;
    }
}

 /** This is specifically for the drop down options */
 export class SettingsOptions{

     /** Server values for the options */
     public serverOptions : any;

     /** Dispaly values for the options */
     public displayOptions : any;

     constructor(jsonData){
         this.serverOptions = jsonData.options.split(",");
         this.displayOptions = jsonData.options.split(",");
     }

 }
