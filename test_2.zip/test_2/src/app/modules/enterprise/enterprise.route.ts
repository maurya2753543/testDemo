
import { Routes, RouterModule } from '@angular/router';
import {EnterpriseComponent} from "./enterprise.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: EnterpriseComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class EnterpriseRoutes{}
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);