import { Component } from "@angular/core";
import { EnterpriseDataService } from "../enterprise.data.service";
import { EnterpriseSettingsList} from "../models/settings.model";
import { SweetAlert } from "../../../utilities/sweetAlert"
import { Logger } from "../../../utilities/logger";
import {SettingsTabService} from "./settings-tab.service";

import {
    DAILY_MINOR_THRESHOLD, DAILY_CRITICAL_THRESHOLD,
    MONTHLY_CRITICAL_THRESHOLD, MONTHLY_MINOR_THRESHOLD, MONTHLY_MACTRAK_MINOR_THRESHOLD,
    DAILY_MACTRAK_MINOR_THRESHOLD, DAILY_MACTRAK_CRITICAL_THRESHOLD,
    MONTHLY_MACTRAK_CRITICAL_THRESHOLD
} from "../../../constant/app.constants";
import { LocaleDataService } from "../../../shared/locale.data.service";
import {ShowAlert} from "../../../utilities/showAlert";
@Component({
    selector: "settings",
    templateUrl: "settings-tab.component.html"
})
export class SettingsTabComponent {

    public settingsList: EnterpriseSettingsList;
    public formDisabled: boolean = true;
    public showMessage: boolean = false;
    private tag: string = "SettingTabComponent::";
    public loadComponent: boolean = false;
    private startRange: any;
    private stopRange: any;

    constructor(
        private enterpriseDataService: EnterpriseDataService,
        private sweetAlert: SweetAlert,
        private showAlert: ShowAlert,
        private localeDataService: LocaleDataService,
        private logger: Logger,
        private settingsTabService:SettingsTabService
    ) {

    }
    ngOnInit() {
        
        this.getSettingsList();
        this.enableDisableSave();
    }
    /*
     * @name: getRegionList()
     * @desc: API call for getting regions
     * */
    private getSettingsList(): void {
        this.enterpriseDataService.getSettingsList()
            .subscribe(this.onSettingsListNext.bind(this), this.onError.bind(this));
    }
    private onSettingsListNext(settingsList): void {
       this.settingsList= this.settingsTabService.processData(settingsList);
       this.loadComponent = true;
    }
    /*
  * @name: onError
  * @desc: used to handle error of api response
  * @param: value=> error code from server
  * */
    private onError(error):void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    private getValueFromInput(numberInputComponent):void {
        this.rangeValidation(numberInputComponent);
    }
    
    //function to call on submit
    public submitForm(): void {
        this.enterpriseDataService.onSubmit();
    }
    //function to call on cancel
    public onCancel(): void {
        this.enterpriseDataService.onCancel();
    }
    private enableDisableSave(){
        this.enterpriseDataService.enableDisableSave.subscribe((data) => {
            this.formDisabled = data.isDisabled;
            this.showMessage = data.showMessage;
        })
    }
    public onTabSwitch(): void{
        this.getSettingsList();
    }

    /*
     * @name: rangeValidation
     * @desc: This method receives the call back from the number input component with component as parameter. We check whether
         the minor threshold range is greater then critical threshold range and if it then we send the error notification to the respective component.
     * @param: numberInputComponent=> number input component object
     * */
    private rangeValidation(numberInputComponent: any): void {

        let rangeType = numberInputComponent.optionObject.name;
        let numberComparatorParam: string;
        switch (rangeType) {
            case DAILY_MINOR_THRESHOLD:
                numberComparatorParam = DAILY_CRITICAL_THRESHOLD;
                break;
            case DAILY_CRITICAL_THRESHOLD:
                numberComparatorParam = DAILY_MINOR_THRESHOLD;
                break;
            case MONTHLY_MINOR_THRESHOLD:
                numberComparatorParam = MONTHLY_CRITICAL_THRESHOLD;
                break;
            case MONTHLY_CRITICAL_THRESHOLD:
                numberComparatorParam = MONTHLY_MINOR_THRESHOLD;
                break;
            case DAILY_MACTRAK_MINOR_THRESHOLD:
                numberComparatorParam = DAILY_MACTRAK_CRITICAL_THRESHOLD;
                break;
            case DAILY_MACTRAK_CRITICAL_THRESHOLD:
                numberComparatorParam = DAILY_MACTRAK_MINOR_THRESHOLD;
                break;
            case MONTHLY_MACTRAK_MINOR_THRESHOLD:
                numberComparatorParam = MONTHLY_MACTRAK_CRITICAL_THRESHOLD;
                break;
            case MONTHLY_MACTRAK_CRITICAL_THRESHOLD:
                numberComparatorParam = MONTHLY_MACTRAK_MINOR_THRESHOLD;
                break;
        }
        switch (numberInputComponent.optionObject.name) {
            case DAILY_MINOR_THRESHOLD:
            case MONTHLY_MINOR_THRESHOLD:
            case MONTHLY_MACTRAK_MINOR_THRESHOLD:
            case DAILY_MACTRAK_MINOR_THRESHOLD:
                this.startRange = numberInputComponent;
                this.stopRange = this.enterpriseDataService.getComparatorNumberInputComponent(numberComparatorParam);

                if (this.startRange.isDefaultPressed) {
                    this.stopRange.updateValue(this.stopRange.numberInputModel.getValue());
                    let isInvalid: boolean = this.isRangeNotValid(this.startRange.numberInputModel.getValue(), this.stopRange.numberInputModel.getValue());
                    if (this.stopRange.isValid) {
                        this.stopRange.setRangeInvalid(isInvalid);
                    }
                    if (this.startRange.isValid) {
                        this.startRange.setRangeInvalid(isInvalid);
                    }

                } else {
                    let isInvalid: boolean = this.isRangeNotValid(this.startRange.numberInputModel.getValue(), this.stopRange.numberInputModel.getValue());
                    this.stopRange.updateValue(this.stopRange.numberInputModel.getValue());
                    if (this.stopRange.isValid) {
                        this.stopRange.setRangeInvalid(isInvalid);
                    } else {
                        if (isInvalid) {
                            this.stopRange.setRangeInvalid(isInvalid);
                        }
                    }

                    if (this.startRange.isValid) {
                        this.startRange.setRangeInvalid(isInvalid);
                    } else {
                        if (isInvalid) {
                            this.startRange.setRangeInvalid(isInvalid);
                        }
                    }
                }
                break;
            case DAILY_CRITICAL_THRESHOLD:
            case MONTHLY_CRITICAL_THRESHOLD:
            case MONTHLY_MACTRAK_CRITICAL_THRESHOLD:
            case DAILY_MACTRAK_CRITICAL_THRESHOLD:

                this.startRange = this.enterpriseDataService.getComparatorNumberInputComponent(numberComparatorParam);
                this.stopRange = numberInputComponent;

                if (this.stopRange.isDefaultPressed) {

                    //this.stopFreq.setFrequencyInvalid(false);
                    this.startRange.updateValue(this.startRange.numberInputModel.getValue());
                    let isInvalid: boolean = this.isRangeNotValid(this.startRange.numberInputModel.getValue(), this.stopRange.numberInputModel.getValue());
                    if (this.startRange.isValid) {
                        this.startRange.setRangeInvalid(isInvalid);
                    }

                    if (this.stopRange.isValid) {
                        this.stopRange.setRangeInvalid(isInvalid);
                    }

                } else {
                    let isInvalid: boolean = this.isRangeNotValid(this.startRange.numberInputModel.getValue(), this.stopRange.numberInputModel.getValue());
                    this.startRange.updateValue(this.startRange.numberInputModel.getValue());
                    if (this.startRange.isValid) {
                        this.startRange.setRangeInvalid(isInvalid);
                    } else {
                        if (isInvalid) {
                            this.startRange.setRangeInvalid(isInvalid);
                        }
                    }

                    if (this.stopRange.isValid) {
                        this.stopRange.setRangeInvalid(isInvalid);
                    } else {
                        if (isInvalid) {
                            this.stopRange.setRangeInvalid(isInvalid);
                        }
                    }
                }
        }
    }



    private isRangeNotValid(startRange: string, stopRange: string): boolean {
        let startRangeNumber = parseFloat(startRange);
        let stopRangeNumber = parseFloat(stopRange);

        if (stopRangeNumber <= startRangeNumber) {
            return true;
        } else {
            return false;
        }
    }

}

