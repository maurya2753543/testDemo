import { Injectable } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import {
    DAYS, MONTHS, DAILY_MINOR_THRESHOLD, DAILY_CRITICAL_THRESHOLD,
    MONTHLY_CRITICAL_THRESHOLD, MONTHLY_MINOR_THRESHOLD, MONTHLY_MACTRAK_MINOR_THRESHOLD,
    DAILY_MACTRAK_MINOR_THRESHOLD, DAILY_MACTRAK_CRITICAL_THRESHOLD,
    MONTHLY_MACTRAK_CRITICAL_THRESHOLD, MONTHLY_ROLLUP, MONTHLY_PURGE, DAILY_ROLLUP, DAILY_PURGE
} from "../../../constant/app.constants";


import { LocaleDataService } from "../../../shared/locale.data.service";
@Injectable()
export class SettingsTabService {
    private DEFAULT: string;
    private DAYS: string;
    private MONTHS: string;

    constructor(
        private localeDataService: LocaleDataService,
        public translate : TranslateService
    ) {
        this.localeDataService.componentCallback.subscribe((response) => { this.translateLocaleStrings()
        });
        this.translateLocaleStrings();
     }


    // divide api data according to diffrent category
    public processData(settingsList): any {
        let newSettingsArray = [];
        let rollUp: any = [];
        let dailyThreshold: any = [];
        let monthlyThreshold: any = [];
        let purge: any = [];
        let dailyMactrak: any = [];
        let monthlyMactrak: any = [];
        let newArr: any;
        for (let i = 0; i < settingsList.length; i++) {
            switch (settingsList[i].name) {
                case MONTHLY_ROLLUP:
                    rollUp.push({
                        response: settingsList[i],
                        name: MONTHLY_ROLLUP,
                        index: 1

                    })
                    this.setUnits(settingsList[i]);
                    break;
                case DAILY_ROLLUP:
                    rollUp.push({
                        response: settingsList[i],
                        name: DAILY_ROLLUP,
                        index: 0
                    })
                    this.setUnits(settingsList[i]);
                    break;
                case MONTHLY_PURGE:
                    purge.push({
                        response: settingsList[i],
                        name: "MONTHLY_PURGE",
                        index: 1
                    })
                    break;
                case DAILY_PURGE:
                    purge.push({
                        response: settingsList[i],
                        name: "DAILY_PURGE",
                        index: 0
                    })
                    break;
                case DAILY_MINOR_THRESHOLD:
                    dailyThreshold.push({
                        response: settingsList[i],
                        name: "DAILY_MINOR_THRESHOLD",
                        desc: "SPECTRAL_MINOR_DESC",
                        index: 0

                    })
                    break;
                case DAILY_CRITICAL_THRESHOLD:
                    dailyThreshold.push({
                        response: settingsList[i],
                        name: "DAILY_CRITICAL_THRESHOLD",
                        desc: "SPECTRAL_CRITICAL_DESC",
                        index: 1
                    })
                    break;
                case MONTHLY_MINOR_THRESHOLD:
                    monthlyThreshold.push({
                        response: settingsList[i],
                        name: "MONTHLY_MINOR_THRESHOLD",
                        desc: "SPECTRAL_MINOR_DESC",
                        index: 2
                    })
                    break;
                case MONTHLY_CRITICAL_THRESHOLD:
                    monthlyThreshold.push({
                        response: settingsList[i],
                        name: "MONTHLY_CRITICAL_THRESHOLD",
                        desc: "SPECTRAL_CRITICAL_DESC",
                        index: 3
                    })
                    break;
                case DAILY_MACTRAK_MINOR_THRESHOLD:
                    dailyMactrak.push({
                        response: settingsList[i],
                        name: "DAILY_MACTRAK_MINOR_THRESHOLD",
                        desc: "MACTRAK_MINOR_DESC",
                        index: 0
                    })
                    break;
                case DAILY_MACTRAK_CRITICAL_THRESHOLD:
                    dailyMactrak.push({
                        response: settingsList[i],
                        name: "DAILY_MACTRAK_CRITICAL_THRESHOLD",
                        desc: "MACTRAK_CRITICAL_DESC",
                        index: 1
                    })
                    break;
                case MONTHLY_MACTRAK_MINOR_THRESHOLD:
                    monthlyMactrak.push({
                        response: settingsList[i],
                        name: "MONTHLY_MACTRAK_MINOR_THRESHOLD",
                        desc: "MACTRAK_MINOR_DESC",
                        index: 2
                    })
                    break;
                case MONTHLY_MACTRAK_CRITICAL_THRESHOLD:
                    monthlyMactrak.push({
                        response: settingsList[i],
                        name: "MONTHLY_MACTRAK_CRITICAL_THRESHOLD",
                        desc: "MACTRAK_CRITICAL_DESC",
                        index: 3
                    })
                    break;
                }
            }
            monthlyThreshold.sort((a, b) => a.index < b.index ? -1 : 1);
            dailyThreshold.sort((a, b) => a.index < b.index ? -1 : 1);
            monthlyMactrak.sort((a, b) => a.index < b.index ? -1 : 1);
            dailyMactrak.sort((a, b) => a.index < b.index ? -1 : 1);
            rollUp.sort((a, b) => a.index < b.index ? -1 : 1);
            purge.sort((a, b) => a.index < b.index ? -1 : 1);

            newSettingsArray.push({
                    name: "ROLL_UP_HEADER",
                    item: rollUp
                }, {
                    name: "PURGE_HEADER",
                    item: purge
                }, {
                    name: "DAILY_SPECTRAL_HEADER",
                    item: dailyThreshold
                }, {
                    name: "MONTHLY_SPECTRAL_HEADER",
                    item: monthlyThreshold
                }, {
                    name: "DAILY_MACTRAK_HEADER",
                    item: dailyMactrak
                }, {
                    name: "MONTHLY_MACTRAK_HEADER",
                    item: monthlyMactrak
                })
            return newSettingsArray;
        }


    /*
 * @name: setUnits
 * @desc: set the units for dropdown option
 * @param: value=> dropdownobject from array
 * */
    private setUnits(dropdownObj): void {
        let unit: string;
        switch (dropdownObj.units) {
            case MONTHS:
                unit = this.MONTHS;
                break;
            case DAYS:
                unit = this.DAYS
                break;
        }
        for (let i = 0; i < dropdownObj.options.displayOptions.length; i++) {
            dropdownObj.options.displayOptions[i] = dropdownObj.options.displayOptions[i] + " " + unit;
            if (dropdownObj.options.serverOptions[i].trim() == dropdownObj.defaultValue) {
                dropdownObj.options.displayOptions[i] = dropdownObj.options.displayOptions[i] + " (" + this.DEFAULT + ")";
            }
        }
    }

    /* Function translates the string into the locale of browser */
    private translateLocaleStrings(): void {
        this.DEFAULT = this.translate.instant('SS_DEFAULT');
        this.MONTHS = this.translate.instant('MONTH');
        this.DAYS = this.translate.instant('DAYS');
    }

}