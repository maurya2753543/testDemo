import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgGridModule } from "ag-grid-angular";
import { SharedModule } from "../shared/shared.module";

import { LocaleDataService } from "../../shared/locale.data.service";
import { EnterpriseComponent } from "./enterprise.component";
import {DropdownComponent} from "./directive/dropdown/dropdown.component";
import {NumberInputComponent} from "./directive/number-input/number-input.component";
import {OnlyNumber} from "./directive/number-input/only-number.directive";
import { AddEditRegionComponent } from "./region-tab/add-edit-region/add-edit-region.component";
import { RegionTabComponent } from "./region-tab/region-tab.component";
import { SystemTabComponent } from "./system-tab/system-tab.component";
import { AddEditSystemComponent } from "./system-tab/add-edit-system/add-edit-system.component";
import { EnterpriseUrlService } from "./enterprise.url.service";
import { EnterpriseHttpService } from "./enterprise.http.service";
import { EnterpriseDataService} from "./enterprise.data.service"
import { EnterpriseColumnDefinitionService } from "./enterprise.column-definition.service";
import { EnterpriseService } from "./enterprise.service";
import { EnterpriseRoutes } from "./enterprise.route";
import { FormsModule } from '@angular/forms';
import {SettingsTabComponent} from "./settings-tab/settings-tab.component";
import {SettingsTabService} from "./settings-tab/settings-tab.service";
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { HttpClient } from '@angular/common/http';
import { LanguageService } from 'src/app/shared/locale.language.service';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/enterprise-locale-`, ".json");
  }

@NgModule({
    imports: [EnterpriseRoutes,
        CommonModule,
        SharedModule,
        FormsModule,
        AgGridModule.withComponents([EnterpriseComponent]),
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),
    ],
    declarations: [
        EnterpriseComponent,
        SystemTabComponent,
        AddEditRegionComponent,
        RegionTabComponent,
        AddEditSystemComponent,
        SettingsTabComponent,
        NumberInputComponent,
        DropdownComponent,
        OnlyNumber
    ],
    providers: [
        LocaleDataService,
        EnterpriseColumnDefinitionService,
        EnterpriseService,
        EnterpriseHttpService,
        EnterpriseUrlService,
        EnterpriseDataService,
        SettingsTabService,
        TranslateService,
        LanguageService
    ],
    entryComponents: [
        SystemTabComponent,
        AddEditRegionComponent,
        RegionTabComponent,
        AddEditSystemComponent,
        SettingsTabComponent,
        NumberInputComponent,
        TranslateService
    ]
})

export class EnterpriseModule  {

}
