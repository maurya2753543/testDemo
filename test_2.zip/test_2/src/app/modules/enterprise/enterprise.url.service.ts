import { Injectable } from "@angular/core";
import { PATHTRAK_ENTERPRISE_PATH } from "../../constant/app.constants";
import { SharedService } from "../../shared/shared.service";
@Injectable()

export class EnterpriseUrlService {
    private host: string = "";
    
    constructor(private sharedService: SharedService) {
        this.host = this.sharedService.getHost();
    }

    private getHost(): string {
        return this.host + PATHTRAK_ENTERPRISE_PATH;
    }
    public getRegionListUrl(): string {
        return  this.getHost() + "region";

    }
    public getRegionDetails(): string {
        return this.getHost() + "system";
    }

    /*add new region to the regionList*/
    public addRegionUrl(): string {
        return this.getHost() + "region"
    }
    /* edit new region in the regionTable*/
    public editRegionUrl(regionId: number): string {
        return this.getHost() + "region/" + regionId;
    }
    /* delete region url*/
    public deleteRegion(regionId): string {
        return this.getHost() + "region/" + regionId;
    }

    /*enterprise setting url*/
    public enterpriseSettingUrl() {
        return this.getHost() + "setting";
    }

    /*url to add new system*/
    public addSystemUrl(): string {
        return this.getHost() + "system";
    }

    /*url to edit system*/
    public editSystemUrl(systemId) {
        return this.getHost() + "system/" + systemId;
    }
    /*url to edit system*/
    public deleteSystemUrl(systemId): string {
        return this.getHost() + "system/" + systemId;

    }
    /* Method to get delete region url*/
    public deleteRegionUrl(regionId): string {
        return this.getHost() + "region/"+ regionId;
    }
    
    /* url to check systemUrl is valid or not*/
    public checkSystemValidityUrl(url):string {
        return this.getHost() + "system/verify?url="+ url;
    }
    public updateSettingsUrl():string{
        return this.getHost() + "setting";
    }
}
