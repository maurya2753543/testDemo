
import { Component, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import { LocaleDataService } from "../../shared/locale.data.service";
import { RegionTabComponent } from "./region-tab/region-tab.component";
import { EnterpriseColumnDefinitionService } from "./enterprise.column-definition.service";
import { SystemTabComponent } from "./system-tab/system-tab.component";
import { SettingsTabComponent } from "./settings-tab/settings-tab.component";
import { CMTS_MODULE, ENTERPRISE_MODULE } from '../../constant/app.constants';
import { TranslateService } from '@ngx-translate/core';
import { EnterpriseDataService } from './enterprise.data.service';
import { NavService } from '../../shared/nav.service';

@Component({
    selector: 'enterprise-component',
    templateUrl: 'enterprise.component.html'
})

export class EnterpriseComponent {
    private settingTabRef;
    private regionTabRef: any;
    private systemTabRef: any;
    private oldSelectedSettings: Object = {};
    public selectedTab : string;

    @ViewChild('targetTabContainer', { read: ViewContainerRef }) _targetTabContainer;


    constructor(
        private enterpriseColumnDefinitionService: EnterpriseColumnDefinitionService,
        public navService: NavService,
        //public locale: LocaleService, public localization: LocalizationService,
        public localeDataService: LocaleDataService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private viewContainerRef: ViewContainerRef,
        public translate : TranslateService,
        private enterpriseDataService: EnterpriseDataService
    ) {
        let module= ENTERPRISE_MODULE;
        this.localeDataService.initLanguage(module); /* To set the current browser's language */
    }

    ngOnInit() {
        this.LoadTab(this.enterpriseDataService.getTab());
        this.translate.onLangChange.subscribe(lang => {
            this.enterpriseDataService.setTab('region');
            this.LoadTab('region');
        })
    }
    
    LoadTab(tabName: string): void {
        this.selectedTab = tabName && tabName.toLowerCase();
    }
}