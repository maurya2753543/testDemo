import { Component, Input, Output, EventEmitter } from "@angular/core";
import { EnterpriseDataService } from "../../enterprise.data.service";
import { EnterpriseService } from "../../enterprise.service";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { SystemDetail, RegionList } from "../../models/enterprise.model";
import { ADD, EDIT } from "../../../../constant/app.constants";
import { Logger } from "../../../../utilities/logger";
import {ShowAlert} from "../../../../utilities/showAlert";

@Component({
    selector: "add-edit-system",
    templateUrl: "add-edit-system.component.html"
})
export class AddEditSystemComponent {

    //public systemEditData: any;
    //private operationName: string;
    public isSystemInValid = false;
    public urlString: string = ": http://<hostname>/pathtrak)";
    private VALID_URL_MSG: string;
    private tag: string = "AddEditSystemComponent::";
    public loadComponent: boolean = false;
    private regionList: RegionList;
    public isRegionListLoaded: boolean = false;
    public isCloseRightSlider: boolean = false;
    public selectedRegionValid: boolean= false;
    private regionselected:string;
    public errorMessages: any = {
        "isNameEmpty": false,
        "isUrlEmpty": false,
    };
    @Input() operationName : string;
    @Input() systemEditData : any;
    @Output() sidebarCloseEvent = new EventEmitter<boolean>();
    constructor(
        private enterpriseDataService: EnterpriseDataService,
        private enterpriseService: EnterpriseService,
        private showAlert: ShowAlert,
        private localeDataService: LocaleDataService,
        private logger: Logger
    ) { }

    
    ngOnInit() {
        this.translateLocaleString();
        this.clearData();
        if (this.operationName == ADD || this.operationName == EDIT) {
            this.getRegionList();
        }
    }

    /* make object empty*/
    private clearData(): void {
        if (this.operationName == ADD || this.operationName == '' || this.operationName == undefined) {
            this.systemEditData = {
                systemId: null,
                name: "",
                linkComment: "",
                systemUrl: "",
                regionId: null,
                regionName: "",
                selectedRegion: ""
            }
        }
        else {
            this.loadComponent = true;
            this.selectedRegionValid = true;
        }

    }

    /*
   * @name: btnCloseclick()
   * @desc: to close slider
   * */
    public btnCloseClick(): void {
        this.isCloseRightSlider = true;
        this.sidebarCloseEvent.emit(true);

          /* on btnCloseClick():- System filed Edit data should not be saved */

        if(this.systemEditData.name =='' || this.systemEditData.name.length === 0 || this.systemEditData.systemUrl =='' || this.systemEditData.systemUrl.length === 0){
            if(this.editSystem){
                this.enterpriseService.getSystemTableRefreshSubject().next(true);
                                             
            }   
        }
        if(this.editSystem){
            if(this.btnCloseClick){
                this.enterpriseService.getSystemTableRefreshSubject().next(true);
            }
                                        
        }  
    
    }

    //used to enable and disable save button
    public ngModelChange(params:any): void {
        this.isSystemInValid = false;
    }

    private valueChange(region):void{
        this.regionselected = region.name;
        this.systemEditData.selectedRegion = region;
        this.systemEditData.regionId = region.regionId;
        this.systemEditData.regionName = region.name;
        this.selectedRegionValid = true;
    }
    /*
    * @name: submitForm()
    * @desc: method to call on save button click
    * */
    public submitForm(): void {
        if (this.operationName == ADD) {
            let systemdetail = new SystemDetail(this.systemEditData);
            this.addSystem(systemdetail.postData());
        }
        else if (this.operationName == EDIT) {
            this.editSystem();
        }
    }

    // api call to add system
    private addSystem(data): void {
        this.enterpriseDataService.addSystem(data).subscribe((respons: any) => {
            this.enterpriseService.getSystemTableRefreshSubject().next(true);
            this.btnCloseClick();
        }, this.onError.bind(this));
    }

    public isNameEmpty(): void{
        if(this.systemEditData.name.length === 0){
            this.errorMessages.isNameEmpty = true;
        }else{
            this.errorMessages.isNameEmpty = false;
        }
    }

    public isUrlEmpty(): void{
        if(this.systemEditData.systemUrl.length === 0){
            this.errorMessages.isUrlEmpty = true;
        }else{
            this.errorMessages.isUrlEmpty = false;
        }
    }

    //api call to edit system
    private editSystem(): void {
        this.enterpriseDataService.editSystem(new SystemDetail(this.systemEditData), this.systemEditData.systemId).subscribe((response: any) => {
            this.enterpriseService.getSystemTableRefreshSubject().next(true);
            this.btnCloseClick();
        }, this.onError.bind(this));
    }


    /*
    * @name: getRegionList()
    * @desc: used to get region list
    * */
    private getRegionList(): void {
        this.enterpriseDataService.getRegionList().subscribe((regionList) => {
             this.regionList = regionList;
             this.regionselected = this.systemEditData.regionName;
            if (this.operationName == ADD || this.operationName == EDIT) {
                this.isRegionListLoaded = true;
                this.loadComponent = true
            }
            else {
                this.isRegionListLoaded = false;
                this.loadComponent = false;
            }
        })
    }
    /*
  * @name: checkforValidUrl()
  * @desc: api call to check entered system url is valid or not
  * */
    public checkforValidUrl(event, url): void {
        event.preventDefault();
        this.enterpriseDataService.checkForValidSystemUrl(url)
            .subscribe(
            (response) => {
                this.showAlert.showSuccessAlert(this.VALID_URL_MSG);
            }, (error) => {
                this.isSystemInValid = true;
                this.onError(error);
            })
    }


    /*
   * @name: onError
   * @desc: used to handle error of api response
   * @param: value=> error code from server
   * */
    private onError(error: any): void {
        this.showAlert.showErrorAlert(error);
        //this.logger.error(this.tag, "onApiError(): error data=", error);
    }

    /*translate locale string*/
    public translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.VALID_URL_MSG = localization.instant("VALID_URL");
        this.regionselected = localization.instant("SELECT_REGION");
    }
}