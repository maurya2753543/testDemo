import { RegionSytemsList, SystemDetail } from '../models/enterprise.model';
import { EnterpriseDataService } from '../enterprise.data.service';
import { Component, ComponentFactoryResolver, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { Grid } from "../../../shared/ag-grid.options";
import { EnterpriseColumnDefinitionService } from "../enterprise.column-definition.service";
import { EnterpriseService } from "../enterprise.service";
import { AddEditSystemComponent } from "./add-edit-system/add-edit-system.component";
import { LocaleDataService } from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import { SweetAlert } from "../../../utilities/sweetAlert"
import { ALERT_WARNING, ADD, EDIT } from "../../../constant/app.constants";
import {ShowAlert} from "../../../utilities/showAlert";
import { CommonStrings } from '../../../constant/common.strings';
import { Logger } from "../../../utilities/logger";

@Component({
    selector: "system-tab",
    templateUrl: "system-tab.component.html"
})
export class SystemTabComponent {

    public loadComponent: boolean = false;
    public systemGrid = new Grid();
    public tableData: RegionSytemsList;
    private systemEditData: SystemDetail;
    public buttonKeys: any;
    private systemList: RegionSytemsList;
    public eventKeys: Array<any>;
    public refreshBtnFlag: boolean = false;
    private totalCount:number = 0;
    private tag: string = "SystemTabComponent::";

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private DELETE_SELECTED_SYSTEM: string;
    private ADD_SYSTEM: string;
    private DELETE_CONFM_MSG: string;
    private DELETE_SYSTEM: string;
    private YES_TEXT: string;
    private NO_TEXT: string;
    public isEdit:boolean = false;
    public operationName = '';
    //@ViewChild('targetAddEditSystem', { read: ViewContainerRef }) _targetAddEditSystem;

    constructor(private enterpriseColumnDefinitionService: EnterpriseColumnDefinitionService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private enterpriseService: EnterpriseService,
        private localeDataService: LocaleDataService,
        private enterpriseDataService: EnterpriseDataService,
        private sweetAlert: SweetAlert,
        private sharedService: SharedService,
        private showAlert: ShowAlert,
        private logger: Logger
    ) {

        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
           this.setEventButtonKeys();
        });
       
    }

    ngOnInit() {
        this.translateLocaleString();
        this.setEventButtonKeys();
        this.showEditSlider();
        this.enterpriseRefreshList();
        if(this.sharedService.RetainFilter){
            this.enterpriseDataService.systemtabfilterchangedata = "";
            this.enterpriseDataService.regionmodeldata = "";
        }
    }

    /*
 * @name: showEditSlider()
 * @desc: callback to get  rowdata for edit and load addedit component onsuccess
 * */
    private showEditSlider(): void {
        this.isEdit = false;
        this.enterpriseService.systemEditComponentCallback.subscribe(response => {
            this.systemEditData = response;
            //this.load(EDIT);
            this.isEdit = true;
            this.operationName = EDIT;
        }, this.onError.bind(this));
    }
    onSideBarClose(event){
        this.isEdit = !event;
    }
    /*
  * @name: enterpriseRefreshList
  * @desc: API call when any of add, edit and delete operation performed
  * */
    private enterpriseRefreshList(): void {
        this.enterpriseService.getSystemTableRefreshSubject().subscribe(() => {
            this.getRegionsSystemList();
        }, this.onError.bind(this));
    }
    public notifyfilterChangeSYSTEMTAB(event): void{
        this.sharedService.RetainFilter = false;
        this.enterpriseDataService.systemtabfilterchangedata = this.systemGrid.api.getFilterModel();
        const countryFilterComponent =  this.systemGrid.api.getFilterInstance('regionName');
        const model = countryFilterComponent.getModel();
        this.enterpriseDataService.regionmodeldata = model;
    }
    /*ag grid button and event*/
    private setEventButtonKeys(): void {
        this.eventKeys = [
            { name: this.DELETE_SELECTED_SYSTEM, status: "only-single", tabType: 'Enterprise' }
        ];
        this.buttonKeys = [
            { name: this.ADD_SYSTEM, tabType: 'Enterprise' },
        ];
        this.refreshBtnFlag = true;
    }

    /*
    * @name: notifyDeleteRegion()
    * @desc: shows confirmation message to delete system
    * */
    private notifyDeleteRegion(systemId): void {
        this.sweetAlert.showConformationAlert(ALERT_WARNING, this.DELETE_SYSTEM, this.DELETE_CONFM_MSG, true, true, this.YES_TEXT, this.NO_TEXT,
            (isConfirm: boolean) => {
                if (isConfirm) {
                    this.deleteSystem(systemId);
                }
            }
        );
    }


    /*
   * @name: notifyGridReadyAlarmConfig
   * @desc: event handler method invoked when ag-grid is ready
   * */
    public regionGridReady(event): void {
        this.showGridLoadingOverly();
        this.systemGrid.api.setColumnDefs(this.enterpriseColumnDefinitionService.getSystemGridColDef());
        this.getRegionsSystemList();
        if(this.systemGrid.api && (this.enterpriseDataService.systemtabfilterchangedata || this.enterpriseDataService.regionmodeldata)){
            this.systemGrid.api.setFilterModel(this.enterpriseDataService.systemtabfilterchangedata);            
            if(this.enterpriseDataService.regionmodeldata || this.enterpriseDataService.systemtabfilterchangedata){
                const countryFilterComponent3 =  this.systemGrid.api.getFilterInstance("regionName");
                countryFilterComponent3.setModel(this.enterpriseDataService.regionmodeldata);
            }
    }

}
    //refresh grid datanotifyRefreshGrid
    public notifyRefreshGrid($event): void {
        this.getRegionsSystemList();
    }
    /*
     * @name: load()
     * @desc: to load add edit component dynamically
     * */
    // private load(btnName: string): void {
    //     this._targetAddEditSystem.clear();
    //     const factory = this.componentFactoryResolver.resolveComponentFactory(AddEditSystemComponent);
    //     let _targetAddEditSystem = this._targetAddEditSystem.createComponent(factory);

    //     _targetAddEditSystem.instance.childData.editData= this.systemEditData;
    //     _targetAddEditSystem.instance.childData.operationName= btnName;
    
    //     console.log(" _targetAddEditRegion.instance.childData.editData", _targetAddEditSystem.instance.childData.editData);
    //     console.log(" _targetAddEditRegion.instance.childData.operationName", _targetAddEditSystem.instance.childData.operationName);
       

    //     // _targetAddEditSystem._component.systemEditData = this.systemEditData;
    //     // _targetAddEditSystem._component.operationName = btnName;
    // }

    /*
    * @name: notifyActionEmitter()
    * @desc: used to specify method for ag-grid button
    * */
    public notifyActionEmitter($event): void {
        if ($event.event.name == this.ADD_SYSTEM) {
            //this.load(ADD);
            this.isEdit = true;
            this.operationName = ADD;
        }
        if ($event.event.name == this.DELETE_SELECTED_SYSTEM) {
            this.notifyDeleteRegion($event.selectedData[0].systemId);
        }
    }

    /*
    * @name: getRegionsSystemList()
    * @desc: used to get system
    * */
    private getRegionsSystemList(): void {
        this.enterpriseDataService.getRegionDetails().subscribe((systemList) => {
            this.tableData = systemList;
            this.totalCount = this.tableData.length
            this.setShowAllLabel(this.tableData.length, this.totalCount);
        }, this.onError.bind(this));
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.systemGrid.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    /*
    * @name: deleteSystem()
    * @desc: api call to delete selected system
    * */
    private deleteSystem(systemId): void {
        this.enterpriseDataService.deleteSystem(systemId).subscribe((response) => {
            this.getRegionsSystemList();
        }, this.onError.bind(this));
    }

    /*
   * @name: onError
   * @desc: used to handle error of api response
   * @param: value=> error code from server
   * */
    private onError(error): void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.systemGrid.api.showLoadingOverlay();
    }

    public onTabSwitch(): void{
        this.getRegionsSystemList();
    }

    /*translate locale string*/
    private translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.DELETE_SELECTED_SYSTEM = localization.instant("DELETE_SELECTED");
        this.ADD_SYSTEM = localization.instant("ADD_SYSTEM");
        this.DELETE_CONFM_MSG = localization.instant("DELETE_SYSTEM_CONFIRMATION");
        this.DELETE_SYSTEM = localization.instant("DELETE_SYSTEM");
        this.TABLE_LIST_SHOWING = localization.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localization.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localization.instant('TABLE_LIST_ROWS');
        this.YES_TEXT = localization.instant('YES');
        this.NO_TEXT =  localization.instant('NO');
    }
}