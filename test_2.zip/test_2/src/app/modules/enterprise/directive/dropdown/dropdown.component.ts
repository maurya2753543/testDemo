
import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {EnterpriseDataService} from "../../enterprise.data.service";

@Component({
    selector: 'cust-enterprise-dropdown',
    templateUrl : 'dropdown.component.html'
})
export class DropdownComponent  implements OnInit{
    itemList: any;
    selectedVal: string;
    defaultSelectedVal: string;
    isLoaded: boolean = false;
    variable: string = "";

    @Input() optionObject: any;
    @Input() label: string;
    @Output() getValue = new EventEmitter();

    constructor(private enterpriseDataService:EnterpriseDataService) {

    }

    ngOnInit() {
        if (this.optionObject) {
        
            let list: any = [];
            for (let i = 0; i < this.optionObject.options.serverOptions.length; i++) {
                let key = this.optionObject.options.serverOptions[i]?this.optionObject.options.serverOptions[i].trim():'';
                let value = this.optionObject.options.displayOptions[i]?this.optionObject.options.displayOptions[i].trim():'';
                list.push({
                    'key': key,
                    'value': value
                });
                if(key.toLowerCase() == this.optionObject.value.trim().toLowerCase()) {
                    this.variable = key;
                    this.selectedVal= value;
                }
            }
            if (list.length > 0) {
                this.itemList = list;
            }
           
            this.defaultSelectedVal = this.optionObject.value;
            //this.variable = this.defaultSelectedVal;
            this.isLoaded = true;
        }
        this.revertValueSubscribe();
    }

    /*
     * @name: ngModelChange
     * @desc: event method invoked on text_changes event of textbox
     * */
    private ngModelChange($evt): void {
        this.optionObject.setValue($evt.target.value);
        this.getValue.emit($evt.target.value);
        this.selectedVal = $evt.target.innerText;
        this.enterpriseDataService.disableSave();
    }

    /*
     * @name: revertValueSubscribe
     * @desc: used to subscribe revertValue subject invoked when click on cancel button
     * */
    private revertValueSubscribe(): void{
        this.enterpriseDataService.revertValue.subscribe((value) => {
            if(value){
                for (let i = 0; i < this.optionObject.options.serverOptions.length; i++) {
                    let key = this.optionObject.options.serverOptions[i]?this.optionObject.options.serverOptions[i].trim():'';
                    let valuePair = this.optionObject.options.displayOptions[i]?this.optionObject.options.displayOptions[i].trim():'';
                    if(key.toLowerCase() == this.optionObject.value.trim().toLowerCase()) {
                        this.selectedVal = valuePair;
                    }
                }
            }
        });
    }

}
