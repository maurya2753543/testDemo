/**
 * Created by B.Kasturiwale on 09-06-2017.
 */
import {Directive, ElementRef, Input, Renderer2} from '@angular/core';


@Directive({
    selector: '[dropdownDirective]'
})
export class DropdownDirective {
    @Input() dropdownDirective:string;

    constructor(private element: ElementRef, private renderer: Renderer2) {

    }

    ngOnChanges(changes) {
        console.log("Changes in Directive ", changes);
        
    }
}