import {EnterpriseSettings} from "../../models/settings.model";
//import {DECIMAL, COMMA} from "./number-input.component";
/**
 * Created by B.Kasturiwale on 30-06-2017.
 */
export const COMMA : string  = ",";
export const DECIMAL : string = ".";
export class NumberInputModel {

    public title : string ;

    public value : string = "";

    public defaultValue : string = "";
    public units : string ;
    public rangeStart : string;
    public rangeStop : string;
    public resolution : string;
    public rangeType : boolean;

    public name : string = "";

    public isFloatValue : boolean = false;

    protected serverValue : string = "";

    //public valueFloat : number;
    private serverValueFloat : number;
    private defaultValueFloat : number;
    public rangeStartFloat : number;
    public rangeStopFloat : number;
    private resolutionFloat : number;


    public inputLength : number = 0;


    constructor(settings : EnterpriseSettings){

        this.title = settings.name;

        this.value = settings.getValue();
        this.serverValue = settings.getServerValue();
        this.defaultValue = settings.defaultValue;
        this.rangeStart = settings.rangeStart;
        this.rangeStop = settings.rangeStop;
        this.resolution = settings.resolution;
        this.rangeType = settings.rangeType;

        this.units = settings.units;
        this.isFloatValue = settings.isFloatValue;

        this.initValue();
        this.calculateInputLength();
       
    }

    /**
     * Initialize value as float or int depending upon the resolution
     */
    private initValue() : void {

        if(this.isFloatValue){
            //this.valueFloat = this.getFloatValue(this.value);
            this.serverValueFloat = this.getFloatValue(this.serverValue);
            this.defaultValueFloat = this.getFloatValue(this.defaultValue);
            this.rangeStartFloat = this.getFloatValue(this.rangeStart);
            this.rangeStopFloat = this.getFloatValue(this.rangeStop);
            this.resolutionFloat = this.getFloatValue(this.resolution);
        }else{
            //this.valueFloat = this.getIntValue(this.value);
            this.serverValueFloat = this.getIntValue(this.serverValue);
            this.defaultValueFloat = this.getIntValue(this.defaultValue);
            this.rangeStartFloat = this.getIntValue(this.rangeStart);
            this.rangeStopFloat = this.getIntValue(this.rangeStop);
            this.resolutionFloat = this.getIntValue(this.resolution);
        }


    }

    private getFloatValue(value : string) : number {
        return parseFloat(value);
    }

    private getIntValue(value : string) : number {
        return parseInt(value);
    }

    /**
     * Calculate the length for the number of characters which user can enter
     */
    private calculateInputLength() : void {

        if(this.isFloatValue){
            if(this.rangeStop && this.rangeStop.indexOf(DECIMAL) > -1 ){
                this.inputLength = this.rangeStop.length;
            }else{
                this.inputLength = this.rangeStop.length + 2;
            }

        }else{
            this.inputLength = this.rangeStop.length;
        }

        //Handle Negative values
        if(this.rangeStartFloat < 0){
            this.inputLength++;
        }
    }

    public updateValue(isCommaRequired : boolean ) : void {
        if(isCommaRequired){
            if(this.value.indexOf(DECIMAL) > -1){
                this.value = this.value.replace(DECIMAL , COMMA);
            }
        }
    }

    /**
     * This method checks whether the entered value is valid or not
     * @param value : entered value
     * @param character : supported character whether decimal or comma
     * @returns {boolean}
     */
    public hasInvalidChar(value : string  , character : string) : boolean {
        let isInvalid : boolean = false;

        if(value){
            isInvalid = value.split(character).length > 2;
        }

        if(!isInvalid){
            let otherCharacter = DECIMAL;
            if(character == COMMA){
                otherCharacter = DECIMAL;
            }else{
                otherCharacter = COMMA;
            }
            isInvalid = value.split(otherCharacter).length > 2;
        }

        if(!isInvalid){
            let index = value.indexOf(DECIMAL);
            if(value.length-1 == index){
                isInvalid = true;
            }
        }

        if(!isInvalid){
            let index = value.indexOf(COMMA);
            if(value.length-1 == index){
                isInvalid = true;
            }
        }
        
        if(!isInvalid){
            isInvalid = value.split("-").length > 2;
        }

        if(!isInvalid){
            isInvalid = value.split("+").length > 2;
        }

        if(!isInvalid){
            isInvalid = value.indexOf("-") > 0;
        }

        if(!isInvalid){
            isInvalid = value.indexOf("+") > 0;
        }

        if(!isInvalid){
            isInvalid = value.indexOf(",.") > 0;
        }

        if(!isInvalid){
            isInvalid = value.indexOf(".,") > 0;
        }

        if(!isInvalid){
            if(value.indexOf(DECIMAL) > 0 && value.indexOf(COMMA) > 0){
                isInvalid = true;
            }
        }
        return isInvalid;
    }
    

    public isInt(n) : boolean{
        return n % 1 === 0;
    }

    private isFloat(n) : boolean {
        return n % 1 !== 0;
    }

     public setDefaultValue() : void {
        this.value = this.defaultValue;
    }

    public resetValue() : void {
        this.value = this.serverValue;
    }

    public setValue(valueF) : void {
        this.value = valueF;
    }

    public getValue() : string{
        return this.value;
    }

    public getDefaultValue() : number{
        return this.defaultValueFloat;
    }
    
    public getServerValue() : number{
        return this.serverValueFloat;
    }

    public updateValueAfterSaved() : void {
        this.serverValue = this.value;
    }
    
    public getRangeStart() : number{
        return this.rangeStartFloat;
    }

    public getRangeStop() : number{
        return this.rangeStopFloat;
    }

    public getResolution() : number{
        return this.resolutionFloat;
    }
}