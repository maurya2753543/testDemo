/**
 * Created by B.Kasturiwale on 09-06-2017.
 */
import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {EnterpriseDataService} from "../../enterprise.data.service";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {NumberInputModel} from "./number-input.model";
import {WindowService} from "../../../../shared/nativeProvider/window.service";
import { SharedService } from "src/app/shared/shared.service";
import { parse } from "querystring";


export const COMMA : string  = ",";
export const DECIMAL : string = ".";

@Component({
    selector: 'number-input',
    templateUrl : 'number-input.component.html'
})
export class NumberInputComponent  implements OnInit{
    private unitsData;
    private inputunits;

    public numberInputModel : NumberInputModel;
    public language : string ;
    private title : string;
    private errorMsg:string = 'REQUIRED_FIELD';

    public isValid : boolean = true;
    public islessThanRange : boolean = false;
    public isgreaterThanRange : boolean = false;
    private isInvalid: boolean = false;
    private isCommaRequired : boolean = false;
    private is10multipleInvalid :boolean = false;
    //private isFrequencyInvalid : boolean = false;
    private isDefaultPressed : boolean = false;

    private value32qam:string;
    private value16qam:string;
    private valueqpsk:string;
    private gdIbCalc:string;

    @Input() optionObject:any;
    @Input() label:string;
    @Input() btnText:string;
    @Input() desc:string;
    @Input() localizedDesc:string;
    @Input() calc32:boolean;
    @Input() inbandCalc:boolean;
    @Input() gdCalc:boolean;

    @Output() getValue = new EventEmitter();

    constructor(private localeDataService : LocaleDataService,
        private enterpriseDataService: EnterpriseDataService,
        private sharedService:SharedService,
        ) {
    }

    ngOnInit(){
        this.numberInputModel = new NumberInputModel(this.optionObject);
        // this.language = this.languageService.getCurrentLanguage();
        this.isCommaRequired = this.sharedService.isCommaRequiredCheck();
        if(this.isCommaRequired){
            this.numberInputModel.updateValue(true);
        }
        this.setTitleforInput();
        this.revertValueSubscribe();
        this.savedValueSubscribe();
        this.enterpriseDataService.setNumberInputComponent(this.optionObject.name , this);

        this.unitsData = new Object(this.numberInputModel.units);
        this.inputunits = new Object((this.numberInputModel.units) ? (this.numberInputModel.units == "percent" || this.numberInputModel.units == "percentage" ? " %" : ""+ this.unitsData) : "");
    }


    /*
     * @name: ngModelChange
     * @desc: event method invoked on text_changes event of textbox
     * */
    public ngModelChange($evt) {
        this.errorMsg = 'REQUIRED_FIELD';
        this.isDefaultPressed = false;
        this.updateValue($evt);
        this.numberInputModel.value = "" + this.numberInputModel.getValue();
        this.optionObject.isModified = ($evt == this.numberInputModel.getServerValue()) ? this.optionObject.isModified : true;
        this.enterpriseDataService.disableSave();
        this.getValue.emit(this);

    }

    private setRangeInvalid(isInvalid : boolean ) : void {
            this.optionObject.isValid = this.isValid = !isInvalid;
            this.errorMsg = isInvalid ? "ENTERPRISE_SETTING_ERRORMSG" : this.errorMsg;
            this.enterpriseDataService.disableSave();

    }

    public updateValue($evt) : void {
        if($evt == null || $evt == undefined){
            this.optionObject.isValid = this.isValid = false;
        }else{
            let enteredValue : string = $evt;
            let character : string = DECIMAL;
            if(this.isCommaRequired){
                character = COMMA;
            }
            if(this.numberInputModel.hasInvalidChar(enteredValue, character)){
                this.isInvalid = true;
                this.optionObject.isValid = this.isValid = false;
                this.errorMsg = 'REQUIRED_INVALID_VALUE';
            }else{
                let floatValue : number = this.getFloatValue(enteredValue);
                if(this.isInputValid(floatValue)){
                    this.setValue(floatValue);
                    this.optionObject.isValid = this.isValid = true;
                }else{
                    this.optionObject.isValid = this.isValid = false;
                }
            }
        }
        this.enterpriseDataService.disableSave();
    }

    private setValue(floatValue : number ) : void {
        this.optionObject.setValue(floatValue);
        this.optionObject.isValid = this.isValid = true;

    }

    private getFloatValue(enteredValue : string ){
        let floatValue : number = 0;
        if(enteredValue.indexOf(COMMA) > 0){
            enteredValue = enteredValue.replace(COMMA , DECIMAL);
        }
        floatValue = parseFloat(enteredValue);
        return floatValue;
    }

    /**
     * Called when user press default key
     */
    public setDefaultValue(e) : void {
        e.preventDefault();
        this.optionObject.isModified = (this.numberInputModel.getDefaultValue() == this.numberInputModel.getServerValue()) ? this.optionObject.isModified : true;
        this.numberInputModel.setDefaultValue();
        this.setValue(this.numberInputModel.getDefaultValue());
        this.focusOut();
        this.enterpriseDataService.disableSave();
        this.isDefaultPressed = true;
        this.getValue.emit(this);
    }


    /**
     * Called when user press cancel key
     */
    private revertValueSubscribe(){
        this.enterpriseDataService.revertValue.subscribe((value) => {
            this.isDefaultPressed = false;
            this.numberInputModel.resetValue();
            this.focusOut();
            this.optionObject.isValid = this.isValid = true;

            this.getValue.emit(this);
        });
    }


    private savedValueSubscribe(){
        this.enterpriseDataService.settingSaved.subscribe((value) => {
            this.isDefaultPressed = false;
            this.numberInputModel.updateValueAfterSaved();
            this.focusOut();
            this.optionObject.isValid = this.isValid = true;
        });
    }


    private setTitleforInput(){

        let localization = this.localeDataService.getLocalizationService();
        let SS_NUMBER_INPUT_TITLE_1 = localization.instant('SS_NUMBER_INPUT_TITLE_1');
        let SS_NUMBER_INPUT_TITLE_2 = localization.instant('SS_NUMBER_INPUT_TITLE_2');
        this.numberInputModel.title = SS_NUMBER_INPUT_TITLE_1 + this.numberInputModel.getRangeStart() + SS_NUMBER_INPUT_TITLE_2 + this.numberInputModel.getRangeStop() + DECIMAL;

        // '1.0-0' NON Float Number parsing
        if(parseInt(this.numberInputModel.rangeStart)!= NaN )
        this.numberInputModel.rangeStart = (this.numberInputModel.isFloatValue) ?
        this.sharedService.toDecimal( parseFloat(this.numberInputModel.rangeStart),  '1.1-2') :
        this.sharedService.toDecimal( parseInt(this.numberInputModel.rangeStart),  '1.0-0') ;

        // '1.0-0' NON Float Number parsing
        if(parseInt(this.numberInputModel.rangeStop)!= NaN )
        this.numberInputModel.rangeStop = (this.numberInputModel.isFloatValue) ?
        this.sharedService.toDecimal( parseFloat(this.numberInputModel.rangeStop),  '1.1-2') :
        this.sharedService.toDecimal( parseInt(this.numberInputModel.rangeStop),  '1.0-0') ;


        // if(this.numberInputModel.isFloatValue){
        //     this.numberInputModel.rangeStart = this.sharedService.toDecimal( parseInt(this.numberInputModel.rangeStart),  '1.1-2');
        //   if(parseInt(this.numberInputModel.rangeStop)!= NaN)
        //     this.numberInputModel.rangeStop = this.sharedService.toDecimal( parseInt(this.numberInputModel.rangeStop),  '1.1-2');
        // }else{
        //   if(parseInt(this.numberInputModel.rangeStop)!= NaN)

        //     this.numberInputModel.rangeStart = this.localeDecimalPipe.transform(this.numberInputModel.rangeStart, this.language);
        //     this.numberInputModel.rangeStop = this.localeDecimalPipe.transform(this.numberInputModel.rangeStop, this.language);
        // }

    }

    /**
     * This method checks whether the entered value is within range or not
     * @param value
     * @returns {boolean}
     */
    private isInputValid(value : number) : boolean {
        let isValid : boolean = false;
        let rangeStartFloat : number = this.numberInputModel.getRangeStart();
        let rangeStopFloat : number = this.numberInputModel.getRangeStop();
        if( rangeStartFloat <= value && value <= rangeStopFloat ){
            this.isgreaterThanRange = this.islessThanRange = false;
            isValid = true;
        }else{
                if (value < rangeStartFloat) {
                    this.isgreaterThanRange = false;
                    this.islessThanRange = true;
                    this.errorMsg = 'REQUIRED_SMALL_RANGE_FIELD';
                } else if (value > rangeStopFloat) {
                    this.islessThanRange = false;
                    this.isgreaterThanRange = true;
                    this.errorMsg = 'REQUIRED_LARGE_RANGE_FIELD';
                }

            return false;
        }

        if(!this.numberInputModel.isFloatValue) {
            isValid = this.numberInputModel.isInt(value);
            if(value % this.numberInputModel.getResolution() == 0){
                isValid = true;
                this.isInvalid = false;
                this.is10multipleInvalid = false;
            } else {
                isValid = false;
                if(this.numberInputModel.getResolution() == 10){
                    this.isInvalid = false;
                    this.is10multipleInvalid = true;
                    this.errorMsg = 'REQUIRED_MULTIPLE_10';
                }else{
                    this.isInvalid = true;
                    this.is10multipleInvalid = false;
                    this.errorMsg = 'REQUIRED_INVALID_VALUE';
                }
                this.isgreaterThanRange = this.islessThanRange = false;
                }
            }
        return isValid;
    }

    /**
     * This method is called when focus moves out of that field
     */
    public focusOut(){
        let value;
        value = this.numberInputModel.value;

        if(this.isCommaRequired){
            if(value.indexOf(DECIMAL) > -1){
                value = value.replace(DECIMAL , COMMA);
            }
        }else {
            if(value.indexOf(COMMA) > -1){
                value = value.replace(COMMA , DECIMAL);
            }
        }
        this.numberInputModel.value = value;
    }
}
