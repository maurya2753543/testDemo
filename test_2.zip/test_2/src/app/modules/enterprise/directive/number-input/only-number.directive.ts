import {Directive, ElementRef, Input} from "@angular/core";

@Directive({
  selector: '[OnlyNumber]',
  host: {
    '(ngModelChange)': 'onInputChange($event)',
    '(input)': 'onInputChange($event.target.value)'
 }
})
export class OnlyNumber {

  constructor(private el: ElementRef) { }

  @Input() OnlyNumber: boolean;
  @Input() obj: any;

  onInputChange(val){
    if (val) {
        this.el.nativeElement.value = val.replace(/[^0-9.,-]*/g, '');
      this.obj.value = val.replace(/[^0-9.,-]*/g, '');
    }
  }
}