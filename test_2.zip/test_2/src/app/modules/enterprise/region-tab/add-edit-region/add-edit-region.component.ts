import { Region } from '../../models/enterprise.model';
import { ADD, EDIT } from "../../../../constant/app.constants";
import { Component, Input, Output,  EventEmitter, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { EnterpriseDataService } from "../../enterprise.data.service";
import { Observable, Subject, throwError } from "rxjs";
import { EnterpriseService } from "../../enterprise.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import { Logger } from "../../../../utilities/logger";
import { ɵBrowserDomAdapter} from "@angular/platform-browser";
import { map, catchError } from 'rxjs/operators';
@Component({
    selector: 'add-edit-region',
    templateUrl: 'add-edit-region.component.html'
})

export class AddEditRegionComponent {

    public loadComponent: boolean;
    
    private regionTableRefreshSubject: Subject<any>;
    private tag: string = "AddEditRegionComponent::";
    public isCloseRightSlider: boolean = false;
    private dom:any = ɵBrowserDomAdapter ;
    public errorMessages: any = {
        "isRegionEmpty": false
    };
    @Input() operationName : string;
    @Input() editData : any;
    @Output() sidebarCloseEvent = new EventEmitter<boolean>();

    constructor(private enterpriseDataService: EnterpriseDataService,
        private enterpriseService: EnterpriseService,
        private showAlert: ShowAlert,
        private logger: Logger
    ) { }

    ngOnInit() {
        this.regionTableRefreshSubject = this.enterpriseService.getRegionTableRefreshSubject();
        this.clearData();
    }

    /* make object empty*/
    private clearData(): void {
        if (this.operationName == ADD || this.operationName == '' || this.operationName == undefined) {
            this.editData = {
                regionId: "",
                name: "",
                numberOfSystems: ""
            };
        }
    }

    public isRegionEmpty(): void{
        if(this.editData.name.length === 0){
            this.errorMessages.isRegionEmpty = true;
        }else{
            this.errorMessages.isRegionEmpty = false;
        }
    }

    //api call to add region
    private addRegion(): void {
        this.enterpriseDataService.addRegion(new Region(this.editData)).subscribe(() => {
            this.btnCloseClick();
            this.regionTableRefreshSubject.next(true);
        }, this.onError.bind(this))
    }

    //api call to edit region
    private editRegion(): void {
        this.enterpriseDataService.editRegion(new Region(this.editData), this.editData.regionId)
            .subscribe(() => {
                this.btnCloseClick();
                this.regionTableRefreshSubject.next(true);
            },catchError(this.handleError));
    }

    public handleError(error) {
        return throwError(error);
    }

    /*
      * @name: btnCloseClick()
      * @desc: to close slider
      * */
    public btnCloseClick(): void {
        this.isCloseRightSlider = true;
        this.sidebarCloseEvent.emit(true);

            
        /* on btnCloseClick():- region filed Edit data should not be saved */
        if(this.editData.name =='' || this.editData.name.length === 0){
            if(this.editRegion){
                this.regionTableRefreshSubject.next(true);
            }    
        
        }
        if(this.editRegion){
            if(this.btnCloseClick){
                this.regionTableRefreshSubject.next(true);
            }
                                        
        }  

    }
    /*
     * @name: submitForm()
     * @desc: method to call on save button click
     * */
    public submitForm(): void {
        if (this.operationName == ADD) {
            this.addRegion();
        }
        else if (this.operationName == EDIT) {
            this.editRegion();
        }
    }
    /*
   * @name: onError
   * @desc: used to handle error of api response
   * @param: value=> error code from server
   * */
    private onError(error): void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }
}