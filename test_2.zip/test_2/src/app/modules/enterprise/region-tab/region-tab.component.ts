
import { Region, RegionList } from '../models/enterprise.model';
import { Component, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
//import { Locale, LocaleService, LocalizationService } from 'angular2localization';
import { LocaleDataService } from "../../../shared/locale.data.service";
import { Grid } from "../../../shared/ag-grid.options";
import { EnterpriseColumnDefinitionService } from "../enterprise.column-definition.service";
import { EnterpriseService } from "../enterprise.service";
import {SharedService} from "../../../shared/shared.service";
import { AddEditRegionComponent } from "./add-edit-region/add-edit-region.component";
import { EnterpriseDataService } from "../enterprise.data.service";
import { SweetAlert } from "../../../utilities/sweetAlert"
import { ALERT_WARNING, ADD, EDIT } from "../../../constant/app.constants";
import {ShowAlert} from "../../../utilities/showAlert";
import { Logger } from "../../../utilities/logger";
import { CommonStrings } from '../../../constant/common.strings';


@Component({
    selector: 'region-tab',
    templateUrl: 'region-tab.component.html'
})

export class RegionTabComponent {

    public loadComponent: boolean = false;
    public regionGrid = new Grid();
    public tableData: RegionList;
    private editData: Region;
    public buttonKeys: any;
    private regionList: RegionList;
    private oldSelectedSettings: Object = {};
    public refreshBtnFlag: boolean = false;
    public eventKeys: any;
    private tag: string = "RegionTabComponent::"
    private DELETE_SELECTED: string;
    private ADD_REGION: string;
    private DELETE_CONF_MSG: string;
    private DELETE_CONF_HEADER: string;
    private DELETE_REGION: string;

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private TABLE_LIST_SHOWING:string = '';
    private TABLE_LIST_SHOWING_OF:string = '';
    private TABLE_LIST_ROWS:string = "";
    private totalCount:number = 0;
    public isEdit:boolean = false;
    private YESbtn: string = '';
    private NObtn:  string = '';
    private operationName = '';

    @ViewChild('targetAddEditRegion', { read: ViewContainerRef }) _targetAddEditRegion;

    constructor(private enterpriseService: EnterpriseService,
        private enterpriseDataService: EnterpriseDataService,
        private enterpriseColumnDefinitionService: EnterpriseColumnDefinitionService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private viewContainerRef: ViewContainerRef,
        private sharedService: SharedService,
        private localeDataService: LocaleDataService,
        private sweetAlert: SweetAlert,
        private showAlert: ShowAlert,
        private logger: Logger
    ) {
        this.localeDataService.componentCallback.subscribe((response) => {
            this.translateLocaleString();
           this.setEventButtonKeys();
        });
    }
    ngOnInit() {
        
        this.translateLocaleString(); 
        this.setEventButtonKeys();
        this.showEditSlider();
        this.enterpriseRefreshList();
        if(this.sharedService.RetainFilter){
            this.enterpriseDataService.regiontabfilterchangedata = "";
            this.enterpriseDataService.regionmodeldata = "";
        }
        
    }

    onSideBarClose(event){
        this.isEdit = !event;
    }

    /*ag grid button and event*/
    private setEventButtonKeys(): void {
        this.refreshBtnFlag = true;
        this.eventKeys = [
            { name: this.DELETE_SELECTED, status: "only-single", tabType: 'enterprise' }
        ];
        this.buttonKeys = [
            { name: this.ADD_REGION, tabType: 'Enterprise' },
        ];
    }
    /*
     * @name: getRegionList()
     * @desc: API call for getting regions
     * */
    private getRegionList(): void {
        this.enterpriseDataService.getRegionList()
            .subscribe(this.onRegionListNext.bind(this), this.onError.bind(this));
    }
    public notifyfilterChangeREGION(event): void{
        this.sharedService.RetainFilter = false;
        this.enterpriseDataService.regiontabfilterchangedata = this.regionGrid.api.getFilterModel();
        const countryFilterComponent = this.regionGrid.api.getFilterInstance('name');
        const model = countryFilterComponent.getModel();
        this.enterpriseDataService.regionmodeldata = model;
    }
    private onRegionListNext(regionList): void {
        this.tableData = regionList;
        this.loadComponent = true;
        this.totalCount = this.tableData.length;
        this.setShowAllLabel(this.tableData.length, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //updates row message.
    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.regionGrid.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }
    /*
     * @name: deleteRegion()
     * @desc: API call to delete selected region
     * */
    private deleteRegion(regionId): void {
        this.enterpriseDataService.deleteRegion(regionId).subscribe((response) => {
            this.getRegionList();
        }, this.onError.bind(this))
    }

    //Show ag-Grid overlay
    private showGridLoadingOverly(): void {
        this.regionGrid.api.showLoadingOverlay();
    }

    /*
     * @name: notifyGridReadyAlarmConfig
     * @desc: event handler method invoked when ag-grid is ready
     * */
    public regionGridReady(event): void {
        this.showGridLoadingOverly();
        this.regionGrid.api.setColumnDefs(this.enterpriseColumnDefinitionService.getRegionGridColDef());
        this.getRegionList();
        if(this.regionGrid.api && (this.enterpriseDataService.regiontabfilterchangedata || this.enterpriseDataService.regionmodeldata)){
            this.regionGrid.api.setFilterModel(this.enterpriseDataService.regiontabfilterchangedata);            
            if(this.enterpriseDataService.regionmodeldata ||this.enterpriseDataService.regiontabfilterchangedata ){
                const countryFilterComponent3 =  this.regionGrid.api.getFilterInstance("name");
                countryFilterComponent3.setModel(this.enterpriseDataService.regionmodeldata);
            }
        }
    }

    /*
  * @name: enterpriseRefreshList
  * @desc: API call when any of add, edit and delete operation performed
  * */
    private enterpriseRefreshList(): void {
        this.enterpriseService.getRegionTableRefreshSubject().subscribe(() => {
            this.getRegionList();
        }, this.onError.bind(this));
    }

    /*
 * @name: showEditSlider()
 * @desc: callback to get  rowdata for edit and load addedit component onsuccess
 * */
    private showEditSlider(): void {
        this.isEdit = false;
        this.enterpriseService.regionEditComponentCallback.subscribe((response) => {
            this.editData = response;
            if (this.editData) {
                //this.load(EDIT);
                this.isEdit = true;
                this.operationName = EDIT;
            }
        }, this.onError.bind(this))
    }
    
    public onTabSwitch(): void{
        this.getRegionList();
    }

    // /*
    // * @name: getRegionList()
    // * @desc: API call for getting regions
    // * */
    // private load(btnName: string): void {
    //     console.log("load region=====",btnName,this.editData);
        
    //     this._targetAddEditRegion.clear();
    //     const factory = this.componentFactoryResolver.resolveComponentFactory(AddEditRegionComponent);
    //     let _targetAddEditRegion = this._targetAddEditRegion.createComponent(factory);
    //    // _targetAddEditRegion.instance.childData = this.editData;
    //     console.log(" _targetAddEditRegion.instance.childData ", _targetAddEditRegion.instance.childData );
    //     _targetAddEditRegion.instance.childData.editData= this.editData;
    //     _targetAddEditRegion.instance.childData.operationName= btnName;
    
    //     console.log(" _targetAddEditRegion.instance.childData.editData", _targetAddEditRegion.instance.childData.editData);
    //     console.log(" _targetAddEditRegion.instance.childData.operationName", _targetAddEditRegion.instance.childData.operationName);
        
    //     // _targetAddEditRegion._component.editData = this.editData;
    //     // _targetAddEditRegion._component.operationName = btnName;
    // }

    /*
     * @name: notifyActionEmitter()
     * @desc: handles all ag-grid events
     * */
    public notifyActionEmitter($event): void {
        if ($event.event.name == this.ADD_REGION) {
            //this.load(ADD);
            this.isEdit = true;
            this.operationName = ADD;
        }
        if ($event.event.name == this.DELETE_SELECTED) {
            this.notifyDeleteRegion($event.selectedData[0].regionId);
        }
        this.refreshBtnFlag = true;
    }

    /*
     * @name: notifyDeleteRegion()
     * @desc: shows confirmation message to delete rigion
     * */
    private notifyDeleteRegion(regionId): void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.sweetAlert.showConformationAlert(ALERT_WARNING, this.DELETE_REGION, this.DELETE_CONF_MSG, true, true, this.YESbtn, this.NObtn,
            (isConfirm: boolean) => {
                if (isConfirm) {
                    this.deleteRegion(regionId);
                }
            }
        );
    }

    //refresh grid datanotifyRefreshGrid
    public notifyRefreshGrid($event): void {
        this.getRegionList();
    }

    /*
    * @name: onError
    * @desc: used to handle error of api response
    * @param: value=> error code from server
    * */
    private onError(error: any): void {
        this.logger.error(this.tag, "onApiError(): error data=", error);
        this.showAlert.showErrorAlert(error);
    }
    
    // translate locale string
    private translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.DELETE_SELECTED = localization.instant("DELETE_SELECTED");
        this.ADD_REGION = localization.instant("ADD_REGION");
        this.DELETE_CONF_MSG = localization.instant("DELETE_REGION_CONFIRMATION")
        this.DELETE_REGION = localization.instant("DELETE_REGION");

        this.TABLE_LIST_SHOWING = localization.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localization.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localization.instant('TABLE_LIST_ROWS');
        this.YESbtn = localization.instant('YES');
        this.NObtn =  localization.instant('NO');
    }
}