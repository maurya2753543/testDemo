import { Subject } from 'rxjs';
import { Injectable } from "@angular/core";
import { LocaleDataService } from "../../shared/locale.data.service";

@Injectable()
export class EnterpriseService {

    public regionEditComponentCallback: Subject<any>;
    public systemEditComponentCallback: Subject<any>;
    private regionTableRefreshSubject: Subject<any>;
    private systemTableRefreshSubject: Subject<any>;
    constructor(){
        this.initSubjects();
    }
    
    private initSubjects(){
        this.regionTableRefreshSubject = new Subject();
        this.regionEditComponentCallback = new Subject<any>();
        this.systemEditComponentCallback = new Subject<any>();
        this.systemTableRefreshSubject= new Subject<any>();
    }
    public showEditSlider(selectedRowData){
        this.regionEditComponentCallback.next(selectedRowData);
    }

    public showSystemEditSlider(selectedRowData){
        this.systemEditComponentCallback.next(selectedRowData);
    }
       
    public getRegionTableRefreshSubject(): Subject<any>{
        return this.regionTableRefreshSubject;
    }
    public getSystemTableRefreshSubject(): Subject<any>{
        return this.systemTableRefreshSubject
    }
    
}
