import { Injectable } from "@angular/core";
import {HttpService} from "../../shared/http.service";
import { EnterpriseUrlService } from "./enterprise.url.service";
import { Observable } from "rxjs";

@Injectable()
export class EnterpriseHttpService {

    constructor(private httpService: HttpService, private enterpriseUrlService: EnterpriseUrlService) { }

    public getRegionList(): Observable<any> {
        return this.httpService.GET(this.enterpriseUrlService.getRegionListUrl());
    }
    public getRegionDetails(): Observable<any> {
        return this.httpService.GET(this.enterpriseUrlService.getRegionDetails());
    }
    public addRegion(data: Object): Observable<any> {
        return this.httpService.POST(this.enterpriseUrlService.addRegionUrl(), data);
    }
    public editRegion(data: Object, regionId: number): Observable<any> {
        return this.httpService.PUT(this.enterpriseUrlService.editRegionUrl(regionId), data);
    }
    public deleteRegion(regionId): Observable<any> {
        return this.httpService.DELETE(this.enterpriseUrlService.deleteRegionUrl(regionId));
    }
    public addSystem(data: Object): Observable<any> {
        return this.httpService.POST(this.enterpriseUrlService.addSystemUrl(), data);
    }
    public editSystem(data: Object, systemId: number): Observable<any> {
        return this.httpService.PUT(this.enterpriseUrlService.editSystemUrl(systemId), data)
    }
    public deleteSystem(systemId: number): Observable<any> {
        return this.httpService.DELETE(this.enterpriseUrlService.deleteSystemUrl(systemId));
    }
    public checkForValidSystemUrl(url: string): Observable<any> {
        return this.httpService.GET(this.enterpriseUrlService.checkSystemValidityUrl(url))
    }
    public getEnterpriseSettings(): Observable<any> {
        return this.httpService.GET(this.enterpriseUrlService.enterpriseSettingUrl());
    }
    public updateSettings(data): Observable<any> {
        return this.httpService.POST(this.enterpriseUrlService.updateSettingsUrl(), data)
    }
}