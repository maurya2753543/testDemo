import { TranslateService } from '@ngx-translate/core';
import {Input, Component, ViewChild, ElementRef} from '@angular/core';
import {BehaviorSubject} from "rxjs";
//import { LocalizationService } from 'angular2localization';

import {HideRciMonitoringPlanSliderEvent, RefreshListTabEvent} from '../../../../shared/tab-event';
import {RciCmtsUsPortGridDataService} from "../rci-cmts-us-port-grid-data.service";
import {RciCmtsUsPortGridService} from "../rci-cmts-us-port-grid.service";
import {saveAs as importedSaveAs} from "file-saver";
import {ShowAlert} from "../../../../utilities/showAlert";
import {Logger} from "../../../../utilities/logger";
import {SweetAlert} from '../../../../utilities/sweetAlert';
import {CommonStrings} from  '../../../../constant/common.strings';
import {ALERT_SUCCESS} from "../../../../constant/app.constants";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {MonitoringTabPlanModel} from "../../../hcu/monitoring-tab/model/monitoringplan.model";

@Component({
    selector: 'rci-importexportmonitoringplan-component',
    templateUrl: 'rci-importexportmonitoringplan-view.html'
})
export class RciImportExportMonitoringPlanComponent {
    @ViewChild('fileInput') fileInput: ElementRef;
    private _ls: TranslateService;
    private formData = new FormData();
    public passEvent: any;
    public testRename: any;
    private MONITORING_PLAN_IMPORT_SUCCESS_MSG:string = "";
    private RCI_MONITORING_PLAN_IMPORT_USED_EXISTING_MSG:string = "";
    private tag:string = "RciMonitoringPlanComponent";
    /*New variable isSliderOpen is added to close slider properly.
      Variable isVisible always holds the object as result
      it block slider from hiding.
    */
    public isSliderOpen: boolean = false;
    public isImportDisabled:boolean = true;
    private get ls() { return this._ls; }
    @Input("localizationService") private set ls(value: TranslateService) {
        this._ls = value;
    }

    constructor(private rciGridService: RciCmtsUsPortGridService,
                private rciGridDataService: RciCmtsUsPortGridDataService,
                private showAlert:ShowAlert,private sweetAlert:SweetAlert,
                private localeDataService:LocaleDataService,
                private logger:Logger){
        this.translateLocalString();
    }

    private readonly isVisible: BehaviorSubject<boolean> = this.rciGridService.isVisible;
    private readonly cmtsNodeID = this.rciGridService.rciCmtsUsPortId;

    ngOnInit() {
        this.isVisible.subscribe((isSliderOpen: boolean) => {
           this.isSliderOpen = isSliderOpen;
        });
    }

    closeRciMonitoringPlanSlider() {
       this.rciGridService.emitTabEvent(new HideRciMonitoringPlanSliderEvent());
       this.isImportDisabled= true;
       this.testRename='';
    }

    //function :: api call to get monitoring plan csv.
    private exportMonitoringPlan():void {
        this.rciGridDataService.exportMonitoringPlan(this.cmtsNodeID.value.id).subscribe(this.onExportMonitoringPlan.bind(this),this.onError.bind(this));
    }

    //function :: on success of export monitoring and downoads csv.
    private onExportMonitoringPlan(blob):void {
        importedSaveAs(blob, this.cmtsNodeID.value.monitoringPlanName);
        //this.closeRciMonitoringPlanSlider();
    }

    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
        this.logger.debug(this.tag, "onError(): error data=", error);
    }

    private selectMonitoringPlan():void {
        this.fileInput.nativeElement.click();
    }

    private fileChange(event):void {
        this.passEvent = event;
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let files: any = event.target.files;
        this.isImportDisabled= false;
        this.testRename= files[0].name.split('?')[0].split('.')[0];
    }

    public importMonitoringPlan():void{
        let files: any = this.passEvent.target.files;
        this.formData = null;
        if (!this.formData) {
            this.formData = new FormData();
        }
        let filetoupload= <File>files[0];
        let filename: string = this.testRename;
        let fileExtension: string = filetoupload.name.split('?')[0].split('.').pop();
     if (files.length) {
        let file;
        file = files[0];
        this.formData.append('file', filetoupload,filename+'.'+fileExtension);
        let monPlanSettings = '{ "elementId": "' + this.cmtsNodeID.value.id + '", "monitoringPlanName": "'+filename+'" }';
        this.formData.append('monPlanSettings', monPlanSettings);
        this.rciGridDataService.importMonitoringPlan(this.formData).subscribe(this.onImportSuccess.bind(this),this.onError.bind(this));
    }
}

    private clearFile(): void{
        let fileInput:any = document.getElementById("rciMonitoringPlanFileInput")
        fileInput.value = null;      
    }

    private onImportSuccess(data):void {
        var monitoringTabPlanModel = new MonitoringTabPlanModel();
        monitoringTabPlanModel.setData(data,this.localeDataService.getLocalizationService())
        if(monitoringTabPlanModel.name)
            this.showMonitoringPopUp(this.RCI_MONITORING_PLAN_IMPORT_USED_EXISTING_MSG + monitoringTabPlanModel.name);
        else
            this.showMonitoringPopUp(this.MONITORING_PLAN_IMPORT_SUCCESS_MSG);
        this.isImportDisabled= true;
        this.testRename='';
    }

    //function :: shows monitoring popup and refreshes porttab list.
    private showMonitoringPopUp(message):void {
        this.sweetAlert.showAlert(ALERT_SUCCESS, message ,CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
            (isConfirm)=>{
                this.rciGridService.isVisible.next(null);
                this.rciGridService.emitTabEvent(new RefreshListTabEvent());
            })
    }

    private translateLocalString():void {
        let localizationService = this.localeDataService.getLocalizationService();
        this.MONITORING_PLAN_IMPORT_SUCCESS_MSG = localizationService.instant('RCI_NODE_MONITORING_PLAN_IMPORT_SUCCESS_MSG');
        this.RCI_MONITORING_PLAN_IMPORT_USED_EXISTING_MSG = localizationService.instant('RCI_MONITORING_PLAN_IMPORT_USED_EXISTING_MSG');
    }
}
