import { TranslateService } from '@ngx-translate/core';
import {Component, Input} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import { publishReplay, refCount} from 'rxjs/operators';
//import {LocalizationService} from 'angular2localization';
import {ClearEditorTabEvent, RefreshListTabEvent} from '../../../../shared/tab-event';
import {RciCmtsUsPortGridService} from '../rci-cmts-us-port-grid.service';
import {SweepGridDataService} from '../../sweep-grid/sweep-grid.data.service';
import {FIRST_SELECT_OPTION, RCI_SWEEP_PLAN_SELECT} from '../../rci.constants';
import {RciCmtsUsPortGridDataService} from '../rci-cmts-us-port-grid-data.service';
import {RciCmtsUsPortEnableSweepRequestModel} from '../../models/rci-cmts-us-port-enable-sweep-request.model';
import {RciCmtsUsPortListModel} from '../../models/rci-cmts-us-port-list.model';
import {RciErrorService} from '../../rci.error.service';
import {Logger} from '../../../../utilities/logger';
import {ShowAlert} from "../../../../utilities/showAlert";
import {LocaleDataService} from '../../../../shared/locale.data.service';

@Component({
    selector: 'rci-cmts-us-port-sweep-component',
    templateUrl: 'rci-cmts-us-port-sweep.component.html'
})
export class RciCmtsUsPortSweepComponent {

    public closeSlider = new BehaviorSubject<boolean>(true);
    private isDisabled: boolean = true;
    private sweepPlanOptions: any;
    private defaultSweepPlan = FIRST_SELECT_OPTION + RCI_SWEEP_PLAN_SELECT;
    private maxDuration = 168;
    private isEnabled: boolean = false;
    private sweepPlanList: Observable<any[]>;
    private sweepPlanDuration: number = 0;
    private sweepDurationDefaultValue: number;
    private sweepPlan: string = null;
    private isDurationDisabled: boolean = false;
    private sweepPlanSelectionValue: any = 'null';
    private RCI_UPSTREAM_PORT_ENABLED: string = '';
	private RCI_UPSTREAM_PORT_DISABLED: string = '';

    private _ls: TranslateService;
    private get ls() {
        return this._ls;
    }

    @Input("localizationService")
    private set ls(value: TranslateService) {
        this._ls = value;
    }

    private _dataModel: RciCmtsUsPortListModel;
    get dataModel(): RciCmtsUsPortListModel {
        return this._dataModel;
    }

    @Input() set dataModel(value: RciCmtsUsPortListModel) {
        this._dataModel = value;
        this.sweepPlan = value.sweepPlanName;
        if (this.sweepPlan) {
            this.isDurationDisabled = true;
            const sweepExpiration: number = value['sweepExpiration'];
            if (sweepExpiration != null) {
                this.sweepDurationDefaultValue = this.getDiffHours(new Date(), new Date(sweepExpiration * 1000));
            }
        }
        let rciCmtsUsPort: RciCmtsUsPortListModel = this.dataModel;
        this.isEnabled = rciCmtsUsPort.sweepEnabled;
        this.closeSlider.next(value == null);
        if (value == null) {
            return;
        }
    }

    constructor(private showAlert: ShowAlert,
                private rciCmtsUsPortGridService: RciCmtsUsPortGridService,
                private sweepGridDataService: SweepGridDataService,
                private rciCmtsUsPortGridDataService: RciCmtsUsPortGridDataService,
                private rciErrorService: RciErrorService,
                private localeDataService: LocaleDataService,
                private logger: Logger) {

    }

    ngOnInit() {
        this.translateLocaleString();
        this.sweepPlanList = this.sweepGridDataService.getSweepPlanList()
            .pipe(publishReplay(1),
            refCount());
            this.getRciSweepData();    
    }
    private getRciSweepData() : void{
        this.rciCmtsUsPortGridDataService.getNodeRciSweepData().subscribe(this.setData.bind(this));
        }
        private setData(data : any) : void{
            
            this.sweepDurationDefaultValue = data.value;
            //this.loadComponent= true;
        }
    private setSweepPlanOptions(data: any): void {
        data.options.serverOptions.splice(0, 0, -1);
        data.options.displayOptions.splice(0, 0, FIRST_SELECT_OPTION + RCI_SWEEP_PLAN_SELECT);
        this.sweepPlanOptions = data;
    }

    private getDiffHours(dt2, dt1): number {
        let diff: number = (dt2.getTime() - dt1.getTime()) / 1000;
        diff /= (60 * 60);
        return Math.abs(Math.round(diff));
    }

    private getSweepPlanSelection(selectedItem): void {
        this.isDisabled = selectedItem.value == "null";
        this.sweepPlanSelectionValue = selectedItem.value;
        if (selectedItem.value === "-1") {
            this.dataModel.sweepPlanId = null;
            this.dataModel.sweepPlanName = null;
        } else {
            this.dataModel.sweepPlanId = selectedItem.value;
            this.dataModel.sweepPlanName = selectedItem.selectedOptions[0].text;
        }
        !this.isDisabled && this.valueChanged(this.sweepDurationDefaultValue);
    }

    //Event Handlers
    valueChanged(value) {
        const parsedVal: number = parseInt(value.toString());
        this.isDisabled = !(parsedVal >= 1 && parsedVal <= 168);
        if (!this.isDisabled) {
            this.isDisabled = this.sweepPlanSelectionValue == "null";
        }
        this.sweepDurationDefaultValue = parsedVal;
        this.sweepPlanDuration = value;
    }

    enableSweep() {
        let rciCmtsUsPortSweepToEnable = this.buildSaveRciCmtsUsPortSweep();

        this.rciCmtsUsPortGridDataService.enableSweep(rciCmtsUsPortSweepToEnable)
            .subscribe(r => {
                    //Save
                    this.closeEditor();
                    this.showAlert.showSuccessAlert(this.RCI_UPSTREAM_PORT_ENABLED);
                    
                    //Refresh Cmts Upstream Port Grid to display changes to Sweep
                    this.rciCmtsUsPortGridService.emitTabEvent(new RefreshListTabEvent());
                },
                err => {
                    this.handleRequestError(err);
                });
    }


    disableSweep() {
        let rciCmtsUsPortSweepToDisable = this.buildSaveRciCmtsUsPortSweep();

        this.rciCmtsUsPortGridDataService.disableSweep(rciCmtsUsPortSweepToDisable)
            .subscribe(r => {
                    this.closeEditor();
                    this.showAlert.showSuccessAlert(this.RCI_UPSTREAM_PORT_DISABLED);
                    //Refresh Cmts Upstream Port Grid to display changes to Sweep
                    this.rciCmtsUsPortGridService.emitTabEvent(new RefreshListTabEvent());
                },
                err => {
                    this.handleRequestError(err);
                });
    }

    closeEditor() {
        this.rciCmtsUsPortGridService.emitTabEvent(new ClearEditorTabEvent());
    }

    buildSaveRciCmtsUsPortSweep(): RciCmtsUsPortEnableSweepRequestModel {
        let result = new RciCmtsUsPortEnableSweepRequestModel();
        result.cmtsUsPortId = this.dataModel.id;
        result.sweepPlanId = this.dataModel.sweepPlanId;
        result.durationHours = this.sweepPlanDuration;

        return result;
    }

    private handleRequestError(error) {
        this.logger.error("onError():  error data=", error);
        this.showAlert.showErrorAlert(error);
    }

    private translateLocaleString(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this.RCI_UPSTREAM_PORT_ENABLED = localizationService.instant('RCI_UPSTREAM_PORT_ENABLED');
		this.RCI_UPSTREAM_PORT_DISABLED = localizationService.instant('RCI_UPSTREAM_PORT_DISABLED');
	}
}
