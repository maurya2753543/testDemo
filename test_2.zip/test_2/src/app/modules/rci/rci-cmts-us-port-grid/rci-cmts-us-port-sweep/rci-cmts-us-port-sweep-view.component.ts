import {Input, Component, Output, EventEmitter} from '@angular/core';
import {RciSweepPlanResponseModel} from '../../models/rci-sweep-plan-response.model';

@Component({
	selector: "rci-cmts-us-port-sweep-view",
	templateUrl: "./rci-cmts-us-port-sweep-view.component.html"
})
export class RciCmtsUsPortSweepViewComponent{

	public sweepPlanList: RciSweepPlanResponseModel[];
	public id: number = null;

	@Input() public isEnabled: boolean;

	@Input() private sweepPlan: string;

	@Output() selectedSweepPlanChanged = new EventEmitter<any>();

	@Input()
	set sweepPlanListItems(sweepPlanListItems: RciSweepPlanResponseModel[]) {
		this.sweepPlanList = sweepPlanListItems;
		if (this.sweepPlan && this.sweepPlanList) {
			this.processId();
		}
	}

	private processId(): void {
		for (let i = 0; i < this.sweepPlanList.length; i ++) {
			if (this.sweepPlanList[i].name === this.sweepPlan) {
				this.id = this.sweepPlanList[i].id;
				break;
			}
		}
	}

	getSweepPlanSelection(item: any){
		this.selectedSweepPlanChanged.emit(item);
	}


}