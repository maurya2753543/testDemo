import {Injectable} from '@angular/core';
import {Observable, throwError } from 'rxjs';
import {HttpResponse} from '@angular/common/http';
import {map, catchError} from "rxjs/operators";
import {RciHttpService} from '../rci.http.service';
import {RciCmtsUsPortListModel} from '../models/rci-cmts-us-port-list.model';
import {RciCmtsUsPortEnableSweepRequestModel} from '../models/rci-cmts-us-port-enable-sweep-request.model';
import {ViewEventsModel} from "../../shared/common-components/models/viewEvents.model";
import {ThresholdService} from "../../shared/threshold.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ThresholdModel} from "../../shared/common-components/models/threshold.model";

@Injectable()
export class RciCmtsUsPortGridDataService{

	private localService:any;

	constructor(private rciHttpService: RciHttpService,
				private thresholdService: ThresholdService,
				private localeDataService:LocaleDataService) {
		this.localService = this.localeDataService.getLocalizationService();
	}

	public getRciCmtsUsPortList(): Observable<RciCmtsUsPortListModel[]>{
		return this.rciHttpService
			.getRciCmtsUsPortList()
			.pipe(map((r) => <RciCmtsUsPortListModel[]>r))
	}

	public enableSweep(rciCmtsUsPortEnableSweepRequestModel: RciCmtsUsPortEnableSweepRequestModel): Observable<any> {

		return this.rciHttpService.enableRciCmtsUsPortSweep(rciCmtsUsPortEnableSweepRequestModel)
			.pipe(catchError(this.handleError))
	}

	public exportRPHY_Mapping(): Observable<any> {
		return this.rciHttpService.exportRPHY_MappingHttp()
			.pipe(
				map(response => response.blob())
				,catchError(this.handleError)
			)
	}
	public getNodeRciSweepData(): Observable<any> {
        return this.rciHttpService.getRciSweep()
            .pipe(
                (data) => {
                    
                    return data;
                },
                catchError(this.handleError)
            )
    }
	public importRPHY_Mapping(data: any): Observable<any> {
		return this.rciHttpService.importRPHY_MappingHttp(data)
			.pipe(catchError(this.handleError))
	}

	public disableSweep(rciCmtsUsPortEnableSweepRequestModel: RciCmtsUsPortEnableSweepRequestModel): Observable<any> {

		return this.rciHttpService.disableRciCmtsUsPortSweep(rciCmtsUsPortEnableSweepRequestModel.cmtsUsPortId)
			.pipe(catchError(this.handleError))
	}

	//Error handler
	public handleError(error) {
		return throwError(error);
	}

	public pasteMonitoringPlan(data):Observable<any> {
		return this.rciHttpService
			.pasteMonitoringPlan(data)
			.pipe(map((res:HttpResponse<any>)=>{
				return res;
			}))
	}

	public exportMonitoringPlan(cmtsUsPortId):Observable<any> {
		return this.rciHttpService
			.exportMonitoringPlan(cmtsUsPortId).pipe(
				map((exportData)=>{
					return exportData;
				})
			)
			
	}

	public importMonitoringPlan(formData):Observable<any> {
		return this.rciHttpService
			.importMonitoringPlan(formData).pipe(
				function(res){ return  res}
				// map((importRes:HttpResponse<any>)=>{
				// 	console.log('importRes ',formData);
				// 	if(importRes.status == 200) return true;
				// })
				,catchError(this.errorHandler)

			)
			
	}

	//Method to get HCU EVENTS list
	public getEventListData(elementID: any, type: string): Observable<any> {
		return this.rciHttpService
			.getEventList(elementID, type).pipe(
				map((eventListDataObj: HttpResponse<any>) => {
					return new ViewEventsModel(eventListDataObj, this.localService);
				})
				,catchError(this.handleError)
			)
			
	}

	public getThresholdsName(): Observable<any>{
		return this.rciHttpService
			.getThresholdLabels().pipe(
				map((resObj:HttpResponse<any>)=>{
				const thresholds: any = resObj;
				this.setThresholds(thresholds);
				return this.processThresholdsName(thresholds);
			}),catchError(this.handleError)
			)
			
	}

	private processThresholdsName(res: any[]): ThresholdModel[]{
		let thresholdModels: ThresholdModel[] = [];
		res.forEach((obj: any)=>{
			thresholdModels.push(obj);
		});
		return thresholdModels;
	}

	private setThresholds(thresholds: any[]): void {
		const obj: any = {};
		thresholds.forEach((threshold: any, index: number) => {
			obj["threshold".concat((index + 1).toString(), "Label")] = threshold.value;
		});
		this.thresholdService.thresholdList = obj;
	}

	//Error handler
	public errorHandler(error) {
		return throwError(error);
	}
}
