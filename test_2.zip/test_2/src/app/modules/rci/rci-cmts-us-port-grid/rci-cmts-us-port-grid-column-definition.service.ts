import { TranslateService } from '@ngx-translate/core';
import {Injectable} from '@angular/core';
import { ColDef } from 'ag-grid';
import {SharedService} from '../../../shared/shared.service';
import {ExportColDef} from '../../../shared/export.coldef';
import {DisabledFilter} from '../../shared/grid/disabled.filter';
import {EDIT_ICON} from '../../../constant/app.constants';
import {EditCmtsUsPort, EditItemTabEvent} from '../../../shared/tab-event';
import {RciCmtsUsPortGridService} from './rci-cmts-us-port-grid.service';
import {SelectBoxFilter, SelectBoxFilterParams} from "../../../shared/select-box.filter";
import {LanguageService} from "../../../shared/locale.language.service";
import { BooleanFilter } from "src/app/shared/boolean.filter";
@Injectable()
export class RciCmtsUsPortGridColumnDefinitionService{


	private _HEADER_FIELDS: any = {
		cmtsUsPortName: {field: "name", name: "RCI_CMTS_US_PORT_NAME"},
		daadevice: {field: "daadevice", name: "RCI_CMTS_US_PORT_DAA_NAME"},
		cmtsCcapName: {field: "cmtsCcapName", name: "RCI_CMTS_US_PORT_CMTS_CCAP_NAME"},
		rciName: {field: "rciName", name: "RCI"},
		rphyVendor: {field: "rphyVendor", name: "RCI_CMTS_US_PORT_RPHYVENDOR"},
		monitoringPlanName: {field: "monitoringPlanName", name: "RCI_CMTS_US_PORT_MONITORING_PLAN"},
		testPointComp: {field: "testPointComp", name: "HCU_TEST_POINT_COMPENSATION"},
		sweepEnabled: {field: "sweepEnabled", name: "RCI_CMTS_US_PORT_SWEEP_STATUS"},
		daaspectrumLicensed: {field: "daaspectrumLicensed", name: "RCI_CMTS_US_PORT_SPECTRUM_LICENSE"},
		daamonitoringLicensed: {field: "daamonitoringLicensed", name: "RCI_CMTS_US_PORT_MONITORING_LICENSE"},
		view: {field: "view", name: "RCI_CMTS_US_PORT_SWEEP_VIEW"}
	};

	constructor(private rciNodeGridService: RciCmtsUsPortGridService,
		private languageService: LanguageService,
		private sharedService: SharedService) {

	}

	public getColumnDef(localizationService: TranslateService): ColDef[] {
		const _TRUE: string = localizationService.instant('TRUE');
		const _FALSE: string = localizationService.instant('FALSE');
		let lang: string = this.languageService.getCurrentLanguage();
		let digits: string = '1.1-2';
		
		BooleanFilter.setBoolValue(
            {
                default: localizationService.instant('DEFAULT'),
                true: _TRUE,
                false: _FALSE
            }
        );
		
		function buildFilter(column) {
			let columnFilterParams = <SelectBoxFilterParams>{
				noSelectionDisplay: localizationService.instant('DEFAULT'),
				valuePassesFilter: (row, filter) => row.data[column] === filter,
				values: [{
					value: true,
					display: localizationService.instant('TRUE')
				}, {
					value: false,
					display: localizationService.instant('FALSE')
				}]
			};

			return columnFilterParams;
		}

		let columnDef: ExportColDef[] = [
			{
				headerName: '',
				maxWidth: 25,
				pinned: true,
				checkboxSelection: true,
				sort: 'asc',
				field: '',
				headerCheckboxSelection: true,
				suppressFilter: true,
				 suppressSizeToFit: true,
				 suppressMenu: true,
				 suppressResize: true,
				comparator: (a, b, nodeA, nodeB) => {
					if(nodeA.isSelected() && nodeB.isSelected()) return 0;
					else if (nodeA.isSelected()) return -1;
					else return 1;
				}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.cmtsUsPortName.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.cmtsUsPortName.name),
				field: localizationService.instant(this._HEADER_FIELDS.cmtsUsPortName.field),
				minWidth: 220,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'},
				sort: 'asc'
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.daadevice.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.daadevice.name),
				field: localizationService.instant(this._HEADER_FIELDS.daadevice.field),
				minWidth: 120,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.cmtsCcapName.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.cmtsCcapName.name),
				field: localizationService.instant(this._HEADER_FIELDS.cmtsCcapName.field),
				minWidth: 130,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.rciName.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.rciName.name),
				field: localizationService.instant(this._HEADER_FIELDS.rciName.field),
				minWidth: 80,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.rphyVendor.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.rphyVendor.name),
				field: localizationService.instant(this._HEADER_FIELDS.rphyVendor.field),
				minWidth: 80,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.monitoringPlanName.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.monitoringPlanName.name),
				field: localizationService.instant(this._HEADER_FIELDS.monitoringPlanName.field),
				minWidth: 130,
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'}
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.testPointComp.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.testPointComp.name),
				field: localizationService.instant(this._HEADER_FIELDS.testPointComp.field),
				minWidth: 242,
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'},
				filter: 'agTextColumnFilter',
				cellRenderer: ((param:any)=>{
					if(param.data && typeof param.data != "undefined") {
						let value: string = this.sharedService.toDecimal(param.data.testPointComp,  digits).toString();
						return "<span>".concat(value, "</span>");
					}
				})
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.sweepEnabled.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.sweepEnabled.name),
				field: this._HEADER_FIELDS.sweepEnabled.field,
				editable: false,
				minWidth: 150,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true,
					newRowsAction: 'keep'
				}, buildFilter("sweepEnabled")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, buildFilter("sweepEnabled")),
				valueFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE'),
				exportFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE')
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.daaspectrumLicensed.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.daaspectrumLicensed.name),
				field: this._HEADER_FIELDS.daaspectrumLicensed.field,
				editable: false,
				minWidth: 150,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true,
					newRowsAction: 'keep'
				}, buildFilter("daaspectrumLicensed")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, buildFilter("daaspectrumLicensed")),
				valueFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE'),
				exportFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE')
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.daamonitoringLicensed.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.daamonitoringLicensed.name),
				field: this._HEADER_FIELDS.daamonitoringLicensed.field,
				editable: false,
				minWidth: 200,
				filter: BooleanFilter.ParentFilter,
				filterParams: Object.assign({
					suppressAndOrCondition: true,
					newRowsAction: 'keep'
				}, buildFilter("daamonitoringLicensed")),
				floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
				floatingFilterComponentParams: Object.assign({
					suppressFilterButton: true
				}, buildFilter("daamonitoringLicensed")),
				valueFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE'),
				exportFormatter: v => localizationService.instant(v.value ? 'TRUE' : 'FALSE')
			},
			{
				colId: 'edit',
				headerName: localizationService.instant(this._HEADER_FIELDS.view.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.view.name),
				field: localizationService.instant(this._HEADER_FIELDS.view.field),
				pinned: this.sharedService.isPinned(),
				minWidth: 70,
				maxWidth: 120,
				width: 70,
				sortingOrder: [null],
				suppressSorting : true,
				cellStyle : () => {
					return { 'text-align': 'center' };
				},
				filter: 'text',
				floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
				floatingFilterComponentParams:{ suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
					newRowsAction: 'keep'},
				suppressMenu: true,
				cellRenderer: ((param:any)=>{
					let gui = document.createElement('div');
					gui.innerHTML = EDIT_ICON;
					let eFilterText = gui.querySelector('i');
					eFilterText.addEventListener("click", (()=>{
						this.editItem(param);
					}));
					gui.className = "ag-Grid-cursor";
					return gui;
				})
			}
		];

		return columnDef;
	}

	editItem(param: any) {
		this.rciNodeGridService.emitTabEvent(new EditCmtsUsPort(param.data));
	}


	private calculateIsEnabledText(s: string) {
		let test = s;

		return test;
	}

	private testFieldValue(field: string) {
		let test = field;

		return test;
	}
}
