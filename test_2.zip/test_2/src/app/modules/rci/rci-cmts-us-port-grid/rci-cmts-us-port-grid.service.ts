import {Injectable} from '@angular/core';
import {ShowAlert} from '../../../utilities/showAlert';
import {RciErrorService} from '../rci.error.service';
import {Logger} from '../../../utilities/logger';
import {
	EditCmtsUsPort,
	EditItemTabEvent,
	ShowRciMonitoringPlanSliderEvent,
	TabAction,
	TabEvent
} from '../../../shared/tab-event';
import {RciCmtsUsPortGridDataService} from './rci-cmts-us-port-grid-data.service';
import {BehaviorSubject, Observable, Subject} from 'rxjs';
import {RciCmtsUsPortListModel} from '../models/rci-cmts-us-port-list.model';
import { repeatWhen, publishReplay, refCount } from 'rxjs/operators';

@Injectable()
export class RciCmtsUsPortGridService{

	public readonly rciCmtsUsPortListItem = new BehaviorSubject<RciCmtsUsPortListModel>(null);
	public readonly rciCmtsUsPortEditListItem = new BehaviorSubject<RciCmtsUsPortListModel>(null);
	private rciCmtsUsPortListUpdated = new Subject();
	public readonly isVisible = new BehaviorSubject<boolean>(false);
	public readonly rciCmtsUsPortId = new BehaviorSubject<any>(null);
	public rcicmtsusportfilterchangedata: any;

	constructor(
		private dataService: RciCmtsUsPortGridDataService,
		private showAlert: ShowAlert,
		private rciErrorService: RciErrorService,
		private logger: Logger){}

	public _rciCmtsUsPortListOneTime: Observable<RciCmtsUsPortListModel[]>;
	public get rciCmtsUsPortList(): Observable<RciCmtsUsPortListModel[]> {
		this._rciCmtsUsPortListOneTime = this.dataService.getRciCmtsUsPortList()
			.pipe(repeatWhen(l => this.rciCmtsUsPortListUpdated),
			// cache and re-issue the result to future subscribers
			publishReplay(),
			refCount());
		return this._rciCmtsUsPortListOneTime;
	}

	emitTabEvent(event: TabEvent) {
		switch(event.action){
			case TabAction.EDIT_ITEM:
				this.rciCmtsUsPortListItem.next((<EditItemTabEvent>event).data);
				break;
			case TabAction.EDIT_CMTS:
				this.rciCmtsUsPortEditListItem.next((<EditCmtsUsPort>event).data);
				break;
			case TabAction.CLEAR_EDITOR:
				this.rciCmtsUsPortListItem.next(null);
				this.rciCmtsUsPortEditListItem.next(null);
				break;
			case TabAction.REFRESH_LIST:
				this.rciCmtsUsPortListUpdated.next();
				break;
			case TabAction.SHOW_RCI_MONITORING_PLAN_SLIDER:
				this.rciCmtsUsPortId.next ((<ShowRciMonitoringPlanSliderEvent>event).data);
				this.isVisible.next(true);
				break;
			case TabAction.HIDE_RCI_MONITORING_PLAN_SLIDER:
				this.rciCmtsUsPortId.next(null);
				this.isVisible.next(null);
				break;
		}
	}
}
