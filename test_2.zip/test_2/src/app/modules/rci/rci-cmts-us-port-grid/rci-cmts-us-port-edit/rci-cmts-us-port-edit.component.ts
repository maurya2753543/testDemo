import {Component, Input} from "@angular/core";
import {BehaviorSubject} from "rxjs";
//import {LocalizationService} from "angular2localization";

import {RciCmtsUsPortListModel} from "../../models/rci-cmts-us-port-list.model";
import {ClearEditorTabEvent} from "../../../../shared/tab-event";
import {RciCmtsUsPortGridService} from "../rci-cmts-us-port-grid.service";
import {RciHttpService} from "../../rci.http.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {ALERT_SUCCESS} from "../../../../constant/app.constants";
import {CommonStrings} from "../../../../constant/common.strings";
import {SweetAlert} from "../../../../utilities/sweetAlert";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import { map } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";
@Component({
    templateUrl: "rci-cmts-us-port-edit.component.html",
    selector: "cmts-us-port-edit"
})

export class RciCmtsUsPortEditComponent {

    public closeSlider = new BehaviorSubject<boolean>(true);
    private _dataModel: RciCmtsUsPortListModel;
    max: number = 50;
    public cmtsData: any;
    public isEditEnable: boolean = true;

    get dataModel(): RciCmtsUsPortListModel { return this._dataModel; }
    @Input() set dataModel(value: RciCmtsUsPortListModel) {
        this._dataModel = value;
        this.closeSlider.next(value == null);
        if(value == null) {
            return;
        } else {
            this.getCmtsInfo();
        }
    }

    constructor(private rciCmtsUsPortGridService: RciCmtsUsPortGridService,
                private rciHttpService: RciHttpService,
                private showAlert: ShowAlert,
                private localeDataService: LocaleDataService,
                private sweetAlert:SweetAlert,
                public translate: TranslateService) {}

    private getCmtsInfo(): void {
        this.rciHttpService.getCmtsUsPortInfo(this.dataModel.id)
            .pipe(map((data) => data))
            .subscribe((data: any) => {
                this.cmtsData = data;
                console.log('cmts', this.cmtsData)
            }, this.onError.bind(this));
    }

    public closeEditor(): void {
        this.rciCmtsUsPortGridService.emitTabEvent(new ClearEditorTabEvent());
    }

    private valueChanged(value: string): void {
        const parsedVal: number = parseInt(value);
        if (value) {
            if (parsedVal < 0) {
                this.cmtsData.testPointComp = 0;
            } else if (parsedVal > this.max) {
                this.cmtsData.testPointComp = this.max;
            }
        } else {
            this.cmtsData.testPointComp = 0;
        }

    }

    private onEditEnable(): void {
        this.isEditEnable = false;
    }

    private onSave(): void {
        this.rciHttpService.setCmtsUsPortInfo(this.dataModel.id, this.cmtsData)
            .subscribe(this.onSuccess.bind(this), this.onError.bind(this));
    }

    private onSuccess(): void {
        const lang = this.translate;// this.localeDataService.getLocalizationService();
        this.sweetAlert.showAlert(ALERT_SUCCESS, lang.instant("CMTS_US_PORT_UPDATE_SUCCESS"),
            CommonStrings.ALERT_SUCCESS_TITLE,CommonStrings.OK,null,
            ()=>{
                this.closeEditor();
            });
    }

    private onError(error:any):void {
        this.showAlert.showErrorAlert(error);
    }
}
