import {LocaleDataService} from '../../../shared/locale.data.service';
import {Grid} from '../../../shared/ag-grid.options';
import {Component, ElementRef, ViewChild} from '@angular/core';
import {Observable, Subject, of} from 'rxjs';
import { map ,publishReplay, refCount, filter,combineLatest, merge} from 'rxjs/operators';
//import {LocalizationService} from 'angular2localization';
import {TranslateService} from '@ngx-translate/core';
import {saveAs as importedSaveAs} from "file-saver";

import {
	EditItemTabEvent,
	RefreshListTabEvent,
	ShowRciMonitoringPlanSliderEvent,
	TabAction,
	TabEvent
} from '../../../shared/tab-event';
import {
	GRID_COMP_KEY_MULTI,
	GRID_COMP_KEY_ONLY_SINGLE,
	GRID_COMP_KEY_SINGLE
} from '../../../constant/app.constants';
import {RciCmtsUsPortGridService} from './rci-cmts-us-port-grid.service';
import {RciCmtsUsPortGridColumnDefinitionService} from './rci-cmts-us-port-grid-column-definition.service';
import {RciCmtsUsPortListModel} from '../models/rci-cmts-us-port-list.model';
import {ShowAlert} from "../../../utilities/showAlert";
import {RciCmtsUsPortGridDataService} from "./rci-cmts-us-port-grid-data.service";
import {SharedService} from "../../../shared/shared.service";
import {Logger} from "../../../utilities/logger";
import {ThresholdService} from "../../shared/threshold.service";
import {RciHttpService} from "../../rci/rci.http.service";
@Component({
	selector: 'rci-cmts-us-port-grid-component',
	templateUrl: 'rci-cmts-us-port-grid.component.html'
})
export class RciCmtsUsPortGridComponent{
	public localizationService: Observable<any>;
	public gridOptions: Observable<Grid>;
	public rcicmtsusGridOptions: Grid = new Grid();
	private gridModelUpdated = new Subject();
	public buttonKeys: Observable<Object[]>;
	public eventKeys: Observable<Object[]>;
	public rowData: Observable<RciCmtsUsPortListModel[]>;
	public showAllLabel: Observable<string>;
	public showAllLabelMob: Observable<string>;
	public rciCmtsUsPortListItem: Observable<RciCmtsUsPortListModel>;
	public rciCmtsUsPortEditListItem: Observable<RciCmtsUsPortListModel>;
	public refreshBtnFlag: Observable<boolean>;
	private gridApi: any;
	private copyPortId:number = null;
	public exportFileName = 'RCICmtsUsPortExport';
	private pastePortIds:Array<number> = [];
	private SweepCmtsUsPortModel:RciCmtsUsPortListModel = new RciCmtsUsPortListModel({});
	private PORT_MONITORING_COPY_SUCCESS_MSG:string = "";
	private MONITORING_PASTE_ON_SAME_MSG:string = "";
	private VIEW_MONITORING:string = "";
	private formData = new FormData();
	public viewEventData: any = null;

	@ViewChild('fileInput') fileInput: ElementRef;

	constructor(
		private thresholdService: ThresholdService,
		private columnDefinition: RciCmtsUsPortGridColumnDefinitionService,
		private localeDataService: LocaleDataService,
		private sharedGridService: RciCmtsUsPortGridService,
		private rciHttpService: RciHttpService,
		private sharedService: SharedService,
		private rciCmtsUsPortGridDataService: RciCmtsUsPortGridDataService,
		private showAlert: ShowAlert,
		private logger: Logger,
		private translate : TranslateService) {
		this.localizationService = this.localeDataService.isReady
			.pipe(filter(ready => ready),
			map(r => this.translate));

		this.rciCmtsUsPortListItem = this.sharedGridService.rciCmtsUsPortListItem.asObservable().pipe(publishReplay(1),refCount());
		this.rciCmtsUsPortEditListItem = this.sharedGridService.rciCmtsUsPortEditListItem.asObservable().pipe(publishReplay(1),refCount());

		this.refreshBtnFlag = this.localeDataService.isReady;
        
		this.gridOptions = this.localizationService.pipe(map( ls =>{
			let result = new Grid();
			result.setColumnDefs(this.columnDefinition.getColumnDef(ls));
			return result;
		}))
		
		this.setupButtons();
		this.translateLocaleString();
		
	}

	ngOnInit() {
		this.rciCmtsUsPortListItemSubjectListener();
		if(this.sharedService.RetainFilter){
			this.sharedGridService.rcicmtsusportfilterchangedata = "";
            this.rciHttpService.rcigridmodel = "";
        }
		
	}

	private rciCmtsUsPortListItemSubjectListener(): void {
	this.rciCmtsUsPortListItem.subscribe(() => {
			if(this.rowData){
				this.rowData = this.sharedGridService._rciCmtsUsPortListOneTime;
				
			}
			else{
				this.rowData = this.sharedGridService.rciCmtsUsPortList;
			}
			this.setupCounts();
		});
		
	}
    public notifyFilterChangeCMTSUSPORT(event): void{
		this.sharedService.RetainFilter = false;
		this.sharedGridService.rcicmtsusportfilterchangedata = this.gridApi.getFilterModel();
		 const countryFilterComponent = this.gridApi.getFilterInstance('rciName');
        const model = countryFilterComponent.getModel();
        this.rciHttpService.rcigridmodel = model;
	}
	private setupButtons() {
		// this.buttonKeys = of([
		// 		{ name: this.translate.instant('IMPORT_RPHY_MAPPING'), action: TabAction.IMPORT_RPHY_MAPPING},
		// 		{ name: this.translate.instant('EXPORT_RPHY_MAPPING'), action: TabAction.EXPORT_RPHY_MAPPING},
		// 	]);
		this.buttonKeys = of([]);
		this.eventKeys = of([
				{ name: this.translate.instant('RCI_CMTS_US_PORT_TAB_COPY_MONITORING'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.COPY_MONITORING_PLAN },
				{ name: this.translate.instant('RCI_CMTS_US_PORT_VIEW_MONITORING'), status:'only-single', action: TabAction.SHOW_RCI_MONITORING_PLAN_SLIDER },
				{ name: this.translate.instant('RCI_CMTS_US_PORT_TAB_PASTE_MONITORING'), status: 'single', action: TabAction.PASTE_RCI_MONITORING_PLAN },
				{ name: this.translate.instant('VIEW_EVENTS'), status: 'only-single', action: TabAction.RCI_CMTS_US_PORT_VIEW_EVENTS },
				{ name: this.translate.instant('SWEEP_ENABLE_DISABLE'), status: 'only-single', action: TabAction.SWEEP },
				{ name: this.translate.instant('TABLE_LIST_EXPORT_SELECTED'), status: GRID_COMP_KEY_SINGLE },
				{ name: this.translate.instant('TABLE_LIST_EXPORT_ALL'), status: GRID_COMP_KEY_MULTI },

			]);
	}

	//method :: used for localization
	private translateLocaleString(): void {
		const localizationService= this.translate;
		this.PORT_MONITORING_COPY_SUCCESS_MSG = localizationService.instant('RCI_CMTS_US_PORT_MONITORING_COPY_SUCCESS_MSG');
		this.MONITORING_PASTE_ON_SAME_MSG = localizationService.instant('RCI_CMTS_US_PORT_MONITORING_PASTE_ON_SAME_MSG');
		this.VIEW_MONITORING = localizationService.instant('RCI_CMTS_US_PORT_VIEW_MONITORING');

		this.thresholdService.alarmClear = localizationService.instant("PORT_ALARM_CLEARED");
		this.thresholdService.nodeOutage = localizationService.instant("NODE_OUTAGE");
		this.thresholdService.violation = localizationService.instant("PORT_VIOLATION");
		this.thresholdService.threshold = localizationService.instant("THRESHOLD");
		this.thresholdService.thresholdInterval = localizationService.instant("ALARM_LIST_THRESHOLD_INTERVAL_VALUE");

	}

	private setupCounts() {
		let totalCount = this.rowData.pipe(map(r => r.length));
		let rowCount = this.gridModelUpdated // when the model is updated
			.pipe(combineLatest(this.gridOptions), // get latest grid options
			filter(result => result[1].api != null), // when the grid api is not null
			map(result => result[1].api.getDisplayedRowCount()), // retrieve the displayed row count
			merge(totalCount)); // or take the total count of data

		let counts = this.localizationService.pipe(combineLatest(totalCount, rowCount));
		this.showAllLabel = counts
			.pipe(map(result => {
				let ls = result[0];
				let totalCount = result[1];
				let rowCount = result[2];
				return `${this.translate.instant('TABLE_LIST_SHOWING')} ${rowCount} ${this.translate.instant('TABLE_LIST_SHOWING_OF')} ${totalCount} ${this.translate.instant('TABLE_LIST_ROWS')}`;
			}));

		this.showAllLabelMob = counts.pipe(map(count => `${count[2]}/${count[1]}`));
		if(this.gridApi &&( this.sharedGridService.rcicmtsusportfilterchangedata || this.rciHttpService.rcigridmodel)){
			this.gridApi.setFilterModel(this.sharedGridService.rcicmtsusportfilterchangedata);
			
			const countryFilterComponent = this.gridApi.getFilterInstance("rciName");
            countryFilterComponent.setModel(this.rciHttpService.rcigridmodel); 
			
		}
	}
	public gridModelUpdatedEmitter(params:any) {
		this.gridModelUpdated.next();
	}

	public handleButtonEvent(context){
		let event: TabEvent;
		switch (context.event.action) {
			case  TabAction.COPY_MONITORING_PLAN:
				this.notifyCopyMonitoringPlan(context.selectedData[0]);
				break;
			case TabAction.PASTE_RCI_MONITORING_PLAN:
				this.notifyPasteMonitoringPlan(context.selectedData);
				break;
			case TabAction.SHOW_RCI_MONITORING_PLAN_SLIDER:
				event = new ShowRciMonitoringPlanSliderEvent(context.selectedData[0]);
				this.sharedGridService.emitTabEvent(event);
				break;

			case TabAction.IMPORT_RPHY_MAPPING:
				this.importRPHU_Mapping();
				break;
			case TabAction.EXPORT_RPHY_MAPPING:
				this.exportRPHU_Mapping();
				break;
			case TabAction.SWEEP:
				this.enableSweep();
				break;
			case TabAction.RCI_CMTS_US_PORT_VIEW_EVENTS:
				this.viewEvents();
				break;
			default: throw new Error('Unhandled button event: ' + context.event.action);
		};
	}

	private viewEvents(): void {
		const data: any = this.gridApi.getSelectedNodes()[0].data;
		if (data) {
			this.viewEventData = data;
		}
	}

	private onCloseSliderEmitter(): void {
		this.viewEventData = null;
	}

	private enableSweep(): void {
		const data: any = this.gridApi.getSelectedNodes()[0].data;
		if (data) {
			this.sharedGridService.emitTabEvent(new EditItemTabEvent(data));
		}
	}

	public notifyGridReadyHCU(gridData: any): void {
		this.gridApi = gridData.api;
		if(this.gridApi && (this.sharedGridService.rcicmtsusportfilterchangedata || this.rciHttpService.rcigridmodel)){
			this.gridApi.setFilterModel(this.sharedGridService.rcicmtsusportfilterchangedata);
			if(this.rciHttpService.rcigridmodel || this.sharedGridService.rcicmtsusportfilterchangedata){
			const countryFilterComponent = this.gridApi.getFilterInstance("rciName");
            countryFilterComponent.setModel(this.rciHttpService.rcigridmodel);
		}
	}
	}

	private importRPHU_Mapping(): void {
		this.fileInput.nativeElement.click();
	}

	public clearFile(): void{
		let fileInput:any = document.getElementById("fileInput")
		fileInput.value = null;
	}

	public fileChange(event: any): void {
		this.formData = null;
		if (!this.formData) {
			this.formData = new FormData();
		}
		let files: any = event.target.files;
		if (files.length) {
			let file;
			file = files[0];
			this.formData.append('file', file, file.name);
			this.rciCmtsUsPortGridDataService
				.importRPHY_Mapping(this.formData)
				.subscribe(this.handleImportLabelResponse.bind(this)
					,this.onError.bind(this));
		}
	}

	//method :: onsuccess of import RPHY.
	private handleImportLabelResponse(data): void{
		this.fileInput.nativeElement.value = "";
		let responseData = data.json();
		if(responseData.errorPresent){
			this.showAlert.showAlertWithExportRPHY(responseData);
		} else{
			this.localizationService
			.pipe(map(ls => ls.translate("IMPORT_RPHY_SUCCESSFUL")))
			.subscribe((message: string) => {
				this.showAlert.showSuccessAlert(message);
			});
		}

	}

	private exportRPHU_Mapping(): void {
		this.rciCmtsUsPortGridDataService.exportRPHY_Mapping()
			.subscribe(this.onExportExportRPHYSuccess.bind(this), this.onError.bind(this));
	}

	private onExportExportRPHYSuccess(data):void{
		this.exportToCsv(data);
	}

	/*export json data in csv format */
	private exportToCsv(blob: any):void{
		importedSaveAs(blob, 'export.csv');
	}

	public notifyRefreshGrid(params:any) {
		this.sharedGridService.emitTabEvent(new RefreshListTabEvent());
	}

	//method :: notify that grid is ready.
	private notifyCopyMonitoringPlan(selectedData){
		let localizationService = this.localeDataService.getLocalizationService();
		this.copyPortId = selectedData.id;
		this.showAlert.showSuccessAlert(this.PORT_MONITORING_COPY_SUCCESS_MSG);
	}

	//method :: notify that grid is ready.
	private notifyPasteMonitoringPlan(selectedData){
		let dataSelected : any[] = [];
		for(let i= 0; i < selectedData.length ; i++) {
			if(selectedData[i] && selectedData[i].id) dataSelected.push(selectedData[i]);
		}
		if(this.copyPortId != null) {
			this.portIdsArray(dataSelected);
			let obj:any = {
				"copyPortId":this.copyPortId,
				"pastePortIds":this.pastePortIds
			}
			if(this.pastePortIds.length) {
				this.rciCmtsUsPortGridDataService.pasteMonitoringPlan(obj).subscribe(this.onPasteMonitoringSuccess.bind(this), this.onError.bind(this));
			}else {
				this.showAlert.showInfoAlert(this.MONITORING_PASTE_ON_SAME_MSG);
			}
		}

	}

	//method :: on paste monitoring success.
	private onPasteMonitoringSuccess(data:any):void {
		this.pastePortIds = [];
		let msg = this.SweepCmtsUsPortModel.getPasteMonitoringErrorCount(data, this.localeDataService.getLocalizationService());
		this.showAlert.showSuccessAlert(msg);
	}

	//method :: creates porIds list for paste monitoring.
	private portIdsArray(data:any):void {
		for(var i=0; i<data.length; i++) {
			if(this.copyPortId != data[i].id) {
				this.pastePortIds.push(data[i].id)
			}
		}
	}

	private onError(error:any):void {
		this.logger.debug("onError(): error data=", error);
		this.showAlert.showErrorAlert(error);
	}
}
