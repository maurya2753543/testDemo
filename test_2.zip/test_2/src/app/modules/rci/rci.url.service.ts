/**
 * Created by nikita.dewangan on 03-07-2017.
 */

import { Injectable } from '@angular/core';

import {SharedService} from "../../shared/shared.service";
import {PATHTRAK_PATH} from "../../constant/app.constants";
import {
    SLASH,
    RCI,
    SYNC,
    RCI_SWEEP_PLAN,
    RCI_REBOOT,
    RCI_FIRMWARE_UPGRADE,
    RCI_VIEW_LOG,
    RCI_CPU_STATS,
    RCI_TEST_CONNECTION,
    RCI_CMTS_US_PORT_SWEEP_ENABLE,
    RCI_CMTS_US_PORT_SWEEP_DISABLE,
    RCI_CMTS_US_PORT_PASTE,
    RCI_CMTS_US_PORT_EXPORT,
    RCI_CMTS_US_PORT_TEXT,
    RCI_CMTS_US_PORT_IMPORT,
    RCI_CMTS_US_PORTS,
    NODE,
    PASTE_CMTS,
    RCI_RPHY_EXPORT, RCI_RPHY, RCI_RPHY_IMPORT
} from "./rci.constants";

@Injectable()
export class RciUrlService {

    private host: string = "";
    // private JSON_BASE_PATH : string = "assets/jsons/" ;

    constructor(private sharedService: SharedService) {
        this.setHost();
    }

    /* Method to set host */
    private setHost(): void {
        this.host = this.sharedService.getHost();
    }

    /* Method to get host */
    private getHost():string{
        return this.host + PATHTRAK_PATH;
    }

    /* Return url to get Rci tab list from server */
    public getRciListUrl(): string {
        return this.getHost() + RCI ;
    }

    /* Method to get rci details url */
    public getRciDetailUrl( rciId : number ) : string {
        return this.getHost() + RCI + SLASH +rciId;
    }

    /* Method to sync rci*/
    public getRciSyncUrl(): string{
        return this.getHost() + RCI + SLASH +SYNC;
    }

    /* Method to get delete rci url */
    public getItemRciUrl(rciId: number): string{
        return this.getHost() + RCI + SLASH +rciId;
    }

    public getRciEventUrl(rciId: number): string{
        return this.getHost() + 'event/element/type/rci/id/' + rciId;
    }

    public getCMTSListUrl(): string {
        return this.getHost() + "cmts";
    }
        
    public getSweepPlanListUrl() {
        return this.getHost() + RCI_SWEEP_PLAN;
    }

    public getAddSweepPlanUrl() {
        return this.getHost() + RCI_SWEEP_PLAN;
    }

    public getUpdateSweepPlanUrl(sweepPlanId: number) {
        return this.getHost() + RCI_SWEEP_PLAN + SLASH + sweepPlanId;
    }

    public getDeleteSweepPlanUrl(sweepPlanId: number) {
        return this.getHost() + RCI_SWEEP_PLAN + SLASH + sweepPlanId;
    }

    public getRciRebootUrl(): string {
		return this.getHost() + RCI + SLASH + RCI_REBOOT;
    }

    public getRciFirmwareUpgradeUrl(): string {
        return this.getHost() + RCI + SLASH + RCI_FIRMWARE_UPGRADE;
    }

    public getLogMessageUrl( rciId : number ) :string{
        return this.getHost() + RCI + SLASH + rciId + SLASH + RCI_VIEW_LOG;
    }

    public getRciCpuStatsUrl(rciId: number) :string {
        return this.getHost() + RCI + SLASH + rciId + SLASH + RCI_CPU_STATS;
    }

    public getRciCmtsUsPortInfoUrl(cmtsUsPortId: number): string {
        return this.getRciCmtsUsPortInfoUpdateUrl() + "/" + cmtsUsPortId;
    }

    public getRciCmtsUsPortInfoUpdateUrl(): string {
        return this.getHost() + 'cmtsusport';
    }

	public getRciDeleteFirmwareUrl() {
		return this.getHost() + RCI + SLASH + RCI_FIRMWARE_UPGRADE;
	}

	public getRciTestUrl(rciId: number):string {
        return this.getHost() + RCI + SLASH + rciId + SLASH + RCI_TEST_CONNECTION;
    }

    public getRciTestButtonUrl(): string {
        return this.getHost() + RCI + SLASH + RCI_TEST_CONNECTION;
    }

	public getRciCmtsUsPortListUrl() {
		// return this.getHost() + RCI + SLASH + RCI_NODES;  //TODO: Change end points on back end to be "cmtsUsPorts" instead of nodes
        return this.getHost() + RCI + SLASH + RCI_CMTS_US_PORTS;
	}

	public getEnableRciCmtsUsPortSweepUrl() {
    	return this.getHost() + RCI + SLASH + RCI_CMTS_US_PORT_SWEEP_ENABLE;
	}

	public getExportRPHY_MappingUrl(): string {
        return this.getHost() + RCI + SLASH + RCI_RPHY+ SLASH + RCI_RPHY_EXPORT;
    }

    public getImportRPHY_MappingUrl(): string {
        return this.getHost() + RCI + SLASH + RCI_RPHY+ SLASH + RCI_RPHY_IMPORT;
    }

	public getDisableRciCmtsUsPortSweepUrl(cmtsUsPortId: number){
    	return this.getHost() + RCI + SLASH + RCI_CMTS_US_PORT_SWEEP_DISABLE + SLASH + cmtsUsPortId;;
	}

    public getMonitoringPlanPasteUrl():string {
        return this.getHost() + 'features/monitoringplan/cmtsusport/paste';
    }

    public getMonitoringExportPlanUrl(cmtsUsPortId: number):string {
        return this.getHost() + 'features/monitoringplan/cmtsusport/export/' + cmtsUsPortId.toString();
    }

    public getMonitoringImportPlanUrl():string {
        return this.getHost() + 'features/monitoringplan' +
            '' +
            '' +
            '' +
            '/cmtsusport/import';
    }

    // returns url to get rpm tab data
    public getRPMEventListUrl(elementId: number, type):string {
        return this.getHost() + "event/element/type/" + type+ "/id/" + elementId ;
    }

    public getThresholdLabelsUrl():string {
        return this.getHost() + 'settings/thresholds';
    }
}
