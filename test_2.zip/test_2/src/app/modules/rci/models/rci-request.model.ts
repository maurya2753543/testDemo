export class RciRequestModel{
	public rciResponseList: any[];
	public fileName: string;
}