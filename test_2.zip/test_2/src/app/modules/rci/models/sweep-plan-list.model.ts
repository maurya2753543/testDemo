/**
 * Created by jerry.blum on 04-17-2019.
 */
// export default class SweepPlanListModel extends Array {
// 	constructor(jsonData, localizationService ?: any){
// 		super();
//
// 		if(jsonData){
// 			for(let i=0; i<jsonData.length; i++){
// 				// let sweepPlanData: SweepPlanListItem = new SweepPlanListItem(jsonData[i]);
// 				this.push(sweepPlanData);
// 			}
// 		}
// 	}
//
// 	public decryptSweepPlanItem() :void {
// 		for(let i=0; i<this.length; i++){
// 			this[i].decryptData();
// 		}
// 	}
// }
//
// export class SweepPlanListItem {
// 	public id: number;
// 	public name: string;
//
// 	constructor(jsonData){
// 		this.id = jsonData.id;
// 		this.name = jsonData.name;
// 	}
// }

