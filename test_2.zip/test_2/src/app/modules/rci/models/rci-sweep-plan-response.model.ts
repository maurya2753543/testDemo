export class RciSweepPlanResponseModel{
	public id: number;
	public name: string;
}