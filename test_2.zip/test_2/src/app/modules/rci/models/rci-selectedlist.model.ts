export class RciSelectedlistModel {
	public listData: any[];
}