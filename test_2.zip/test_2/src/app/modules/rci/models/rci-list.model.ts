export class RciListModel extends Array{
    constructor(jsonData){
        super();

        if(jsonData){
            for(let i=0; i<jsonData.length; i++) {
                this.push(<RciListItem>jsonData[i]);
            }
        }
    }
}

export class RciListItem{
    public elementId: number;
    public name: string;
    public hostname: string;
    public firmwareVersion: string;
    public offline: boolean;
    public status: string;
    public cmtses: Array<number>;
    public accessed: string;
    public sweepCount: number;
    public spectrumCount: number;
    public apiCount: number;
    public assignedCmtsCount: number;
    public cmtsUsPortCount: number;
}