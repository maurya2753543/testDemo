export class RciFirmwareUpgradeModel {
	public filename: string;
	public lastmodified: string;
}