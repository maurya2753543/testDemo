export class RciCmtsUsPortListModel{
	public id: number;
	public cmtsUsPortName: string;
	public cmtsCcapName: string;
	public rciName: string;
	public monitoringPlanName: string;
	public sweepPlanId: number;
	public sweepPlanName: string;
	public hasRpd: boolean;
	public DAADevice;
	public DAASpectrumLicensed;
	public DAAMonitoringLicensed;
	public sweepDurationDurationTimeStamp: Date;
	public sweepEnabled: boolean;
	public lastUpdateDate: string;
	private errorCount:number;
	private pasteMonitoringMsg:string = "";

	constructor(modelData) {
		if (modelData) {
			this.id = modelData.id;
			this.lastUpdateDate = modelData.lastUpdateDate;
		}
	}

	public getPasteMonitoringErrorCount(obj:any, localizationService):any {
		this.errorCount = 0;
		for(var i=0; i<obj.length; i++) {
			if( obj[i].status != "SUCCESSFUL") {
				this.errorCount++;
			}
		}

		if(this.errorCount) {
			this.pasteMonitoringMsg = localizationService.instant('RCI_NODE_PASTE_ROW_FAILED_MSG') + this.errorCount + ' '+ localizationService.instant('RCIs')
		}else {
			this.pasteMonitoringMsg = localizationService.instant('RCI_NODE_MONITORING_PASTED_SUCCESS_MSG');
		}
		return this.pasteMonitoringMsg;
	}
}