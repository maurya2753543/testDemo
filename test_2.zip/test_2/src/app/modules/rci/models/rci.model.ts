export class RciModel {
    public elementId: number;
    public name: string;
    public hostname: string;
    public status: string;
    public offline: boolean;
    public cmtses: any[];
    public accessed: string;
    public rciServicePort: number;
    public upgradeServicePort: number;
    public https: boolean;
    public sweepCount: number = 4;
    public spectrumCount: number = 10;
    public apiCount: number = 8;
    public olVersion: number;
}
