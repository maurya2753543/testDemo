export class SweepPlanModel {
    public id: number;
    public name: string;
    public points: SweepPoints;
}

export class SweepPoints {
    public freqHz: number[];
}