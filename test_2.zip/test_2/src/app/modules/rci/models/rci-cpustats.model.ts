export class RciCpustatsModel {
    public softwareversion: string;
    public uptime: number;
    public numprocessors: number;
    public cpuload: string;
    public totalmemoryMB: number;
    public availmemoryMB: number;
    public totalDiskSpaceMB: number;
    public usedDiskSpaceMB: number;
    public diskSpaceAvail: number;
    public currenttime: number;
}