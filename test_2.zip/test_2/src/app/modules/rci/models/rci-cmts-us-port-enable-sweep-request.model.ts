export class RciCmtsUsPortEnableSweepRequestModel{
	public cmtsUsPortId: number;
	public sweepPlanId: number;
	public durationHours: number;
}