import { RciModel } from "./rci.model";

export class CmtsRci {
    public cmts: CmtsModel;
    public rcis: RciModel[];
    public get rciNames () { 
        return this.rcis == null ? null : this.rcis.map(r => r.name).join(', ');
    }
}

export class CmtsModel {
    public cmtsId: number;
    public name: string;
    public hostname: string;
}