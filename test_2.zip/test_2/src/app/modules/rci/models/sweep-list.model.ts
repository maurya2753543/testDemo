import { SweepPoints } from "./sweep-plan.model";

export class SweepPlanListItem {
    public id: number;
    public name: string;
}