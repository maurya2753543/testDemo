import { RciCmtsColumnDefinitionService } from './rci-grid/rci-view/rci-cmts.column-definition.service';
import { FormsModule } from '@angular/forms';
import { RciGridService } from './rci-grid/rci-grid.service';
//import { Locale, LocaleModule, LocalizationModule } from "angular2localization";
import { ReactiveFormsModule } from "@angular/forms";
import { LocaleDataService } from "../../shared/locale.data.service";
import { SharedModule } from "../shared/shared.module";
import { RciComponent } from "./rci.component";
import { NgModule } from "@angular/core";
import { RciRoutes } from "./rci.route";
import {RciGridComponent} from "./rci-grid/rci-grid.component";
import { CommonModule, registerLocaleData } from '@angular/common';
import {RciGridColumnDefinitionService} from "./rci-grid/rci-grid.column-definition.service";
import {RciGridDataService} from "./rci-grid/rci-grid.data.service";
import {RciUrlService} from "./rci.url.service";
import {RciHttpService} from "./rci.http.service";
import { RciViewComponent } from './rci-grid/rci-view/rci-view.component';
import { SweepGridComponent } from "./sweep-grid/sweep-grid.component";
import { SweepGridColumnDefinitionService } from "./sweep-grid/sweep-grid.column-definition.service";
import { SweepGridDataService } from "./sweep-grid/sweep-grid.data.service";
import { SweepViewComponent } from "./sweep-grid/sweep-view/sweep-view.component";
import { SweepGridSharedService } from "./sweep-grid/sweep-grid.shared.service";
import { SweepPointsColumnDefinitionService } from "./sweep-grid/sweep-view/sweep-points.column-definition.service";
import { AgGridModule } from "ag-grid-angular";
import { RciErrorService } from './rci.error.service';
import {RciCpustatsComponent} from "./rci-grid/rci-cpustats/rci-cpustats.component";
import {RciFirmwareUpgradeComponent} from './rci-grid/rci-firmwareUpgrade/rci-firmwareUpgrade.component';
import {RciFirmwareUpgradeColumnDefinition} from './rci-grid/rci-firmwareUpgrade/rci-firmwareUpgrade.column-definition';
import {RciSelectedGridColumnDefinitionService} from './rci-grid/rci-firmwareUpgrade/rci-selectedgrid.column.definition.service';
import {RciCmtsUsPortGridComponent} from './rci-cmts-us-port-grid/rci-cmts-us-port-grid.component';
import {RciCmtsUsPortGridColumnDefinitionService} from './rci-cmts-us-port-grid/rci-cmts-us-port-grid-column-definition.service';
import {RciCmtsUsPortGridService} from './rci-cmts-us-port-grid/rci-cmts-us-port-grid.service';
import {RciCmtsUsPortGridDataService} from './rci-cmts-us-port-grid/rci-cmts-us-port-grid-data.service';
import {RciCmtsUsPortSweepComponent} from './rci-cmts-us-port-grid/rci-cmts-us-port-sweep/rci-cmts-us-port-sweep.component';
import {RciCmtsUsPortSweepViewComponent} from './rci-cmts-us-port-grid/rci-cmts-us-port-sweep/rci-cmts-us-port-sweep-view.component';
import {RciViewEventComponent} from "./rci-grid/rci-view-event/rci-view-event.component";
import {ViewEventsColumnDefinitionService} from "../shared/common-components/listView/viewEvents.column-definition.service";
import {RciImportExportMonitoringPlanComponent} from "./rci-cmts-us-port-grid/rci-monitoringplan/RciImportExportMonitoringPlanComponent";
import {RciCmtsUsPortEditComponent} from "./rci-cmts-us-port-grid/rci-cmts-us-port-edit/rci-cmts-us-port-edit.component";
import {CMTSViewEvent} from "./rci-cmts-us-port-grid/view-events/view-event.component";
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import localeDe from "@angular/common/locales/de";
import localeEs from "@angular/common/locales/es";
import localeFr from "@angular/common/locales/fr";
import localeJa from "@angular/common/locales/ja";
import localeZh from "@angular/common/locales/zh";
import localeZhHans from "@angular/common/locales/zh-Hans";
import localeZhHansHk from "@angular/common/locales/zh-Hant-HK";

import { HttpClient } from '@angular/common/http';
import { LanguageService } from 'src/app/shared/locale.language.service';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';
import { SweepImportComponent } from './sweep-grid/sweep-import/sweep-import.component';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/rci-locale-`, ".json");
  }
@NgModule({
    imports: [
        AgGridModule,
        SharedModule,
        RciRoutes,
        // LocaleModule.forRoot(),
        // LocalizationModule.forRoot(),
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),
    ],
    declarations: [
        CMTSViewEvent,
        RciComponent,
        RciGridComponent,
        RciViewComponent,
        SweepGridComponent,
        SweepViewComponent,
        RciCpustatsComponent,
        RciImportExportMonitoringPlanComponent,
        RciFirmwareUpgradeComponent,
        RciCmtsUsPortGridComponent,
		RciCmtsUsPortSweepComponent,
		RciCmtsUsPortSweepViewComponent,
        RciViewEventComponent,
        RciCmtsUsPortEditComponent,
        SweepImportComponent
    ],
    entryComponents: [
        RciComponent,
        RciGridComponent,
        RciViewComponent,
        SweepGridComponent,
        SweepViewComponent,
        RciCmtsUsPortEditComponent,
        SweepImportComponent
    ],
    providers: [
        LocaleDataService,
        RciGridColumnDefinitionService,
        RciGridDataService,
        RciHttpService,
        RciUrlService,
        RciGridService,
        RciErrorService,
        RciCmtsColumnDefinitionService,
        SweepGridColumnDefinitionService,
        SweepGridDataService,
        SweepGridSharedService,
        SweepPointsColumnDefinitionService,
		RciFirmwareUpgradeColumnDefinition,
		RciSelectedGridColumnDefinitionService,
		RciCmtsUsPortGridColumnDefinitionService,
        RciCmtsUsPortGridService,
        RciCmtsUsPortGridDataService,
        ViewEventsColumnDefinitionService,
        TranslateService
    ]
})
export  class RciModule {

}
