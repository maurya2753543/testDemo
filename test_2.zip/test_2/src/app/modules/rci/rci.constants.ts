export const SLASH: string = "/";
export const RCI: string = "rci";
export const SYNC: string = "sync";

export const RCI_SWEEP_PLAN = "rcisweepplan";
export const RCI_REBOOT = "reboot";
export const RCI_FIRMWARE_UPGRADE = "firmware";
export const RCI_VIEW_LOG = "viewLog";
export const RCI_CPU_STATS = "cpustats";
export const RCI_TEST_CONNECTION = "ping";
export const RCI_CMTS_US_PORTS = "cmtsusports";
export const FIRST_SELECT_OPTION = "-- Select ";
export const RCI_SWEEP_PLAN_SELECT = "Sweep Plan";
export const RCI_CMTS_US_PORT_SWEEP_ENABLE = "enablesweep";
export const RCI_CMTS_US_PORT_SWEEP_DISABLE = "disablesweep";
export const RCI_CMTS_US_PORT_TEXT = "cmtsusport";
export const RCI_CMTS_US_PORT_PASTE = "paste";
export const RCI_CMTS_US_PORT_IMPORT = "import";
export const RCI_CMTS_US_PORT_EXPORT = "export";
export const NODE = "node";
export const PASTE_CMTS = "paste";

export const RCI_RPHY_EXPORT: string = "export";
export const RCI_RPHY_IMPORT: string = "import";
export const RCI_RPHY: string = "rpdportmac";