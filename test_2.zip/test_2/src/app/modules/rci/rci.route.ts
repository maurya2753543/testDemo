import { Routes, RouterModule } from '@angular/router';
import {RciComponent} from "./rci.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: RciComponent, pathMatch: 'prefix' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class RciRoutes{}
//export const RciRoutes: Routes = [{ path: "", component: RciComponent, pathMatch: 'prefix' }];
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);