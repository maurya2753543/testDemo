import { TranslateService } from '@ngx-translate/core';
//import { LocalizationService } from "angular2localization";

export class SweepPointsColumnDefinitionService {
    private frequencyHeader = { name: 'FREQUENCY_MHZ', field: 'freqMhz' };

    private getFreqColumn(ls: TranslateService) {
        return {
            headerName: ls.instant(this.frequencyHeader.name),
            headerTooltip: ls.instant(this.frequencyHeader.name),
            field: this.frequencyHeader.field,
            filter: 'text',
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {suppressAndOrCondition: true},
            sort:'asc',
            comparator: (a, b, rowA, rowB) => rowA.data.freqHz - rowB.data.freqHz
        };
    }

    public getColumnDef(ls: TranslateService): any[] {
        return [
            {
                headerName: '',
                width: 21,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true},
                suppressResize: true
            }, 
            this.getFreqColumn(ls)
        ];
    }

    public getReadOnlyColumnDef(ls: TranslateService) {
        return [this.getFreqColumn(ls)];
    }

}