import { TranslateService } from '@ngx-translate/core';
import { Component, Input } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
// import { LocalizationService } from 'angular2localization';
import { BehaviorSubject, Observable } from 'rxjs';

import { ALERT_ERROR } from '../../../../constant/app.constants';
import { CommonStrings } from '../../../../constant/common.strings';
import {
    ClearEditorTabEvent,
    DeleteItemTabEvent,
    SaveNewItemTabEvent,
    UpdateItemTabEvent,
} from '../../../../shared/tab-event';
import { ThemeService } from '../../../../shared/theme.service';
import {ShowAlert} from '../../../../utilities/showAlert';
import { SweepPlanModel, SweepPoints } from '../../models/sweep-plan.model';
import { SweepGridDataService } from '../sweep-grid.data.service';
import { SweepGridSharedService } from '../sweep-grid.shared.service';
import { SweepPointsColumnDefinitionService } from './sweep-points.column-definition.service';
import {LanguageService} from '../../../../shared/locale.language.service';
import { COMMA, DOT } from "../../../../constant/app.constants";
import {AgGridConfigurationService} from "../../../../shared/agGrid.configuration.service";
import { map } from 'rxjs/operators';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
    selector: 'sweep-view',
    templateUrl: 'sweep-view.component.html'
})
export class SweepViewComponent {
    private mhzToHzFactor = 1e6;
    private lang: string;
    public sweepPlanForm: FormGroup;
    private pointGridData = new BehaviorSubject<FreqPoint[]>([]);
    private pointCount: Observable<string>;
    public closeSlider = new BehaviorSubject<boolean>(true);
    private isCreate = false;
    private isEdit = false;
    private pointGridOptions: GridOptions;
    private readOnlyPointGridOptions: GridOptions;
    private acceptComma: boolean = false;
    private inputPattern: string = '';
    public tooltipMsg:boolean;

    private _ls: TranslateService;
    private get ls(): TranslateService { return this._ls; }
    @Input("localizationService") private set ls(value: TranslateService) {
        this._ls = value;
        this.setupGrid();
    }
    private _sweepModel: SweepPlanModel;
    private get sweepModel(): SweepPlanModel { return this._sweepModel; }
    @Input() private set sweepModel(value: SweepPlanModel) {
        this._sweepModel = value;
        this.closeSlider.next(value == null);
        this.setupForm();
        this.setPoints(value == null ? null : value.points.freqHz);
    };

    constructor(
        private agGridConfigurationService:AgGridConfigurationService,
        private sweepGridService: SweepGridDataService,
        private fb: FormBuilder,
        private ThemeService: ThemeService,
        private sharedService: SweepGridSharedService,
        private pointGridColumnService: SweepPointsColumnDefinitionService,
        private alert: ShowAlert,
        private languageService : LanguageService,
        private _sharedService:SharedService) {
        this.pointCount = this.pointGridData
            .pipe(map(p => {
                if (p.length == 0) return '';

                return `${this.ls.instant('POINT_COUNT')}: ${p.length}`;
            }));
        this.lang = this.languageService.getCurrentLanguage();
        let langArr : string[] = ['es', 'de', 'fr'];
        if(langArr.some(code => code == this.lang)) {
            this.acceptComma = true;
            this.inputPattern = '[0-9]+([\,][0-9]{1,3})?';
        }
        else {
            this.acceptComma = false;
            this.inputPattern = '[0-9]+([\.][0-9]{1,3})?';
        }
    }

    ngOnInit() {
        this.readOnlyPointGridOptions.getMainMenuItems = this.getReadOnlyPointGridOptions.bind(this);
        this.pointGridOptions.getMainMenuItems = this.getPointGridOptions.bind(this);
    }


    /*
  *@name getMainMenuItems
  *@desc adds menu items and functionality
  *@return any
  */
    private getReadOnlyPointGridOptions(params: any): any{
        let arr = params.defaultItems; /* comments:- Specify the type of the variable */
        arr.splice(2,6);
        let newMenu: any[] = arr;
        this.agGridConfigurationService.setMenuOption(newMenu, this.readOnlyPointGridOptions, params);
        return newMenu;
    }

    /*
   *@name getMainMenuItems
   *@desc adds menu items and functionality
   *@return any
   */
    private getPointGridOptions(params: any): any{
        let arr = params.defaultItems; /* comments:- Specify the type of the variable */
        arr.splice(2,6);
        let newMenu: any[] = arr;
        this.agGridConfigurationService.setMenuOption(newMenu, this.pointGridOptions, params);
        return newMenu;
    }

    private setupForm() {
        if (this.sweepModel == null) {
            this.sweepPlanForm = null;
            return;
        }

        this.isCreate =
            this.isEdit = this.sweepModel.id == null;

        this.sweepPlanForm = this.fb.group({
            planProperties: this.fb.group({
                name: this.fb.control(this.sweepModel.name, Validators.required),
            }),
            sweepPoints: this.fb.group({
                multiPoint: this.fb.group({
                    multiPointStart: this.fb.control(5, [this.sweepRangeValidator]),
                    multiPointStop: this.fb.control(42, [this.sweepRangeValidator]),
                    multiPointStep: this.fb.control(6, [this.stepRangeValidator]),
                }, { validator: this.startGreaterThanStop('multiPointStart', 'multiPointStop') }),
                singlePointCenter: this.fb.control(null, [this.sweepRangeValidator])
            })
        });
    }

    private sweepRangeValidator(control: AbstractControl): any {
        if (control.value > 204 || control.value < 4) {
            return { invalidRange: true };
        }


    }


    // Center Tooltip Validation
        onKey(control: AbstractControl):any { 
            var regex = /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i;
            
            if(control.value > 204 || control.value < 4 || !regex){ 
                this.tooltipMsg = false
            }else{
                this.tooltipMsg = true
            }
        }

    private startGreaterThanStop(startProp: string, stopProp: string) {
        return (g: FormGroup) => {
            let startPropValue = parseFloat(g.controls[startProp].value.toString().replace(COMMA,DOT));
            let stopPropValue = parseFloat(g.controls[stopProp].value.toString().replace(COMMA,DOT));
            if (startPropValue >= stopPropValue) {
                return { startGreaterThanStop: true };
            }
        }
    }

    
    private stepRangeValidator(control: AbstractControl): any {
        if (control.value > 204 || control.value < 0.1) {
            return { invalidStep: true };
        }
    }

    private setPoints(freqHz: number[]) {
        if (freqHz == null) { this.pointGridData.next([]); }
        else {
            this.pointGridData.next(freqHz.map(p => new FreqPoint(p, this._sharedService)));
        }
    }

    getFormSweepPlan(): SweepPlanModel {
        let points: SweepPoints = { freqHz: [] };
        this.pointGridOptions.api.forEachNode(row => points.freqHz.push(row.data.freqHz));
        return {
            id: this.sweepModel.id,
            name: this.name.value,
            points: points
        };
    }

    // Button Event Handlers

    onSubmit() {
        let plan = this.getFormSweepPlan();
        this.sharedService.emitTabEvent(this.isCreate ? new SaveNewItemTabEvent(plan) : new UpdateItemTabEvent(plan));
    }

    delete() { this.sharedService.emitTabEvent(new DeleteItemTabEvent(this.sweepModel)); }

    closeEditor() { this.sharedService.emitTabEvent(new ClearEditorTabEvent()); }

    enableEdit() { this.isEdit = true; }

    // Form Properties
    private get planProperties() { return this.sweepPlanForm.get('planProperties'); }
    private get name() { return this.planProperties.get('name'); }
    private get sweepPoints() { return this.sweepPlanForm.get('sweepPoints'); }
    private get multiPoint() { return this.sweepPoints.get('multiPoint'); }
    private get multiPointStart() { return this.multiPoint.get('multiPointStart'); }
    private get multiPointStop() { return this.multiPoint.get('multiPointStop'); }
    private get multiPointStep() { return this.multiPoint.get('multiPointStep'); }
    private get singlePointCenter() { return this.sweepPoints.get('singlePointCenter'); }

    // Sweep Point Grid Setup

    setupGrid() {
        this.pointGridOptions = <GridOptions>{
            suppressContextMenu: true,
            rowSelection: 'multiple',
            enableSorting: true,
            localeText: this.getLocalText(),
            columnDefs: this.pointGridColumnService.getColumnDef(this.ls)
        };

        this.readOnlyPointGridOptions = <GridOptions>{
            suppressContextMenu: true,
            enableSorting: true,
            localeText: this.getLocalText(),
            columnDefs: this.pointGridColumnService.getReadOnlyColumnDef(this.ls)
        }
    }

    private getLocalText(): any {
        return {
            noRowsToShow: CommonStrings.AG_GRID_NO_ROWS_TO_SHOW,
            filterOoo : CommonStrings.FILTER,
            equals : CommonStrings.FILTER_EQUALS,
            notContains : CommonStrings.FILTER_NOT_CONTAINS,
            startsWith : CommonStrings.FILTER_STARTS_WITH,
            endsWith : CommonStrings.FILTER_ENDS_WITH,
            pinColumn : CommonStrings.PIN_COLUMN_MAIN_MENU,
            pinLeft : CommonStrings.PIN_LEFT,
            pinRight : CommonStrings.PIN_RIGHT,
            noPin : CommonStrings.NO_PIN,
            contains : CommonStrings.FILTER_CONTAINS
        }
    }

    pointGridButtons() {
        return [{ name: this.ls.instant('DELETE_SELECTED'), action: 'DELETE_SELECTED' }];
    }

    deleteSelectedPoints() {
        let updated = [];
        this.pointGridOptions.api.forEachNode(row => {
            if (!row.isSelected()) updated.push(row.data);
        });

        this.pointGridData.next(updated);
    }

    addSweepPoints(points: FreqPoint[]) {
        let updated = points.reduce((map, point) => {
            map.set(point.freqHz, point);
            return map;
        }, new Map<number, FreqPoint>());

        // Add existing back to updated
        this.pointGridOptions.api.forEachNode(row => {
            updated.set(row.data.freqHz, row.data);
        });

        let newPoints = Array.from(updated.values());
        if (newPoints.length > 300) {
            this.alert.showSimpleAlert(ALERT_ERROR, this.ls.instant('TOO_MANY_SWEEP_POINTS'));
            return;
        }

        this.pointGridData.next(newPoints);
    }

    addMultipleSweepPoints() {
        let result = [];
        let startValue: number, stopValue: number, stepValue: number;
        if(this.acceptComma) {
            startValue = parseFloat(this.multiPointStart.value.toString().replace(COMMA,DOT));
            stopValue = parseFloat(this.multiPointStop.value.toString().replace(COMMA,DOT));
            stepValue = parseFloat(this.multiPointStep.value.toString().replace(COMMA,DOT));
        } else {
            startValue = parseFloat(this.multiPointStart.value);
            stopValue = parseFloat(this.multiPointStop.value);
            stepValue = parseFloat(this.multiPointStep.value);
        }
        for (let i = startValue; i < stopValue; i += stepValue) {
            result.push(new FreqPoint(i * this.mhzToHzFactor, this._sharedService));
        }

        this.addSweepPoints(result);
    }

    addSingleSweepPoint() {
        let singlePointValue: number;
        if(this.acceptComma) {
            singlePointValue = parseFloat(this.singlePointCenter.value.toString().replace(COMMA,DOT));
        } else {
            singlePointValue = parseFloat(this.singlePointCenter.value);
        }
        this.addSweepPoints([new FreqPoint(singlePointValue * this.mhzToHzFactor, this._sharedService)]);
    }

    hasPoints() {
        if(this.pointGridOptions.api == null) { return false; }
        let hasPoints = false;
        this.pointGridOptions.api.forEachNode(n => hasPoints = true);
        return hasPoints;
    }

    hasSelectedPoints() {
        if (this.pointGridOptions.api == null) { return false; }

        return this.pointGridOptions.api.getSelectedRows().length > 0;
    }

    onGridResize(event) {
        if (event.api) {
            event.api.sizeColumnsToFit();
        }
    }
}

export class FreqPoint {
    public freqHz: number;
    public freqMhz: string;


    constructor(freqHz: number, sharedService:SharedService) {
        this.freqHz = freqHz;
        this.freqMhz = (freqHz / 1e6).toFixed(3);
        if(sharedService) {
            this.freqMhz = sharedService.toDecimal(
              parseFloat(this.freqMhz), '1.3-3');
        }
    }
}
