import { TranslateService } from '@ngx-translate/core';
import { Injectable } from "@angular/core";
//import { LocalizationService } from "angular2localization/src/services/localization.service";
import { EDIT_ICON } from "../../../constant/app.constants";
import { DisabledFilter } from "../../shared/grid/disabled.filter";
import { SweepGridSharedService } from "./sweep-grid.shared.service";
import { TabAction, EditItemTabEvent } from "../../../shared/tab-event";

@Injectable()
export class SweepGridColumnDefinitionService {

    private _HEADER_FIELDS: any = {
        name : {field: "name", name: "SWEEP_PLAN_NAME"},
        view : {field: "view", name: "RCI_HEADER_VIEW"}
    };

    constructor(private sharedService: SweepGridSharedService) {}

    public getColumnDef(ls: TranslateService): any[] {
        return [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            }, {
                headerName: ls.instant(this._HEADER_FIELDS.name.name),
                headerTooltip: ls.instant(this._HEADER_FIELDS.name.name),
                field: this._HEADER_FIELDS.name.field,
                minWidth: 400,
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                sort:'asc',
                resizable:true
            }, {
                colId: 'edit',
                headerName: ls.instant(this._HEADER_FIELDS.view.name),
                headerTooltip: ls.instant(this._HEADER_FIELDS.view.name), 
                field: this._HEADER_FIELDS.view.field,
                minWidth: 70, 
                maxWidth: 120,
				pinned: 'right',
                width: 70,
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.viewItem(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            }
        ];
    }

    viewItem(param: any) {
        this.sharedService.emitTabEvent(new EditItemTabEvent(param.data));
    }
}