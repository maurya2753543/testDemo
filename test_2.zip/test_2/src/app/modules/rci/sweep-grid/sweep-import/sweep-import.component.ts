import {Component, EventEmitter, Output, OnInit} from '@angular/core';
import {ALERT_ERROR} from '../../../../constant/app.constants';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ShowAlert} from '../../../../utilities/showAlert';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import * as AppConstants from '../../../../constant/app.constants';
import { Observable } from 'rxjs';
import { SweepGridDataService } from '../sweep-grid.data.service';
import { RefreshListTabEvent, SaveNewItemTabEvent } from 'src/app/shared/tab-event';
import { SweepGridSharedService } from '../sweep-grid.shared.service';
import { SweepPlanModel } from '../../models/sweep-plan.model';

@Component({
  selector: 'app-sweep-import',
  templateUrl: './sweep-import.component.html'
})
export class SweepImportComponent implements OnInit {
  public closeSlider: Observable<boolean>;
	@Output() onCloseSlider: EventEmitter<any> = new EventEmitter<any>();
	
	private isValidCSVFile: boolean = false;
	public form: FormGroup;
	private tag: string = "ImportSweepPlanComponent ::";

	private IMPORT_RCI_SUCCESS: string = '';
	private IMPORT_FILE_INVALID: string = '';
	private IMPORT_RCI_ERROR: string = '';

	// Form Properties
	private get file() {
		return this.form.get('file');
	}
	
	constructor(private sweepTabDataService: SweepGridDataService,
				private showAlert: ShowAlert, private fb: FormBuilder,
				private sharedGridService: SweepGridSharedService,
				private localeDataService: LocaleDataService){
	}

	private getFormProperties(): any {
		const formatProperties: any = {
			file: this.fb.control(null, Validators.required)
		}

		return formatProperties;
	}

	private buildForm(): FormGroup {
		return this.fb.group(this.getFormProperties());
	}

	ngOnInit() {
		this.form = this.buildForm();
		this.translateLocaleString();
	}

	// Cancels out of the modem import editor without submitting the form.
	private onCancel(): void {
		this.sharedGridService.enableImportSweepSlider.next(false);
	}

	// Add imported Sweep Plan' to server on submit
	private onSubmit(): void {
		const fileData = this.file.value;
		if(fileData.planName && fileData.sweepPoints) {
			const requestData: SweepPlanModel = {
				id: undefined,
				name: fileData.planName,
				points: { freqHz: fileData.sweepPoints }
			};
			this.sharedGridService.emitTabEvent(new SaveNewItemTabEvent(requestData));
		} else {
			this.showAlert.showSuccessAlert(this.IMPORT_FILE_INVALID, true, ALERT_ERROR);
		}
	}

	private fileChange(event: any): void {
		console.log('file change', event.target)
		const target: any = event.target;
		
		this.isValidCSVFile = target.value && target.value.endsWith('.json');
		if (this.isValidCSVFile) {
			var reader = new FileReader();
			var self:any = this;
			reader.onload = (event: any) => {
				const value = event.target.result;
				if(value) {
					const parsedData = JSON.parse(value.replace(/\\"|"(?:\\"|[^"])*"|(\/\/.*|\/\*[\s\S]*?\*\/)/g, (m, g) => g ? "" : m));
					self.file.setValue(parsedData);
				}
			}
			reader.readAsText(event.target.files[0]);
		} else {
			this.showAlert.showSuccessAlert(this.IMPORT_FILE_INVALID, true, ALERT_ERROR);
		}
	}

	// Sets up localization resources used by this component.
	private translateLocaleString(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this.IMPORT_RCI_SUCCESS = localizationService.instant('IMPORT_RCI_SUCCESS');
		this.IMPORT_FILE_INVALID = localizationService.instant('IMPORT_FILE_INVALID');
		this.IMPORT_RCI_ERROR = localizationService.instant('IMPORT_RCI_ERROR');
	}

}
