import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SweepImportComponent } from './sweep-import.component';

describe('SweepImportComponent', () => {
  let component: SweepImportComponent;
  let fixture: ComponentFixture<SweepImportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SweepImportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SweepImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
