import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {RciHttpService} from '../rci.http.service';
import {map, catchError} from "rxjs/operators";
import { Observable, throwError } from 'rxjs';
import { SweepPlanModel } from '../models/sweep-plan.model';
// import SweepPlanListModel from '../models/sweep-plan-list.model';
import {LocaleDataService} from '../../../shared/locale.data.service';
import {RciSweepPlanResponseModel} from '../models/rci-sweep-plan-response.model';

@Injectable()
export class SweepGridDataService {
    private sweepPlanModelList;

    constructor(private rciHttpService: RciHttpService,
				private localeDataService: LocaleDataService) {}

    public getSweepPlanList(): Observable<any[]> {
        return this.rciHttpService.getSweepPlanList().pipe(catchError(this.handleError))
    }

    public addSweepPlan(sweepPlan: SweepPlanModel): Observable<any> {
        return this.rciHttpService.addSweepPlan(sweepPlan);
    }

    public updateSweepPlan(sweepPlan: SweepPlanModel): Observable<any> {
        return this.rciHttpService.updateSweepPlan(sweepPlan);
    }

    public deleteSweepPlan(sweepPlanId: number): Observable<any> {
        return this.rciHttpService.deleteSweepPlan(sweepPlanId);
    }

	//Error handler
	public handleError(error) {
		return throwError(error);
	}
}