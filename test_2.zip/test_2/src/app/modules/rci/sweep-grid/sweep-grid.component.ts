import { Component } from '@angular/core';
//import { LocalizationService } from 'angular2localization/src/services/localization.service';
import { Observable, Subject, of, BehaviorSubject } from 'rxjs';
import { map , filter,combineLatest, merge} from 'rxjs/operators';

import { GRID_COMP_KEY_MULTI, GRID_COMP_KEY_ONLY_SINGLE, GRID_COMP_KEY_SINGLE } from '../../../constant/app.constants';
import { Grid } from '../../../shared/ag-grid.options';
import { LocaleDataService } from '../../../shared/locale.data.service';
import { AddItemTabEvent, DeleteItemTabEvent, RefreshListTabEvent, TabAction, TabEvent } from '../../../shared/tab-event';
import { SweepPlanListItem } from '../models/sweep-list.model';
import { SweepPlanModel } from '../models/sweep-plan.model';
import { SweepGridColumnDefinitionService } from './sweep-grid.column-definition.service';
import { SweepGridSharedService } from './sweep-grid.shared.service';
import { TranslateService } from '@ngx-translate/core';
import { DomSanitizer } from '@angular/platform-browser';
import * as FileSaver from 'file-saver';

@Component({
    selector: 'sweep-grid-component',
    templateUrl: 'sweep-grid.component.html'
})
export class SweepGridComponent {
    public localizationService: Observable<any>;
    public gridOptions: Observable<Grid>;
    public sweepTabGridOptions: Grid = new Grid();
    public buttonKeys: Observable<Object[]>;
    public eventKeys: Observable<Object[]>;
    public refreshBtnFlag: Observable<boolean>;
    public showAllLabel: Observable<string>;
    public showAllLabelMob: Observable<string>;
    private gridApi: any;
    public rowData: Observable<SweepPlanListItem[]>;
    private gridModelUpdated = new Subject();
    public sweepPlanModel: Observable<SweepPlanModel>;
    public exportFileName = 'SweepPlanExport';
    public enableImportSweepSlider: any = this.sharedGridService.enableImportSweepSlider;
    public downloadJsonHref: any;
    constructor(
        private columnDefinitionService: SweepGridColumnDefinitionService,
        private localeDataService: LocaleDataService,
        private sharedGridService: SweepGridSharedService,
        public translate: TranslateService,
        private sanitizer: DomSanitizer
    ) {
        this.localizationService = this.localeDataService.isReady
        .pipe(filter(ready => ready),
        map(r => this.localeDataService.getLocalizationService()))

        this.sweepPlanModel = this.sharedGridService.sweepPlanModel.asObservable();
        this.rowData = this.sharedGridService.sweepPlanListModel;
        this.refreshBtnFlag = this.localeDataService.isReady;
        this.gridOptions = this.localizationService.pipe(map(ls => {
            let result = new Grid();
            result.setColumnDefs(this.columnDefinitionService.getColumnDef(ls));
            return result;
        }))

        this.setupCounts();
        this.setupButtons();
    }
    public notifyFilterChangeSWEEP(event): any{
        this.sharedGridService.sweepgridfilterchangedata = this.gridApi.getFilterModel();
        console.log("filterchange data",this.sharedGridService.sweepgridfilterchangedata);
    }
    private setupCounts() {
        let totalCount = this.rowData.pipe(map(r => r.length));
        let rowCount = this.gridModelUpdated // when the model is updated
            .pipe(combineLatest(this.gridOptions), // get latest grid options
            filter(result => result[1].api != null), // when the grid api is not null
            map(result => result[1].api.getDisplayedRowCount()), // and retrieve the displayed row count
            merge(totalCount)); // or take the total count of data

        let counts = this.localizationService.pipe(combineLatest(totalCount, rowCount));
        this.showAllLabel = counts
            .pipe(map(result => {
                let ls = result[0];
                let totalCount = result[1];
                let rowCount = result[2];
                return `${this.translate.instant('TABLE_LIST_SHOWING')} ${rowCount} ${this.translate.instant('TABLE_LIST_SHOWING_OF')} ${totalCount} ${this.translate.instant('TABLE_LIST_ROWS')}`;
            }));

        this.showAllLabelMob = counts.pipe(map(count => `${count[2]}/${count[1]}`));
    }
    public gridReady(param): void{
        this.gridApi =param.api;
        if(this.gridApi && this.sharedGridService.sweepgridfilterchangedata){
            this.gridApi.setFilterModel(this.sharedGridService.sweepgridfilterchangedata);            
            console.log("filter executed",this.sharedGridService.sweepgridfilterchangedata);
        }

    }
    private setupButtons() {
        this.buttonKeys = of([
            { name: this.translate.instant('IMPORT_SWEEP_PLAN'), action: TabAction.IMPORT_RPHY_MAPPING },
            { name: this.translate.instant('ADD_SWEEP_PLAN'), action: TabAction.ADD_ITEM }
        ]);
        this.eventKeys =of([
            { name: this.translate.instant('TABLE_LIST_EXPORT_SWEEP'), status: GRID_COMP_KEY_ONLY_SINGLE, action: 'JSON'},
            { name: this.translate.instant('DELETE_SELECTED'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.DELETE_ITEM },
            { name: this.translate.instant('TABLE_LIST_EXPORT_SELECTED'), status: GRID_COMP_KEY_SINGLE },
            { name: this.translate.instant('TABLE_LIST_EXPORT_ALL'), status: GRID_COMP_KEY_MULTI }
        ]);
    }

    // EVENT HANDLERS

    public gridModelUpdatedEmitter(params:any) {
        this.gridModelUpdated.next();
    }

    public notifyRefreshGrid(params:any) {
        this.sharedGridService.emitTabEvent(new RefreshListTabEvent());
    }

    public notifyActionEmitter(context) {
        let event: TabEvent;
        switch(context.event.action) {
            case TabAction.ADD_ITEM: 
                event = new AddItemTabEvent();
                break;
            case TabAction.IMPORT_RPHY_MAPPING: 
            this.sharedGridService.enableImportSweepSlider.next(true);
                break;
            case 'JSON': 
                this.generateJSON(context);
                break;
            case TabAction.DELETE_ITEM:
                event = new DeleteItemTabEvent(context.selectedData[0]);
                break;
            default: throw new Error('Unhandled button event: ' + context.event.action);
        }
        this.sharedGridService.emitTabEvent(event);
    }

    generateJSON(context: any) {
        const data = this.jsonMapping(context.selectedData);
        data && data.forEach(elem => {
            this.convertToJson(elem);
            console.log('generate JSON', data);
        })
    }

    convertToJson(data: any) {
        let filename = data.planName + ".json";
        let contentType = "application/json;charset=utf-8;";
        let a = document.createElement('a');
        a.download = filename;
        a.href = 'data:' + contentType + ',' + encodeURIComponent(JSON.stringify(data));
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }

    jsonMapping(data: any) {
        if(data && data.length) {
            let arr: any[] = [];
            console.log('data',data);
            data.forEach(element => {
                const obj = {
                    uid: element.id,
                    planName: element.name ? element.name.trim() : '',
                    sweepPoints: element.points ? element.points['freqHz'] : []
                }
                arr.push(obj);
            });
            return arr;
        }
        return [];
    }
}