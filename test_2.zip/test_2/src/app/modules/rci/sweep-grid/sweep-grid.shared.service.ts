import { Injectable } from "@angular/core";
import { Subject, BehaviorSubject, Observable } from "rxjs";
import { map , repeatWhen, filter, take, tap} from 'rxjs/operators';
import { SweepPlanModel, SweepPoints } from "../models/sweep-plan.model";
import { SweepGridDataService } from "./sweep-grid.data.service";
import {ShowAlert} from "../../../utilities/showAlert";
import { Logger } from "../../../utilities/logger";
import { TabAction, TabEvent, SaveNewItemTabEvent, UpdateItemTabEvent, DeleteItemTabEvent, EditItemTabEvent } from "../../../shared/tab-event";
import { SweepPlanListItem } from "../models/sweep-list.model";
import { LocaleDataService } from "../../../shared/locale.data.service";
import { RciErrorService } from "../rci.error.service";

/**
 * SweepGridSharedService supplies and handles changes to the state of the current SweepPlanModel and the Grid's list of SweepPlanListItems. 
 */
@Injectable()
export class SweepGridSharedService {

    /**
     * The currently selected SweepPlanModel for the editor. If null, no item is selected for editing.
     */
    
    public readonly enableImportSweepSlider = new BehaviorSubject<boolean>(false);
    public readonly sweepPlanModel = new BehaviorSubject<SweepPlanModel>(null);
    public readonly sweepPlanListModel: Observable<SweepPlanListItem[]>;
    public sweepgridfilterchangedata: any;
    private listUpdated = new Subject();

    constructor(
        private dataService: SweepGridDataService,
        private showAlert: ShowAlert,
        private logger: Logger,
        private localeDataService: LocaleDataService,
        private rciErrorService: RciErrorService) {
        this.sweepPlanListModel = this.dataService.getSweepPlanList().pipe(repeatWhen(l => this.listUpdated));
    }

    public emitTabEvent(event: TabEvent) {
        switch (event && event.action) {
            case TabAction.SAVE_NEW_ITEM:
                this.handleEditorRequest(this.dataService.addSweepPlan((<SaveNewItemTabEvent>event).data));
                break;
            case TabAction.UPDATE_ITEM:
                this.handleEditorRequest(this.dataService.updateSweepPlan((<UpdateItemTabEvent>event).data));
                break;
            case TabAction.ADD_ITEM:
                this.sweepPlanModel.next(this.createEmptySweepPlan());
                break;
            case TabAction.DELETE_ITEM:
                this.confirmAndDelete(<DeleteItemTabEvent>event);
                break;
            case TabAction.EDIT_ITEM:
                this.sweepPlanModel.next((<EditItemTabEvent>event).data);
                break;
            case TabAction.CLEAR_EDITOR:
                this.sweepPlanModel.next(null);
                break;
            case TabAction.REFRESH_LIST:
                this.listUpdated.next();
                break;
        }
    }

    private confirmAndDelete(event: DeleteItemTabEvent) {
        this.localeDataService.isReady
            .pipe(filter(r => r),
            map(r => this.localeDataService.getLocalizationService()),
            take(1))
            .subscribe(ls => {
                this.showAlert.showCustomWarningAlertConfirm(ls.instant('REMOVE_SWEEP_PLAN'), ls.instant('REMOVE_SWEEP_PLAN_CONFIRM'),
                    (isConfirm) => {
                        if (isConfirm) {
                            this.handleEditorRequest(this.dataService.deleteSweepPlan(event.data.id));
                        }
                    }
                );
            });
    }

    /**
     * Handles requests related to the currently editing sweep plan. This will close the editor once the request is successful.
     * @param request The request being sent
     */
    private handleEditorRequest(request: Observable<any>) {
        request
            .pipe(take(1),
            tap(r => this.listUpdated.next()))
            .subscribe(r => {
                this.sweepPlanModel.next(null);
                this.enableImportSweepSlider.next(false);
            }, err => {
                let error = err.json();
                this.logger.error("onError():  error data=", error);
                this.rciErrorService.showError(error);
            });
    }

    private createEmptySweepPlan() {
        let result = new SweepPlanModel();
        result.points = new SweepPoints();
        result.points.freqHz = [];
        return result;
    }
}