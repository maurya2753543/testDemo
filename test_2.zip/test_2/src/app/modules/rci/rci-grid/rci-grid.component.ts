import { Component, OnDestroy } from '@angular/core';
//import { LocalizationService } from 'angular2localization';
import {TranslateService} from '@ngx-translate/core';
import { Observable, Subject, of } from 'rxjs';
import { map ,filter,combineLatest, merge} from 'rxjs/operators';

import { GRID_COMP_KEY_MULTI, GRID_COMP_KEY_ONLY_SINGLE, GRID_COMP_KEY_SINGLE } from '../../../constant/app.constants';
import {
	AddItemTabEvent,
	DeleteItemTabEvent,
	ExportLogMessageTabEvent,
	FirmwareUpgradeShowTabEvent,
	HideRciCpuStatsTabEvent,
	HideRciFirmwareUpgradeTabEvent,
	RefreshListTabEvent,
	RemoteRebootTabEvent,
	RetrieveRciCpuStatsTabEvent,
	TabAction,
	TabEvent, TestRciConnectionTabEvent,
	SyncSelectedTabEvent,
	SyncAllTabEvent,
    UpdateRciConnectionStatusTabEvent
} from '../../../shared/tab-event';
import {RciListModel} from '../models/rci-list.model';
import { RciModel } from '../models/rci.model';
import { Grid } from './../../../shared/ag-grid.options';
import { LocaleDataService } from './../../../shared/locale.data.service';
import {RciGridColumnDefinitionService} from './rci-grid.column-definition.service';
import {RciHttpService} from './../../rci/rci.http.service';
import { RciGridService } from './rci-grid.service';
import { RciCpustatsModel } from "../models/rci-cpustats.model";
import { RciFirmwareUpgradeModel } from '../models/rci-firmwareupgrade.model';
import { SharedService } from "../../../shared/shared.service";

@Component({
    selector: 'rci-grid-component',
    templateUrl: 'rci-grid.component.html'
})
export class RciGridComponent implements OnDestroy {
    private gridApi: any;
    public localizationService: Observable<any>;
    public gridOptions: Observable<Grid>;
    public buttonKeys: Observable<Object[]>;
    public eventKeys: Observable<Object[]>;
    public refreshBtnFlag: Observable<boolean>;
    public showAllLabel: Observable<string>;
    public showAllLabelMob: Observable<string>;
    public rowData: Observable<RciListModel>;
    private gridModelUpdated = new Subject();
    public rciModel: Observable<RciModel>;
    public rciCpuStatsModel: Observable<RciCpustatsModel>;
    private rciFirmwareUpgradeModel: Observable<RciFirmwareUpgradeModel>;
    public rciConnectionStatus: Observable<String>;

    public exportFileName = 'RCIExport';
    public rciEventData: any = null;

    constructor(
        private columnDefinitionService: RciGridColumnDefinitionService,
        private localeDataService: LocaleDataService,
        private sharedGridService: RciGridService,
        private sharedService: SharedService,
        private rciHttpservice: RciHttpService,
        public translate : TranslateService
    ) {
        
    }
    
    ngOnInit(){
        this.localizationService = this.localeDataService.isReady
            .pipe(filter(ready => ready),
            map(r => this.translate))

        this.rciModel = this.sharedGridService.rciModel.asObservable();
        this.rciCpuStatsModel = this.sharedGridService.rciCpuStatsModel.asObservable();
        this.rowData = this.sharedGridService.rciList;
        
        this.refreshBtnFlag = this.localeDataService.isReady;
        this.gridOptions = this.localizationService.pipe(map(ls => {
            let result = new Grid();
            result.setColumnDefs(this.columnDefinitionService.getColumnDef(ls));
            return result;
        }))

        this.setupCounts();
        this.setupButtons();

        this.rciConnectionStatus = this.sharedGridService.rciConnectionStatus;
        if(this.sharedService.RetainFilter){
            this.sharedGridService.rcigridfilterchangedata = "";
            this.rciHttpservice.rcigridmodel = "";
        }
    }
    ngOnDestroy(): void {
        this.sharedService.setFilterForTAB('');
    }

    private setupCounts() {
        let totalCount = this.rowData.pipe(map(r => r.length));
        let rowCount = this.gridModelUpdated // when the model is updated
            .pipe(combineLatest(this.gridOptions), // get latest grid options
            filter(result => result[1].api != null), // when the grid api is not null
            map(result => result[1].api.getDisplayedRowCount()), // retrieve the displayed row count
            merge(totalCount)) // or take the total count of data

        let counts = this.localizationService.pipe(combineLatest(totalCount, rowCount))
        
        this.showAllLabel = counts
            .pipe(map(result => {
                let ls = result[0];
                let totalCount = result[1];
                let rowCount = result[2];
                return `${this.translate.instant('TABLE_LIST_SHOWING')} ${rowCount} ${this.translate.instant('TABLE_LIST_SHOWING_OF')} ${totalCount} ${this.translate.instant('TABLE_LIST_ROWS')}`;
            }))

        this.showAllLabelMob = counts.pipe(map(count => `${count[2]}/${count[1]}`));
    }

    public notifyFilterChangeRCIGRID(event): void{
        this.sharedService.RetainFilter = false;
        this.sharedGridService.rcigridfilterchangedata = this.gridApi.getFilterModel();
         const countryFilterComponent = this.gridApi.getFilterInstance('name');
        const model = countryFilterComponent.getModel();
        this.rciHttpservice.rcigridmodel = model;
    }
    private setupButtons() {
        this.buttonKeys = of([{ name: this.translate.instant('ADD_RCI'), action: TabAction.ADD_ITEM }]);
        this.eventKeys = of([
                { name: this.translate.instant('REMOTE_REBOOT_SELECTED'), status: GRID_COMP_KEY_SINGLE, action: TabAction.RCI_REMOTE_REBOOT_ITEM },
                { name: this.translate.instant('RCI_FIRMWARE_UPGRADE_SELECTED'), status: GRID_COMP_KEY_MULTI, action: TabAction.RCI_FIRMWARE_UPGRADE_SHOW },
                { name: this.translate.instant('TABLE_LIST_RCI_TEST_CONNECTION'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.TEST_CONNECTION },

                { name: this.translate.instant('VIEW_EVENTS'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.VIEW_EVENT },

                { name: this.translate.instant('TABLE_LIST_RCI_SHOW_PERFORMANCE_FOR_ALL'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.SHOW_RCI_CPU_STATS },
                { name: this.translate.instant('TABLE_LIST_EXPORT_LOG_MESSAGE'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.EXPORT_LOG_MESSAGE },
                { name: this.translate.instant('SYNC_SELECTED'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TabAction.SYNC_SELECTED },
                { name: this.translate.instant('SYNC_ALL'), status: GRID_COMP_KEY_MULTI, action: TabAction.SYNC_ALL },
                { name: this.translate.instant('TABLE_LIST_EXPORT_SELECTED'), status: GRID_COMP_KEY_SINGLE },
                { name: this.translate.instant('TABLE_LIST_EXPORT_ALL'), status: GRID_COMP_KEY_MULTI }
            ])
    }

    // EVENT HANDLERS

    public gridModelUpdatedEmitter(params:any) {
        this.gridModelUpdated.next();
    }

    public notifyRefreshGrid(params:any) {
        this.sharedGridService.emitTabEvent(new RefreshListTabEvent());
    }

    public gridReady(param): void {
        const filter: string = this.sharedService.getFilterForTAB();
        this.gridApi = param.api;
        if (filter.length) {
            document.getElementById('statusFilter')['value'] = filter.toUpperCase();
            param.api.getFilterInstance('status')
                .setModel(filter.toUpperCase());
            param.api.onFilterChanged();
        }
        if(this.gridApi && (!jQuery.isEmptyObject(this.sharedGridService.rcigridfilterchangedata) || this.rciHttpservice.rcigridmodel)){
			this.gridApi.setFilterModel(this.sharedGridService.rcigridfilterchangedata);
            if(this.rciHttpservice.rcigridmodel || this.sharedGridService.rcigridfilterchangedata){
			const countryFilterComponent = this.gridApi.getFilterInstance("name");
            countryFilterComponent.setModel(this.rciHttpservice.rcigridmodel);
            }
		}

    }

    private viewEvent(): void {
        const data: any = this.gridApi.getSelectedNodes()[0].data;
        this.rciEventData = {
            eventName: data.name,
            elementId: data.elementId
        };
        console.log('this.rci', this.rciEventData)
    }

    public handleButtonEvent(context) {
        let event: TabEvent;
        switch (context.event.action) {
            case TabAction.VIEW_EVENT:
                this.viewEvent();
                break;
            case TabAction.ADD_ITEM:
                event = new AddItemTabEvent();
                break;
            case TabAction.DELETE_ITEM:
                event = new DeleteItemTabEvent(context.selectedData[0]);
                break;
            case TabAction.RCI_REMOTE_REBOOT_ITEM:
                event = new RemoteRebootTabEvent(context.selectedData[0]);
                break;
            case TabAction.RCI_FIRMWARE_UPGRADE_SHOW:
                event = new FirmwareUpgradeShowTabEvent(context.selectedData);
                break;
            case TabAction.RCI_FIRMWARE_UPGRADE_CLOSE:
                event = new HideRciFirmwareUpgradeTabEvent();
                break;
            case TabAction.EXPORT_LOG_MESSAGE:
                event = new ExportLogMessageTabEvent(context.selectedData[0]);
                break;
            case TabAction.SHOW_RCI_CPU_STATS:
                event = new RetrieveRciCpuStatsTabEvent(context.selectedData[0]);
                break;
            case TabAction.HIDE_RCI_CPU_STATS:
                event = new HideRciCpuStatsTabEvent();
                break;
            case TabAction.TEST_CONNECTION:
                event = new TestRciConnectionTabEvent(context.selectedData[0]);
                break;
			case TabAction.UPDATE_RCI_CONNECTION_STATUS:
				event = new UpdateRciConnectionStatusTabEvent(context);
				break;
            case TabAction.SYNC_SELECTED:
                let ArrayRCIids = [];
                for (let i = 0; i < context.selectedData.length; i++) {
                    ArrayRCIids.push(context.selectedData[i].elementId)
                }
                this.sharedGridService.ArrayRciIds = ArrayRCIids;
                event = new SyncSelectedTabEvent(ArrayRCIids);
                break;
            case TabAction.SYNC_ALL:
                event = new SyncAllTabEvent([]);
                break;
            default: throw new Error('Unhandled button event: ' + context.event.action)
        };

        event && this.sharedGridService.emitTabEvent(event);
    }
}