import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import { ColDef } from 'ag-grid';
//import { LocalizationService } from 'angular2localization';

import { ExportColDef } from '../../../shared/export.coldef';
import { SelectBoxFilter, SelectBoxFilterParams } from '../../../shared/select-box.filter';
import { EditItemTabEvent } from '../../../shared/tab-event';
import { EDIT_ICON } from './../../../constant/app.constants';
import { LocaleDataService } from './../../../shared/locale.data.service';
import { DisabledFilter } from './../../shared/grid/disabled.filter';
import { RciGridService } from './rci-grid.service';
import { SharedService } from '../../../shared/shared.service';
import { StatusFilter } from 'src/app/shared/status.filter';


@Injectable()
export class RciGridColumnDefinitionService{


    private _HEADER_FIELDS: any = {
        name : {field: "name", name: "RCI_NAME"},
        status : {field: "status", name: "RCI_STATUS"},
        hostname : {field: "hostname", name: "RCI_HOSTNAME"},
        firmwareversion: {field: "firmwareVersion", name: "RCI_FIRMWARE_VERSION"},
        assignedCmtsCount: {field: "assignedCmtsCount", name: "RCI_ASSIGNED_CMTS_COUNT"},
        cmtsUsPortCount: {field: "cmtsUsPortCount", name: "RCI_CMTS_US_PORT_COUNT"},
        view : {field: "view", name: "RCI_HEADER_VIEW"}
    };

    constructor(private localeDataService:LocaleDataService,
        private rciGridService:RciGridService,
        private sharedService:SharedService,
        public translate: TranslateService){
    }

    /*
     *@name getColumnDef
     *@desc Get column def for user-accounts data-grid
     *@return array[any]
     */
    public getColumnDef(localizationService: TranslateService): ColDef[] {
        // let statusFilterParams = <SelectBoxFilterParams> { 
        //     noSelectionDisplay: localizationService.instant('DEFAULT'),
        //     valuePassesFilter: (row, filter) => row.data.offline === filter,
        //     values: [{
        //         value: false,
        //         display: localizationService.instant('ONLINE').toLocaleUpperCase()
        //     }, {
        //         value: true,
        //         display: localizationService.instant('OFFLINE')
        //     }]
        //  };
         StatusFilter.setSeverity(
            {
                default: localizationService.instant('DEFAULT'),
                online: localizationService.instant('ONLINE'),
                offline: localizationService.instant('OFFLINE'),
                busy: localizationService.instant('BUSY'),
                error: localizationService.instant('ERROR'),
                disabled: localizationService.instant('DISABLED'),
                unavailable: localizationService.instant('UNAVAILABLE')
            }
        );
        StatusFilter.setCMTSVisibility(false);
        StatusFilter.setRCIVisibility(true);
        let columnDef: ExportColDef[] = [
            {
                headerName: '',
                width: 15,
                maxWidth: 25,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: this.translate.instant(this._HEADER_FIELDS.status.name),
                headerTooltip: this.translate.instant(this._HEADER_FIELDS.status.name),
                field: this._HEADER_FIELDS.status.field,
              //  minWidth: 200,
                filter: StatusFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true,
                    newRowsAction: 'keep'
                }),
                floatingFilterComponent: StatusFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                })
               // valueFormatter: v => localizationService.instant(v.value ? 'OFFLINE' : 'ONLINE'),
               // exportFormatter: v => localizationService.instant(v.value ? 'OFFLINE' : 'ONLINE')
            },
            {
                headerName: this.translate.instant(this._HEADER_FIELDS.name.name),
                headerTooltip: this.translate.instant(this._HEADER_FIELDS.name.name),
                field: this._HEADER_FIELDS.name.field,
              //  minWidth: 200,
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                sort:'asc'
            },
			{
				headerName: this.translate.instant(this._HEADER_FIELDS.firmwareversion.name),
				headerTooltip: this.translate.instant(this._HEADER_FIELDS.firmwareversion.name),
				field: this._HEADER_FIELDS.firmwareversion.field,
			//	minWidth: 200,
				filter: 'text',
				floatingFilterComponentParams: { supressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
			},
            {
                headerName: this.translate.instant(this._HEADER_FIELDS.hostname.name),
                headerTooltip: this.translate.instant(this._HEADER_FIELDS.hostname.name),
                field: this._HEADER_FIELDS.hostname.field,
              //  minWidth: 200,
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
            {
                headerName: this.translate.instant(this._HEADER_FIELDS.assignedCmtsCount.name),
                headerTooltip: this.translate.instant(this._HEADER_FIELDS.assignedCmtsCount.name),
                field: this._HEADER_FIELDS.assignedCmtsCount.field,
              //  minWidth: 200,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
            },
			{
				headerName: this.translate.instant(this._HEADER_FIELDS.cmtsUsPortCount.name),
				headerTooltip: this.translate.instant(this._HEADER_FIELDS.cmtsUsPortCount.name),
				field: this._HEADER_FIELDS.cmtsUsPortCount.field,
			//	minWidth: 200,
				filter: 'text',
				floatingFilterComponentParams: { suppressFilterButton:true },
				filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'}
			},
            {
                colId: 'edit',
                headerName: this.translate.instant(this._HEADER_FIELDS.view.name),
                headerTooltip: this.translate.instant(this._HEADER_FIELDS.view.name), 
                field: this._HEADER_FIELDS.view.field,
                pinned: this.sharedService.isPinned(),
                minWidth: 70, 
                maxWidth: 120,
                width: 70,
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                        this.editItem(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }
        ]
        return columnDef;
    }

    editItem(param: any) {
        this.rciGridService.emitTabEvent(new EditItemTabEvent(param.data));
    }
}