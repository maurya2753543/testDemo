import {Component, Input} from '@angular/core';
import {Observable} from 'rxjs';
import {RciGridService} from '../rci-grid.service';
//import {LocalizationService} from 'angular2localization';
import {FirmwareUpgradeShowTabEvent, HideRciFirmwareUpgradeTabEvent} from '../../../../shared/tab-event';
import {RciFirmwareUpgradeColumnDefinition} from './rci-firmwareUpgrade.column-definition';
import {RciGridDataService} from '../rci-grid.data.service';
import {ShowAlert} from '../../../../utilities/showAlert';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {GridOptions, RowDataChangedEvent} from 'ag-grid';
import {ThemeService} from '../../../../shared/theme.service';
import {RciGridColumnDefinitionService} from '../rci-grid.column-definition.service';
import {RciSelectedGridColumnDefinitionService} from './rci-selectedgrid.column.definition.service';
// import {forEach} from '@angular/router/src/utils/collection';
import {RciRequestModel} from '../../models/rci-request.model';
import {Logger} from '../../../../utilities/logger';
import {RciErrorService} from '../../rci.error.service';
import {ALERT_INFO} from '../../../../constant/app.constants';
import {CommonStrings} from '../../../../constant/common.strings';
import { map, filter } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';


@Component({
	selector: 'rci-firmwareupgrade-component',
	templateUrl: 'rci-firmwareUpgrade.component.html'
})
export class RciFirmwareUpgradeComponent{

	public rciFirmwareUpgradeFileGridOptions: GridOptions;
	public rciToUpgradeGridOptions: GridOptions;

	public rowData: Observable<any[]>;
	public rowDataRci: Observable<any[]>;
	public closeSlider: Observable<boolean>;

	//Translation fields
	public DELETE_PACKAGE :string;
	public UPGRADE_SUBMIT_TEXT: string;
	private SELECTED_RCI_SUCCESS_UPGRADE: string;


	public selectedData:any = [];
	private columnDefs: any[];
	public deleteBtnStatus:boolean;


	private _ls: TranslateService;
	private get ls() { return this._ls; }
	@Input("localizationService") private set ls(value: TranslateService) {
		this._ls = value;
		this.setupGrid();
	}

	constructor(private rciGridService: RciGridService,
				private columnDefinitionService: RciFirmwareUpgradeColumnDefinition,
				private rciColumnDefinitionService: RciGridColumnDefinitionService,
				private rciSelectedColumnDefinitionService: RciSelectedGridColumnDefinitionService,
				private rciGridDataService: RciGridDataService,
				private showAlert: ShowAlert,
				private localeDataService: LocaleDataService,
				public ThemeService: ThemeService,
				private logger: Logger,
				private rciErrorService: RciErrorService) {
		this.translateLocaleString();
		this.createRowData();
		this.closeSlider = this.rowData.pipe(map(r => r == null));
	}

	private createRowData() {
		this.rowData = this.rciGridService.rciFirmwareUpgradeModel.asObservable();

		this.rowDataRci = this.rciGridService.rciSelectedList.asObservable()
			.pipe(filter(model => model != null));
	}

	//function :: used for localization
	private translateLocaleString():void {
		let localizationService = this.localeDataService.getLocalizationService();
		this.DELETE_PACKAGE = localizationService.instant("RCI_DELETE_PACKAGE");
		this.UPGRADE_SUBMIT_TEXT = localizationService.instant("RCI_UPGRADE_SUBMIT_TEXT");
		this.SELECTED_RCI_SUCCESS_UPGRADE = localizationService.instant("RCI_SELECTED_RCI_SUCCESS_UPGRADE");
	}

	private setupGrid(){
		this.rciFirmwareUpgradeFileGridOptions = <GridOptions>{
			suppressContextMenu: true,
			rowSelection: 'single',
			enableSorting: true,
			floatingFilter: true,
			columnDefs: this.columnDefinitionService.getColumnDef(this.ls)
		};

		this.rciToUpgradeGridOptions = <GridOptions>{
			suppressContextMenu: true,
			// rowSelection: 'single',
			enableSorting: false,
			floatingFilter: true,
			columnDefs: this.rciSelectedColumnDefinitionService.getColumnDef(this.ls)
		};
	}

	public onGridResize(event) {
		if(event.api) {
			event.api.sizeColumnsToFit();
		}
	}

	public onSelectionChanged($event): void{
		console.log("Selection Changed on Grid.");
		let data:any = $event;
		this.selectedData = data.api.selectionController.getSelectedRows();
	}

	public UpgradeFirmware(): void{
		//rowData has fileNameWIthPath which is needed to be passed to upgradeRciFirmware api.
		let fileNameWitPath: string = this.rciFirmwareUpgradeFileGridOptions.api.getSelectedNodes()[0].data.fileNameWithPath;

		let rciRequest: RciRequestModel = new RciRequestModel();
		rciRequest.fileName = fileNameWitPath;
		rciRequest.rciResponseList = this.rciGridService.rciSelectedList.value;

		this.rciGridDataService.upgradeRciFirmware({rciRequest: rciRequest})
			.subscribe(r => (
				this.upgradeSuccessFlow(),
				err => this.handleRequestError(err)));
	}

	//method :: delets pkg
	public deletePackage():void{
		this.rciGridDataService.deleteFirmwareFile(this.rciFirmwareUpgradeFileGridOptions.api.getSelectedNodes()[0].data.fileName)
			.subscribe( r => (
				this.rciGridService.emitTabEvent(new FirmwareUpgradeShowTabEvent(this.rciGridService.rciSelectedList.value)),
				err => this.handleRequestError(err)
			));
	}

	public btnClose_click():void{
		this.rciGridService.emitTabEvent(new HideRciFirmwareUpgradeTabEvent())
	}

	private handleRequestError(err) {
		let error = err.json();
		this.logger.error("onError():  error data=", error);
		this.rciErrorService.showError(error);
	}

	private upgradeSuccessFlow() {
    	this.showAlert.showInfoAlert(this.SELECTED_RCI_SUCCESS_UPGRADE);
		this.btnClose_click();

	}
}