import {Injectable} from '@angular/core';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {gridCustomComparator} from '../../../../shared/ag-Grid.comparator';

@Injectable()

export class RciFirmwareUpgradeFileColumnDefinition{
	private _HEADER_FIELDS: any = {
		fileName: {field: "fileName", name: "FILENAME"},
		lastModeiied: {field: "lastModified", name: "LAST_MODIFIED"}
	};

	constructor(private localeDataService: LocaleDataService){
		this.translateLocaleStr();
	}

	private translateLocaleStr():void{
		let localizationService = this.localeDataService.getLocalizationService();
	}

	public getColumnDef(): any[] {
		let columnDef: any[] = [
			{
				headerName: '',
				width: 21,
				checkboxSelection: true,
				pinned: true,
				sortingOrder: [null],
				field: '',
				headerCheckboxSelection: false,
				suppressFilter: true,
				suppressSizeToFit: true,
				suppressMenu: true,
				filterParams: {suppressAndOrCondition: true},
				cellStyle: (params:any) => {
					let backgroundColor:any;
					if (params.data.fileCorrupted) {
						backgroundColor = {'background-color': 'red'};
					}
					return backgroundColor;
				}
			},
			{
				headerName: this._HEADER_FIELDS.fileName.name,
				headerToolTip: this._HEADER_FIELDS.fileName.name,
				field: this._HEADER_FIELDS.fileName.field,
				minWidth: 50,
				floatingFilterComponentParams: {suppressFilterButton: true},
				filter: 'text',
				comparator: gridCustomComparator,
				filterParams: {suppressAndOrCondition: true},
				cellStyle: function() { return { 'text-align': 'center' }}
			},
			{
				headerName: this._HEADER_FIELDS.lastModeiied.name,
				headerToolTip: this._HEADER_FIELDS.lastModeiied.name,
				field: this._HEADER_FIELDS.lastModeiied.field,
				minWidth: 50,
				floatingFilterComponentParams: {suppressFilterButton: true},
				filter: 'text',
				comparator: gridCustomComparator,
				filterParams: {suppressAndOrCondition: true},
				cellStyle: function() { return { 'text-align': 'center' }}
			}
		]

		return columnDef;
	}
}