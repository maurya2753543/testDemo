import { TranslateService } from '@ngx-translate/core';
import {Injectable} from '@angular/core';
import { ColDef } from 'ag-grid';
import {SharedService} from '../../../../shared/shared.service';
//import {LocalizationService} from 'angular2localization';
import {SelectBoxFilter, SelectBoxFilterParams} from '../../../../shared/select-box.filter';

@Injectable()

export class RciFirmwareUpgradeColumnDefinition {

	//Header Fields with field name and display name.
	private _HEADER_FIELDS: any = {
		fileName: {field: "fileName", name: "FILENAME"},
		lastModified: {field: "lastModified", name: "LAST_MODIFIED"}
	};

	constructor(private sharedService: SharedService){
		// this.translateLocaleStr();
	}

	getColumnDef(ls: TranslateService): ColDef[] { return this.buildColDefs(ls); }

	private buildColDefs(ls: TranslateService) {

		return [
			{
				colId: 'selected',
				headerName: '',
				width: 21,
				checkboxSelection: true,
				field: '',
				headerCheckboxSelection: false,
				suppressFilter: true,
				suppressSizeToFit: true,
				suppressMenu: true,
				suppressResize: true
			},
			{
				headerName: ls.instant(this._HEADER_FIELDS.fileName.name), 
				headerToolTip: ls.instant(this._HEADER_FIELDS.fileName.name),
				field: this._HEADER_FIELDS.fileName.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.fileName.name, 60),
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton: true },
				filterParams: { newRowAction: 'keep' }
			},
			{
				headerName: ls.instant(this._HEADER_FIELDS.lastModified.name),
				headerToolTip: ls.instant(this._HEADER_FIELDS.lastModified.name),
				field: this._HEADER_FIELDS.lastModified.field,
				minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.lastModified.name, 60),
				filter: 'text',
				floatingFilterComponentParams:{ suppressFilterButton: true },
				filterParams: { newRowAction: 'keep' }
			}
		]
	}
}