import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import { ColDef } from 'ag-grid';
//import { LocalizationService } from 'angular2localization';
import {SelectBoxFilterParams} from '../../../../shared/select-box.filter';
import {SharedService} from '../../../../shared/shared.service';
import {RciGridService} from '../rci-grid.service';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {ExportColDef} from '../../../../shared/export.coldef';

@Injectable()
export class RciSelectedGridColumnDefinitionService{

	private _HEADER_FIELDS: any = {
		name : {field: "name", name: "RCI_NAME"},
		offline : {field: "offline", name: "RCI_STATUS"},
		hostname : {field: "hostname", name: "RCI_HOSTNAME"},
		view : {field: "view", name: "RCI_HEADER_VIEW"}
	};

	constructor(private localeDataService:LocaleDataService,
				private rciGridService:RciGridService,
				private sharedService:SharedService){
	}

	/*
	 *@name getColumnDef
	 *@desc Get column def for user-accounts data-grid
	 *@return array[any]
	 */
	public getColumnDef(localizationService: TranslateService): ColDef[] {

		let statusFilterParams = <SelectBoxFilterParams> {
			noSelectionDisplay: localizationService.instant('DEFAULT'),
			valuePassesFilter: (row, filter) => row.data.offline === filter,
			values: [{
				value: false,
				display: localizationService.instant('ONLINE').toLocaleUpperCase()
			}, {
				value: true,
				display: localizationService.instant('OFFLINE')
			}]
		};

		let columnDef: ExportColDef[] = [
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.offline.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.offline.name),
				field: this._HEADER_FIELDS.offline.field,
				minWidth: 200,
				// filter: SelectBoxFilter,
				// filterParams: Object.assign({
				// 	newRowsAction: 'keep'
				// }, statusFilterParams),
				// floatingFilterComponent: SelectBoxFilter.FloatingFilter,
				// floatingFilterComponentParams: Object.assign({
				// 	suppressFilterButton: true
				// }, statusFilterParams),
				valueFormatter: v => localizationService.instant(v.value ? 'OFFLINE' : 'ONLINE'),
				exportFormatter: v => localizationService.instant(v.value ? 'OFFLINE' : 'ONLINE')
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.name.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.name.name),
				field: this._HEADER_FIELDS.name.field,
				minWidth: 200
				//,
				// filter: 'text',
				// floatingFilterComponentParams:{ suppressFilterButton:true },
				// filterParams: {newRowsAction: 'keep'},
				// sort:'asc'
			},
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.hostname.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.hostname.name),
				field: this._HEADER_FIELDS.hostname.field,
				minWidth: 200
				// ,
				// filter: 'text',
				// floatingFilterComponentParams:{ suppressFilterButton:true },
				// filterParams: {newRowsAction: 'keep'},
			}
		]
		return columnDef;
	}
}