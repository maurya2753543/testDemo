import { TranslateService } from '@ngx-translate/core';
import { Input, Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
//import { LocalizationService } from 'angular2localization';
import { RciCpustatsModel } from '../../models/rci-cpustats.model';
import { HideRciCpuStatsTabEvent } from '../../../../shared/tab-event';
import { RciGridService } from "../rci-grid.service";
import {SharedService} from "../../../../shared/shared.service";

@Component({
    selector: 'rci-cpustats-component',
    templateUrl: 'rci-cpustats-view.html'
})
export class RciCpustatsComponent {

    public closeSlider = new BehaviorSubject<boolean>(true);
    private _ls: TranslateService;
    private get ls() { return this._ls; }
    @Input("localizationService") private set ls(value: TranslateService) {
        this._ls = value;
    }
    private _dataModel: RciCpustatsModel;
    get dataModel(): RciCpustatsModel { return this._dataModel; }
    @Input() set dataModel(value: RciCpustatsModel) {
        if(value){
            let currentDateTime = value.currenttime * 1000;
            value.currenttime = this.sharedService.getLocaleDate(new Date(currentDateTime));
        }
        this._dataModel = value;
        this.closeSlider.next(value == null);
        if(value == null) { return; }
    }
    constructor(private rciGridService: RciGridService,
                private sharedService: SharedService
    ) {}

    closeRciCpuStatsDisplay() { this.rciGridService.emitTabEvent(new HideRciCpuStatsTabEvent()); }
}