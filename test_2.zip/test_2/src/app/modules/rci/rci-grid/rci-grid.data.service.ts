import { catchError } from 'rxjs/operators';
import { map } from 'rxjs/operators';

import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import {RciHttpService} from "../rci.http.service";
import {RciListModel} from "../models/rci-list.model";
import { CmtsModel } from '../models/cmts-rci.model';
import {RciCpustatsModel} from "../models/rci-cpustats.model";
import {RciRequestModel} from '../models/rci-request.model';
import { LocaleDataService } from "../../../shared/locale.data.service";
import {RciModel} from '../models/rci.model';
import { TranslateService } from '@ngx-translate/core';
@Injectable()
export class RciGridDataService {
    
    // private accessDataList : any;
    // private rciModelList;

    constructor(private rciHttpService: RciHttpService, private localeDataService : LocaleDataService, private translate: TranslateService) {}

    /*Method to get Rci List */
    public getRciList(): Observable<RciListModel> {
        return this.rciHttpService
            .getRciList()
            .pipe(
                map((r) =>{
                    let localizationService = this.translate;//this.localeDataService.getLocalizationService(); 
                    let rcidata = r;
                    for(let i = 0; i < rcidata.length; i++){
                        rcidata[i].status = rcidata[i].offline ? localizationService.instant('OFFLINE') : localizationService.instant('ONLINE');
                    }
                    
                    return new RciListModel(rcidata)})
            )
    }

    // public getRciDetails(rciId: number): Observable<any> {
    //     return this.rciHttpService.getRciDetail(rciId);
    // }

    public addRci(rciData: any): Observable<any> {
        return this.rciHttpService.addNewRci(rciData);
    }

    public syncRci(rciIdArray: any[]): Observable<any> {
        return this.rciHttpService.syncRci(rciIdArray);
    }

    updateRci(rciData: any): any {
        return this.rciHttpService.updateRci(rciData);
    }

    public deleteRci(rciId: number): Observable<any> {
        return this.rciHttpService.deleteRci(rciId);
    }

    public getAllCmtsList(): Observable<CmtsModel[]> {
        return this.rciHttpService
            .getAllCmtsList()
            .pipe(map(r => <CmtsModel[]>r)
            )
    }

	public rebootRci(rciData: any): Observable<any> {
        return this.rciHttpService.rebootRci(rciData);
	}

	public retrieveRciFirmwareUpgradeFiles(): Observable<any> {
        return this.rciHttpService
            .retrieveRciFirmwareUpgradeFiles()
            .pipe(
                map((rciFirmwareUpgradeFilesObj: HttpResponse<any>) =>{
                    return rciFirmwareUpgradeFilesObj;
                }),catchError(RciGridDataService.handleError)
            )
    }

	public upgradeRciFirmware(parameters: { rciRequest: RciRequestModel }): Observable<any> {
		let rciRequest = parameters.rciRequest;
        return this.rciHttpService.upgradeFirmware(rciRequest);
    }

    public deleteFirmwareFile(fileName: string): Observable<any> {
        return this.rciHttpService.deleteFirmwareFile(fileName);
    }

    public getLogMessage(rciId: number): Observable<any> {
        return this.rciHttpService.retrieveLogMessage(rciId);
    }

    public retrieveRciCpuStats(rciId: number): Observable<any> {
        return this.rciHttpService.retrieveRciCpuStats(rciId)
        .pipe(
            map( (r) => <RciCpustatsModel>(r))
        )
    }

    public testRciConnection(rciId: number): Observable<any> {
        return this.rciHttpService.testRciConnection(rciId);
    }

    public testRciConnectionButton(rci: RciModel): Observable<any> {
    	return this.rciHttpService.testRciConnectionButton(rci);
	}

    public getRciEvent(rciId: number): Observable<any> {
        return this.rciHttpService.getRciEvent(rciId);
    }

	//Error handler
	static handleError(error) {
		return throwError(error);
	}
}
