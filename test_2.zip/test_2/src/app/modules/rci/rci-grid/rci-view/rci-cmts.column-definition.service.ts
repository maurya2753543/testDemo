import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import { ColDef } from 'ag-grid';
//import { LocalizationService } from 'angular2localization';
import { BooleanFilter } from "src/app/shared/boolean.filter";
import { SelectBoxFilter, SelectBoxFilterParams } from '../../../../shared/select-box.filter';
import { SharedService } from './../../../../shared/shared.service';


@Injectable()
export class RciCmtsColumnDefinitionService {

    constructor(private sharedService : SharedService, public translate: TranslateService) { }

    private buildColDefs(ls: TranslateService, isEdit: boolean): ColDef[] {
        let name = { field: 'cmts.name', name: ls.instant('CMTS') };
        let hostname = { field: 'cmts.hostname', name: ls.instant('CMTS_HOSTNAME') };
        let assignedRci = { field: 'rciNames', name: ls.instant('ASSIGNED_RCI') };
        
        BooleanFilter.setCMTSValue(
            {
                default: ls.instant('ALL'),
                true: ls.instant('ASSIGNED'),
                false: ls.instant('UNASSIGNED'),
                isCMTS : true
            }
        );

        let assignedFilterParams = <SelectBoxFilterParams> {
            noSelectionDisplay: ls.instant('ALL'),
            valuePassesFilter: (row, filter) => {
                console.log('row',row , '::', filter)
                return filter == !!row.data.rciNames
            },
            values: [{
                value: true,
                display: ls.instant('ASSIGNED'),
            }, {
                value: false,
                display: ls.instant('UNASSIGNED')
            },{
                isCMTS : true
            }]
         };

        return [
            {
                colId: 'selected',
                hide: !isEdit,
                headerName: '',
                width: 21,
                checkboxSelection: true,
                sort: 'asc',
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                suppressResize: true
            },
            {
                headerName: name.name,
                headerTooltip: name.name,
                field: name.field,
                minWidth: this.sharedService.getHeaderTemplate(name.name, 60),
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true}
            },
            {
                headerName: hostname.name,
                headerTooltip: hostname.name,
                field: hostname.field,
                minWidth: this.sharedService.getHeaderTemplate(hostname.name, 60),
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {suppressAndOrCondition: true}
            },
            {
                headerName: assignedRci.name,
                headerTooltip: assignedRci.name,
                field: assignedRci.field,
                minWidth: this.sharedService.getHeaderTemplate(assignedRci.name, 60),
                filter: BooleanFilter.ParentFilter,
                filterParams: Object.assign({suppressAndOrCondition: true}, assignedFilterParams),
                floatingFilterComponent: BooleanFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({ suppressFilterButton:true }, assignedFilterParams),
                valueFormatter: (params) => {
                    return params.value == null ? this.translate.instant('UNASSIGNED') : params.value;
                }
            }
        ];
    }

    public getReadColumnDef(ls: TranslateService): ColDef[] { return this.buildColDefs(ls, false); }

    public getEditColumnDef(ls: TranslateService): ColDef[] { return this.buildColDefs(ls, true); }
}
