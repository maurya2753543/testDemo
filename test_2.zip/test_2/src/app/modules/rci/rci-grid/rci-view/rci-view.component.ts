/*
 * Copyright (c) 2022 Viavi Solutions Inc. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions is strictly prohibited.
 */

import {TranslateService} from '@ngx-translate/core';
import {Component, Input} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {GridApi, GridOptions, RowDataChangedEvent} from 'ag-grid';
import {RciCmtsColumnDefinitionService} from './rci-cmts.column-definition.service';
import {RciGridService} from '../rci-grid.service';
//import { LocalizationService } from 'angular2localization';
import {RciModel} from '../../models/rci.model';
import {ThemeService} from '../../../../shared/theme.service';
import {CmtsRci} from '../../models/cmts-rci.model';
import {
    ClearEditorTabEvent,
    DeleteItemTabEvent,
    SaveNewItemTabEvent,
    UpdateItemTabEvent,
    UpdateRciConnectionStatusTabEvent
} from '../../../../shared/tab-event';
import {SharedService} from "../../../../shared/shared.service";
import {AgGridConfigurationService} from "../../../../shared/agGrid.configuration.service";
import {CommonStrings} from "../../../../constant/common.strings";
import {RciGridDataService} from '../rci-grid.data.service';
import {ALERT_INFO, ALERT_SUCCESS} from '../../../../constant/app.constants';
import {LocaleDataService} from '../../../../shared/locale.data.service';
import {ShowAlert} from '../../../../utilities/showAlert';

@Component({
    selector: 'rci-view-component',
    templateUrl: 'rci-view.component.html'
})
export class RciViewComponent {
    private numberOfCmtses:number;
    private isEdit = false;
    private isCreate = false;
    private isOperationInProgress: boolean = false;
	private isConnectionTested = false;
    private errorMessages = {
        isHostnameEmpty: false,
        isNameEmpty: false
    };
    private rowData: Observable<any[]>;
    private totalCount: Observable<number>;
    private showAllLabel: Observable<string>;
    public closeSlider = new BehaviorSubject<boolean>(true);
    private cmtsGridOptions: GridOptions;
    private readOnlyCmtsGridOptions: GridOptions;

    private RCI_TEST_CONNECT_SUCCESS = "RCI_TEST_CONNECT_SUCCESS";
    private RCI_TEST_CONNECT_FAILURE = "RCI_TEST_CONNECT_FAILURE";

    private rciTestInvalid: boolean = true;

    private readonly ConnectionStatus = UpdateRciConnectionStatusTabEvent;

    private _ls: TranslateService;
    private get ls() { return this._ls; }
    @Input("localizationService") private set ls(value: TranslateService) {
        this.translate = value;
        this.setupGrid();
        this.translateLocaleString();
    }
    private _dataModel: RciModel;
    get dataModel(): RciModel { return this._dataModel; }
    @Input() set dataModel(value: RciModel) {
        // Get deep copy to avoid loss of original data.
        console.log('datamodel', value)
        this._dataModel = JSON.parse(JSON.stringify(value));
        this.closeSlider.next(value == null);
        if(value == null) { return; }

        this.isCreate =
            this.isEdit = value.elementId == null;
    }

    @Input() public rciConnectionStatus: String;

    constructor(public sharedService: SharedService,
                private rciGridService:RciGridService,
                private agGridConfigurationService:AgGridConfigurationService,
                private rciCmtsColumnDefinitionService:RciCmtsColumnDefinitionService,
                private ThemeService: ThemeService,
                private rciGridDataService: RciGridDataService,
				private localeDataService: LocaleDataService,
                private showAlert: ShowAlert,
                public translate: TranslateService
    ) {}

    ngOnInit() {
        this.onRciUpdateError();
        this.rowData = this.rciGridService.cmtsRciList
        this.totalCount = this.rowData.map(d => d.length);
        this.showAllLabel = this.totalCount.map(count => {
            return `${this.translate.instant('TABLE_LIST_SHOWING')} ${count} ${this.translate.instant('TABLE_LIST_SHOWING_OF')} ${count} ${this.translate.instant('TABLE_LIST_ROWS')}`;
        })
        
        this.setupGrid();
        
        this.readOnlyCmtsGridOptions.getMainMenuItems = this.getMainMenuItemsReadOnlyCmts.bind(this);
        this.cmtsGridOptions.getMainMenuItems = this.getMainMenuItemsCmts.bind(this);
    }

    onKey(event: any){
        if(this.rciConnectionStatus === UpdateRciConnectionStatusTabEvent.connected){
            // Set rciConnectionStatus to not connected because some data changed.
			this.rciGridService.emitTabEvent(new UpdateRciConnectionStatusTabEvent(UpdateRciConnectionStatusTabEvent.notConnected));
        }

        //Check model to see if Hostname, Service and Upgrade Port
        if((this.dataModel.hostname != null || this.dataModel.hostname != "") &&
            (this.dataModel.rciServicePort != null) &&
            (this.dataModel.upgradeServicePort != null)) {
            this.rciTestInvalid = false;
        } else {
            this.rciTestInvalid = true;
        }
    }

    /*
  *@name getMainMenuItems
  *@desc adds menu items and functionality
  *@return any
  */
    private getMainMenuItemsReadOnlyCmts(params: any): any{
        let arr = params.defaultItems; /* comments:- Specify the type of the variable */
        arr.splice(2,6);
        let newMenu: any[] = arr;
        this.agGridConfigurationService.setMenuOption(newMenu, this.readOnlyCmtsGridOptions, params);
        return newMenu;
    }

    /*
   *@name getMainMenuItems
   *@desc adds menu items and functionality
   *@return any
   */
    private getMainMenuItemsCmts(params: any): any{
        let arr = params.defaultItems; /* comments:- Specify the type of the variable */
        arr.splice(2,6);
        let newMenu: any[] = arr;
        this.agGridConfigurationService.setMenuOption(newMenu, this.cmtsGridOptions, params);
        return newMenu;
    }

    private onRciUpdateError(): void {
        this.rciGridService.rciUpdate.subscribe(() => {
            this.isOperationInProgress = false;
        });
    }

    // Event handlers
    submitForm() {
        this.isOperationInProgress = true;
        let rciToSave = this.buildSaveRci();
        this.rciGridService.emitTabEvent(this.isCreate ? new SaveNewItemTabEvent(rciToSave) : new UpdateItemTabEvent(rciToSave));
    }

    delete() {
        this.isOperationInProgress = false;
        this.rciGridService.emitTabEvent(new DeleteItemTabEvent(this.dataModel));
    }

    closeEditor() { this.rciGridService.emitTabEvent(new ClearEditorTabEvent()); }

    enableEdit() {
        this.isEdit = true;
        this.rciTestInvalid = false;
        this.isOperationInProgress = false;
    }

	testConnection(){
        // this.rciGridService.emitTabEvent(new TestRciConnectionButtonTabEvent(this.buildSaveRci()));
        
		this.rciGridService.emitTabEvent(new UpdateRciConnectionStatusTabEvent(UpdateRciConnectionStatusTabEvent.pending));

		this.rciGridDataService.testRciConnectionButton(this.buildSaveRci())
			.subscribe(
				success => {
				    this.showAlert.showSimpleAlert(ALERT_SUCCESS,this.RCI_TEST_CONNECT_SUCCESS);
					this.rciGridService.emitTabEvent(new UpdateRciConnectionStatusTabEvent(UpdateRciConnectionStatusTabEvent.connected))
				},
				err => {
					this.showAlert.showSimpleAlert(ALERT_INFO,this.RCI_TEST_CONNECT_FAILURE);

					this.rciGridService.emitTabEvent(new UpdateRciConnectionStatusTabEvent(UpdateRciConnectionStatusTabEvent.notConnected));
				});
	}

    buildSaveRci(): RciModel {
        let result = new RciModel();
        result.elementId = this.dataModel.elementId;
        result.name = this.dataModel.name;
        result.https = this.dataModel.https;
        result.hostname = this.dataModel.hostname;
        // just selecting id property, it is all that is required to update the RCI entity.
        result.cmtses = this.cmtsGridOptions.api.getSelectedRows().map(row => ({ elementId: row.cmts.cmtsId }));

        //Added rciServer and upgradeServer ports so they can be set by users.
        result.rciServicePort = this.dataModel.rciServicePort;
        result.upgradeServicePort = this.dataModel.upgradeServicePort;
        result.sweepCount = this.dataModel.sweepCount;
        result.spectrumCount = this.dataModel.spectrumCount;
        result.apiCount = this.dataModel.apiCount;
        result.olVersion = this.dataModel.olVersion;
        return result;
    }

    // CMTS Grid Setup
    private setupGrid() {
        this.numberOfCmtses = 0;
        this.cmtsGridOptions = <GridOptions> {
            suppressContextMenu: true,
            rowSelection: 'multiple',
            enableSorting: true,
            floatingFilter: true,
            onRowSelected: this.onRowSelected.bind(this),
            columnDefs: this.rciCmtsColumnDefinitionService.getEditColumnDef(this.translate),

            localeText: this.getLocalText(),
            rowData: null,
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            autoGroupColumnDef: {headerName: "CMTS",
                cellRenderer:'agGroupCellRenderer',
                cellRendererParams: {
                    checkbox: true
                }}
        };

        this.readOnlyCmtsGridOptions = <GridOptions> {
            suppressContextMenu: true,
            rowSelection: 'multiple',
            enableSorting: true,
            floatingFilter: true,
            onRowSelected: this.onRowSelected.bind(this),
            columnDefs: this.rciCmtsColumnDefinitionService.getReadColumnDef(this.translate),
            localeText: this.getLocalText()
        };
    }

    private getLocalText(): any {
        return {
            noRowsToShow: CommonStrings.AG_GRID_NO_ROWS_TO_SHOW,
            filterOoo : CommonStrings.FILTER,
            equals : CommonStrings.FILTER_EQUALS,
            notContains : CommonStrings.FILTER_NOT_CONTAINS,
            startsWith : CommonStrings.FILTER_STARTS_WITH,
            endsWith : CommonStrings.FILTER_ENDS_WITH,
            pinColumn : CommonStrings.PIN_COLUMN_MAIN_MENU,
            pinLeft : CommonStrings.PIN_LEFT,
            pinRight : CommonStrings.PIN_RIGHT,
            noPin : CommonStrings.NO_PIN,
            contains : CommonStrings.FILTER_CONTAINS
        }
    }

    private onGridResize(event) {
        if(event.api) {
            event.api.sizeColumnsToFit();
        }
    }

    private onRowSelected(event):void{
        if(this.cmtsGridOptions.api != undefined)
        {
            this.numberOfCmtses = this.cmtsGridOptions.api.getSelectedRows().length;
        }
    }

    onRowDataChange(event: RowDataChangedEvent) {
        this.sortAndSelectByOwned(event.api);
    }

    sortAndSelectByOwned(api: GridApi) {
        api.forEachNode(row => {
            let rowData = <CmtsRci>row.data;
            if(rowData.rcis != null && rowData.rcis.findIndex(v => v.elementId == this.dataModel.elementId) >= 0){
                row.setSelected(true);
            }
            else { row.setSelected(false); }
        });

        api.setSortModel([{ colId: 'selected', sort: 'asc' }]);
    }

    hasSelectedRows() {
        if(this.cmtsGridOptions.api == null) { return false; }

        return this.cmtsGridOptions.api.getSelectedRows().length > 0;
    }

	setDefaultValue(defaultValue: string) : void {
    	if(defaultValue == "sweepCount"){
    		this.dataModel.sweepCount = 4;
		} else if(defaultValue == "spectrumCount"){
    		this.dataModel.spectrumCount = 10;
		} else if(defaultValue == "apiCount"){
    		this.dataModel.apiCount = 8;
		}
	}

	private translateLocaleString(): void {
		let localizationService = this.localeDataService.getLocalizationService();
		this.RCI_TEST_CONNECT_SUCCESS = localizationService.instant('RCI_TEST_CONNECT_SUCCESS');
		this.RCI_TEST_CONNECT_FAILURE = localizationService.instant('RCI_TEST_CONNECT_FAILURE');
    }
}
