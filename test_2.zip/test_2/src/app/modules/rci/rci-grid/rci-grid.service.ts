import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, Subject} from 'rxjs';
import {RciListModel} from '../models/rci-list.model';
import {ShowAlert} from '../../../utilities/showAlert';
import {Logger} from '../../../utilities/logger';
import {RciGridDataService} from './rci-grid.data.service';
import {RciModel} from '../models/rci.model';
import {
	DeleteItemTabEvent,
	EditItemTabEvent,
	ExportLogMessageTabEvent,
	FirmwareUpgradeShowTabEvent,
	RemoteRebootTabEvent,
	RetrieveRciCpuStatsTabEvent,
	SaveNewItemTabEvent,
	TabAction,
	TabEvent,

	TestRciConnectionTabEvent,
	UpdateItemTabEvent, UpdateRciConnectionStatusTabEvent
} from '../../../shared/tab-event';
import {CmtsModel, CmtsRci} from '../models/cmts-rci.model';
import {ControlMessagesService} from '../../../shared/control.messages.service';
import {LocaleDataService} from '../../../shared/locale.data.service';
import {RciErrorService} from '../rci.error.service';
import {RciCpustatsModel} from "../models/rci-cpustats.model";
import {ALERT_WARNING} from '../../../constant/app.constants';
import {RciFirmwareUpgradeModel} from '../models/rci-firmwareupgrade.model';
import {saveAs} from "file-saver";
import { repeatWhen, publishReplay, refCount, map, combineLatest, filter, take } from 'rxjs/operators';

/**
 * RciGridService provides and handles changes to the state of the currently selected RciModel that is (or is not) being edited.
 */
@Injectable()
export class RciGridService {
    private readonly RCI_RESERVED_ERROR = 11005;
    public ArrayRciIds: any = [];

    /**
     * The currently selected RciModel for the editor. If null, there is currently no item being edited.
     */
    public readonly rciModel = new BehaviorSubject<RciModel>(null);
    public readonly rciCpuStatsModel = new BehaviorSubject<RciCpustatsModel>(null);
    public readonly rciFirmwareUpgradeModel = new BehaviorSubject<RciFirmwareUpgradeModel[]>(null);
    public readonly rciSelectedList = new BehaviorSubject<any[]>(null);
    public readonly rciConnectionStatus = new BehaviorSubject<String>(UpdateRciConnectionStatusTabEvent.unknown);
    public rciUpdate = new Subject();
    public rcigridfilterchangedata: any;
    private rciListUpdated = new Subject();

    constructor(
        private dataService: RciGridDataService,
        private showAlert: ShowAlert,
        private controlMessageService: ControlMessagesService,
        private localeDataService: LocaleDataService,
        private rciErrorService: RciErrorService,
        private logger: Logger) { }

    private _rciList: Observable<RciListModel>;
    public get rciList(): Observable<RciListModel> {
        if (this._rciList == null) {
            this._rciList = this.dataService.getRciList()
                .pipe(repeatWhen(l => this.rciListUpdated),
                // cache and re-issue the result to future subscribers
                publishReplay(),
            refCount());
        }
        
        return this._rciList;
    }

    private _cmtsRciList: Observable<CmtsRci[]>;
    public get cmtsRciList(): Observable<CmtsRci[]> {
        if (this._cmtsRciList == null) {
            this._cmtsRciList = this.dataService.getAllCmtsList()
                .pipe(combineLatest(this.rciList
                    // convert to dictionary mapping cmtsId to RciModel[]
                    .pipe(map(rcis => rcis
                        .reduce((map, rci) => {
                            let rciModel = <RciModel>rci;
                            rci.cmtses.forEach(cmts => {
                                map[cmts.elementId] = map[cmts.elementId] == null ? [rciModel] : map[cmts.elementId].concat([rciModel]);
                            });
                            return map;
                        }, {}))
                )),
                map((result: [CmtsModel[], Map<number, RciModel[]>]) => {
                    // NOTE: This will not work correctly when many-many relationship is allowed.
                    return result[0].map(cmts => {
                        let rciCmts = new CmtsRci();
                        rciCmts.cmts = <CmtsModel>cmts;
                        rciCmts.rcis = result[1][cmts.cmtsId];
                        return rciCmts;
                    });
                })),
                // cache and re-issue the result to future subscribers
                publishReplay(),
                refCount();
        }

        return this._cmtsRciList;
    }

    public emitTabEvent(event: TabEvent) {
       console.log("event action",event.action);
       
        switch (event.action) {
            case TabAction.SYNC_SELECTED:
               
                this.dataService.syncRci(this.ArrayRciIds)
                    .subscribe(
                        r => this.handleSuccessAlertRciSync(r),
                        
                        err => {
                            let errorCode = err.json().errorCode;
                            this.handleRequestError(err); 
                        }
                    );
                break;

            case TabAction.SYNC_ALL:
                    this.dataService.syncRci([])
                    .subscribe(
                        r => this.handleSuccessAlertRciSync(r),
                        
                        err => {
                            let errorCode = err.json().errorCode;
                            this.handleRequestError(err); 
                        }
                    );
            break;
            case TabAction.SAVE_NEW_ITEM:
                let saveRci = (<SaveNewItemTabEvent>event).data;
                this.dataService.addRci(saveRci)
                    .subscribe(
                        r => this.handleRequestSuccess(r),
                        err => {
                            let errorCode = err.errorCode;
                            if (errorCode == this.RCI_RESERVED_ERROR) {
                                saveRci.forcePair = true;
                                this.confirmForcePair(new SaveNewItemTabEvent(saveRci));
                            }
                            else { this.handleRequestError(err); }
                            this.rciUpdate.next();
                        }
                    );
                break;
            case TabAction.UPDATE_ITEM:
                let updateRci = (<UpdateItemTabEvent>event).data;
                this.dataService.updateRci(updateRci)
                    .subscribe(
                        r => this.handleRequestSuccess(r),
                        err => {
                            let errorCode = err.errorCode;
                            if (errorCode == this.RCI_RESERVED_ERROR) {
                                updateRci.forcePair = true;
                                this.confirmForcePair(new UpdateItemTabEvent(updateRci));
                            }
                            else { this.handleRequestError(err); }
                            this.rciUpdate.next();
                        }
                    );
                break;
            case TabAction.ADD_ITEM:
                this.rciModel.next(new RciModel());
				this.rciConnectionStatus.next(UpdateRciConnectionStatusTabEvent.notConnected);
                break;
            case TabAction.DELETE_ITEM:
                this.confirmAndDelete(<DeleteItemTabEvent>event);
                break;
            case TabAction.EDIT_ITEM:
                this.rciModel.next((<EditItemTabEvent>event).data);
				this.rciConnectionStatus.next(UpdateRciConnectionStatusTabEvent.connected);
                break;
            case TabAction.CLEAR_EDITOR:
                this.rciModel.next(null);
                break;
            case TabAction.REFRESH_LIST:
                this.rciListUpdated.next();
                break;
            case TabAction.RCI_REMOTE_REBOOT_ITEM:
                this.confirmAndReboot(<RemoteRebootTabEvent>event);
                break;
            case TabAction.RCI_FIRMWARE_UPGRADE_SHOW:
                this.rciSelectedList.next((<FirmwareUpgradeShowTabEvent>event).data);
                this.dataService.retrieveRciFirmwareUpgradeFiles()
                    .subscribe(r => (
                        this.rciFirmwareUpgradeModel.next(r)),

                        err => this.handleRequestError(err));
                break;
            case TabAction.RCI_FIRMWARE_UPGRADE_CLOSE:
                this.rciFirmwareUpgradeModel.next(null);
                this.rciListUpdated.next();
                this.rciSelectedList.next(null);
                break;
            case TabAction.EXPORT_LOG_MESSAGE:
                this.dataService.getLogMessage((<ExportLogMessageTabEvent>event).data.elementId)
                    .subscribe( r => saveAs(r, 'logs.tar.gz'),
                        err => this.handleRequestError(err));
                break;
            case TabAction.SHOW_RCI_CPU_STATS:
                this.dataService.retrieveRciCpuStats((<RetrieveRciCpuStatsTabEvent>event).data.elementId)
                    .subscribe(r => (this.rciCpuStatsModel.next(r)),
                        err => this.handleRequestError(err));
                break;
            case TabAction.HIDE_RCI_CPU_STATS:
                this.rciCpuStatsModel.next(null);
                break;
            case TabAction.TEST_CONNECTION:
              this.dataService.testRciConnection((<TestRciConnectionTabEvent>event).data.elementId)
                  .subscribe(
                      success => (this.handleSuccessAlert(success)),
                      err => this.handleRequestError(err));
              break
            case TabAction.UPDATE_RCI_CONNECTION_STATUS:
				this.rciConnectionStatus.next((<UpdateRciConnectionStatusTabEvent>event).status);
                break;

        }
    }

    private confirmAndReboot(event: RemoteRebootTabEvent) {
        this.localeDataService.isReady
            .pipe(filter(r => r),
            map(r => this.localeDataService.getLocalizationService()),
            take(1))
            .subscribe(ls => {
                this.showAlert.showCustomWarningAlertConfirm(ls.instant('REBOOT_RCI'), ls.instant('REBOOT_RCI_CONFIRM'),
                    (isConfirm) => {
                        if(isConfirm) {
                            this.dataService.rebootRci(event.data)
                                .subscribe(
                                    r => {
                                        this.showAlert.showSuccessAlert(this.localeDataService.getLocalizationService().instant('RCI_REBOOT_INITIATED'));
                                        this.handleRequestSuccess(r);
                                    },
                                    err => {
                                        this.handleRequestError(err);
                                    })
                        }
                    })
            });
    }

    private confirmAndDelete(event: DeleteItemTabEvent) {
        this.localeDataService.isReady
            .pipe(filter(r => r),
            map(r => this.localeDataService.getLocalizationService()),
            take(1))
            .subscribe(ls => {
                this.showAlert.showCustomWarningAlertConfirm(ls.instant('REMOVE_RCI'), ls.instant('REMOVE_RCI_CONFIRM'),
                    (isConfirm) => {
                        if (isConfirm) {
                            this.dataService.deleteRci(event.data.elementId)
                                .subscribe(
                                    r => this.handleRequestSuccess(r),
                                    err => this.handleRequestError(err));
                        }
                    }
                );
            });
    }

    private handleRequestError(err) {
        //let error = err.json();
        this.logger.error("onError():  error data=", err);
        this.rciErrorService.showError(err);
        this.rciUpdate.next();
    }

    private handleRequestSuccess(r) {
        this.rciListUpdated.next();
        this.rciUpdate.next();
        this.rciModel.next(null);
    }

    private handleSuccessAlert(success) {
        this.showAlert.showSuccessAlert(this.localeDataService.getLocalizationService().instant("TEST_CONNECTION_SUCCESS"));
    }

    private handleSuccessAlertRciSync(success) {
        this.showAlert.showInfoAlert(this.localeDataService.getLocalizationService().instant("RCI_SYNC_SUCCESS"));
    }

    private confirmForcePair(updateEvent: TabEvent) {
        this.showAlert.showCustomWarningAlertConfirm(ALERT_WARNING, this.controlMessageService.getMsg(this.RCI_RESERVED_ERROR), confirm => {
            if (confirm)
                this.emitTabEvent(updateEvent);
        });
    }
}