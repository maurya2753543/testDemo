import { RCI_MODULE } from './../../constant/app.constants';
import { Observable } from 'rxjs';
import { LocaleDataService } from './../../shared/locale.data.service';
import { Component } from "@angular/core";
import { TranslateService } from '@ngx-translate/core';
import { RciHttpService } from './rci.http.service';
import { NavService } from '../../shared/nav.service';

@Component({
    selector: 'rci-component',
    templateUrl: 'rci.component.html'
})
export class RciComponent {
    selectedTab = 'rci';
    public loadComponent: boolean;

    constructor(public localeDataService: LocaleDataService, 
        private rciHttpService: RciHttpService,
        public navService: NavService,
        public translate : TranslateService) {
        let module = RCI_MODULE;
        this.localeDataService.initLanguage(module); /* To set the current browser's language */
    }
    
    LoadTab(tab: string) {
        this.selectedTab = tab.toLowerCase();
    }

    ngOnInit(){
        this.selectedTab = this.rciHttpService.getTab();
        this.translate.onLangChange.subscribe(lang => {
            this.LoadTab('rci');
            this.rciHttpService.setTab('rci');
        })
    }
}