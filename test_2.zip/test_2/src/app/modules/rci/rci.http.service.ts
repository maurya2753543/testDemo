import { map } from 'rxjs/operators';
/**
 * Created by nikita.dewangan on 03-07-2017.
 */

/* Common HTTP service to call http request from Generic Http Service*/

import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import { HttpResponse } from '@angular/common/http';

import {HttpService} from "../../shared/http.service";
import {RciUrlService} from "./rci.url.service";
import { SweepPlanModel } from "./models/sweep-plan.model";
import { RciModel } from "./models/rci.model";
import {RciRequestModel} from './models/rci-request.model';
import {RciCmtsUsPortEnableSweepRequestModel} from './models/rci-cmts-us-port-enable-sweep-request.model';
import { SharedService } from 'src/app/shared/shared.service';
import { PATHTRAK_SETTINGS_PATH } from 'src/app/constant/app.constants';
@Injectable()
export class RciHttpService {
    selectedTab: string;
    public rcigridmodel: any;
    //public rcigridmodel2: any;  
    constructor(private httpService: HttpService,
                private rciUrlService:RciUrlService,
                private sharedService:SharedService) {}

    // get rci list
    public getRciList(): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciListUrl());
    }

    private getHost():string{
        return this.sharedService.getHost() + PATHTRAK_SETTINGS_PATH;
    }
    // get rci details
    public getRciDetail( rciId : number ): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciDetailUrl( rciId ));
    }
    //get rci sweep duration
    public getRciSweep(): Observable<any> {
        return this.httpService.GET(this.getRciSweepUrl());
    }
    public getRciSweepUrl():string {
        return this.getHost() + "getsweepduration";
    }
    // post rci data
    public postRciData(rciId: number, data: any): Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getRciDetailUrl(rciId), data);
    }

    // add rci
    public addNewRci(data: any): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getRciListUrl(), data);
    }

    // sync rci
    public syncRci(data: any): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getRciSyncUrl(), data);
    }

    public updateRci(data: RciModel): Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getItemRciUrl(data.elementId), data);
    }

    // delete rci
    public deleteRci(rciId: number): Observable<any> {
        return this.httpService.DELETE(this.rciUrlService.getItemRciUrl(rciId));
    }

    public getRciEvent(id: number): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciEventUrl(id))
        .pipe(
           map(r => r)
        )
    }

    // get RciSweepPlan list
    public getSweepPlanList(): Observable<any[]> {
        return this.httpService.GET(this.rciUrlService.getSweepPlanListUrl())
        .pipe(
            map(r => r)
        )
            
    }

    public addSweepPlan(data: SweepPlanModel): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getAddSweepPlanUrl(), data);
    }

    public updateSweepPlan(data: SweepPlanModel): Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getUpdateSweepPlanUrl(data.id), data);
    }

    public deleteSweepPlan(sweepPlanId: number): Observable<any> {
        return this.httpService.DELETE(this.rciUrlService.getDeleteSweepPlanUrl(sweepPlanId));
    }

    public getAllCmtsList(): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getCMTSListUrl());
    }

    public rebootRci(rciData: RciModel): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getRciRebootUrl(),rciData);
    }

    public retrieveRciFirmwareUpgradeFiles(): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciFirmwareUpgradeUrl());
    }
    public upgradeFirmware(rciRequest: RciRequestModel): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getRciFirmwareUpgradeUrl(), rciRequest);
    }

    public retrieveLogMessage(rciID: number): Observable<any> {
        return this.httpService.GETBLOB(this.rciUrlService.getLogMessageUrl(rciID)).pipe(map(r => r));
    }

    public retrieveRciCpuStats(rciId: number): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciCpuStatsUrl(rciId));
    }

    public getCmtsUsPortInfo(cmtsUsPortId: number): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRciCmtsUsPortInfoUrl(cmtsUsPortId));
    }

    public setCmtsUsPortInfo(cmtsUsPortId:number, data: any): Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getRciCmtsUsPortInfoUpdateUrl(), data);
    }

    public testRciConnection(rciId: number): Observable<any> {
        return this.httpService.POST(this.rciUrlService.getRciTestUrl(rciId), null);
    }

    public testRciConnectionButton(rci: RciModel): Observable<any>{
        return this.httpService.POST(this.rciUrlService.getRciTestButtonUrl(), rci);
    }

	public deleteFirmwareFile(fileName: string) {
		return this.httpService.DELETEWITHDATA(this.rciUrlService.getRciDeleteFirmwareUrl(), fileName);
	}

	public getRciCmtsUsPortList() {
        return this.httpService.GET(this.rciUrlService.getRciCmtsUsPortListUrl());
	}

	public enableRciCmtsUsPortSweep(request: RciCmtsUsPortEnableSweepRequestModel): Observable<any>{
        return this.httpService.POST(this.rciUrlService.getEnableRciCmtsUsPortSweepUrl(),request,null);
    }

    public exportRPHY_MappingHttp(): Observable<any>{
        return this.httpService.GETBLOB(this.rciUrlService.getExportRPHY_MappingUrl(),null);
    }

    public importRPHY_MappingHttp(data: any): Observable<any>{
        return this.httpService.POST_FILE(this.rciUrlService.getImportRPHY_MappingUrl(), data);
    }

    public disableRciCmtsUsPortSweep(cmtsUsPortId: number): Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getDisableRciCmtsUsPortSweepUrl(cmtsUsPortId),null);
    }

    public pasteMonitoringPlan(data):Observable<any> {
        return this.httpService.PUT(this.rciUrlService.getMonitoringPlanPasteUrl(), data);
    }

    public exportMonitoringPlan(cmtsUsPortId):Observable<any> {
        return this.httpService.GETBLOB(this.rciUrlService.getMonitoringExportPlanUrl(cmtsUsPortId));
    }

    public importMonitoringPlan(formData):Observable<any> {
        return this.httpService.POSTFILEDATA(this.rciUrlService.getMonitoringImportPlanUrl(), formData);
    }

    public getEventList(elementId: number, type): Observable<any> {
        return this.httpService.GET(this.rciUrlService.getRPMEventListUrl(elementId, type));
    }

    public getThresholdLabels():Observable<any> {
        return this.httpService.GET(this.rciUrlService.getThresholdLabelsUrl());
    }

    public getTab() {
        return this.selectedTab;
    }

    public setTab(value: string) {
        this.selectedTab = value;
    }
}
