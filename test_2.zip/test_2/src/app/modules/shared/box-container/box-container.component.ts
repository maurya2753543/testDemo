/**
 * Created by narayan.reddy on 21-08-2017.
 */

import { Component} from '@angular/core';

@Component({
    selector: 'box-container',
    templateUrl: './box-container.component.html'
})
export class BoxContainerComponent {

    constructor() { }

}