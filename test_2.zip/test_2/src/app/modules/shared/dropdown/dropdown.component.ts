/**
 * Created by komal.chaudhary on 11-06-2017.
 */
import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';

@Component({
    selector: 'cust-dropdown',
    templateUrl : 'dropdown.component.html'
})
export class DropdownComponent  implements OnInit{
    private itemList:any;
    private selectedVal:string;
    public isLoaded: boolean = false;
    private variable:string="";
    private searchValue: string = '';
    private searchPlaceholder: string;

    @Input() optionObject: any;
    @Input() label: string;
    @Input() initialVal: string;
    @Output() getValue = new EventEmitter();
    @Input() defaultSelectedVal: string;
    @Input() defaultSelectedObject: {display: any, value: any};
    @Input() hasErrorBackground = false;
    @Input() searchEnable = false;

    constructor(private translate: TranslateService){
        this.searchPlaceholder=translate.instant("SEARCH_NODE");
    }  

    ngOnInit() {
        if (this.initialVal) {
            this.selectedVal = this.initialVal;
        }
        else if (this.defaultSelectedVal || this.defaultSelectedObject) {
            this.selectedVal = this.defaultSelectedVal || this.defaultSelectedObject.display;
        }
    }

    public ngOnChanges(changes:any):void {
        if(changes.optionObject && changes.optionObject.currentValue){
            this.optionObject = changes.optionObject.currentValue;
            this.setList();
        }
    }

    private setList(){
        if (this.optionObject && this.optionObject.options && this.optionObject.options.serverOptions) {
            this.itemList = [];
            let list = [];
            for (let i = 0; i < this.optionObject.options.serverOptions.length; i++) {
                let key = this.optionObject.options.serverOptions[i]?this.optionObject.options.serverOptions[i]:'';
                let value = this.optionObject.options.displayOptions[i]?this.optionObject.options.displayOptions[i].trim():'';
                list.push({
                    'key': key,
                    'value': value
                });
            }

            if(this.defaultSelectedVal && !this.defaultSelectedObject) {
                this.defaultSelectedObject = {
                    display: this.defaultSelectedVal,
                    value: null
                };
            }

            if(this.defaultSelectedObject) {
                list.unshift({
                    key: this.defaultSelectedObject.value,
                    value: this.defaultSelectedObject.display
                });
            }

            if (list.length > 0) {
                this.itemList = list;
            }

            this.isLoaded = true;
        }
    }

    /*
     * @name: ngModelChange
     * @desc: event method invoked on text_changes event of textbox
     * */
    private ngModelChange($evt): void {
        this.optionObject.setValue($evt.target.value);
        this.getValue.emit($evt.target);
        this.selectedVal = $evt.target.innerText;
    }
}
