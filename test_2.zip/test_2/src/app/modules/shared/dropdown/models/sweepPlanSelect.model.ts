export class sweepPlanSelect {

	protected value : string = "";
	protected serverValue: string = "";
	public name: string;
	public defaultValue: string = "";
	public options: SweepPlanOptions;
	public isModified : boolean = false;
	public isValid: boolean = true;
	private isOptional: boolean = false;

	constructor(jsonData){
		this.name = jsonData.name;
		this.value = jsonData.id;
		this.defaultValue = jsonData.defaultValue;

		this.options = new SweepPlanOptions(jsonData);

		this.serverValue = jsonData.value;
	}

	public setValue(value:string): void {
		if(this.value != value){
			this.value = value;
			this.isModified = true;
		}
	}

	public getValue():string{
		return this.value;
	}

	public getServerValue():string {
		return this.serverValue;
	}

	public isOriginalValue() : boolean {
		return (this.serverValue == this.value);
	}

	public setOptional(flag:boolean): void {
		this.isOptional = flag;
	}

	public getOptional(): boolean {
		return this.isOptional;
	}

	public getJSON() : string {
		let generalSetting = {
			"value" : this.value,
			"name" : this.name
		}

		return JSON.stringify(generalSetting);
	}

	public cancel() : void {
		this.value = this.serverValue;
		this.isValid = true;
	}

	/** Update the server value once the value on the server are updated by user */
	public setSavedValue() : void {
		this.serverValue = this.value;
		this.isModified = false;
	}
}

export class SweepPlanOptions {
	public serverOptions: any;
	public displayOptions: any;

	constructor(jsonData){
		this.serverOptions = jsonData.map(function(option){return option.value});
		this.displayOptions = jsonData.map(function(option){return option.name});
	}
}