 /**
 * Created by Jeremy Falkmann on 27-12-2017.
 */
 /**
 /**
  * This class holds the value for particular setting
  */
 export class ContainersSelect {
    /** Value of the settings which can be modified by the server*/
    protected value : string = "";

    /** Valued of the settings from the server which is modified only when user saves updated value to server*/
    protected serverValue : string = "";


    public name : string = "";
    public defaultValue : string = "";

    public options : ContainerOptions;

    /** This field is used to identify whether user entered value is modified or is same */
    public isModified : boolean = false;

     /** This field is used to identify whether user entered value is valid or not */
    public isValid : boolean = true;

    /** This field is used to identify whether field is optional or not */
    private isOptional:boolean = false;



    constructor(jsonData){
        this.name = jsonData.name;
        this.value = jsonData.value;

        this.defaultValue = jsonData.defaultValue;

        const sortedData: any = jsonData.sort(function(a, b){
            const containerA: string = a.containerPath.toLowerCase();
            const containerB: string = b.containerPath.toLowerCase();
            if (containerA < containerB) //sort string ascending
                return -1;
            if (containerA > containerB)
                return 1;
            return 0;
        });

        this.options = new ContainerOptions(sortedData);

        this.serverValue = jsonData.value;

    }

    public setValue(value:string) : void {
        if(this.value != value){
            this.value = value;
            this.isModified = true;
        }
    }

    public getValue():string {
        return this.value;
    }

    public getServerValue():string {
        return this.serverValue;
    }

    public isOriginalValue() : boolean {
        return (this.serverValue == this.value);
    }

    public setOptional(flag:boolean): void {
        this.isOptional = flag;
    }

    public getOptional(): boolean {
        return this.isOptional;
    }

    //Create a json object to send to the server
    public getJSON() : string {

        let generalSetting ={
            "name": this.name,
            "value": this.value,
        }

        return JSON.stringify(generalSetting);
     }


    /** Reset the value with the value received from server */
    public cancel() : void {
        this.value = this.serverValue;
        this.isValid = true;
    }

    /** Update the server value once the value on the server are updated by user */
    public setSavedValue() : void {
        this.serverValue = this.value;
        this.isModified = false;
    }
}

 /** This is specifically for the drop down options */
 export class ContainerOptions {

     /** Server values for the options */
     public serverOptions : any;

     /** Dispaly values for the options */
     public displayOptions : any;

     constructor(jsonData){
         this.serverOptions = jsonData.map(function (option){ return option.id });
         this.displayOptions = jsonData.map(function (option){ return option.containerPath && option.containerPath.replace(/\//g, ' ► ') }); //replace all slashes with arrows
     }

 }
