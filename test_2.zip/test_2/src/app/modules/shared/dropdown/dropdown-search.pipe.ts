import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'dropdownSearch'
})
export class DropdownSearchPipe implements PipeTransform {

    transform(value: any[], searchValue: string): any[] {
        const result: any[] = [];
        result.push(value[0]);
        for (let i = 1; i < value.length; i ++) {
            if (value[i].value.toLowerCase().includes(searchValue.toLowerCase())) {
                result.push(value[i]);
            }
        }
        if (!searchValue.length) {
            return value;
        }
        return result;
    }
}