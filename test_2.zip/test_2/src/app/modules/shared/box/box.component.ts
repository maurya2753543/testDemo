import { TranslateService } from '@ngx-translate/core';
/**
 * Created by narayan.reddy on 21-08-2017.
 */
import { Component, Input ,Output, OnChanges ,EventEmitter, ViewChild, ElementRef} from '@angular/core';
//import {Locale ,LocaleService,LocalizationService } from 'angular2localization';
import {LocaleDataService} from "../../../shared/locale.data.service";
import {DASHBOARD_MODULE} from "../../../constant/app.constants";
import {Router} from '@angular/router';
import {SharedService} from '../../../shared/shared.service';
import {
    ALERT_INFO, MAX_STRING_LIMIT,
} from "../../../constant/app.constants";
import {
    CommonStrings
} from "../../../constant/common.strings";
import {SweetAlert} from "../../../utilities/sweetAlert";

@Component({
    selector: 'box-component',
    templateUrl: './box.component.html',
})
export class BoxComponent{
    @Input('listData') listData: Object[];
    @Input('panelId') panelId: string;
    public lists:any;
    private loadComponent:boolean = false;
    constructor(public localization:TranslateService
        , private router:Router
        , private sharedService:SharedService
        ,private sweetAlert:SweetAlert
        , //public locale:LocaleService
         public localeDataService:LocaleDataService
    ){
       // super(locale, localization);
        let module = DASHBOARD_MODULE;
        this.localeDataService.initLanguage(module); /* To set the current browser's language */

        this.localeDataService.componentCallback.subscribe((response) => {
            this.loadComponent = true;
        });
    }

    //detect changes relate to component variables or value.
    public ngOnChanges(changes:any):void {
        if (changes) {
            if(changes.listData.currentValue){
                this.lists = changes.listData.currentValue;
                this.lists.name = this.localization.instant(this.lists.name);
            }
        }
    }

    //going to view part of the selected element.
    public goToView(listData){
        console.log('list data', listData)
        if(listData){
            if(listData.tab){
                this.sharedService.setRedirectTAB(listData.tab);
            }
            if(listData.filter){
                this.sharedService.setFilterForTAB(listData.txt);
            }else{
                this.sharedService.setFilterForTAB("");
            }
            if(listData.url){
                if (listData.permissionKey && this.sharedService.checkPermissions(listData.permissionKey)) {
                    this.router.navigate([listData.url]);
                } else {
                    if (listData.permissionKey && !this.sharedService.checkPermissions(listData.permissionKey)) {
                        this.sweetAlert.showConformationAlert(ALERT_INFO, "", listData.permissionError, false, true, CommonStrings.OK, CommonStrings.CANCEL,
                            (isConfirm)=> {
                                if (isConfirm) {

                                }
                            }
                        );
                    } else {
                        this.router.navigate([listData.url]);
                    }
                }
            }
        }


    }

    public closeBtnClicked(clickedBoxId: number){
        this.sharedService.updateClosedContainerArr(clickedBoxId);
    }
}
