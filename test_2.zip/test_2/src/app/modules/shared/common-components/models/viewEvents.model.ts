import {ESCAPE_SYMBOL} from "../../../../constant/app.constants";

export class ViewEventsModel extends Array {
    constructor(jsonData, localizationService){
        super();

        if(jsonData){
            for(let i=0; i<jsonData.length; i++) {
                let eventList: EventListItems = new EventListItems(jsonData[i], localizationService);
                this.push(eventList); 
            }
        }
    }
}

export class EventListItems {
    public posted:string;
    public eventType: string;
    public eventId: number;
    public userName: string;
    public eventName: string;

    constructor(obj:any, localizationService) {
        if(obj && localizationService){
           this.posted = obj.posted || ESCAPE_SYMBOL;
           this.eventType = obj.eventType.toUpperCase();
           this.eventName = localizationService.instant(obj.eventType.toUpperCase()) || ESCAPE_SYMBOL;;
           this.eventId = obj.eventId || 0;
           this.userName = obj.userName || "";
       }
    }
}