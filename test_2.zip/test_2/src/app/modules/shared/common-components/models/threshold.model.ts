export class ThresholdModel{
    public ptDb: boolean;
    public name: string;
    public value: string;
    public defaultValue: string;
    public rangeType: boolean;

    constructor(response: any){
        if(response){
            this.ptDb = response.ptDb;
            this.name = response.name;
            this.value = response.value;
            this.defaultValue = response.defaultValue;
            this.rangeType = response.rangeType;
        }
    }
}