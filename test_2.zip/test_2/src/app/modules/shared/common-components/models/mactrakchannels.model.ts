
export class MactrakChannelsModel extends Array {
    constructor(jsonData, localizationService:any){
        super();

        if(jsonData){
            for(let i=0; i<jsonData.length; i++) {
                let channelsData: MactrakChannels = new MactrakChannels(jsonData[i], localizationService);
                this.push(channelsData); 
            }
        }
    }
}

export class MactrakChannels {
    public portId:number;
    public node: string;
    public hcu: string;
    public frequency: number;
    public bandwidth: number;
    public modulation: string;
    public macTrakAvailable: any;
    constructor(channelObj, localizationService) {
        if (channelObj) {
            this.portId = channelObj.portId;
            this.node = channelObj.node;
            this.hcu = channelObj.hcu;
            this.frequency = channelObj.frequency;
            this.bandwidth = channelObj.bandwidth;
            this.modulation = channelObj.modulation;
            this.macTrakAvailable = (channelObj.macTrakAvailable == true) ? localizationService.instant('YES') : localizationService.instant('NO');
        }
    }
}
