import {Injectable} from "@angular/core";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import {SharedService} from "../../../../shared/shared.service";
import {gridCustomComparator} from "../../../../shared/ag-Grid.comparator";

@Injectable()

export class MACTrakChannelsColumnDefinitionService {

     private _HEADER_FIELDS: any = {
        node : {field: "node", name: ""},
        hcu : {field: "hcu", name: ""},
        frequency : {field: "frequency", name: ""},
        bandwidth : {field: "bandwidth", name: ""},
        modulation : {field: "modulation", name: ""},
        macTrakAvailable : {field: "macTrakAvailable", name: ""},
    };
    private ismobileDevice;
    constructor(private localeDataService:LocaleDataService
                ,private sharedService : SharedService){
        this.translateLocaleStr();
    }

     private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();

        this._HEADER_FIELDS.node.name = localizationService.instant('HCU_NODE');
        this._HEADER_FIELDS.hcu.name = localizationService.instant('HCU_HCU');
        this._HEADER_FIELDS.frequency.name = localizationService.instant('HCU_FREQUENCY');
        this._HEADER_FIELDS.bandwidth.name = localizationService.instant('HCU_BANDWIDTH');
        this._HEADER_FIELDS.modulation.name = localizationService.instant('HCU_MODULATION');
        this._HEADER_FIELDS.macTrakAvailable.name = localizationService.instant('HCU_MACTRAK_CHANNELS');
    }


    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        this.ismobileDevice = this.sharedService.isMobileDevice();
        let columnDef: any[] = [
            this.getColumns(this._HEADER_FIELDS.node.name, this._HEADER_FIELDS.node.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.node.name, 90), "text", 'asc'),
            this.getColumns(this._HEADER_FIELDS.hcu.name, this._HEADER_FIELDS.hcu.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.hcu.name, 90), "text"),
            this.getColumns(this._HEADER_FIELDS.frequency.name, this._HEADER_FIELDS.frequency.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.frequency.name, 40), "text"),
            this.getColumns(this._HEADER_FIELDS.bandwidth.name, this._HEADER_FIELDS.bandwidth.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.bandwidth.name, 40), "text"),
            this.getColumns(this._HEADER_FIELDS.modulation.name, this._HEADER_FIELDS.modulation.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.modulation.name, 40), "text"),
            this.getColumns(this._HEADER_FIELDS.macTrakAvailable.name, this._HEADER_FIELDS.macTrakAvailable.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.macTrakAvailable.name, 60), "text")
        ]
        return columnDef;
    }

    private getColumns(headerName: string, field: string, minWidth: number, filter: string, sort?:string): any{
        return {
            headerName: headerName,
            headerTooltip: headerName,
            field: field,
            minWidth : minWidth,
            width: field == this._HEADER_FIELDS.macTrakAvailable.field ? 160 : 120,
            maxWidth : 300,
            filter: filter,
            comparator: gridCustomComparator,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            suppressFilter: true,
            suppressSizeToFit: this.sharedService.isMobileDevice(),
            autoSizeColumns : true,
            filterParams: {newRowsAction: 'keep'},
            sort:sort,
            suppressResize: true,
        }
    }
}
