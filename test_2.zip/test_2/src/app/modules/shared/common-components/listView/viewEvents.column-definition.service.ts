/**
 * Created by yogesh.paisode on 7/14/2017.
 */
import {Injectable} from "@angular/core";
import {SharedService} from "../../../../shared/shared.service";
import {TimeFilter} from "../../../../shared/time.filter";
import {LocaleDataService} from "../../../../shared/locale.data.service";
import { TranslateService } from "@ngx-translate/core";
@Injectable()

export class ViewEventsColumnDefinitionService{

    private _HEADER_FIELDS: any = {
        time : {field: "posted", name: ""},
        event : {field: "eventName", name: ""},
        eventId : {field: "eventId", name: ""},
        username : {field: "userName", name: ""}
    };

    constructor(private localeDataService: LocaleDataService , 
        private sharedService:SharedService,
        public translate: TranslateService){
        this.translateLocaleStr();
    }

    /*
     *@name translateLocaleStr
     *@desc Get Localize strings
     *@return void
     */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();
        console.log(this.translate.instant('TIME'))
        this._HEADER_FIELDS.time.name = localizationService.instant('TIME');
        this._HEADER_FIELDS.event.name = localizationService.instant('EVENT');
        this._HEADER_FIELDS.eventId.name = localizationService.instant('EVENT_ID');
        this._HEADER_FIELDS.username.name = localizationService.instant('USER_NAME');
    }


    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
     */
    public getColumnDef(): any[] {
        let columnDef: any[] = [
            {
                headerName: this._HEADER_FIELDS.time.name,
                headerTooltip: this._HEADER_FIELDS.time.name,
                field: this._HEADER_FIELDS.time.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.time.name, 150),
                sort: 'desc',
                filter: TimeFilter.ParentFilter,
                floatingFilterComponent: TimeFilter.ChildFloatingFilter,
                comparator: this.sharedService.dateComparator,
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                cellRenderer:(params:any)=>{                    
                    return  this.sharedService.getLocaleDate(params.value);
                }
            },
            {
                headerName: this._HEADER_FIELDS.event.name,
                headerTooltip: this._HEADER_FIELDS.event.name,
                field: this._HEADER_FIELDS.event.field,
                minWidth: this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.event.name, 150),
                filter: "text",
                floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                resizable:true,
                cellStyle: {
                    'white-space': 'normal'
                }
            },
            this.getColumns(this._HEADER_FIELDS.eventId.name, this._HEADER_FIELDS.eventId.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.eventId.name, 50), "text"),
            this.getColumns(this._HEADER_FIELDS.username.name, this._HEADER_FIELDS.username.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.username.name, 150), "text")
        ]
        return columnDef;
    }

    private getColumns(headerName: string, field: string, minWidth: number, filter: string): any{
        return {
            headerName: headerName,
            headerTooltip: headerName,
            field: field,
            minWidth: minWidth,
            filter: filter,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            filterParams: {newRowsAction: 'keep'}
        }
    }
}
