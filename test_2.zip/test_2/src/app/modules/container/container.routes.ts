
import { Routes, RouterModule } from '@angular/router';

import {ContainerComponent} from "./container.component";

export const ContainerRoutes: Routes = [
    { path: '', component: ContainerComponent , pathMatch: 'prefix'}
];