import { AfterViewInit, ChangeDetectorRef, Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from "@angular/core";
//import {Locale, LocaleService, LocalizationService} from "angular2localization";

import { SharedService } from "../../shared/shared.service";
import { CONTAINER_MODULE } from "../../constant/app.constants";
import { LocaleDataService } from "../../shared/locale.data.service";
import { ContainerTabComponent } from "./container-tab/container-tab.component";
import { ContainerMetaTypeComponent } from "./container-meta-tab/container-meta-type.component";
import { TranslateService } from "@ngx-translate/core";
import { ContainerDataService } from "./container.data.service";
import { NavService } from '../../shared/nav.service';

@Component({
    templateUrl: "container.component.html",
    selector: "container"
})
export class ContainerComponent implements AfterViewInit, OnInit {

    public loadComponent: boolean = true;
    private CONTAINER_Ref: any;
    private CONTAINER_MET_TYPE_Ref: any;
    public selectedTab: string;
    private oldSelectedSettings: Object = {};
    private CONTAINER_NAME: string = "CONTAINER_NAME";
    private META_TAG: string = "META_TAG";
    private TABLE_LIST_SHOWING: string;
    private TABLE_LIST_SHOWING_OF: string;

    @ViewChild('target_CONTAINER', {read: ViewContainerRef}) _target_CONTAINER;
    @ViewChild('target_CONTAINER_META_TYPE', {read: ViewContainerRef}) _target_CONTAINER_META_TYPE;

    constructor(
        public localeDataService: LocaleDataService,
        public navService: NavService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private sharedService: SharedService,
        private containerDataService: ContainerDataService,
        private cd: ChangeDetectorRef,
        public translate: TranslateService) {
            let module = CONTAINER_MODULE;
            this.localeDataService.initLanguage(module);
    }

    ngOnInit() {
        this.translate.onLangChange.subscribe(lang => {
            this.translateLocaleString();
            this.containerDataService.setTab('container-tab');
            this.LoadTab("container-tab");
        })
        this.loadComponent = true;
    }

    ngAfterViewInit() {
        this.LoadTab(this.containerDataService.getTab() ? this.containerDataService.getTab() : '');
        this.cd.detectChanges();
    }

    //function used to load tabs of Container section.
    LoadTab(tab: string): void {
        let selectedTab = this.sharedService.getRedirectTAB();
        this.selectedTab = tab && tab.toLowerCase();
        if (selectedTab && selectedTab.length > 0) {
            this.selectedTab = selectedTab;
            this.sharedService.setRedirectTAB("");
        }
        switch (this.selectedTab) {
            case 'container-tab':
                this.CONTAINER_Ref !== this.oldSelectedSettings["comp"] && this.CONTAINER_Ref ? this.CONTAINER_Ref.instance.onTabSwitch(true) : "";
                this.CONTAINER_Ref = this.createComponentOnClick(ContainerTabComponent, this._target_CONTAINER, this.CONTAINER_Ref);
                break;
            case 'containermetatype':
                this.CONTAINER_MET_TYPE_Ref !== this.oldSelectedSettings["comp"] && this.CONTAINER_MET_TYPE_Ref ? this.CONTAINER_MET_TYPE_Ref.instance.onTabSwitch(true) : "";
                this.CONTAINER_MET_TYPE_Ref = this.createComponentOnClick(ContainerMetaTypeComponent, this._target_CONTAINER_META_TYPE, this.CONTAINER_MET_TYPE_Ref);
                break;
            default:
                break;
        }
    }

    /* Function used to create component on settings section link click */
    private createComponentOnClick(clickedComponent: any, currentViewContainer: any, currentCompRef: any): void {
        this.oldSelectedSettings['comp'] ? this.oldSelectedSettings['viewRef'].detach() : '';
        if (!currentCompRef) {
            let componentFactory: any = this.componentFactoryResolver.resolveComponentFactory(clickedComponent);
            currentCompRef = currentViewContainer.createComponent(componentFactory);
        } else {
            currentViewContainer.insert(currentCompRef.hostView);
        }
        this.oldSelectedSettings = { 'comp': currentCompRef, 'viewRef': currentViewContainer };
        return currentCompRef;
    }

    //function :: used for localization
    private translateLocaleString(): void {
        let localization = this.localeDataService.getLocalizationService();
        this.TABLE_LIST_SHOWING = localization.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localization.instant('TABLE_LIST_SHOWING_OF');
        this.CONTAINER_NAME = this.translate.instant('CONTAINER_NAME');
        this.META_TAG = this.translate.instant('META_TAG');
    }
}