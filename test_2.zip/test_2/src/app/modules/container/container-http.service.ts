import {Injectable} from "@angular/core";
import {Observable} from "rxjs";

import {HttpService} from "../../shared/http.service";
import {ContainerUrlService} from "./container-url.service";

@Injectable()
export class ContainerHttpService{

    constructor(private httpService: HttpService, private containerUrlService: ContainerUrlService){}

    public getContainerList(): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getContainerUrl());
    }

    public deleteContainer(id: number): Observable<any>{
        return this.httpService.DELETE(this.containerUrlService.getContainerUrl()+ "/" + id);
    }

    public getContainerMetaTypeList(): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getContainerMetaTypeListUrl());
    }

    public syncContainerData(id: any): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getSyncContainerDataUrl(id));
    }

    public updateMetaType(data: any): Observable<any>{
        return this.httpService.PUT(this.containerUrlService.getContainerMetaTypeListUrl(), data);
    }

    public createMetaType(data: any): Observable<any>{
        return this.httpService.POST(this.containerUrlService.getContainerMetaTypeListUrl(), data);
    }

    public deleteMetaType(id: number): Observable<any>{
        return this.httpService.DELETE(this.containerUrlService.getContainerMetaTypeListUrl()+ "/" + id);
    }

    public createContainer(data: any): Observable<any>{
        return this.httpService.POST(this.containerUrlService.getContainerUrl(), data);
    }

    public updateContainer(data: any): Observable<any>{
        return this.httpService.PUT(this.containerUrlService.getContainerUrl(), data);
    }

    public getHardwareList(): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getHardwareListUrl());
    }

    public getHardwareNodesHcu(id: number): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getHardwareNodesHcuUrl(id));
    }

    public getHardwareNodesCmts(id: number): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getHardwareNodesCmtsUrl(id));
    }

    public moveContainers(containerId: string, data: any): Observable<any>{
        return this.httpService.POST(this.containerUrlService.getContainerMoveUrl(containerId), data);
    }

    public moveElements(containerId: string, data: any): Observable<any>{
        return this.httpService.POST(this.containerUrlService.getElementMoveUrl(containerId), data);
    }

    public getNodeOnlyContainers(): Observable<any>{
        return this.httpService.GET(this.containerUrlService.getNodeOnlyContainersUrl());
    }

    public getAllContainers(): Observable<any> {
        return this.httpService.GET(this.containerUrlService.getAllContainersUrl());
    }
}
