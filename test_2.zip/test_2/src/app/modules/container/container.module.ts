import {FormsModule} from "@angular/forms";
import {NgModule} from "@angular/core";
import {SharedModule} from "../shared/shared.module";
import {AgGridModule} from "ag-grid-angular";
import {ContainerRoutes} from "./container.routes";
import {MoveContainerComponent} from "./container-tab/move-view/moveContainer.component";
import {CommonModule} from "@angular/common";
import {AddElementViewComponent} from "./container-tab/add-element-view/add-element-view.component";
import {ContainerSharedService} from "./container-shared.service";
import {ContainerService} from "./container-tab/container.service";
import {ContainerColumnDefinitionService} from "./container-tab/container.column-definition.service";
import {ContainerUrlService} from "./container-url.service";
import {ContainerHttpService} from "./container-http.service";
import {ContainerDataService} from "./container.data.service";
import {AddContainerComponent} from "./container-tab/add-update-container-view/add-update-container-view.component";
import {ContainerComponent} from "./container.component";
import {ContainerMetaTypeComponent} from "./container-meta-tab/container-meta-type.component";
import {ContainerTabComponent} from "./container-tab/container-tab.component";
import {ContainerMetaTypeTabColumnDefinitionService} from "./container-meta-tab/container-meta-type-tab.column-definition.service";
import {AddUpdateMetaTypeComponent} from "./container-meta-tab/add-update-meta-type-view/add-update-meta-type.component";
import {LocaleDataService} from "../../shared/locale.data.service";
import { RouterModule } from "@angular/router";
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { LanguageService } from 'src/app/shared/locale.language.service';
import { HttpClient } from "@angular/common/http";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import * as AppConstants from './../../constant/app.constants';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/container-locale-`, ".json");
  }
@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        SharedModule,
        AgGridModule.withComponents([ContainerComponent]),
        RouterModule.forChild(ContainerRoutes),
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }}),
    ],
    declarations: [
        //Wrapper component would go here
        MoveContainerComponent,
        AddElementViewComponent,
        AddContainerComponent,
        ContainerComponent,
        ContainerTabComponent,
        ContainerMetaTypeComponent,
        AddUpdateMetaTypeComponent
    ],
    entryComponents: [
        //Dynamic component would go here
        AddElementViewComponent,
        MoveContainerComponent,
        AddContainerComponent,
        ContainerTabComponent,
        ContainerMetaTypeComponent,
        AddUpdateMetaTypeComponent
    ],
    providers: [
        //Services would go here
        LocaleDataService,
        ContainerSharedService,
        ContainerService,
        ContainerColumnDefinitionService,
        ContainerMetaTypeTabColumnDefinitionService,
        ContainerUrlService,
        ContainerHttpService,
        ContainerDataService,
        TranslateService,
        LanguageService
    ]
})
export class ContainerModule {
}
