import {Component, Input} from "@angular/core";

import {ContainerSharedService} from "../../container-shared.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {ALERT_ERROR} from "../../../../constant/app.constants";
import {ContainerDataService} from "../../container.data.service";
import {ContainerService} from "../container.service";
import {LocaleDataService} from "../../../../shared/locale.data.service";

@Component({
    selector: "moveContainer",
    templateUrl: "moveContainer.component.html"
})
export class MoveContainerComponent {

    private isDirty: boolean = false;
    public dropDownList: any[] = [];
    public closeSider: boolean = false;
    private rowData: any;
    private selectedRows: any;
    private isContainer: boolean;
    private isValid: boolean = true;
    public selectedName: string = null;
    private selectedId: string;
    private containerData: any;
    private CONTAINER_MOVE_ERROR: string = "";
    private ELEMENT_MOVE_ERROR: string = "";
    private SELECT: string = "";
    private CONTAINER_MAX_LIMIT: string = "";

    @Input('childData') childData: any;

    constructor(private localeDataService: LocaleDataService,
                private containerSharedService: ContainerSharedService,
                private containerDataService: ContainerDataService,
                private containerService: ContainerService,
                private showAlert: ShowAlert) {
    }

    ngOnInit() {
        this.translateLocaleString();
        this.loadDropdowns();
    }

    private loadDropdowns(): void {
        if (this.childData) {
            this.rowData = this.childData.rowData;
            this.selectedRows = this.childData.selectedRows;
            this.isContainer = this.childData.isContainer;
            this.dropDownList.length = 0;
            this.dropDownList.push({
                id: Math.random().toString(), data: [{name: this.rowData[0].name, id: this.rowData[0].id}],
                selected: this.SELECT
            });
        }
    }

    private processDataTree(id: string, type: string): void {
        let group: any;
        this.isDirty = false;
        for (let i = 0; i < this.rowData.length; i++) {
            if (!this.isDirty) {
                group = this.rowData[i];
                if (group.id == id) {
                    if (type === "other") {
                        this.createList(group.children, group.id);
                    }
                } else {
                    this.processChild(group.children, id, type);
                }
            } else {
                break;
            }
        }// End of for
    }


    private processChild(children: any, id: string, type: string) {
        let processChild: boolean;
        let child: any;
        for (let i = 0; i < children.length; i++) {
            processChild = false;
            child = children[i];
            if (this.isDirty) {
                break;
            }
            if (child.group) {
                if (type === "other") {
                    if (child.id === id && !child.isElementGroup) {
                        processChild = false;
                        this.isDirty = true;
                        this.createList(child.children, child.id);
                        break;
                    } else {
                        processChild = true;
                    }
                } else if (type === "validate") {
                    if (child.id == id) {
                        if (!(child.containerChildType === "Undefined") && child.children.length) {
                            if (!this.isContainer && !child.isElementGroup) {
                                this.isValid = false;
                                this.showInfoAlert(ALERT_ERROR, this.ELEMENT_MOVE_ERROR);
                            } else if (this.isContainer && child.isElementGroup) {
                                this.isValid = false;
                                this.showInfoAlert(ALERT_ERROR, this.CONTAINER_MOVE_ERROR);
                            }
                        }
                        if (!child.children.length) {
                            child.containerChildType = "default";
                            child.isElementGroup = false;
                            child.group = "default";
                        }
                        this.isDirty = true;
                        break;
                    } else {
                        processChild = true;
                    }
                }

            }// End of If

            if (processChild) {
                this.processChild(child.children, id, type);
            }// End of If
        }
    }

    private createList(child: any[], id: string): void {
        let data: any[] = [];
        let isValid: boolean = false;
        let isTypeContainer: boolean;

        child.forEach((child) => {
            isTypeContainer = this.isContainer ? !child.isElementGroup : true;
            if (child.group && this.selectedRows) {
                isValid = false;
                for (let i = 0; i < this.selectedRows.length; i++) {
                    if (this.selectedRows[i].id == child.id) {
                        isValid = false;
                        break;
                    } else {
                        isValid = true;
                    }
                }
                if (isValid) {
                    data.push(child);
                }
            }
        });
        if (data.length > 0) {
            this.dropDownList.push({id: id, data: data, selected: this.SELECT});
        }
        //this.dropDownList.push({id: id, data: child});
    }

    private loadNextLevel(level: any, wrapper: any): void {
        let id = level.id;
        for (let i = 0; i < this.dropDownList.length; i++) {
            if (wrapper.id == this.dropDownList[i].id && !(i + 1 == this.dropDownList.length)) {
                this.dropDownList.splice(i + 1);
            }
        }
        wrapper.selected = level.name;
        this.selectedName = level.name;
        wrapper["selectedId"] = level.id;
        this.processDataTree(id, "other");
    }

    public moveContainers(type: string): void {
        if (type === "move") {
            let isDirty: boolean = true;
            let i: number = 1;
            this.isValid = true;
            if (type === "move") {
                do {
                    this.selectedId = this.dropDownList[this.dropDownList.length - i].selectedId;
                    if (this.selectedId && !this.selectedId.toString().startsWith(this.SELECT)) {
                        isDirty = false;
                        break;
                    }
                    i++;
                } while (isDirty);
                this.processDataTree(this.selectedId, "validate");
            }

            if (this.isValid) {
                this.containerService.containerData = [];
                this.selectedRows.forEach((row: any) => {
                    this.containerService.processContainerData(row);
                });
                this.containerData = this.containerService.containerData;

                if (this.isContainer) {
                    let length: number = this.containerService.getPath(this.selectedId).split(" > ").length;
                    if (length < 10 && !this.containerService.getMaxCount(length)) {
                        this.moveContainer();
                    } else {
                        this.showErrorAlert(this.CONTAINER_MAX_LIMIT);
                    }
                } else {
                    this.moveElements();
                }
            }//End of If
        } else {
            this.selectedId = null;
            this.notifyGrid();
        }
    }

    private showErrorAlert(message: string): void {
        this.showAlert.showSimpleAlert(ALERT_ERROR, message);
    }

    private moveContainer(): void {
        this.containerData.forEach((container: any) => {
            if (container.children.length === 0) {
                container.containerChildType = container.group = "Undefined";
            }
        });
        this.containerDataService.moveContainers(this.selectedId.toString(), this.containerData).subscribe(() => {
            this.notifyGrid();
        }, this.onError.bind(this));
    }

    private moveElements(): void {
        this.containerDataService.moveElements(this.selectedId.toString(), this.containerData).subscribe(() => {
            this.notifyGrid();
        }, this.onError.bind(this));
    }

    private notifyGrid(): void {
        this.containerSharedService.getCloseSliderSubject()
            .next({type: "moveContainer", selectedId: this.selectedId});
    }

    private showInfoAlert(type: string, message: string): void {
        this.showAlert.showSimpleAlert(type, message);
    }

    //Handle error
    private onError(error): void {
        this.selectedId = null;
        this.showAlert.showErrorAlert(error);
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.ELEMENT_MOVE_ERROR = localizationService.instant('ELEMENT_MOVE_ERROR');
        this.CONTAINER_MOVE_ERROR = localizationService.instant('CONTAINER_MOVE_ERROR');
        this.SELECT = localizationService.instant('DEFAULT').toLowerCase();
        this.SELECT = this.SELECT.charAt(0).toUpperCase() + this.SELECT.substring(1, this.SELECT.length);
        this.CONTAINER_MAX_LIMIT = localizationService.instant('CONTAINER_MAX_LIMIT');
    }
}