import {Component, Input} from "@angular/core";

import {ContainerDataService} from "../../container.data.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {ContainerModel} from "../model/container.model";
import {ContainerService} from "../container.service";
import {ContainerSharedService} from "../../container-shared.service";
import {LocaleDataService} from "../../../../shared/locale.data.service";

@Component({
    templateUrl: "add-update-container-view.component.html",
    selector: "add-container-view"
})
export class AddContainerComponent{
    public closeSider: boolean = false;
    private containerMetaTypeList: any[];
    private metaName: string = null;
    private containerModel: ContainerModel = null;
    public isEdit: boolean;
    private CONTAINER_ADD_META_TYPE: string = "";
    private DEFAULT: string = "";
    private defaultOption: string = "";
    private isNameErrorDirty: boolean = false;

    @Input('childData') childData: any;

    private containerObj: any = {
        "name": null,
        "address": null,
        "containerMetaType": null,
        "parentId": 0
    };

    constructor(private containerDataService: ContainerDataService, private showAlert: ShowAlert,
                private containerService: ContainerService,
                private localeDataService: LocaleDataService,
                private containerSharedService: ContainerSharedService){}

    ngOnInit(){
        this.translateLocaleString();
        this.setData();
        this.getMetaList();
    }

    private setData(): void{
        this.containerObj.parentId = this.childData.container.id;
        this.isEdit = this.childData.isEdit;
        if(!this.childData.isEdit){
            this.containerObj["id"] = this.childData.container.id;
            this.containerObj["version"] = this.childData.container.version;
            this.containerObj.name = this.childData.container.name;
            this.containerObj.address = this.childData.container.address;
            this.containerObj.containerMetaType = this.childData.container.containerMetaType;
            if(this.containerObj.containerMetaType){
                this.defaultOption = this.childData.container.containerMetaType.name;
            }
            this.containerObj.parentId = this.childData.container.parentId;
        }
    }

    private enableEdit(): void{
        this.isEdit = true;
        this.syncContainerData();
    }

    private syncContainerData(): void{
        this.containerDataService.syncContainerData(this.containerObj.id).subscribe((containerData: any)=>{
            this.containerObj.name = containerData.name;
            this.containerObj.address = containerData.address;
            this.containerObj.containerMetaType = containerData.containerMetaType;
            this.containerObj.version = containerData.version;
        },this.onError.bind(this));
    }

    private getMetaList(): void{
        this.containerDataService.getContainerMetaTypeList().subscribe((containerMetaTypeList: any[])=>{
            this.containerMetaTypeList = containerMetaTypeList;
        },this.onError.bind(this));
    }

    private setMetaType(metaType: any): void{
        let isAddMetaTypeSelected: boolean = (metaType === this.CONTAINER_ADD_META_TYPE);
        let isDefaultSelected: boolean = (metaType === this.DEFAULT);

        if(!(isAddMetaTypeSelected) && !(isDefaultSelected)){
            this.containerObj.containerMetaType = metaType;
            this.defaultOption = metaType.name;
        }else{
            this.containerObj.containerMetaType = null;
            this.metaName = null;
            if(isAddMetaTypeSelected){
                this.defaultOption = this.CONTAINER_ADD_META_TYPE;
            }else{
                this.defaultOption = this.DEFAULT;
            }
        }
    }

    public addContainer(): void{
        if(!this.containerObj.containerMetaType && this.metaName){
            this.containerObj.containerMetaType = {"name": this.metaName};
        }
        if(this.childData.isEdit){
            this.createContainer();
        }else{
            this.updateContainer();
        }
    }

    private updateContainer(): void{
        this.containerDataService.updateContainer(this.containerObj).subscribe((container: any)=>{
            this.createContainerMode(container);
        },this.onError.bind(this));
    }

    private createContainer(): void{
        this.containerDataService.createContainer(this.containerObj).subscribe((container: any)=>{
           this.createContainerMode(container);
        },this.onError.bind(this));
    }

    private createContainerMode(container: any): void{
        this.containerModel = new ContainerModel();
        this.containerService.setFields(this.containerModel, container);
        this.closeSlider("add");
    }

    public closeSlider(type: string): void{
        if(!type){
            this.containerModel = null;
        }
        this.containerSharedService.getCloseSliderSubject().next({type: "addContainer", containerData: this.containerModel, isEdit: this.childData.isEdit});
    }

    //Handle error
    private onError(error): void{
        this.containerModel = null;
        this.showAlert.showErrorAlert(error);
        if(!this.childData.isEdit){
            this.syncContainerData();
        }

    }

    private nameValidation(): void{
        if(this.containerObj.name.length === 0){
            this.isNameErrorDirty = true;
        }else{
            this.isNameErrorDirty = false;
        }
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.CONTAINER_ADD_META_TYPE = localizationService.instant('CONTAINER_ADD_META_TYPE');
        this.DEFAULT = localizationService.instant('DEFAULT').toLocaleLowerCase();
        this.DEFAULT = this.DEFAULT.charAt(0).toUpperCase() + this.DEFAULT.substring(1);
        this.defaultOption = this.DEFAULT;
    }
}