export class ContainerModel{
    public id: number;
    public name: string;
    public address: string;
    public containerChildType: string;
    public containerMetaType: any;
    public parentId: number;
    public childrenContainers: any[];
    public childrenElements: any[];
    public version: number;
    public containerPath: string;

    public open: boolean = false;
    public group: boolean;
    public isElementGroup: boolean;

    public elementType: string;

    public children: ContainerModel[] = [];
}