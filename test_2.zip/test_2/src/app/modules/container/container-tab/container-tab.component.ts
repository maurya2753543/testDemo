import {Component, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';

import {Grid} from "../../../shared/ag-grid.options";
import {AddElementViewComponent} from "./add-element-view/add-element-view.component";
import {ContainerSharedService} from "../container-shared.service";
import {MoveContainerComponent} from "./move-view/moveContainer.component";
import {ShowAlert} from "../../../utilities/showAlert";
import {ALERT_ERROR, ALERT_SUCCESS} from "../../../constant/app.constants";
import {ContainerService} from "./container.service";
import {ContainerColumnDefinitionService} from "./container.column-definition.service";
import {ContainerDataService} from "../container.data.service";
import {AddContainerComponent} from "./add-update-container-view/add-update-container-view.component";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ThemeService} from "../../../shared/theme.service";
import {SharedService} from "../../../shared/shared.service";

@Component({
    selector : "container-tab",
    templateUrl: "container-tab.component.html"
})

export class ContainerTabComponent{

    public containerGridOptions: Grid = new Grid();
    public rowData: any[];
    private isContainer: boolean = false;
    public actionDropDownList: any = {isAddContainer: false,
        isAddElement: false,
        isEdit: false,
        isDelete: false,
        isMove: false,
        isSelectAllChildren: false,
        isDeselectAll: false};
    private CONTAINER_ELEMENT_ERROR: string = "";
    private CONTAINER_CONTAINER_ERROR: string = "";
    private CONTAINER_DELETE_CONFIRMATION: string = "";

    private ADD_ELEMENT_SUCCESS: string = "";
    private MOVE_CONTAINER_SUCCESS: string = "";
    private MOVE_ELEMENT_SUCCESS: string = "";
    private ADD_CONTAINER_SUCCESS: string = "";
    private EDIT_CONTAINER_SUCCESS: string = "";
    private DELETE_CONTAINER_SUCCESS: string = "";
    private CONTAINER_SELECT_ALL_CHILDREN: string = "";
    private CONTAINER_MAX_LIMIT: string = "";
    private DESELECT_ALL: string = "";
    private serverId: any;
    public newTime: string = "";
    public getContextMenuItems: any;

    private CMTS_TAB_COL_EDIT: string = "";
    private MOVE: string = "";
    private ADD_CONTAINER: string = "";
    private ADD_ELEMENTS: string = "";
    private HCU_DELETE_BTN_TEXT: string = "";
    public filterText: string = "";
    public actionDropdownClass: string = "dropdown inline container-actions";
    private isNotContexMenu: boolean = true;

    private EXPAND_ALL: string;
    private COLLAPSE_ALL: string;

    @ViewChild('containerView', { read: ViewContainerRef }) _containerViewEvents;

    constructor(private localeDataService: LocaleDataService,
                public ThemeService:ThemeService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private containerService: ContainerService,
                private showAlert: ShowAlert,
                private containerColumnDefinitionService: ContainerColumnDefinitionService,
                private containerDataService: ContainerDataService,
                private containerSharedService: ContainerSharedService,
                private sharedService :SharedService){
        this.containerGridOptions.setFloatingFilter(false);
    }

    ngOnInit() {
        //Init Contex menu
        this.setContextMenu();
        //Init Translation
        this.translateLocaleString();
        //Init Grid options
        this.containerService.setGridOptions(this.containerGridOptions);
        //Init Sibject Listener
        this.initSubjectListener();
        //Set Column definition
        this.setColumnDefination();
    }

    /*
    * @Method :: Set ag-Grid Context menu
    * */
    private setContextMenu(): void{
        this.getContextMenuItems =  (params) => {
            let result: any[];
            let rowNode: any = params.node;
            rowNode.setSelected(true);
            document.getElementById("containerAction").className = this.actionDropdownClass;
            this.selectionChanged();
            this.isNotContexMenu = false;
            result = [
                {
                    name: this.CMTS_TAB_COL_EDIT,
                    disabled: !this.actionDropDownList.isEdit,
                    action: () => {
                        this.updateContainer();
                    }
                },
                {
                    name: this.MOVE,
                    disabled: !this.actionDropDownList.isMove,
                    action: () => {
                        this.moveContainer();
                    }
                },
                {
                    name: this.CONTAINER_SELECT_ALL_CHILDREN,
                    disabled: !this.actionDropDownList.isSelectAllChildren,
                    action: () => {
                        this.selectAllChildren();
                    }
                },
                {
                    name: this.ADD_CONTAINER,
                    disabled: !this.actionDropDownList.isAddContainer,
                    action: () => {
                        this.setContainer();
                    }
                },
                {
                    name: this.ADD_ELEMENTS,
                    disabled: !this.actionDropDownList.isAddElement,
                    action: () => {
                        this.addElement();
                    }
                },
                {
                    name: this.HCU_DELETE_BTN_TEXT,
                    disabled: !this.actionDropDownList.isDelete,
                    action: () => {
                        this.deleteSelected();
                    }
                },
                {
                    name: this.DESELECT_ALL,
                    disabled: !this.actionDropDownList.isDeselectAll,
                    action: () => {
                        this.deselectAll();
                    }
                }
            ];

            if(rowNode.group){
                result.push( {
                    name: this.EXPAND_ALL,
                    action: () => {
                        this.containerService.toggleTreeState(true, rowNode.data.id);
                    },
                    disabled: rowNode.expanded || !rowNode.data.children.length
                },{
                    name: this.COLLAPSE_ALL,
                    action: () => {
                        this.containerService.toggleTreeState(false, rowNode.data.id);
                    },
                    disabled: !rowNode.expanded || !rowNode.data.children.length
                });
            }
            return result;
        };
    }

    /*
   * @Event :: ag-Grid ready
   * */
    public gridReady(){
        this.containerGridOptions.setsuppressMenuColumnPanel(true);
        this.containerGridOptions.setSupresstoolPanelRowsGroup(true);
        this.containerGridOptions.settoolPanelSuppressValues(true);
        this.containerGridOptions.settoolPanelSuppressPivots(true);
        this.containerGridOptions.setDragLeaveHidesColumns(true);
        this.getContainerList();
        this.onResize();
    }

    public clearFilter(): void{
        this.filterText = "";
        this.containerGridOptions.api.setQuickFilter(this.filterText);
    }


    /*
   * @Method :: Refresh container list
   * */
    public refresh(){
        this.getContainerList();
    }

    /*
   * @Method :: API call get contaiber List
   * */
    private getContainerList(): void{
        this.showLoadingOverlay();
        this.containerDataService.getContainerList().subscribe((data: any)=>{
            this.containerService.containerData.length = 0;
            this.rowData = this.containerService.processContainerData(data);
            this.serverId = data.id;
            this.rowData[0].open = true;
            this.containerService.updateRowData(this.rowData);
            this.newTime = this.sharedService.getLocaleMediumDate(new Date());
        },this.onError.bind(this));
    }

    //@method :: shows overlay on grid.
    private showLoadingOverlay(): void {
        this.containerGridOptions.api.showLoadingOverlay();
    }

    /*
   * @Method :: Set ag-Grid column definition
   * */
    private setColumnDefination(): void{
        this.containerGridOptions.getNodeChildDetails = (data) =>{
            if (data.group) {
                return {
                    group: true,
                    children: data.children,
                    expanded: data.open
                };
            } else {
                return null;
            }
        };
        this.containerGridOptions.setColumnDefs(this.containerColumnDefinitionService.getColumnDefinition());
    }

    /*
   * @Method :: Close slider event listener
   * */
    private initSubjectListener(): void{
        this.closeSliderSubjectListener();
    }

    /*
   * @Method :: Add new container
   * */
    public setContainer(): void{
        let rows: any = this.containerService.getSelectedRows();
            let length: number = this.containerService.getPath(rows[0].id).split(" > ").length;
            if(length < 10){
                this.createComponentOnClick(AddContainerComponent, {container: rows[0], isEdit: true});
            }else{
                this.showErrorAlert(this.CONTAINER_MAX_LIMIT);
            }
    }

    /*
   * @Method :: Edit container
   * */
    public updateContainer(): void{
        let rows: any = this.containerService.getSelectedRows();
        if(rows && rows.length === 1){
            this.createComponentOnClick(AddContainerComponent, {container: rows[0], isEdit: false});
        }
    }

    /*
    * @Event :: On ag-Grid model update
    * */
    public modelUpdated(): void{
        this.containerColumnDefinitionService.activeIds.forEach((idObj)=>{
            if(!idObj.isDirty){
                idObj.isDirty = true;
                this.containerService.addListener(idObj.id);
            }
        });
        this.selectionChanged();
        this.onResize();
    }

    /*
   * @Method and @Event :: On ag-Grid selection change
   * */
    public selectionChanged(): void{
        let rows: any = this.containerService.getSelectedRows();
        let isDirty: boolean = false;
        this.actionDropDownList = {isAddContainer: false,
            isAddElement: false,
            isEdit: false,
            isDelete: false,
            isMove: false,
            isSelectAllChildren: false,
            isDeselectAll: false};

        if(rows.length > 0){
            this.actionDropDownList.isDeselectAll = true;
            this.toggleEditAddOptions(rows);
            this.toggleIsMove(rows);

            for(let i = 0; i < rows.length; i ++){
                if(rows[i].group){
                    isDirty = true;
                    break;
                }
            }

            this.actionDropDownList.isSelectAllChildren = isDirty;

            if(this.isNotContexMenu){
               /* let element: any = document.querySelectorAll(".ag-menu");
                if(element){
                    element.forEach((e) => {
                        try{
                            e.parentNode.removeChild(e);
                        }catch (ex){}
                    });
                }*/
            }

            this.isNotContexMenu = true;
        }
    }
    /*
       * @Method :: deselect all rows
       * */
    public deselectAll(): void{
        this.containerGridOptions.api.deselectAll();
    }

    /*
   * @Method :: toggle move option
   * */
    private toggleIsMove(rows: any): void{
        let isDirty: boolean = false;
        for(let i = 0; i < rows.length; i ++){
            if(i === 0){
                if(rows[i].group){
                    this.isContainer = true;
                }else{
                    this.isContainer = false;
                }
            }else{
                if(this.isContainer){
                    if(!rows[i].group){
                        isDirty = true;
                        break;
                    }
                }else{
                    if(rows[i].group){
                        isDirty = true;
                        break;
                    }
                }
            }

            if(rows[i].id == this.serverId){
                isDirty = true;
                break;
            }
        }
        if(!isDirty){
            this.actionDropDownList.isMove = true;
        }
    }

    /*
   * @Method :: toggle edit option
   * */
    private toggleEditAddOptions(rows: any): void{
        if(rows.length === 1){
            if(rows[0].group){
                this.actionDropDownList.isEdit = true;
                if(rows[0].id != this.serverId){
                    this.actionDropDownList.isDelete = true;
                }
                if(rows[0].children.length === 0){
                    this.actionDropDownList.isAddElement = true;
                    this.actionDropDownList.isAddContainer = true;
                }else if(rows[0].isElementGroup){
                    this.actionDropDownList.isAddElement = true;
                }else if(!rows[0].isElementGroup){
                    this.actionDropDownList.isAddContainer = true;
                }
            }
        }
    }

    /*
   * @Method :: Move Container
   * */
    public moveContainer(): void{
        this.moveSelected(this.isContainer);
    }

    /*
   * @Method :: Delete current selection
   * */
    public deleteSelected(): void{
        this.showAlert.showCustomWarningAlertConfirm("", this.CONTAINER_DELETE_CONFIRMATION , (isConfirm: boolean)=>{
            this.deleteOnConfirmation(isConfirm);
        });
    }

    /*
   * @Method :: Show on before confirmation alert
   * */
    private deleteOnConfirmation(isConfirm): void{
        if(isConfirm){
            let rows: any = this.containerService.getSelectedRows();
            let isDirty: boolean = false;
            for(let i = 0; i < rows.length; i ++){
                if(rows[0].children && rows[0].children.length !> 0 ){
                    isDirty = true;
                    break;
                }
            }
            if(rows && !isDirty){
                this.deleteContainer(rows);
            }else{
                /* Timeout Required to add delay between two sweet alert.
                 * Multiple sweet alert can't be shown at a single time.
                 * We need to wait until first become invisible.*/
                setTimeout(()=>{
                    if(!rows[0].isElementGroup){
                        this.showErrorAlert(this.CONTAINER_CONTAINER_ERROR);
                    }else{
                        this.showErrorAlert(this.CONTAINER_ELEMENT_ERROR);
                    }
                }, 200);
            }
        }
    }

    /*
   * @Method :: Delete container
   * */
    private deleteContainer(rows: any): void{
        let id: any = rows[0].id;
        this.containerDataService.deleteContainer(id).subscribe(()=>{
            this.containerService.processDataTree(id, true, "delete");
            this.containerService.updateRowData(this.rowData);
            this.showSuccessAlert({type: "deleteContainer"});
        },this.onError.bind(this));
    }

    /*
   * @Event :: ag-Grid on filter change event
   * */
    public onFilterChanged(): void {
        this.containerGridOptions.api.setQuickFilter(this.filterText);
    }

    /*
   * @Method :: Move selected
   * */
    private moveSelected(isTypeContainer: boolean): void{
        this.containerService.selectedRows = this.containerService.getSelectedRows();
        this.createComponentOnClick(MoveContainerComponent, {selectedRows: this.containerService.selectedRows, rowData: this.rowData, isContainer: isTypeContainer});
    }

    /*
   * @Method :: Select all selected rows children
   * */
    public selectAllChildren(): void{
        let rows: any = this.containerService.getSelectedRows();
        rows.forEach((row: any) => {
            if(row.group){
                row.open = true;
            }
        });
        this.containerService.updateRowData(this.rowData);

        rows.forEach((row: any) => {
            if(row.group){
                this.containerColumnDefinitionService.selectAllChild(row.id, true);
            }else{
                this.containerService.gridOptions.api.forEachNode((rowNode: any) => {
                    if(rowNode.data.id === row.id){
                        rowNode.setSelected(true);
                    }
                });
            }
        });
    }

    /*
   * @Method :: Add element
   * */
    public addElement(): void{
        let rows: any = this.containerService.getSelectedRows();
        if(rows.length === 1){
            this.createComponentOnClick(AddElementViewComponent, {containerId: rows[0].id, path: this.containerService.getPath(rows[0].id)});
        }
    }

    //@method :: creates component on click.
    private createComponentOnClick(targetComponent:any, data?: any):void {
        this.clearComponent();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        this._containerViewEvents.createComponent(factory).instance.childData = data
    }

    //@method :: Clear component from memory
    private clearComponent(): void{
        this._containerViewEvents.clear();
    }

    /*
   * @Method :: Filter change
   * */
    public filterChanged(): void{
        if(this.filterText.length === 0){
            this.containerService.updateRowData(this.rowData);
        }else{
            this.containerGridOptions.api.expandAll();
        }
    }

    /*
   * @Method :: Close slider subject listener
   * */
    private closeSliderSubjectListener(): void{
        this.containerSharedService.getCloseSliderSubject().subscribe((data: any)=>{
            let isValid: boolean;
            switch (data.type){
                case "addElement":
                    this.containerService.addNodes(data.nodes);
                    isValid = data.nodes ? true : false;
                    break;
                case "moveContainer":
                    this.containerService.retriveParent(data.selectedId);
                    isValid = data.selectedId ? true : false;
                    break;
                case "addContainer":
                    this.containerService.addContainer(data.containerData, data.isEdit);
                    isValid = data.containerData ? true : false;
                    break;
            }
            this.clearComponent();
            if(isValid){
                this.showSuccessAlert(data);
            }
        });
    }

    /*
   * @Method :: Show sweet alert
   * */
    private showErrorAlert(message: string): void{
        this.showAlert.showSimpleAlert(ALERT_ERROR, message);
    }

    /*
   * @Method :: Show success sweet alert
   * */
    private showSuccessAlert(data: any): void{
        let message: string = "";
        switch (data.type){
            case "addElement":
                message = this.ADD_ELEMENT_SUCCESS;
                break;
            case "moveContainer":
                message = this.isContainer ? this.MOVE_CONTAINER_SUCCESS : this.MOVE_ELEMENT_SUCCESS;
                break;
            case "addContainer":
                message = data.isEdit ? this.ADD_CONTAINER_SUCCESS : this.EDIT_CONTAINER_SUCCESS;
                break;
            case "deleteContainer":
                message = this.DELETE_CONTAINER_SUCCESS;
                break;
        }
        this.filterChanged();
        this.showAlert.showSimpleAlert(ALERT_SUCCESS, message);
    }

    /* Method get called when we come in HCU tab after switch the tab */
    public onTabSwitch(): void{
        this.refresh();
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.CONTAINER_DELETE_CONFIRMATION = localizationService.instant('CONTAINER_DELETE_CONFIRMATION');
        this.CONTAINER_CONTAINER_ERROR = localizationService.instant('CONTAINER_CONTAINER_ERROR');
        this.CONTAINER_ELEMENT_ERROR = localizationService.instant('CONTAINER_ELEMENT_ERROR');

        this.ADD_ELEMENT_SUCCESS = localizationService.instant('ADD_ELEMENT_SUCCESS');
        this.MOVE_CONTAINER_SUCCESS = localizationService.instant('MOVE_CONTAINER_SUCCESS');
        this.MOVE_ELEMENT_SUCCESS = localizationService.instant('MOVE_ELEMENT_SUCCESS');
        this.ADD_CONTAINER_SUCCESS = localizationService.instant('ADD_CONTAINER_SUCCESS');
        this.EDIT_CONTAINER_SUCCESS = localizationService.instant('EDIT_CONTAINER_SUCCESS');
        this.DELETE_CONTAINER_SUCCESS = localizationService.instant('DELETE_CONTAINER_SUCCESS');

        this.CMTS_TAB_COL_EDIT = localizationService.instant('CMTS_TAB_COL_EDIT');
        this.MOVE = localizationService.instant('MOVE');
        this.ADD_CONTAINER = localizationService.instant('ADD_CONTAINER');
        this.ADD_ELEMENTS = localizationService.instant('ADD_ELEMENTS');
        this.HCU_DELETE_BTN_TEXT = localizationService.instant('HCU_DELETE_BTN_TEXT');
        this.CONTAINER_MAX_LIMIT = localizationService.instant('CONTAINER_MAX_LIMIT');
        this.CONTAINER_SELECT_ALL_CHILDREN = localizationService.instant('CONTAINER_SELECT_ALL_CHILDREN');
        this.CONTAINER_SELECT_ALL_CHILDREN = localizationService.instant('CONTAINER_SELECT_ALL_CHILDREN');
        this.DESELECT_ALL = localizationService.instant('DESELECT_ALL');

        this.EXPAND_ALL = localizationService.instant('EXPAND_ALL');
        this.COLLAPSE_ALL = localizationService.instant('COLLAPSE_ALL');
    }

    /*
     *@name onResize
     *@desc perform action on resize of ag-grid.
     *@return void
     */
    public onResize():void {
        let width: number = window.innerWidth;
        if(width <= 750){
            if(this.containerGridOptions.columnApi){
                let allColumnIds = [];
                this.containerGridOptions.columnApi.getAllColumns().forEach((column) => {
                    allColumnIds.push(column.colId);
                });
                this.containerGridOptions.columnApi.autoSizeColumns(allColumnIds);
                this.containerGridOptions.columnApi.autoSizeColumns();
            }
        }else{
            this.containerGridOptions.api.sizeColumnsToFit();
        }
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }
}