import {Injectable} from "@angular/core";

import {ContainerService} from "./container.service";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {SharedService} from "../../../shared/shared.service";
import { TranslateService } from '@ngx-translate/core';
@Injectable()
export class ContainerColumnDefinitionService{

    private idPrefix: string = "container_";

    public activeIds: any[] = [];

    private _HEADER_FIELDS: any = {
        containerName : {field: "name", name: "Containers"},
        selectAllChildren : {field: "countOfContainers", name: ""},
        childrenCount : {field: "Children Count", name: "# Children"}
    };

    constructor(private localeDataService: LocaleDataService,
                private sharedService : SharedService,
                private containerService: ContainerService,
                private translate:TranslateService){
                    // this.localeDataService.componentCallback.subscribe((response) => {
        this.translateLocaleStr();
    // });
    }

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();

        //Moved Locale definitions from container-locale-<lang>.json to locale-<lang>.json
        //This allows headers to be found in mulitple modules as this grid is being used in more than one module.
        this._HEADER_FIELDS.containerName.name = localizationService.instant('CONTAINER_NAME');
        this._HEADER_FIELDS.selectAllChildren.name = localizationService.instant('CONTAINER_SELECT_ALL_CHILDREN');
        this._HEADER_FIELDS.childrenCount.name = localizationService.instant('CONTAINER_CHILDREN_COUNT');
    }

    public getColumnDefinition(): any[]{
        let width: number = window.innerWidth;
        let factor: number;

        if(width <= 1100){
            factor = 2;
        }else{
            factor = 5;
        }

        //Removed "/factor" as it was making the #children column width too small
        // let childrenCountWidth: number = parseInt((this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.childrenCount.name, 0)/factor).toString());
		let childrenCountWidth: number = parseInt((this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.childrenCount.name, 0)).toString());

        let colDef: any [] = [
            {headerName: this._HEADER_FIELDS.containerName.name, field: this._HEADER_FIELDS.containerName.field,menuTabs: [],
                filter: 'text',
                cellRenderer: 'group',
                minWidth: 610,
                tooltipField: this._HEADER_FIELDS.containerName.field,
                cellClass: (param) =>{
                    let className: string = "";
                    if(param.data.group){
                        className = this.idPrefix + param.data.id;
                        this.addIds(className);
                    }
                    return className
                },
                floatingFilterComponentParams:{ suppressFilterButton:true },
                cellRendererParams: {
                    checkbox: true,
                    innerRenderer: this.innerCellRenderer,
                    suppressCount: true
                }
            },
            {headerName: this._HEADER_FIELDS.childrenCount.name,
                minWidth: 100,
				pinned: this.sharedService.isPinned(),
                width: childrenCountWidth,
                field: "",
                menuTabs: [],
                filter: 'text',
                floatingFilterComponentParams:{ suppressFilterButton:true },
                cellRenderer: (param)=>{
                    let child: string = "";
                    let data: any = param.data;
                    if(data.group){
                        child = data.children.length.toString();
                    }
                    return child;
                }},
        ];
        return colDef;
    }

    innerCellRenderer(params) {
        let name: string = params.data.name;
        let icon: string;
        if(params.data.group){
            icon = ` <label><i class="fas fa-cube containerIcon"></i> `;
        }else{
            icon = ` <label><i class="fas fa-crosshairs containerIcon"></i> `;
        }
        icon = icon + name + `</label>`;
        return icon;
    }

    private addIds(elementId: string): void{
        let isNewId = true;
        for(let i = 0; i < this.activeIds.length; i ++){
            let idObj: any = this.activeIds[i];
            if(elementId === idObj.id){
                idObj.isDirty = false;
                isNewId = false;
            }
        }
        if(isNewId){
            this.activeIds.push({id: elementId, isDirty: false});
        }
    }

    public selectAllChild(id: string, isSelected: boolean): void{
        this.containerService.gridOptions.api.forEachNode((rowNode: any) => {
            if(rowNode.data.id === id){
                rowNode.setSelected(false);
            }
            if(rowNode.data.parentId === id){
                rowNode.setSelected(isSelected);
            }
        });
    }
}