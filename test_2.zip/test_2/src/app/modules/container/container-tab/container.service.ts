import {Injectable} from "@angular/core";

import {ContainerModel} from "./model/container.model";

@Injectable()
export class ContainerService{

    public currentChildCount: number = 0;
    public containerData: any[] = [];
    public selectedRows: any[];
    public gridOptions: any;

    private rowData: any[];
    private isDirty: boolean = false;

    public containerPath: string = "";
    public parentId: any = 0;
    public isSearchContinued: boolean = true;
    private count: number = 1;
    private existingCount: number;
    private isOverflowed: boolean;
    private isTreeDoneProcessing: boolean;

    public setRowData(rowData: any): void{
        this.rowData = rowData;
    }

    public setGridOptions(gridOptions: any): void{
        this.gridOptions = gridOptions;
    }

    public updateRowData(rowData: any): void{
        this.rowData = rowData;
        this.gridOptions.api.setRowData(rowData);
    }

    public toggleIcon(selector: any, isSelected: boolean): void{
        try{
            let className : string = isSelected ? "fa fa-check-square-o" : "fa fa-square-o";
            selector.className = className;
        }catch (e){}
    }



    public toggleTreeState(isOpen: boolean, id: any): void{
        this.isTreeDoneProcessing = false;
        for(let i = 0; i < this.rowData.length; i ++){
            if(this.isTreeDoneProcessing){
                break;
            }
            let rowData: any = this.rowData[i];
            if(rowData.id == id){
                rowData.open = isOpen;
                if(rowData.group){
                    this.processChildForTreeState(isOpen, rowData.children);
                }else{
                    this.isTreeDoneProcessing = true;
                }
                break;
            }else if(rowData.group){
                this.serachInChild(isOpen, id, rowData.children);
            }
        }
        this.updateRowData(this.rowData);
    }

    private serachInChild(isOpen: boolean, id: any, child: any[]): void{
        for(let i = 0; i < child.length; i ++){
            if(this.isTreeDoneProcessing){
                break;
            }
            let rowData: any = child[i];
            if(rowData.id == id){
                rowData.open = isOpen;
                if(rowData.group){
                    this.processChildForTreeState(isOpen, rowData.children);
                }else{
                    this.isTreeDoneProcessing = true;
                }
                break;
            }else if(rowData.group){
                this.serachInChild(isOpen, id, rowData.children);
            }
        }
    }

    private processChildForTreeState(isOpen: boolean,child: any[]): void{
        child.forEach((data: any)=>{
            data.open = isOpen;
            if(data.group){
                this.processChildForTreeState(isOpen, data.children);
            }
        });
    }

    public processDataTree(id: string, openStatus: boolean, operation: string): void {
        this.isDirty = false;
        for(let i = 0; i < this.rowData.length; i ++){
            if(!this.isDirty){
                let group = this.rowData[i];
                if(group.id == id){
                    group.open = openStatus;
                    if(operation === "add"){
                        this.selectedRows.forEach((row)=>{
                            row.parentId = id;
                            group.children.push(row);
                        });
                        if(group.children[0] && !group.children[0].group){
                            group.containerChildType = group.group = "Element";
                            group.isElementGroup = true;
                        }
                    }else if(operation === "search"){
                        this.buildPath(group.name);
                        this.parentId = group.parentId;
                        this.isSearchContinued = false;
                    }
                    break;
                }else{
                    this.processChild(group, id, openStatus, operation);
                }
            }else{
                break;
            }// End of else
        }
    }

    private buildPath(name: string): void{
        this.containerPath = name + " > " + this.containerPath;
    }

    private processChild(group, id: string, openStatus: boolean, operation: string): void {
        if(!this.isDirty){
            let processChild: boolean;
            let children = group.children;
            let child: any;
            for(let i = 0; i < children.length; i ++){
                child = children[i];
                processChild = false;
                if(this.isDirty){
                    break;
                }

                if(operation === "search"){
                    if(child.group){
                        if(child.id == id ){
                            this.isDirty = true;
                            processChild = false;
                            this.buildPath(child.name);
                            this.parentId = child.parentId;
                            break;
                        }else{
                            processChild = true;
                        }
                    }
                }else if(operation === "delete" || operation === "move"){
                    if(child.id == id){
                        children.splice(i, 1);
                        this.isDirty = true;
                        processChild = false;
                        if(!group.children.length){
                            group.containerChildType = "default";
                            group.isElementGroup = false;
                            group.group = "default";
                        }
                        break;
                    }else if(child.group){
                        processChild = true;
                    }// End of else
                }else if(operation === "other"){
                    if(child.group){
                        if(child.id == id ){
                            child.open = openStatus;
                            this.isDirty = true;
                            processChild = false;
                            break;
                        }else{
                            processChild = true;
                        }
                    }// End of If
                }else if(operation === "add"){
                    if(child.group){
                        if(child.id == id ){
                            this.isDirty = true;
                            this.selectedRows.forEach((row)=>{
                                row.parentId = child.id;
                                child.children.push(row);
                            });
                            if(child.children[0] && !child.children[0].group){
                                child.containerChildType = child.group = "Element";
                                child.isElementGroup = true;
                            }
                            processChild = false;
                            break;
                        }else{
                            processChild = true;
                        }
                    }// End of If
                }else if(operation === "removeDuplicate"){
                    if(child.group){
                        processChild = true;
                    }else{
                        if(child.id == id){
                            this.isDirty = true;
                            this.processDataTree(child.id, true, "delete");
                            break;
                        }
                    }
                }

                if(processChild){
                    this.processChild(child, id, openStatus, operation);
                }// End of If

            }// End of For
        }// End of If
    }// End of method

    public randomId(len) {
        len = len || 100;
        let nuc = ["A", "T", "C", "G"];
        let i = 0;
        let n = 0;
        let s = '';
        while (i <= len - 1) {
            n = Math.floor(Math.random() * 4)
            s += nuc[n]
            i++
        }
        return s
    }

    public getNewId(row: any): string{
        let id: string;
        if(row.id){
            id = row.id;
        }else{
            row.id = "element_" + this.randomId(7);
            id = row.id;
        }
        return id;
    }

    public getSelectedRows(): any[]{
        if(this.gridOptions){
            return this.gridOptions.api.getSelectedRows();
        }
        return [];
    }

    public getPath(id: any): string{
        let path: string;
        this.containerPath = "";
        this.parentId = id;
        this.isSearchContinued = true;
        while(this.isSearchContinued){
            this.processDataTree(this.parentId, true, "search");
        }
        path = this.containerPath.substring(0, this.containerPath.length - 3);
        return path;
    }

    public addNodes(nodes: any): void{
        if(nodes && nodes.length >= 1){
            let rows: any = this.getSelectedRows();
            nodes.forEach((node: any)=>{
                rows[0].children.push(node);
            });
            rows[0].containerChildType = "Element";
            rows[0].isElementGroup = true;
            this.updateRowData(this.rowData);
        }
    }

    public retriveParent(selectedId: any): void{
        if(selectedId){
            this.selectedRows.forEach((row)=>{
                let id: string = this.getNewId(row);
                this.processDataTree(id, true, "move");
            });
            this.processDataTree(selectedId, true, "add");
            this.updateRowData(this.rowData);
        }
    }

    public addContainer(containerModel: ContainerModel, isEdit: boolean): void{
        if(containerModel){
            let rows: any = this.getSelectedRows();
            if(isEdit){
                rows[0].children.push(containerModel);
            }else{
                rows[0].name = containerModel.name;
                rows[0].address = containerModel.address;
                rows[0].version = containerModel.version;
                rows[0].containerMetaType = containerModel.containerMetaType;
            }
            rows[0].containerChildType = containerModel.containerChildType;
            rows[0].isElementGroup = containerModel.isElementGroup;
            this.updateRowData(this.rowData);
        }
    }

    public addListener(className: string): void{
        let collapse = document.querySelector("." + className + " span span.ag-group-expanded span");
           if(collapse){
               collapse.addEventListener("click", ()=>{
                   this.processDataTree(className.split("_")[1], false, "other");
               });
           }
        let expand = document.querySelector("." + className + " span span.ag-group-contracted span");
        if(expand){
            expand.addEventListener("click", ()=>{
                this.processDataTree(className.split("_")[1], true, "other");
            });
        }
    }

    public processContainerData(data: any): any{
        let server: ContainerModel = new ContainerModel();
        this.setFields(server, data);
        let children: any =  this.getChildren(server, data);
        this.processChildren(server, children);
        this.containerData.push(server);
        return this.containerData;
    }

    private processChildren(containerModel: ContainerModel, childrenData: any): void{
        if(childrenData){
            let childModel: ContainerModel;
            let children: any;
            childrenData.forEach((child: any)=>{
                childModel = new ContainerModel();
                this.setFields(childModel, child);
                children = this.getChildren(childModel, child);
                if(!childModel.parentId){
                    childModel.parentId = containerModel.id;
                }
                containerModel.children.push(childModel);
                this.processChildren(childModel, children);
            });
        }
    }

    private getChildren(containerModel: ContainerModel, child): any[]{
        return containerModel.isElementGroup ? child.childrenElements : child.childrenContainers
    }

    public setFields(containerModel: ContainerModel, data: any): void{
        containerModel.id = data.id;
        containerModel.name = data.name;
        containerModel.address = data.address;
        containerModel.containerChildType = data.containerChildType;
        containerModel.containerMetaType = data.containerMetaType;
        containerModel.parentId = data.parentId;
        containerModel.version = data.version;
        containerModel.isElementGroup = data.containerChildType === "Element" ? true : false;
        containerModel.group =  data["containerChildType"];
        containerModel.elementType = data["elementType"];
        containerModel.containerPath = data["containerPath"];
        containerModel.open = !data.childrenElements && !data.childrenContainers;
    }

    public getMaxCount(existingCount: number): boolean{
        let rows: any = this.getSelectedRows();
        this.existingCount = existingCount;
        this.isOverflowed = false;

        for(let i = 0; i < rows.length; i ++){
            this.count = 1;
            if(this.isOverflowed){
                break;
            }
            if(!rows[i].isElementGroup){
                this.processForMaxCountChildren(rows[i].children);
            }
        }
        return this.isOverflowed;
    }
    private processForMaxCountChildren(child: any[]): void{
        for(let i = 0; i < child.length; i ++){

            if(this.isOverflowed){
                break;
            }

            if(child[i].group){
                this.count ++;
                if(!child[i].isElementGroup && child[i].children.length > 0){
                    this.processForMaxCountChildren(child[i].children);
                }else{
                    if((this.existingCount + this.count) > 10){
                        this.isOverflowed = true;
                        break;
                    }
                    this.count = 1;
                }
            }
        }
    }

}
