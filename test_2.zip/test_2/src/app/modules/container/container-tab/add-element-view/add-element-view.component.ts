import {Component, EventEmitter, Input, Output} from '@angular/core';

import {ShowAlert} from "../../../../utilities/showAlert";
import {ContainerDataService} from "../../container.data.service";
import {ContainerService} from "../container.service";
import {ContainerModel} from "../model/container.model";
import {ContainerSharedService} from "../../container-shared.service";
import {ALERT_ERROR} from "../../../../constant/app.constants";
import {LocaleDataService} from "../../../../shared/locale.data.service";

@Component({
    selector: "add-element-view",
    templateUrl: "add-element-view.component.html"
})
export class AddElementViewComponent{
    public addElementViewCloseSlider: boolean = false;
    public hardwareData: any[];
    public activeNodeData: any[];
    private containerId: any;
    private nodesToBeMoved: ContainerModel[] = null;
    public containerPath: string = "";
    public isNoNodeAvailable: boolean = false;
    private SELECT_AT_LEAST_ONE_NODE: string = "";
    public isAscending: boolean = false;
    public search: string = "";
    public hideChild: boolean;

    @Input('childData') childData: any;

    constructor(private localeDataService: LocaleDataService,
                private containerSharedService: ContainerSharedService,
                private containerDataService: ContainerDataService, private containerService: ContainerService,
                private showAlert: ShowAlert){}

    ngOnInit(){
        this.translateLocaleString();
        this.setData();
        this.getHardwareData();
    }

    private setData(): void{
        if(this.childData){
            this.containerId = this.childData.containerId;
            this.containerPath = this.childData.path;
        }
    }

    private getHardwareData(): void{
        this.containerDataService.getHardwareList().subscribe((hardwareData: any[])=>{
            this.hardwareData = hardwareData;
            this.hardwareData[0]["isActive"] = true;
            this.hardwarCheckBoxChange(null, this.hardwareData[0], "click");
        },this.onError.bind(this));
    }

    public closeSlider(action: string): void{
        if(action === "add"){
            this.nodesToBeMoved = [];
            this.hardwareData.forEach((hardware: any)=>{
                if(hardware["nodes"]){
                    hardware["nodes"].forEach((node: any)=>{
                        if(node['isSelected']){
                            node['parentId'] = this.containerId;
                            let containerModel: ContainerModel = new ContainerModel();
                            this.containerService.setFields(containerModel, node);
                            this.nodesToBeMoved.push(containerModel);
                        }
                    });
                }
            });

            if(this.nodesToBeMoved.length === 0){
                this.showInfoAlert(ALERT_ERROR, this.SELECT_AT_LEAST_ONE_NODE);
                this.nodesToBeMoved = null;
            }else{
                this.moveElement();
            }

        }else{
            this.nodesToBeMoved = null;
            this.notifyGrid();
        }
    }

    private moveElement(): void{
        this.containerDataService.moveElements(this.containerId, this.nodesToBeMoved).subscribe(()=>{
            this.notifyGrid();
        },this.onError.bind(this));
    }

    public searchChange(): void{
        this.hideChild = false;
        this.hardwareData.map((data: any) => {
            data.name.toLowerCase().concat(" (", data.networkDeviceType, ")")
                .indexOf(this.search.toLowerCase()) > -1 ? (data["isFilter"] = true) : (data["isFilter"] = false);
            if(!this.hideChild){
                this.hideChild = data["isActive"] && !data["isFilter"];
            }
        });
    }

    public sortList(): void{
        this.isAscending = !this.isAscending;
        this.hardwareData.sort((a: any, b: any) => {
            let nameA: string = a.name.toLowerCase(), nameB: string = b.name.toLowerCase()
            if (nameA < nameB) //sort string ascending
                return -1
            if (nameA > nameB)
                return 1
            return 0 //default return value (no sorting)
        });
        if(!this.isAscending){
            this.hardwareData.reverse();
        }
    }

    private notifyGrid(): void{
        if(this.nodesToBeMoved){
            this.nodesToBeMoved.forEach((node: any)=>{
                this.containerService.processDataTree(node.id, true, "removeDuplicate");
            });
        }
        this.containerSharedService.getCloseSliderSubject().next({type: "addElement", nodes: this.nodesToBeMoved});
    }

    private hardwarCheckBoxChange(event: Event, hardware: any, type: string): void{
            this.activeNodeData = null;
            if(event){
                event.stopPropagation();
            }
           if(!hardware["nodes"]){
               this.getHardwareNodes(type, hardware);
           }else{
               if(!hardware["nodes"][0]){
                   this.isNoNodeAvailable = true;
               }else{
                   this.isNoNodeAvailable = false;
                   this.fillActiveNodeData(hardware["nodes"]);
                   this.toggleSelection(type, hardware);
               }
           }
            this.removeAllHardwareSelection();
            hardware["isActive"] = true;
            this.searchChange();
    }

    private nodeCheckBoxChange(node: any): void{
        let hardwareId: number = node.harewareId;
        let hardware: any;
        for(let i = 0; i < this.hardwareData.length; i ++){
            if(this.hardwareData[i].id === hardwareId){
                hardware = this.hardwareData[i];
                break;
            }
        }
        this.removeAllNodeSelection(hardware.nodes);
        node["isActive"] = true;

        if(!node['isSelected']){
            hardware["isSelected"] = false;
        }else{
            let isAllSelected: boolean = true;
            for(let i = 0; i < hardware.nodes.length; i ++){
                if(!hardware.nodes[i]["isSelected"]){
                    isAllSelected = false;
                }
            }
            if(isAllSelected){
                hardware["isSelected"] = true;
            }
        }
    }

    private removeAllNodeSelection(nodeList: any[]): void{
        nodeList.forEach((node: any)=>{
            node["isActive"] = false;
        });
    }

    private removeAllHardwareSelection(): void{
        this.hardwareData.forEach((hardware: any)=>{
            hardware["isActive"] = false;
        });
    }

    //Method to stop event bubbling
    private dummyMethod(event: Event): void{
        event.stopPropagation();
    }

    private toggleSelection(type: string, hardware: any): void{
        if(type){
            hardware["nodes"].forEach((node: any)=>{
                node['isSelected'] = hardware['isSelected'];
            });
        }
    }

    private getHardwareNodes(type: string, hardware: any): void{
        if(hardware.networkDeviceType === "hcu"){
            this.getHardwareNodesHcu(type, hardware);
        }else if(hardware.networkDeviceType === "cmts"){
            this.getHardwareNodesCmts(type, hardware);
        }
    }

    private getHardwareNodesHcu(type: string, hardware: any): void{
        this.containerDataService.getHardwareNodesHcu(hardware.id).subscribe((nodeList: any[])=>{
            this.loadNodes(hardware, type, nodeList);
        },this.onError.bind(this));
    }

    private getHardwareNodesCmts(type: string, hardware: any): void{
        this.containerDataService.getHardwareNodesCmts(hardware.id).subscribe((nodeList: any[])=>{
            this.loadNodes(hardware, type, nodeList);
        },this.onError.bind(this));
    }

    private loadNodes(hardware: any, type: string, nodeList: any): void{
        this.fillHadrwareNodeList(hardware, nodeList);
        this.toggleSelection(type, hardware);
    }

    private fillHadrwareNodeList(hardware: any, nodeList: any[]): void{
        hardware["nodes"] = nodeList;
        hardware["nodes"].forEach((node: any)=>{
            node["harewareId"] = hardware.id;
        });

        if(!nodeList[0]){
            this.isNoNodeAvailable = true;
        }else{
            this.isNoNodeAvailable = false;
            nodeList[0]["isActive"] = true;
        }
        this.fillActiveNodeData(nodeList);
    }

    private fillActiveNodeData(nodeList: any[]): void{
        this.activeNodeData = nodeList;
    }

    private showInfoAlert(type: string, message: string): void{
        this.showAlert.showSimpleAlert(type, message);
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.SELECT_AT_LEAST_ONE_NODE = localizationService.instant('SELECT_AT_LEAST_ONE_NODE');
    }


    //Handle error
    private onError(error): void{
        this.nodesToBeMoved = null;
        this.showAlert.showErrorAlert(error);
    }
}