import {Injectable} from '@angular/core';

import {Subject} from "rxjs";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {DisabledFilter} from "../../shared/grid/disabled.filter";
import {EDIT_ICON} from "../../../constant/app.constants";
import {SharedService} from "../../../shared/shared.service";
import {ContainerSharedService} from "../container-shared.service";
import {gridCustomComparator} from "../../../shared/ag-Grid.comparator";

import { TranslateService } from "@ngx-translate/core";
@Injectable()
export class ContainerMetaTypeTabColumnDefinitionService {
    private containerEditSubject: Subject<any>;

    private _HEADER_FIELDS: any = {
        containerName : {field: "name", name: "CONTAINER_META_NAME"},
        numberOfContainers : {field: "countOfContainers", name: "CONTAINER_META_NUMBER_OF_CONTAINER"},
        edit : {field: "edit", name: "CONTAINER_META_EDIT"}
    };

    constructor(private localeDataService: LocaleDataService,
                private sharedService : SharedService,
                public translate : TranslateService,
                private containerSharedService: ContainerSharedService){
        this.containerEditSubject = null;
        this.localeDataService.componentCallback.subscribe((response) => {
        this.translateLocaleStr();
    });
    }

    /*
    *@name translateLocaleStr
    *@desc Get Localize strings
    *@return void
    */
    private translateLocaleStr(): void{
        let localizationService = this.localeDataService.getLocalizationService();

        this._HEADER_FIELDS.containerName.name = localizationService.instant('CONTAINER_META_NAME');
        this._HEADER_FIELDS.numberOfContainers.name = localizationService.instant('CONTAINER_META_NUMBER_OF_CONTAINER');
        this._HEADER_FIELDS.edit.name = localizationService.instant('CONTAINER_META_EDIT');
    }

    /*
     *@name getColumnDef
     *@desc Get column def for alarm-list data-grid
     *@return array[any]
    */
    public getColumnDef(): any[] {
        this.translateLocaleStr();
        let columnDef: any[] = [
            {
                headerName: '',
                width: 21,
                maxWidth:25,
                checkboxSelection: true,
                pinned: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: {newRowsAction: 'keep'},
                suppressResize: true
            },
            this.getColumns(this._HEADER_FIELDS.containerName.name, this._HEADER_FIELDS.containerName.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.containerName.name, 70), "text"),
            this.getColumns(this._HEADER_FIELDS.numberOfContainers.name, this._HEADER_FIELDS.numberOfContainers.field, this.sharedService.getHeaderTemplate(this._HEADER_FIELDS.numberOfContainers.name, 200), "number"),
            {
                headerName: this._HEADER_FIELDS.edit.name,headerTooltip: this._HEADER_FIELDS.edit.name, field: this._HEADER_FIELDS.edit.field,
                minWidth: 150, maxWidth: 150,
                pinned: this.sharedService.isPinned(),
                sortingOrder: [null],
                suppressSorting : true,
                cellStyle : () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                comparator: gridCustomComparator,
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,floatingFilterComponentParams:{ suppressFilterButton:true },
                filterParams: {newRowsAction: 'keep'},
                suppressMenu: true,
                cellRenderer: ((param:any)=>{
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (()=>{
                    this.action(param);
                }));
                gui.className = "ag-Grid-cursor";
                return gui;
                })
            }
        ]
        return columnDef;
    }

    //@method :: get column definition
    private getColumns(headerName: string, field: string, minWidth: number, filter: string, sort?:string): any{
        return {
            headerName: headerName,
            headerTooltip: headerName.replace("&trade;",""),
            field: field,
            minWidth: minWidth,
            filter: filter,
            filterParams: {newRowsAction: 'keep'},
            comparator: gridCustomComparator,
            floatingFilterComponentParams:{ suppressFilterButton:true },
            sort:sort
        }
    }

    //@method :: callback action for clear icon click
    private action(param: any): void{
        this.containerSharedService.getContainerEditSubject().next(param.data);
    }
}