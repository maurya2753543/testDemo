import {Component, Input} from "@angular/core";

import {ContainerSharedService} from "../../container-shared.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import {ContainerDataService} from "../../container.data.service";

@Component({
    templateUrl: "add-update-meta-type.component.html"
})
export class AddUpdateMetaTypeComponent{
    public isOpen: boolean = false
    public isEdit: boolean;
    private isNameErrorDirty: boolean = false;

    private containerMetaObj: any = {
        "id": 0,
        "name": "",
        "countOfContainers": 0
    };
    private isEditOperation: boolean = false;

    @Input('childData') childData: any;

    constructor(private showAlert: ShowAlert,
                private containerSharedService: ContainerSharedService,
                private containerDataService: ContainerDataService){}

    ngOnInit(){
        this.setData();
    }

    private setData(): void{
        if(this.childData.metaTypeObj){
            this.containerMetaObj = this.childData.metaTypeObj;
            this.isEditOperation = true;
        }else{
            this.isEdit = true;
        }
    }

    public saveData(): void{
        if(this.childData.metaTypeObj){
            this.updateMetaType();
        }else{
            this.createMetaType();
        }
    }

    private createMetaType(): void{
        this.containerDataService.createMetaType(this.containerMetaObj).subscribe({next:this.closeSlider.bind(this),error:this.onError.bind(this)});
    }

    private updateMetaType(): void{
        this.containerDataService.updateMetaType(this.containerMetaObj).subscribe({next:this.closeSlider.bind(this),error:this.onError.bind(this)});
    }

    private enableEdit(): void{
        this.isEdit = true;
    }

    private nameValidation(): void{
        if(this.containerMetaObj.name.length === 0){
            this.isNameErrorDirty = true;
        }else{
            this.isNameErrorDirty = false;
        }
    }

    public closeSlider(data: any): void{
        this.containerSharedService.getCloseSliderSubject().next({isMetaType: true, type: data, isEdit: this.isEditOperation});
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }
}