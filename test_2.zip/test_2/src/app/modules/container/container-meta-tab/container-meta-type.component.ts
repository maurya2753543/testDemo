import {Component, ComponentFactoryResolver, ViewChild, ViewContainerRef} from "@angular/core";

import {Grid} from "../../../shared/ag-grid.options";
import {LocaleDataService} from "../../../shared/locale.data.service";
import {ContainerMetaTypeTabColumnDefinitionService} from "./container-meta-type-tab.column-definition.service";
import {ShowAlert} from "../../../utilities/showAlert";
import {ContainerDataService} from "../container.data.service";
import {AddUpdateMetaTypeComponent} from "./add-update-meta-type-view/add-update-meta-type.component";
import {ContainerSharedService} from "../container-shared.service";
import {
    ALERT_SUCCESS, GRID_COM_KEY_NO_SELECTION, GRID_COMP_KEY_ALL, GRID_COMP_KEY_ONLY_SINGLE,
    GRID_COMP_KEY_SINGLE
} from "../../../constant/app.constants";

import { TranslateService } from "@ngx-translate/core";

@Component({
    templateUrl: "container-meta-type.component.html",
    selector: "container-meta-type"
})
export class ContainerMetaTypeComponent{

    public containerMetaTypeGridOptions: Grid = new Grid();
    private _containerMetaTypeTab: string = "CONTAINER_META_TYPE_TAB";
    public eventKeys: Object[];
    public refreshBtnFlag:boolean;

    private EXPORT_ALL_TEXT: string = "";
    private EXPORT_SELECTED_TEXT: string = "";
    private ADD_META_TYPE: string = "";
    private EDIT: string = "";
    private DELETE: string = "";

    public buttonKeys: Object[];
    private totalCount:number = 0;
    public rowdata: any[];
    private id: number;

    private TABLE_LIST_SHOWING: string = "";
    private TABLE_LIST_SHOWING_OF: string = "";
    private TABLE_LIST_ROWS: string = "";
    private META_TYPE_DELETE_SUCCESS: string = "";
    private META_TYPE_ADD_SUCCESS: string = "";
    private META_TYPE_EDIT_SUCCESS: string = "";

    public showAllLabel:string = '';
    public showAllLabelMob:string = '';
    private META_TAG_DELETE_CONFIRMATION: string = "";
    public gridTabType: string = "";

    @ViewChild('containerMetaType', { read: ViewContainerRef }) _containerMetaType;

    constructor(private localeDataService: LocaleDataService,
        public translate : TranslateService,
                private componentFactoryResolver: ComponentFactoryResolver,
                private containerMetaTypeTabColumnDefinitionService: ContainerMetaTypeTabColumnDefinitionService,
                private showAlert: ShowAlert,
                private containerDataService: ContainerDataService,
                private containerSharedService: ContainerSharedService){}

    ngOnInit(){
        this.translateLocaleString();
        this.closeSliderSubjectListener();
        this.containerEditSubjectListener();
    }

    //@method :: set button keys
    private setEventButtonKeys():void {
        this.eventKeys = [
            {name: this.EDIT,status: GRID_COMP_KEY_ONLY_SINGLE, tabType: this._containerMetaTypeTab},
            {name: this.DELETE,status: GRID_COMP_KEY_ONLY_SINGLE, tabType: this._containerMetaTypeTab},
            {name: this.EXPORT_SELECTED_TEXT,status: GRID_COMP_KEY_SINGLE, tabType: this._containerMetaTypeTab},
            {name: this.EXPORT_ALL_TEXT,status: GRID_COMP_KEY_ALL, tabType: this._containerMetaTypeTab}
        ];
        this.refreshBtnFlag = true;
        this.buttonKeys = [
            { name: this.ADD_META_TYPE, tabType: this._containerMetaTypeTab, disable:false}
        ];
    }

    public notifyActionEmitter($event){
        switch ($event.event.name) {
            case this.ADD_META_TYPE:
                this.openSlider(null);
                break;
            case this.EDIT:
                this.edit();
                break;
            case this.DELETE:
                this.delete();
                break;
            default:
        }
    }
    public notifyFilterChangeCONTAINERMETA(event): any{
        this.containerDataService.containermetafilterchangedata = this.containerMetaTypeGridOptions.api.getFilterModel();
        console.log("filterchange data",this.containerDataService.containermetafilterchangedata);
    }
    private openSlider(data: any): void{
        this.createComponentOnClick(AddUpdateMetaTypeComponent, {metaTypeObj: data});
    }

    private edit(): void{
        this.openSlider(this.getSelectedRow());
    }

    private delete(): void{
        this.showAlert.showCustomWarningAlertConfirm("", this.META_TAG_DELETE_CONFIRMATION , (isConfirm: boolean)=>{
            if(isConfirm){
                let id: number = this.getSelectedRow().id;
                this.containerDataService.deleteMetaType(id).subscribe({next:this.deleteSuccess.bind(this), error: this.onError.bind(this)});
            }
        });
    }

    private deleteSuccess(): void{
        this.showSuccessAlert("deleteSuccess");
    }

    private getSelectedRow(): any{
        return this.containerMetaTypeGridOptions.api.getSelectedRows()[0];
    }

    private containerEditSubjectListener(): void{
        this.containerSharedService.getContainerEditSubject().subscribe((data: any)=>{
            this.openSlider(data);
        });
    }

    public modelUpdatedEmitter(e:any):void {
        let rowCount = this.containerMetaTypeGridOptions.api.getDisplayedRowCount();
        this.setShowAllLabel(rowCount, this.totalCount);
    }

    //method sets showalllabel.
    private setShowAllLabel(rowCount, totalCount):void {
        this.showAllLabel = this.TABLE_LIST_SHOWING +" "+ rowCount +" "+ this.TABLE_LIST_SHOWING_OF +" "+ totalCount +" "+ this.TABLE_LIST_ROWS;
        this.showAllLabelMob = rowCount + "/" + totalCount;
    }

    //@method :: notify grid is ready.
    public notifyGridReady(params:any): void{
        this.setGridColDefinition();
    }

    //@method :: sets column definition to grid.
    private setGridColDefinition(){
        this.containerMetaTypeGridOptions.api.setColumnDefs(this.containerMetaTypeTabColumnDefinitionService.getColumnDef());
        this.getMetaTypeList();
    }

    private getMetaTypeList(): void{
        this.showLoadingOverlay();
        this.containerDataService.getContainerMetaTypeList().subscribe({next:this.setRowData.bind(this), error : this.onError.bind(this)}); 
        if(this.containerMetaTypeGridOptions.api && this.containerDataService.containermetafilterchangedata){
            this.containerMetaTypeGridOptions.api.setFilterModel(this.containerDataService.containermetafilterchangedata);            
            console.log("filter executed",this.containerDataService.containermetafilterchangedata);
        }    
    }

    //@method :: Set ag-Grid row data
    private setRowData(data: any): void{
        this.rowdata = data;
        this.totalCount = data.length;
    }

    //@method :: shows overlay on grid.
    private showLoadingOverlay():void {
        this.containerMetaTypeGridOptions.api.showLoadingOverlay();
    }

    //refresh
    public notifyRefreshGrid(): void{
        this.getMetaTypeList();
    }

    //@method :: creates component on click.
    private createComponentOnClick(targetComponent:any, data?: any):void {
        this.clearComponent();
        const factory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
        this._containerMetaType.createComponent(factory).instance.childData = data
    }

    //@method :: Clear component from memory
    private clearComponent(): void{
        this._containerMetaType.clear();
    }

    //@method :: used for localization
    private translateLocaleString(): void {
        let localizationService = this.localeDataService.getLocalizationService();

        this.EXPORT_ALL_TEXT = localizationService.instant('GRID_SECTION.GRID_EXPORT_ALL');
        this.EXPORT_SELECTED_TEXT = localizationService.instant('GRID_SECTION.GRID_EXPORT_SELECTED');
        this.ADD_META_TYPE = localizationService.instant('CONTAINER_ADD_META_TYPE');

        this.EDIT = localizationService.instant('CONTAINER_META_EDIT');
        this.DELETE = localizationService.instant('HCU_DELETE_BTN_TEXT');

        this.TABLE_LIST_SHOWING = localizationService.instant('TABLE_LIST_SHOWING');
        this.TABLE_LIST_SHOWING_OF = localizationService.instant('TABLE_LIST_SHOWING_OF');
        this.TABLE_LIST_ROWS = localizationService.instant('TABLE_LIST_ROWS');
        this.META_TAG_DELETE_CONFIRMATION = localizationService.instant('META_TAG_DELETE_CONFIRMATION');
        this.META_TYPE_DELETE_SUCCESS = localizationService.instant('META_TYPE_DELETE_SUCCESS');

        this.META_TYPE_ADD_SUCCESS = localizationService.instant('META_TYPE_ADD_SUCCESS');
        this.META_TYPE_EDIT_SUCCESS = localizationService.instant('META_TYPE_EDIT_SUCCESS');
        this.gridTabType = localizationService.instant('META_TAG').split(" ").join("");

        this.setEventButtonKeys();
    }

    private closeSliderSubjectListener(): void{
        this.containerSharedService.getCloseSliderSubject().subscribe((data: any)=>{
            this.clearComponent();
            if(data.type && data.isMetaType){
                let action: string = data.isEdit ? "editSuccess" : "addSuccess";
                this.showSuccessAlert(action);
            }
            else{
                this.getMetaTypeList();
            }
        });
    }

    private showSuccessAlert(type: string): void{
        let message: string = "";
        switch (type){
            case "addSuccess":
                message = this.META_TYPE_ADD_SUCCESS;
                break;
            case "editSuccess":
                message = this.META_TYPE_EDIT_SUCCESS;
                break;
            case "deleteSuccess":
                message = this.META_TYPE_DELETE_SUCCESS;
                break;
        }
        this.showAlert.showSimpleAlert(ALERT_SUCCESS, message);
        this.getMetaTypeList();
    }

    /* Method get called when we come in HCU tab after switch the tab */
    public onTabSwitch(): void{
        this.getMetaTypeList();
    }

    //Handle error
    private onError(error): void{
        this.showAlert.showErrorAlert(error);
    }
}