import {Injectable} from "@angular/core";
import {Subject} from "rxjs";

@Injectable()
export class ContainerSharedService{

    private closeSliderSubject: Subject<any> = new Subject();
    private containerEditSubject: Subject<any> = new Subject();

    public getCloseSliderSubject(): Subject<any>{
        return this.closeSliderSubject;
    }

    public getContainerEditSubject(): Subject<any>{
        return this.containerEditSubject;
    }
}