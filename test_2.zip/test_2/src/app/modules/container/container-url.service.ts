import {Injectable} from "@angular/core";

import {SharedService} from "../../shared/shared.service";
import {PATHTRAK_CONTAINER_PATH} from "../../constant/app.constants";

@Injectable()
export class ContainerUrlService{

    private path: string = PATHTRAK_CONTAINER_PATH;
    private baseUrl: string;

    constructor(private sharedService: SharedService){
        this.setBaseUrl();
    }

    private setBaseUrl(): void{
        this.baseUrl = this.sharedService.getHost() + this.path;
    }

    public getContainerUrl(): string {
        return this.baseUrl;
    }

    public getContainerMetaTypeListUrl(): string{
        return this.baseUrl + "/meta";
    }

    public getSyncContainerDataUrl(id: any): string{
        return this.baseUrl + "/" + id;
    }

    public getHardwareListUrl(): string{
        return this.baseUrl + "/hardware";
    }

    public getHardwareNodesHcuUrl(id: number): string{
        return this.baseUrl + "/hardware/type/hcu/id/" + id;
    }

    public getHardwareNodesCmtsUrl(id: number): string{
        return this.baseUrl + "/hardware/type/cmts/id/" + id;
    }

    public getContainerMoveUrl(containerId: string): string{
        return this.baseUrl + "/" + containerId + "/move/containers";
    }

    public getElementMoveUrl(containerId: string): string{
        return this.baseUrl + "/" + containerId + "/move/elements";
    }

    public getNodeOnlyContainersUrl(): string{
        return this.baseUrl + "/nodeContainers";
    }

    public getAllContainersUrl(): string {
        return this.baseUrl + "/path";
    }
}