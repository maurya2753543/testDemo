import { map,catchError } from 'rxjs/operators';
import {Injectable} from "@angular/core";

import {ContainerHttpService} from "./container-http.service";
import {Observable} from "rxjs";
import { _throw } from 'rxjs/observable/throw';

@Injectable()

export class ContainerDataService{
    selectedTab: string;
    public containermetafilterchangedata: any;
    constructor(private containerHttpService: ContainerHttpService){}

    public getContainerList(): Observable<any> {
        return this.containerHttpService.getContainerList()
        .pipe(
            map((containerList: any) => {
                return containerList;
            }),catchError(this.handleError)
        )
    }

    public getContainerMetaTypeList(): Observable<any> {
        return this.containerHttpService.getContainerMetaTypeList()
        .pipe(
            map((containerMetaTypeList: any) => {
                console.log(containerMetaTypeList)
                return containerMetaTypeList;
            }),catchError(this.handleError)
        )
    }

    public syncContainerData(id: any): Observable<any> {
        return this.containerHttpService.syncContainerData(id)
        .pipe(
            map((containerData: any) => {
                return containerData;
            }),catchError(this.handleError)
        )
    }

    public updateMetaType(data: any): Observable<any>{
        return this.containerHttpService.updateMetaType(data)
        .pipe(
            map(()=>{
                return true;
            }),catchError(this.handleError)
        )
    }

    public createMetaType(data: any): Observable<any>{
        return this.containerHttpService.createMetaType(data)
        .pipe(
            map(()=>{
                return true;
            }),catchError(this.handleError)
        )
    }

    public deleteMetaType(id: number): Observable<any>{
        return this.containerHttpService.deleteMetaType(id)
        .pipe(
            map(()=>{
                return true;
            }),catchError(this.handleError)
        )
    }

    public deleteContainer(id: number): Observable<any>{
        return this.containerHttpService.deleteContainer(id)
        .pipe(
            map(()=>{
                return true;
            }),catchError(this.handleError)
        )
    }

    public createContainer(data: any): Observable<any>{
        return this.containerHttpService.createContainer(data)
        .pipe(
            map((container: any) => {
                return container;
            }),catchError(this.handleError)
        )
    }

    public updateContainer(data: any): Observable<any>{
        return this.containerHttpService.updateContainer(data)
        .pipe(
            map((container: any) => {
                return container;
            }),catchError(this.handleError)
        )
    }

    public getHardwareList(): Observable<any> {
        return this.containerHttpService.getHardwareList()
        .pipe(
            map((dataList: any) => {
                return this.processHardwareData(dataList);
            }),catchError(this.handleError)
        )
    }

    private processHardwareData(dataList: any[]): any[]{
        dataList.forEach((data: any) => {
            data["isFilter"] = true;
        });
        return dataList;
    }

    public getHardwareNodesHcu(id: number): Observable<any> {
        return this.containerHttpService.getHardwareNodesHcu(id)
        .pipe(
            map((dataList: any) => {
                return dataList;
            }),catchError(this.handleError)
        )
    }

    public getHardwareNodesCmts(id: number): Observable<any> {
        return this.containerHttpService.getHardwareNodesCmts(id)
        .pipe(
            map((dataList: any) => {
                return dataList;
            }),catchError(this.handleError)
        )
    }

    public moveContainers(containerId: string, data: any): Observable<any>{
        return this.containerHttpService.moveContainers(containerId, data)
        .pipe(
            map(() => {
                return true;
            }),catchError(this.handleError)
        )
    }

    public moveElements(containerId: string, data: any): Observable<any>{
        return this.containerHttpService.moveElements(containerId, data)
        .pipe(
            map(() => {
                return true;
            }),catchError(this.handleError)
        )
    }

    public getNodeOnlyContainers(): Observable<any>{
        return this.containerHttpService.getNodeOnlyContainers()
        .pipe(
            map((dataList) => {
                return dataList;
            })
        );
    }

    public getAllContainers(): Observable<{id: number, containerPath: string}> {
        return this.containerHttpService.getAllContainers()
        .pipe(
            map(r => r)
        )
    }

    getTab(){
        return this.selectedTab;
    }

    setTab(value: string){
        this.selectedTab = value;
    }

    //Error handler
    public handleError(error) {
        console.log('handleError---> ',error)
        return _throw(error);
    }
}
