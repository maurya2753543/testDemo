import { TranslateService } from '@ngx-translate/core';
/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Injectable } from "@angular/core";
import { ColDef } from "ag-grid";
//import { LocalizationService } from "angular2localization";
import { SharedService } from "../../../shared/shared.service";
import { DisabledFilter } from "./../../shared/grid/disabled.filter";
import { EDIT_ICON } from "./../../../constant/app.constants";
import { OtuStore } from "../otu.state";
import { ViewOtuItemAction } from "../reducers/otu.reducer";
import { SelectBoxFilter, SelectBoxFilterParams } from "../../../shared/select-box.filter";
import { StatusFilter } from 'src/app/shared/status.filter';

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
@Injectable()
export class OtuGridColumnDefinitionService {

    private _HEADER_FIELDS = {
        name: { field: 'name', name: 'OTU_NAME' },
        status: { field: 'status', name: 'STATUS' },
        url: { field: 'url', name: 'OTU_URL' },
		proxyHostname: { field: 'proxyHostname', name: 'OTU_PROXYHOSTNAME' },
        model: { field: 'model', name: 'OTU_MODEL' },
        portCount: { field: 'portCount', name: 'OTU_PORT_COUNT' },
        serialNumber: { field: 'serialNumber', name: 'OTU_SERIAL_NUMBER' },
        softwareVersion: { field: 'softwareVersion', name: 'OTU_SOFTWARE_VERSION' },
        view: { field: 'view', name: 'OTU_HEADER_VIEW' }
    };

    constructor(private sharedService: SharedService, private otuStore: OtuStore) { }

    /**
     * Get column def for otu data-grid
     */
    public getColumnDef(localizationService: TranslateService): ColDef[] {
        // console.log('isReady definistion', localizationService);
        // let statusFilterParams = <SelectBoxFilterParams> { 
        //     noSelectionDisplay: localizationService.instant('DEFAULT'),
        //     valuePassesFilter: (row, filter) => row.data.offline === filter,
        //     values: [{
        //         value: false,
        //         display: localizationService.instant('ONLINE').toLocaleUpperCase()
        //     }, {
        //         value: true,
        //         display: localizationService.instant('OFFLINE')
        //     }]
        // };
        StatusFilter.setSeverity(
            {
                default: localizationService.instant('DEFAULT'),
                online: localizationService.instant('ONLINE'),
                offline: localizationService.instant('OFFLINE'),
                busy: localizationService.instant('BUSY'),
                error: localizationService.instant('ERROR'),
                disabled: localizationService.instant('DISABLED'),
                unavailable: localizationService.instant('UNAVAILABLE')
            }
        );
        StatusFilter.setCMTSVisibility(false);
        StatusFilter.setRCIVisibility(true);
        console.log('localizationService service',localizationService, localizationService.instant(this._HEADER_FIELDS.name.name));
        return [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep'},
                suppressResize: true
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.name.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.name.name),
                field: this._HEADER_FIELDS.name.field,
                width: 200,
                minWidth: 180,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                sort: 'asc'
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.status.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.status.name),
                field: this._HEADER_FIELDS.status.field,
                width: 200,
                minWidth: 180,
                // valueFormatter: val => val.value ? localizationService.instant('OFFLINE').toUpperCase() : localizationService.instant('ONLINE').toUpperCase(),
                filter: StatusFilter.ParentFilter,
                filterParams: Object.assign({
                    suppressAndOrCondition: true,
                    newRowsAction: 'keep'
                }),
                floatingFilterComponent: StatusFilter.ChildFloatingFilter,
                floatingFilterComponentParams: Object.assign({
                    suppressFilterButton: true
                })
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.url.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.url.name),
                field: this._HEADER_FIELDS.url.field,
                width: 260,
                minWidth: 200,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                cellRenderer: (params) => `<a class="tableUrlLink" href="${params.value}" target="_blank">${params.value}</a>`
            },
			{
				headerName: localizationService.instant(this._HEADER_FIELDS.proxyHostname.name),
				headerTooltip: localizationService.instant(this._HEADER_FIELDS.proxyHostname.name),
				field: this._HEADER_FIELDS.proxyHostname.field,
				width: 280,
                minWidth: 200,
				filter: 'text',
				floatingFilterComponentParams: { suppressFilterButton: true },
				filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                cellRenderer: function(params) {
				    if(params.value != null){
				        return '<a class="tableUrlLink" href="' + params.value + '" target="_blank">' + params.value + '</a>'
                    }}
			},
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.model.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.model.name),
                field: this._HEADER_FIELDS.model.field,
                width: 200,
                minWidth: 180,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'},
                valueGetter: params => localizationService.instant(params.data.model)
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.portCount.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.portCount.name),
                field: this._HEADER_FIELDS.portCount.field,
                width: 200,
                minWidth: 180,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true ,
                    newRowsAction: 'keep'}
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.serialNumber.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.serialNumber.name),
                field: this._HEADER_FIELDS.serialNumber.field,
                width: 200,
                minWidth: 180,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                headerName: localizationService.instant(this._HEADER_FIELDS.softwareVersion.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.softwareVersion.name),
                field: this._HEADER_FIELDS.softwareVersion.field,
                width: 200,
                minWidth: 180,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' }
            },
            {
                colId: 'edit',
                headerName: localizationService.instant(this._HEADER_FIELDS.view.name),
                headerTooltip: localizationService.instant(this._HEADER_FIELDS.view.name),
                field: this._HEADER_FIELDS.view.field,
                pinned: 'right',
                minWidth: 70,
                maxWidth: 120,
                width: 70,
                sortingOrder: [null],
                suppressSorting: true,
                cellStyle: () => {
                    return { 'text-align': 'center' };
                },
                filter: 'text',
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { newRowsAction: 'keep' },
                suppressMenu: true,
                cellRenderer: ((param: any) => {
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    eFilterText.addEventListener("click", (() => {
                        this.editItem(param);
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })

            }
        ];
    }

    private editItem(param: any) {
        this.otuStore.dispatch(new ViewOtuItemAction(param.data));
    }
}