import { map } from 'rxjs/operators';
import { Component, Input, OnDestroy } from "@angular/core";
import { OtuItemState, ItemMode, ClearItemViewAction as ClearOtuViewAction, SetOtuItemModeAction, SliderStatus, SaveOtuAction, AddOtuAction, SAVE_OTU_ACTION, OtuErrorAction, RefreshOtuListAction, DELETE_OTU_ACTION, DeleteOtuAction, OTU_ERROR_ACTION, SetOtuSliderStatusAction, ConnectionStatus, SetOtuConnectionStatusAction, SET_OTU_CONNECTION_STATUS, TestOtuConnectionAction, TEST_OTU_CONNECTION_ACTION } from "../../reducers/otu.reducer";
import { OtuResponse } from "../../models/otu-response";
import { OtuStore, StoreAction } from "../../otu.state";
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AddOtuRequest } from "../../models/add-otu-request";
import { Subject, Observable, of, merge } from "rxjs";
import 'rxjs/add/operator/merge';
import { takeUntil, withLatestFrom, filter, exhaustMap, switchMap, catchError} from 'rxjs/operators';
import { OtuHttpService } from "../../otu.http.service";
import {ShowAlert} from "../../../../utilities/showAlert";
//import { LocalizationService } from "angular2localization";
import { OtuErrorService } from "../../otu.error.service";
import { TranslateService } from '@ngx-translate/core';

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

/**
 * The OtuItemViewComponent is a component for viewing, editing, and creating OTUs. It's a "ViewComponent" in the sense
 * that it is closer to the View in the MVC pattern - not in the sense that it is only used for "viewing" OTUs.
 */
@Component({
    selector: 'otu-item-view-component',
    templateUrl: './otu-item.view-component.html'
})
export class OtuItemViewComponent implements OnDestroy {
    private ItemMode = ItemMode;
    private SliderStatus = SliderStatus;
    private ConnectionStatus = ConnectionStatus;
    public otuForm: FormGroup;
    private ngUnsubscribe = new Subject();

    @Input() public mode: ItemMode;
    @Input() public sliderStatus: SliderStatus;
    @Input() public connectionStatus: ConnectionStatus;
    @Input('localizationService') private ls: TranslateService;

    private _otu: OtuResponse;
    get otu(): OtuResponse { return this._otu }
    @Input() set otu(val: OtuResponse) {
        this._otu = val;
        this.setupForm();
    }

    constructor(
        private otuStore: OtuStore,
        private fb: FormBuilder,
        private otuService: OtuHttpService,
        private showAlert: ShowAlert) {

        this.initializeEffects();
    }

    // FORM HELPERS

    private setupForm() {
        if (this.otu == null) {
            this.otuForm = null;
            return;
        }

        let disabled = this.sliderStatus === SliderStatus.DISABLED;
        this.otuForm = this.fb.group({
            name: this.fb.control({ value: this.otu.name, disabled: disabled }, Validators.required),
            url: this.fb.control({ value: this.otu.url, disabled: disabled }, Validators.pattern(/^http[s]?:\/\/.*/)),
            proxyHostname: this.fb.control( {value: this.otu.proxyHostname, disabled: disabled }, Validators.pattern(/^http[s]?:\/\/.*/)),
            username: this.fb.control({ value: this.otu.username, disabled: disabled }, Validators.required),
            password: this.fb.control({ value: this.otu.password, disabled: disabled }, Validators.required),
            location: this.fb.control({ value: this.otu.location, disabled: disabled }),
            notes: this.fb.control({ value: this.otu.notes, disabled: disabled })
        });

        this.setupFormEvents();
    }

    private resetFormEvents = new Subject();
    private setupFormEvents() {
        this.resetFormEvents.next();

        // set ConnectionStatus to untested on change of any connection info
        merge(this.url.valueChanges, this.username.valueChanges, this.password.valueChanges)
            .pipe(withLatestFrom(this.otuStore.select(s => s.itemView.connectionStatus)),
            takeUntil(this.resetFormEvents),
            filter(args => args[1] !== ConnectionStatus.UNTESTED))
            .subscribe(() => this.otuStore.dispatch(new SetOtuConnectionStatusAction(ConnectionStatus.UNTESTED)));
    }

    get name() { return this.otuForm.get('name'); }
    get url() { return this.otuForm.get('url'); }
    get proxyHostname() { return this.otuForm.get('proxyHostname');}
    get username() { return this.otuForm.get('username'); }
    get password() { return this.otuForm.get('password'); }
    get location() { return this.otuForm.get('location'); }
    get notes() { return this.otuForm.get('notes'); }

    showValidationErrors(control: FormControl) {
        return control.invalid && (control.dirty || control.touched);
    }

    // INTERFACE METHODS

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    // EVENT HANDLERS

    closeEditor() {
        this.otuStore.dispatch(new ClearOtuViewAction())
    }

    enableEdit() {
        this.otuStore.dispatch(new SetOtuItemModeAction(ItemMode.EDIT));
    }

    submitForm() {
        this.otuStore.dispatch(new SaveOtuAction(this.getOtuSaveEntity()));
    }

    delete() {
        this.showAlert.showCustomWarningAlertConfirm(this.ls.instant('REMOVE_OTU'), this.ls.instant('REMOVE_OTU_CONFIRM'),
            (isConfirm) => {
                if (isConfirm) {
                    this.otuStore.dispatch(new DeleteOtuAction(this.otu.elementId));
                }
            }
        );
    }

    testConnection() {
        this.otuStore.dispatch(new TestOtuConnectionAction(this.url.value, this.username.value, this.password.value));
    }

    // OTHER HELPER METHODS

    /**
     * Based on effects from redux pattern. Effects emit actions to the store without necessarily requiring user action. They also
     * are frequently used for triggering Actions after other Actions have been triggered.
     * 
     * These are effects that are local to just the otu-item slide-out editor.
     */
    private initializeEffects() {
        // Send add/update request on save
        this.otuStore.actionsOfType<SaveOtuAction>(SAVE_OTU_ACTION)
            .pipe(takeUntil(this.ngUnsubscribe),
            map(a => this.mode === ItemMode.NEW ?
                this.otuService.addOtu(<AddOtuRequest>a.otu) :
                this.otuService.updateOtu(<OtuResponse>a.otu)),
            exhaustMap(
                request => request
                    // close editor and refresh list on success
                    .pipe(switchMap(r => of<StoreAction>(new ClearOtuViewAction(), new RefreshOtuListAction())),
                    // display error and re-enable editor on fail
                    catchError(err => {
                        const getErr: any = this.getErrorActionObservable(err);
                        return getErr.pipe(merge(of<StoreAction>(new SetOtuSliderStatusAction(SliderStatus.VISIBLE)))) 
                    }))
            ))
            .subscribe((action: any) => this.otuStore.dispatch(action));

        // Send delete request on removal
        this.otuStore.actionsOfType<DeleteOtuAction>(DELETE_OTU_ACTION)
            .pipe(takeUntil(this.ngUnsubscribe),
            map(a => this.otuService.deleteOtu(a.otuId)),
            exhaustMap(
                request => request
                    .pipe(// close editor and refresh list on success
                        switchMap(r => of<StoreAction>(new ClearOtuViewAction(), new RefreshOtuListAction())),
                        // display error and re-enable editor on fail
                        catchError(err => this.getErrorActionObservable(err).merge(of<StoreAction>(new SetOtuSliderStatusAction(SliderStatus.VISIBLE)))))
            ))
            .subscribe(action => this.otuStore.dispatch(action));

        // Test connection
        this.otuStore.actionsOfType<TestOtuConnectionAction>(TEST_OTU_CONNECTION_ACTION)
            .pipe(takeUntil(this.ngUnsubscribe),
            map(a => this.otuService.testConnectionInfo(a.url, a.username, a.password)),
            exhaustMap(
                request => request
                    .pipe(switchMap(r => {
                        this.showAlert.showInfoAlert(this.ls.instant('TEST_CONNECTION_SUCCESSFUL'));
                        // TODO: On successful connection, take the response and dispatch another action (yet to be defined) that overwrites the state of the active OTU
                        // once we do that, we'll need to allow for the extra read-only info at the bottom of the editor to be visible in "NEW" mode.
                        return of<StoreAction>(new SetOtuConnectionStatusAction(ConnectionStatus.CONNECTED))
                    }),
                    catchError(err => this.getErrorActionObservable(err).merge(of<StoreAction>(new SetOtuConnectionStatusAction(ConnectionStatus.FAILED)))))
            ))
            .subscribe(action => this.otuStore.dispatch(action));
    }

    private getErrorActionObservable(err): Observable<OtuErrorAction> {
        return of(new OtuErrorAction(err));
    }

    private getOtuSaveEntity(): OtuResponse | AddOtuRequest {
        var editableFields = <AddOtuRequest>{
            name: this.name.value,
            url: this.url.value,
            proxyHostname: this.proxyHostname.value,
            username: this.username.value,
            password: this.password.value,
            location: this.location.value,
            notes: this.notes.value
        };

        if (this.mode == ItemMode.NEW) {
            return editableFields;
        }

        return Object.assign({}, this.otu, editableFields);
    }
}