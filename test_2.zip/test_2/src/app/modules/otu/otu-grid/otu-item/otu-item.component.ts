import { TranslateService } from '@ngx-translate/core';
import { map } from 'rxjs/operators';
import { Component, Input } from "@angular/core";
import { OtuStore } from "../../otu.state";
import { SliderStatus } from "../../reducers/otu.reducer";
//import { LocalizationService } from "angular2localization";

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

 @Component({
     selector: 'otu-item-component',
     templateUrl: './otu-item.component.html'
 })
 export class OtuItemComponent {

    public _ls: TranslateService;
    public get ls() { return this._ls; }
    @Input("localizationService") public set ls(value: TranslateService) {
        this._ls = value;
    }

    constructor(private otuStore: OtuStore) {}

    public otuState = this.otuStore.select(s => s.itemView.otu);
    public mode = this.otuStore.select(s => s.itemView.mode);
    public sliderStatus = this.otuStore.select(s => s.itemView.sliderStatus);
    public connectionStatus = this.otuStore.select(s => s.itemView.connectionStatus);

    public closeSlider = this.otuStore
        .select(s => s.itemView.sliderStatus)
        .pipe(map(m => m == SliderStatus.HIDDEN))
        
 }