/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Component, OnInit } from "@angular/core";
import { SharedService } from "../../../shared/shared.service";
import { OtuGridService } from "./otu-grid.service";
import { Observable, Subject } from "rxjs";
import {filter, combineLatest, map, merge} from 'rxjs/operators';
import { LocaleDataService } from "../../../shared/locale.data.service";
//import { LocalizationService } from "angular2localization";
import { Grid } from './../../../shared/ag-grid.options';
import { OtuGridColumnDefinitionService } from "./otu-grid.column-definition.service";
import { GRID_COMP_KEY_SINGLE, GRID_COMP_KEY_MULTI, GRID_COMP_KEY_ONLY_SINGLE, GRID_COMP_KEY_ALL } from "../../../constant/app.constants";
import { ADD_OTU_ACTION, AddOtuAction, RefreshOtuListAction, OtuErrorAction } from "../reducers/otu.reducer";
import { OtuStore } from "../otu.state";
import { OtuHttpService } from "../otu.http.service";
import {ShowAlert} from "../../../utilities/showAlert";
import { ControlMessagesService } from "../../../shared/control.messages.service";
// import { iM } from '@angular/core/src/r3_symbols';
// import { pipe } from '@angular/core/src/render3/pipe';

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

// Component-Local actions - these are events that don't really need to be part of the shared store as they do not affect any shared state.
const SYNC_ALL = 'SYNC_ALL';
const SYNC_SELECTED = 'SYNC_SELECTED';
const SYNC_CLOCK = 'SYNC_CLOCK';
const TEST_CONNECTION = 'TEST_CONNECTION';

@Component({
    selector: 'otu-grid-component',
    templateUrl: 'otu-grid.component.html'
})
export class OtuGridComponent implements OnInit {
    private gridModelUpdated = new Subject();

    //#region Observable Properties

    public rowData = this.otuGridService.otuList;
    public localizationService: Observable<any>;
    public gridOptions: Observable<Grid>;
    public buttonKeys: Observable<Object[]>;
    public eventKeys: Observable<Object[]>;
    public showAllLabel: Observable<string>;
    public showAllLabelMob: Observable<string>;
    public showRefreshButton = this.localeDataService.isReady;
    public exportFileName: any;
    private gridApi: any;
    //#endregion

    //#region Constructor

    constructor(private sharedService: SharedService,
        private localeDataService: LocaleDataService,
        private otuGridService: OtuGridService,
        private columnDefinitionService: OtuGridColumnDefinitionService,
        private otuStore: OtuStore,
        private otuHttpService: OtuHttpService,
        private showAlert: ShowAlert,
        private controlMessageService: ControlMessagesService) {

        this.localizationService = this.localeDataService.isReady
            .pipe(filter(ready => { console.log('otu -> isReady', ready); return ready }),
            map(r => this.localeDataService.getLocalizationService()));

        this.gridOptions = this.localizationService.
        pipe(
            map(ls => {
            let result = new Grid();
            result.setColumnDefs(this.columnDefinitionService.getColumnDef(ls));
            return result;
        }));

        this.localeDataService.componentCallback.subscribe((response) => {
            this.setupButtons();
            this.setupCounts();
        });
    }

    //#endregion

    ngOnInit(){
        this.setupButtons();
        this.setupCounts();
        if(this.sharedService.RetainFilter){
            this.otuGridService.otufilterchangedata = "";
            this.otuHttpService.otugridmodel = "";
        }
    }

    //#region Setup Helpers

    private setupCounts() {
        // let totalCount = this.localizationService.pipe(map(ls => {                
        //     let result = new Grid();
        //     result.setColumnDefs(this.columnDefinitionService.getColumnDef(ls));
        //     return result;
        // }));
        let totalCount = this.rowData.pipe(map(r => r.length));
        let rowCount = this.gridModelUpdated // when the model is updated
            .pipe(combineLatest(this.gridOptions), // get latest grid options
            filter(result => result[1].api != null), // when the grid api is not null
            map(result => result[1].api.getDisplayedRowCount() // retrieve the displayed row count
            ), merge(totalCount)); // or take the total count of data
        
        let counts = this.localizationService.pipe(combineLatest(totalCount, rowCount));
        this.showAllLabel = counts
            .pipe(map(result => {
                let ls = result[0];
                let totalCount = result[1];
                let rowCount = result[2];
                let trans = this.localeDataService.getLocalizationService();
                console.log('otu --> ls 12', result, 'and ls', ls, 'translate', trans.instant('TABLE_LIST_SHOWING'))
                return `${ls.instant('TABLE_LIST_SHOWING')} ${rowCount} ${ls.instant('TABLE_LIST_SHOWING_OF')} ${totalCount} ${ls.instant('TABLE_LIST_ROWS')}`;
            }));

        this.showAllLabelMob = counts.pipe(map(count => `${count[2]}/${count[1]}`));
    }
    public notifyFilterChangeOTU(event): any{
        this.sharedService.RetainFilter = false;
        const countryFilterComponent = this.gridApi.getFilterInstance('name');
        const model = countryFilterComponent.getModel();
        this.otuHttpService.otugridmodel = model;
        this.otuGridService.otufilterchangedata = this.gridApi.getFilterModel();

    }
    private setupButtons() {
        this.buttonKeys = this.localizationService.pipe(
            map(ls => [{ name: ls.instant('ADD_OTU'), action: ADD_OTU_ACTION }])
        );
        this.eventKeys = this.localizationService
            .pipe(
                map(ls => 
                    {
                        console.log('Is Translated ---> ', ls);
                        return [
                            { name: ls.instant('TABLE_LIST_SYNC_ALL'), status: GRID_COMP_KEY_ALL, action: SYNC_ALL },
                            { name: ls.instant('TABLE_LIST_SYNC_SELECTED'), status: GRID_COMP_KEY_SINGLE, action: SYNC_SELECTED },
                            { name: ls.instant('TEST_CONNECTION'), status: GRID_COMP_KEY_ONLY_SINGLE, action: TEST_CONNECTION },
                            { name: ls.instant('TABLE_LIST_SYNC_CLOCK'), status: GRID_COMP_KEY_SINGLE, action: SYNC_CLOCK },
                            { name: ls.instant('TABLE_LIST_EXPORT_SELECTED'), status: GRID_COMP_KEY_SINGLE },
                            { name: ls.instant('TABLE_LIST_EXPORT_ALL'), status: GRID_COMP_KEY_MULTI }
                        ]
                    }
                )
            )
    }

    //#endregion

    //#region Event Handlers
    public gridReady(param): void{
        const filter: string = this.sharedService.getFilterForTAB();
        this.gridApi = param.api;
        if (filter.length) {
            document.getElementById('statusFilter')['value'] = filter.toUpperCase();
            param.api.getFilterInstance('status')
                .setModel(filter.toUpperCase());
            param.api.onFilterChanged();
        }
        if(this.gridApi && ( !jQuery.isEmptyObject(this.otuGridService.otufilterchangedata) || this.otuHttpService.otugridmodel)){
            this.gridApi.setFilterModel(this.otuGridService.otufilterchangedata); 
            if(this.otuHttpService.otugridmodel || this.otuGridService.otufilterchangedata){
            const countryFilterComponent3 = this.gridApi.getFilterInstance("name");
            countryFilterComponent3.setModel(this.otuHttpService.otugridmodel);
            }
        }
    }
    public gridModelUpdatedEmitter(params:any) {
        this.gridModelUpdated.next();
    }

    public handleRefreshGrid(params:any) {
        this.otuStore.dispatch(new RefreshOtuListAction());
    }

    public handleButtonEvent(context) {
        switch (context.event.action) {
            case ADD_OTU_ACTION:
                this.otuStore.dispatch(new AddOtuAction());
                break;
            case SYNC_ALL:
                this.syncAll();
                break;
            case SYNC_SELECTED:
                this.syncSelected(context.selectedData.map(r => r.elementId));
                break;
            case TEST_CONNECTION:
                this.testConnection(context.selectedData[0].elementId);
                break;
            case SYNC_CLOCK:
                this.syncClock(context.selectedData.map(r => r.elementId));
                break;
        }
    }
    
    syncClock(otuIds: number[]) {
        this.otuHttpService.syncClock(otuIds)
            .pipe(combineLatest(this.localizationService))
            .subscribe(
                args => this.showAlert.showInfoAlert(args[1].instant('SYNC_CLOCK_SUCCESSFUL')),
                err => this.otuStore.dispatch(new OtuErrorAction(err))
            );
    }
    
    testConnection(otuId: number) {
        this.otuHttpService.testConnection(otuId)
            .pipe(combineLatest(this.localizationService))
            .subscribe(
                args => this.showAlert.showInfoAlert(args[1].instant('TEST_CONNECTION_SUCCESSFUL')),
                err => this.otuStore.dispatch(new OtuErrorAction(err))
            );
    }
    
    syncSelected(otuIds: number[]) {
        this.otuHttpService.sync(otuIds)
            .pipe(combineLatest(this.localizationService))
            .subscribe(
                args => this.showAlert.showInfoAlert(args[1].instant('SYNC_INITIALIZED')),
                err => this.otuStore.dispatch(new OtuErrorAction(err))
            );
    }
    
    syncAll() {
        this.otuHttpService.syncAll()
            .pipe(combineLatest(this.localizationService))
            .subscribe(
                args => this.showAlert.showInfoAlert(args[1].instant('SYNC_INITIALIZED')),
                err => this.otuStore.dispatch(new OtuErrorAction(err))
            );
    }

    //#endregion
}