/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Injectable } from "@angular/core";
import { OtuHttpService } from "../otu.http.service";
import { OtuStore } from "../otu.state";
import { Observable } from "rxjs";
import { OtuResponse } from "../models/otu-response";
import { REFRESH_OTU_LIST_ACTION, OtuErrorAction, OTU_ERROR_ACTION } from "../reducers/otu.reducer";
import { OtuErrorService } from "../otu.error.service";
import {repeatWhen, publishReplay, refCount } from 'rxjs/operators'
/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
@Injectable()
export class OtuGridService {
        public otufilterchangedata: any;
    constructor(
        private otuHttpService: OtuHttpService,
        private otuStore: OtuStore) {}

    /**
     * The list of OTUs to be displayed in the OTU Grid.
     */
    public otuList: Observable<OtuResponse[]> = this.otuHttpService
        .getOtuList()
        .pipe(repeatWhen(() => this.otuStore.actionsOfType(REFRESH_OTU_LIST_ACTION)),
        publishReplay(1),
        refCount());
}