
import { Routes, RouterModule } from '@angular/router';
import {OtuComponent} from "./otu.component";
import { NgModule } from '@angular/core';

const routes: Routes = [
    { path: '', component: OtuComponent ,pathMatch : 'prefix'}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class OtuRoutes{}
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);