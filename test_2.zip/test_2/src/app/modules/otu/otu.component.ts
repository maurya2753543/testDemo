/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */
import { Component, OnInit } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { Observable } from 'rxjs';
import { OTU_MODULE } from './../../constant/app.constants';
import { LocaleDataService } from './../../shared/locale.data.service';
import { OtuErrorService } from './otu.error.service';
import { OtuHttpService } from './otu.http.service';
import { OtuStore } from './otu.state';
import { OtuErrorAction, OTU_ERROR_ACTION } from './reducers/otu.reducer';
import { NavService } from '../../shared/nav.service';

@Component({
    selector: 'otu-component',
    templateUrl: 'otu.component.html'
})
export class OtuComponent implements OnInit {
    selectedTab = '';
    public loadComponent: Observable<boolean>;

    constructor(
        public localeDataService: LocaleDataService,
        public navService: NavService,
        private otuStore: OtuStore,
        private otuService: OtuHttpService,
        private otuErrorService: OtuErrorService,
        public translate : TranslateService) {
        let module = OTU_MODULE;
        this.localeDataService.initLanguage(module); /* To set the current browser's language */
        this.loadComponent = this.localeDataService.isReady;
        this.initializeEffects();
    }

    LoadTab(tab: string) { this.selectedTab = tab.toLowerCase(); }

    ngOnInit(){
        this.selectedTab = this.otuService.getTab();
        this.translate.onLangChange.subscribe(lang => {
            this.otuService.setTab('otu');
            this.LoadTab('otu');
            console.log('default --> onLang ',lang,  this.translate.instant('DEFAULT'))
        })
    }

    // PRIVATE HELPER METHODS

    /**
     * Based on effects from redux pattern. Effects emit actions to the store without necessarily requiring user action. They also
     * are frequently used for triggering Actions after other Actions have been triggered.
     * 
     * These are effects that are global to all views and components within the OTU module.
     */
    private initializeEffects() {
        // Show error notification on any sort of error
        this.otuStore.actionsOfType<OtuErrorAction>(OTU_ERROR_ACTION)
            .subscribe(action => this.otuErrorService.showError(action.error));
    }
}