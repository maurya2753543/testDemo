/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import {OtuState, StoreAction} from "../otu.state";
import {OtuPortEditModel, OtuPortResponse} from "../models/otu-port";
import {ItemMode, SliderStatus} from "./otu.reducer";

//#region STATE

export class OtuPortState {
    port: OtuPortEditModel;
    sliderStatus: SliderStatus;
    itemMode: ItemMode;
}

export const defaultOtuPortState: OtuPortState = {
    port: null,
    itemMode: ItemMode.VIEW,
    sliderStatus: SliderStatus.HIDDEN
};

//#endregion

//#region ACTIONS

export const REFRESH_OTU_PORT_LIST_ACTION = 'REFRESH_OTU_PORT_LIST_ACTION';

export const OPEN_PORT_EDITOR_ACTION = 'ENABLE_PORT_EDITOR_ACTION';
export const ENABLE_EDIT_PORT_ACTION = 'ENABLE_EDIT_PORT_ACTION';
export const SET_OTU_PORT_SLIDER_STATUS_ACTION = 'SET_OTU_PORT_SLIDER_STATUS_ACTION';
export const CLOSE_PORT_EDITOR_ACTION = 'CLOSE_PORT_EDITOR_ACTION';
export const DISABLE_PORT_EDITOR_ACTION = 'DISABLE_PORT_EDITOR_ACTION';
export const SAVE_PORT_ACTION = 'SAVE_PORT_ACTION';
export const SAVE_MULTIPLE_PORTS_ACTION = 'SAVE_MULTIPLE_PORTS_ACTION';

/**
 * Used for indicating that the OTU Port List should be refreshed. This does not affect the state of the store.
 */
export class RefreshOtuPortListAction implements StoreAction {
    public type = REFRESH_OTU_PORT_LIST_ACTION;
}

export class OpenPortEditorAction implements StoreAction {
    public type = OPEN_PORT_EDITOR_ACTION;
    constructor(public port: OtuPortEditModel) {}
}

export class EnableEditPortAction implements StoreAction {
    public type = ENABLE_EDIT_PORT_ACTION;
}

export class ClosePortEditorAction implements StoreAction {
    public type = CLOSE_PORT_EDITOR_ACTION;
}

export class DisablePortEditorAction implements StoreAction {
    public type = DISABLE_PORT_EDITOR_ACTION;
}

export class SavePortAction implements StoreAction {
    public type = SAVE_PORT_ACTION;
    constructor (public port: OtuPortEditModel){}
}

export class SaveMultiplePortsAction implements StoreAction {
    public type = SAVE_MULTIPLE_PORTS_ACTION;
    constructor (public ports: OtuPortEditModel[]) {}
}

export class SetOtuPortSliderStatusAction implements StoreAction {
    public type = SET_OTU_PORT_SLIDER_STATUS_ACTION;
    constructor (public sliderStatus: SliderStatus) {}
}

//#endregion

export function otuPortReducer(state: OtuState, action: StoreAction): OtuState {
    switch (action.type) {
        case OPEN_PORT_EDITOR_ACTION:
            state = mergePortState(state, {
                itemMode: ItemMode.VIEW,
                sliderStatus: SliderStatus.VISIBLE,
                port: (<OpenPortEditorAction>action).port
            });
            break;
        case ENABLE_EDIT_PORT_ACTION:
            state = mergePortState(state, {
                itemMode: ItemMode.EDIT
            });
            break;
        case SET_OTU_PORT_SLIDER_STATUS_ACTION:
            state = mergePortState(state, {
                sliderStatus: (<SetOtuPortSliderStatusAction>action).sliderStatus,
            });
            break;
        case CLOSE_PORT_EDITOR_ACTION:
            state = mergePortState(state, {
                itemMode: ItemMode.VIEW,
                sliderStatus: SliderStatus.HIDDEN,
                port: null
            });
            break;
        case DISABLE_PORT_EDITOR_ACTION:
            state = mergePortState(state, {
                sliderStatus: SliderStatus.DISABLED,
            });
            break;
    }

    return state;
}

/**
 * Merges pieces of the OtuItemState onto the OtuState's itemView property without
 * mutating the OtuState or OtuItemState objects.
 */
function mergePortState(state: OtuState, infoToMerge: any): OtuState {
    let portUpdate = Object.assign({}, state.otuPort, infoToMerge);
    return Object.assign({}, state, { otuPort: portUpdate });
}