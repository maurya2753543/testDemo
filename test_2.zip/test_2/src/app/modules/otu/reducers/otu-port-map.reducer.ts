/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
import { SliderStatus } from "./otu.reducer";

import { OtuPortResponse } from "../models/otu-port";
import { OtuState, StoreAction } from "../otu.state";

export class OtuPortMapState {
    public sliderStatus: SliderStatus;
    public selectedPorts: OtuPortResponse[]
}

export const defaultOtuPortMapState: OtuPortMapState = {
    sliderStatus: SliderStatus.HIDDEN,
    selectedPorts: []
};

// #region ACTIONS

export const OPEN_PORT_MAP_EDITOR_ACTION = 'ENABLE_PORT_MAP_EDITOR_ACTION';
export const CLOSE_PORT_MAP_EDITOR_ACTION = 'CLOSE_PORT_MAP_EDITOR_ACTION';
export const DISABLE_PORT_MAP_EDITOR_ACTION = 'DISABLE_PORT_MAP_EDITOR_ACTION';
export const SET_SELECTED_PORT_MAP_PORTS = 'SET_SELECTED_PORT_MAP_PORTS';
export const SET_PORT_MAP_SLIDER_STATUS_ACTION = 'SET_PORT_MAP_SLIDER_STATUS_ACTION';

export class OpenPortMapEditorAction implements StoreAction {
    public type = OPEN_PORT_MAP_EDITOR_ACTION;
}
export class ClosePortMapEditorAction implements StoreAction {
    public type = CLOSE_PORT_MAP_EDITOR_ACTION;
}
export class DisablePortMapEditorAction implements StoreAction {
    public type = DISABLE_PORT_MAP_EDITOR_ACTION;
}
export class SetSelectedPortMapPortsAction implements StoreAction {
    public type = SET_SELECTED_PORT_MAP_PORTS;
    constructor(public selectedPorts: OtuPortResponse[]) { }
}
export class SetPortMapSliderStatusAction implements StoreAction {
    public type = SET_PORT_MAP_SLIDER_STATUS_ACTION;
    constructor(public sliderStatus: SliderStatus) { }
}

// #endregion

export function otuPortMapReducer(state: OtuState, action: StoreAction): OtuState {
    switch (action.type) {
        case OPEN_PORT_MAP_EDITOR_ACTION:
            state = mergePortState(state, {
                sliderStatus: SliderStatus.VISIBLE
            });
            break;
        case CLOSE_PORT_MAP_EDITOR_ACTION:
            state = mergePortState(state, {
                sliderStatus: SliderStatus.HIDDEN,
                selectedPorts: []
            });
            break;
        case DISABLE_PORT_MAP_EDITOR_ACTION:
            state = mergePortState(state, {
                sliderStatus: SliderStatus.DISABLED
            });
            break;
        case SET_SELECTED_PORT_MAP_PORTS:
            state = mergePortState(state, {
                selectedPorts: (<SetSelectedPortMapPortsAction>action).selectedPorts
            });
            break;
        case SET_PORT_MAP_SLIDER_STATUS_ACTION:
            state = mergePortState(state, {
                sliderStatus: (<SetPortMapSliderStatusAction>action).sliderStatus
            });
            break;
    }

    return state;
}

/**
 * Merges pieces of the OtuItemState onto the OtuState's itemView property without
 * mutating the OtuState or OtuItemState objects.
 */
function mergePortState(state: OtuState, infoToMerge: any): OtuState {
    let portUpdate = Object.assign({}, state.otuPortMap, infoToMerge);
    return Object.assign({}, state, { otuPortMap: portUpdate });
}