import { AddOtuRequest } from "../models/add-otu-request";
import { OtuResponse } from "../models/otu-response";
import { OtuState, StoreAction } from "../otu.state";

export enum ItemMode {
    /**
     * Editing a new item
     */
    NEW,
    /**
     * Editing an existing item
     */
    EDIT,
    /**
     * Viewing an existing item
     */
    VIEW
}

export enum ConnectionStatus {
    /**
     * The OTU connection has either been tested and successful, or it is an existing OTU and assumed to be connected.
     */
    CONNECTED,
    /**
     * The OTU connection has not been tested.
     */
    UNTESTED,
    /**
     * In the process of testing the connection.
     */
    TESTING,
    /**
     * The OTU connection has been tested, but failed to connect.
     */
    FAILED
}

export enum SliderStatus {
    /**
     * Slide-out is visible
     */
    VISIBLE,
    /**
     * Slide-out is hidden
     */
    HIDDEN,
    /**
     * Slide-out is visible, but controls should be disabled.
     */
    DISABLED
}

/**
 * Represents the state of the OTU that is currently being viewed or edited
 */
export class OtuItemState {
    /**
     * The status of the OTU Slide-Out container.
     */
    public sliderStatus: SliderStatus;
    /**
     * The mode of the editor
     */
    public mode: ItemMode;
    /**
     * The status of the connection-test state of the current OTU.
     */
    public connectionStatus: ConnectionStatus;
    /**
     * The OTU currently being edited or viewed. Null if mode == ItemMode.NEW
     */
    public otu: OtuResponse;
}

export const defaultOtuItemState: OtuItemState = {
    sliderStatus: SliderStatus.HIDDEN,
    connectionStatus: ConnectionStatus.UNTESTED,
    mode: ItemMode.VIEW,
    otu: null
}

export const VIEW_OTU_ITEM_ACTION = 'VIEW_OTU_ITEM_ACTION';
/**
 * Initiates the view-mode for a specified, existing OTU. It is assumed that this OTU is already valid and can be connected to.
 */
export class ViewOtuItemAction implements StoreAction {
    public type = VIEW_OTU_ITEM_ACTION;
    /**
     * Creates a new ViewOtuItemAction that can be dispatched to initialize view-mode for an OTU.
     * @param otu The OTU to view.
     */
    constructor(public otu: OtuResponse) { }
}

export const CLEAR_ITEM_VIEW_ACTION = 'DISABLE_ITEM_VIEW_ACTION';
/**
 * Hides the slide-out and clears the currently active OTU item.
 */
export class ClearItemViewAction implements StoreAction {
    public type = CLEAR_ITEM_VIEW_ACTION;
}

export const SET_OTU_ITEM_MODE_ACTION = 'SET_OTU_ITEM_MODE_ACTION';
/**
 * Allows setting the ItemMode of the OtuItemState without changing the active OTU or the slide-out status.
 */
export class SetOtuItemModeAction implements StoreAction {
    public type = SET_OTU_ITEM_MODE_ACTION;
    constructor(public mode: ItemMode) { }
}

export const SET_OTU_SLIDER_STATUS_ACTION = 'SET_OTU_SLIDER_STATUS_ACTION';

/**
 * Allows for changing the SliderStatus without changing the active OTU or ItemMode.
 */
export class SetOtuSliderStatusAction implements StoreAction {
    public type = SET_OTU_SLIDER_STATUS_ACTION;
    constructor(public sliderStatus: SliderStatus) { }
}

export const SET_OTU_CONNECTION_STATUS = 'SET_OTU_CONNECTION_STATUS';

export class SetOtuConnectionStatusAction implements StoreAction {
    public type = SET_OTU_CONNECTION_STATUS;
    constructor(public connectionStatus: ConnectionStatus) { }
}

export const TEST_OTU_CONNECTION_ACTION = 'TEST_OTU_CONNECTION_ACTION';

export class TestOtuConnectionAction implements StoreAction {
    public type = TEST_OTU_CONNECTION_ACTION;
    constructor(public url: string, public username: string, public password: string) { }
}

export const ADD_OTU_ACTION = 'ADD_OTU_ACTION';

/**
 * Sets the mode to "NEW" and sets the active OTU to a default new OTU. Shows the slide-out if it is not visible.
 */
export class AddOtuAction implements StoreAction {
    public type = ADD_OTU_ACTION;
}

export const SAVE_OTU_ACTION = 'SAVE_OTU_ACTION';
/**
 * Saves an OTU and disables the OTU slide-out
 */
export class SaveOtuAction implements StoreAction {
    public type = SAVE_OTU_ACTION;
    constructor(public otu: OtuResponse | AddOtuRequest) { }
}

export const DELETE_OTU_ACTION = 'DELETE_OTU_ACTION';

/**
 * Deletes an OTU and disabled the OTU slide-out
 */
export class DeleteOtuAction implements StoreAction {
    public type = DELETE_OTU_ACTION;
    constructor(public otuId: number) { }
}

export const OTU_ERROR_ACTION = 'OTU_ERROR_ACTION';

/**
 * Used for indicating an error has occurred. This does not affect the state of the store, but can be used to handle various errors.
 */
export class OtuErrorAction implements StoreAction {
    public type = OTU_ERROR_ACTION;
    public error: any;
    constructor(error: any) {
        console.log('get json', error.error)
        if (error != null && error) {
            this.error = error;
        }
    }
}

export const REFRESH_OTU_LIST_ACTION = 'REFRESH_OTU_LIST_ACTION';

/**
 * Used for indicating that the OTU List should be refreshed. This does not affect the state of the store.
 */
export class RefreshOtuListAction implements StoreAction {
    public type = REFRESH_OTU_LIST_ACTION;
}

export function otuReducer(state: OtuState, action: StoreAction): OtuState {
    switch (action.type) {
        // CRUD actions
        case VIEW_OTU_ITEM_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: SliderStatus.VISIBLE,
                mode: ItemMode.VIEW,
                connectionStatus: ConnectionStatus.CONNECTED,
                otu: (<ViewOtuItemAction>action).otu
            });
            break;
        case ADD_OTU_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: SliderStatus.VISIBLE,
                connectionStatus: ConnectionStatus.UNTESTED,
                otu: {},
                mode: ItemMode.NEW
            });
            break;
        case SAVE_OTU_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: SliderStatus.DISABLED,
                otu: (<SaveOtuAction>action).otu
            });
            break;
        case DELETE_OTU_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: SliderStatus.DISABLED
            });
            break;

        // Simple state-change actions
        case CLEAR_ITEM_VIEW_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: SliderStatus.HIDDEN,
                mode: ItemMode.VIEW,
                otu: null
            });
            break;
        case SET_OTU_ITEM_MODE_ACTION:
            state = mergeItemViewState(state, {
                mode: (<SetOtuItemModeAction>action).mode
            });
            break;
        case SET_OTU_SLIDER_STATUS_ACTION:
            state = mergeItemViewState(state, {
                sliderStatus: (<SetOtuSliderStatusAction>action).sliderStatus
            });
            break;
        case SET_OTU_CONNECTION_STATUS:
            state = mergeItemViewState(state, {
                connectionStatus: (<SetOtuConnectionStatusAction>action).connectionStatus
            });
            break;
        case TEST_OTU_CONNECTION_ACTION:
            state = mergeItemViewState(state, {
                connectionStatus: ConnectionStatus.TESTING
            });
            break;
    }

    return state;
}

/**
 * Merges pieces of the OtuItemState onto the OtuState's itemView property without
 * mutating the OtuState or OtuItemState objects.
 */
function mergeItemViewState(state: OtuState, infoToMerge: any): OtuState {
    let itemViewUpdate = Object.assign({}, state.itemView, infoToMerge);
    return Object.assign({}, state, { itemView: itemViewUpdate });
}