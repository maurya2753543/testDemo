/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Injectable, OnDestroy } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { OtuItemState, defaultOtuItemState, otuReducer } from "./reducers/otu.reducer";
import { otuPortReducer, OtuPortState, defaultOtuPortState } from "./reducers/otu-port.reducer";
import { OtuPortMapState, defaultOtuPortMapState, otuPortMapReducer } from "./reducers/otu-port-map.reducer";
import { scan, publishReplay, refCount, filter, map, distinctUntilChanged  } from "rxjs/operators";

/**
 * This file contains all the state for this module.
 * 
 * TO MODIFY:
 *  When adding a new section/property on the OtuState class, create a new ".reducer.ts" file in the reducers directory.
 * In the reducer file, create a class that will contain all the pertinent state, any actions that will be dispatched for
 * that state, and the reducer, itself. 
 * 
 * Then, add the new state class to the OtuState as a property, and add the reducer to the "reducers" array, below.
 */

/**
 * Contains all shared state of the OTU module.
 */
export class OtuState {
    itemView: OtuItemState;
    otuPort: OtuPortState;
    otuPortMap: OtuPortMapState;
}

/**
 * Reducers defined for this module.
 */
const reducers: ((state: OtuState, action: StoreAction) => OtuState)[] = [
    otuReducer,
    otuPortReducer,
    otuPortMapReducer
];

/**
 * Initial state of the OTU module.
 */
const initialState: OtuState = {
    itemView: defaultOtuItemState,
    otuPort: defaultOtuPortState,
    otuPortMap: defaultOtuPortMapState
};

/**
 * An interface for defining Actions that can be dispatched to the store. This is similar to the "TabEvent" class in the RCI Grid. I acknowledge the annoyance
 * of having slightly different ways of doing things, but this avoids creating a single, massive, TabAction enum that needs to be shared across all modules.
 * 
 * Again, this will hopefully be decluttered once we move to a 3rd party store implementation (such as ngrx-store)
 */
export interface StoreAction {
    type: string
}

/**
 * An action that occurs only once when the store is first initialized.
 */
export class StoreInitAction implements StoreAction {
    public type = 'STORE_INIT_ACTION';
}

 /**
  * A simplified form of a redux store. (Based on the class in the pnm-application) This is primarily intended as a placeholder
  * until we can migrate to a more robust redux library like the ones used by the other client applications.
  */
 @Injectable()
 export class OtuStore implements OnDestroy {

    /**
     * The Observable stream of all actions this store handles.
     */
    private readonly actionStream: Subject<StoreAction>;
    private state: Observable<OtuState>;
    private ngUnsubscribe = new Subject();

    constructor() {
        this.actionStream = new Subject<StoreAction>();
        this.state = this.actionStream
            .pipe(
                scan((state, action) => reducers.reduce((currentState, r) => r(currentState, action), state), initialState)
                ,publishReplay(1)
                ,refCount()
            )

        this.state.subscribe();
        this.dispatch(new StoreInitAction());
    }

    /**
     * Returns an Observable that contains the piece of state selected in the provided function. Only emits
     * a new value when the selected piece of state is changed.
     */
    public select<U>(selector: (state: OtuState) => U): Observable<U> {
        return this.state.pipe(map(selector), distinctUntilChanged())
    }

    public dispatch(action: StoreAction) { console.log('dispatch', action); this.actionStream.next(action); }

    public actions(): Observable<StoreAction> { return this.actionStream.asObservable(); }

    public actionsOfType<U extends StoreAction>(actionType: string): Observable<U> {
        return this.actionStream.pipe(filter(a => a.type == actionType), map(a => <U>a))
    }

    ngOnDestroy() { this.ngUnsubscribe.next(); }
}