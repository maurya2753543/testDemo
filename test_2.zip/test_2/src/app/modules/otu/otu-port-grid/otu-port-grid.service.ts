/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Injectable } from "@angular/core";
import { OtuStore } from "../otu.state";
import { OtuHttpService } from "../otu.http.service";
import { REFRESH_OTU_PORT_LIST_ACTION } from "../reducers/otu-port.reducer";
import { repeatWhen, publishReplay, refCount} from 'rxjs/operators';
 @Injectable()
export class OtuPortGridService {
     public otuportfilterchangedata: any;
    constructor (private otuHttpService: OtuHttpService, private otuStore: OtuStore) {

    }

    /**
     * Contains the shared port list for the OTU Port Grid. This list is used for the main OTU Port Grid and both port mapping grids.
     * This list will update as a result of the RefreshOtuPortListAction.
     */
    public otuPortList = this.otuHttpService.getOtuPortList()
        .pipe(repeatWhen(() => this.otuStore.actionsOfType(REFRESH_OTU_PORT_LIST_ACTION)),
        publishReplay(1),
        refCount())

    public nodeList = this.otuHttpService.getNodeList()
        .pipe(publishReplay(1),
        refCount())
}