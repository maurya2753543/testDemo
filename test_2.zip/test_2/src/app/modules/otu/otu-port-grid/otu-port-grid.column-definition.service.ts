/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */
import { Injectable } from "@angular/core";
//import { LocalizationService } from "angular2localization";
import { EDIT_ICON } from "../../../constant/app.constants";
import { SharedService } from "../../../shared/shared.service";
import { DisabledFilter } from "../../shared/grid/disabled.filter";
import { OtuPortEditModel } from "../models/otu-port";
import { OtuStore } from "../otu.state";
import { OpenPortEditorAction } from "../reducers/otu-port.reducer";
import { TranslateService } from "@ngx-translate/core";

@Injectable()
export class OtuPortGridColumnDefinitionService {

    private _HEADER_FIELDS = [
        {
            field: 'name',
            name: 'OTU_PORT_NAME',
            options: {
                sort: 'asc',
                cellRenderer: (params) => {
                    if (params.data.portUrl)
                        return `<a class="tableUrlLink" href="${params.data.portUrl}" target="_blank">${params.value}</a>`;
                    else {
                        return params.value;
                    }
                }
            }
        },
        { field: 'portNumber', name: 'OTU_PORT_NUMBER' },
        { field: 'otuName', name: 'OTU_NAME' },
        { field: 'otuSerial', name: 'OTU_SERIAL_NUMBER' },
        {
            field: 'view',
            name: 'OTU_HEADER_VIEW',
            options: {
                pinned: this.sharedService.isPinned(),
                minWidth: 70,
                maxWidth: 120,
                width: 70,
                sortingOrder: [null],
                suppressSorting: true,
                cellStyle: () => ({'text-align': 'center'}),
                floatingFilterComponent: DisabledFilter.ChildFloatingFilter,
                suppressMenu: true,
                cellRenderer: ((param: any) => {
                    let gui = document.createElement('div');
                    gui.innerHTML = EDIT_ICON;
                    let eFilterText = gui.querySelector('i');
                    let rowData = param.data;
                    eFilterText.addEventListener("click", (() => {
                        this.editItem({
                            monitored: rowData.monitored,
                            portNumber: rowData.portNumber,
                            name: rowData.name,
                            elementId: rowData.elementId,
                            containerId: rowData.containerId
                        });
                    }));
                    gui.className = "ag-Grid-cursor";
                    return gui;
                })
            }
        }
    ];

    constructor(private sharedService: SharedService, private otuStore: OtuStore) { }

    public getColumnDef(ls: TranslateService): Object[] {
        console.log('OTU -> translated', ls.instant('ONLINE'))
        var fieldOptions = Object.keys(this._HEADER_FIELDS).map(k => {
            var field = this._HEADER_FIELDS[k];
            return Object.assign({
                headerName: ls.instant(field.name),
                headerTooltip: ls.instant(field.name),
                field: field.field,
                minWidth: 200,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
            }, field.options || {});
        });

        return [
            {
                headerName: '',
                maxWidth: 25,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { suppressAndOrCondition: true,
                    newRowsAction: 'keep' },
                suppressResize: true
            },
            ...fieldOptions
        ];
    }

    private editItem(param: OtuPortEditModel) {
        this.otuStore.dispatch(new OpenPortEditorAction(param));
    }
}