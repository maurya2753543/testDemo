import { map, publishReplay, refCount, takeUntil, exhaustMap, switchMap, catchError } from 'rxjs/operators';
import { Component, OnDestroy } from "@angular/core";
import { Observable, Subject, of, pipe } from "rxjs";
import { ContainerDataService } from "../../../container/container.data.service";
import { OtuHttpService } from "../../otu.http.service";
import { OtuStore, StoreAction } from "../../otu.state";
import { ClosePortEditorAction, RefreshOtuPortListAction, SavePortAction, SAVE_PORT_ACTION, SetOtuPortSliderStatusAction } from "../../reducers/otu-port.reducer";
import { OtuErrorAction, SliderStatus } from "../../reducers/otu.reducer";
//import { LocaleService, LocalizationService } from "angular2localization";
import { LocaleDataService } from "../../../../shared/locale.data.service";

@Component({
    selector: 'otu-port-item',
    templateUrl: './otu-port-item.component.html'
})
export class OtuPortItemComponent implements OnDestroy {
    public SliderStatus = SliderStatus;

    constructor(private otuStore: OtuStore,
        private otuService: OtuHttpService,
        private containerService: ContainerDataService,
        private localeDataService: LocaleDataService) {
        this.initializeEffects();
    }

    private ngUnsubscribe = new Subject();
    public otuPortState = this.otuStore.select(s => s.otuPort);
    public closeSlider = this.otuPortState.pipe(map(s => s.sliderStatus == SliderStatus.HIDDEN));
    public containerList = this.containerService.getAllContainers().pipe(publishReplay(1),refCount());
    public localizationService = this.localeDataService.isReady.pipe(map(() => this.localeDataService.getLocalizationService()));

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    initializeEffects() {
        // Send add/update request on save of single Port
        this.otuStore.actionsOfType<SavePortAction>(SAVE_PORT_ACTION)
            .pipe(takeUntil(this.ngUnsubscribe),
            map(a => this.otuService.updateOtuPort(a.port)),
            exhaustMap(
                request => request
                    .pipe(// close editor and refresh list on success
                        switchMap(r => of<StoreAction>(new ClosePortEditorAction(), new RefreshOtuPortListAction())),
                        // display error and re-enable editor on fail
                        catchError(err => of(new OtuErrorAction(err)).merge(of<StoreAction>(new SetOtuPortSliderStatusAction(SliderStatus.VISIBLE)))))
            ))
            .subscribe(action => this.otuStore.dispatch(action));
    }
}