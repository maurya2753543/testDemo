import { Component, Input, OnDestroy } from "@angular/core";
import {
    ClosePortEditorAction,
    EnableEditPortAction,
    RefreshOtuPortListAction,
    SAVE_PORT_ACTION,
    SavePortAction,
    SetOtuPortSliderStatusAction,
    OtuPortState
} from "../../reducers/otu-port.reducer";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ItemMode, OtuErrorAction, SliderStatus } from "../../reducers/otu.reducer";
import { OtuStore, StoreAction } from "../../otu.state";
import { Observable, Subject } from "rxjs";
import { OtuHttpService } from "../../otu.http.service";
import { ContainersSelect } from "../../../shared/dropdown/models/containersSelect.model";
import { TranslateService } from "@ngx-translate/core";
//import { LocalizationService } from "angular2localization";

@Component({
    selector: 'otu-port-item-view',
    templateUrl: './otu-port-item.view-component.html'
})
export class OtuPortItemViewComponent {
    private ItemMode = ItemMode;
    private SliderStatus = SliderStatus;
    public form: FormGroup;
    public drop: string;
    public check: boolean = false;
    public portName: string;
    public monit: boolean = false;
    private containerOptions: ContainersSelect;
    private noSelectionOption: { display: string, value: any } = null;
    private selectDropdown : boolean = false;

    private _otuPortState: OtuPortState;
    public get otuPortState() {
        return this._otuPortState;
    }

    @Input()
    public set otuPortState(otuPortState: OtuPortState) {
        this._otuPortState = otuPortState;
        this.setupForm();
        this.setDefaultSelectedContainer();
    }

    private _localizationService: TranslateService;
    public get localizationService() {
        return this._localizationService;
    }

    @Input()
    public set localizationService(ls: TranslateService) {
        this._localizationService = ls;

        if (ls != null) {
            this.noSelectionOption = {
                display: ls.instant('SELECT_CONTAINER'),
                value: null
            };
        }
    }

    private _containerList: any[];
    public get containerList() { return this._containerList; }

    @Input()
    public set containerList(containerList: any[]) {
        this._containerList = containerList;
        if (containerList != null) {
            this.containerOptions = new ContainersSelect(containerList);
            this.setDefaultSelectedContainer();
        }
    }

    private setDefaultSelectedContainer() {
        if (this.otuPortState == null || this.otuPortState.port == null || this.containerOptions == null) return;

        this.containerOptions.setValue(String(this.otuPortState.port.containerId));
    }

    constructor(
        private otuStore: OtuStore,
        private otuService: OtuHttpService,
        private fb: FormBuilder) {
    }

    // FORM HELPERS
    private setupForm() {
        if (this.otuPortState == null || this.otuPortState.port == null) {
            this.form = null;
            return;
        }

        let disabled = this.otuPortState.sliderStatus === SliderStatus.DISABLED;
        let port = this.otuPortState.port;
        this.form = this.fb.group({
            name: this.fb.control({ value: port.name, disabled: disabled }, Validators.required),
            monitored: this.fb.control({ value: port.monitored, disabled: disabled }),
            containerId: this.fb.control({ value: port.containerId, disabled: disabled }, Validators.required)
        });

    }

    get name() { return this.form.get('name'); }
    get monitored() { return this.form.get('monitored'); }
    get containerId() { return this.form.get('containerId'); }

    showValidationErrors(control: AbstractControl) {
        return control.invalid && (control.dirty || control.touched);
    }

    // EVENT HANDLERS

    closeEditor() {
        this.check = false;
        this.otuStore.dispatch(new ClosePortEditorAction()),
        this.drop= "";
        // this.monit=false;
        

    }

    enableEdit() {
        
        this.otuStore.dispatch(new EnableEditPortAction());
    }

    submitForm() {
        this.check = false;
        this.otuStore.dispatch(new SavePortAction(Object.assign({}, this.otuPortState.port, {
            name: this.name.value,
            monitored: this.monitored.value,
            containerId: parseInt(this.containerOptions.getValue(), 10),
        })));
        this.drop = ""


    }

    // OTHER HELPER METHODS

    public get selectedContainer() {
        if (this.containerList == null || this.otuPortState == null) return null;

        return this.containerList
            .filter(c => c.id == this.containerId.value)
            .map(c => c.containerPath)[0];
    }

    public getContainerSelection(dropdownItem) : void {
        console.log("check dropdown item", dropdownItem)
        if(dropdownItem.value === "null"){
            this.selectDropdown = true;
        }
        else{
            this.selectDropdown = false;
        }

        // this.selectedContainer.container = dropdownItem.innerText;
        // this.selectedContainer.containerId = dropdownItem.value;
        this.drop = dropdownItem.value;
        // this.containerId. = dropdownItem.value === 'null' ? true : Number(dropdownItem.value) < 1;
        // this.onRequiredFieldChange();
    }

    public monitValueCheckbox(monitcheck){
        this.monit = monitcheck;
        this.check = true
    }

}