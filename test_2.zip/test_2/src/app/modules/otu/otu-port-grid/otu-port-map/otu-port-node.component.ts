import { map, filter, take, mergeMap, catchError } from 'rxjs/operators';
import { Component } from "@angular/core";
import { GridApi, GridOptions } from "ag-grid";
import { BehaviorSubject, Observable, combineLatest, of} from "rxjs";
import { CommonStrings } from "../../../../constant/common.strings";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { ThemeService } from "../../../../shared/theme.service";
import {ShowAlert} from "../../../../utilities/showAlert";
import { OtuPortResponse } from "../../models/otu-port";
import { OtuHttpService } from "../../otu.http.service";
import { OtuStore, StoreAction } from "../../otu.state";
import { RefreshOtuPortListAction } from "../../reducers/otu-port.reducer";
import { SliderStatus, OtuErrorAction } from "../../reducers/otu.reducer";
import { OtuPortGridService } from "../otu-port-grid.service";
import { OtuPortMapColumnDefinitionService } from "./otu-port-map.column-definition.service";
import { ClosePortMapEditorAction, DisablePortMapEditorAction, SetPortMapSliderStatusAction } from "../../reducers/otu-port-map.reducer";

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
@Component({
    selector: 'otu-port-node',
    templateUrl: './otu-port-node.component.html'
})
export class OtuPortNodeComponent {
    public SliderStatus = SliderStatus;

    constructor(private otuStore: OtuStore,
        private otuPortGridService: OtuPortGridService,
        private localeDataService: LocaleDataService,
        public themeService: ThemeService,
        private columnDefinitionService: OtuPortMapColumnDefinitionService,
        private otuHttpService: OtuHttpService,
        private showAlert: ShowAlert) {

        var localizationService = this.localeDataService.isReady
            .pipe(filter(ready => ready),
            map(r => this.localeDataService.getLocalizationService()));

        this.nodeGridOptions = localizationService.pipe(map(ls => {
            return <GridOptions>{
                onSelectionChanged: s => this.hasSelectedNodes.next(s.api.getSelectedNodes().length > 0),
                suppressContextMenu: true,
                suppressMenu: true,
                rowSelection: 'multiple',
                enableSorting: true,
                enableFilter: true,
                floatingFilter: true,
                enableColResize: true,
                overlayLoadingTemplate: "<span class='ag-overlay-loading-center'>" + CommonStrings.APP_LOADING + "</span>",
                overlayNoRowsTemplate: "<span class='ag-overlay-loading-center'>" + CommonStrings.AG_GRID_NO_ROWS_TO_SHOW + "</span>",
                columnDefs: this.columnDefinitionService.getNodeColumnDef(ls)
            };
        }));
    }

    //#region Observable Properties

    public sliderStatus = this.otuStore.select(state => state.otuPortMap).pipe(map(p => p.sliderStatus));
    public nodeGridOptions: Observable<GridOptions>;
    private nodeGridApi = new BehaviorSubject<GridApi>(null);
    public hasSelectedNodes = new BehaviorSubject<boolean>(false);    
    private selectedPorts = this.otuStore.select(s => s.otuPortMap.selectedPorts);
    public hasSelectedPorts = this.selectedPorts.pipe(map(p => p != null && p.length > 0));
    public hasSelectedPortWithContainer = this.selectedPorts.pipe(map(ports => ports.some(p => p.containerId != null)));

    public otuPorts = this.otuPortGridService.otuPortList;
    public nodes = combineLatest(
        this.otuPortGridService.nodeList,
        this.otuPorts.pipe(map(p =>this.buildPortsByNodeMap(p)))
    ).pipe(map(args => {
        var portsByNode = args[1];
        return args[0].map(node => {
            if (!portsByNode[node.nodeId]) return node;

            return Object.assign({}, node, {
                otuPortNames: portsByNode[node.nodeId].map(p => p.name),
                otuPorts: portsByNode[node.nodeId]
            });
        });
    }));
    //#endregion

    //#region EVENTS

    addAll() {
        combineLatest(this.selectedPorts, this.nodeGridApi)
            .pipe(filter(args => args[0] != null && args[1] != null),
            take(1),
            map(args => {
                var selectedPorts = args[0];
                var nodeGrid = args[1];

                var nodeIds = nodeGrid.getSelectedNodes().map(n => n.data.nodeId);
                return selectedPorts.map(p => {
                    var port = Object.assign({}, p);
                    port.nodeIds = port.nodeIds || [];
                    nodeIds.forEach(n => {
                        if (port.nodeIds.indexOf(n) < 0) port.nodeIds.push(n);
                    });

                    return port;
                });
            }))
            .subscribe(ports => this.savePortNodeMappings(ports));
    }

    removeNodesFromPorts() {
        this.selectedPorts
            .pipe(filter(ports => ports != null),
            take(1),
            map(ports => {
                return ports.map(p => {
                    return Object.assign({}, p, { nodeIds: [] });
                });
            }))
            .subscribe(ports => this.savePortNodeMappings(ports));
    }

    closeEditor() {
        this.otuStore.dispatch(new ClosePortMapEditorAction())
    }

    onNodeGridResize(event) {
        if (event.api) {
            this.hasSelectedNodes.next(event.api.getSelectedNodes().length > 0);
            this.nodeGridApi.next(event.api);
            event.api.sizeColumnsToFit();
        }
    }  

    //#endregion

    //#region HELPER METHODS

    private buildPortsByNodeMap(p: OtuPortResponse[]): {} {
        return p.reduce((portsByNode, port) => {
            port.nodeIds.forEach(nodeId => {
                if (!portsByNode[nodeId])
                    portsByNode[nodeId] = [];
                portsByNode[nodeId].push(port);
            });
            return portsByNode;
        }, {});
    }

    private savePortNodeMappings(ports: OtuPortResponse[]) {
        this.otuStore.dispatch(new DisablePortMapEditorAction());
        var enableAction = new SetPortMapSliderStatusAction(SliderStatus.VISIBLE);

        let mappings = ports.map(p => ({ portId: p.elementId, nodeIds: p.nodeIds }));
        this.otuHttpService.saveOtuPortNodeMapping(mappings)
            .pipe(mergeMap(r => of<StoreAction>(new RefreshOtuPortListAction(), enableAction)),
            catchError(err => of<StoreAction>(new OtuErrorAction(err), enableAction)))
            .subscribe(r => this.otuStore.dispatch(r));
    }

    //#endregion
}