import { map , filter, withLatestFrom, takeUntil, mergeMap} from 'rxjs/operators';
/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

import { Component, OnDestroy } from "@angular/core";
import { GridApi, GridOptions, SelectionChangedEvent, GridReadyEvent } from "ag-grid";
import { BehaviorSubject, Observable, Subject, of } from "rxjs";
import { CommonStrings } from "../../../../constant/common.strings";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { ThemeService } from "../../../../shared/theme.service";
import { OtuPortResponse } from "../../models/otu-port";
import { OtuStore } from "../../otu.state";
import { SliderStatus } from "../../reducers/otu.reducer";
import { OtuPortGridService } from "../otu-port-grid.service";
import { OtuPortMapColumnDefinitionService } from "./otu-port-map.column-definition.service";
import { OpenPortMapEditorAction, SetSelectedPortMapPortsAction } from "../../reducers/otu-port-map.reducer";
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'otu-port-map',
    templateUrl: './otu-port-map.component.html'
})
export class OtuPortMapComponent implements OnDestroy {
    public SliderStatus = SliderStatus;
    
    public readonly NODE_TAB = 'NODE';
    public readonly CONTAINER_TAB = 'CONTAINER';
    selectedTab = new BehaviorSubject<string>(this.NODE_TAB);

    constructor(private otuStore: OtuStore,
        private otuPortGridService: OtuPortGridService,
        private localeDataService: LocaleDataService,
        private columnDefinitionService: OtuPortMapColumnDefinitionService,
        public themeService: ThemeService) {
        this.initializeEffects();
        
        var localizationService = localizationService = this.localeDataService.isReady
            .pipe(filter(ready => ready),
            map(ready => this.localeDataService.getLocalizationService()));

        this.portGridOptions = localizationService.pipe(map((ls: TranslateService) => {
            return <GridOptions>{
                onSelectionChanged: evt => this.selectionChanged(evt),
                suppressContextMenu: true,
                rowSelection: 'multiple',
                enableSorting: true,
                enableFilter: true,
                floatingFilter: true,
                enableColResize: true,
                overlayLoadingTemplate: "<span class='ag-overlay-loading-center'>" + CommonStrings.APP_LOADING + "</span>",
                overlayNoRowsTemplate: "<span class='ag-overlay-loading-center'>" + CommonStrings.AG_GRID_NO_ROWS_TO_SHOW + "</span>",
                columnDefs: this.columnDefinitionService.getPortColumnDef(ls)
            };
        }))
    }

    // #region Observable Properties
    
    private ngUnsubscribe = new Subject();
    private portGridOptions: Observable<GridOptions>;
    public portMapState = this.otuStore.select(state => state.otuPortMap);
    public otuPorts = this.otuPortGridService.otuPortList;
    public sliderStatus = this.portMapState.pipe(map(p => p.sliderStatus));
    public closeSlider = this.sliderStatus.pipe(map(s => s == SliderStatus.HIDDEN));
    private portGridApi = new BehaviorSubject<GridApi>(null);
    private hasSelectedPorts = new BehaviorSubject<boolean>(false);
    
    // #endregion

    // #region Event Handlers

    public selectTab(tabName: string) {
        // Until we can re-use the tables in both the OtuPortNodeMapComponent and OtuPortContainerMapComponent
        // (which might be possible with a sub-component or ng-template in Angular 4+), we will clear the selection
        // rather than trying to copy the state of the selection, filter, and sort between tables when switching tabs.
        this.otuStore.dispatch(new SetSelectedPortMapPortsAction([]));
        this.selectedTab.next(tabName);
    }

    public isTabSelected(tabName: string): Observable<boolean> {
        return this.selectedTab.pipe(map(t => t === tabName));
    }

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    onPortGridResize(event) {
        if (event.api) {
            this.hasSelectedPorts.next(event.api.getSelectedNodes().length > 0);
            this.portGridApi.next(event.api);
            event.api.sizeColumnsToFit();
        }
    }
    
    public selectionChanged (evt: SelectionChangedEvent) {
        let ports = evt.api.getSelectedNodes().map(n => <OtuPortResponse>n.data);
        this.otuStore.dispatch(new SetSelectedPortMapPortsAction(ports));
    }

    // #endregion

    private initializeEffects() {
        // When the Otu Port List updates and the editor is disabled, it means that the RefreshOtuPortListAction has completed after making a
        // change to port mappings, so we re-enable the editor and clear the selection.
        this.otuPorts.pipe(withLatestFrom(this.otuStore.select(s => s.otuPortMap.sliderStatus)),
            filter(args => args[1] === SliderStatus.DISABLED),
            takeUntil(this.ngUnsubscribe),
            mergeMap(() => of(new OpenPortMapEditorAction(), new SetSelectedPortMapPortsAction([]))))
            .subscribe(action => this.otuStore.dispatch(action));
    }
}