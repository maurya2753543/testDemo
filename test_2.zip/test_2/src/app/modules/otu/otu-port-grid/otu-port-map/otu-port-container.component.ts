import { map, publishReplay, refCount, filter, takeUntil, exhaustMap, catchError, take, switchMap } from 'rxjs/operators';
/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

import { Component, OnDestroy } from "@angular/core";
import { GridOptions, GridReadyEvent, SelectionChangedEvent } from "ag-grid";
import { BehaviorSubject, Observable, Subject, of, combineLatest } from "rxjs";
import { LocaleDataService } from "../../../../shared/locale.data.service";
import { ThemeService } from "../../../../shared/theme.service";
import { ContainerDataService } from "../../../container/container.data.service";
import { OtuPortEditModel, OtuPortResponse } from "../../models/otu-port";
import { OtuHttpService } from "../../otu.http.service";
import { OtuStore, StoreAction } from "../../otu.state";
import { ClosePortMapEditorAction, SetPortMapSliderStatusAction } from "../../reducers/otu-port-map.reducer";
import { RefreshOtuPortListAction, SaveMultiplePortsAction, SAVE_MULTIPLE_PORTS_ACTION } from "../../reducers/otu-port.reducer";
import { OtuErrorAction, SliderStatus } from "../../reducers/otu.reducer";
import { OtuPortMapColumnDefinitionService } from "./otu-port-map.column-definition.service";
@Component({
    selector: 'otu-port-container',
    templateUrl: 'otu-port-container.component.html'
})
export class OtuPortContainerComponent implements OnDestroy {
    public SliderStatus = SliderStatus;

    constructor(private otuStore: OtuStore,
        private otuService: OtuHttpService,
        private containerDataService: ContainerDataService,
        public themeService: ThemeService,
        private localeDataService: LocaleDataService,
        private columnDefinitionService: OtuPortMapColumnDefinitionService) {

        this.initializeEffects();

        this.containerGridOptions = this.localeDataService.isReady
            .pipe(filter(r => r),
            map(r => this.localeDataService.getLocalizationService()),
            map(ls => <GridOptions>{
                onSelectionChanged: evt => this.onContainerSelect(evt),
                onGridReady: evt => this.onGridReady(evt),
                columnDefs: this.columnDefinitionService.getContainerColumnDef(ls),
                enableFilter: true,
                enableSorting: true,
                treeData: true,
                animateRows: true,
                getDataPath: data => data.path,
                getRowNodeId: data => data.id,
                suppressRowClickSelection: true,
                suppressContextMenu: true,
                autoGroupColumnDef: {
                    headerName: ls.instant('CONTAINERS'),
                    filter: 'text',
                    minWidth: 200,
                    valueGetter: params => params.data && params.data.name,
                    valueFormatter: (params) => params.data && params.data.name,
                    cellRendererParams: {
                        suppressCount: true,
                        checkbox: true,
                    }
                }
            }))
    }

    private initializeEffects() {        
        // Send add/update request on save of multiple ports, and re-enable slider on request completion
        this.otuStore.actionsOfType<SaveMultiplePortsAction>(SAVE_MULTIPLE_PORTS_ACTION)
        .pipe(takeUntil(this.ngUnsubscribe),
        map(a => this.otuService.updateMultipleOtuPorts(a.ports)),
        exhaustMap(
            request => request
                .pipe(// close editor and refresh list on success
                    map(r => new RefreshOtuPortListAction()),
                    // display error and re-enable editor on fail
                    catchError(err => of(new OtuErrorAction(err)).merge(of<StoreAction>(new SetPortMapSliderStatusAction(SliderStatus.VISIBLE)))))
        ))
        .subscribe(action => this.otuStore.dispatch(action));
    }

    // #region Observable Properties

    private ngUnsubscribe = new Subject();
    public sliderStatus = this.otuStore.select(state => state.otuPortMap).pipe(map(p => p.sliderStatus));
    public containers = this.containerDataService.getContainerList()
    .pipe(
        map(containerTree => this.flattenContainerTree(containerTree)),
        publishReplay(1),
        refCount()
    )
       
    public containerGridOptions: Observable<GridOptions>;
    private selectedContainer = new BehaviorSubject<any>(null);
    
    public hasSelectedContainer = this.selectedContainer.pipe(map(p => {
        if(p && p.selected){
            return true
        }
        p && p.selected}
        // p && p.sliderStatus}
        ));
    private selectedPorts = this.otuStore.select(s => s.otuPortMap.selectedPorts);
    public hasSelectedPorts = this.selectedPorts.pipe(map(p => p != null && p.length > 0));

    // #endregion

    // #region Event Handlers

    assignContainerToPorts() {
        combineLatest(this.selectedPorts, this.selectedContainer)
            .pipe(take(1),
            map(args => this.getPortsToSaveWithContainer(args[0], args[1].id)))
            .subscribe(ports => {
                this.otuStore.dispatch(new SetPortMapSliderStatusAction(SliderStatus.DISABLED));
                this.otuStore.dispatch(new SaveMultiplePortsAction(ports));
            });
    }

    removeContainerFromPorts() {
        this.selectedPorts
            .pipe(take(1),
            map(ports => this.getPortsToSaveWithContainer(ports, null)))
            .subscribe(ports => {
                this.otuStore.dispatch(new SetPortMapSliderStatusAction(SliderStatus.DISABLED));
                this.otuStore.dispatch(new SaveMultiplePortsAction(ports));
            });
    }

    private getPortsToSaveWithContainer(ports: OtuPortResponse[], containerId: number): OtuPortEditModel[] {
        return ports.map(p => ({
            portNumber: p.portNumber,
            elementId: p.elementId,
            containerId: containerId,
            monitored: p.monitored,
            name: p.name
        }));
    }

    closeEditor() {
        this.otuStore.dispatch(new ClosePortMapEditorAction())
    }

    onContainerSelect(event: SelectionChangedEvent) {
        this.selectedContainer.next(event.api.getSelectedNodes()[0]);
    }

    onGridReady(event: GridReadyEvent) {
        event.api.sizeColumnsToFit();
    }

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    // #endregion

    // #region Tree Helpers

    private flattenContainerTree(containerTree): any[] {
        if (containerTree == null) return [];

        var containerSubtreeStack = [{ container: containerTree, parent: null }];
        var result = [];
        while (containerSubtreeStack.length > 0) {
            var containerAndParent = containerSubtreeStack.pop();
            var containerModel = this.buildContainerModel(containerAndParent.container, containerAndParent.parent);
            result.push(containerModel);
            this.getChildren(containerModel)
                .reverse()
                .forEach(c => containerSubtreeStack.push({
                    container: c,
                    parent: containerModel
                }));
        }

        return result;
    }

    private buildContainerModel(serverContainer, parent): any {
        var hasChildren = this.hasChildren(serverContainer);
        // This is a workaround for the way ag-grid handles the display value for nodes of a tree - I could not figure out an alternative workaround,
        // but there could be one that exists. Ideally, we would use "id" to build the path of each container in the tree since container name is non-unique.
        // This is fine, because ag-grid's "formatValue" allows us to use an alternative display value. However, "formatValue" seems to be ignored for
        // leaf nodes, and the last value in the path is used for display. So here, we use the id for building the path, unless the container is a leaf
        // node, in which case we use the display name.
        var pathId = hasChildren ? serverContainer.id : serverContainer.name;
        return Object.assign({
            path: parent == null ? [pathId] : parent.path.concat(pathId),
            isElementGroup: serverContainer.containerChildType === "Element" ? true : false,
        }, serverContainer);
    }

    private getChildren(containerModel): any[] {
        return (containerModel.isElementGroup ?
            containerModel.childrenElements :
            containerModel.childrenContainers) || [];
    }

    private hasChildren(serverContainer) {
        return (serverContainer.childrenElements || serverContainer.childrenContainers || []).length > 0;
    }

    // #endregion
}