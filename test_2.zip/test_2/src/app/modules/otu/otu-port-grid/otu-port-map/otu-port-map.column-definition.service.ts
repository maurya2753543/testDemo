import { TranslateService } from '@ngx-translate/core';
import { Injectable } from "@angular/core";
//import { LocalizationService } from "angular2localization";
import { ColDef } from "ag-grid/main";
import { SharedService } from "../../../../shared/shared.service";

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */

@Injectable()
export class OtuPortMapColumnDefinitionService {

    constructor(private sharedService: SharedService){}

    private NODE_HEADER_FIELDS = [
        {
            field: "name",
            name: "NODE_TAB_COLUMN_NODE",
            options: {
                pinned: true,
                sort: 'asc'
            }
        },
        {
            field: "otuPorts",
            name: 'OTU_PORTS',
            options: <ColDef>{
                valueGetter: params => {
                    if (!params.data.otuPorts) return '';
                    return params.data.otuPortNames.join(', ');
                }
            }
        },
        { field: "billingNode", name: "NODE_TAB_COLUMN_BILLING_NODE" },
        { field: "cmts", name: "NODE_TAB_COLUMN_CMTS" },
        { field: "cmtsNode", name: "NODE_TAB_COLUMN_CMTS_NODE" },
        { field: "rphyMac", name: "NODE_TAB_COLUMN_DAA_DEVICE" },
        { field: "cmtsUsPortName", name: "NODE_TAB_COLUMN_UPSTREAM_PORT" },
        { field: "macDomain", name: "NODE_TAB_COLUMN_MAC_DOMAIN" },
        { field: "serviceGroup", name: "NODE_TAB_COLUMN_SERVICE_GROUP" },
        { field: "hcu", name: "NODE_TAB_COLUMN_HCU" },
        { field: "rpmPort", name: "NODE_TAB_COLUMN_PORT" },
    ];

    public getNodeColumnDef(ls: TranslateService): ColDef[] {
        return [
            {
                headerName: '',
                pinned: true,
                maxWidth: 25,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { suppressAndOrCondition: true },
                suppressResize: true,
                headerCheckboxSelectionFilteredOnly: true
            },
            ...this.buildColumnOptions(ls, this.NODE_HEADER_FIELDS)
        ];
    }

    private PORT_HEADER_FIELDS = [
        {
            field: 'name',
            name: 'OTU_PORT_NAME',
            options: { sort: 'asc', pinned: true }
        },
        { field: 'portNumber', name: 'OTU_PORT_NUMBER' },
        { field: 'containerName', name: 'CONTAINER' },
        { field: 'otuName', name: 'OTU_NAME' },
        { field: 'otuSerial', name: 'OTU_SERIAL_NUMBER' }
    ];

    public getPortColumnDef(ls: TranslateService): ColDef[] {
        return [
            {
                headerName: '',
                pinned: true,
                maxWidth: 25,
                checkboxSelection: true,
                sortingOrder: [null],
                field: '',
                headerCheckboxSelection: true,
                suppressFilter: true,
                suppressSizeToFit: true,
                suppressMenu: true,
                filterParams: { suppressAndOrCondition: true },
                suppressResize: true,
                headerCheckboxSelectionFilteredOnly: true
            },
            ...this.buildColumnOptions(ls, this.PORT_HEADER_FIELDS)
        ];
    }

    private CONTAINER_HEADER_FIELDS = [
        { 
            field: 'childrenCount',
            name: 'CONTAINER_CHILDREN_COUNT',
            options: <ColDef>{
                pinned: this.sharedService.isPinned(),
                field: "",
                valueGetter: (param) => {
                    var length = 0;
                    if(param.data.childrenContainers) length = param.data.childrenContainers.length;
                    else if (param.data.childrenElements) length = param.data.childrenElements.length;

                    return length === 0 ? '' : String(length);
                }
            }
        }
    ];

    public getContainerColumnDef(ls: TranslateService): ColDef[] {
        return this.buildColumnOptions(ls, this.CONTAINER_HEADER_FIELDS);
    }

    private buildColumnOptions(ls: TranslateService, fieldProperties: { field: string, name: string, options?: ColDef }[]): ColDef[] {
        return fieldProperties.map(field => {
            return Object.assign({
                headerName: ls.instant(field.name),
                headerTooltip: ls.instant(field.name),
                field: field.field,
                minWidth: 150,
                filter: 'text',
                floatingFilterComponentParams: { suppressFilterButton: true },
                filterParams: { suppressAndOrCondition: true },
            }, field.options || {});
        });
    }
}