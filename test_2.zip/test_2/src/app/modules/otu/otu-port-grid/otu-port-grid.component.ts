import { map, filter, combineLatest, merge } from 'rxjs/operators';
/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

 import { Component } from "@angular/core";
//import { LocalizationService } from "angular2localization";
import { Observable, Subject } from "rxjs";
import { GRID_COMP_KEY_MULTI, GRID_COMP_KEY_SINGLE } from "../../../constant/app.constants";
import { LocaleDataService } from "../../../shared/locale.data.service";
import { SharedService } from "../../../shared/shared.service";
import { OtuHttpService } from "../otu.http.service";
import { OtuStore } from "../otu.state";
import { RefreshOtuPortListAction } from "../reducers/otu-port.reducer";
import { Grid } from './../../../shared/ag-grid.options';
import { OtuPortGridColumnDefinitionService } from "./otu-port-grid.column-definition.service";
import { OtuPortGridService } from "./otu-port-grid.service";
import { OpenPortMapEditorAction } from "../reducers/otu-port-map.reducer";
const MAP_OTU_PORT = 'MAP_OTU_PORT'; // This will probably need to be associated with the store - leaving here temporarily

@Component({
    selector: 'otu-port-grid-component',
    templateUrl: './otu-port-grid.component.html'
})
export class OtuPortGridComponent {
    private gridModelUpdated = new Subject();
    public exportFileName: any;
    private gridApi: any;

    //#region Constructor

    constructor(private localeDataService: LocaleDataService,
        private otuStore: OtuStore,
        private columnDefinitionService: OtuPortGridColumnDefinitionService,
        private otuHttpService: OtuHttpService,
        private otuPortGridService: OtuPortGridService) {
        
        this.localizationService = this.localeDataService.isReady
            .pipe(filter(ready => ready),
            map(r => this.localeDataService.getLocalizationService()));
    }

    ngOnInit(){
        this.gridOptions = this.localizationService.pipe(
            map(ls => {
                let result = new Grid();
                result.setColumnDefs(this.columnDefinitionService.getColumnDef(ls));
                return result;
            })
        );
        this.setupButtons();
        this.setupCounts();
    }
    //#endregion

    //#region Observable properties

    public rowData = this.otuPortGridService.otuPortList;
    private localizationService: Observable<any>;
    public gridOptions: Observable<Grid>;
    public buttonKeys: Observable<Object[]>;
    public eventKeys: Observable<Object[]>;
    public showAllLabel: Observable<string>;
    public showAllLabelMob: Observable<string>;
    public showRefreshButton = this.localeDataService.isReady;

    //#endregion

    //#region Setup Helpers

    private setupCounts() {
        let totalCount = this.rowData.pipe(map(r => r.length));
        let rowCount = this.gridModelUpdated // when the model is updated
            .pipe(combineLatest(this.gridOptions), // get latest grid options
            filter(result => result[1].api != null), // when the grid api is not null
            map(result => result[1].api.getDisplayedRowCount()), // retrieve the displayed row count
            merge(totalCount)); // or take the total count of data

        let counts = this.localizationService.pipe(combineLatest(totalCount, rowCount));
        this.showAllLabel = counts
            .pipe(map(result => {
                let ls = result[0];
                let totalCount = result[1];
                let rowCount = result[2];
                return `${ls.instant('TABLE_LIST_SHOWING')} ${rowCount} ${ls.instant('TABLE_LIST_SHOWING_OF')} ${totalCount} ${ls.instant('TABLE_LIST_ROWS')}`;
            }));

        this.showAllLabelMob = counts.pipe(map(count => `${count[2]}/${count[1]}`));
    }


    private setupButtons() {
        this.buttonKeys = this.localizationService.pipe(map(ls => [{ name: ls.instant('MAP_OTU_PORT'), action: MAP_OTU_PORT }]));
        this.eventKeys = this.localizationService
            .pipe(
                map(ls => [
                    { name: ls.instant('TABLE_LIST_EXPORT_SELECTED'), status: GRID_COMP_KEY_SINGLE },
                    { name: ls.instant('TABLE_LIST_EXPORT_ALL'), status: GRID_COMP_KEY_MULTI }
                ])
            )
    }
    
    //#endregion

    //#region Event Handlers

    public gridModelUpdatedEmitter(params:any) {
        this.gridModelUpdated.next();
    }
    public gridReady(param): any{
        this.gridApi = param.api;
        if(this.gridApi && (this.otuPortGridService.otuportfilterchangedata || this.otuHttpService.otugridmodel )){
            this.gridApi.setFilterModel(this.otuPortGridService.otuportfilterchangedata);            
            console.log("filter executed",this.otuPortGridService.otuportfilterchangedata);
            if(this.otuHttpService.otugridmodel || this.otuPortGridService.otuportfilterchangedata ){
            const countryFilterComponent3 = this.gridApi.getFilterInstance("otuName");
            countryFilterComponent3.setModel(this.otuHttpService.otugridmodel);
        }
    }

    }
    public notifyFilterChangeOTUPORT(event): void{
        const countryFilterComponent = this.gridApi.getFilterInstance('otuName');
        const model = countryFilterComponent.getModel();
        this.otuHttpService.otugridmodel = model;
        this.otuPortGridService.otuportfilterchangedata = this.gridApi.getFilterModel();
        console.log("filterchange data",this.otuPortGridService.otuportfilterchangedata);
    }
    public handleRefreshGrid(params:any) {
        this.otuStore.dispatch(new RefreshOtuPortListAction());
    }

    public handleButtonEvent(context) {
        switch (context.event.action) {
            case MAP_OTU_PORT: 
                this.otuStore.dispatch(new OpenPortMapEditorAction())
                break;
        }
    }
    //#endregion
}