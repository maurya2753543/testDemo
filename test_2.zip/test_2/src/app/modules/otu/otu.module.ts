/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */
import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgGridModule } from "ag-grid-angular";
import { TranslateService, TranslateModule,TranslateLoader } from '@ngx-translate/core';
//import { Locale, LocaleModule, LocalizationModule } from "angular2localization";
import { LocaleDataService } from "../../shared/locale.data.service";
import { ContainerHttpService } from "../container/container-http.service";
import { ContainerService } from "../container/container-tab/container.service";
import { ContainerUrlService } from "../container/container-url.service";
import { ContainerDataService } from "../container/container.data.service";
import { SharedModule } from "../shared/shared.module";
import { OtuGridColumnDefinitionService } from './otu-grid/otu-grid.column-definition.service';
import { OtuGridComponent } from './otu-grid/otu-grid.component';
import { OtuGridService } from './otu-grid/otu-grid.service';
import { OtuItemComponent } from './otu-grid/otu-item/otu-item.component';
import { OtuItemViewComponent } from './otu-grid/otu-item/otu-item.view-component';
import { OtuPortGridColumnDefinitionService } from './otu-port-grid/otu-port-grid.column-definition.service';
import { OtuPortGridComponent } from './otu-port-grid/otu-port-grid.component';
import { OtuPortGridService } from './otu-port-grid/otu-port-grid.service';
import { OtuPortItemComponent } from "./otu-port-grid/otu-port-item/otu-port-item.component";
import { OtuPortItemViewComponent } from "./otu-port-grid/otu-port-item/otu-port-item.view-component";
import { OtuPortContainerComponent } from './otu-port-grid/otu-port-map/otu-port-container.component';
import { OtuPortMapColumnDefinitionService } from './otu-port-grid/otu-port-map/otu-port-map.column-definition.service';
import { OtuPortMapComponent } from './otu-port-grid/otu-port-map/otu-port-map.component';
import { OtuPortNodeComponent } from './otu-port-grid/otu-port-map/otu-port-node.component';
import { OtuComponent } from "./otu.component";
import { OtuErrorService } from './otu.error.service';
import { OtuHttpService } from './otu.http.service';
import { OtuRoutes } from "./otu.route";
import { OtuStore } from './otu.state';

import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as AppConstants from './../../constant/app.constants';

export function HttpLoaderFactory(http: HttpClient) {
    let lan = navigator.language.split('-')[0];
    const langs = AppConstants.LANGUAGE_LIST_SHORT;
    const isLang = langs && langs.find(lang => lang === lan);
    const lang = (isLang) ? isLang : 'en';
    return new TranslateHttpLoader(http, `./././assets/lang/${lang}/otu-locale-`, ".json");
}

@NgModule({
    imports: [
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient],
        }, isolate: false }),
        AgGridModule,
        SharedModule,
        OtuRoutes,
        // LocaleModule.forRoot(),
        // LocalizationModule.forRoot(),
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        
    ],
    declarations: [
        OtuComponent,
        OtuGridComponent,
        OtuPortGridComponent,
        OtuItemComponent,
        OtuItemViewComponent,
        OtuPortMapComponent,
        OtuPortNodeComponent,
        OtuPortContainerComponent,
        OtuPortItemComponent,
        OtuPortItemViewComponent
    ],
    entryComponents: [
        OtuComponent,
        OtuGridComponent
    ],
    providers: [
        LocaleDataService,
        OtuHttpService,
        OtuStore,
        OtuGridService,
        OtuGridColumnDefinitionService,
        OtuErrorService,
        OtuPortGridColumnDefinitionService,
        OtuPortGridService,
        OtuPortMapColumnDefinitionService,
        ContainerService,
        ContainerUrlService,
        ContainerDataService,
        ContainerHttpService,
        TranslateService
    ]
})
export class OtuModule  {

}