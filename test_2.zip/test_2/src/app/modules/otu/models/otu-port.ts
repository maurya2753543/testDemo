/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */
export class OtuPortResponse {
    public elementId: number;
    public containerId: number;
    public name: string;
    public portNumber: number;
    public monitored: boolean;
    public otuId: number;
    public otuUrl: string;
    public otuName: string;
    public otuSerial: string;
    public nodeIds: number[];
}

export class OtuPortEditModel {
    public elementId: number;
    public containerId: number;
    public name: string;
    public portNumber: number;
    public monitored: boolean;
}