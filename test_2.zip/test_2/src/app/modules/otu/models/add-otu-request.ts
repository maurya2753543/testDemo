/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */
export class AddOtuRequest {
    public url: string;
    public proxyHostname: string;
    public username: string;
    public password: string;
    public name: string;
    public location: string;
    public notes: string;
}