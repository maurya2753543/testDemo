import { map } from 'rxjs/operators';
/*
 * Copyright (c) 2019 VIAVI Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * VIAVI Solutions Corporation is strictly prohibited.
 *
 */

import { Injectable } from "@angular/core";
import {HttpService} from "../../shared/http.service";
import { Observable } from "rxjs";
import { SharedService } from "../../shared/shared.service";
import { PATHTRAK_PATH } from "../../constant/app.constants";
import { OtuResponse } from "./models/otu-response";
import { AddOtuRequest } from "./models/add-otu-request";
import { HttpResponse } from "@angular/common/http";
import {OtuPortEditModel, OtuPortResponse} from "./models/otu-port";
import { TranslateService } from '@ngx-translate/core';

/*
 * Copyright (c) 2019 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
@Injectable()
 export class OtuHttpService {
    private otuApiUrl: string;
    private otuPortApiUrl: string;
    private selectedTab: string;
    public otugridmodel: any;
    //public otugridmodel2: any;
    constructor(private httpService: HttpService, private translate: TranslateService,
        private sharedService: SharedService) {
            this.otuApiUrl = `${this.sharedService.getHost()}${PATHTRAK_PATH}otu`;
            this.otuPortApiUrl = `${this.sharedService.getHost()}${PATHTRAK_PATH}otuPort`;
        }
    
    //#region OTU

    /**
     * Gets the list of OTUs from the XPERTrak server.
     */
    public getOtuList(): Observable<OtuResponse[]> {
        return this.httpService.GET(`${this.otuApiUrl}`).pipe(
            map(v => {
                let localizationService = this.translate;
                let otuData = v;
                for(let i = 0; i < otuData.length; i++){
                    otuData[i].status = otuData[i].offline ? localizationService.instant('OFFLINE') : localizationService.instant('ONLINE')
                }
                return <OtuResponse[]>otuData;
            })
        );
    }

    /**
     * Retrieves a single OTU from the XPERTrak server.
     * @param id The id of the OTU to retrieve.
     */
    public getOtu(id: number): Observable<OtuResponse> {
        return this.httpService.GET(`${this.otuApiUrl}/${id}`).pipe(
            map(v => <OtuResponse>v)
        );
    }

    /**
     * Updates an OTU that already exists on the XPERTrak server.
     * @param otu The OTU to update
     */
    public updateOtu(otu: OtuResponse): Observable<OtuResponse> {
        return this.httpService.PUT(`${this.otuApiUrl}/${otu.elementId}`, otu).pipe(map(v => <OtuResponse>v));
    }

    /**
     * Adds a new OTU to the XPERTrak server and returns the newly added OTU with information about the OTU, itself.
     * @param otu The OTU to add
     */
    public addOtu(otu: AddOtuRequest): Observable<OtuResponse> {
        return this.httpService.POST(`${this.otuApiUrl}`, otu).pipe(map(v => <OtuResponse>v));
    }

    /**
     * Deletes an OTU with the specified id from the XPERTrak server.
     * @param id The id or elementId of the OTU to delete.
     */
    public deleteOtu(id: number): Observable<any> {
        return this.httpService.DELETE(`${this.otuApiUrl}/${id}`);
    }

    /**
     * Syncs all OTUs in the XPERTrak system. This will update the system clock and ports for each OTU. Does not have a response body.
     */
    public syncAll(): Observable<any> {
        return this.httpService.POST(`${this.otuApiUrl}/syncAll`, null);
    }

    /**
     * Syncs only the specified OTUs. This will update the system clock and ports for each OTU. Does not have a response body.
     * @param otuIds The ids of the OTUs to sync.
     */
    public sync(otuIds: number[]): Observable<any> {
        return this.httpService.POST(`${this.otuApiUrl}/sync`, otuIds);
    }

    /**
     * Tests the connection of the specified OTU. An HTTP error will be returned if the connection fails. Does not have a response body.
     * @param otuId The ID of the OTU to test.
     */
    public testConnection(otuId: number): Observable<any> {
        return this.httpService.POST(`${this.otuApiUrl}/ping/${otuId}`, null);
    }

    /**
     * Tests that the provided url, username, and password can be used for communicating with an OTU. Returns information about the
     * OTU received from the connection to the device.
     * @param url The URL of the OTU
     * @param username The username used for authenticating requests to the OTU
     * @param password The password used for authenticating requests to the OTU
     */
    public testConnectionInfo(url: string, username: string, password: string): Observable<OtuResponse> {
        return this.httpService.POST(`${this.otuApiUrl}/testConnection`, {
            url: url,
            username: username,
            password: password
        }).pipe(
            map(v => <OtuResponse>v)
        );
    }

    /**
     * Synchronizes the system clocks of the OTUs specified. Does not have a response body.
     * @param otuIds The IDs of the OTUs to synchronize.
     */
    public syncClock(otuIds: number[]): Observable<any> {
        return this.httpService.POST(`${this.otuApiUrl}/syncClock`, otuIds);
    }

    //#endregion OTU

    //#region OTU PORT

    /**
     * Returns all the OTU Ports visible to the user.
     */
    public getOtuPortList(): Observable<OtuPortResponse[]> {
        return this.httpService.GET(`${this.otuPortApiUrl}`).pipe(map(v => <OtuPortResponse[]>v));
    }

    public updateOtuPort(port: OtuPortEditModel): Observable<OtuPortEditModel> {
        return this.httpService.PUT(`${this.otuPortApiUrl}/${port.elementId}`, port).pipe(map(v => v));
    }

    public updateMultipleOtuPorts(ports: OtuPortEditModel[]): Observable<OtuPortEditModel[]> {
        return this.httpService.POST(`${this.otuPortApiUrl}`, ports).pipe(map(v => v));
    }

    public saveOtuPortNodeMapping(portNodeMapping: { portId: number, nodeIds: number[] }[]): Observable<any> {
        return this.httpService.POST(`${this.otuPortApiUrl}/mapNodes`, portNodeMapping);
    }

    public getNodeList(): Observable<any[]> {
        return this.httpService.GET(`${this.sharedService.getHost()}${PATHTRAK_PATH}node`).pipe(map(v => v));
    }

    public setTab(value: string){
        this.selectedTab = value;
    }

    public getTab() {
        return this.selectedTab;
    }
    //#endregion
}