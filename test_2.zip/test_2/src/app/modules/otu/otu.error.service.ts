/*
 * Copyright (c) 2018 Viavi Solutions Corporation. All rights reserved.
 * All material contained herein is Confidential and Proprietary.
 * Any reproduction or use of this material without the written consent from
 * Viavi Solutions Corporation is strictly prohibited.
 */
import { Injectable } from '@angular/core';
//import { LocalizationService } from 'angular2localization';
import { Observable } from 'rxjs';

import { ALERT_ERROR } from '../../constant/app.constants';
import { ControlMessagesService } from '../../shared/control.messages.service';
import { LocaleDataService } from '../../shared/locale.data.service';
import {ShowAlert} from '../../utilities/showAlert';
import { filter, map, take } from 'rxjs/operators';

@Injectable()
export class OtuErrorService {
    private localizationService: Observable<any>
    constructor (
        private localeDataService: LocaleDataService,
        private showAlert: ShowAlert,
        private controlMessageService: ControlMessagesService) {
            this.localizationService = this.localeDataService.isReady
            .pipe(filter(r => r),
            map(r => this.localeDataService.getLocalizationService()));
        }

    public showError(errorResponse) {
        console.log('get error message', errorResponse);
        this.localizationService.pipe(take(1))
        .subscribe(ls => {
            let message = this.controlMessageService.getMsg(errorResponse.error.errorCode);          
            this.showAlert.showSimpleAlert(ALERT_ERROR, message,"ERROR");
        });
    }
}