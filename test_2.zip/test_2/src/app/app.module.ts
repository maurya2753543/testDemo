import { SharedModule } from './modules/shared/shared.module';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {AppRoutes} from './app.routes';
import { FormsModule, ReactiveFormsModule  } from "@angular/forms";
import { AppComponent } from './app.component';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';

// 3rd Party
// import { ChartModule } from 'angular2-highcharts';
import { HighchartsChartModule } from 'highcharts-angular';
import {TranslateModule, TranslateLoader, TranslateService} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
//import { LocaleModule, LocalizationModule } from 'angular2localization';
import { Logger } from './utilities/logger';
// import { PerfectScrollbarModule, PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';

//Don't remove this below two lines for ag-grid license.
import {LicenseManager} from "ag-grid-enterprise";
LicenseManager.setLicenseKey('Viavi__PathTrak_1Devs_150Deployment_8_July_2020__MTU5NDE2MjgwMDAwMA==d04104de1da4af739d72e75962d5b9c6');

//Common services
import  {HttpService} from "./shared/http.service";
import {UrlService} from "./shared/url.service";
import {SharedService} from "./shared/shared.service";
import {WindowService} from "./shared/nativeProvider/window.service";
import {LocaleDataService } from "./shared/locale.data.service";
import {LanguageService} from "./shared/locale.language.service";
import {SweetAlert} from "./utilities/sweetAlert";
import {ShowAlert} from "./utilities/showAlert";
import { NavService } from './shared/nav.service';
import {ThemeService} from './shared/theme.service';
import {CookieService} from './shared/cookie.service';
import { HttpModule } from '@angular/http';
import * as AppConstants from './constant/app.constants';
//modules
// import {HomeComponent} from './components/home/home.component';

//component services
import { HostService } from './shared/host.service';
import { AuthService } from './shared/auth.service';
import { ControlMessagesService } from './shared/control.messages.service';
// import AlarmSummaryService from "./modules/dashboard/alarmSummary/alarm-summary.service";
// import AlarmSummaryDataService from "./modules/dashboard/alarmSummary/alarm-summary.data.service";
// import AlarmSummaryChartConfigService from "./modules/dashboard/alarmSummary/alarm-summary-chart.config"

//Pipes
import { OrderBy } from './utilities/orderBy';
import {AgGridConfigurationService} from "./shared/agGrid.configuration.service";
import {DocumentService} from "./shared/nativeProvider/document.service";
import {LeftNavComponent} from "./components/leftNavigation/leftNav.component";


import {HeaderModule} from "./components/header/header.module";
import {RouteResolverService} from "./shared/route.resolver.service";

import {PermissionGuard} from "./shared/permission.guard";
import {CommonStringsService} from "./shared/commonStringsService";

//import { PERFECT_SCROLLBAR_CONFIG } from "./constant/app.constants";
import {ModemSearchService} from './modules/shared/modem-search/modemSearch.service';
import localeDe from "@angular/common/locales/de";
import localeEs from "@angular/common/locales/es";
import localeFr from "@angular/common/locales/fr";
import localeJa from "@angular/common/locales/ja";
import localePt from "@angular/common/locales/pt";
import localeZh from "@angular/common/locales/zh";
import localeZhHans from "@angular/common/locales/zh-Hans";
import localeZhHansHk from "@angular/common/locales/zh-Hant-HK";
import { registerLocaleData } from '@angular/common';
//import { HttpClientModule } from '@angular/common/http';
// import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { PerfectScrollbarModule , PerfectScrollbarConfigInterface ,PERFECT_SCROLLBAR_CONFIG} from 'ngx-perfect-scrollbar';
import { HeadersInterceptor } from './shared/headers.interceptors';
   // import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
    
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

    


registerLocaleData(localeDe, "de");
registerLocaleData(localeEs, "es");
registerLocaleData(localeFr, "fr");
registerLocaleData(localeJa, "ja");
registerLocaleData(localePt, "pt");
registerLocaleData(localeZh, "zh");
registerLocaleData(localeZhHans, "zh-CN");
registerLocaleData(localeZhHansHk, "zh-TW");

declare var require: {
  <T>(path: string): T;
  (paths: string[], callback: (...modules: any[]) => void): void;
  ensure: (paths: string[], callback: (require: <T>(path: string) => T) => void) => void;
};

export function HttpLoaderFactory(http: HttpClient) {
  let lan = navigator.language.split('-')[0];
  const langs = AppConstants.LANGUAGE_LIST_SHORT;
  const isLang = langs && langs.find(lang => lang === lan);
  const lang = (isLang) ? isLang : 'en';
  return new TranslateHttpLoader(http, `./assets/lang/${lang}/locale-`, ".json");
}

export function highchartsFactory() {
  const hc = require('highcharts');
  const dd = require('highcharts/modules/drilldown');
  this.dd(hc);

  return hc;
}
const APP_PROVIDERS = [
    RouteResolverService,
    SharedService,
    HostService,
    AuthService,
    LocaleDataService,
    ControlMessagesService,
    // InformationDataService,
    // AlarmSummaryService,
    // AlarmSummaryChartConfigService,
    // AlarmSummaryDataService,
    LanguageService,
    ModemSearchService
];

@NgModule({
  imports: [
    HttpModule,
    HttpClientModule,
    BrowserModule,
    
    CommonModule,
    FormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
      // ChartModule.forRoot(require('highcharts')),
      HighchartsChartModule,
      // PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
      // import HttpClientModule after BrowserModule.
      HeaderModule,
      ReactiveFormsModule,
      PerfectScrollbarModule,
      AppRoutes,
      SharedModule 
      
      //MomentModule
  ],
  declarations: [
      AppComponent,
      // HomeComponent,
      LeftNavComponent,
      OrderBy
  ],
  bootstrap: [AppComponent],
  providers: [
      APP_PROVIDERS,
      HttpService,
      UrlService,
      Logger,
      TranslateService,
      CommonStringsService,
      SweetAlert,
      ShowAlert,
      WindowService,
      DocumentService,
      AgGridConfigurationService,
      NavService,
      ThemeService,
      PermissionGuard,
      CookieService,
      // {
      //   provide: HighchartsStatic,
      //   useFactory: highchartsFactory
      //   },
        {
          provide: PERFECT_SCROLLBAR_CONFIG,
          useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        { 
          provide: HTTP_INTERCEPTORS, 
          useClass: HeadersInterceptor,
          multi: true },
          
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA ]
})

export class AppModule { };
