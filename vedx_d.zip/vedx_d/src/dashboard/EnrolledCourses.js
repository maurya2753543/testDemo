import React, { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

// Styled components

// Styled components
const EnrollCourseContainer = styled.div`
  padding: 20px;
`;

const CourseTitle = styled.h3`
  margin-bottom: 20px;
  color: #333; /* Darker color for the title */
`;

const TabContainer = styled.div`
  display: flex;
  flex-direction: column; /* Stack tabs vertically */
  margin-bottom: 20px;
  position: relative; /* Needed for positioning the border */

  ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
   

    li {
      margin-right: 20px;

      a {
        text-decoration: none;
        padding: 10px 15px;
        color: black; /* Text color for the tab */
        border-radius: 5px;
       

        &.active {
          color: #ff5248; /* Text color for the tab */
          border-bottom: 2px solid ; /* Red border for the active tab */
        }
      }
    }
  }

  /* Add a black border below the tabs */
  &::after {
    content: '';
    display: block;
    height: 2px; /* Height of the border */
    background-color: black; /* Color of the border */
    position: absolute;
    bottom: 0; /* Position at the bottom */
    left: 0;
    right: 0; /* Full width */
    z-index: -1; /* Place it behind the tabs */
  }
`;

const CourseCard = styled.div`
  display: flex;
  border: 1px solid #e0e0e0; /* Card border */
  border-radius: 8px; /* Rounded corners */
  overflow: hidden; /* Prevents overflow of content */
  margin-bottom: 20px; /* Space between cards */
  cursor: pointer; /* Change cursor on hover to indicate clickability */
`;

const CourseThumbnail = styled.div`
  width: 50%; /* 50% width for the thumbnail */
  height: 200px; /* Fixed height for the thumbnail */
  background-image: url(${(props) => props.img});
  background-size: cover; /* Cover the area */
  background-position: center; /* Center the image */
`;

const CourseContent = styled.div`
  width: 50%; /* 50% width for the content */
  padding: 20px; /* Padding inside the content area */
  display: flex;
  flex-direction: column; /* Stack items vertically */
`;

const Stars = styled.div`
  color: gold; /* Color for stars */
  margin-bottom: 10px; /* Space below the stars */
  font-size: 25px;
`;

const ProgressBar = styled.div`
  background-color: #e0e0e0;
  border-radius: 5px;
  height: 5px;
  position: relative;

  .progress-filled {
    background-color: #ff5248; /* Color for the filled part of the progress bar */
    height: 100%;
    border-radius: 5px;
  }
`;

// Sample course data
const coursesData = {
  allCourses: {
    title: "Maths Genius Program",
    totalLessons: 351,
    completedLessons: 44,
    progress: 13,
    thumbnail: "https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png",
    instructor: "Prof Ved's"
  },
  activeCourses: {
    title: "Active Maths Genius Program",
    totalLessons: 200,
    completedLessons: 100,
    progress: 50,
    thumbnail: "https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png",
    instructor: "Prof Ved's"
  },
  completedCourses: {
    title: "Completed Maths Genius Program",
    totalLessons: 150,
    completedLessons: 150,
    progress: 100,
    thumbnail: "https://www.profved.com/wp-content/uploads/2021/05/course-v2-thumbnail.png",
    instructor: "Prof Ved's"
  }
};

const EnrollCourse = () => {
  const [activeTab, setActiveTab] = useState('allCourses');
  const navigate = useNavigate(); // Initialize useNavigate

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const handleCourseClick = () => {
    navigate('/courses/maths-genius-program-level-1/'); // Redirect to the specified route
  };

  const { title, totalLessons, completedLessons, progress, thumbnail } = coursesData[activeTab];

  return (
    <EnrollCourseContainer>
      <CourseTitle>Enrolled Courses</CourseTitle>
      <TabContainer>
        <ul>
          <li>
            <a
              href="#"
              className={activeTab === 'allCourses' ? 'active' : ''}
              onClick={() => handleTabClick('allCourses')}
            >
              All Courses
            </a>
          </li>
          <li>
            <a
              href="#"
              className={activeTab === 'activeCourses' ? 'active' : ''}
              onClick={() => handleTabClick('activeCourses')}
            >
              Active Courses
            </a>
          </li>
          <li>
            <a
              href="#"
              className={activeTab === 'completedCourses' ? 'active' : ''}
              onClick={() => handleTabClick('completedCourses')}
            >
              Completed Courses
            </a>
          </li>
        </ul>
      </TabContainer>

      <CourseCard onClick={handleCourseClick}> {/* Add onClick to CourseCard */}
        <CourseThumbnail img={thumbnail} />
        <CourseContent>
          <Stars>
            {[...Array(5)].map((_, index) => (
              <span key={index}>★</span>
            ))}
          </Stars>
          <h3>{title}</h3>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Total Lessons: {totalLessons}</span>
            <span>Completed Lessons: {completedLessons}</span>
          </div>
          <ProgressBar>
            <div className="progress-filled" style={{ width: `${progress}%` }}></div>
          </ProgressBar>
          <span>{progress}% Complete</span>
        </CourseContent>
      </CourseCard>
    </EnrollCourseContainer>
  );
};

export default EnrollCourse;


