import React, { useState } from 'react';
import Header from '../comman-header/Header';
import Footer from '../footer/Footer';
import './StudentRegistration.css';
const StudentRegistration = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    userName: '',
    email: '',
    password: '',
    confirmPassword: '',
    subscribe: false,
    unsubscribe: false,
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const validateForm = () => {
    let formErrors = {};
    if (!formData.firstName) formErrors.firstName = 'First Name is required';
    if (!formData.lastName) formErrors.lastName = 'Last Name is required';
    if (!formData.userName) formErrors.userName = 'Username is required';
    if (!formData.email) formErrors.email = 'Email is required';
    if (!formData.password) formErrors.password = 'Password is required';
    if (formData.password !== formData.confirmPassword)
      formErrors.confirmPassword = 'Passwords do not match';

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // Handle form submission
      console.log('Form Submitted', formData);
    }
  };

  return (
    <>
              <Header />
              <div className="entry-content clearfix">
      <form onSubmit={handleSubmit} className="registration-form">
        <div className="tutor-form-row2">
          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>First Name</label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                placeholder="First Name"
                required
              />
              {errors.firstName && <p className="error">{errors.firstName}</p>}
            </div>
          </div>

          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>Last Name</label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                placeholder="Last Name"
                required
              />
              {errors.lastName && <p className="error">{errors.lastName}</p>}
            </div>
          </div>
        </div>

        <div className="tutor-form-row2">
          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>Username</label>
              <input
                type="text"
                name="userName"
                value={formData.userName}
                onChange={handleChange}
                placeholder="Username"
                required
              />
              {errors.userName && <p className="error">{errors.userName}</p>}
            </div>
          </div>

          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Email"
                required
              />
              {errors.email && <p className="error">{errors.email}</p>}
            </div>
          </div>
        </div>

        <div className="tutor-form-row2">
          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Password"
                required
              />
              {errors.password && <p className="error">{errors.password}</p>}
            </div>
          </div>

          <div className="tutor-form-col-6">
            <div className="tutor-form-group">
              <label>Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="Confirm Password"
                required
              />
              {errors.confirmPassword && (
                <p className="error">{errors.confirmPassword}</p>
              )}
            </div>
          </div>
        </div>

        <div className="tutor-form-row">
          <div className="tutor-form-col-12">
          <label>
              Subscribe to Email Updates
              </label>
            <div className="tutor-form-group-student">
             
                <input
                  type="checkbox"
                  name="subscribe"
                  checked={formData.subscribe}
                  onChange={handleChange}
                />
               
            </div>
            <label>
              Unsubscribe from Email Updates
              </label>
            <div className="tutor-form-group-student">
             
                <input
                  type="checkbox"
                  name="unsubscribe"
                  checked={formData.unsubscribe}
                  onChange={handleChange}
                />
             
            </div>
          </div>
        </div>

        <div className="tutor-form-row-reg">
          <div className="tutor-form-col-12">
            <div className="tutor-form-group tutor-reg-form-btn-wrap">
              <button type="submit" className="tutor-button">
                Register
              </button>
            </div>
          </div>
        </div>
      </form>

    </div>

    <div className="Footer_div">
    <Footer/>

    </div>

    </>
   
  );
};

export default StudentRegistration;
