import React, { useState, useEffect } from 'react';
import './Notifications.css'; // Assuming you have some styles here
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import notificationService from '../service/NotificationService'; // Import the service

const Notifications = () => {
  const [inputText, setInputText] = useState(''); // Temporary input for typing
  const [isEditing, setIsEditing] = useState(false);
  const [notificationText, setNotificationText] = useState('');

  // Handle input change and word limit enforcement
  const handleInputChange = (e) => {
    const input = e.target.value;
    const words = input.trim().split(/\s+/);
    if (words.length <= 100) {
      setInputText(input);
    } else {
      alert('Maximum 100 words allowed');
    }
  };

  // Add a new notification or update the existing one
  const handleAddOrUpdate = () => {
    if (inputText.trim() === '') {
      alert('Please enter a notification text!');
      return;
    }

    // If editing, update the existing notification
    if (isEditing) {
      setNotificationText(inputText);
      notificationService.addNotification(inputText); // Add updated notification
      setIsEditing(false);
    } else {
      // If not editing, add new notification
      if (!notificationText) {
        setNotificationText(inputText);
        notificationService.addNotification(inputText); // Add new notification
      } else {
        alert('You can only add one notification. Edit the current one.');
      }
    }

    setInputText(''); // Clear the input field after adding/updating
  };

  // Handle edit notification
  const handleEdit = () => {
    setInputText(notificationText); // Load current notification into the input
    setIsEditing(true); // Set edit mode
  };

  // Handle delete notification
  const handleDelete = () => {
    setNotificationText('');
    setInputText('');
    setIsEditing(false);
    notificationService.clearNotifications(); // Clear notifications
  };

  return (
    <div className="notifications-container">
      <h1>Notifications</h1>

      <div className="notification-input">
        <textarea
          placeholder="Enter notification text (Max 100 words)"
          value={inputText}
          onChange={handleInputChange}
          rows="4"
          style={{ maxHeight: '200px' }}
        />
        <div className="notification-controls">
          <button onClick={handleAddOrUpdate}>
            {isEditing ? 'Update Notification' : 'Add Notification'}
          </button>
        </div>
      </div>

      {notificationText && (
        <ul className="notification-list">
          <li className="notification-item">
            <span>{notificationText}</span>
            <div className="notification-actions">
              <button onClick={handleEdit}>
                <FontAwesomeIcon icon={faEdit} /> {/* Edit icon */}
              </button>
              <button onClick={handleDelete}>
                <FontAwesomeIcon icon={faTrashAlt} /> {/* Delete icon */}
              </button>
            </div>
          </li>
        </ul>
      )}
    </div>
  );
};

export default Notifications;
