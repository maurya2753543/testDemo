import React, { useState } from 'react';
import AppwriteService from '../appwrite/AppwriteService'; // Update with the correct path
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ChangePasswordForm = () => {
    const [passwords, setPasswords] = useState({
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
    });

    const appwriteService = new AppwriteService();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setPasswords({ ...passwords, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validate new passwords match
        if (passwords.newPassword !== passwords.confirmPassword) {
            toast.error("New passwords do not match!"); // Use toastr for error
            return;
        }

        try {
            // Call the Appwrite service to update the password
            await appwriteService.updatePassword(passwords.oldPassword, passwords.newPassword);
            toast.success("Password updated successfully!"); // Use toastr for success
        } catch (error) {
            toast.error("Failed to update password: " + error.message); // Use toastr for error
        }
    };

    return (
        <>
            <form onSubmit={handleSubmit}>
                <div className="tutor-form-group">
                    <label>Old Password</label>
                    <input
                        type="password"
                        name="oldPassword"
                        value={passwords.oldPassword}
                        onChange={handleInputChange}
                        placeholder="Old Password"
                        required
                    />
                </div>

                <div className="tutor-form-group">
                    <label>New Password</label>
                    <input
                        type="password"
                        name="newPassword"
                        value={passwords.newPassword}
                        onChange={handleInputChange}
                        placeholder="New Password"
                        required
                    />
                </div>

                <div className="tutor-form-group">
                    <label>Confirm New Password</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        value={passwords.confirmPassword}
                        onChange={handleInputChange}
                        placeholder="Confirm New Password"
                        required
                    />
                </div>

                <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                        <div className="tutor-form-group tutor-profile-form-btn-wrap">
                            <button type="submit" className="tutor-button">
                                Reset Password
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            <ToastContainer /> {/* Add the ToastContainer here */}
        </>
    );
};

export default ChangePasswordForm;
