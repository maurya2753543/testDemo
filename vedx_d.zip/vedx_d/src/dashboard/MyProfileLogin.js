import React, { useState } from 'react';
import './MyProfileLogin.css';
import { Link, useNavigate } from 'react-router-dom';
import AppwriteService from '../appwrite/AppwriteService'; // Ensure this path is correct
// Access environment variables
const apiEndpoint = process.env.REACT_APP_API_ENDPOINT;
const apiKey = process.env.REACT_APP_API_KEY;

const MyProfileLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
   // event.preventDefault();
   navigate('/dashboard/user'); // Change this to the correct path for your TabLayout page

    try {
      // Pass the API endpoint and API key to the service
      const appwriteService = new AppwriteService(apiEndpoint, apiKey);
      const response = await appwriteService.login({ username, password });

      console.log(response ,"response user")
      if (response) {
        // Redirect to TabLayout page
        navigate('/dashboard/user'); // Change this to the correct path for your TabLayout page
      //  onLoginNowClick();
        setErrorMessage('');
      }
    } catch (error) {
      setErrorMessage('Login failed. Please check your credentials.');
      console.error('Error during login:', error);
    }
  };

  return (
    <div className="tutor-wrap tutor-page-wrap post-5 page type-page status-publish hentry">
      <div className="tutor-template-segment tutor-login-wrap">
        <div className="tutor-login-title">
          <h4>Please Sign-In to view this section</h4>
        </div>

        {errorMessage && <p style={{ color: 'red' , textAlign : 'center' }}>{errorMessage}</p>} {/* Error message display */}

        <div className="tutor-template-login-form">
          <div className="tutor-login-form-wrap">
            <form name="loginform" id="loginform" method="post" onSubmit={handleSubmit}>
              <p className="login-username">
                <input
                  type="text"
                  placeholder="Username or Email Address"
                  name="log"
                  id="user_login"
                  className="input"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <p className="login-password">
                <input
                  type="password"
                  placeholder="Password"
                  name="pwd"
                  id="user_pass"
                  className="input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <div className="tutor-login-remember-wrap">
                <p className="login-remember">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label htmlFor="rememberme">Remember Me</label>
                  <Link to="/dashboard/retrieve-password" className="forgot-password-link">
                    Forgot Password?
                  </Link>
                </p>
              </div>

              <p className="login-submit">
                <input type="submit" name="wp-submit" id="wp-submit" className="tutor-button1" value="Log In" />
                <input type="hidden" name="redirect_to" value="" />
              </p>

              <p className="tutor-form-register-wrap">
                <Link to="/dashboard/student-registration">
                  Create a new account
                </Link>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyProfileLogin;


