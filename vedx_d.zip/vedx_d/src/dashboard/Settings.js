import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components';
import './Settings.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCamera, faTrash } from '@fortawesome/free-solid-svg-icons';
import NotificationComponent from './Notifications';
import ChangePasswordForm from './ChangePasswordForm';
import AppwriteService from '../appwrite/AppwriteService';
// Styled components
const SettingsContainer = styled.div`
  padding: 20px;
`;

const SettingsTitle = styled.h3`
  margin-bottom: 20px;
  color: #333; /* Darker color for the title */
`;

const TabContainer = styled.div`
  display: flex;
  flex-direction: column; /* Stack tabs vertically */
  margin-bottom: 20px;
  position: relative; /* Needed for positioning the border */

  ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;

    li {
      margin-right: 20px;

      a {
        text-decoration: none;
        padding: 10px 15px;
        color: black; /* Text color for the tab */
        border-radius: 5px;
        transition: color 0.3s ease-in-out, border-bottom 0.3s ease-in-out;

        &:hover {
          color: #ff5248;
        }

        &.active {
          color: #ff5248; /* Text color for the active tab */
          border-bottom: 2px solid #ff5248; /* Red border for the active tab */
        }
      }
    }
  }

  /* Add a black border below the tabs */
  &::after {
    content: '';
    display: block;
    height: 2px; /* Height of the border */
    background-color: black; /* Color of the border */
    position: absolute;
    bottom: 0; /* Position at the bottom */
    left: 0;
    right: 0; /* Full width */
    z-index: -1; /* Place it behind the tabs */
  }
`;

const SettingsContent = styled.div`
  border: 1px solid #e0e0e0; /* Content border */
  border-radius: 8px; /* Rounded corners */
  padding: 20px; /* Padding inside the content area */
`;

// Sample settings data
const settingsData = {
  profile: {
    title: 'Profile Settings',
    content: 'Update your personal information, profile picture, and contact details.'
  },
  account: {
    title: 'Reset Password',
    content: 'Change your password by entering your old password and confirming the new one.'
  },
  notifications: {
    title: 'Notification Settings',
    content: 'Customize your notification preferences and email alerts.'
  }
};

const Settings = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [passwords, setPasswords] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const [createdAt, setCreatedAt] = useState('');
  const [updatedAt, setUpdatedAt] = useState('');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [emailVerified, setEmailVerified] = useState(false);
  const [status, setStatus] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  useEffect(() => {
    // Fetch the user profile on component mount
    const fetchUserProfile = async () => {
        try {
            const appwriteService = new AppwriteService();
            const user = await appwriteService.account.get(); // Fetch the current user's data
            const nameParts = user.name ? user.name.split(' ') : [];
            const firstName = nameParts.length > 0 ? nameParts[0] : 'Not provided';
            const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : 'Not provided'; 
            // Map the response data to the state
            setCreatedAt(user.$createdAt);
            setUpdatedAt(user.$updatedAt);
            setEmail(user.email);
            setFirstName(firstName);
            setLastName(lastName);
            setPhone(user.phone || 'Not provided'); // Show 'Not provided' if phone is empty
            setName(user.name);
           // Handles cases where there's no last name
            setPhone(user.phone || 'Not provided'); // Show 'Not provided' if phone is empty
            setEmailVerified(user.emailVerification);
            setStatus(user.status);
            
            console.log("User Data:", user); // Log the fetched user data for debugging
        } catch (error) {
            console.error("Error fetching user profile:", error);
        }
    };

    fetchUserProfile();
}, []);



  const fileInputRef = useRef(null);

  // Step 4: Handle the file upload
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      console.log('File selected:', file);
      // You can add more logic here, e.g., uploading the file
    }
  };
  // Step 5: Trigger the file input click on button click
  const handleButtonClick = () => {
    fileInputRef.current.click();
  };
  const { title, content } = settingsData[activeTab];

  return (
    <SettingsContainer>
      <SettingsTitle>User Settings</SettingsTitle>
      <TabContainer>
        <ul>
          <li>
            <a
              href="#"
              className={activeTab === 'profile' ? 'active' : ''}
              onClick={() => handleTabClick('profile')}
            >
              Profile
            </a>
          </li>
          <li>
            <a
              href="#"
              className={activeTab === 'account' ? 'active' : ''}
              onClick={() => handleTabClick('account')}
            >
              Reset Password
            </a>
          </li>
          <li>
            <a
              href="#"
              className={activeTab === 'notifications' ? 'active' : ''}
              onClick={() => handleTabClick('notifications')}
            >
              Notifications
            </a>
          </li>
        </ul>
      </TabContainer>

      <SettingsContent>
        {activeTab === 'profile' ? (
          <div className="tutor-col-9">
            <div className="tutor-dashboard-content">
              <h3>Settings</h3>
              <div className="tutor-dashboard-content-inner">
                <div id="tutor_profile_cover_photo_editor">
                  <div id="tutor_cover_area" style={{ backgroundImage: 'url(https://www.profved.com/wp-content/plugins/tutor/assets/images/cover-photo.jpg)' }}>
                    <div className="tutor_overlay" style={{ position: 'relative' }}>
                      {/* Profile Image */}
                      <div
                        className="Profile_name_settings" id='tutor_profile_area_profile'
                        style={{
                          backgroundImage: 'url(https://www.profved.com/wp-content/plugins/tutor/assets/images/profile-photo.png)',
                          height: '142px',
                          width: '142px',
                          backgroundSize: 'cover',
                          borderRadius: '50%',
                          position: 'absolute', // Positioning it absolutely
                          bottom: '-40px', // Adjust to place it above the uploader and delete button
                          left: '30px', // Adjust to position it horizontally
                          fontSize: '18px',
                          background: 'rgba(0, 0, 0, 0.253);'
                        }}
                      >
                        <FontAwesomeIcon icon={faCamera} style={{ marginLeft: '60px', marginTop: '110px', color: 'black' }} />
                      </div>

                      {/* Overlay for uploader and delete button */}
                      <div style={{ position: 'absolute', bottom: 0, width: '100%' }}>
                        <button className="tutor_cover_uploader" onClick={handleButtonClick}>
                          <FontAwesomeIcon icon={faCamera} style={{ marginRight: '8px' }} />
                          <span>Upload Cover Photo</span>
                          <input
                            type="file"
                            accept=".png,.jpg,.jpeg"
                            ref={fileInputRef}
                            style={{ display: 'none' }} // Hide the input
                            onChange={handleFileChange} // Handle file selection
                          />
                        </button>

                        <span className="tutor_cover_deleter">
                          <FontAwesomeIcon icon={faTrash} />
                        </span>
                      </div>
                    </div>

                  </div>
                  <div className="info_icon_settings" id="tutor_photo_meta_area">
                    <img src="https://www.profved.com/wp-content/plugins/tutor//assets/images/info-icon.svg" alt="info" />
                    <span>
                      Profile Photo Size: <span>200x200</span> pixels,
                    </span>
                    <span> Cover Photo Size: <span>700x430</span> pixels </span>
                  </div>


                </div>

                <form action="" method="post" encType="multipart/form-data">
                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-6">
                      <div className="tutor-form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name"
                         value={firstName} // Use state variable for value
                        placeholder="First Name" />
                      </div>
                    </div>

                    <div className="tutor-form-col-6">
                      <div className="tutor-form-group">
                        <label>Last Name</label>
                        <input type="text"
                         value={lastName} // Use state variable for value

                         name="last_name" 
                              placeholder="Last Name" />
                      </div>
                    </div>
                  </div>

                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-6">
                      <div className="tutor-form-group">
                        <label>User Name</label>
                        <input type="text" disabled
                          value={name} 
                          // Use state variable for value 
                          />
                      </div>
                    </div>

                    <div className="tutor-form-col-6">
                      <div className="tutor-form-group">
                        <label>Phone Number</label>
                        <input type="number" name="phone_number"
                        value={phone} // Use state variable for value
                         placeholder="Phone Number" />
                      </div>
                    </div>
                  </div>

                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label>Bio</label>
                        <textarea name="tutor_profile_bio"></textarea>
                      </div>
                    </div>
                  </div>

                  <div className="display_name">
                    <label htmlFor="display_name" style={{ display: "block", color: "black", padding: "8px" , marginTop: "10px" }}>
                      Display name publicly as
                    </label>

                    <select className="display_name_select" id="display_name" style={{ width: "40%", color: "red", padding: "15px" , marginLeft : "10px" }}>
                      <option>{name}1234</option>
                      <option>{firstName}</option>
                      <option>{lastName}</option>
                      <option selected="selected">{name}</option>
                      <option>{lastName} {firstName}</option>
                    </select>
                  </div>

                  <p style={{ marginTop: "10px" , marginLeft: "10px" }}>
                    <small>
                      The display name is shown in all public fields, such as the author name, instructor name, student name, and name that will be printed on the certificate.
                    </small>
                  </p>


                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label htmlFor="_tutor_profile_website">Website URL</label>
                        <input type="text" id="_tutor_profile_website" name="_tutor_profile_website" placeholder="https://example.com/" />
                      </div>
                    </div>
                  </div>
                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label htmlFor="_tutor_profile_website">Github URL</label>
                        <input type="text" id="_tutor_profile_website" name="_tutor_profile_website" placeholder="https://example.com/" />
                      </div>
                    </div>
                  </div>
                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label htmlFor="_tutor_profile_website">Facebook URL</label>
                        <input type="text" id="_tutor_profile_website" name="_tutor_profile_website" placeholder="https://example.com/" />
                      </div>
                    </div>
                  </div>
                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label htmlFor="_tutor_profile_website">Twitter URL</label>
                        <input type="text" id="_tutor_profile_website" name="_tutor_profile_website" placeholder="https://example.com/" />
                      </div>
                    </div>
                  </div>
                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group">
                        <label htmlFor="_tutor_profile_website"> Linkedin URL</label>
                        <input type="text" id="_tutor_profile_website" name="_tutor_profile_website" placeholder="https://example.com/" />
                      </div>
                    </div>
                  </div>



                  {/* Add more fields for social media URLs */}

                  <div className="tutor-form-row1">
                    <div className="tutor-form-col-12">
                      <div className="tutor-form-group tutor-profile-form-btn-wrap">
                        <button type="submit" className="tutor-button">
                          Update Profile
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        ) : activeTab === 'account' ? (
         <div>
          <ChangePasswordForm />
         </div>
        )   : activeTab === 'notifications' ? (
          <div>
          <NotificationComponent /> 

          </div>
        ) : null}
      </SettingsContent>
    </SettingsContainer>
  );
};

export default Settings;
