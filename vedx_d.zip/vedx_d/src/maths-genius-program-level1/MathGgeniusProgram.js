import React from 'react';
import MathGeniusHeader from './MathGeniusHeader';
import Dashboard_Header from '../comman-header/Dashbord-header';
const mathsGenius = () => {
  return (
    <div>
      <Dashboard_Header />
     <MathGeniusHeader />
    </div>
  );
};

export default mathsGenius;
