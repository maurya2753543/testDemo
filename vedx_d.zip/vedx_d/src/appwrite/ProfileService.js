import { ID, Account, Client, Storage } from 'appwrite';

// Initialize Appwrite Client
const appwriteClient = new Client();

class AppwriteService {
    account;
    storage;

    constructor() {
        const endpoint = "https://cloud.appwrite.io/v1"; // Replace with your actual endpoint
        const projectId = "66fb8c0f0024c89bdea5"; // Replace with your actual project ID
        appwriteClient
            .setEndpoint(endpoint)
            .setProject(projectId);

        this.account = new Account(appwriteClient);
        this.storage = new Storage(appwriteClient); // Initialize storage for file uploads
    }

    // Update user profile details
    async updateProfile(userId, { email, name, phone }) {
        try {
            const response = await this.account.update(userId, email, name, phone);
            console.log('Profile updated:', response);
            return response;
        } catch (error) {
            console.error("Appwrite service :: updateProfile() :: ", error);
            throw error;
        }
    }

    // Upload profile picture
    async uploadProfilePicture(userId, file) {
        try {
            // Upload the file to storage
            const uploadedFile = await this.storage.createFile('profile_pictures', ID.unique(), file);
            console.log('Profile picture uploaded:', uploadedFile);

            // Update user's profile with new image URL
            const profilePictureURL = `https://cloud.appwrite.io/v1/storage/files/${uploadedFile.$id}/view?project=66fb8c0f0024c89bdea5`;
            const response = await this.account.updatePrefs({ profilePictureURL });
            console.log('Profile picture URL updated:', response);
            return response;
        } catch (error) {
            console.error("Appwrite service :: uploadProfilePicture() :: ", error);
            throw error;
        }
    }
}

export default AppwriteService;
