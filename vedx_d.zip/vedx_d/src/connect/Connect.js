// src/Connect.js

import React from 'react';
import './Connect.css'; // Import the CSS file for styling
import Header from '../comman-header/Header';
const Connect = () => {
    return (
      <>
      <Header/>
      <section id="main">
            

            <div className="container page-global-padding">
                <div className="row">
                    <div className="col-md-12">
                        <div id="content" className="site-content" role="main">
                            <div className="entry-content clearfix">
                                <div className="elementor">
                                    <section className="elementor-section elementor-top-section" >
                                        <div className="elementor-container">
                                            <div className="elementor-row">
                                                <div className="elementor-column elementor-col-100">
                                                    <div className="elementor-widget-wrap">
                                                        <h2 className="elementor-heading-title">Connect with Prof Ved on Social media</h2>
                                                        <div className="elementor-widget-container">
                                                            <iframe 
                                                                className="elementor-video-iframe" 
                                                                allowFullScreen 
                                                                title="vimeo Video Player" 
                                                                src="https://player.vimeo.com/video/867039005?color&autopause=0&loop=0&muted=0&title=1&portrait=1&byline=1#t="
                                                            ></iframe>
                                                        </div>
                                                        <section className="elementor-section elementor-inner-section">
                                                            <div className="elementor-container">
                                                                <div className="elementor-row">
                                                                    <div className="elementor-column elementor-col-33">
                                                                        <h3 className="elementor-heading-title">Connect with PROF VED</h3>
                                                                        <div className="elementor-social-icons-wrapper">
                                                                            <div className="elementor-grid-item">
                                                                                <a 
                                                                                    className="elementor-icon elementor-social-icon elementor-social-icon-instagram" 
                                                                                    href="https://www.instagram.com/theprofved/" 
                                                                                    target="_blank" 
                                                                                    rel="noopener noreferrer"
                                                                                >
                                                                                    <i className="fab fa-instagram"></i>
                                                                                </a>
                                                                            </div>
                                                                            <div className="elementor-grid-item">
                                                                                <a 
                                                                                    className="elementor-icon elementor-social-icon elementor-social-icon-whatsapp" 
                                                                                    href="https://wa.me/13103045880" 
                                                                                    target="_blank" 
                                                                                    rel="noopener noreferrer"
                                                                                >
                                                                                    <i className="fab fa-whatsapp"></i>
                                                                                </a>
                                                                            </div>
                                                                            {/* Add more social icons here */}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </section>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
      </>
       
    );
};

export default Connect;
