import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './header/NavBar'; // Assuming NavBar is inside a 'components' folder
import Connect from './connect/Connect'; // Connect page component
import Dashboard from './dashboard/Dashboard'; // Dashboard page component
import TabLayout from './dashboard/TabLayout';
import 'font-awesome/css/font-awesome.min.css';
import RetrievePassword from './dashboard/RetrievePassword';
import StudentRegistration from './dashboard/StudentRegistration';
import TabContent from './dashboard/DashbordContent';
import  MainHomeForm from './header/MainHomeForm';
import MathGgeniusProgram from './maths-genius-program-level1/MathGgeniusProgram';

import Settings from './dashboard/Settings';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Function to handle successful login
  const handleLoginSuccess = () => {
    setIsLoggedIn(true); // Update state to indicate user is logged in
  };
  return (

    <Router>
      {/* NavBar is rendered on all routes */}
      
      <Routes>
        {/* Define your routes here */}
        <Route path="/" element={<NavBar />} />
        <Route path="/connect-wth-prof-ved" element={<Connect />} />     
        <Route path="/dashboard/retrieve-password" element={<RetrievePassword />} />
        <Route path="/dashboard/student-registration" element={<StudentRegistration />} /> 
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/user" element={<TabLayout />} />      
        <Route path="/dashboard/settings" element={<Settings />} />
        <Route path="/mainhome" element={<MainHomeForm />} />
        <Route path="/courses/maths-genius-program-level-1/" element={<MathGgeniusProgram />} />

        

       

      </Routes>

      {/* <TabLayout /> */}
    
    </Router>
  );
}

export default App;
