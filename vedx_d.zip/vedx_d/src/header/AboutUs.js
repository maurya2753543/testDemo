import React from 'react';
import './AboutUs.css'; // Create a CSS file to style this component if needed
import { Link, useNavigate } from 'react-router-dom';

const AboutUs = () => {
  return (
    <>
      <div className="qubely-heading-container">
        <h1 className="qubely-heading-selector">About Prof. Ved & his math geniuses</h1>
      </div>
      <div className="about-us-container has-white-background-color">
        <div className="wp-block-columns has-white-color has-background">
          {/* Empty column for layout */}
          <div className="wp-block-column"></div>
          {/* Main Content */}
          <div className="wp-block-column main-content">
            {/* Video Embed */}
            <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo wp-embed-aspect-9-16">
              <div className="arve" style={{ maxWidth: '100%', maxHeight: '600px' }} itemscope itemType="http://schema.org/VideoObject">
                <span className="arve-inner">
                  <span className="arve-embed arve-embed--has-aspect-ratio">
                    <span className="arve-ar" style={{ paddingTop: '56.25%' }}></span>
                    <iframe
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="arve-iframe1"
                      src="https://player.vimeo.com/video/913119463?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                      frameBorder="0"
                      sandbox="allow-scripts allow-same-origin allow-presentation allow-popups allow-popups-to-escape-sandbox allow-forms"
                      scrolling="no"
                    ></iframe>
                  </span>
                </span>
              </div>
            </figure>

            {/* Call to Action Button */}
            <div className="wp-block-qubely-button qubely-block-2dc7da">
              <div className="qubely-block-btn-wrapper">
                <div className="qubely-block-btn">
                  <Link
                    className="qubely-block-btn-anchor is-large"
                    to="/mainhome"  
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Book a Free Demo Class
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Empty column for layout */}
          <div className="wp-block-column"></div>
        </div>
      </div>

      {/* Border Separator */}
      <div className="qubely-separator qubely-separator-before">
        {/* <span className="qubely-separator-type-css qubely-separator-double"></span> */}
      </div>

      <div className="qubely-heading-container">
        <div className="qubely-separator qubely-separator-before">
          <span className="qubely-separator-type-css qubely-separator-double"></span>
        </div>
        <h1 className="qubely-heading-selector">Math Genius Programs</h1>
      </div>
    </>
  );
};

export default AboutUs;
