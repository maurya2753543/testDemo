import React from 'react';
import './Videocontent.css'; // Optional: Import CSS for styling

const Videocontent = () => {
  return (
    <div className="video-content">
        <h2 class="qubely-block-text-title">Hear directly from 1000s of young geniuses across the US &amp; Canada</h2>
      <div className="video-row">
        {/* Column 1 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 2 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978329?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 3 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>
         {/* Column 1 */}
         <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 2 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978329?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 3 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>
         {/* Column 1 */}
         <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 2 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978329?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 3 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>
         {/* Column 1 */}
         <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 2 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978329?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* Column 3 */}
        <div className="video-column">
          <figure className="wp-block-embed is-type-video is-provider-vimeo wp-block-embed-vimeo">
            <div className="arve" data-provider="vimeo">
              <iframe
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="arve-iframe"
                src="https://player.vimeo.com/video/648978505?dnt=1&app_id=122963&html5=1&title=1&byline=0&portrait=0&autoplay=0"
                frameBorder="0"
                scrolling="no"
              ></iframe>
            </div>
          </figure>
        </div>

        {/* More rows can be added similarly */}
      </div>
    </div>
  );
};

export default Videocontent;
