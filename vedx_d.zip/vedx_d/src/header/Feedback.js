import React from 'react';
import './Feedback.css'; // Assuming you will create custom styles in this file

const testimonials = [
  {
    id: 1,
    quote: "The little monkey of mine went from not being confident with numbers to zipping it through just in few weeks! Prof Ved, we can not thank you enough for installing such confidence in her & making her love math!",
    author: "Radha Ramanan",
    designation: "San Jose, CA",
    image: "https://www.profved.com/wp-content/uploads/2021/10/245125914_10208638504195572_3610477779445442180_n.jpg"
  },
  {
    id: 2,
    quote: "Prof Ved got him (my kid) to think about stuff that a normal mind might not think about. Prof Ved does an amazing job in interacting with kids. I never expected my kid to be so happy!",
    author: "Akhil Bharadwaj",
    designation: "Amsterdam, Netherlands",
    image: "https://www.profved.com/wp-content/uploads/2021/11/Akhil-bharadwaj.jpg"
  },
  {
    id: 3,
    quote: "I think the magic of Super memory course is this whole system, nicely designed interesting questions, asking students to make videos, giving great feedback. It creates a positive spiral of confidence, enjoyment & extra effort in your students.",
    author: "Dr Ninad",
    designation: "CEO, Innerlabs, USA",
    image: "https://www.profved.com/wp-content/uploads/2021/11/Dr-ninad.jpg"
  }
];

const Feedback = () => {
  return (
    <>
<div className="feedback-main">
<h1 class="qubely-block-text-title-feedback">What Do Parents Say About Vedx Classes?</h1>
<div className="feedback-container">
      <div className="feedback-row">
        {testimonials.map((testimonial) => (
          <div key={testimonial.id} className="feedback-card">
            <div className="card-body">
              <div className="testimonial-quote">
                <i className="fas fa-quote-left"></i>
              </div>
              <div className="testimonial-content">
                <p><em>{testimonial.quote}</em></p>
              </div>
              <div className="testimonial-author d-flex align-items-center">
                <img
                  className="testimonial-avatar"
                  src={testimonial.image}
                  alt={testimonial.author}
                />
                <div className="author-info">
                  <div className="author-name">{testimonial.author}</div>
                  <div className="author-designation">{testimonial.designation}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
</div>
  
    </>
  
  );
};

export default Feedback;
