import React, { useState } from 'react';
import './NavBar.css'; // Import your custom styles
import StickyButton from './StickyButton';
import LoginPopup from './LoginPopup';
import styled from 'styled-components';
import SignUp from './Registration';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import Footer from '../footer/Footer'; // Import the Footer component
import CenteredContent from './CenteredContent';
import TopStudentsGallery from '../header/TopStudentsGallery';
import ShowNotification from './ShowNotification';
import AboutUs from './AboutUs';
import Grade from './Grade';
import SupperMemory from './SupperMemory'; 
import Videocontent from './Videocontent';
import Feedback from './Feedback';
const NavbarWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 20px;
  background-color: #333;
  color: white;
`;
const SvgCurve = styled.svg`
  width: 100%;
  height: auto;
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: -1; /* Ensure it stays behind other elements */
`;
const NavBar = () => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);

  const openLogin = () => setIsLoginOpen(true);
  const closeLogin = () => setIsLoginOpen(false);
  const openSignUpModal = () => setIsSignUpOpen(true);
  const closeSignUpModal = () => setIsSignUpOpen(false);

  return (
    <>
    <div className="Main-section">

      <header id="masthead" className="site-header header-transparent disable-sticky">
        <div className="container-fluid">
          <div className="navbar-row d-flex align-items-center justify-content-between">
            {/* Logo Section */}
            <div className="logo-wrapper">
              <Link className="skillate-navbar-brand" to="/">
                <img
                  className="enter-logo img-responsive"
                  src="https://www.profved.com/wp-content/uploads/2022/03/VEDX-logo-cropped-website.png"
                  alt="Logo"
                  title="Logo"
                />
              </Link>
            </div>


            {/* Connect and Dashboard Menu (Centered) */}
            <div className="menu-center">
              <ul id="menu-main-menu" className="nav">
                <li className="menu-item">
                  <Link to="/connect-wth-prof-ved">CONNECT</Link>
                </li>
                <li className="menu-item">
                  <Link to="/dashboard">DASHBOARD</Link>
                </li>
              </ul>
            </div>

            {/* Cart, Login, Sign Up (Right Aligned) */}
            <div className="d-flex align-items-center right-section">
              {/* Cart */}
              <div className="skillate-header-cart mr-lg-2 d-none d-lg-inline-block">
                <div id="site-header-cart" className="site-header-cart menu">
                  <span className="cart-icon">
                    <img
                      src="https://www.profved.com/wp-content/themes/skillate/images/cart-icon.svg"
                      alt="Cart Icon"
                    />
                    <a className="cart-contents" href="#modal-cart" title="View your shopping cart">
                      <span className="count">0</span>
                    </a>
                  </span>
                </div>
              </div>

    

              {/* Login and Sign Up */}
              <div className="skillate-header-login ml-4">
                <div className="header-login-wrap">
                  <a href="#!" onClick={openLogin}>Login</a>
                  <span className='line_spe'>|</span>
                  <a href="#!" onClick={openSignUpModal} className="ml-3">Sign Up</a>
                </div>
              </div>
            </div>
          </div>
       
        </div>
       
        <div className="ShowNotification">
        <ShowNotification />
 
        </div>

      </header>

      <CenteredContent />

      </div>

      {/* Conditionally render StickyButton based on isLoginOpen and isSignUpOpen */}
      {!isLoginOpen && !isSignUpOpen && <StickyButton />}

      <LoginPopup isOpen={isLoginOpen} onClose={closeLogin} />
      <SignUp isOpen={isSignUpOpen} onClose={closeSignUpModal} />
       
      {/* <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 99" preserveAspectRatio="none">
    <path 
        d="M526.35,17.11C607.41,28.38,687,48.17,768.06,59.5A1149.19,1149.19,0,0,0,1000,68.07V0H0V99C155.18,13.84,347.42-7.77,526.35,17.11Z" 
        fill="#041a62" 
        transform="rotate(180 500 49.5)"  
    ></path>
</svg> */}
{/* <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 99" preserveAspectRatio="none">
    
    <path transform="rotate(-180 500 49.5)" d="M526.35,17.11C607.41,28.38,687,48.17,768.06,59.5A1149.19,1149.19,0,0,0,1000,68.07V0H0V99C155.18,13.84,347.42-7.77,526.35,17.11Z" ></path>
</svg> */}
      <div>
        <AboutUs/>
      </div>
      <div>
        <Grade />
      </div>
      <div>
        <SupperMemory />
      </div>
      <div>
        <Videocontent />
      </div>
      <div className="feedback">
        <Feedback />
      </div>
      <div className="Top-galary">

      <TopStudentsGallery/>

      </div>

      <Footer /> {/* Add the Footer here */}
    </>
  );
};

export default NavBar;
