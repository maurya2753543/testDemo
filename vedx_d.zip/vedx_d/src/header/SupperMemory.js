import React, { useState } from 'react';
import './SupperMemory.css';

const SupperMemory = () => {
  const [isPlayingFirst, setIsPlayingFirst] = useState(false);
  const [isPlayingSecond, setIsPlayingSecond] = useState(false);

  const handlePlayFirstVideo = () => {
    setIsPlayingFirst(true);
  };

  const handlePlaySecondVideo = () => {
    setIsPlayingSecond(true);
  };

  return (
    <div className="qubely-block-text">
      <div className="qubely-block-text-title-container qubely-separator-position-top">
        <div className="qubely-block-text-title-inner">
          <h2 className="qubely-block-text-title">
            <span style={{ color: '#2084F9' }}>Super Memory Program</span>
          </h2>
        </div>
      </div>
      <p>
        <span style={{ color: '#062040' }}>
          Enroll your child in the Super Memory Program to make your child a super fast learner. 
          Imagine your child learning 3x faster all her life. Check the student videos below to 
          know the power of the program.
        </span>
      </p>

      {/* Video popup container for the first video */}
      <div className="wp-block-qubely-videopopup qubely-block-711639">
        <div 
          className={`qubely-block-videopopup-wrapper qubely-alignment-center ${isPlayingFirst ? 'playing' : ''}`}
        >
          {!isPlayingFirst ? (
            <>
              <div className="qubely-block-videopopup-overlay"></div>
              <i className="fas fa-play qubely-btn-icon" onClick={handlePlayFirstVideo}></i>
            </>
          ) : (
            <iframe
              className="video-iframe"
              src="https://player.vimeo.com/video/d9749d6f-89ef-43c8-b441-7d8823702706?autoplay=1"
              frameBorder="0"
              allow="autoplay; fullscreen"
              allowFullScreen
              title="Super Memory Program Video 1"
            ></iframe>
          )}
        </div>
      </div>

      {/* Video popup container for the second video */}
      <div className="qubely-block-13">
        <div 
          className={`qubely-block-videopopup-wrapper qubely-alignment-center ${isPlayingSecond ? 'playing' : ''}`}
        >
          {!isPlayingSecond ? (
            <>
              <div className="qubely-block-videopopup-overlay"></div>
              <i className="fas fa-play qubely-btn-icon1" onClick={handlePlaySecondVideo}></i>
            </>
          ) : (
            <iframe
              className="video-iframe"
              src="https://player.vimeo.com/video/d9749d6f-89ef-43c8-b441-7d8823702706?autoplay=1"
              frameBorder="0"
              allow="autoplay; fullscreen"
              allowFullScreen
              title="Super Memory Program Video 2"
            ></iframe>
          )}
        </div>
      </div>

      <div style={{marginTop : '100px'}} className="wp-block-qubely-button qubely-block-c698c2">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn2">
                        <a className="qubely-block-btn-anchor is-large" href="https://www.profved.com/ap-math-genius-program-by-prof-ved-algebra-geometry-calculus-statistics/">
                            Enroll Now
                        </a>
                    </div>
                </div>
            </div>

            <div className="wp-block-qubely-button-book">
                <div className="qubely-block-btn-wrapper">
                    <div className="qubely-block-btn-book1">
                        <a className="qubely-block-btn-anchor is-large" href="https://www.profved.com/onboard.html?src=home">
                        Book A Free Demo Class
                        </a>
                    </div>
                </div>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 99" preserveAspectRatio="none">
    <path 
        d="M526.35,17.11C607.41,28.38,687,48.17,768.06,59.5A1149.19,1149.19,0,0,0,1000,68.07V0H0V99C155.18,13.84,347.42-7.77,526.35,17.11Z" 
        fill="#041a62" 
        transform="rotate(180 500 49.5)"  
    ></path>
</svg>

      {/* Shape Divider */}
    </div>
  );
};

export default SupperMemory;
