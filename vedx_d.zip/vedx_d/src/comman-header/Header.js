import React, { useState } from 'react';
import StickyButton from '../header/StickyButton';
import LoginPopup from '../header/LoginPopup';
import styled from 'styled-components';
import SignUp from '../header/Registration';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import { FaUserCircle } from 'react-icons/fa'; // Import a user profile icon
import './Header.css';
const NavbarWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 20px;
  background-color: #333;
  color: white;
`;

const DropdownMenu = styled.div`
  position: absolute;
  top: 60px;
  right: 40px;
  width: 200px;
  background-color: white;
  color: black;
  border-radius: 3px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  height: 360px;
  display: ${(props) => (props.show ? 'block' : 'none')};
  z-index: 10;    
 cursor: pointer;
  ul {
    list-style: none;
    padding: 0;
    margin : 0;
    border-radius: 3px;
   cursor: pointer;
    li {
      padding:  9px 9px 9px 30px;       
       cursor: pointer;
      &:hover {
        background-color: rgba(0, 0, 0, .05);
       cursor: pointer;
         
      }
    }
  }
`;

const Header = () => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const openLogin = () => setIsLoginOpen(true);
  const closeLogin = () => setIsLoginOpen(false);
  const openSignUpModal = () => setIsSignUpOpen(true);
  const closeSignUpModal = () => setIsSignUpOpen(false);
  const toggleDropdown = () => setIsDropdownOpen((prev) => !prev);

  return (
    <>
      <header id="masthead" className="site-header-header header-transparent disable-sticky">
        <div className="container-fluid">
          <div className="navbar-row d-flex align-items-center justify-content-between">
            {/* Logo Section */}
            <div className="logo-wrapper">
              <Link className="skillate-navbar-brand" to="/">
                <img
                  className="enter-logo img-responsive"
                  src="https://www.profved.com/wp-content/uploads/2022/03/VEDX-logo-cropped-website.png"
                  alt="Logo"
                  title="Logo"
                />
              </Link>
            </div>

            {/* Connect and Dashboard Menu (Centered) */}
            <div className="menu-center">
              <ul id="menu-main-menu" className="nav">
                <li className="menu-item">
                  <Link to="/connect-wth-prof-ved">CONNECT</Link>
                </li>
                <li className="menu-item">
                  <Link to="/dashboard">DASHBOARD</Link>
                </li>
              </ul>
            </div>

            {/* Cart, Login, Sign Up, and Profile Icon (Right Aligned) */}
            <div className="d-flex align-items-center right-section">
              {/* Cart */}
              <div className="skillate-header-cart mr-lg-2 d-none d-lg-inline-block">
                <div id="site-header-cart" className="site-header-cart menu">
                  <span className="cart-icon">
                    <img
                      src="https://www.profved.com/wp-content/themes/skillate/images/cart-icon.svg"
                      alt="Cart Icon"
                    />
                    <a className="cart-contents" href="#modal-cart" title="View your shopping cart">
                      <span className="count">0</span>
                    </a>
                  </span>
                </div>
              </div>

              {/* Login and Sign Up */}
              <div className="skillate-header-login ml-4">
                <div className="header-login-wrap">
                  <a href="#!" onClick={openLogin}>Login</a>
                  <span className="line_spe">|</span>
                  <a href="#!" onClick={openSignUpModal} className="ml-3">Sign Up</a>
                </div>
              </div>

              {/* Profile Icon with Dropdown */}
              {/* <div className="profile-icon ml-4" onClick={toggleDropdown} style={{ cursor: 'pointer' }}>
                <FaUserCircle size={30} color="white" />
              </div> */}

              {/* Dropdown Menu */}
              {/* <DropdownMenu show={isDropdownOpen}>
                <ul>
                  <li>Dashboard</li>
                  <li>My Profile</li>
                  <li>Enrolled Courses</li>
                  <li>Wishlist</li>
                  <li>Reviews</li>
                  <li>My Quiz Attempts</li>
                  <li>Purchase History</li>
                  <li>Settings</li>
                  <li>Logout</li>
                </ul>
              </DropdownMenu> */}
            </div>
          </div>
        </div>
      </header>

      {!isLoginOpen && !isSignUpOpen && <StickyButton />}
      <LoginPopup isOpen={isLoginOpen} onClose={closeLogin} />
      <SignUp isOpen={isSignUpOpen} onClose={closeSignUpModal} />

    </>
  );
};

export default Header;
