import React from 'react';
import './Footer.css'; // Ensure the styles are placed here
import { Link } from 'react-router-dom'; // Import Link from react-router-dom


const Footer = () => {
    return (
        <div id="bottom-wrap" className="footer">
            {/* Footer Top Section with Client Logos */}
            <div className="footer-top-section">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-12 text-center">
                            <div className="client-logo-carousel">
                                <div className="client-logo-single-widget">
                                    <img 
                                        src="https://www.profved.com/wp-content/uploads/2022/03/VEDX5.png" 
                                        alt="Client Logo" 
                                        className="client-logo" 
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Social Media Icons */}
            <div className="social-media-section text-center" style={{ backgroundColor: 'white', padding: '20px 0' }}>
                <ul className="sxc-follow-buttons d-flex justify-content-center list-unstyled">
                    <li className="sxc-follow-button mx-2">
                        <a href="https://www.instagram.com/theprofved/" title="Instagram" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/instagram.png" alt="Instagram" />
                        </a>
                    </li>
                    <li className="sxc-follow-button mx-2">
                        <a href="https://wa.me/16505055528" title="WhatsApp" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/whatsapp.png" alt="WhatsApp" />
                        </a>
                    </li>
                    <li className="sxc-follow-button mx-2">
                        <a href="mailto:profved@suphalaam.com" title="Email" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/email.png" alt="Email" />
                        </a>
                    </li>
                </ul>
            </div>

            {/* Footer Main Content */}
            <div className="container">
                <div className="row clearfix border-wrap">
                    {/* Column 1: About Section */}
                    <div className="col-sm-6 col-lg-3">
                        <div className="bottom-widget">
                            <h3 className="widget-title">Vedx – making children geniuses</h3>
                            <div className="about-desc">
                                Vedx Inc<br />
                                2055,<br />
                                Limestone Road, STE -<br />
                                200C<br />
                                Wilmington, Delaware 19808<br />
                                United States
                            </div>
                            <div className="themeum-about-info">
                                <span>
                                    <span className="mt-10">
                                        <img src="https://www.profved.com/wp-content/themes/skillate/images/phone-icon.svg" alt="Phone Icon" />
                                    </span>
                                    +1 415-255-5640
                                </span>
                                <span>
                                    <span className="mt-10" >
                                        <img src="https://www.profved.com/wp-content/themes/skillate/images/envelope-icon.svg" alt="Email Icon" />
                                    </span>
                                    info@vedx.us
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Column 2: Company Section */}
                    <div className="col-6 col-lg-3">
                        <div className="bottom-widget">
                            <h3 className="widget-title">Company</h3>
                            <div className="menu">
                              <span><Link href="https://www.profved.com/about-prof-ved/">About Prof Ved</Link></span>  <br />
                              <span> <Link href="https://www.profved.com/profved/contact">Contact</Link> </span><br />
                              <span> <Link href="https://www.profved.com/privacy-policy/">Privacy Policy <br /> & Terms & Conditions</Link></span> 
                            </div>
                        </div>
                    </div>

                    {/* Column 3: Resources Section */}
                    <div className="col-6 col-lg-3">
                        <div className="bottom-widget">
                            <h3 className="widget-title">Resources</h3>
                            <p>
                                <Link href="https://www.profved.com/math-kangaroo-competition-previous-year-question-papers-and-answer-keys/">
                                    Math Kangaroo Test Papers
                                </Link>
                            </p>
                        </div>
                    </div>

                    {/* Column 4: Support Section */}
                    <div className="col-6 col-lg-3">
                        <div className="bottom-widget">
                            <h3 className="widget-title">Support</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div className="social-media-section text-center" style={{ backgroundColor: 'white', padding: '20px 0' }}>
                <ul className="sxc-follow-buttons d-flex justify-content-center list-unstyled">
                    <li className="sxc-follow-button mx-2">
                        <a href="https://www.instagram.com/theprofved/" title="Instagram" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/instagram.png" alt="Instagram" />
                        </a>
                    </li>
                    <li className="sxc-follow-button mx-2">
                        <a href="https://wa.me/16505055528" title="WhatsApp" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/whatsapp.png" alt="WhatsApp" />
                        </a>
                    </li>
                    <li className="sxc-follow-button mx-2">
                        <a href="mailto:profved@suphalaam.com" title="Email" target="_blank" rel="noopener noreferrer">
                            <img src="https://www.profved.com/wp-content/plugins/social-media-buttons-toolbar/inc/img/social-media-icons/email.png" alt="Email" />
                        </a>
                    </li>
                </ul>
            </div>

            {/* Footer Copyright Section */}
            <div className="footer-copyright">
                <p>2023 www.profved.com All Rights Reserved.</p>
            </div>
        </div>
    );
};

export default Footer;
