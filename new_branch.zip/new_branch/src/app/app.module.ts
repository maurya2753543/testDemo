import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LandingComponent } from './components/landing/landing.component';
import { TitleBarComponent } from './components/title-bar/title-bar.component';
import { MenuBarComponent } from './components/menu-bar/menu-bar.component';
import { NavPanelComponent } from './components/nav-panel/nav-panel.component';
import { AngularSvgIconModule} from 'angular-svg-icon';
import { FontAwesomeModule, FaIconLibrary} from '@fortawesome/angular-fontawesome'
import { MatMenuModule} from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule} from '@angular/material/button';
import { MatSidenavModule} from '@angular/material/sidenav';
import { MatTooltipModule} from '@angular/material/tooltip';
import { MatTabsModule} from '@angular/material/tabs'
import { ProjectPanelComponent } from './components/project/project-panel/project-panel.component';
import { ProjectInfoPanelComponent } from './components/project/project-info-panel/project-info-panel.component';
import { TestGridPanelComponent } from './components/test-grid-panel/test-grid-panel.component';
import { TestToolbarPanelComponent } from './components/test-toolbar-panel/test-toolbar-panel.component';
import { ProjectNavPanelComponent } from './components/project/project-nav-panel/project-nav-panel.component';
import { AgGridModule } from 'ag-grid-angular';
import { MatTreeModule } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { ProjectNavToolbarComponent } from './components/project/project-nav-toolbar/project-nav-toolbar.component';
import { StatusBarComponent } from './components/status-bar/status-bar.component';
import { ProjectsService } from './services/projects.service';
import { MatDialogModule } from '@angular/material/dialog'
import { MatNativeDateModule} from '@angular/material/core';
import { ResizableModule } from "angular-resizable-element";
import { TestDetailPanelComponent } from './components/test/test-detail-meas/test-detail-meas.component';
import { TestDetailTabsComponent } from './components/test/test-detail-tabs/test-detail-tabs.component';
import { TestConfigurationComponent } from './components/test/test-detail-configuration/test-detail-configuration.component';
import { TestInstrumentComponent } from './components/test/test-detail-instrument/test-detail-instrument.component';
import { MatBadgeModule } from '@angular/material/badge';
import { AngularSplitModule } from 'angular-split';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule  }   from '@angular/forms';
import { CustomSideBarComponent } from './components/custom-side-bar/custom-side-bar.component';
import { moveFilesDialogComponent } from './components/move-files-dialog/move-files-dialog.component'
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatTableModule } from '@angular/material/table';
import { HighlightPipe } from './pipes/highlight.pipe';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { TestDetailMeasurementTitleComponent } from './components/test/test-detail-meas-title/test-detail-meas-title.component';
import { TestDetailMeasurementInfoComponent } from './components/test/test-detail-meas-info/test-detail-meas-info.component';
import { TestDetailMeasurementResultOpticalPowerComponent } from './components/test/test-detail-meas-result-optical-power/test-detail-meas-result-optical-power.component';
import { TitleCaseWordPipe } from './pipes/title-case-word.pipe';
import { TestDetailMeasurementResultTruePonComponent } from './components/test/test-detail-meas-result-truepon/test-detail-meas-result-truepon.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { TestMeasurementOpticalLossComponent } from './components/test/test-detail-meas-optical-loss/test-detail-meas-optical-loss.component';
import { TestMeasurementInspectionComponent } from './components/test/test-detail-meas-inspection/test-detail-meas-inspection.component';
import { TestMeasurementOtdrComponent } from './components/test/test-detail-meas-otdr/test-detail-meas-otdr.component';
import { TestDetailExpandCollapseComponent } from './components/test/test-detail-expand-collapse/test-detail-expand-collapse.component';
import { PassFailColorPipe } from './pipes/pass-fail-color.pipe';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { EventsTableComponent } from './components/events-table/events-table.component';
import { PopupInputComponent } from './components/popup-input/popup-input.component';
import { PopupPdfComponent } from './components/popup-pdf/popup-pdf.component';
import { ReportsInformationsComponent } from './components/reports-informations/reports-informations.component';
import { ProfileManagerComponent } from './components/profile-manager/profile-manager.component';
import { SettingsProjectComponent } from './components/settings-project/settings-project.component';
import { GlobalSettingsComponent } from './components/global-settings/global-settings.component';
import { TestDetailMeasOntDetectonComponent } from './components/test/test-detail-meas-ont-detecton/test-detail-meas-ont-detecton.component';
import { TestDetailMeasInspectionMpoComponent } from './components/test/test-detail-meas-inspection-mpo/test-detail-meas-inspection-mpo.component';
import { TestDetailMeasTier1Component } from './components/test/test-detail-meas-tier1/test-detail-meas-tier1.component';
import { TestDetailMeasTier1MpoComponent } from './components/test/test-detail-meas-tier1-mpo/test-detail-meas-tier1-mpo.component';
import { TestDetailMeasFcproComponent } from './components/test/test-detail-meas-fcpro/test-detail-meas-fcpro.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ProjectMenuComponent } from './components/project-menu/project-menu.component';
import { ConvertToHexPipe } from './pipes/convert-to-hex.pipe';
import { InstrumentCommsPanelComponent } from './components/instrument-comms-panel/instrument-comms-panel.component';
import { ProjectsTreeComponent } from './components/project/projects-tree/projects-tree.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { ReplaceTechnicianComponent } from './components/replace-technician/replace-technician.component';
import { ReplacecableIdComponent } from './components/replace-cable-id/replace-cable-id.component';
import { MarkdownComponent } from './components/markdown/markdown.component'
import { MarkdownModule } from 'ngx-markdown';
import { DetailsPdfPopupComponent } from './components/details-pdf-popup/details-pdf-popup.component';
import { DetailsCsvPopupComponent } from './components/details-csv-popup/details-csv-popup.component'



// ModuleRegistry.registerModules([
//   ClientSideRowModelModule,
//   RowGroupingModule,
//   MenuModule,
//   SetFilterModule,
//   ColumnsToolPanelModule,
//   SideBarModule
// ]);


// ModuleRegistry.registerModules([
//   ClientSideRowModelModule,
//   MenuModule,
//   ColumnsToolPanelModule,
// ]);
@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    TitleBarComponent,
    MenuBarComponent,
    NavPanelComponent,
    ProjectPanelComponent,
    ProjectInfoPanelComponent,
    TestGridPanelComponent,
    TestToolbarPanelComponent,
    ProjectNavPanelComponent,
    ProjectNavToolbarComponent,
    StatusBarComponent,
    TestDetailPanelComponent,
    TestDetailTabsComponent,
    TestConfigurationComponent,
    TestInstrumentComponent,
    CustomSideBarComponent,
    moveFilesDialogComponent,
    HighlightPipe,
    TestDetailMeasurementTitleComponent,
    TestDetailMeasurementInfoComponent,
    TestDetailMeasurementResultOpticalPowerComponent,
    TitleCaseWordPipe,
    TestDetailMeasurementResultTruePonComponent,
    TestMeasurementOpticalLossComponent,
    TestMeasurementInspectionComponent,
    TestMeasurementOtdrComponent,
    TestDetailExpandCollapseComponent,
    PassFailColorPipe,
    LineChartComponent,
    ConfirmationDialogComponent,
    EventsTableComponent,
    PopupInputComponent,
    PopupPdfComponent,
    ReportsInformationsComponent,
    ProfileManagerComponent,
    SettingsProjectComponent,
    GlobalSettingsComponent,
    TestDetailMeasOntDetectonComponent,
    TestDetailMeasInspectionMpoComponent,
    TestDetailMeasTier1Component,
    TestDetailMeasTier1MpoComponent,
    TestDetailMeasFcproComponent,
    ProjectMenuComponent,
    ConvertToHexPipe,
    InstrumentCommsPanelComponent,
    ProjectsTreeComponent,
    ReplaceTechnicianComponent,
    ReplacecableIdComponent,
    MarkdownComponent,
    DetailsPdfPopupComponent,
    DetailsCsvPopupComponent,



  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MarkdownModule.forRoot({ loader: HttpClient }),
    FontAwesomeModule,
    MatMenuModule,
    MatDividerModule,
    MatButtonModule,
    MatSidenavModule,
    MatTooltipModule,
    AgGridModule,
    MatTreeModule,
    MatIconModule,
    MatDialogModule,
    MatNativeDateModule,
    MatTabsModule,
    ResizableModule,
    MatBadgeModule,
    AngularSplitModule,
    AngularSvgIconModule.forRoot(),
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatTableModule,
    DragDropModule,
    MatGridListModule,
    MatCheckboxModule,
    MatSnackBarModule,
  
    
  ],
  exports: [MatSelectModule],
  providers: [ProjectsService, TestGridPanelComponent],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule {
    constructor( ) {

    }
}
