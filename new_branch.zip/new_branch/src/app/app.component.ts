import { Component, NgZone } from '@angular/core';
import { InstrumentsService } from './services/instruments.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ReportPRO';
  showNotification = false
  showRestartButton = false
  message = ''

    constructor(public zone: NgZone, public instService : InstrumentsService) {

        window.api?.updateEvent(this.handleUpdateEvent.bind(this))
        instService.Initialize();

    }

    private handleUpdateEvent(type: string, version: string) {
        this.zone.run(() => {
          switch (type) {
            case 'available':
              this.message = `A new update ${version} is available. Downloading now...`
              this.showNotification = true
              break
            case 'downloaded':
              this.message = `Update ${version} downloaded. It will be installed on restart. Restart now?`
              this.showRestartButton = true
              this.showNotification = true
              break
          }
        })
      }
    
      hideNotification() {
        this.showNotification = false
        this.showRestartButton = false
      }
    
      restartApp() {
        this.showNotification = false
        window.api?.restartApp()
      }

}
