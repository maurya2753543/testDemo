import { Range } from './range.model';

describe('Range', () => {
  it('should create an instance', () => {
    expect(new Range()).toBeTruthy();
  });
});
