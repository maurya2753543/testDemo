import {BehaviorSubject} from 'rxjs'
// import {SpectrogramIrModel} from '../models/ir/spectrogram-ir-model'
// import {GraphHelper} from './graph-helper'
import { Range } from 'src/app/models/ir/range.model'
import {IconDefinition} from '@fortawesome/fontawesome-svg-core'
import {
  faChartLine,
  faChartLineDown,
  faChartScatter3d,
  faChartSimpleHorizontal,
  faChartWaterfall
} from '@fortawesome/pro-solid-svg-icons'

export enum GraphType {
  ThreeDCanvas,
  LineGraph,
  Heatmap,
  PersistentSpectrum,
  Rssi,
  Error
}

export class GraphDef {
  constructor(
    public title: string,
    public graphType: GraphType,
    public icon: IconDefinition) {
  }
}

export const GraphDefs: Array<GraphDef> = [
  new GraphDef('Line Graph', GraphType.LineGraph, faChartLine),
  new GraphDef('3D Canvas', GraphType.ThreeDCanvas, faChartScatter3d),
  new GraphDef('HeatMap', GraphType.Heatmap, faChartSimpleHorizontal),
  new GraphDef('Persistent Spectrum', GraphType.PersistentSpectrum, faChartWaterfall),
  new GraphDef('RSSI', GraphType.Rssi, faChartLineDown)
]

export class ZoomRegion {
  freqMin = 0
  ampMin = 0
  freqMax = 0
  ampMax = 0
  active = false

  constructor() {}

  update(
    freqMin: number,
    ampMin: number,
    freqMax: number = freqMin,
    ampMax: number = ampMin
  ) {
    this.freqMin = freqMin
    this.freqMax = freqMax
    this.ampMin = ampMin
    this.ampMax = ampMax
    this.active = true
  }
}

export class DisplayWindow {
  windowSize = new BehaviorSubject<DisplayWindow>(this)
  zoomRegion: ZoomRegion = new ZoomRegion()

  private internalFreqMin: number
  private internalFreqMax: number
  private internalAmplitudeIncrement: number
  private internalAmplitudeReference: number
  private internalGraphType: GraphType

  private static readonly incrementOptions = [10, 5, 2, 1]
  private readonly autoScaleRange: Range

  get graphType(): GraphType {
    return this.internalGraphType
  }

  set graphType(value: GraphType) {
    this.internalGraphType = value
    this.windowSize.next(this)
  }

  autoScale(){
    this.amplitudeIncrement = (this.autoScaleRange.max - this.autoScaleRange.min) / 10
    this.amplitudeReference = this.autoScaleRange.max
  }

  get amplitudeIncrement(): number {
    return this.internalAmplitudeIncrement
  }
  set amplitudeIncrement(value: number) {
    // Find the integer ceiling of the incoming value in the reversed incrementOptions array
    const options = [...DisplayWindow.incrementOptions].reverse()
    const incrementValue = options.filter(it => value <= it)[0] ?? DisplayWindow.incrementOptions[0]
    if (incrementValue != this.internalAmplitudeIncrement) {
      this.internalAmplitudeIncrement = incrementValue
      this.windowSize.next(this)
    }
  }
  get amplitudeIncrementString(): string {
    return this.internalAmplitudeIncrement.toString()
  }
  set amplitudeIncrementString(value: string) {
    this.amplitudeIncrement = parseFloat(value)
  }

  get amplitudeReference(): number {
    return this.internalAmplitudeReference
  }
  set amplitudeReference(value: number) {
    this.internalAmplitudeReference = value
    this.windowSize.next(this)
  }

  get amplitudeReferenceString(): string {
    return this.amplitudeReference.toString()
  }
  set amplitudeReferenceString(value: string) {
    this.amplitudeReference = parseFloat(value)
  }

  get amplitudeMin(): number {
    return this.internalAmplitudeReference - (10 * this.internalAmplitudeIncrement)
  }

  get freqMinString(): string {
    return this.freqMin.toString()
  }
  set freqMinString(value: string) {
    if (value) {
      this.freqMin = parseFloat(value)
    } else {
      this.freqMin = 0
    }
  }
  get freqMin(): number {
    return this.internalFreqMin
  }
  set freqMin(value: number) {
    this.internalFreqMin = this.bounded(value, 0, this.internalFreqMax)
    this.windowSize.next(this)
  }

  get freqMaxString(): string {
    return this.freqMax.toString()
  }
  set freqMaxString(value: string) {
    if (value) {
      this.freqMax = parseFloat(value)
    } else {
      this.freqMax = 0
    }
  }
  get freqMax(): number {
    return this.internalFreqMax
  }
  set freqMax(value: number) {
    this.internalFreqMax = this.bounded(value, this.internalFreqMin)
    this.windowSize.next(this)
  }

  get freqCenterString(): string {
    return this.freqCenter.toString()
  }
  set freqCenterString(value: string) {
    if (value) {
      this.freqCenter = parseFloat(value)
    } else {
      this.freqCenter = 0
    }
  }
  get freqCenter(): number {
    return (this.freqMax - this.freqMin) / 2 + this.freqMin
  }
  set freqCenter(value: number) {
    value = this.bounded(value)
    const halfSpan = this.bounded(this.freqSpan / 2, 0, value)
    this.freqMin = value - halfSpan
    this.freqMax = value + halfSpan
  }

  get freqSpanString(): string {
    return this.freqSpan.toString()
  }
  set freqSpanString(value: string) {
    if (value) {
      this.freqSpan = parseFloat(value)
    } else {
      this.freqSpan = 0
    }
  }
  get freqSpan(): number {
    return (this.freqMax - this.freqMin)
  }
  set freqSpan(value: number) {
    const halfSpan = this.bounded(value / 2, 0, this.freqCenter)
    const center = this.freqCenter
    this.freqMin = center - halfSpan
    this.freqMax = center + halfSpan
  }

   autoScaleAmp(range: Range): Range {
    const rangeDiff = Math.abs(range.max - range.min)
    const logRangeDiff = Math.log10(rangeDiff)
    if (logRangeDiff > 1) {
      return new Range(
        this.floorToNearest(range.min - 10, 10),
        this.ceilToNearest(range.max + 10, 10))
    }
    else if (logRangeDiff < 1 && logRangeDiff >=0) {
      return new Range(range.min - 1, range.max + 1)
    }
    else if (logRangeDiff < 0 && logRangeDiff >=-1) {
      return new Range(
        this.floorToNearest(range.min - 0.1, 10),
        this.ceilToNearest(range.max + 0.1, 10))
    }
    else if (logRangeDiff < -1 && logRangeDiff >=-2) {
      return new Range(
        this.floorToNearest(range.min - .01, 100),
        this.ceilToNearest(range.max + .01, 10))
    }
    else if (logRangeDiff < -2 && logRangeDiff >=-3) {
      return new Range(
        this.floorToNearest(range.min - .001, 1000),
        this.ceilToNearest(range.max + .001, 10))
    }
    return new Range(0, -100)
  }

    // Generic Math functions
     floorToNearest(n: number, magnitude: number) {
        return Math.floor(n/magnitude) * magnitude
      }
    
       ceilToNearest(n: number, magnitude: number) {
        return Math.ceil(n/magnitude) * magnitude
      }
    
       round(n: number, places: number) {
        return Math.round(n * Math.pow(10, places))/Math.pow(10, places)
      }
    

  constructor(public spectrogramIR: any) {
    this.autoScaleRange = this.autoScaleAmp(new Range(spectrogramIR.amplitudeMin, spectrogramIR.amplitudeMax))
    this.internalFreqMin = spectrogramIR.freqMin ?? 0
    this.internalFreqMax = spectrogramIR.freqMax ?? 0
    this.internalAmplitudeIncrement = this.spectrogramIR.scaleDivision
    this.internalAmplitudeReference = this.spectrogramIR.reference
    this.internalGraphType = GraphType.LineGraph
  }

  private bounded(value: number, lower: number = 0, upper: number = Number.MAX_SAFE_INTEGER): number {
    return Math.max(lower, Math.min(upper, value))
  }
}
