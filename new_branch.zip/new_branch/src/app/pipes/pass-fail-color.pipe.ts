import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'passFailColor'
})
export class PassFailColorPipe implements PipeTransform {

  transform(value: string): string {
    if (value.toLowerCase() == 'pass') {
      return `<span class="pass-color" i18n ><i class="fa fa-circle-check" ></i>` +  " " + value.toUpperCase() + `</span>`;
    } else if (value.toLowerCase() == 'none') {
      return `<span style="color: gray" i18n ><i class="fa-solid fa-circle-question" ></i>` +  " " + value.toUpperCase() + `</span>`;
    } else {
      return `<span class="fail-color"' i18n ><i class="fa fa-circle-xmark" ></i>` +  " " +value.toUpperCase() + `</span>`;
    }

    // return value;
  }

}
