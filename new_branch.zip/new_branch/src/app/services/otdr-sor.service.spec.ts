import { TestBed } from '@angular/core/testing';

import { OtdrSorService } from './otdr-sor.service';

describe('OtdrSorService', () => {
  let service: OtdrSorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OtdrSorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
