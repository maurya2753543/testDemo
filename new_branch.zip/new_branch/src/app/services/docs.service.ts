import { Injectable } from '@angular/core';
import { Router } from '@angular/router'

interface DocDescriptor {
    doc: string
    section?: string
  }
  
  interface WindowLookup {
    [key: string]: Window | null
  }

@Injectable({
  providedIn: 'root'
})
export class DocsService {

    private openWindows: WindowLookup = {}

    constructor(private router: Router) { }
  
    open(descriptor: DocDescriptor): void {
      const url = this.router.serializeUrl(this.router.createUrlTree(['docs'], { queryParams: descriptor }))
  
      // If the requested window is already open, close it
      const oldWindow = this.openWindows[descriptor.doc]
      if (oldWindow && !oldWindow.closed) oldWindow?.close()
  
      // (Re)open the requested window
      this.openWindows[descriptor.doc] = window.open(url, '_blank')
    }
}
