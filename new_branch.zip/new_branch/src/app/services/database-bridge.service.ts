import { Injectable } from '@angular/core';
import '../window-extensions'

@Injectable({
  providedIn: 'root'
})
export class DatabaseBridgeService {

  constructor() {

   }

  //----------------------------------------------------------------- 
  //createConfigDocument() {}

 //----------------------------------------------------------------- 
 getAllProjects() {

    console.log("Db-Bridge getAllProject ");
    window.db.getAllProjects();

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.getAllProjectsMsg( (event:any, response:any) => {
            console.log("DB-Bridge resp: ", event, response);
            resolve( response );
        })
    
    })
    return myPromise
  }


   //----------------------------------------------------------------- 
  createProject(name: any, defaultSettings: any ) {

    console.log("DBB create porject", name, defaultSettings);
    window.db.createProject(name, defaultSettings);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.createProjectMsg( (event:any, response:any) => {
            console.log("Db Update: ", response);
            resolve( response );
        })
    
    })
    return myPromise
  }
  //----------------------------------------------------------------- 
  addProjectFolder(name:string, parentId: any, projectId: any) {

    window.db.addProjectFolder(name, parentId, projectId);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.addProjectFolderMsg( (response: any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
    getDocumentId(id: any) {

    window.db.getDocumentId(id);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.getDocumentIdMsg( (event:any, settings:any) => {
            //console.log("Db Update: ", settings);
            resolve( settings );
        })
    
    })
    return myPromise
  }
  //----------------------------------------------------------------- 
  addResultFile (
    name : string,
    parent : any,
    projectId : any,
    content : any,
    type : string
  ) {
    // Call the main side function
    window.db.addResultFile(name, parent, projectId, content, type);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.addResultFileMsg( (event:any, response:any) => {
            console.log("Db addResultFileMsg ", response);
            resolve( response );
        })
    
    })
    return myPromise
  };

  //----------------------------------------------------------------- 
  //addAttachment(id: any, rev: any, attachmentId: any, attachment: any, format: any) {}

  //----------------------------------------------------------------- 
  getResultsGrid(id: any) {

    // Call the main side function
    window.db.getResultsGrid(id);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.getResultsGridMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
  getChildrenOfDocument(id : any) {

    // Call the main side function
    window.db.getChildrenOfDocument(id);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.getChildrenOfDocumentMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
  updateDocument(doc : any) {
    // Call the main side function
    window.db.updateDocument(doc);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.updateDocumentMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
  public async deleteDocId(id: any, rev: any ) {

    console.log("DBB delete doc id ", id, rev);
    // Call the main side function
    window.db.deleteDocId(id, rev);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.deleteDocIdMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
  public async getAppSettings(): Promise<any> {

        // Call the main side function
        window.db.getAppSettings();

        let myPromise: any = new Promise<any>( function( resolve, reject) {
            // wait for the response
            window.db.getAppSetingsMsg( (event:any, settings:any) => {
                //console.log("Db Update: ", settings);
                resolve( settings );
            })
        
        })
        return myPromise

  }

  //----------------------------------------------------------------- 
  setAppSettings(settings : any ) {

    // Call the main side function
    window.db.setAppSettings(settings);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.setAppSetingsMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

  //----------------------------------------------------------------- 
  getAllDatabaseInfo() {

    // Call the main side function
    window.db.getDatabaseInfo("key", "defaultValue");

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.getDatabaseInfoMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
  }

   //----------------------------------------------------------------- 
   createIndex() {}

   //----------------------------------------------------------------- 
   exportProject(projectId:any, filename:any, remove:boolean) {
    // Call the main side function
    window.db.exportProject(projectId, filename, remove);

    let myPromise: any = new Promise<any>( function( resolve, reject) {
        // wait for the response
        window.db.exportProjectMsg( (event:any, response:any) => {
            //console.log("Db Update: ", settings);
            resolve( response );
        })
    
    })
    return myPromise
   }

   //----------------------------------------------------------------- 
   importProject( target: any ) {
     // Call the main side function
     window.db.importProject(target);

     let myPromise: any = new Promise<any>( function( resolve, reject) {
         // wait for the response
         window.db.importProjectMsg( (event:any, response:any) => {
             //console.log("Db Update: ", settings);
             resolve( response );
         })
     
     })
     return myPromise
   }


   
}