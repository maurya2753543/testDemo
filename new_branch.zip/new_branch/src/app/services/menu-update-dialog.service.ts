import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
@Injectable({
  providedIn: 'root'
})
export class menuUpdateDialogService {
  constructor(private dialog: MatDialog) { }

  update(data: any, DarkThemesApply: boolean, select: string) {

  }

  closeDialog() {
    this.dialog.closeAll()
  }
}
