import * as parts from './parts.js'

const showDebug = false;
function logger( value ) {
    if( showDebug ) {
        console.log( value );
    }
}

export function parseGenParams(data, offset) {

    let namePad = 25;

    logger("-----------------------------------------");
    let str = parts.get_string( data, offset);
    logger( str );
    logger("-----------------------------------------");
    offset += str.length + 1;

    let lang = parts.get_stringFixed( data, offset, 2);
    logger( "Language: ".padEnd(namePad) + lang)
    offset += 2

    let label = parts.get_string( data, offset);
    logger( "Label: ".padEnd(namePad) + label );
    offset += label.length + 1;

    let fiberId = parts.get_string( data, offset);
    logger( "Fiber Id: ".padEnd(namePad) + fiberId );
    offset += fiberId.length + 1;

    let fiberType = data.readInt16LE( offset );
    fiberType = fiber_type(fiberType);
    logger( "Fiber Type: ".padEnd(namePad) + fiberType);
    offset += 2;

    let wavelength = data.readInt16LE( offset );
    logger( "Wavelength: ".padEnd(namePad) + wavelength);
    offset += 2;

    let locA = parts.get_string( data, offset);
    logger( "Location A: ".padEnd(namePad) + locA );
    offset += locA.length + 1;

    let locB = parts.get_string( data, offset);
    logger( "Location B: ".padEnd(namePad) + locB );
    offset += locB.length + 1;

    let cableCode = parts.get_string( data, offset);
    logger( "cable code/fiber type: ".padEnd(namePad) + cableCode );
    offset += cableCode.length + 1;

    let bc = parts.get_stringFixed( data, offset, 2);
    bc = build_condition(bc)
    logger( "Build condition: ".padEnd(namePad) + bc)
    offset += 2

    let userOffset = data.readUInt32LE(offset);
    logger( "User offset: ".padEnd(namePad) + userOffset);
    offset += 4;
    
    let userOffsetDist = data.readUInt32LE(offset);
    logger( "User offset distance: ".padEnd(namePad) + userOffsetDist);
    offset += 4;

    let operator = parts.get_string( data, offset);
    logger( "Operator: ".padEnd(namePad) + operator );
    offset += operator.length + 1;

    let comment = parts.get_string( data, offset);
    logger( "Comment: ".padEnd(namePad) + comment );

    //offset += comment.length + 1;
    
    // let fields = [
    //     "cable ID",    // ........... 0
    //     "fiber ID",    // ........... 1
        
    //     "fiber type",  // ........... 2: fixed 2 bytes value
    //     "wavelength",  // ............3: fixed 2 bytes value
        
    //     "location A", // ............ 4
    //     "location B", // ............ 5
    //     "cable code/fiber type", // ............ 6
    //     "build condition", // ....... 7: fixed 2 bytes char/string
    //     "user offset", // ........... 8: fixed 4 bytes int (Andrew Jones)
    //     "user offset distance", // .. 9: fixed 4 bytes int (Andrew Jones)
    //     "operator",    // ........... 10
    //     "comments",    // ........... 11
    // ];

    let genParams = {
        "language": lang,
        "cable ID": label,
        "fiber ID": fiberId,
        "fiber type": fiberType,
        "wavelength": wavelength,
        "location A": locA,
        "location B": locB,
        "cable code/fiber type": cableCode,
        "build condition": bc,
        "user offset": userOffset,
        "user offset distance": userOffsetDist,
        "operator": operator,
        "comments": comment

    }
    return genParams;

}


export function process( fh, results, logger, errlog, debug=false)
{
    let bname = "GenParams";
    let hsize = bname.length + 1; // include trailing '\0'
    let pname = "genparam.process():"
    let ref = null;
    let status = 'nok'

    try {
        ref = results['blocks'][bname];
        let startpos = ref['pos'];
        fh.seek( startpos );
    }catch(e){
        errlog( pname+" "+bname+"block starting position unknown");
        return status;
    }

    let format = results['format'];
    
    if (format == 2) {
        let mystr = parts.get_string(fh, hsize);

        if ( mystr != bname ) {
            errlog(pname+" incorrect header '"+mystr+"' vs '"+bname+"'");
            return status
	}
    }
    
    results[bname] = {};
    //let xref = results[bname];
    
    // if (format == 1) {
    //     status = process1(fh, results, logger, errlog, debug);
    // }else{
    //     status = process2(fh, results, logger, errlog, debug);
    // }
    
    return 'ok';
}

// ================================================================
function build_condition(bcstr) {
    // decode build condition
    if (bcstr == 'BC') {
        bcstr += " (as-built)";
    }else if (bcstr == 'CC') {
        bcstr+= " (as-current)";
    }else if (bcstr == 'RC') {
        bcstr+= " (as-repaired)";
    }else if (bcstr == 'OT') {
        bcstr+= " (other)";
    }else{
        bcstr+= " (unknown)";
    }
    return bcstr;
};

// ================================================================
function fiber_type(val) {
    /*
     * decode fiber type 
     * REF: http://www.ciscopress.com/articles/article.asp?p=170740&seqNum=7
     */
    let fstr;
    if (val == 651) { // ITU-T G.651
        fstr = "G.651 (50um core multimode)";
    }else if (val == 652) { // standard nondispersion-shifted 
        fstr = "G.652 (standard SMF)";
	// G.652.C low Water Peak Nondispersion-Shifted Fiber            
    }else if (val == 653) {
        fstr = "G.653 (dispersion-shifted fiber)";
    }else if (val == 654) {
        fstr = "G.654 (1550nm loss-minimzed fiber)";
    }else if (val == 655) {
        fstr = "G.655 (nonzero dispersion-shifted fiber)";
    }else{
        fstr = `${val} (unknown)`;
    }
    return fstr;
};

// ================================================================
export function process1(fh, results, logger, errlog, debug) {
    // process version 1 format
    let bname = "GenParams";
    let xref  = results[bname];
    
    let lang = fh.readString(2);
    xref['language'] = lang;
    if (debug) {
        logger(`${sep}  language: '${lang}', next pos ${fh.tell()}`)
    }

    let fields = [
        "cable ID",    // ........... 0
        "fiber ID",    // ........... 1
        "wavelength",  // ............2: fixed 2 bytes value
        
        "location A",  // ........... 3
        "location B",  // ........... 4
        "cable code/fiber type", //.. 5
        "build condition", // ....... 6: fixed 2 bytes char/string
        "user offset", // ........... 7: fixed 4 bytes (Andrew Jones)
        "operator",    // ........... 8
        "comments",    // ........... 9
    ];
    
    let count = 0
    let xstr = "";
    let val = "";
    // fields.forEach( async function(field) { // !!! not async
    for( let i in fields ) {
	let field = fields[i];
	
        if (field == 'build condition') {
            xstr = build_condition( fh.read(2) );
        }else if (field == 'wavelength') {
            val = parts.get_uint(fh, 2);
            xstr = `${val} nm`;
        }else if (field == "user offset") {
            val = parts.get_signed(fh, 4)
            xstr = parseInt(val, 10).toString();
        }else{
            xstr = parts.get_string(fh);
        }
        if (debug ) {
            logger(`${sep} ${count}. ${field}: ${xstr}`);
        }
        xref[field] = xstr;
        count += 1
    }
    
    //status = 'ok';
    //return; // status;
}

// ================================================================
export function process2(fh, results, logger, errlog, debug) {
    // process version 2 format
    let bname = "GenParams";
    let xref  = results[bname];
    
    let lang = fh.readString(2);
    xref['language'] = lang;
    if (debug) {
        logger(`${sep}  language: '${lang}', next pos ${ fh.tell()}`);
    }    
    let fields = [
        "cable ID",    // ........... 0
        "fiber ID",    // ........... 1
        
        "fiber type",  // ........... 2: fixed 2 bytes value
        "wavelength",  // ............3: fixed 2 bytes value
        
        "location A", // ............ 4
        "location B", // ............ 5
        "cable code/fiber type", // ............ 6
        "build condition", // ....... 7: fixed 2 bytes char/string
        "user offset", // ........... 8: fixed 4 bytes int (Andrew Jones)
        "user offset distance", // .. 9: fixed 4 bytes int (Andrew Jones)
        "operator",    // ........... 10
        "comments",    // ........... 11
    ];

    let count = 0;
    let xstr = "";
    let val = "";
    for(let i in fields ) {
	let field = fields[i];
        if ( field == 'build condition' ) {
            xstr = build_condition( fh.read(2) );
        }else if (field == 'fiber type') {
            val = parts.get_uint(fh, 2);
            xstr = fiber_type( val );
        }else if (field == 'wavelength') {
            val = parts.get_uint(fh, 2);
            xstr = `${val} nm`;
        }else if (field == "user offset" || field == "user offset distance") {
            val = parts.get_signed(fh, 4);
            xstr = parseInt(val, 10).toString();
	}else{
            xstr = parts.get_string(fh);
        }
        if (debug) {
            logger(`${sep} ${count}. ${field}: ${xstr}`);
        }
        xref[field] = xstr;
        count += 1
    }
    // status = 'ok';
    
     //return; // status;
}