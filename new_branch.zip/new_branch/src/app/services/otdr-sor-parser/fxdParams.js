import * as parts from './parts.js'

const showDebug = false;
function logger( value ) {
    if( showDebug ) {
        console.log( value );
    }
}

export function parseFixParams(data, offset) {

    let namePad = 32

    logger("-----------------------------------------");
    var str = parts.get_string( data, offset);
    logger( str );
    logger("-----------------------------------------");
    offset += str.length + 1;

/* functions to use
     * 'h': get_hexstring
     * 'v': get_uint
     * 's': get_string
     * 'i': get_signed
     */
    // name, start-pos, length (bytes), type, multiplier, precision, units

    //["date/time",0,4,'v','','',''], // ............... 0-3 seconds in Unix time
    let timestamp = data.readUInt32LE(offset);
    let ts = new Date( timestamp * 1000);
    logger( "timestamp: ".padEnd(namePad) + ts.toISOString() );
    offset += 4;

    //["unit",4,2,'s','','',''], // .................... 4-5 distance units, 2 char (km,mt,ft,kf,mi)
    let units = parts.get_stringFixed( data, offset, 2);
    logger( "Units: ".padEnd(namePad) + units);
    offset += 2;
    
    //["wavelength",6,2,'v',0.1,1,'nm'], // ............ 6-7 wavelength (nm)
    let wavelength = data.readUInt16LE( offset ) * 0.1;
    logger( "Wavelength: ".padEnd(namePad) + wavelength);
    offset += 2;
    
    // from Andrew Jones
    //["acquisition offset",8,4,'i','','',''], // .............. 8-11 acquisition offset; units?
    let acquisition_offset = data.readInt32LE(offset);
    logger( "Acquisition offset: ".padEnd(namePad) + acquisition_offset);
    offset += 4;

    //["acquisition offset distance",12,4,'i','','',''], // .... 12-15 acquisition offset distance; units?
    let acquisition_offset_distance = data.readInt32LE(offset);
    logger( "Acquisition offset distance: ".padEnd(namePad) + acquisition_offset_distance);
    offset += 4;

    //["number of pulse width entries",16,2,'v','','',''], // .. 16-17 number of pulse width entries
    let numPulsewidthEntries = data.readUInt16LE( offset );
    logger( "Number of pulse width entries: ".padEnd(namePad) + numPulsewidthEntries);
    offset += 2;

    
    //["pulse width",18,2,'v','',0,'ns'],  // .......... 18-19 pulse width (ns)
    let pulsewidth = data.readUInt16LE( offset );
    logger( "Pulse width: ".padEnd(namePad) + pulsewidth);
    offset += 2;

    //["sample spacing", 20,4,'v',1e-8,'','usec'], // .. 20-23 sample spacing (usec)
    let sampleSpacing = data.readUInt32LE(offset) * 1e-8;
    logger( "Sample spacing: ".padEnd(namePad) + sampleSpacing);
    offset += 4;


    //["num data points", 24,4,'v','','',''], // ....... 24-27 number of data points
    let numDataPoints = data.readUInt32LE(offset);
    logger( "Number of data points: ".padEnd(namePad) + numDataPoints);
    offset += 4;

    //["index", 28,4,'v',1e-5,6,''], // ................ 28-31 index of refraction
    let indexOfRefraction = data.readUInt32LE(offset) * 1e-5;
    logger( "Index of refraction: ".padEnd(namePad) + indexOfRefraction);
    offset += 4;

    //["BC", 32,2,'v',-0.1,2,'dB'], // ................. 32-33 backscattering coeff
    let backScatterCoeff = data.readUInt16LE( offset ) * -0.1;
    logger( "backscattering coeff: ".padEnd(namePad) + backScatterCoeff.toFixed(2) );
    offset += 2;

    //["num averages", 34,4,'v','','',''], // .......... 34-37 number of averages
    let numAverages = data.readUInt32LE(offset);
    logger( "number of averages: ".padEnd(namePad) + numAverages);
    offset += 4;
    
    // from Dmitry Vaygant:
    //["averaging time", 38,2,'v',0.1,0,'sec'], // ..... 38-39 averaging time in seconds
    let averagingTime = data.readUInt16LE( offset ) * 0.1;
    logger( "averaging time in seconds: ".padEnd(namePad) + averagingTime);
    offset += 2;

    
    //["range", 40,4,'v',2e-5,6,'km'], // .............. 40-43 range (km); note x2
    let range = data.readUInt32LE(offset) * 2e-5;
    logger( "Range: ".padEnd(namePad) + range);
    offset += 4;

    // from Andrew Jones
    //["acquisition range distance",44,4,'i','','',''], // ........ 44-47
    let acquisition_range_distance = data.readInt32LE(offset);
    logger( "acquisition range distance: " + acquisition_range_distance);
    offset += 4;

    //["front_panel_offset",48,4,'i','','',''], // ................ 48-51
    let front_panel_offset = data.readInt32LE(offset);
    logger( "front panel offset: ".padEnd(namePad) + front_panel_offset);
    offset += 4;

    //["noise floor level",52,2,'v','','',''], // ................. 52-53 unsigned
    let noise_floor_level = data.readUInt16LE( offset );
    logger( "noise floor level: ".padEnd(namePad) + noise_floor_level);
    offset += 2;


    //["noise floor scaling factor",54,2,'i','','',''], // ........ 54-55
    let noise_floor_scaling_factor = data.readInt16LE( offset );
    logger( "noise floor scaling factor: ".padEnd(namePad) + noise_floor_scaling_factor);
    offset += 2;


    //["power offset first point",56,2,'v','','',''], // .......... 56-57 unsigned
    let power_offset_first_point = data.readUInt16LE( offset );
    logger( "power offset first point: ".padEnd(namePad) + power_offset_first_point);
    offset += 2;

    
    //["loss thr", 58,2,'v',0.001,3,'dB'], // .......... 58-59 loss threshold
    let loss_thr = data.readUInt16LE( offset ) * 0.001;
    logger( "loss thr: ".padEnd(namePad) + loss_thr.toFixed(3));
    offset += 2;

    //["refl thr", 60,2,'v',-0.001,3,'dB'], // ......... 60-61 reflection threshold
    let refl_thr = data.readUInt16LE( offset ) * -0.001;
    logger( "refl thr: ".padEnd(namePad) + refl_thr.toFixed(3));
    offset += 2;

    //["EOT thr",62,2,'v',0.001,3,'dB'], // ............ 62-63 end-of-transmission threshold
    let EOT_thr = data.readUInt16LE( offset ) * 0.001;
    logger( "EOT thr: ".padEnd(namePad) + EOT_thr.toFixed(3));
    offset += 2;

    //["trace type",64,2,'s','','',''], // ............. 64-65 trace type (ST,RT,DT, or RF)
    let  trace_type = parts.get_stringFixed( data, offset, 2);
    logger( "Trace type: ".padEnd(namePad) + trace_type)
    offset += 2

    // from Andrew Jones
    //["X1",66,4,'i','','',''], // ............. 66-69
    let X1 = data.readInt32LE(offset);
    logger( "X1: ".padEnd(namePad) + X1);
    offset += 4;

    //["Y1",70,4,'i','','',''], // ............. 70-73
    let Y1 = data.readInt32LE(offset);
    logger( "Y1: ".padEnd(namePad) + Y1);
    offset += 4;

    //["X2",74,4,'i','','',''], // ............. 74-77
    let X2 = data.readInt32LE(offset);
    logger( "X2: ".padEnd(namePad) + X2);
    offset += 4;

    //["Y2",78,4,'i','','',''], // ............. 78-81
    let Y2 = data.readInt32LE(offset);
    logger( "Y2: ".padEnd(namePad) + Y2);
    offset += 4;


     // corrrections/adjustment:
    let dx  = parseFloat( sampleSpacing ) * parts.sol / parseFloat(indexOfRefraction);
    range = dx * parseInt(numDataPoints);
    let resolution = dx * 1000.0 // in meters

    logger( "Range Calc: ".padEnd(namePad) + range);
    logger( "Resolution: ".padEnd(namePad) + resolution);




    let fxdParams = {
        "timestamp": ts.toISOString(),
        "unit": units,
        "wavelength": wavelength,
        "acquisition offset": acquisition_offset,
        "acquisition offset distance": acquisition_offset_distance,
        "number of pulse width entries": numPulsewidthEntries,
        "pulse width": pulsewidth,
        "sample spacing": sampleSpacing,
        "num data points": numDataPoints,
        "index": indexOfRefraction,
        "BC": backScatterCoeff,
        "num averages": numAverages,
        "averaging time": averagingTime,
        "range": range,
        "acquisition range distance": acquisition_range_distance,
        "front panel offset": front_panel_offset,
        "noise floor level": noise_floor_level,
        "noise floor scaling factor": noise_floor_scaling_factor,
        "power offset first point": power_offset_first_point,
        "loss thr": loss_thr,
        "refl thr": refl_thr,
        "EOT thr": EOT_thr,
        "trace type": trace_type,
        "X1": X1,
        "Y1": Y1,
        "X2": X2,
        "Y2": Y2,
        "resolution": resolution
    };

    return fxdParams;


}

var sep = "    :";

var unit_map = {
    "mt": " (meters)",
    "km": " (kilometers)",
    "mi": " (miles)",
    "kf": " (kilo-ft)"
};

var tracetype = {
    'ST': "[standard trace]",
    'RT': "[reverse trace]",
    'DT': "[difference trace]",
    'RF': "[reference]",
};

// function  process(fh, results, logger, errlog, debug=false)
// {
//     var bname = "FxdParams";
//     var hsize = bname.length + 1; // include trailing '\0'
//     var pname = "fxdparams.process():"
//     var ref = null;
//     var status = 'nok'

//     // try {
//     //     ref = results['blocks'][bname];
//     //     startpos = ref['pos'];
//     //     await fh.seek( startpos );
//     // }catch(e){
//     //     errlog( pname+" "+bname+"block starting position unknown");
//     //     return status;
//     // }

//     format = results['format'];
    
//     if (format == 2) {
//         //var mystr = await parts.get_string(fh, hsize);

//         if ( mystr != bname ) {
//             errlog(pname+" incorrect header '"+mystr+"' vs '"+bname+"'");
// 	    return status;
// 	}
//     }
    
//     results[bname] = {};
//     var xref = results[bname];

//     if ( format == 1 ) {
//         plist = [// name, start-pos, length (bytes), type, multiplier, precision, units
//             // type: display type: 'v' (value) or 'h' (hexidecimal) or 's' (string)
//             ["date/time",0,4,'v','','',''], // ............... 0-3 seconds in Unix time
//             ["unit",4,2,'s','','',''], // .................... 4-5 distance units, 2 char (km,mt,ft,kf,mi)
//             ["wavelength",6,2,'v',0.1,1,'nm'], // ............ 6-7 wavelength (nm)
            
//             // from Andrew Jones
//             ["acquisition offset",8,4,'i','','',''], // .............. 8-11 acquisition offset; units?
//             ["number of pulse width entries",12,2,'v','','',''], // .. 12-13 number of pulse width entries
            
//             ["pulse width",14,2,'v','',0,'ns'],  // .......... 14-15 pulse width (ns)
//             ["sample spacing", 16,4,'v',1e-8,'','usec'], // .. 16-19 sample spacing (in usec)
//             ["num data points", 20,4,'v','','',''], // ....... 20-23 number of data points
//             ["index", 24,4,'v',1e-5,6,''], // ................ 24-27 index of refraction
//             ["BC", 28,2,'v',-0.1,2,'dB'], // ................. 28-29 backscattering coeff
//             ["num averages", 30,4,'v','','',''], // .......... 30-33 number of averages
//             ["range", 34,4,'v',2e-5,6,'km'], // .............. 34-37 range (km)
            
//             // from Andrew Jones
//             ["front panel offset",38,4,'i','','',''], // ................ 38-41
//             ["noise floor level",42,2,'v','','',''], // ................. 42-43 unsigned
//             ["noise floor scaling factor",44,2,'i','','',''], // ........ 44-45
//             ["power offset first point",46,2,'v','','',''], // .......... 46-47 unsigned
            
//             ["loss thr", 48,2,'v',0.001,3,'dB'], // .......... 48-49 loss threshold
//             ["refl thr", 50,2,'v',-0.001,3,'dB'], // ......... 50-51 reflection threshold
//             ["EOT thr",52,2,'v',0.001,3,'dB'], // ............ 52-53 end-of-transmission threshold
//         ];
//     }else{
//         plist = [// name, start-pos, length (bytes), type, multiplier, precision, units
//             // type: display type: 'v' (value) or 'h' (hexidecimal) or 's' (string)
//             ["date/time",0,4,'v','','',''], // ............... 0-3 seconds in Unix time
//             ["unit",4,2,'s','','',''], // .................... 4-5 distance units, 2 char (km,mt,ft,kf,mi)
//             ["wavelength",6,2,'v',0.1,1,'nm'], // ............ 6-7 wavelength (nm)
            
//             // from Andrew Jones
//             ["acquisition offset",8,4,'i','','',''], // .............. 8-11 acquisition offset; units?
//             ["acquisition offset distance",12,4,'i','','',''], // .... 12-15 acquisition offset distance; units?    V2 only
//             ["number of pulse width entries",16,2,'v','','',''], // .. 16-17 number of pulse width entries
            
//             ["pulse width",18,2,'v','',0,'ns'],  // .......... 18-19 pulse width (ns)
//             ["sample spacing", 20,4,'v',1e-8,'','usec'], // .. 20-23 sample spacing (usec)
//             ["num data points", 24,4,'v','','',''], // ....... 24-27 number of data points
//             ["index", 28,4,'v',1e-5,6,''], // ................ 28-31 index of refraction
//             ["BC", 32,2,'v',-0.1,2,'dB'], // ................. 32-33 backscattering coeff
            
//             ["num averages", 34,4,'v','','',''], // .......... 34-37 number of averages
            
//             // from Dmitry Vaygant:
//             ["averaging time", 38,2,'v',0.1,0,'sec'], // ..... 38-39 averaging time in seconds     V2 only
            
//             ["range", 40,4,'v',2e-5,6,'km'], // .............. 40-43 range (km); note x2
            
//             // from Andrew Jones
//             ["acquisition range distance",44,4,'i','','',''], // ........ 44-47       V2 only
//             ["front panel offset",48,4,'i','','',''], // ................ 48-51
//             ["noise floor level",52,2,'v','','',''], // ................. 52-53 unsigned
//             ["noise floor scaling factor",54,2,'i','','',''], // ........ 54-55
//             ["power offset first point",56,2,'v','','',''], // .......... 56-57 unsigned
            
//             ["loss thr", 58,2,'v',0.001,3,'dB'], // .......... 58-59 loss threshold
//             ["refl thr", 60,2,'v',-0.001,3,'dB'], // ......... 60-61 reflection threshold
//             ["EOT thr",62,2,'v',0.001,3,'dB'], // ............ 62-63 end-of-transmission threshold
//             ["trace type",64,2,'s','','',''], // ............. 64-65 trace type (ST,RT,DT, or RF)     V2 only
            
//             // from Andrew Jones
//             ["X1",66,4,'i','','',''], // ............. 66-69   V2 only
//             ["Y1",70,4,'i','','',''], // ............. 70-73   V2 only
//             ["X2",74,4,'i','','',''], // ............. 74-77   V2 only
//             ["Y2",78,4,'i','','',''], // ............. 78-81   V2 only
//         ];	
//     }

//     //status = await process_fields(fh, plist, results, logger, errlog, debug);
//     /*
//     // read the rest of the block (just in case)
//     var endpos = results['blocks'][bname]['pos'] + results['blocks'][bname]['size'];
//     await fh.read( endpos - (await fh.tell()) );
//     status = 'ok'
//     */
    
//     return status;
// }

// ================================================================
// function process_fields(fh, plist, results, logger, errlog, debug) {
//     var bname = "FxdParams";
//     var xref  = results[bname];
    
//     /* functions to use
//      * 'h': get_hexstring
//      * 'v': get_uint
//      * 's': get_string
//      * 'i': get_signed
//      */

//     var count = 0;
//     for(let i in plist) {
// 	let field = plist[i];
	
//         let name  = field[0];
//         let fsize = field[2];
//         let ftype = field[3];
//         let scale = field[4];
//         let dgt   = field[5];
//         let unit  = field[6];
//         let xstr  = "";

// 	let val;
	
//         if (ftype == 'i') {
//             //val = await parts.get_signed(fh, fsize);
//             xstr = val;
// 	}else if (ftype == 'v') {
//             //val = await parts.get_uint(fh, fsize)
//             if (scale != '') {
//                 val *= scale;
// 	    }
//             if (dgt != '' ) {
//                 xstr = val.toFixed(dgt);
// 	    }else{
//                 xstr = val
// 	    }
// 	}else if (ftype == 'h') {
//             //xstr = await parts.get_hex(fh, fsize);
//         }else if (ftype == 's') {
//             //xstr = await fh.readString( fsize );
// 	}else{
//             //val = await fh.read(fsize);
//             xstr = val.toString();
// 	}
	
//         // .................................
//         if (name == 'date/time') {
// 	    // xstr = str(datetime.datetime.fromtimestamp(val))+(" (%d sec)" % val)
//             // xstr = datetime.datetime.fromtimestamp(val).strftime("%a %b %d %H:%M:%S %Y") + \
//             // (" (%d sec)" % val);
// 	    var d = new Date(0);
// 	    d.setUTCSeconds(val);
	    
// 	    xstr = d+` (${val} sec)`;
// 	    // console.log("............... got "+xstr);
// 	}else if (name == 'unit') {
//             xstr += unit_map[ xstr ]
//         }else if (name == 'trace type') {
//             try {
//                 xstr += tracetype[ xstr ];
// 	    }catch(e) {
//                 continue;
// 	    }
// 	}
	
// 	// don't bother even trying if there are multiple pulse width entries; too lazy
//         // to restructure code to handle this case
//         if (name == 'number of pulse width entries' && val > 1) {
//             errlog(`WARNING!!!: Cannot handle multiple pulse width entries (${val}); aborting`);
//             process.exit();
// 	}

// 	// .................................
//         if (debug) {
//             logger(`${sep} ${count}. ${name}: ${xstr} ${unit}`);
//         }
// 	if ( unit=="" ) {
//             xref[name] = xstr;
// 	}else{
// 	    xref[name] = xstr+" "+unit;
// 	}
//         count += 1
//     }

//     // corrrections/adjustment:
//     var ior = parseFloat(xref['index']);
//     var ss = xref['sample spacing'].split(' ')[0];
//     var dx  = parseFloat( ss ) * parts.sol / ior;
//     xref['range'] = dx * parseInt(xref['num data points']);
//     xref['resolution'] = dx * 1000.0 // in meters

//     if (debug) {
//         logger("");
//         logger(`${sep} [adjusted for refractive index]`)
//         logger(`${sep} resolution = ${xref['resolution'].toFixed(14)} m`);
//         logger(`${sep} range      = ${xref['range'].toFixed(13)} km`);
//     }
//     status = 'ok';
    
//     return status;
// };

/* =====================================================================
 * export this as a module
 * =====================================================================
 */
// var FxdParams = function()
// {
//     this.process = process;
// }

// module.exports = FxdParams;
