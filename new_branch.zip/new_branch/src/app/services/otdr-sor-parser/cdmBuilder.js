import _ from 'lodash'


export function createCDM( gp, sp, fp, dp, ke ) {

    //console.log( dp );


    let cdm = {
        "cdmVersion" : "2.2",
        "workflow" : {
            "type": "viaviJob",
        },
        "assetInfo" : {
        },
        "tests" : []
    }

    // ------------------------------------------------------------
    // Populate the assetInfo block
    _.set( cdm, 'assetInfo.assetType', sp.OTDR);
    _.set( cdm, 'assetInfo.manufacturer', sp.supplier);
    _.set( cdm, 'assetInfo.uniqueId', sp.OTDR + '_' + sp.OTDR_SN);

    let modulesInfo = [];
    let myModule = { 
        "assetType": sp.module,
        "uniqueId": sp.module + '_' +sp.module_SN,
        "model": sp.module,
        "swVersion": sp.software    
    }
    modulesInfo.push(myModule );

    _.set( cdm, 'assetInfo.modulesInfo', modulesInfo);
 
    // ------------------------------------------------------------
    // Populate the tests block
    let tests = [];
    let myTest = {
        "type": "OTDR",
        "label": "OTDR",
        "schemaVersion": "1.5.0",
        "configuration" : {}, 
    }

    _.set( myTest, 'results.status', "PASS");
    _.set( myTest, 'results.testTime', fp.timestamp );
    _.set( myTest, 'results.comment', "");


    _.set( myTest, 'results.data.otdrResults.distanceUnits', fp.unit);

    let measuredResults = [];
    let meas = {};

    let events = [];
    let totalLength;
    let totalLengthM;
    let totalLoss = 0.0;
    let totalORL = 0.0;


    const connectorlossMax = 0.5;
    const splicelossMax = 0.3;
    const reflectanceMax = -35.0;
    const slopeMax = 1.00;

    let distanceOffset = ke[0].dist.toFixed(3)
    
    for(const element of ke) {

        

        let event = {};
        _.set( event, "id", element.eventId );
        _.set( event, "distance", (element.dist - distanceOffset).toFixed(3) );
        _.set( event, "distanceM", (element.dist - distanceOffset).toFixed(3) ); 
        _.set( event, "reflectancedB", element.refl.toFixed(3) ); 
        _.set( event, "lossdB", element.spliceLoss.toFixed(3) ); 

        let eventType;
        let code = element.lang.charAt(0);
        switch( code ) {
            case "0":
                eventType = "Splice";
                break;
            case "1":
                eventType = "Reflectance";
                break;
            case "2":
                eventType = "Multiple";
                break;
            default:
                eventType = "Unknown";
        }

        let eventTestStatus = "PASS";
        let lossAlarmFailed = false;
        let reflAlarmFailed = false;
        let slopeAlarmFailed = false;

        if( eventType == "Splice" ) {
            if( element.spliceLoss > splicelossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        } else {
            if( element.spliceLoss > connectorlossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
            if( element.refl > reflectanceMax) {
                reflAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        }
       
        if( element.slope > slopeMax ) {
            slopeAlarmFailed = true;
            eventTestStatus = "FAIL";
        }
        


        _.set( event, "eventType", eventType); 
        _.set( event, "eventTestStatus", "PASS" ); 
        _.set( event, "sectionLength", (element.start_next - element.start_curr).toFixed(3) ); 
        _.set( event, "sectionLengthM", (element.start_next - element.start_curr).toFixed(3) ); 
        _.set( event, "slope", element.slope.toFixed(3) );
        _.set( event, "lossAlarmFailed",  lossAlarmFailed);
        _.set( event, "reflAlarmFailed", reflAlarmFailed );
        _.set( event, "slopeAlarmFailed", slopeAlarmFailed  );
        _.set( event, "eventTestStatus", eventTestStatus );


        _.set( event, "groupNumber", 0 );  

 
        // "reflSaturated": false,
        // "reflPeakDistanceM": -2.55,
        //  "sectionLossdB": 0.0,
        // "cumulativeLossdB": 0.0,


         events.push( event ); 
        
         totalLength = element.dist;
         totalLengthM = element.dist; 
         totalLoss +=  element.spliceLoss;
         totalORL =  element.refl            // probably need to sum up something
        
    }

    _.set( meas, 'wavelength', fp.wavelength);
    _.set( meas, 'wavelengthTestStatus', "PASS");
    _.set( meas, 'acqDateTime', fp.timestamp);

    _.set( meas, 'fiberLength', totalLength.toFixed(3));
    _.set( meas, 'fiberLengthM', totalLengthM.toFixed(3));
    _.set( meas, 'linkLossdB', totalLoss);
    _.set( meas, 'linkOrldB', totalORL);
    _.set( meas, 'numberOfEvents', ke.numEvents );
    _.set( meas, 'maxConnectorMeasureddB', 7);
    _.set( meas, 'maxReflectanceMeasureddB', 7);
    _.set( meas, 'averageSlopedBkm', 7);
    _.set( meas, 'trace', dp);


    _.set( meas, 'events', events);

    measuredResults.push( meas );
    
    
    _.set( myTest, 'results.data.otdrResults.measuredResults', measuredResults);
    tests.push( myTest );


    _.set( cdm, 'tests', tests);

    //console.log("-----------------------------------------");
    //console.log( JSON.stringify( cdm, null, 3 ));

    return cdm;

}