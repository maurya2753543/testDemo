export const sol = 299792.458/1.0e6; // = 0.299792458 km/usec

export function get_string(data, offset) {
  var mystr = "";
  var byte = String.fromCharCode(data.readUint8(offset++));

  while (byte != "") {
    var tt = byte.charCodeAt(0);
    if (tt == 0) {
      break;
    }
    mystr += byte;
    byte = String.fromCharCode(data.readUint8(offset++));
  }
  return mystr;
}


export function get_stringFixed(data, offset, len) {
    var mystr = "";
    var byte = String.fromCharCode(data.readUint8(offset++));
  
    while (byte != "") {
      var tt = byte.charCodeAt(0);
      if (tt == 0) {
        break;
      }
      mystr += byte;
      if( mystr.length == len ) { break; }
      byte = String.fromCharCode(data.readUint8(offset++));
    }
    return mystr;
  }
  


export function get_uint(bytes, offset, nbytes = 2) {
  if (nbytes == 2) {
    val = readUInt16(bytes, offset);
  } else if (nbytes == 4) {
    val = readUInt32(bytes, offset);
  } else {
    val = null;
    console.log(`parts.get_uint(): Invalid number of bytes ${nbytes}`);
  }

  return val;
}

function readUInt16(bytes, offset) {
  return 0;
}

function readUInt32(bytes, offset) {
  return 0;
}

export function get_signed(bytes, offset, nbytes = 2) {
  if (nbytes == 2) {
    val = readInt16();
  } else if (nbytes == 4) {
    val = readInt32();
  } else {
    val = null;
    console.log(`parts.get_signed(): Invalid number of bytes ${nbytes}`);
  }

  return val;
}

function readInt16(bytes, offset) {
  return 0;
}

function readInt32(bytes, offset) {
  return 0;
}

export function get_hex(bytes, offset, nbytes = 1) {
  var hstr = "";
  for (var i = 0; i < nbytes; i++) {
    var b = readUInt8().toString(16);
    b = ("00000" + b).substr(-2).toUpperCase() + " ";
    hstr += b;
  }
}

export function readUInt8() {}
export function tohex() {
  return val.toString(16).toUpperCase();
}

export function slurp() {
  // try {
  //     var ref = results['blocks'][bname];
  //     var startpos = ref['pos'];
  //     await fh.seek( startpos );
  // }catch(e){
  //     errlog(pname+" "+bname+"block starting position unknown");
  //     return 'nok';
  // }
  // var nn = ref['size'];

  // var tt = await fh.read(nn);

  return "ok";
}
