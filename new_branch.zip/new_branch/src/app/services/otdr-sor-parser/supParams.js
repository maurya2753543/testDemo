import * as parts from './parts.js'

const showDebug = false;
function logger( value ) {
    if( showDebug ) {
        console.log( value );
    }
}

export function parseSupParams(data, offset) {

    let namePad = 25

    logger("-----------------------------------------");
    var str = parts.get_string( data, offset);
    logger( str );
    logger("-----------------------------------------");
    offset += str.length + 1;

    var supplier = parts.get_string( data, offset);
    logger( "Supplier: ".padEnd((namePad)) + supplier );
    offset += supplier.length + 1;

    var otdr = parts.get_string( data, offset);
    logger( "OTDR: ".padEnd((namePad)) +otdr );
    offset += otdr.length + 1;

    var otdr_sn = parts.get_string( data, offset);
    logger( "OTDR SN: ".padEnd((namePad)) +otdr_sn );
    offset += otdr_sn.length + 1;

    var module = parts.get_string( data, offset);
    logger( "Module: ".padEnd((namePad)) +module );
    offset += module.length + 1;

    var module_sn = parts.get_string( data, offset);
    logger( "Moduel SN: ".padEnd((namePad)) +module_sn );
    offset += module_sn.length + 1;

    var software = parts.get_string( data, offset);
    logger( "Software: ".padEnd((namePad)) +software );
    offset += software.length + 1;

    var other = parts.get_string( data, offset);
    logger( "Other: ".padEnd((namePad)) +other );
    offset += other.length + 1;

    let supParams = {
        "supplier": supplier,
        "OTDR": otdr,
        "OTDR_SN": otdr_sn,
        "module": module,
        "module_SN": module_sn,
        "software": software,
        "other": other
    }

    return supParams;

}




// var sep = "    :";

function process(fh, results, logger, errlog, debug=false)
{
    var bname = "SupParams";
    var hsize = bname.length + 1; // include trailing '\0'
    var pname = "supparam.process():"
    var ref = null;
    var status = 'nok'

    // try {
    //     ref = results['blocks'][bname];
    //     startpos = ref['pos'];
    //     await fh.seek( startpos );
    // }catch(e){
    //     errlog( pname+" "+bname+"block starting position unknown");
    //     return status;
    // }

    format = results['format'];
    
    // if (format == 2) {
    //     var mystr = await parts.get_string(fh, hsize);

    //     if ( mystr != bname ) {
    //         errlog(pname+" incorrect header '"+mystr+"' vs '"+bname+"'");
	//     return status;
	// }
    // }
    
    results[bname] = {};
    var xref = results[bname];

    // version 1 and 2 are the same
    // status = await process_supparam(fh, results, logger, errlog, debug);

    // read the rest of the block (just in case)
    /*
    var endpos = results['blocks'][bname]['pos'] + results['blocks'][bname]['size']
    await fh.read( endpos - (await fh.tell()) )
    status = 'ok';
    */
    
    return status;
}

// ================================================================
function process_supparam (fh, results, logger, errlog, debug) {
    // process SupParams fields
    var bname = "SupParams";
    var xref  = results[bname];
    
    var fields = [
        "supplier", // ............. 0
        "OTDR", // ................. 1
        "OTDR S/N", // ............. 2
        "module", // ............... 3
        "module S/N", // ........... 4
        "software", // ............. 5
        "other", // ................ 6
    ];
    
    var count = 0
    // for(let i in fields ) {
	// let field = fields[i];
    //     let xstr = await parts.get_string(fh);
    //     if (debug) {
    //         logger(`${sep} ${count}. ${field}: ${xstr}`);
    //     }
    //     xref[field] = xstr;
    //     count += 1
    // }
    var status = 'ok'
    
    return status;
};

/* =====================================================================
 * export this as a module
 * =====================================================================
 */
// var SupParams = function()
// {
//     this.process = process;
// }

// module.exports = SupParams;
