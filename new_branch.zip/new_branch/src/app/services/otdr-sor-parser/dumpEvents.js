import fs from 'fs';


export function writeToCSV( ke, filename ) {


    let events = [];
    let totalLength;
    let totalLengthM;
    let totalLoss = 0.0;
    let totalORL = 0.0;


    const connectorlossMax = 0.5;
    const splicelossMax = 0.3;
    const reflectanceMax = -35.0;
    const slopeMax = 1.00;

    let distanceOffset = ke[0].dist.toFixed(3)


    let header = "id, distance, reflectancedB, lossdB, type, sectionLength, slope, lossAlrm, RefAlrm, slopeAlrm, status\n";
    let rows = [];

    rows.push( header ); 
    
    for(const element of ke) {

        let eventRow;

        let event = {};
        // _.set( event, "id", element.eventId );
        // _.set( event, "distance", (element.dist - distanceOffset).toFixed(3) );
        // _.set( event, "distanceM", (element.dist - distanceOffset).toFixed(3) ); 
        // _.set( event, "reflectancedB", element.refl.toFixed(3) ); 
        // _.set( event, "lossdB", element.spliceLoss.toFixed(3) ); 

        let eventType;
        let code = element.lang.charAt(0);
        switch( code ) {
            case "0":
                eventType = "Splice";
                break;
            case "1":
                eventType = "Reflectance";
                break;
            case "2":
                eventType = "Multiple";
                break;
            default:
                eventType = "Unknown";
        }

        let eventTestStatus = "PASS";
        let lossAlarmFailed = false;
        let reflAlarmFailed = false;
        let slopeAlarmFailed = false;

        if( eventType == "Splice" ) {
            if( element.spliceLoss > splicelossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        } else {
            if( element.spliceLoss > connectorlossMax) {
                lossAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
            if( element.refl > reflectanceMax) {
                reflAlarmFailed = true;
                eventTestStatus = "FAIL";
            }
        }
       
        if( element.slope > slopeMax ) {
            slopeAlarmFailed = true;
            eventTestStatus = "FAIL";
        }
 
        // _.set( event, "eventType", eventType); 
        // _.set( event, "sectionLength", (element.start_next - element.start_curr).toFixed(3) ); 
        // _.set( event, "sectionLengthM", (element.start_next - element.start_curr).toFixed(3) ); 
        // _.set( event, "slope", element.slope.toFixed(3) );
        // _.set( event, "lossAlarmFailed",  lossAlarmFailed);
        // _.set( event, "reflAlarmFailed", reflAlarmFailed );
        // _.set( event, "slopeAlarmFailed", slopeAlarmFailed  );
        // _.set( event, "eventTestStatus", eventTestStatus );
        // _.set( event, "groupNumber", 0 );  
 
        // "reflSaturated": false,
        // "reflPeakDistanceM": -2.55,
        //  "sectionLossdB": 0.0,
        // "cumulativeLossdB": 0.0,


        eventRow = element.eventId + ", ";
        eventRow = eventRow.concat(element.dist.toFixed(3) + ", ");
        eventRow = eventRow.concat(element.refl.toFixed(3) + ", " );
        eventRow = eventRow.concat(element.spliceLoss.toFixed(3)+ ", " );
        eventRow = eventRow.concat(eventType + ", " ); 
        eventRow = eventRow.concat((element.start_next - element.start_curr).toFixed(3) + ", " );
        eventRow = eventRow = eventRow.concat(element.slope.toFixed(3) + ", " );
        eventRow = eventRow = eventRow.concat(lossAlarmFailed + ", " );
        eventRow = eventRow.concat(reflAlarmFailed + ", " );
        eventRow = eventRow.concat(slopeAlarmFailed + ", " );
        eventRow = eventRow.concat(eventTestStatus + "\n" );

         rows.push( eventRow ); 
        
         totalLength += element.dist;
         totalLengthM = element.dist; 
         totalLoss +=  element.spliceLoss;
         totalORL +=  element.refl            // probably need to sum up something
        
    }

    // clear the csv file
    fs.writeFile( filename+".csv", '' , (err) => {
            if (err) {
            console.log(err)
            }
        });


    for(const line of rows) {
        fs.appendFileSync( filename+".csv", line , (err) => {
            if (err) {
            console.log(err)
            }
        });
    }

    // fs.writeFile( filename+".csv", rows , (err) => {
    //     if (err) {
    //        console.log(err)
    //     }
    // });


}