import { HttpClient } from "@angular/common/http";
import { Injectable, Renderer2, RendererFactory2, EventEmitter } from "@angular/core";
import { BehaviorSubject, Observable, Subject, firstValueFrom } from "rxjs";
import { DatabaseBridgeService } from "./database-bridge.service";
//import { environment, databaseMode } from 'src/environments/environment';
import '../window-extensions'

export interface ReportsInformationsList {
  title: string;
  company: string;
  technician: string;
  streetaddress: string;
  city: string;
  postalcode: string;
  phone: number | null;
  email: string;
}

// Create an interface to define the shape of the API response (adjust the properties as per your actual API response)
interface ApiResponse {
  status: string;
  data: any;
  // Add other properties if needed
}
@Injectable({
  providedIn: 'root'
})

export class GlobalSettingsService {
  ////////// DATA SOURCE MODE /////////////////
  databaseLocal = true;


  
  //databaseLocal = databaseMode.useLocal;

  [x: string]: any;
  selectedProjectProfile: any
  // for DarkThemes service mode
  private isDarkMode = false;
  private renderer: Renderer2;

  language = 'English';
  defaultLevelUnits: string = '';
  defaultDistanceUnits = 'km';

  strataSyncUsername = '';
  strataSyncPassword = '';
  strataSyncServer: any;
  strataSyncServerUrl = 'https://stratasync.viavisolutions.com';

   projectProfileListData: any[] = [];
  private ReportInformationListData: any[] = [];  // move to project settings

  languageList = [];

  strataSyncServerList = [];

  theme = 'light';
  splitViewOrientation = "horizontal";
  splitViewPositionExpanded = 80;
  splitViewPositionNormal = 20;

  constructor(private rendererFactory: RendererFactory2, private http: HttpClient, private databaseBridgeService: DatabaseBridgeService) {

      if( !window.db ) {
        this.databaseLocal = false;
      }
    

    this.getAppSettings().then((settings: any) => {
      console.log("Settings response ", settings);
      this.language = settings.language;
      this.defaultLevelUnits = settings.defaultLevelUnits;
      this.defaultDistanceUnits = settings.defaultDistanceUnits;
      this.strataSyncUsername = settings.strataSyncUsername;
      this.strataSyncPassword = settings.strataSyncPassword;
      this.strataSyncServer = settings.strataSyncServerUrl;
      this.strataSyncServerUrl = settings.strataSyncServerUrl.url;
      this.projectProfileListData = settings.projectProfiles;
      this.languageList = settings.languageList;
      this.strataSyncServerList = settings.strataSyncServers;
      this.theme = settings.theme;
      if (this.theme == "light") { this.isDarkMode = false; }
      this.splitViewOrientation = settings.splitViewOrientation;
      this.splitViewPositionExpanded = settings.splitViewPositionExpanded;
      this.splitViewPositionNormal = settings.splitViewPositionNormal;
    });


    this.renderer = rendererFactory.createRenderer(null, null);
    this.getTheme();
  }

  //----------------------------------------------------------------------------------
  isDatabaseLocal() {
    return this.databaseLocal
  }

  //----------------------------------------------------------------------------------
  // Language setting
  getLanguage(): string {
    return this.language;
  }


  //----------------------------------------------------------------------------------
  // Default Distance Units
  getlanguageList(): string[] {
    return this.languageList;
  }

  //----------------------------------------------------------------------------------
  // default Optical Level Units
  getLevelUnitList(): string[] {
    return ['dBm', 'Watts'];
  }

  //----------------------------------------------------------------------------------
  getDefaultLevelUnits(): string {
    return this.defaultLevelUnits;
  }

  //----------------------------------------------------------------------------------
  // Default Distance Units
  getDistanceUnitList(): any[] {
   return [{ name: 'Feets', value: 'feet' }, { name: 'Meters', value: 'meter' }, { name: 'Kilometer', value: 'kilometers' }];
  }

  //----------------------------------------------------------------------------------
  getDefaultDistanceUnits(): string {
    return this.defaultDistanceUnits;
  }

  getDefaultProjectProfile(): any {
    return this.projectProfileListData[0];
  }

  //----------------------------------------------------------------------------------
  getStrataSyncServerList() {
    return this.strataSyncServerList;
  }

  //----------------------------------------------------------------------------------
  // Project Profiles
  // get a list profiles
  getAllProjectProfilesList(): any[] {
    console.log("GSS ", this.projectProfileListData)
    return this.projectProfileListData;
  }

  //----------------------------------------------------------------------------------
  // get a profile
  getProjectProfile() {
    return this.selectedProjectProfile;
  }

  //----------------------------------------------------------------------------------
  // Method to retrieve the listData  Project Profile Name data listData
  getProjectProfileListData() {
    return this.projectProfileListData;
  }

  //----------------------------------------------------------------------------------
  // method for set Report information data
  getReportInformations() {
    return this.ReportInformationListData;

  }

  //----------------------------------------------------------------------------------
  // set  method for set Report information data
  setReportInformations(reportinfodata: any) {
    this.ReportInformationListData = reportinfodata;
    console.log(this.ReportInformationListData, " what are list data this.listData")
  }

  // set report data info all details

 //----------------------------------------------------------------------------------
  private reportTitle: string = '';
  private companyTitle: string = '';
  private technicianTitle: string = '';
  private streetaddressTitle : string = '';
  private  cityTitle : string = '';
  private postalcodeTitle : string = '';
  private phoneTitle : string = '';
  private emailTitle : string = '';
 //----------------------------------------------------------------------------------
  setReportTitle(title: string) {
      this.reportTitle = title;
  }
 //----------------------------------------------------------------------------------
  setCompanyTitle(title: string) {
      this.companyTitle = title;
  }
 //----------------------------------------------------------------------------------
  setTechnicianTitle(title: string) {
    this.technicianTitle = title;
}
 //----------------------------------------------------------------------------------
  setStreetaddressTitle(title: string) {
      this.streetaddressTitle = title;
  }
   //----------------------------------------------------------------------------------
  setCityTitle(title: string) {
    this.cityTitle = title;
}
 //----------------------------------------------------------------------------------
setPostalcodeTitle(title: string) {
    this.postalcodeTitle = title;
}
 //----------------------------------------------------------------------------------
setPhoneTitle(title: string) {
    this.phoneTitle = title;
}
 //----------------------------------------------------------------------------------

setEmailTitle(title: string) {
  this.emailTitle = title;
}
 //----------------------------------------------------------------------------------
// get the data

getReportTitle(title: string) {
 return this.reportTitle;
}
 //----------------------------------------------------------------------------------
getCompanyTitle(title: string) {
  return this.companyTitle;
}
 //----------------------------------------------------------------------------------
getTechnicianTitle(title: string) {
  return this.technicianTitle;
}
 //----------------------------------------------------------------------------------
getStreetaddressTitle(title: string) {
  return this.streetaddressTitle;
}
 //----------------------------------------------------------------------------------
getCityTitle(title: string) {
  return this.cityTitle;
}
 //----------------------------------------------------------------------------------
getPostalcodeTitle(title: string) {
  return this.postalcodeTitle;
}
 //----------------------------------------------------------------------------------
getPhoneTitle(title: string) {
  return this.phoneTitle;
}
 //----------------------------------------------------------------------------------
getEmailTitle(title: string) {
  return this.emailTitle;
}

  // Set  Image data service data into from Report Information component +++ Image
  // private reportInformations: ReportsInformationsList[] = []; // Initialize as needed
  // private imageSubject = new Subject<File>();
  // image$: Observable<File> = this.imageSubject.asObservable();

  // setImage(image: File): void {
  //   this.imageSubject.next(image);
  // }
  // saveReportInformationWithImage(data: ReportsInformationsList, imageFile: File): void {
  //       const formData = new FormData();
  //     formData.append('image', imageFile, imageFile.name);
  //     this.setImage(imageFile);


  // }
  //----------------------------------------------------------------------------------
  private imageSubject = new BehaviorSubject<File | null>(null);

  saveReportInformationWithImage(data: ReportsInformationsList, imageFile: File): void {
    this.imageSubject.next(imageFile);
  }

  //----------------------------------------------------------------------------------
  getImageObservable(): Observable<File | null> {
    return this.imageSubject.asObservable();
  }

  //----------------------------------------------------------------------------------
  // User Preferences
  // light / dark theme

  getTheme(): void {
    this.isDarkMode = !this.isDarkMode;
    if (this.isDarkMode) {
      this.renderer.addClass(document.body, 'dark-mode');
    } else {
      this.renderer.removeClass(document.body, 'dark-mode');
    }
  }

  //----------------------------------------------------------------------------------
  public getAppSettings(): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.getAppSettings()
    } else {
      return firstValueFrom(this.http.get("http://localhost:3000/api/v1/appsettings"))
    }
  };

  //----------------------------------------------------------------------------------
  public updateAppSettings(settings: any): Promise<any> {
    if (this.databaseLocal) {
      return this.databaseBridgeService.setAppSettings(settings);
    }
    else {
      return firstValueFrom(this.http.patch("http://localhost:3000/api/v1/appsettings", settings));
    }
  };
}
