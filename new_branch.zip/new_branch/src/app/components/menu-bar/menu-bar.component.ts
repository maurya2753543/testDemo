import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { faTableRows } from '@fortawesome/pro-solid-svg-icons';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { OverlayContainer } from '@angular/cdk/overlay';
import { FormControl } from '@angular/forms';
import { DatabaseBridgeService } from 'src/app/services/database-bridge.service';
import { ProjectsService } from 'src/app/services/projects.service';
import {DocsService} from 'src/app/services/docs.service'
import { MatDialog, MatDialogRef ,MAT_DIALOG_DATA} from '@angular/material/dialog';
import {
  faPlus,
  faFileImport,
  faEllipsis,
  faFloppyDisk,
  faFloppyDiskPen,
  faEdit,
  faFileExport,
  faClose,
  faCloudArrowDown,
  faUsbDrive,
  faTable,
  faLayerGroup,
} from '@fortawesome/pro-solid-svg-icons';


import { InstrumentCommsPanelComponent } from '../instrument-comms-panel/instrument-comms-panel.component';
import { PopupInputComponent } from '../popup-input/popup-input.component';
import { PopupPdfComponent } from '../popup-pdf/popup-pdf.component';
import { DetailsPdfPopupComponent } from '../details-pdf-popup/details-pdf-popup.component';
export interface DialogData {
  version: any;
}

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.scss'],
})
export class MenuBarComponent implements OnInit {

  //------------------------------------------------

  faPlus = faPlus
  faFileImport = faFileImport
  faEllipsis = faEllipsis
  faFloppyDisk = faFloppyDisk
  faFloppyDiskPen = faFloppyDiskPen
  faEdit = faEdit;
  faFileExport = faFileExport
  faClose = faClose;
  faCloudArrowDown = faCloudArrowDown;
  faUsbDrive = faUsbDrive;
  faTable = faTable;
  faLayerGroup = faLayerGroup;

  appVersion = "";
  DarkThemesApply :any;
  noRowselected: any; // no row selected

  constructor(public dialog: MatDialog,  private sharedService: SharedService,
     private darkModeService: DarkModeService,
     //private instrumentCommsPanelComponent: InstrumentCommsPanelComponent,
     private overlay: OverlayContainer,
     private databaseBridgeService: DatabaseBridgeService,
     private docsService: DocsService,
     private projectsService: ProjectsService) {

        window.api?.getAppVersion().then(version => { this.appVersion = `${version}` });

  }
  public toggle :any = false;
  @HostBinding('class') className = '';

  toggleControl = new FormControl(false);
  ngOnInit(): void {
    this.darkModeService.emitEvent();
    this.projectsService.getNoRowPdfData().subscribe((e) => {
      this.noRowselected = e;
    });
    //this.toggleDarkMode(event: Event);
  }
   theme(value: string) {
    if (value) {
      document.getElementsByTagName('body')[0].classList.add(value);
    } else {
      document.getElementsByTagName('body')[0].classList.remove('dark-theme');
    }
    this.#theme = value;
  }
  #theme: string = '';


  // selectedView: string;
 selectedFile!: File;
 faTableRows = faTableRows
//-----------------------------------------------------------------------

  itemcclickEventlick() {
    console.log($localize`click New event`);
  }
//-----------------------------------------------------------------------

  saveProject() {
    console.log($localize`click save event`);
    this.databaseBridgeService.getAllDatabaseInfo().then( (resp:any) => {
        console.log("DB Info", resp);
    })

  }
  //------------------------------------------------------------------
   // pdf maker logic
   generatePDF() {
    const dialogRef: MatDialogRef<PopupPdfComponent> = this.dialog.open(
      PopupPdfComponent,
      {
        width: '400px', // Set the desired width for the dialog
        data: {
          /* Optional data to pass to the dialog component */
        },
        panelClass: 'custom-modalbox',
      }
    );

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog closed with result:', result);
      // Perform any necessary actions after the dialog is closed
    });
  }
   //------------------------------------------------------------------
   // pdf maker logic details pdf
   generateDetailsPdf() {
    const dialogRef: MatDialogRef<DetailsPdfPopupComponent> = this.dialog.open(
      DetailsPdfPopupComponent,
      {
        width: '400px', // Set the desired width for the dialog
        data: {
          /* Optional data to pass to the dialog component */
        },
        panelClass: 'custom-modalbox',
      }
    );

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog closed with result:', result);
      // Perform any necessary actions after the dialog is closed
    });
  }
//-----------------------------------------------------------------------

  // pdf maker logic end
  exportToCSV() {
    const dialogRef: MatDialogRef<PopupInputComponent> = this.dialog.open(
      PopupInputComponent,
      {
        width: '400px', // Set the desired width for the dialog
        data: { title: ' Please select CSV File Name' },
      }
    );

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog closed with result:', result);
      // Perform any necessary actions after the dialog is closed
    });
  }
//-----------------------------------------------------------------------

  // export csv logic end

  saveAs() {
    console.log($localize`click Save as event`);
  }
//-----------------------------------------------------------------------

  closeClick() {
    console.log($localize`click Close event`);
  }
//-----------------------------------------------------------------------

  CloseAllClick() {
    console.log($localize`click Close all event`);
  }

//-----------------------------------------------------------------------

  settingClick() {
    console.log($localize`click Setting event`);
  }
//-----------------------------------------------------------------------

  helpAboutClicked() {
    this.dialog.open(HelpAboutDialog, {
      data: {
        version: this.appVersion,
      },
    });
  }

  releaseNotesClicked() {
    this.docsService.open({doc: 'guide', section: 'about'})

  }




//-----------------------------------------------------------------------

  doFileInput(event:  Event) {
    const element = event.currentTarget as HTMLInputElement;
    let fileList: FileList | null = element.files;
    if (fileList) {
      console.log($localize`FileUpload -> files`, $localize`${fileList}`);
    }
  }
//-----------------------------------------------------------------------

 toggleView (event: Event) {
  const element = event.currentTarget as HTMLInputElement;
  console.log(element.getAttribute('val'));
  this.sharedService.setselectedViewDirection(element.getAttribute('val'));
  //  selectedView = element.getAttribute('val')
 }

 //------------------------------------------------------------------


newProject() {
  this.projectsService.newProject("rename me");
}
//--------------------------------------------------------------------------
importProject(event:  Event) {
console.log('event', event);
}
//-----------------------------------------------------------------------
exportProject() {
  this.projectsService.exportProject(false);


}
//-----------------------------------------------------------------------

archiveProject() {
  console.log("Archive Clicked - Yeah!!!");
  console.log ( window.api.cpus() );

}
//-----------------------------------------------------------------------


renameProject() {
  // this.projectsService.renameTreeNode();
}

//-----------------------------------------------------------------------

instrumentImport() {
    console.log("instrument Import");

      const dialogRef = this.dialog.open(InstrumentCommsPanelComponent, {
        //  maxHeight: '500px',
        //data: {data: data, DarkThemesApply: DarkThemesApply}

      });

}



//-----------------------------------------------------------------------

 /////// imported json file reads into obj//////////

// for the multiple file select for import
onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input && input.files && input.files.length) {
      for (var i = 0; i < input.files.length; i++) {
        //console.log(input.files[i], 'how are select ++');
        this.selectedFile = input.files[i];
        //console.log(this.selectedFile, 'how are select ++');
        const reader = new FileReader();

        reader.onload = (e) => {
          const result = reader.result;

          this.projectsService.importResultFile(this.selectedFile, result);
        };

        if (this.selectedFile.name.endsWith(".json")) {
          reader.readAsText(input.files[i]);
        } else {
          reader.readAsArrayBuffer(input.files[i]);
        }
      }
    }
  }


toggleDarkMode(event: Event): void {
  this.darkModeService.emitEvent();
  if (this.#theme === 'dark-theme') {
    this.#theme = '';
  } else {
    this.#theme = 'dark-theme';
  }
  this.theme(this.#theme);
  this.darkModeService.isDarkThemesActiveValue(this.#theme);

}
public isDark:any = false ;

}

@Component({
  selector: 'help-about-dialog',
  templateUrl: 'help-about-dialog.html',
})
export class HelpAboutDialog {
  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData) {}
}
