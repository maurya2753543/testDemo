import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { ProjectsService } from 'src/app/services/projects.service';
import { SharedService } from 'src/app/services/shared.service';

/**
 * projects data with nested structure.
 * Each node has a name and an optional list of children.
 */
interface ProjectNode {
  name: string;
  children?: ProjectNode[];
}
/** Flat to-do item node with expandable and level information */
class TodoItemFlatNode {
  name: string;
  level: number;
  expandable: boolean;
  children: any;
  id: string;
  rev: string;
  parent: string;
  projectId: string;
  haschild: boolean;
  numResults: number;
}
class TodoItemNode {
  children: TodoItemNode[] = []
  name: string;
  id: string;
  rev: string;
  parent: string;
  projectId: string;
  numResults: number;
}
@Component({
  selector: 'app-projects-tree',
  templateUrl: './projects-tree.component.html',
  styleUrls: ['./projects-tree.component.scss']
})
export class ProjectsTreeComponent implements OnInit {
  @Output() destinationId = new EventEmitter<any>();

  /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);

  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.name === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {

    const existingNode = this.nestedNodeMap.get(node);
    const flatNode =
      existingNode && existingNode.name === node.name ? existingNode : new TodoItemFlatNode();
    flatNode.name = node.name;
    flatNode.id = node.id;
    flatNode.level = level;
    flatNode.expandable = true;
    flatNode.children = node.children;
    flatNode.rev = node.rev;
    flatNode.parent = node.parent;
    flatNode.projectId = node.projectId;
    flatNode.numResults = node.numResults
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    flatNode.haschild = (node.numResults > 0)              //!!node.children?.length;
    return flatNode;
  };

  //----------------------------------------------------------------------------------
  activeNode: any;
  @Input() nodeChildren: any
  @Input() dialogOpen: boolean = false;
  @Input() selectedIds: any;

  constructor(private projectsService: ProjectsService, private SharedService: SharedService) {
    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this.getLevel,
      this.isExpandable,
      this.getChildren,
    );
    this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    if (!this.dialogOpen) {
      this.SharedService.breadCrumbsChildListSubject$.subscribe((value: any) => {
        this.dataSource.data = value;
      });
    } else {

      this.projectsService.getAppProjects().then((resp: any) => {
        this.dataSource.data = resp;
      });
    }
  }

  //----------------------------------------------------------------------------------
  activeNodeClicked(node: any, nodeClicked?: boolean) {
    nodeClicked = nodeClicked !== undefined ? nodeClicked : true
    this.activeNode = node;
  }

  //----------------------------------------------------------------------------------
  updateBreadCrumbs(node: any) {
    if (!this.dialogOpen) {
      this.SharedService.setIdValue(node.id, false);
      this.projectsService.setActiveNode(node);
    } else {
      const payload = [this.selectedIds, node.id];
      this.destinationId.emit(node.id)
      this.projectsService.moveResults(node.id,this.selectedIds);
    }
  }

}
