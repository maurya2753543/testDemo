import { Component, ElementRef, OnInit, ViewChild, Renderer2 } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTree, MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { ProjectsService } from 'src/app/services/projects.service';
import { SharedService } from 'src/app/services/shared.service';
import { SelectionModel } from '@angular/cdk/collections';
import { ConfirmationDialogComponent } from '../../confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';

interface ProjectNode {
  name: string;
  iconname?: string;
  children?: ProjectNode[];
}

interface TreeNode {
  name: string;
  children?: TreeNode[];
  isEditing?: boolean;
  newItem?: string;
  rev?: string;
}

import { DarkModeService } from 'src/app/services/darkMode.service';
import { BehaviorSubject } from 'rxjs';
class TodoItemNode {
  children: TodoItemNode[] = []
  name: string;
  id: string;
  rev: string;
  parent: string;
  projectId: string;
  numResults: number;
}

/** Flat to-do item node with expandable and level information */
class TodoItemFlatNode {
  name: string;
  level: number;
  expandable: boolean;
  children: any;
  id: string;
  rev: string;
  parent: string;
  projectId: string;
  haschild: boolean;
  numResults: number;
}
@Component({
  selector: 'app-project-nav-panel',
  templateUrl: './project-nav-panel.component.html',
  styleUrls: ['./project-nav-panel.component.scss']
})

export class ProjectNavPanelComponent implements OnInit {
  toolbarService: any;
  /* Drag and drop */
  dragNode: any;
  dragNodeExpandOverWaitTimeMs = 300;
  dragNodeExpandOverNode: any;
  dragNodeExpandOverTime?: any;
  dragNodeExpandOverArea?: any;
  disabledAdd: boolean = false;
  addProjectNodeTemplate: boolean = false;
  editedValue: string = ''
  projects: any;
  @ViewChild('myProjectNameField')
  myProjectNameFieldInput!: ElementRef;

  @ViewChild('saveProjectButton')
  saveProjectButton!: any;

  @ViewChild(MatTree)
  tree!: MatTree<any>;
  newProject: boolean = false;
  newFolderEditor: boolean = false;
  public selectedData: any[] = [];
  public dark: any;
  elementRef: any;
  treeData: any
  nodeId: any;
  breadcrumbs: any[] = []
  node: any
  /** Dark themes*/
  DarkThemesApply: any

  dataChange = new BehaviorSubject<TodoItemNode[]>([]);

  activeNode: any;


  //----------------------------------------------------------------------------------
  constructor(private projectsService: ProjectsService,
    private sharedService: SharedService,
    private el: ElementRef,
    private dialog: MatDialog, private renderer: Renderer2, public darkModeService: DarkModeService) {

    this.projectsService.getAppProjects().then((resp: any) => {
      this.dataSource.data = resp;
    });

    this.initialize();
    // Dark themes
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })
    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this.getLevel,
      this.isExpandable,
      this.getChildren,
    );
    this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

    this.dataChange.subscribe(data => {
      if (data.length > 0) {
        this.dataSource.data = data;

      }

    });

    this.projectsService.projectDataUpdatedSubject$.subscribe((message) => {
      this.projectsService.getProjectData(null).then((data) => {

        this.projectsService.getAppProjects().then((resp: any) => {
          this.dataSource.data = resp;
        });

      });

    });


  }

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.selectedData = this.sharedService.getSelectedData();
    this.projectsService.activeNodeSubject$.subscribe((node: any) => {
      this.nodeId = node;
      const nodeElement = this.getTreeNodeByKey(node);
      this.buildBreadScrumbsFromTree();
      nodeElement?.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted selected-background-highlight');
    });
    this.sharedService.valueidSubject$.subscribe((value: any) => {
      const nodeOldElement = this.getTreeNodeByKey(this.nodeId);
      nodeOldElement?.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted')
      this.nodeId = value.value;
      this.buildBreadScrumbsFromTree();

      const nodeElement = this.getTreeNodeByKey(this.nodeId);
      if (nodeElement) {
        nodeElement.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted selected-background-highlight');
      }
      if (!value.nodeClicked) {
        for (const node of this.breadcrumbs) {
          if (node.id === this.nodeId) {
            this.activeNode = node;
            this.node = node;
            this.triggerNodeClick(this.nodeId);
            return
          }
        }
      }
    })
  }

  //----------------------------------------------------------------------------------
  setActiveNode(node: TodoItemFlatNode) {
    this.activeNode = node;
  }

  //----------------------------------------------------------------------------------
  getActiveNode(): TodoItemFlatNode | undefined {
    return this.activeNode;
  }

  //----------------------------------------------------------------------------------
  get data(): TodoItemNode[] {
    return this.dataChange.value;
  }

  //----------------------------------------------------------------------------------
  triggerNodeClick(nodeId: string): void {
    const nodeElement = this.getTreeNodeByKey(nodeId);
    if (nodeElement) {
      // this.nodeClicked(this.node);
      nodeElement.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted selected-background-highlight');
    }
  }

  //----------------------------------------------------------------------------------
  initialize(incomeData?: any) {
    this.projectsService.getProjectChildren().then((treeData: any) => {
      this.dataChange.next(treeData);
      this.projectsService.setActiveNode(this.dataSource.data[0]);
    })
  }

  //----------------------------------------------------------------------------------
  /** Add an item to to-do list */
  insertItem(parent: TodoItemNode, name: string) {
    if (!parent.children) parent.children = [];
    parent.children.push({ name: name } as TodoItemNode);
    this.dataChange.next(this.data);
  }

  // //----------------------------------------------------------------------------------
  removeInsert() {
    this.el.nativeElement.querySelector('mat-tree .add-node-template').remove()
  }

  //----------------------------------------------------------------------------------
  updateItem(node: TodoItemNode, name: any, parentId: string, projectId: string, id: string) {
    node.name = Object.keys(name)[0];
    node.children = [];
    node.projectId = projectId;
    node.parent = parentId;
    node.id = id;
    this.dataChange.next(this.data);
  }

  //----------------------------------------------------------------------------------
  nodeClicked(node: any) {
    if (!this.treeControl.isExpanded(node)) {
      let parent = null;
      let index = this.treeControl.dataNodes.findIndex((n) => n.id === node.id);
      parent = this.treeControl.dataNodes[index];
      if (parent) {
        this.treeControl.collapseDescendants(parent);
        this.treeControl.expand(parent);
      } else {
        this.treeControl.collapseAll()
      }
      this.treeControl.expand(node);
    }
  }

  //----------------------------------------------------------------------------------
  // Get the DOM element of a node in the mat-tree based on its key
  getTreeNodeByKey(key: string): ElementRef | null {
    const treeNodes = Array.from(document.querySelectorAll('.mat-tree-node')) as Element[];
    for (const treeNode of treeNodes) {
      const nodeKey = treeNode.getAttribute('data-key');
      if (nodeKey === key) {
        return new ElementRef(treeNode);
      }
    }
    return null;
  }

  //----------------------------------------------------------------------------------
  addNewProjectClick(message: any) {
    this.projectsService.createProject(message).then((res: any) => {
      this.initialize()
    })
    this.newProject = false;
    this.addProjectNodeTemplate = false
  }

  //----------------------------------------------------------------------------------
  newSubProject() {
    console.log($localize`new sub Project`);
  }

  //----------------------------------------------------------------------------------
  newFolder() {
    console.log($localize`new folder`);
  }

  //----------------------------------------------------------------------------------
  logNode(node: any) {

  }

  //----------------------------------------------------------------------------------  
  activeNodeClicked(node: any, nodeClicked?: boolean) {
    this.activeNode = node;
  }

  //----------------------------------------------------------------------------------
  nodeClickBreadCrumbs(node: any, nodeClicked?: boolean) {
    this.activeNode = node;
    nodeClicked = nodeClicked !== undefined ? nodeClicked : true
    this.sharedService.setIdValue(node.id, nodeClicked);
    //this.buildBreadScrumbsFromTree()
    this.setActiveNode(node);
    this.projectsService.setActiveNode(node);
  }

  //----------------------------------------------------------------------------------
  dragHover(node: any) {

  }
  //----------------------------------------------------------------------------------
  dragHoverEnd() {

  }
  //----------------------------------------------------------------------------------
  dragStart() {

  }
  //----------------------------------------------------------------------------------
  drop(params: any) {

  }

  //----------------------------------------------------------------------------------
  handleDragOver(event: any, node: any) {
    event.preventDefault();
    // Handle node expand
    if (this.dragNodeExpandOverNode && node === this.dragNodeExpandOverNode) {
      if ((Date.now() - this.dragNodeExpandOverTime) > this.dragNodeExpandOverWaitTimeMs) {
        if (!this.treeControl.isExpanded(node)) {
          this.treeControl.expand(node);
          //this.cd.detectChanges();
        }
      }
    } else {
      this.dragNodeExpandOverNode = node;
      this.dragNodeExpandOverTime = new Date().getTime();
    }

    // Handle drag area
    const percentageY = event.offsetY / event.target.clientHeight;
    if (0 <= percentageY && percentageY <= 0.25) {
      this.dragNodeExpandOverArea = 1;
    } else if (1 >= percentageY && percentageY >= 0.75) {
      this.dragNodeExpandOverArea = -1;
    } else {
      this.dragNodeExpandOverArea = 0;
    }
  }

  //----------------------------------------------------------------------------------
  handleDrop(event: any, node: any) {

  }

  //----------------------------------------------------------------------------------
  handleDragEnd(event: any) {
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
    this.dragNodeExpandOverArea = NaN;
    event.preventDefault();
  }

  //----------------------------------------------------------------------------------
  dropHandler(event: any) {
    event.preventDefault();
    const payload = event.dataTransfer.getData('text/plain');
    const data = JSON.parse(payload);
  }


  // onGridDropped(event: CdkDragDrop<any>){
  //   console.log("called")
  //   const gridElemennt = event.name.element.nativeElement as HTMLElement;
  //   const draggedRow = event.name.data.row;
  //   console.log(draggedRow)
  //   console.log(gridElemennt)
  //  }

  //----------------------------------------------------------------------------------
  onDragOver(event: any) {
    //console.log( "onDragOver", event )
    // var dragSupported = event.dataTransfer.length;
    // if (dragSupported) {
    //   event.dataTransfer.dropEffect = 'move';
    // }
    event.preventDefault();
  }


  //----------------------------------------------------------------------------------
  // From drag and drop
  onDropSuccess(event: any) {
    const files = [...event.dataTransfer.files];
    event.preventDefault();
    this.projectsService.importProject(files[0].path);
    this.onFileChange(files);    // notice the "dataTransfer" used instead of "target"


  }

  //----------------------------------------------------------------------------------
  // From attachment link
  onChange(event: any) {
    this.onFileChange(event.target.files);    // "target" is correct here
  }
  //----------------------------------------------------------------------------------
  private onFileChange(files: File[]) {
    console.log("onFileChange", File)

  }

  ////////////////////////////////////////////Mat-tree- with add child and project feature////////////////////////////////////////////////////////////

  /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);

  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.name === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {
    const existingNode = this.nestedNodeMap.get(node);
    const flatNode =
      existingNode && existingNode.name === node.name ? existingNode : new TodoItemFlatNode();
    flatNode.name = node.name;
    flatNode.id = node.id;
    flatNode.level = level;
    flatNode.expandable = true;
    flatNode.children = node.children;
    flatNode.rev = node.rev;
    flatNode.parent = node.parent;
    flatNode.projectId = node.projectId;
    flatNode.numResults = node.numResults
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    flatNode.haschild = (node.numResults > 0)              //!!node.children?.length;
    return flatNode;
  };

  //----------------------------------------------------------------------------------
  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every(child => {
        return this.checklistSelection.isSelected(child);
      });
    return descAllSelected;
  }

  //----------------------------------------------------------------------------------
  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.descendantsAllSelected(node);
  }

  //----------------------------------------------------------------------------------
  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: TodoItemFlatNode): void {
    const nodeSelected = this.checklistSelection.isSelected(node);
    const descendants = this.treeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every(child => {
        return this.checklistSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.checklistSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.checklistSelection.select(node);
    }
  }

  //----------------------------------------------------------------------------------
  /** Select the category so we can insert the new item. */
  addNewItem(node: TodoItemFlatNode) {
    const parentNode = this.flatNodeMap.get(node);
    this.insertItem(parentNode!, '');
    this.treeControl.expand(node);
    this.disabledAdd = true    // mg was true
    node.haschild = true
  }

  //----------------------------------------------------------------------------------
  /** Save the node to database */
  saveNode(node: TodoItemFlatNode, itemValue: string) {
    const nestedNode = this.flatNodeMap.get(node);
    //
    this.projectsService.addFolderProject(this.activeNode.id, this.activeNode.projectId, itemValue).then((result: any) => {
      this.updateItem(nestedNode!, { [itemValue]: [''] }, this.activeNode.id, this.activeNode.projectId, result.id);
    })
    this.disabledAdd = false
  }


  //----------------------------------------------------------------------------------
  ////////trigger save on enter ///////////
  triggerProjectSave() {
    setTimeout(() => this.saveProjectButton._elementRef.nativeElement.click());
  }

  //----------------------------------------------------------------------------------
  triggerNodeSave(node: any, item: any) {
    this.saveNode(node, item);
  }

  //----------------------------------------------------------------------------------
  addNewProjectTemplate() {
    this.newProject = true;
    this.addProjectNodeTemplate = true;
    setTimeout(() => this.myProjectNameFieldInput.nativeElement.focus());
  }

  isEditing = false;
  editValue: string = '';

  //----------------------------------------------------------------------------------
  editNodeRecursive(nodes: TreeNode[] | undefined, nodeToEdit: TreeNode, editValue: string) {
    if (nodes)
      for (let i = 0; i < this.dataSource.data.length; i++) {
        if (this.dataSource.data[i].name === nodeToEdit.name) {
          this.dataSource.data[i].name = editValue;
          return;
        }

        this.dataSource.data = [...this.dataSource.data]
      }
  }

  //----------------------------------------------------------------------------------
  startEditing(node: TreeNode) {
    node.isEditing = true;
  }

  //----------------------------------------------------------------------------------
  stopEditing(node: TreeNode, newName: any) {
    node.name = newName.target.value;
    node.isEditing = false;
    this.projectsService.renameTreeNode(node, newName.target.value);
    this.projectsService.saveProjectSettings({ id: this.projectsService.activeNode.id, rev: this.projectsService.activeNode.rev }, { name: newName.target.value })
  }

  //----------------------------------------------------------------------------------
  cancelNode(activeNode?: any) {
    this.disabledAdd = false;
    this.addProjectNodeTemplate = false;
    if (activeNode) {
      this.removeInsert();
    }
  }

  //----------------------------------------------------------------------------------
  deleteNode(node: TreeNode): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (result === true) {
          const data = this.dataSource.data;
          const index = this.deleteNodeRecursive(data, node);
          if (index !== -1) {
            this.dataSource.data = [...data]; // Trigger update in the data source
          }
        }
        // Proceed with deletion
        // Delete the node from the data source or update it as desired
      } else {
        this.dialog.closeAll();
      }
    });
  }

  //----------------------------------------------------------------------------------
  private deleteNodeRecursive(nodes: TreeNode[] | undefined, nodeToDelete: TreeNode): number {
    let deletedIndex = -1;
    if (nodes) {
      for (let i = 0; i < nodes.length; i++) {
        if (nodes[i].name === nodeToDelete.name) {
          nodes.splice(i, 1);
          deletedIndex = i;
          this.projectsService.deleteProject(nodeToDelete).then(res => {
            console.log("deleteNodeRecursive ", res);
          })
          break;
        }
        if (nodes[i].children) {
          const index = this.deleteNodeRecursive(nodes[i].children, nodeToDelete);
          if (index !== -1) {
            deletedIndex = index;
            break;
          }
        }
      }
    }
    return deletedIndex;
  }

  //----------------------------------------------------------------------------------
  getBreadcrumbs(tree: any) {
    const breadCrumbId = this.nodeId;
    const breadcrumbs: any[] = [];
    function findItem(node: any) {
      let level = node.ancestors.length;
      if (node.id === breadCrumbId) {
        breadcrumbs.push({ 'name': node.name, 'id': node.id, "expandable": true, "children": node.children, "level": level });
        return true;
      }
      if (node.children) {
        for (const child of node.children) {
          if (findItem(child)) {
            breadcrumbs.unshift({ 'name': node.name, 'id': node.id, "expandable": true, "children": node.children, "level": level });
            return true;
          }
        }
      }
      return false;
    }
    for (const node of tree) {
      if (findItem(node)) {

        break;
      }
    }
    return breadcrumbs;
  }

  //----------------------------------------------------------------------------------
  buildBreadScrumbsFromTree() {
    this.projectsService.getProjectChildren().then((treeData: any) => {
      this.treeData = treeData;
      this.breadcrumbs = this.getBreadcrumbs(treeData);
      this.sharedService.setBreadcrumbsValue(this.breadcrumbs);
      this.activeNode = this.breadcrumbs[this.breadcrumbs.length - 1]
  
      this.breadcrumbs.forEach((value: any) => {
        this.nodeClicked(value);
      })
      this.triggerNodeClick(this.breadcrumbs[this.breadcrumbs.length - 1].id);
    })
  }
}
