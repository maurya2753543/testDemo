import { Component, Input, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
import {
  faCaretRight,
  faCircleCheck,
  faFileChartColumn,
  faFileExport,
  faFloppyDisk,
  faFloppyDiskPen,
  faFolderOpen,
  faImage,
  faQuestion,
  faXmarkCircle,
  faCloudArrowDown,
  faPenToSquare,
  faUsbDrive,
  faFileImport,
  faEllipsis,
  faTruckMoving,
  faTrash,
  faUserPen,
} from '@fortawesome/pro-solid-svg-icons';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { ReplacecableIdComponent } from '../../replace-cable-id/replace-cable-id.component';
import { moveFilesDialogComponent } from '../../move-files-dialog/move-files-dialog.component';
import { ReplaceTechnicianComponent } from '../../replace-technician/replace-technician.component';
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
interface TestResultRow {
  Timestamp: string;
  Test: string;
  Location: string;
  Status: string;
  Limit: string;
  device: string;
  id: number;
}
@Component({
  selector: 'app-project-info-panel',
  templateUrl: './project-info-panel.component.html',
  styleUrls: ['./project-info-panel.component.scss'],
})
export class ProjectInfoPanelComponent implements OnInit {
  // Dark themes
  DarkThemesApply: any;
  rowData: any;
  activeNode: any;
  @Input() selectedRows: any;
  constructor(
    private sharedService: SharedService,
    public darkModeService: DarkModeService,
    public projectsService: ProjectsService,
    private dialog: MatDialog
  ) {
    // for pdf making ins
    (pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
    this.projectsService.getProjectData(null).then((results) => {
      //todo check for error
      this.rowData = results;
    });

    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });

    this.projectsService.activeNodeSubject$.subscribe((node: any) => {
      this.activeNode = this.projectsService.getActiveNode();
    });
  }

  faCaretRight = faCaretRight;
  faCircleCheck = faCircleCheck;
  faFolderOpen = faFolderOpen;
  faFloppyDisk = faFloppyDisk;
  faFloppyDiskPen = faFloppyDiskPen;
  faFileExport = faFileExport;
  faFileChartColumn = faFileChartColumn;
  faHelpQuestion = faQuestion;
  faImage = faImage;
  faXMark = faXmarkCircle;
  faEllipsis = faEllipsis;
  menuHeader: any;
  faCloudArrowDown = faCloudArrowDown;
  faPenToSquare = faPenToSquare;
  faUsbDrive = faUsbDrive;
  faFileImport = faFileImport;
  faTruckMoving = faTruckMoving;
  faTrash = faTrash;
  faUserPen = faUserPen;
  selectedFile: any;
  importRow: any;
  gridApi: any;
  activeProject = 'Project Alpha';
  activeProjectPaths: any[] = [];
  selcetdProfile: any;
  //-----------------------------------------------------------------------

  ngOnInit(): void {
    this.sharedService.importFileDataSubjectNext$.subscribe((value: any) => {
      var id = this.rowData.length + 1;
      var row: TestResultRow = {
        Test: value.tests[0].label,
        Timestamp: value.tests[0].results.testTime,
        Location: value.tests[0].results.Location,
        Status: value.tests[0].results.status,
        device: value.assetInfo.model,
        id: id,
        Limit: 'NONE',
      };
      this.rowData.push(row);
      this.gridApi.setRowData(row);
    });
    // end share grid
    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });
    this.sharedService.valueBreadcrumbsSubject$.subscribe((value) => {
      this.menuHeader = value;
      this.activeProjectPaths = [];
      this.selcetdProfile =
        this.projectsService.getActiveProject().settings.profile.levels;
      this.menuHeader.forEach((element: any, index: any) => {
        this.activeProjectPaths.push({
          alias: this.selcetdProfile[index],
          name: element.name,
          id: element.id,
          children: element.children
        });
      });

      // Handle the value update in the grand-grand-grandparent component
    });
  }

  //-----------------------------------------------------------------------
  breadCrumb(id: string) {
    this.sharedService.setIdValue(id, false);
  }

  //-----------------------------------------------------------------------
  breadScrumsTree(children: any) {
    this.sharedService.setBreadCrumbsChildListSubject(children);
  }

  //-----------------------------------------------------------------------
  /** for the multiple file select for import */
  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input && input.files && input.files.length) {
      for (var i = 0; i < input.files.length; i++) {
        //console.log(input.files[i], 'how are select ++');
        this.selectedFile = input.files[i];
        //console.log(this.selectedFile, 'how are select ++');
        const reader = new FileReader();

        reader.onload = (e) => {
          const result = reader.result;

          this.projectsService.importResultFile(this.selectedFile, result);
        };

        if (this.selectedFile.name.endsWith(".json")) {
          reader.readAsText(input.files[i]);
        } else {
          reader.readAsArrayBuffer(input.files[i]);
        }
      }
    }
  }


  //-----------------------------------------------------------------------

  //   parseAndConvertToCDM(file: File): Promise<any> {
  //     return new Promise((resolve, reject) => {
  //       const reader = new FileReader();

  //       // Read the .sor file content as text
  //       reader.readAsText(file);

  //       // Handle the file reading completion
  //       reader.onload = () => {
  //         try {
  //           const fileContent = reader.result as string;
  //           const parsedData = this.parseSorFile(fileContent);
  //           const cdmData = this.convertToCdm(parsedData);
  //           resolve(cdmData);
  //         } catch (error) {
  //           reject(error);
  //         }
  //       };

  //       // Handle errors during file reading
  //       reader.onerror = (error) => {
  //         reject(error);
  //       };
  //     });
  //   }
  //-----------------------------------------------------------------------

  //   parseSorFile(fileContent: string): any[] {
  //     // Assuming the first row is the header row
  //     const rows = fileContent.trim().split('\n');
  //     if (rows.length < 2) {
  //       throw new Error(
  //         'Invalid .sor file format. At least two rows expected (header and data).'
  //       );
  //     }

  //     const headers = rows[0].split(',');

  //     const data = [];
  //     for (let i = 1; i < rows.length; i++) {
  //       const row = rows[i].split(',');
  //       if (row.length !== headers.length) {
  //         throw new Error(
  //           'Invalid .sor file format. Inconsistent number of columns.'
  //         );
  //       }

  //       const rowData: any = {};
  //       for (let j = 0; j < headers.length; j++) {
  //         rowData[headers[j]] = row[j];
  //       }

  //       data.push(rowData);
  //     }

  //     return data;
  //   }

  //-----------------------------------------------------------------------

  private convertToCdm(parsedData: any): any {
    // Implement the logic to convert the parsed data into the desired CDM format.
    // Return the converted data in the CDM structure.
    // Example: const cdmData = { ...parsedData };
    // Note: The specific conversion logic will depend on the CDM structure you defined.
  }
  //-----------------------------------------------------------------------

  onDeleteRows() {
    this.projectsService.deleteNode(this.selectedRows);
  }


  //-----------------------------------------------------------------------
  openeditProjectDialog(): void {
    this.dialog.open(ReplacecableIdComponent, {
      data: { data: this.selectedRows, DarkThemesApply: this.DarkThemesApply }
    });

  }

  //-----------------------------------------------------------------------
  editOperatorDialog(): void {
    this.dialog.open(ReplaceTechnicianComponent, {
      data: { data: this.selectedRows, DarkThemesApply: this.DarkThemesApply }
    });
  }

  //-----------------------------------------------------------------------
  moveFilesDialog(): void {
    this.dialog.open(moveFilesDialogComponent, {
      data: { data: this.selectedRows, DarkThemesApply: this.DarkThemesApply }
    });
  }

  //-----------------------------------------------------------------------
  closeDialog() {
    this.dialog.closeAll()
  }
}
