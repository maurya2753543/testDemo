import { Component, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
@Component({
  selector: 'app-replace-technician',
  templateUrl: './replace-technician.component.html',
  styleUrls: ['./replace-technician.component.scss']
})
export class ReplaceTechnicianComponent implements OnInit {
  constructor(private ProjectsService: ProjectsService,private SharedService: SharedService,  @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  technician: string = '';
  selectedData: any;

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.selectedData = this.data.data;
  }

  //----------------------------------------------------------------------------------
  onTechnicianFormSubmit() {
    const newData = this.selectedData.map((obj: any) => ({ ...obj, Technician: this.technician }));
    const toSaveData = this.selectedData.map((obj: any) => ({resultId: obj.id, name: this.technician })); 
    this.ProjectsService.updateOperator(toSaveData)
    this.SharedService.setUpdatedSelectRow(newData);
  }
}
