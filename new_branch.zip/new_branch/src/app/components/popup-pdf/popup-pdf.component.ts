import { Component, EventEmitter, Output ,Input,Inject , OnInit} from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { ProjectsService } from 'src/app/services/projects.service';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { ColDef, GridReadyEvent, IDateFilterParams, ITextFilterParams, RowDropZoneParams, RowNode, SideBarDef, StatusPanelDef, CellValueChangedEvent, Column, ColumnApi, GridApi, ICellRendererParams, IRowNode } from 'ag-grid-community';
import { saveAs } from 'file-saver-es';
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
import { HttpClient } from '@angular/common/http';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { MatTableDataSource, MatTable } from '@angular/material/table';
interface UserData {
  Original: string;
  Currently: string;
  NewFiber: string;
  Location: string;
}

import {
  faPlus,
  faFileImport,
  faEllipsis,
  faFloppyDisk,
  faFloppyDiskPen,
  faEdit,
  faFileExport,
  faClose
} from '@fortawesome/pro-solid-svg-icons';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';

// Declare the type for TDocumentDefinitions
interface TDocumentDefinitions {
  content: any[];
  styles?: any;
  pageSize?: any;
  pageOrientation?: any;
  pageMargins?: any;
  defaultStyle?: any;
  header?: any;
  footer?: any;
  images?: any;
  columns?: any;
  background?: any;
  pageBreakBefore?: (currentNode: any, followingNodesOnPage: any, nodesOnNextPage: any, previousNodesOnPage: any) => boolean;
  pageBreakAfter?: (currentNode: any, nodesOnNextPage: any) => boolean;
}


@Component({
  selector: 'app-popup-pdf',
  templateUrl: './popup-pdf.component.html',
  styleUrls: ['./popup-pdf.component.scss']
})

export class PopupPdfComponent  implements OnInit{
  faPlus = faPlus
  faFileImport = faFileImport
  faEllipsis = faEllipsis
  faFloppyDisk = faFloppyDisk
  faFloppyDiskPen = faFloppyDiskPen
  faEdit = faEdit;
  faFileExport = faFileExport
  faClose = faClose;
  rowPdfData: any;
  MappingPdfReportInfo: any= [];
// pdf file export header logic
// Dark themes
@Input() DarkThemesApply: any;
inputValue: any;
projectName: any; // for  anme selection
selectedId: string | null = null;
selectedName: any;
dataPdfSource: MatTableDataSource<UserData> = new MatTableDataSource<UserData>([]);
noRowselected: any;
//----------------------------------------------------------------------------------
// drag image
draggedImage: any;

//----------------------------------------------------------------------------------
constructor( public darkModeService: DarkModeService, @Inject(MAT_DIALOG_DATA) public data: any,
   private GlobalServicesetting :GlobalSettingsService,
  public ProjectsService: ProjectsService , private http: HttpClient){


// add project Name-------------------


}

ngOnInit(): void{
  this.ProjectsService.getPdfData().subscribe((data) => {
    this.dataPdfSource = data;
    this.rowPdfData= this.dataPdfSource;
  });
  this.ProjectsService.getNoRowPdfData().subscribe((e) => {
    this.noRowselected = e;
  });

  const ReportInfodata = this.ProjectsService.getActiveProject().reportInformation ? this.ProjectsService.getActiveProject().reportInformation : this.ProjectsService.settings.reportInformation;
  this.draggedImage=ReportInfodata.companyLogo;
  this.MappingPdfReportInfo=ReportInfodata;
  this.loadData();
  this.updateInputValueWithDateTime();
  this.projectName = this.ProjectsService.getActiveNode();



}
//---------------------------------------------------------------------------------------

updateInputValueWithDateTime(): void {
  // Get the current date and time
  const currentDateTime = new Date();

  // Format the date and time as desired (e.g., YYYY-MM-DD HH:mm:ss)
  const formattedDateTime = this.formatDateTime(currentDateTime);
  this.projectName = this.ProjectsService.getActiveNode();
  this.inputValue =this.projectName.name+"  "+formattedDateTime;

  // Set inputValue to the formatted date and time

}

formatDateTime(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Add 1 because months are zero-based
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}



//----------------------------------------------------------------------------------
loadData() {
  this.data = this.GlobalServicesetting.getReportInformations();
}


//----------------------------------------------------------------------------------
saveInputPdf() {
  const headerNames = [
    { field: 'Timestamp', displayName: 'Time Stamp' },
    { field: 'Test', displayName: 'Test Type' },
    { field: 'Location', displayName: 'Cable ID' },
    { field: 'Status', displayName: 'Status' },
    { field: 'Limit', displayName: 'Limit Type' },
    { field: 'device', displayName: 'Device' },

  ];

  // Create a header row with centered alignment
const columnHeaders = headerNames.map(header => ({
  text: header.displayName,
   bold: true,
  // width: '*', // This column will take the remaining space
  // fillColor: '#CCCCCC', // Set background color for the header row
}));
  const tableData = [columnHeaders]; // Create header row

  this.rowPdfData.forEach((row: any) => {
    const dataRow = headerNames.map(header => row[header.field]);
    tableData.push(dataRow);
  });
 // Fetch the SVG image using HttpClient
 this.http.get('assets/images/viavi_logo_rgb_purple.svg', { responseType: 'text' })
 .subscribe((svgContent: string) => {
  const logoImage = new Image();
    logoImage.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgContent);
   const image = new Image();
   // Define the background color you want to apply (e.g., red background)
 const backgroundColor = '#FFFFFF'; // HEX color code for red
// Set the desired width and height for the logo image
 const logoWidth = 200;
 const logoHeight = 40;
   image.onload = () => {
    const canvas = document.createElement('canvas');
  canvas.width = logoWidth;
  canvas.height = logoHeight;
  // Get the canvas context
  const ctx = canvas.getContext('2d');
  // Draw the background color on the canvas
//----------------------------------------------------------------------------------
  if (ctx) {
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    // Draw the logo image on top of the background
    ctx.drawImage(logoImage, 0, 0, logoWidth, logoHeight);
    // Convert canvas content to JPG data URL
    const jpgDataURL = canvas.toDataURL('image/jpeg');
    // here we set report in

    const companyTitle =  this.MappingPdfReportInfo.company;
    const streetaddressTitle =  this.MappingPdfReportInfo.streetaddress;
    const cityTitle =  this.MappingPdfReportInfo.city;
    const postalcodeTitle =  this.MappingPdfReportInfo.postalcode;
    const reportTitle = this.MappingPdfReportInfo.title || this.rowPdfData[0].Test ;


    if(this.rowPdfData[0].Test){
      const testtype =this.rowPdfData[0].Test;
    } else{
      const reportTitle = this.MappingPdfReportInfo.title;

    }
//----------------------------------------------------------------------------------
// Original width and height of the logo image default logo
const originalWidth = 400; // Replace with your actual original width
const originalHeight = 350; // Replace with your actual original height
const desiredWidth = 90; // Desired width for the logo
const aspectRatio = originalWidth / originalHeight;

// data hide and show besed on content avaiblity
//----------------------------------------------------------------------------------

const contentStack = [];
    contentStack.push({
        text: companyTitle ? `Company: ${companyTitle} `  : "",
        bold: true,
        fontSize: 8,
        alignment: 'left',
        width: '100', // Set the maximum width
        noWrap: false,
    });

//----------------------------------------------------------------------------------

// Check if at least one address field has data before showing the address section
    const addressStack = [];
        addressStack.push({
            text: streetaddressTitle ? `Street Address: ${streetaddressTitle} `  : "" ,
            bold: true,
            fontSize: 8,
            alignment: 'left',
            width: '100', // Set the maximum width
            noWrap: false,
        });

//----------------------------------------------------------------------------------
        addressStack.push({
            text: cityTitle ? `City: ${cityTitle} `  : "" ,
            bold: true,
            fontSize: 8,
            alignment: 'left',
            width: '100', // Set the maximum width
            noWrap: false,
        });

//----------------------------------------------------------------------------------
        addressStack.push({
            text: postalcodeTitle ? `Postal Code: ${postalcodeTitle} `  : "" ,
            bold: true,
            fontSize: 8,
            alignment: 'left',
            margin: [0, 0, 0, 0],
            width: '100', // Set the maximum width
            noWrap: false,
        });

//----------------------------------------------------------------------------------
    contentStack.push({
        stack: addressStack,
        // Adjust the width as needed
    });

const finalStack = {
    stack: contentStack,
    margin: [0, 5, 0, 0],

};

       // Now you can use the jpgDataURL in the documentDefinition
       const documentDefinition: TDocumentDefinitions = {
        content: [
          {
            table: {
              headerRows: 1, // Treat the first row as the header
              widths: ['20%', '20%', '40%', '20%'], // Adjust widths as needed
              layout: {
                hLineColor: () => '#000000', // Color of horizontal lines between rows
                vLineColor: () => '#000000', // Color of vertical lines between columns
              },
              body: [
                [
                  {
                    stack: [
                      this.draggedImage
                        ? {
                            image: this.draggedImage,
                            width: desiredWidth,
                            margin: [0, 5, 0, 0],
                            fontSize: 14,

                          }
                        : null,
                    ],
                  },
                  {
                    stack: [
                      finalStack,
                    ],
                  },
                  {
                    text:`${reportTitle}`,
                    fontSize: 14,
                    bold: true,
                    alignment: 'center',
                    margin: [0, 5, 100, 0],

                  },
                  {
                    stack: [
                      {
                        stack: [
                          {
                            image: jpgDataURL,
                            width: desiredWidth,
                            height: 40,
                            alignment: 'right',
                            margin: [0, 0, 0, 0],
                          },
                          {
                            text: 'ReportPRO v1.0',
                            fontSize: 9,
                            bold: true,
                            color: '#500778',
                            alignment: 'right',
                            margin: [0, 0, 10, 0],
                          },
                        ],
                      },
                    ],
                  },
                ],
              ],
            },
            layout: 'lightHorizontalLines', // Apply lines within the table

          },
          {
            table: {
              widths: ['50%', '50%'], // Equal width for both columns
              layout: {
                hLineColor: () => '#000000', // Color of horizontal lines between rows
                vLineColor: () => '#000000', // Color of vertical lines between columns
              },
              body: [
                [
                  {
                    text: formatDate(new Date()), // Format and display the current date
                    style: 'date',
                    alignment: 'right',
                    fontSize: 10,
                    margin: [0, 5, 0, 5],
                  },
                  {
                    text: formatTime(new Date()), // Format and display the current time
                    style: 'time',
                    alignment: 'left',
                    fontSize: 10,
                    margin: [0, 5, 0, 5],
                  },
                ],
              ],
              // Remove all cell borders
            },
            layout: 'lightHorizontalLines', // Apply lines within the table

          },

          {

            table: {
              widths: ['*'],
              // Set the column widths as needed
              body: [
                [
                  {
                    table: {

                      headerRows: 1,
                      body: tableData,
                      layout: {
                        hLineColor: () => '#000000', // Color of horizontal lines between rows
                        vLineColor: () => '#000000', // Color of vertical lines between columns
                      },
                    },
                     layout: 'lightHorizontalLines', // Apply lines within the table
                  },
                ],
              ],
            },
        }
          // Other content elements...
        ],

         footer: (currentPage: number, pageCount: number) =>
         createFooter(currentPage, pageCount), styles: {
           header: {
             fontSize: 16,
             bold: true,
           }
         }

       };
// Function to format the date in a desired format (e.g., 'YYYY-MM-DD')
function formatDate(date : any) {
  const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
  return date.toLocaleDateString(undefined, options);
}

// Function to format the time in a desired format (e.g., 'HH:mm:ss')
function formatTime(date : any) {
  const options = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
  return date.toLocaleTimeString(undefined, options);
}
//----------------------------------------------------------------------------------
// function for current and next page
// Define the footer function with dynamic content
    const createFooter = (currentPage: number, pageCount: number): any => {
  // Your dynamic footer content logic here

  const technicianTitle =   this.MappingPdfReportInfo.technician || '';
  const technicianEmail =   this.MappingPdfReportInfo.email || '';
  const technicianPhone =   this.MappingPdfReportInfo.phone || '';


  return {
    columns: [
      {
        table: {
          widths: ['33%', '33%', '33%'], // Equal width for all columns
          body: [
            [
              {
                text: `Technician: ${technicianTitle}`,
                style: 'header',
                alignment: 'left',
                fontSize: 10,
                margin: [20, 0, 0, 0],
                bold: true,
              },
              {
                text: `Page ${currentPage} of ${pageCount}`,
                alignment: 'center',
                fontSize: 10,
              },
              {
                text: [
                  '',
                  ` Email: ${technicianEmail}`,
                  { text: ` Phone: ${technicianPhone}` },
                ],
                alignment: 'right',
                fontSize: 10,
                margin: [0, 0, 20, 0],
                bold: true,
              },
            ],
          ],
          layout: 'noBorders', // Remove all cell borders
        },
        layout: 'lightHorizontalLines', // Apply lines within the table

      },
    ],
    styles: {
      header: {
        fontSize: 14,
        bold: true,
        alignment: 'center',
        margin: [0, 20, 0, 10],
      },
    },
  };
}
       const pdfDocGenerator = pdfMake.createPdf(documentDefinition);
       pdfDocGenerator.getBlob((pdfBlob: Blob) => {

         saveAs(pdfBlob, this.inputValue);
       });
     }
   };
   // Set the SVG content as the image source
   image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgContent);
 });
}

}
