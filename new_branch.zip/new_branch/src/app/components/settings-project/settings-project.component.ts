import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import {
  faPlus,
  faFileImport,
  faEllipsis,
  faFloppyDisk,
  faFloppyDiskPen,
  faEdit,
  faFileExport,
  faClose,
  faSave,
  faTrash,
} from '@fortawesome/pro-solid-svg-icons';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-settings-project',
  templateUrl: './settings-project.component.html',
  styleUrls: ['./settings-project.component.scss'],
})
export class SettingsProjectComponent implements OnInit {
  selcetdProfile: any;
  faPlus = faPlus;
  faFileImport = faFileImport;
  faEllipsis = faEllipsis;
  faFloppyDisk = faFloppyDisk;
  faFloppyDiskPen = faFloppyDiskPen;
  faEdit = faEdit;
  faFileExport = faFileExport;
  faClose = faClose;
  faSave = faSave;
  faTrash = faTrash;
  ProjectSettingsForm!: FormGroup;
  DistanceUnitsOptions: any[] = [{ name: 'Feets', value: 'feet' }, { name: 'Meters', value: 'meter' }, { name: 'Kilometer', value: 'km' }];
  PowerUnitsOptions: any[] = [{ name: 'dBm', value: 'dBm' }, { name: 'Watts', value: 'Watts' }];
  DarkThemesApply: any;
  ProjectlistDataShow: any[] = [];

  constructor(
    public darkModeService: DarkModeService,
    private globalSettingService: GlobalSettingsService,
    private projectsService: ProjectsService,
    private formBuilder: FormBuilder,
  ) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe((value) => {
      this.DarkThemesApply = value;
    });
    this.selcetdProfile = this.projectsService.getActiveProject().settings;
    // Set the default value
    // this.selectedProfileName =  // Use the appropriate property here, e.g., 'name'
    this.ProjectSettingsForm = this.formBuilder.group({
      name: this.selcetdProfile.profile.name,
      distanceUnits: this.selcetdProfile.distanceUnits,
      levelUnits: this.selcetdProfile.levelUnits
    });

    //----------------------------------------------------------------------------------
    // Retrieve the updated listData
    this.ProjectlistDataShow = this.globalSettingService.getProjectProfileListData();
  }

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.ProjectSettingsForm.valueChanges.subscribe((value) => {
      var selcetdProfileOption = this.ProjectlistDataShow.find(item => item.name === value.name);
      this.projectsService.saveProjectSettings({id:this.projectsService.activeNode.id, rev: this.projectsService.activeNode.rev},{settings: {'profile': selcetdProfileOption, 'levelUnits': value.levelUnits, 'distanceUnits': value.distanceUnits}})
    });
  }
}
