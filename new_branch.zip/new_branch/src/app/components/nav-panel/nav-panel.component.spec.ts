import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavPanelComponent } from './nav-panel.component';
// import {FontAwesomeModule} from "@fortawesome/angular-fontawesome"
// import {MatSidenavModule} from "@angular/material/sidenav"
// import {NoopAnimationsModule} from "@angular/platform-browser/animations"
// import {MatButtonModule} from '@angular/material/button'
// import {MatTooltipModule} from '@angular/material/tooltip'
// import { MatSlideToggleModule } from '@angular/material/slide-toggle'
// import { MatSnackBarModule } from '@angular/material/snack-bar'
// import {MatDialogModule} from '@angular/material/dialog'

describe('NavPanelComponent', () => {
  let component: NavPanelComponent;
  let fixture: ComponentFixture<NavPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NavPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
