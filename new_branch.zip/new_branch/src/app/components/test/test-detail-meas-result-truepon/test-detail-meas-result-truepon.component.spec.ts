import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasurementResultTruePonComponent } from './test-detail-meas-result-truepon.component';

describe('TestDetailMeasurementResultTruePonComponent', () => {
  let component: TestDetailMeasurementResultTruePonComponent;
  let fixture: ComponentFixture<TestDetailMeasurementResultTruePonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailMeasurementResultTruePonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailMeasurementResultTruePonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
