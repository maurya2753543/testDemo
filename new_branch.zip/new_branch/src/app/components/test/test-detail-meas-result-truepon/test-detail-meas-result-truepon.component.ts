import { Component, Input, OnInit } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-result-truepon',
  templateUrl: './test-detail-meas-result-truepon.component.html',
  styleUrls: ['./test-detail-meas-result-truepon.component.scss']
})
export class TestDetailMeasurementResultTruePonComponent implements OnInit {
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  truePonGpon: any;
  truePonxgspon: any;
  truePonConfig: any;
  constructor(private projectsService: ProjectsService) { }
  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.truePonGpon = this.detailData.tests[0].results.data.gpon;
    this.truePonConfig = this.detailData.tests[0].configuration;
    this.truePonxgspon = this.detailData.tests[0].results.data.xgspon;
    this.projectsService.selectedResultSubject$.subscribe(id => {
      this.detailData= [];
      this.detailData = this.projectsService.getResultFile(id);
      this.truePonGpon = this.detailData.tests[0].results.data.gpon;
      this.truePonConfig = this.detailData.tests[0].configuration;
      this.truePonxgspon = this.detailData.tests[0].results.data.xgspon;
    })

  }
}
