import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-tier1-mpo',
  templateUrl: './test-detail-meas-tier1-mpo.component.html',
  styleUrls: ['./test-detail-meas-tier1-mpo.component.scss']
})
export class TestDetailMeasTier1MpoComponent implements OnInit {
  @Input() DarkThemesApply: any;
  @Input() detailData: any
  tier1MpoData: any;
  value: any;
  statusColor: any;
  icon: any;

  //----------------------------------------------------------------------------------
  columnTierDefs: ColDef[] = [
    { field: 'fiberNumberLocal', headerName: 'Local', headerTooltip: "Local" },
    { field: 'fiberNumberRemote', headerName: 'Remote', headerTooltip: "Remote" },
    { field: 'loss', headerName: 'Loss', headerTooltip: "Loss(dB)" },
    { field: 'lossMarginUpper', headerName: 'Loss Margin Upper', headerTooltip: "Upper Margin(dB)" },
    { field: 'lossMarginLower', headerName: 'Loss Margin Lower', headerTooltip: "Lower Margin(dB)" },
    { field: 'lossTestStatus', headerName: 'Loss Test Status', cellRenderer: TestGridCellComponent, headerTooltip: "Status" },
    { field: 'power', headerName: 'Power', headerTooltip: "Power (dBm)" },
    { field: 'powerReference', headerName: 'Power Reference', headerTooltip: "Ref (dBm)" },
    { field: 'powerReferenceTime', headerName: 'Power Reference Time', headerTooltip: "Ref Time" },
    { field: 'signalStatus', headerName: 'Signal Status', headerTooltip: "Signal Status" }
  ];
  constructor(private projectsService: ProjectsService) { }
  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.tier1MpoData = this.detailData;

      //----------------------------------------------------------------------------------
      this.projectsService.selectedResultSubject$.subscribe(id => {
        this.detailData= [];
        this.detailData = this.projectsService.getResultFile(id);
        this.tier1MpoData = this.detailData;
      })

    if (this.tier1MpoData.tests[0].results.data.lengthTestStatus.toUpperCase() === 'PASS') {
      this.statusColor = "pass-color"
      this.icon = "fa-circle-check"
    } else {
      this.statusColor = "fail-color"
      this.icon = "fa-circle-xmark"
    }
  }

}
