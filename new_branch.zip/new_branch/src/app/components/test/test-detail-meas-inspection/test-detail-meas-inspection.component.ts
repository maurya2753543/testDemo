import { Component, Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';

@Component({
  selector: 'app-test-detail-meas-inspection',
  templateUrl: './test-detail-meas-inspection.component.html',
  styleUrls: ['./test-detail-meas-inspection.component.scss']
})

export class TestMeasurementInspectionComponent {
  columnInspetionDefs: ColDef[] = [
    { field: 'name', headerName: 'Name',  headerTooltip: "name", width: 340 },
    { field: 'passesAll', headerName: 'Passes All', cellRenderer: TestGridCellComponent, headerTooltip: "Status",width: 320 },
    { field: 'passesDefects', headerName: 'Passes Defects', cellRenderer: TestGridCellComponent, headerTooltip: "defect",width: 340 }
  ];

  //----------------------------------------------------------------------------------
  imageUrl: any = [];
  @Input() DarkThemesApply: any;
  @Input() detailData: any
  inspectionData: any;

  //----------------------------------------------------------------------------------
  ngOnInit() {
    const magData = [];
    this.inspectionData = this.detailData.tests[0];
    console.log(this.detailData.tests[0]);
    if( this.detailData.tests[0].results.data.endfaces.length > 1 ) { console.log( "MPO, ", this.detailData.tests[0].results.data.endfaces.length )}
    else {
    magData.push(
      {
        'atob': this.inspectionData.results.data.endfaces[0].images.lowMag.fiberAndOverlaysImage.dataBase64, 'label': 'Low Magnification', "width": this.inspectionData.results.data.endfaces[0].images.lowMag.fiberImage.width,
        "height": this.inspectionData.results.data.endfaces[0].images.lowMag.fiberImage.height
      },
      {
        'atob': this.inspectionData.results.data.endfaces[0].images.highMag.fiberAndOverlaysImage.dataBase64, 'label': 'High Magnification', "width": this.inspectionData.results.data.endfaces[0].images.highMag.fiberImage.width,
        "height": this.inspectionData.results.data.endfaces[0].images.highMag.fiberImage.height
      });
    }

    magData.forEach(element => {
      this.converBase64ToBinary(element);
    });
  }

  //----------------------------------------------------------------------------------
  converBase64ToBinary(data: any) {
    // Convert Base64 to binary data
    const binaryData = atob(data.atob);

    // Convert binary data to an ArrayBuffer
    const buffer = new ArrayBuffer(binaryData.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < binaryData.length; i++) {
      view[i] = binaryData.charCodeAt(i);
    }

    // Convert ArrayBuffer to Blob
    const blob = new Blob([buffer], { type: 'image/png' }); // Specify the appropriate MIME type

    // Create a URL for the Blob
    this.imageUrl.push({ 'img': URL.createObjectURL(blob), 'label': data.label, "width": data.width, "height": data.height });
  }
}
