import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';

import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-title',
  templateUrl: './test-detail-meas-title.component.html',
  styleUrls: ['./test-detail-meas-title.component.scss']
})
export class TestDetailMeasurementTitleComponent implements OnInit {

  cdm: any;
  statusColor: string = ''
  icon: string = ''
  hideDetail: boolean = true;

  constructor(private projectsService: ProjectsService, private sharedService: SharedService) {}

  ngOnInit(): void {

    this.projectsService.selectedResultSubject$.subscribe( id => {
        this.cdm = this.projectsService.getResultFile( id );
        //console.log( "Test Measurement Title" ,  id._id, this.cdm );
        let status =this.cdm.tests[0].results.status.toUpperCase();
        if (status === 'FAIL') {
            this.statusColor = "red"
            this.icon = "fa-circle-xmark"
          } else  {
            this.statusColor = "green"
            this.icon = "fa-circle-check"
          }
          if (status === 'NONE') {
            this.statusColor = "darkgray"
            this.icon = "fa-solid fa-circle-question"
          }
          this.hideDetail = false;
    
      });

  }

}
