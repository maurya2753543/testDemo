import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasTier1Component } from './test-detail-meas-tier1.component';

describe('TestDetailMeasTier1Component', () => {
  let component: TestDetailMeasTier1Component;
  let fixture: ComponentFixture<TestDetailMeasTier1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestDetailMeasTier1Component]
    });
    fixture = TestBed.createComponent(TestDetailMeasTier1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
