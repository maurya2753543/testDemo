import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-tier1',
  templateUrl: './test-detail-meas-tier1.component.html',
  styleUrls: ['./test-detail-meas-tier1.component.scss']
})
export class TestDetailMeasTier1Component implements OnInit {

  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  dataSource: any;
  tier1DetailData: any;
  //----------------------------------------------------------------------------------
  columnTierDefs: ColDef[] = [
    { field: 'loss', headerName: 'Loss', headerTooltip: "Loss(dB)" },
    { field: 'lossMarginUpper', headerName: 'Loss Margin Upper', headerTooltip: "Upper Margin(dB)" },
    { field: 'lossMarginLower', headerName: 'Loss Margin Lower', headerTooltip: "Lower Margin(dB)" },
    { field: 'lossTestStatus', headerName: 'Loss Test Status', cellRenderer: TestGridCellComponent, headerTooltip: "Status" },
    { field: 'power', headerName: 'Power', headerTooltip: "Power (dBm)" },
    { field: 'powerReference', headerName: 'Power Reference', headerTooltip: "Ref (dBm)" },
    { field: 'powerReferenceTime', headerName: 'Power Reference Time', headerTooltip: "Ref Time" },
    { field: 'signalStatus', headerName: 'Signal Status', cellRenderer: TestGridCellComponent, headerTooltip: "Signal Status" }
  ];
  constructor(private projectsService: ProjectsService) { }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource = this.detailData.tests[0].results.data.optical;
    this.tier1DetailData = this.detailData;

    //----------------------------------------------------------------------------------
    this.projectsService.selectedResultSubject$.subscribe(id => {
      this.tier1DetailData = [];
      this.tier1DetailData = this.projectsService.getResultFile(id);
      this.dataSource = this.tier1DetailData.tests[0].results.data.optical;
    })
  }

}
