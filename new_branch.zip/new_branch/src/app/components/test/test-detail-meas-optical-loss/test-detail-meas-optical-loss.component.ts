import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-optical-loss',
  templateUrl: './test-detail-meas-optical-loss.component.html',
  styleUrls: ['./test-detail-meas-optical-loss.component.scss']
})
export class TestMeasurementOpticalLossComponent implements OnInit {
  dataSource1: any;
  dataSource2: any;
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  opticalLossConfig: any;

  constructor(private projectsService: ProjectsService) { }
  //----------------------------------------------------------------------------------
  displayedColumns1: ColDef[] = [
    { field: 'wavelengthNm', headerName: 'Wavelength', headerTooltip: "Wavelength" },
    { field: 'lossdB', headerName: 'Loss(dB)', headerTooltip: "loss" },
    { field: 'status', headerName: 'Status', cellRenderer: TestGridCellComponent, headerTooltip: "status" },
    { field: 'powerReferencedBm', headerName: 'Power Reference(dBm)', headerTooltip: "Reference" },
    { field: 'powerReferenceTime', headerName: 'Power Reference Time', headerTooltip: "refTimeStamp" }
  ];

  //----------------------------------------------------------------------------------
  displayedOpticalLoss2: ColDef[] = [
    { field: 'wavelengthNm', headerName: 'Wavelength', headerTooltip: "Wavelength" },
    { field: 'lowerThresholddB', headerName: 'lower Threshold(dB)', headerTooltip: "low" },
    { field: 'lowerMarginalThresholddB', headerName: 'Lower Marginal Threshold(dB)', headerTooltip: "lowMarginal" },
    { field: 'upperMarginalThresholddB', headerName: 'Upper Marginal Threshold(dB)', headerTooltip: "highMarginal" },
    { field: 'upperThresholddB', headerName: 'Upper Threshold(dB)', headerTooltip: "high" }
  ];

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
    this.dataSource2 = this.detailData.tests[0].configuration.setup;
    this.opticalLossConfig = this.detailData.tests[0].configuration;
      //----------------------------------------------------------------------------------
      this.projectsService.selectedResultSubject$.subscribe( id => {
        this.detailData= [];
        this.detailData = this.projectsService.getResultFile( id );
        this.detailData = this.projectsService.getResultFile(id);
        this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
        this.dataSource2 = this.detailData.tests[0].configuration.setup;
        this.opticalLossConfig = this.detailData.tests[0].configuration;
    });
  }
}
