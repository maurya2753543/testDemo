import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasOntDetectonComponent } from './test-detail-meas-ont-detecton.component';

describe('TestDetailMeasOntDetectonComponent', () => {
  let component: TestDetailMeasOntDetectonComponent;
  let fixture: ComponentFixture<TestDetailMeasOntDetectonComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestDetailMeasOntDetectonComponent]
    });
    fixture = TestBed.createComponent(TestDetailMeasOntDetectonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
