import { Component, Input, OnInit } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';
@Component({
  selector: 'app-test-detail-meas-ont-detecton',
  templateUrl: './test-detail-meas-ont-detecton.component.html',
  styleUrls: ['./test-detail-meas-ont-detecton.component.scss']
})
export class TestDetailMeasOntDetectonComponent implements OnInit {

  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  OntDetectonDetailData: any;
  constructor(private projectsService: ProjectsService) { }
  
  ngOnInit(): void {
    this.OntDetectonDetailData = this.detailData;
      //----------------------------------------------------------------------------------
      this.projectsService.selectedResultSubject$.subscribe(id => {
        this.detailData= [];
        this.detailData = this.projectsService.getResultFile(id);
        this.OntDetectonDetailData = this.detailData;
      })
  }
}
