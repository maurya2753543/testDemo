import { Component, Input, OnInit } from '@angular/core';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';
import { ColDef } from 'ag-grid-community';
import { ProjectsService } from 'src/app/services/projects.service';
@Component({
  selector: 'app-test-detail-meas-inspection-mpo',
  templateUrl: './test-detail-meas-inspection-mpo.component.html',
  styleUrls: ['./test-detail-meas-inspection-mpo.component.scss']
})
export class TestDetailMeasInspectionMpoComponent implements OnInit {
  @Input() DarkThemesApply: any;
  @Input() detailData: any;
  opticalPowerMpoData: any;
  imageUrl: any[] = [];
  imageUrl1: any[] = [];
  imageUrl2: any[] = [];
  imageUrl3: any[] = [];
  displayImg: any;
  overallEvaluationResult: any;
  selectedImageIndex: number = 0;
  displayRowsCols: any;
  constructor(private projectsService: ProjectsService) {

  }
  //----------------------------------------------------------------------------------
  // Column definitions for AG-Grid
  columnInspetionDefs: ColDef[] = [
    { field: 'name', headerName: 'Name', headerTooltip: "name", width: 185 },
    { field: 'passesAll', headerName: 'Passes All', cellRenderer: TestGridCellComponent, headerTooltip: "Status", width: 185 },
    { field: 'passesDefects', headerName: 'Passes Defects', cellRenderer: TestGridCellComponent, headerTooltip: "defect", width: 222 }
  ];

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.opticalPowerMpoData = this.detailData;
    this.processEndfaceImages();
    this.projectsService.selectedResultSubject$.subscribe(id => {
      this.opticalPowerMpoData = []
      this.opticalPowerMpoData = this.projectsService.getResultFile(id);
      if (this.opticalPowerMpoData.tests[0].type === 'fiberInspection' && this.opticalPowerMpoData.tests[0].results.data.endfaces.length > 1) {
        this.processEndfaceImages();
      }
    })

  }

  //----------------------------------------------------------------------------------
  private processEndfaceImages() {
    this.imageUrl = [];
    this.imageUrl1 = [];
    this.imageUrl2 = [];
    this.imageUrl3 = [];
    this.opticalPowerMpoData.tests[0].results.data.endfaces.forEach((element: any, index: number) => {
      this.convertBase64ToBinary(element, index, this.opticalPowerMpoData.tests[0].configuration.connectorStructure.rowCount);
    });
  }

  //----------------------------------------------------------------------------------
  private convertBase64ToBinary(data: any, index: number, rowCount: number) {
    let blob;
    if (data.images) {
      const binaryData = atob(data.images.highMag.fiberImage.dataBase64);
      const buffer = new ArrayBuffer(binaryData.length);
      const view = new Uint8Array(buffer);
      for (let i = 0; i < binaryData.length; i++) {
        view[i] = binaryData.charCodeAt(i);
      }
      blob = new Blob([buffer], { type: 'image/png' });
    }
    if (data.rowPos === 1) {
      this.imageUrl.push(
        {
          'img': blob ? URL.createObjectURL(blob) : null,
          "rowPos": data.rowPos,
          "columnPos": data.columnPos,
          "width": data.images ? data.images.highMag.fiberImage.width : null,
          'index': index, "status": data.status,
          "height": data.images ? data.images.highMag.fiberImage.height : null,
          'overallEvaluationResult': data.overallEvaluationResult
        });
      this.imageUrl.sort((a, b) => a.columnPos - b.columnPos);
    } else if (data.rowPos === 2) {
      this.imageUrl1.push(
        {
          'img': blob ? URL.createObjectURL(blob) : null,
          "rowPos": data.rowPos,
          "columnPos": data.columnPos,
          "width": data.images ? data.images.highMag.fiberImage.width : null,
          'index': index, "status": data.status,
          "height": data.images ? data.images.highMag.fiberImage.height : null,
          'overallEvaluationResult': data.overallEvaluationResult
        });
      this.imageUrl.sort((a, b) => a.columnPos - b.columnPos);
    } else if (data.rowPos === 3) {
      this.imageUrl2.push(
        {
          'img': blob ? URL.createObjectURL(blob) : null,
          "rowPos": data.rowPos,
          "columnPos": data.columnPos,
          "width": data.images ? data.images.highMag.fiberImage.width : null,
          'index': index, "status": data.status,
          "height": data.images ? data.images.highMag.fiberImage.height : null,
          'overallEvaluationResult': data.overallEvaluationResult
        }); this.imageUrl2.sort((a, b) => a.columnPos - b.columnPos);
    } else if (data.rowPos === 4) {
      this.imageUrl3.push(
        {
          'img': blob ? URL.createObjectURL(blob) : null,
          "rowPos": data.rowPos,
          "columnPos": data.columnPos,
          "width": data.images ? data.images.highMag.fiberImage.width : null,
          'index': index, "status": data.status,
          "height": data.images ? data.images.highMag.fiberImage.height : null,
          'overallEvaluationResult': data.overallEvaluationResult
        });
      this.imageUrl3.sort((a, b) => a.columnPos - b.columnPos);
    }

    if (!this.displayImg) {
      this.displayImg = this.imageUrl[0];
      this.overallEvaluationResult = this.imageUrl[0].overallEvaluationResult;
    }
  }

  //----------------------------------------------------------------------------------
  displayImgClick(img: any) {
    this.displayImg = img;
    this.overallEvaluationResult = img.overallEvaluationResult;
    this.selectedImageIndex = img.index;
  }
}
