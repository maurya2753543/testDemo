import { Component } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-configuration',
  templateUrl: './test-detail-configuration.component.html',
  styleUrls: ['./test-detail-configuration.component.scss']
})
export class TestConfigurationComponent {


    constructor( private projectsService: ProjectsService ) {



    }

    ngOnInit() : void {

        this.projectsService.selectedResultSubject$.subscribe( id => {
            //console.log( "Test Config Tab" ,  id._id);
          });
    }



}
