import { Component, Input, OnInit } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { ProjectsService } from 'src/app/services/projects.service';

export interface ResultTableData {
  name?: string;
  description?: string;
  type: string;
  expireDate: string;
}
let TABBLE1_DATA: ResultTableData[] = [];
//   { name: 'TPA', description: 'Test Process Automation', type: 'SW Permanent', expireDate: 'n/a' },
//   { name: 'Turbo', description: 'Turbo Processor', type: 'HW', expireDate: 'n/a' }
// ];

@Component({
  selector: 'app-test-detail-instrument',
  templateUrl: './test-detail-instrument.component.html',
  styleUrls: ['./test-detail-instrument.component.scss'],
})
export class TestInstrumentComponent implements OnInit {
  //   myData: any;
  //   detailData: any;
  cdm: any;
  optionsDetected = false;
  hideDetail: boolean = true;

  @Input() DarkThemesApply: string | undefined;
  //isDarkThemesActive: boolean = false;

  //@Input() selectedRow: any

  constructor(
    private projectsService: ProjectsService,
    private DarkModeService: DarkModeService
  ) {}

  ngOnInit(): void {
    this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply=value

    })
    this.projectsService.selectedResultSubject$.subscribe((id) => {
      this.cdm = this.projectsService.getResultFile(id);
      //console.log( "Test Instruments Tab " ,  id._id, this.cdm);
      this.optionsDetected = false;
      this.hideDetail = false;

      TABBLE1_DATA = [];
      if (
        this.cdm.assetInfo.swOptions &&
        this.cdm.assetInfo.swOptions.length > 0
      ) {
        this.optionsDetected = false;
        // create the table here
        let row = {
          name: 'TPA1',
          description: 'Test Process Automation',
          type: 'SW Permanent',
          expireDate: 'n/a',
        };
        TABBLE1_DATA.push(row);
      }

      if (
        this.cdm.assetInfo.hwOptions &&
        this.cdm.assetInfo.hwOptions.length > 0
      ) {
        let row = {
          name: 'Turbo',
          description: 'CPU upgrade',
          type: 'Hardware',
          expireDate: 'n/a',
        };
        TABBLE1_DATA.push(row);
      }
    });
  }

  displayedColumns: string[] = ['name', 'description', 'type', 'expireDate'];
  dataSource = TABBLE1_DATA;

  uppercaseValue(word: any) {
    const result = word.replace(/[A-Z]/g, ' $&');
    return result[0].toUpperCase() + result.substr(1);
  }

  //upddateRowCheckedData(selectedRow: any, cdm: any) {

  //   console.log( "I>>>>>>>", selectedRow, cdm )
  //this.detailData.tests[0].label = selectedRow.Test;
  //this.cdm = cdm;
  // this.selectedRow = selectedRow;
  // this.hideDetail = false;
  // TABBLE1_DATA = [];
  // if( cdm.assetInfo.swOptions && cdm.assetInfo.swOptions.length > 0 ) {
  //     // create the table here
  //     let row = {
  //         name: 'TPA1',
  //         description: 'Test Process Automation',
  //         type: 'SW Permanent',
  //         expireDate: 'n/a'
  //     }
  //     TABBLE1_DATA.push(row)

  // }

  // if( cdm.assetInfo.hwOptions && cdm.assetInfo.hwOptions.length > 0 ) {
  //     let row = {
  //         name: 'Turbo',
  //         description: 'CPU upgrade',
  //         type: 'Hardware',
  //         expireDate: 'n/a'
  //     }
  //     TABBLE1_DATA.push(row)
  // }

  // }
}
