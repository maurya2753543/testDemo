import { Component, Input } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';


@Component({
  selector: 'app-test-detail-meas-info',
  templateUrl: './test-detail-meas-info.component.html',
  styleUrls: ['./test-detail-meas-info.component.scss']
})
export class TestDetailMeasurementInfoComponent {

  detailInfo: any
  hideDetail: boolean = true;
  //isDarkThemes logic
  @Input() DarkThemesApply: any;
  @Input() detailData: any;

location!: string;

  constructor(private projectService :ProjectsService){

  }
  ngOnInit(): void {
    this.hideDetail = false;
    this.detailInfo = this.detailData;

    this.projectService.setDetailInfo(this.detailData)

    console.log(this.detailInfo ,this.detailData, "this.detailInfo in test  whata this.detailData test")


    if ( this.detailInfo.tests[0].testLocations ) {
        this.location = this.detailInfo.tests[0].testLocations[0].label;
    } else {
        this.location = ""
    }




  }

}
