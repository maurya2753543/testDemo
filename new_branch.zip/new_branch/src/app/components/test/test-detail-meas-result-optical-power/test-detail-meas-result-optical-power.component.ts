import { Component, Input } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TestGridCellComponent } from '../../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-test-detail-meas-result-optical-power',
  templateUrl: './test-detail-meas-result-optical-power.component.html',
  styleUrls: ['./test-detail-meas-result-optical-power.component.scss']
})
export class TestDetailMeasurementResultOpticalPowerComponent {
  @Input() detailData: any;
  @Input() DarkThemesApply: any;
  dataSource2: any;
  dataSource1: any;
  opticalPowerConfig: any;
  constructor(private projectsService: ProjectsService) { }
  //---------------------------------------------------------------
  columnMeasOpticalDefs1: ColDef[] = [
    { field: 'wavelengthNm', headerName: 'Wavelength(Nm)', headerTooltip: "wavelength", width: 320 },
    { field: 'absolutePowerdBm', headerName: 'Absolute Power(dBm)', headerTooltip: "power", width: 330, },
    { field: 'absoluteTestStatus', headerName: 'Absolute Test Status', cellRenderer: TestGridCellComponent, headerTooltip: "status", width: 330 }
  ];

  //---------------------------------------------------------------
  columnMeasOpticalDefs2: ColDef[] = [
    { field: 'wavelengthNm', headerName: 'Wavelength(Nm)', headerTooltip: "wavelength" , width: 250},
    { field: 'lowerThresholddBm', headerName: 'Lower Threshold(dBm)', headerTooltip: "low"  , width: 250 },
    { field: 'lowerMarginalThresholddBm', headerName: 'Lower Marginal Threshold(dBm)', headerTooltip: "lowMarginal"  , width: 250},
    { field: 'upperMarginalThresholddBm', headerName: 'Upper Marginal Threshold(dBm)', headerTooltip: "highMarginal"  , width: 250 },
    { field: 'upperThresholddBm', headerName: 'Upper Threshold(dBm)', headerTooltip: "high"  , width: 250}
  ];

  //---------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
    this.dataSource2 = this.detailData.tests[0].configuration.setup;
    this.opticalPowerConfig = this.detailData.tests[0].configuration;
    this.projectsService.selectedResultSubject$.subscribe(id => {
      this.detailData= [];
      this.detailData = this.projectsService.getResultFile(id);
      this.dataSource1 = this.detailData.tests[0].results.data.measuredResults;
      this.dataSource2 = this.detailData.tests[0].configuration.setup;
      this.opticalPowerConfig = this.detailData.tests[0].configuration;
    })
  }
}
