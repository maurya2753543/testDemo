import {Component, Input, Output, ChangeDetectorRef } from '@angular/core';
import {
    faUp,
    faDown
  } from '@fortawesome/pro-solid-svg-icons'
import { TestDetailTabsComponent } from '../test-detail-tabs/test-detail-tabs.component';
import { ProjectsService } from 'src/app/services/projects.service';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-test-detail-meas',
  templateUrl: './test-detail-meas.component.html',
  styleUrls: ['./test-detail-meas.component.scss']
})
export class TestDetailPanelComponent {

  constructor(private projectsService: ProjectsService, private DarkModeService: DarkModeService, private ChangeDetectorRef: ChangeDetectorRef) { }
    faUp = faUp
    faDown = faDown
    detailData: any
    cdm: any;
    cmdTier1Mpo: any;
    cmdONTDetection: any;
    measurementType : any;
    inspMpoData: any;
    hideDetail: boolean = true;
    @Input() selectedRow: any

    DarkThemesApply :any

    sidebyside = true;
    myDirection:any = 'vertical';

  //----------------------------------------------------------------------------------
    ngOnInit(): void {
      this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value
      })

  //----------------------------------------------------------------------------------
    this.projectsService.selectedResultSubject$.subscribe( id => {
        this.cdm = [];
        this.hideDetail = true
        this.measurementType = '';
        this.cdm = this.projectsService.getResultFile( id );
        this.cmdONTDetection = this.projectsService.getONTResult();
        this.measurementType = this.cdm.tests[0].type;
        this.hideDetail = false;
        this.ChangeDetectorRef.detectChanges()
    });
  }
  
  //----------------------------------------------------------------------------------
    setSplit() {
        this.sidebyside = !this.sidebyside;
        if (this.sidebyside) {
            this.myDirection = 'vertical';
        } else {
            this.myDirection = 'horizontal';
        }
    }
}
