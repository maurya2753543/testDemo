import { Component, Input, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-replace-cabel-id',
  templateUrl: './replace-cabel-id.component.html',
  styleUrls: ['./replace-cabel-id.component.scss']
})
export class ReplaceCabelIdComponent implements OnInit {
  @Input() data: any;
  dataSource: any;
  newCabelId: string = '';
  oldCabelId: string = '';

  columnSelectedDefs: ColDef[] = [
    { field: 'Location', headerName: 'Location', headerTooltip: "Location" },
    { field: 'NewLocation', headerName: 'NewLocation', headerTooltip: "New Location" }
  ];
  constructor(private SharedService: SharedService) { }

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource = this.data.data.map((obj: any) => ({ ...obj, NewLocation: obj.Location }));
  }

  //----------------------------------------------------------------------------------
  onApply() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, NewLocation: obj.Location.replace(this.oldCabelId, this.newCabelId) }));
  }

  //----------------------------------------------------------------------------------
  onCabelIdFormSubmit() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, Location: obj.NewLocation }));
    this.SharedService.setUpdatedSelectRow(this.dataSource);
  }
}
