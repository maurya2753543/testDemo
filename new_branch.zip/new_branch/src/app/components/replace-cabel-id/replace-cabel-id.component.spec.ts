import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplaceCabelIdComponent } from './replace-cabel-id.component';

describe('ReplaceCabelIdComponent', () => {
  let component: ReplaceCabelIdComponent;
  let fixture: ComponentFixture<ReplaceCabelIdComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReplaceCabelIdComponent]
    });
    fixture = TestBed.createComponent(ReplaceCabelIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
