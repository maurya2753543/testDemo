import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplacecableIdComponent } from './replace-cable-id.component';

describe('ReplacecableIdComponent', () => {
  let component: ReplacecableIdComponent;
  let fixture: ComponentFixture<ReplacecableIdComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReplacecableIdComponent]
    });
    fixture = TestBed.createComponent(ReplacecableIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
