import { Component, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ColDef } from 'ag-grid-community';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-replace-cable-id',
  templateUrl: './replace-cable-id.component.html',
  styleUrls: ['./replace-cable-id.component.scss']
})
export class ReplacecableIdComponent implements OnInit {
  dataSource: any;
  newcableId: string = '';
  oldcableId: string = '';
  DarkThemesApply: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, private SharedService: SharedService, private ProjectsService: ProjectsService) {
    this.dataSource = new MatTableDataSource<any>(data.data);
    this.DarkThemesApply = data.DarkThemesApply;
  }


  columnSelectedDefs: ColDef[] = [
    { field: 'Location', headerName: 'Location', headerTooltip: "Location" },
    { field: 'NewLocation', headerName: 'NewLocation', headerTooltip: "New Location" }
  ];

  //----------------------------------------------------------------------------------
  ngOnInit(): void {
    this.dataSource = this.dataSource.data.map((obj: any) => ({ ...obj, NewLocation: obj.Location }));
  }

  //----------------------------------------------------------------------------------
  onApply() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, NewLocation: obj.Location.replace(this.oldcableId, this.newcableId) }));
  }

  //----------------------------------------------------------------------------------
  oncableIdFormSubmit() {
    this.dataSource = this.dataSource.map((obj: any) => ({ ...obj, Location: obj.NewLocation }));
    const toSaveData = this.dataSource.map((obj: any) => ({resultId: obj.id, Location: obj.NewLocation })); 
    this.ProjectsService.updateCableId(toSaveData)
    this.SharedService.setUpdatedSelectRow(this.dataSource);
  }

  showNextExampleClick() {
    // let incrementedValue = this.num + 1;
    // TODO: Implement replace logic
    // this.findText = "ID",
    //   this.replacementText = "NO."
    // this.showExample1 = 'Use "Find" to replace the firct match of text "ID" with the text "No."'

    // this.showExamplesSection = true
    // // incrementedValue = incrementedValue + 1

    // this.showDescriptionOfExm = 'Description of example ' + this.num;
    // this.num = this.num + 1;
    // // let buttonNum = this.num +1;
    // this.showButtonText = 'Show next example(' + this.num + '/8)'
    // switch (this.num) {
    //   case 2:
    //     this.findText = "ID",
    //       this.replacementText = "NO."
    //     this.showExample1 = 'Use "Find" to replace the firct match of text "ID" with the text "No."'
    //     break;
    //   case 3:
    //     this.findText = "***",
    //       this.replacementText = "Result"
    //     this.showExample1 = 'Use "***" to replace with the text "Result"'
    //     break;
    //   case 4:
    //     this.findText = "***",
    //       this.replacementText = "Result***6"
    //     this.showExample1 = 'Use "***" and "###n" to replace with the text "Result 000001" etc'
    //     break;
    //   case 5:
    //     this.findText = "<<<",
    //       this.replacementText = "XT=YZ Ltd.:"
    //     this.showExample1 = 'Use "<<<" to prepend text "XYZ Ltd.:"'
    //     break;
    //   case 6:
    //     this.findText = ">>>",
    //       this.replacementText = "(of Room 102)"
    //     this.showExample1 = 'Use ">>>" to append the text "(of Room 102)"'
    //     break;
    //   case 7:
    //     this.findText = "<<<",
    //       this.replacementText = "Task #7###2:"
    //     this.showExample1 = 'Use "<<<" and "###n" to prepend the text "Task #701:" etc.'
    //     break;
    //   case 8:
    //     this.findText = "***",
    //       this.replacementText = ": FiberID #7###2"
    //     this.showExample1 = 'Use "***" and "###n" to replace with the text "Meas 1001: FiberID #701" etc.'
    //     break;
    //   case 9:
    //     this.findText = "ID",
    //       this.replacementText = "[###6], Meas. #"
    //     this.showExample1 = 'Use "Find:" and "###n" to replace with the text "Number [000001], Meas. #" etc.'
    //     this.showButtonText = 'Restore entries';
    //     this.num = 1;
    //     break;
    //   default:
    //     this.findText = "",
    //       this.replacementText = ""
    //     this.showExample1 = ''
    //     break;
    // }

  }
}
