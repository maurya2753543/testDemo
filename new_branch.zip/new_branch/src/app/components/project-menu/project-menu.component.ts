import { Component } from '@angular/core';
import {
  faPlus,
  faFileImport,
  faEllipsis,
  faFloppyDisk,
  faFloppyDiskPen,
  faEdit,
  faFileExport,
  faClose
} from '@fortawesome/pro-solid-svg-icons'
import { ProjectsService } from 'src/app/services/projects.service';
import "../../window-extensions"
@Component({
  selector: 'app-project-menu',
  templateUrl: './project-menu.component.html',
  styleUrls: ['./project-menu.component.scss']
})
export class ProjectMenuComponent {
  faPlus = faPlus
  faFileImport = faFileImport
  faEllipsis = faEllipsis
  faFloppyDisk = faFloppyDisk
  faFloppyDiskPen = faFloppyDiskPen
  faEdit = faEdit;
  faFileExport = faFileExport
  faClose = faClose;

  constructor( private projectsService: ProjectsService){

  }
 //------------------------------------------------------------------


newProject() {
  this.projectsService.newProject("rename me");
}
//--------------------------------------------------------------------------
importProject() {
    
    this.projectsService.importProject("");
}

//-----------------------------------------------------------------------
async exportProject() {

        this.projectsService.exportProject(false);

}


//-----------------------------------------------------------------------

archiveProject() {
  
    this.projectsService.exportProject(true);

}
//-----------------------------------------------------------------------


renameProject() {
  // this.projectsService.renameTreeNode();
}
//-----------------------------------------------------------------------

}
