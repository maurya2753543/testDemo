import { Component, Output, EventEmitter, OnInit, ViewChild, Input } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import { MatTreeNestedDataSource, MatTreeModule } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { SelectionModel } from '@angular/cdk/collections';

interface ColumnNode {
  name: string;
  enabled: boolean;
  children?: ColumnNode[];
}
@Component({
  selector: 'app-custom-side-bar',
  templateUrl: './custom-side-bar.component.html',
  styleUrls: ['./custom-side-bar.component.scss']
})
export class CustomSideBarComponent implements OnInit {
  @ViewChild('TestGridPanelComponent')
  filterGrid!: TestGridPanelComponent;
  treeControl = new NestedTreeControl<ColumnNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<ColumnNode>();
  checklistSelection = new SelectionModel<ColumnNode>(true);

  //----------------------------------------------------------------------------------
  todoItemSelectionToggle(node: any): void {
    console.log("todoItemSelectionToggle", node);
  }

  //----------------------------------------------------------------------------------
  constructor(private SharedService: SharedService, private ProjectsService: ProjectsService, private TestGridPanelComponent: TestGridPanelComponent) {
  }

  //----------------------------------------------------------------------------------
  hasChild = (_: number, node: ColumnNode) => !!node.children && node.children.length > 0;

  //----------------------------------------------------------------------------------
  ngOnInit() {
    this.fetchData()
    this.SharedService.isVisibleSource.subscribe((isVisible) => {
      console.log('isVisible: ', isVisible); // => true/false
    });
  }

  //----------------------------------------------------------------------------------
  private async fetchData() {
    //console.log("fetch Columns Tree");
    this.dataSource.data = this.ProjectsService.getColumnsTable();
    console.log("FETCH:", this.dataSource)
  }

  //----------------------------------------------------------------------------------
  @Output() toggleColumnVisibility = new EventEmitter<string>();
  mainGridColumnDefs: any

  //----------------------------------------------------------------------------------
  /////////////////////Custom Hide and Show Coulumns in ag-grid///////////////////////
  onToggleColumnVisibility(columnsFiled: string) {
    // Find the column definition object with the matching field property
    let matchingObj;
    this.mainGridColumnDefs = this.SharedService.getColumnDefinations();
    for (const group of this.mainGridColumnDefs) {
      for (const column of group.children) {
        if (column.field === columnsFiled) {
          matchingObj = column;
          break; // If you only want the first match, you can break out of the loop.
        }
      }
      if (matchingObj) {
        matchingObj.hide = !matchingObj.hide; // Or false to show the column
        const gridApi = this.SharedService.getGridApi();
        gridApi.setColumnDefs(this.mainGridColumnDefs);
        break; // If you found a match, break out of the outer loop as well.
      }
    }
    console.log(matchingObj);
  }

  //----------------------------------------------------------------------------------
  onCheckBoxClicked(columnsFiled: any) {
    this.ProjectsService.setColumnHideState(columnsFiled.category, columnsFiled.name, !columnsFiled.enabled);
    this.onToggleColumnVisibility(columnsFiled.name);
  }

}
