import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { environment } from '../../../environments/environment'

@Component({
  selector: 'app-markdown',
  templateUrl: './markdown.component.html',
  styleUrls: ['./markdown.component.scss']
})
export class MarkdownComponent implements OnInit {
  docUrl: string | undefined
  appVersion = environment.version
  errorMessage: string | undefined

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    const { doc, section = '' } = this.route.snapshot.queryParams
    this.docUrl = `/assets/docs/${doc}.md`
  }

  onError(event: any) {
    console.warn('Failed to open document:', event)
    this.errorMessage = 'Failed to load requested document.'
  }
}
