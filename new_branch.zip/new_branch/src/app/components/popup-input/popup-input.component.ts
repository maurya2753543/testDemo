import { Component, EventEmitter, Output, Input, Inject, OnInit } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { ProjectsService } from 'src/app/services/projects.service';
import {
  faPlus,
  faFileImport,
  faEllipsis,
  faFloppyDisk,
  faFloppyDiskPen,
  faEdit,
  faFileExport,
  faClose,

} from '@fortawesome/pro-solid-svg-icons';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { GlobalSettingsService } from 'src/app/services/global-settings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
interface UserData {
  Original: string;
  Currently: string;
  NewFiber: string;
  Location: string;
}

@Component({
  selector: 'app-popup-input',
  templateUrl: './popup-input.component.html',
  styleUrls: ['./popup-input.component.scss']
})
export class PopupInputComponent implements OnInit {
  faPlus = faPlus
  faFileImport = faFileImport
  faEllipsis = faEllipsis
  faFloppyDisk = faFloppyDisk
  faFloppyDiskPen = faFloppyDiskPen
  faEdit = faEdit;
  faFileExport = faFileExport
  faClose = faClose;
  // Dark themes
  // Dark themes
  @Input() DarkThemesApply: any;
  rowData: any;
  // set csv data
  rowDataTable: any

  inputValue: any;
  projectName: any; // for  anme selection
  selectedId: string | null = null;
  selectedName: any;
  dataPdfSource: MatTableDataSource<UserData> = new MatTableDataSource<UserData>([]);
  noRowselected: any;
  rowPdfData: any;
  showPopup = false;

  //----------------------

  constructor(
    public dialogRef: MatDialogRef<PopupInputComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public darkModeService: DarkModeService,
    private GlobalServicesetting: GlobalSettingsService,
    public ProjectsService: ProjectsService, private http: HttpClient

  ) {
  }

  //---------------------------------------------------------------------
  /**
   *
   */
  ngOnInit(): void {
    this.ProjectsService.getPdfData().subscribe((data) => {
      this.dataPdfSource = data;
      this.rowPdfData = this.dataPdfSource;
    });
    this.ProjectsService.getNoRowPdfData().subscribe((e) => {
      this.noRowselected = e;
    });


    this.updateInputValueWithDateTime();
    this.projectName = this.ProjectsService.getActiveNode();



  }
  //----------------------------------------------------------------------

  updateInputValueWithDateTime(): void {
    // Get the current date and time
    const currentDateTime = new Date();

    // Format the date and time as desired (e.g., YYYY-MM-DD HH:mm:ss)
    const formattedDateTime = this.formatDateTime(currentDateTime);
    this.projectName = this.ProjectsService.getActiveNode();
    this.inputValue = this.projectName.name + "  " + formattedDateTime;

    // Set inputValue to the formatted date and time

  }

  formatDateTime(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Add 1 because months are zero-based
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }


  //---------------------------------------------------------------------

  // CONVER ARRAY TO CSV
  convertArrayToCSV(data: any[]): string {
    if (data && data.length > 0) {
      const header = Object.keys(data[0]).join(',');
      const rows = data.map(item => Object.values(item).join(','));
      return `${header}\n${rows.join('\n')}`;
    } else {
      // Handle the case where 'data' is empty or undefined
      return ''; // or throw an error, return a default CSV, etc.
    }
  }

  /**@default
   *
   */
  saveInput() {
    // Convert data to CSV format
    const csvContent = this.convertArrayToCSV(this.rowPdfData);
    // Create a download link and trigger the download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const downloadLink = document.createElement('a');
    const url = URL.createObjectURL(blob);
    downloadLink.setAttribute('href', url);
    downloadLink.setAttribute('download', this.inputValue);
    // Trigger the download
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    this.showPopup = false; // Close the pop-up
  }
}
