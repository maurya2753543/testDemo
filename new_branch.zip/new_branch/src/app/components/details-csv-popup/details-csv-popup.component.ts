import { Component } from '@angular/core';

@Component({
  selector: 'app-details-csv-popup',
  templateUrl: './details-csv-popup.component.html',
  styleUrls: ['./details-csv-popup.component.scss']
})
export class DetailsCsvPopupComponent {

}
