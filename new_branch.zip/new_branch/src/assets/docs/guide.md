# ReportPRO release notes
Hello, welcome to ReportPRO release notes


## New Measurements
    - Fiber Inspection MPO
    - Tier 1
    - Tier 1 MPO
    - ONT Detection

## New Features

- Bulk  Change Tech/Operator name
- Bulk change the Cable Id
- Menu cleanup and reorganization
- Configuration items can now be enabled as grid columns
- OTDR Trace
  - Zoom region sow on thumbnail
  - Enable/Disable event text
- Smart Pocket File import via USB
- Import Export Projects
  - exports are compressed by zip and encrypted
- Drag and Drop a project to import works
- Archive a Project ( same as export but the project is removed from the project tree)
- Duplicate result detection is enabled,  Still need to connect up the error message
- Files are validated for proper CDM syntax before import,   Still need to connect up the error message
- User can click on bread crumb and navigate to the next level down 

## Misc updates
- Window Splitter handles are styled in dark mode
- Row content is properly aligned in dark mode
  


