import React from 'react';
import './Footer.css'; // Ensure the styles are placed here
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import logo from '../images/maurya_logo.png';
import EnquiryForm from './EnquiryForm';

const Footer = () => {
    return (
        <>
                        <EnquiryForm />
                        <div id="bottom-wrap" className="footer">
            {/* Footer Top Section with Client Logos */}
            <div className="footer-top-section">
                <div className="container">
                    <div className="row-feedback justify-content-center">
                        <div className="col-md-12 text-center">
                            <div className="client-logo-carousel">
                                <div className="client-logo-single-widget">
                                    <img
                                        src={logo}
                                        alt="Client Logo"
                                        className="client-logo"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Social Media Icons */}        


            {/* Footer Copyright Section */}
            <div className="footer-copyright">
                <p>2025 Chanakya Edu All Rights Reserved.</p> <br />
            </div>
            <div className="footer-copyright">
            <p>Support E-mail : - neeraj03121996@gmail.com</p>
            </div>
            <div>
            </div>

        </div>

        </>
        
    );
};

export default Footer;
