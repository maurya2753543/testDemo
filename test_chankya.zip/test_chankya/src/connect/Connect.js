import React, { useEffect, useState } from 'react';
import './Connect.css'; // Import the CSS file for styling
import Header from '../comman-header/Header';
import Dashboard_Header from '../comman-header/Dashbord-header';
import AppwriteService from '../appwrite/AppwriteService'; // Assuming you are using Appwrite for session handling

const Connect = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const appwriteService = new AppwriteService(); // Create an instance of AppwriteService

  // Check for session when component loads
  useEffect(() => {
    const checkSession = async () => {
      try {
        const currentUser = await appwriteService.account.get();
        if (currentUser) {
          setIsLoggedIn(true); // If session exists, set isLoggedIn to true
        }
      } catch (error) {
        console.log("No active session found, showing login page");
        setIsLoggedIn(false); // No session, show login
      }
    };
    checkSession();
  }, []);

  return (
    <>
      {/* Conditionally render headers based on login status */}
      {isLoggedIn ? <Dashboard_Header /> : <Header />}

     <div>
      
     </div>
    </>
  );
};

export default Connect;
