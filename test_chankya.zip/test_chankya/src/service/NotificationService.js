// NotificationService.js
class NotificationService {
    constructor() {
      this.notifications = [];
    }
  
    addNotification(notification) {
      this.notifications.push(notification);
    }
  
    getNotifications() {
      return this.notifications;
    }
  
    clearNotifications() {
      this.notifications = [];
    }
  }
  
  const notificationService = new NotificationService();
  export default notificationService;
  