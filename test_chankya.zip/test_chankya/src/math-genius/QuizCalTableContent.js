import React, { useState, useEffect } from 'react';
import './QuizCalTableContent.css'; // Import your CSS for dark and light mode styles
import { faSun, faMoon } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const TableContentMath = () => {
  const [data, setData] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  useEffect(() => {
    // Full data for the table
    const tableData = [
      { sn: 1, activity: "Multiply by 11", highestScore: 36, geniusScore: 40, currentLevel: "Master" },
      { sn: 2, activity: "Fast addition of 2 digits - practice", highestScore: 39, geniusScore: 40, currentLevel: "Master" },
      { sn: 3, activity: "2 digit addition", highestScore: 34, geniusScore: 35, currentLevel: "Master" },
      { sn: 4, activity: "2 Digit Subtraction", highestScore: 22, geniusScore: 35, currentLevel: "Challenger" },
      { sn: 5, activity: "Add fast using give and take", highestScore: 25, geniusScore: 40, currentLevel: "Challenger" },
      { sn: 6, activity: "Add 3 digit numbers in head", highestScore: 15, geniusScore: 20, currentLevel: "Master" },
      { sn: 7, activity: "subtract 3 digit numbers", highestScore: 17, geniusScore: 20, currentLevel: "Master" },
      { sn: 8, activity: "Find complements", highestScore: 36, geniusScore: 50, currentLevel: "Challenger" },
      { sn: 9, activity: "Practice tables up to 10", highestScore: 74, geniusScore: 80, currentLevel: "Master" },
      { sn: 10, activity: "Fast subtraction", highestScore: 24, geniusScore: 30, currentLevel: "Challenger" },
      { sn: 11, activity: "Use Subtraction Method to multiply these two digit numbers", highestScore: 11, geniusScore: 25, currentLevel: "Starter" },
      { sn: 12, activity: "Multiple any 2 digit number by a 1 digit number in head", highestScore: 8, geniusScore: 25, currentLevel: "Starter" },
      { sn: 13, activity: "Use 3 by 1 Multiplication addition method", highestScore: 7, geniusScore: 16, currentLevel: "Starter" },
      { sn: 14, activity: "Use Group Together base 10", highestScore: 53, geniusScore: 40, currentLevel: "Genius" },
      { sn: 15, activity: "Use Group Together base 100", highestScore: 21, geniusScore: 40, currentLevel: "Challenger" },
      { sn: 16, activity: "Use Group Together base 20", highestScore: 8, geniusScore: 40, currentLevel: "Starter" },
      { sn: 17, activity: "Multiply 2 digit numbers around 50", highestScore: 5, geniusScore: 40, currentLevel: "Starter" },
      { sn: 18, activity: "Fast multiplication with 9", highestScore: 28, geniusScore: 50, currentLevel: "Starter" },
      { sn: 19, activity: "Special 2x2 multiplication", highestScore: 31, geniusScore: 50, currentLevel: "Challenger" },
      { sn: 20, activity: "Fast multiplication with 99", highestScore: 48, geniusScore: 50, currentLevel: "Master" },
      { sn: 21, activity: "Fast multiplication - tens are complements, units are same", highestScore: 14, geniusScore: 50, currentLevel: "Starter" },
      { sn: 22, activity: "Multiply using factor method", highestScore: 24, geniusScore: 20, currentLevel: "Genius" },
      { sn: 23, activity: "Multiply two 2 digit numbers", highestScore: 15, geniusScore: 16, currentLevel: "Master" },
      { sn: 24, activity: "Calculate perfect squares 1-25", highestScore: 94, geniusScore: 80, currentLevel: "Genius" },
      { sn: 25, activity: "Calculate the Root", highestScore: 116, geniusScore: 80, currentLevel: "Genius" },
      { sn: 26, activity: "Fast perfect squares up to 110", highestScore: 34, geniusScore: 25, currentLevel: "Genius" },
      { sn: 27, activity: "Guess the last digit of the number given the perfect square's last digit", highestScore: 82, geniusScore: 75, currentLevel: "Genius" },
      { sn: 28, activity: "Guess if a number could be a perfect square by just looking at the last digit", highestScore: 110, geniusScore: 80, currentLevel: "Genius" },
      { sn: 29, activity: "Guess the square root of a perfect square", highestScore: 11, geniusScore: 40, currentLevel: "Starter" },
      { sn: 30, activity: "Tell Cubes lightning fast up to 16", highestScore: 31, geniusScore: 80, currentLevel: "Starter" },
      { sn: 31, activity: "Tell cube roots of cubes up to 16", highestScore: 51, geniusScore: 80, currentLevel: "Challenger" },
      { sn: 32, activity: "Guess the cube just below a given number", highestScore: 31, geniusScore: 60, currentLevel: "Challenger" },
      { sn: 33, activity: "Diagonal intersection angles of a quad", highestScore: 0, geniusScore: 40, currentLevel: "Starter" },
      { sn: 34, activity: "Tell cubes of large numbers, it is so easy", highestScore: 3, geniusScore: 30, currentLevel: "Starter" },
      { sn: 35, activity: "Fast basic division", highestScore: 50, geniusScore: 80, currentLevel: "Challenger" },
      { sn: 36, activity: "Fast division from numbers greater than 10x", highestScore: 30, geniusScore: 80, currentLevel: "Starter" },
      { sn: 37, activity: "3 digit Fast Quotient and fast remainder", highestScore: 23, geniusScore: 60, currentLevel: "Starter" },
      { sn: 38, activity: "2 digit Fast quotient and fast remainder", highestScore: 14, geniusScore: 60, currentLevel: "Starter" },
      { sn: 39, activity: "Decimal Division by 2", highestScore: 30, geniusScore: 40, currentLevel: "Master" },
      { sn: 40, activity: "Decimal Division by 3", highestScore: 5, geniusScore: 40, currentLevel: "Starter" },
      { sn: 41, activity: "Decimal Division by 4", highestScore: 0, geniusScore: 40, currentLevel: "Starter" },
      { sn: 42, activity: "Decimal Division by 10", highestScore: 101, geniusScore: 40, currentLevel: "Genius" },
      { sn: 43, activity: "Decimal Division by 5", highestScore: 9, geniusScore: 40, currentLevel: "Starter" },
      { sn: 44, activity: "Fast aliquot practice - 2, 5 and 10", highestScore: 29, geniusScore: 80, currentLevel: "Starter" },
      { sn: 45, activity: "Superfast PEMDAS", highestScore: 0, geniusScore: 40, currentLevel: "Starter" },
      { sn: 46, activity: "Fast aliquot practice - 2, 4, 5, 8 & 10", highestScore: 12, geniusScore: 80, currentLevel: "Starter" },
      { sn: 47, activity: "Fast division using aliquots", highestScore: 5, geniusScore: 60, currentLevel: "Starter" }
    ];
  
    setData(tableData);
  }, []);
  

  // Handle dark mode toggle
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = data.slice(indexOfFirstItem, indexOfLastItem);

  const nextPage = () => {
    if (currentPage < Math.ceil(data.length / itemsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  return (
    <>
    <div>
        <div>
        <div className="performance-container">
  <h4 style={{marginLeft: '60px'}}>Your Overall Performance across Math Genius Activities</h4>
  <div  style={{marginRight : '130px'}}>
    <div className="theme-toggle">
      <p>Light</p>
      <label className="switch">
        <input type="checkbox" onChange={toggleDarkMode} checked={darkMode} />
        <span className="slider">
          <FontAwesomeIcon icon={faMoon} className="icon-moon" />
          <FontAwesomeIcon icon={faSun} className="icon-sun" />
        </span>
      </label>
      <p>Dark</p>
    </div>
  </div>
</div>

    
   
      <table className={darkMode ? 'app dark-mode data-table' : 'app data-table'} >
        <thead>
          <tr>
            <th>S.N.</th>
            <th>Activity Name</th>
            <th>Your Highest Score</th>
            <th>Genius Score</th>
            <th>Your Current Level</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((item, index) => (
            <tr key={index}>
              <td>{item.sn}</td>
              <td>{item.activity}</td>
              <td>{item.highestScore}</td>
              <td>{item.geniusScore}</td>
              <td>{item.currentLevel}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
  <button onClick={prevPage} disabled={currentPage === 1} className="prev-button">
    ← Previous
  </button>
  <button onClick={nextPage} disabled={currentPage === Math.ceil(data.length / itemsPerPage)} className="next-button">
    Next →
  </button>
</div>

    </div>
    </div>
    </>
  
  );
};

export default TableContentMath;
