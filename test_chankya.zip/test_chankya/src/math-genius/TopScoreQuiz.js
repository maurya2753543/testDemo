import React, { useState, useEffect } from 'react';
import './QuizCalTableContent.css'; // Import your CSS for dark and light mode styles
import { faSun, faMoon } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const TopScoresTable = () => {
  const [data, setData] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    // Full data for the top scores table
    const tableData = [
      { position: 1, name: "Aadhya Maurya", score: 390 },
      { position: 2, name: "Neeraj Verma", score: 320 },
      { position: 3, name: "Ishaan Pal", score: 310 },
      { position: 4, name: "Neha Srinivas Nand", score: 290 },
      { position: 5, name: "Advay Bansal", score: 280 },
      { position: 6, name: "Manav Pagadala", score: 267 },
      { position: 7, name: "Siddharth Chandra", score: 250 },
      { position: 8, name: "Kavya Nisad", score: 240 },
      { position: 9, name: "Raj Mistra", score: 233 },
      { position: 10, name: "Rahul Kumar", score: 210 },
    ];
  
    setData(tableData);
  }, []);

  // Handle dark mode toggle
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = data.slice(indexOfFirstItem, indexOfLastItem);

  const nextPage = () => {
    if (currentPage < Math.ceil(data.length / itemsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <>
      <div className="performance-container">
        <h4 style={{ marginLeft: '60px' }}>Top Scores</h4>
        <div style={{ marginRight: '130px' }}>
          <div className="theme-toggle">
            <p>Light</p>
            <label className="switch">
              <input type="checkbox" onChange={toggleDarkMode} checked={darkMode} />
              <span className="slider">
                <FontAwesomeIcon icon={faMoon} className="icon-moon" />
                <FontAwesomeIcon icon={faSun} className="icon-sun" />
              </span>
            </label>
            <p>Dark</p>
          </div>
        </div>
      </div>

      <table className={darkMode ? 'app dark-mode data-table' : 'app data-table'}>
        <thead>
          <tr>
            <th>Position</th>
            <th>Name</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((item, index) => (
            <tr key={index}>
              <td>{item.position}</td>
              <td>{item.name}</td>
              <td>{item.score}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* <div className="pagination">
        <button onClick={prevPage} disabled={currentPage === 1} className="prev-button">
          ← Previous
        </button>
        <button onClick={nextPage} disabled={currentPage === Math.ceil(data.length / itemsPerPage)} className="next-button">
          Next →
        </button>
      </div> */}
    </>
  );
};

export default TopScoresTable;
