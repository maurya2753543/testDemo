import React, { useState, useEffect } from 'react';
import './QuizCalTableContent.css'; // Import your CSS for dark and light mode styles
import { faSun, faMoon } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const TableContentMath = () => {
  const [data, setData] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  useEffect(() => {
    // Full data for the table
    const tableData = [
        { sn: 1, activity: "Ancient Indian History - Harappan Civilization (KBC 2000)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 2, activity: "Mughal Emperors and their Contributions (KBC 2001)", highestScore: 300, geniusScore: 25, currentLevel: "Starter" },
        { sn: 3, activity: "Modern History - Indian Independence Movement (KBC 2002)", highestScore: 300, geniusScore: 50, currentLevel: "Challenger" },
        { sn: 4, activity: "Famous Scientists and their Inventions (KBC 2003)", highestScore: 300, geniusScore: 60, currentLevel: "Challenger" },
        { sn: 5, activity: "Geography: Indian States and their Capitals (KBC 2004)", highestScore: 300, geniusScore: 15, currentLevel: "Starter" },
        { sn: 6, activity: "World Geography: Rivers, Mountains, and Deserts (KBC 2005)", highestScore: 300, geniusScore: 80, currentLevel: "Master" },
        { sn: 7, activity: "Constitution of India: Important Articles (KBC 2006)", highestScore: 300, geniusScore: 70, currentLevel: "Challenger" },
        { sn: 8, activity: "Science: Basic Physics Laws - Newton's Laws (KBC 2007)", highestScore: 300, geniusScore: 25, currentLevel: "Starter" },
        { sn: 9, activity: "Biology: Human Anatomy - Digestive System (KBC 2008)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 10, activity: "Mathematics: Pythagorean Theorem and Applications (KBC 2009)", highestScore: 300, geniusScore: 25, currentLevel: "Starter" },
        { sn: 11, activity: "Chemistry: Periodic Table Elements and their Properties (KBC 2010)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 12, activity: "Current Affairs: Recent Nobel Prize Winners (KBC 2011)", highestScore: 300, geniusScore: 15, currentLevel: "Starter" },
        { sn: 13, activity: "Famous Indian Authors and their Works (KBC 2012)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 14, activity: "Sports: Cricket World Cup Winners by Year (KBC 2013)", highestScore: 300, geniusScore: 75, currentLevel: "Challenger" },
        { sn: 15, activity: "Indian Classical Dances and Their Origins (KBC 2014)", highestScore: 300, geniusScore: 15, currentLevel: "Starter" },
        { sn: 16, activity: "Current Affairs: Major Global Events - Olympics (KBC 2015)", highestScore: 300, geniusScore: 18, currentLevel: "Starter" },
        { sn: 17, activity: "Famous Battles in Indian History - Panipat, Plassey (KBC 2016)", highestScore: 300, geniusScore: 77, currentLevel: "Challenger" },
        { sn: 18, activity: "Political Science: Indian Parliament Structure (KBC 2017)", highestScore: 300, geniusScore: 96, currentLevel: "Master" },
        { sn: 19, activity: "Space Science: Solar System and Planets (KBC 2018)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 20, activity: "Technology: Computer Fundamentals and Internet (KBC 2019)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 21, activity: "Environment: Famous Environmentalists (KBC 2020)", highestScore: 300, geniusScore: 18, currentLevel: "Starter" },
        { sn: 22, activity: "Economics: Basic Concepts of GDP, Inflation (KBC 2021)", highestScore: 300, geniusScore: 88, currentLevel: "Challenger" },
        { sn: 23, activity: "Indian Rivers and their Tributaries (KBC 2022)", highestScore: 300, geniusScore: 22, currentLevel: "Master" },
        { sn: 24, activity: "Mythology: Indian Gods and Goddesses (KBC 2023)", highestScore: 300, geniusScore: 25, currentLevel: "Master" },
        { sn: 25, activity: "World War History - Key Events and Figures (KBC 2001)", highestScore: 300, geniusScore: 98, currentLevel: "Master" },
        { sn: 26, activity: "Important Freedom Fighters of India (KBC 2002)", highestScore: 300, geniusScore: 87, currentLevel: "Challenger" },
        { sn: 27, activity: "Space Explorations and Missions (KBC 2005)", highestScore: 300, geniusScore: 76, currentLevel: "Challenger" },
        { sn: 28, activity: "Global Famous Landmarks and Monuments (KBC 2003)", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 29, activity: "Folk Dances from Different States of India (KBC 2007)", highestScore: 300, geniusScore: 17, currentLevel: "Starter" },
        { sn: 30, activity: "Indian Constitution Amendments and Articles (KBC 2008)", highestScore: 300, geniusScore: 75, currentLevel: "Challenger" },
        { sn: 31, activity: "Environmental Science: Global Warming (KBC 2010)", highestScore: 300, geniusScore: 28, currentLevel: "Starter" },
        { sn: 32, activity: "Famous Mathematicians and their Theorems (KBC 2006)", highestScore: 300, geniusScore: 23, currentLevel: "Starter" },
        { sn: 33, activity: "Renaissance Period and Key Figures (KBC 2011)", highestScore: 300, geniusScore: 99, currentLevel: "Master" },
        { sn: 34, activity: "Literature: Nobel Prize Winners in Literature (KBC 2014)", highestScore: 300, geniusScore: 91, currentLevel: "Master" },
        { sn: 35, activity: "Great Emperors and Conquerors of the World (KBC 2015)", highestScore: 300, geniusScore: 84, currentLevel: "Challenger" },
        { sn: 36, activity: "Art and Architecture of India (KBC 2016)", highestScore: 300, geniusScore: 16, currentLevel: "Starter" },
        { sn: 37, activity: "Major Indian Festivals and Their Significance (KBC 2018)", highestScore: 300, geniusScore:145, currentLevel: "Starter" },
        { sn: 38, activity: "Physics: Theory of Relativity (KBC 2019)", highestScore: 300, geniusScore: 93, currentLevel: "Master" },
        { sn: 39, activity: "Economic Planning in India (KBC 2021)", highestScore: 300, geniusScore: 27, currentLevel: "Challenger" },
        { sn: 40, activity: "Science and Technology - ISRO Missions (KBC 2017)", highestScore: 300, geniusScore: 79, currentLevel: "Master" },
        { sn: 41, activity: "Significant Global Movements - Civil Rights (KBC 2020)", highestScore: 300, geniusScore: 88, currentLevel: "Master" },
        { sn: 42, activity: "Indian Space Research Achievements (KBC 2022)", highestScore: 300, geniusScore: 94, currentLevel: "Master" },
        { sn: 43, activity: "Cultural Heritage Sites in India (KBC 2013)", highestScore: 300, geniusScore: 69, currentLevel: "Challenger" },
        { sn: 44, activity: "Famous Global Leaders in History (KBC 2004)", highestScore: 300, geniusScore: 27, currentLevel: "Starter" },
        { sn: 45, activity: "Endangered Species and Conservation (KBC 2012)", highestScore: 300, geniusScore: 18, currentLevel: "Starter" },
        { sn: 46, activity: "Indian Economy: Basic Economic Terms (KBC 2009)", highestScore: 300, geniusScore: 20, currentLevel: "Starter" },
        { sn: 47, activity: "Ancient Greek and Roman Mythology (KBC 2000)", highestScore: 300, geniusScore: 19, currentLevel: "Starter" },
        { sn: 48, activity: "Recent Scientific Breakthroughs (KBC 2008)", highestScore: 300, geniusScore: 98, currentLevel: "Master" },
        { sn: 49, activity: "Indian Armed Forces: Major Operations (KBC 2014)", highestScore: 300, geniusScore: 70, currentLevel: "Challenger" },
        { sn: 50, activity: "Space Science: Black Holes and Stars (KBC 2016)", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 51, activity: "India-government-politics-current-affairs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 52, activity: "Summits and Conferences in Current Affairs MCQs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 53, activity: "Government Schemes [India & States] ", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 54, activity: "Indian Culture MCQs", highestScore: 300, geniusScore: 70, currentLevel: "Challenger" },
        { sn: 55, activity: "Science & Technology Current Affairs MCQs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 56, activity: "India-government-politics-current-affairs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 57, activity: "World History MCQs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 58, activity: "Environment & Biodiversity MCQs ", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 59, activity: "Modern Indian History MCQs", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        { sn: 60, activity: "Fastest Finger First KBC", highestScore: 300, geniusScore: 22, currentLevel: "Starter" },
        // Continue up to 300 as per required
    ];
  
    setData(tableData);
  }, []);
  

  // Handle dark mode toggle
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = data.slice(indexOfFirstItem, indexOfLastItem);

  const nextPage = () => {
    if (currentPage < Math.ceil(data.length / itemsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  return (
    <>
    <div>
        <div>
        <div className="performance-container">
  <h4 style={{marginLeft: '60px'}}>Your Overall Performance across KBC Genius Activities</h4>
  <div  style={{marginRight : '130px'}}>
    <div className="theme-toggle">
      <p>Light</p>
      <label className="switch">
        <input type="checkbox" onChange={toggleDarkMode} checked={darkMode} />
        <span className="slider">
          <FontAwesomeIcon icon={faMoon} className="icon-moon" />
          <FontAwesomeIcon icon={faSun} className="icon-sun" />
        </span>
      </label>
      <p>Dark</p>
    </div>
  </div>
</div>

    
   
      <table className={darkMode ? 'app dark-mode data-table' : 'app data-table'} >
        <thead>
          <tr>
            <th>S.N.</th>
            <th>Activity Name</th>
            <th>Total Score</th>
            <th>Genius Score</th>
            <th>Your Current Level</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((item, index) => (
            <tr key={index}>
              <td>{item.sn}</td>
              <td>{item.activity}</td>
              <td>{item.highestScore}</td>
              <td>{item.geniusScore}</td>
              <td>{item.currentLevel}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
  <button onClick={prevPage} disabled={currentPage === 1} className="prev-button">
    ← Previous
  </button>
  <button onClick={nextPage} disabled={currentPage === Math.ceil(data.length / itemsPerPage)} className="next-button">
    Next →
  </button>
</div>

    </div>
    </div>
    </>
  
  );
};

export default TableContentMath;
