import React, { useRef, useState } from 'react';
import './WhiteBordCal.css'; // Assuming you have a CSS file for styles

const WhiteboardCalculator = () => {
    const canvasRef = useRef(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [expression, setExpression] = useState(""); // For calculator logic
    const [showCalculator, setShowCalculator] = useState(false); // Show or hide calculator

    // Drawing logic
    const startDrawing = (e) => {
        const ctx = canvasRef.current.getContext("2d");
        ctx.beginPath();
        ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        setIsDrawing(true);
    };

    const draw = (e) => {
        if (!isDrawing) return;
        const ctx = canvasRef.current.getContext("2d");
        ctx.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        ctx.strokeStyle = "black";
        ctx.lineWidth = 2;
        ctx.stroke();
    };

    const stopDrawing = () => {
        setIsDrawing(false);
    };

    // Function to clear the whiteboard
    const clearWhiteboard = () => {
        const ctx = canvasRef.current.getContext("2d");
        ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height); // Clear the entire canvas
    };

    // Calculator logic
    const handleButtonClick = (value) => {
        if (value === "C") {
            setExpression("");
        } else if (value === "=") {
            try {
                setExpression(eval(expression).toString()); // Avoid eval for better security in real-world apps
            } catch {
                setExpression("Error");
            }
        } else {
            setExpression((prev) => prev + value);
        }
    };

    return (
        <div className="whiteboard-calculator">
            {/* Clear Whiteboard Button */}
            <div className="clear-whiteboard">
                <button onClick={clearWhiteboard} className="clear-btn">
                    Clear Whiteboard
                </button>
            </div>

            {/* Whiteboard Section */}
            <canvas
                ref={canvasRef}
                width={750}
                height={450}
                className="whiteboard"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
            ></canvas>

            {/* Show calculator message button */}
            <div className="calculator-message">
                <button className="message-btn" onClick={() => setShowCalculator(!showCalculator)}>
                    {showCalculator ? "Great job! Hide Calculator" : "Try solving it on your own first! Need help? Open Calculator"}
                </button>
            </div>

            {/* Conditionally show Calculator Section */}
            {showCalculator && (
                <div className="calculator">
                    <input type="text" value={expression} readOnly className="calculator-display" />
                    <div className="calculator-buttons">
                        {["1", "2", "3", "+", "4", "5", "6", "-", "7", "8", "9", "*", "C", "0", "=", "/"].map((button) => (
                            <button key={button} onClick={() => handleButtonClick(button)}>
                                {button}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default WhiteboardCalculator;
