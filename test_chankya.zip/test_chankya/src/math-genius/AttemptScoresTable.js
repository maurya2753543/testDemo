import React, { useState, useEffect } from 'react';
import './QuizCalTableContent.css'; // Import your CSS for dark and light mode styles
import { faSun, faMoon } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const AttemptScoresTable = () => {
  const [data, setData] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    // Full data for the table
    const tableData = [
      { attempt: 2, score: 12 },
      { attempt: 1, score: 0 }
    ];

    setData(tableData);
  }, []);

  // Handle dark mode toggle
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = data.slice(indexOfFirstItem, indexOfLastItem);

  const nextPage = () => {
    if (currentPage < Math.ceil(data.length / itemsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div>
      <div className="performance-container">
        <h4 style={{ marginLeft: '60px' }}>Your Attempt & Scores</h4>
        <div style={{ marginRight: '130px' }}>
          <div className="theme-toggle">
            <p>Light</p>
            <label className="switch">
              <input type="checkbox" onChange={toggleDarkMode} checked={darkMode} />
              <span className="slider">
                <FontAwesomeIcon icon={faMoon} className="icon-moon" />
                <FontAwesomeIcon icon={faSun} className="icon-sun" />
              </span>
            </label>
            <p>Dark</p>
          </div>
        </div>
      </div>

      <table className={darkMode ? 'app dark-mode data-table' : 'app data-table'}>
        <thead>
          <tr>
            <th>Attempt</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((item, index) => (
            <tr key={index}>
              <td>{item.attempt}</td>
              <td>{item.score}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* <div className="pagination">
        <button onClick={prevPage} disabled={currentPage === 1} className="prev-button">
          ← Previous
        </button>
        <button onClick={nextPage} disabled={currentPage === Math.ceil(data.length / itemsPerPage)} className="next-button">
          Next →
        </button>
      </div> */}
    </div>
  );
};

export default AttemptScoresTable;
