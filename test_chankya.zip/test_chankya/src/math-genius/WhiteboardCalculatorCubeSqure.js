import React, { useRef, useState } from 'react';
import './WhiteBordCal.css';

const WhiteboardCalculator = () => {
    const canvasRef = useRef(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [expression, setExpression] = useState(""); // For calculator logic
    const [showCalculator, setShowCalculator] = useState(false); // Show or hide calculator

    // Drawing logic
    const startDrawing = (e) => {
        const ctx = canvasRef.current.getContext("2d");
        ctx.beginPath();
        ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        setIsDrawing(true);
    };

    const draw = (e) => {
        if (!isDrawing) return;
        const ctx = canvasRef.current.getContext("2d");
        ctx.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        ctx.strokeStyle = "black";
        ctx.lineWidth = 2;
        ctx.stroke();
    };

    const stopDrawing = () => {
        setIsDrawing(false);
    };

    // Function to clear the whiteboard
    const clearWhiteboard = () => {
        const ctx = canvasRef.current.getContext("2d");
        ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    };

    // Calculator logic
    const handleButtonClick = (value) => {
        if (value === "C") {
            setExpression("");
        } else if (value === "=") {
            try {
                setExpression(eval(expression).toString()); // Avoid eval in production code
            } catch {
                setExpression("Error");
            }
        } else if (value === "√") {
            setExpression((prev) => Math.sqrt(parseFloat(prev)).toString());
        } else if (value === "x²") {
            setExpression((prev) => (Math.pow(parseFloat(prev), 2)).toString());
        } else if (value === "x³") {
            setExpression((prev) => (Math.pow(parseFloat(prev), 3)).toString());
        } else if (value === "⁴√") {
            setExpression((prev) => Math.pow(parseFloat(prev), 1 / 4).toString());
        } else if (value === ".") {
            if (!expression.includes(".")) {
                setExpression((prev) => prev + value);
            }
        } else {
            // Trigonometric functions with degree conversion to radians
            const degToRad = (angle) => (angle * Math.PI) / 180;
            if (value === "sin") {
                setExpression((prev) => Math.sin(degToRad(parseFloat(prev))).toFixed(4).toString());
            } else if (value === "cos") {
                setExpression((prev) => Math.cos(degToRad(parseFloat(prev))).toFixed(4).toString());
            } else if (value === "tan") {
                setExpression((prev) => Math.tan(degToRad(parseFloat(prev))).toFixed(4).toString());
            } else if (value === "cosec") {
                setExpression((prev) => (1 / Math.sin(degToRad(parseFloat(prev)))).toFixed(4).toString());
            } else if (value === "sec") {
                setExpression((prev) => (1 / Math.cos(degToRad(parseFloat(prev)))).toFixed(4).toString());
            } else if (value === "cot") {
                setExpression((prev) => (1 / Math.tan(degToRad(parseFloat(prev)))).toFixed(4).toString());
            } else {
                setExpression((prev) => prev + value);
            }
        }
    };

    return (
        <div className="whiteboard-calculator">
            <div className="clear-whiteboard">
                <button onClick={clearWhiteboard} className="clear-btn">
                    Clear Whiteboard
                </button>
            </div>

            <canvas
                ref={canvasRef}
                width={750}
                height={450}
                className="whiteboard"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
            ></canvas>

            <div className="calculator-message">
                <button className="message-btn" onClick={() => setShowCalculator(!showCalculator)}>
                    {showCalculator ? "Great job! Hide Calculator" : "Try solving it on your own first! Need help? Open Calculator"}
                </button>
            </div>

            {showCalculator && (
                <div className="calculator">
                    <input type="text" value={expression} readOnly className="calculator-display" />
                    <div className="calculator-buttons">
                        {[
                            "1", "2", "3", "+", "4", "5", "6", "-", "7", "8", "9", "*", "C", "0", "=", "/", "√",
                            "x²", "x³", "⁴√", ".", "sin", "cos", "tan", "cosec", "sec", "cot"
                        ].map((button) => (
                            <button key={button} onClick={() => handleButtonClick(button)}>
                                {button}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default WhiteboardCalculator;
