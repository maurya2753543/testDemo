import React from 'react';
import './AdditionVideoSteptwonumber.css'; // Import the CSS file

const MathDivision = () => {
  const examples = [
    {
      title: "Example 1: Simple Division Without Remainder",
      problem: "84 ÷ 12",
      steps: [
        "Step 1: Set up 84 divided by 12.",
        "Step 2: Determine how many times 12 fits into 84 without exceeding it.",
        "Step 3: 12 fits into 84 exactly 7 times. Write 7 as the answer.",
        "Answer: 7",
      ],
    },
    {
      title: "Example 2: Division With a Remainder",
      problem: "75 ÷ 12",
      steps: [
        "Step 1: Set up 75 divided by 12.",
        "Step 2: Determine how many times 12 fits into 75 without exceeding it.",
        "Step 3: 12 fits into 75 six times (12 x 6 = 72) with a remainder of 3.",
        "Answer: 6 R3",
      ],
    },
    {
      title: "Example 3: Division With Larger Remainder",
      problem: "97 ÷ 15",
      steps: [
        "Step 1: Set up 97 divided by 15.",
        "Step 2: Determine how many times 15 fits into 97 without exceeding it.",
        "Step 3: 15 fits into 97 six times (15 x 6 = 90) with a remainder of 7.",
        "Answer: 6 R7",
      ],
    },
    {
      title: "Example 4: Division with Zero Remainder",
      problem: "56 ÷ 7",
      steps: [
        "Step 1: Set up 56 divided by 7.",
        "Step 2: Determine how many times 7 fits into 56 exactly.",
        "Step 3: 7 fits into 56 exactly 8 times with no remainder.",
        "Answer: 8",
      ],
    },
  ];

  return (
    <div className="math-container">
      <h1>Learn Two-Digit Division</h1>
      {examples.map((example, index) => (
        <div className="card" key={index}>
          <h2>{example.title}</h2>
          <p>Problem: {example.problem}</p>
          {example.steps.map((step, stepIndex) => (
            <p key={stepIndex}>{step}</p>
          ))}
        </div>
      ))}
    </div>
  );
};

export default MathDivision;
