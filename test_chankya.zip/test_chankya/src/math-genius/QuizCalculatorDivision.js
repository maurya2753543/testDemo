import React, { useState, useEffect } from "react";
import "./QuizCalculatorMulti.css";
import AppwriteService from '../appwrite/AppwriteService';
import QuizCalTableContent from './QuizCalTableContent';
import TopScoreQuiz from './TopScoreQuiz';
import AttemptScoresTable from './AttemptScoresTable';
import MathDivisionFor from './MathDivisionFor';

const QuizCalculatorDivision = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes = 300 seconds
  const [showResult, setShowResult] = useState(false);
  const [userAnswer, setUserAnswer] = useState("");
  const [quizStarted, setQuizStarted] = useState(false); // To handle quiz start
  const [name, setName] = useState('');
  
  const totalDuration = 300;

  let timerColor;
  let progressPercentage = (timeLeft / totalDuration) * 100;

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get();       
        setName(user.name);
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  // Generate 80 random questions (Adding two 2-digit numbers)
  useEffect(() => {
    const generatedQuestions = [];
    for (let i = 0; i < 80; i++) {
      let num1 = Math.floor(Math.random() * 90) + 10; // Two-digit number
      let num2 = Math.floor(Math.random() * 9) + 1; // Smaller non-zero divisor

      // Ensure num1 is divisible by num2 to get an integer result
      num1 = num1 - (num1 % num2); // Adjust num1 to be divisible by num2

      const quotient = num1 / num2; // Perform the division

      generatedQuestions.push({
        question: `${num1} ÷ ${num2}`,
        answer: quotient,
      });
    }
    setQuestions(generatedQuestions);
  }, []);


  useEffect(() => {
    if (quizStarted && timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => {
        setTimeLeft((prevTimeLeft) => prevTimeLeft - 1);
      }, 1000);

      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setShowResult(true);
    }
  }, [quizStarted, timeLeft, showResult]);

  const handleAnswerChange = (e) => {
    const userInput = e.target.value;
    setUserAnswer(userInput);

    if (parseInt(userInput) === questions[currentQuestion].answer) {
      setScore(score + 1);
      setUserAnswer(""); // Clear input for the next question
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        setShowResult(true);
      }
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setScore(0);
    setTimeLeft(300); // reset to 5 minutes
    setShowResult(false);
    setUserAnswer("");
    setQuizStarted(false);
  };

  const startQuiz = () => {
    setQuizStarted(true);
  };

  const calculateLevel = () => {
    if (score < 20) return "Starter";
    if (score >= 20 && score < 30) return "Challenger";
    if (score >= 30 && score < 40) return "Master";
    return "Genius";
  };

  if (!quizStarted) {
    return (
      <>
      <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="MuiCardContent-root dashboard-background">
          <div className="MuiPaper-root MuiCard-root MuiPaper-elevation1 MuiPaper-rounded" style={{ background: "transparent", borderBottom: "3px solid rgb(116, 130, 232)", marginBottom: "10px", backdropFilter: "blur(4px)" }}>
            <div>
            <h3
                className="MuiTypography-root MuiTypography-h3"
                style={{
                  fontWeight: "800",
                  color: "rgb(85, 100, 204)",
                  padding: "0px",
                  fontSize: "30px",
                  marginRight: '100px',
                  marginTop : '20px',
                  width : '100%'
                }}
              >
               Division 2 digits in a sequence
              </h3>
            </div>
          </div>
          <div style={{ padding: "40px", width : '100%',  textAlign: "center", marginTop: "3%", marginBottom: "5%", background: "transparent", backdropFilter: "blur(4px)" }}>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)' }} className="MuiTypography-root MuiTypography-h4">Fast Division
            </h1>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontSize: '20px' }}>Fast Division</p>
            <button className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary" onClick={startQuiz} style={{ marginTop: "10px", color: 'white', width: '80%', backgroundColor: '#3f51b5', fontSize: '16px', borderRadius: '5px' }}>
              <h3 className="MuiTypography-root MuiTypography-h6">LET'S GO</h3>
            </button>
           
          </div>
        </div>
      </div>
      </>
      
    );
  }

  if (showResult) {
    return (
      <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="main-multi-section">
          <div className="MuiCardContent-root dashboard-background">
            <h1 className="Game_over">GAME OVER</h1>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', marginLeft: '20px' }}>Hi {name}, Your Score: {score}</h1>
            <p style={{ marginTop: "10px",  color: 'rgb(116, 130, 232)',
                 fontWeight : '700' ,marginLeft: '220px', fontSize: '18px' }}>Your Level: {calculateLevel()}</p>
            
            <button
              className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary"
              onClick={handleRestart}
              
              style={{ marginTop: "10px" ,
                marginBottom : '100px',
                color : 'white',
                width : '60%',
                backgroundColor : '#3f51b5',
                fontSize : '16px',
                borderRadius : '10px',
                marginLeft : '150px',
                height : '80px',
                
               }}
            >
              <h2 className="MuiTypography-root MuiTypography-h6">PLAY AGAIN</h2>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion] || {};
  let timerBackgroundColor;

  if (timeLeft > 150) {
    timerColor = "#BCB6E2";
    timerBackgroundColor = "#2962FF"; // Light blue background
  } else if (timeLeft > 60) {
    timerColor = "#BCB6E2";
    timerBackgroundColor = "darkorange"; // Light yellow background
  } else {
    timerColor = "red";
    timerBackgroundColor = "red"; // Light red background
  }

  return (
    <>
    <MathDivisionFor />
    <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
      <div className="MuiCardContent-root dashboard-background">
      <div
          className="MuiPaper-root MuiCard-root MuiPaper-elevation1 MuiPaper-rounded"
          style={{
            background: "transparent",
            borderBottom: "3px solid rgb(116, 130, 232)",
            marginBottom: "10px",
            backdropFilter: "blur(4px)",
          }}
        >
          <div className="MuiCardContent-root">
            <div style={{width : '500px' , paddingTop : '10px'}}>
              <h3
                className="MuiTypography-root MuiTypography-h3"
                style={{
                  fontWeight: "800",
                  color: "rgb(85, 100, 204)",
                  padding: "0px",
                  fontSize: "30px",
                  marginRight: '100px',
                  paddingTop : '20px',
                  width : '100%'
                }}
              >
               Division 2 digits in a sequence
              </h3>
            </div>
          </div>
        </div>

        <div style={{ position: "relative", marginTop: "50px" }}>
          <div>
            <div
              className="MuiLinearProgress-root MuiLinearProgress-colorPrimary MuiLinearProgress-determinate"
              style={{ height: "10px", backgroundColor: timerColor }}
            >
             <div
          className="MuiLinearProgress-bar MuiLinearProgress-barColorPrimary MuiLinearProgress-bar1Determinate"
          style={{
            width: `${progressPercentage}%`, // Ensure the width decreases as timeLeft decreases
            transition: "width 1s linear", // Smooth transition when the width changes
            backgroundColor: "#3f51b5", // Progress bar color
            height: "100%",
            borderRadius: "5px",
          }}
        ></div>
            </div>
          </div>
          <div
            style={{
              position: "absolute",
              marginTop: "10px",
              right: "20px",
              top: "-50px",
              zIndex: "10",
              fontSize: "24px",
              fontWeight: "bold",
              color: "white",
              lineHeight: "5px",
              backgroundColor: timerBackgroundColor,
              padding: "5px",
              borderRadius: "5px",
              boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
            }}
          >
            <h3>{`${Math.floor(timeLeft / 60)}:${
              timeLeft % 60 < 10 ? "0" : ""
            }${timeLeft % 60}`}</h3>
          </div>
        </div>

        <div
          className="MuiPaper-root MuiCard-root question-section MuiPaper-elevation1 MuiPaper-rounded"
          style={{
            padding: "50px",
            textAlign: "center",
            marginTop: "3%",
            marginBottom: "10%",
            height: "100%",
            background: "transparent",
            backdropFilter: "blur(4px)",
            lineHeight: "2em",
          }}
        >
          <h1>
            {`${currentQ.question} = `}
            <input
              type="number"
              value={userAnswer}
              onChange={handleAnswerChange}
              placeholder=""
              className="input-box-calmulti"
            />
          </h1>
          <div  style={{
            padding: "50px",
           
            borderBottom: "3px solid rgb(116, 130, 232)",
          }}>

          </div>
        </div>
       
      </div>
    </div>
    <AttemptScoresTable />
    <QuizCalTableContent/>
    <TopScoreQuiz />
    </>
  );
};

export default QuizCalculatorDivision;
