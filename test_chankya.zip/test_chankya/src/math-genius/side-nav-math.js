import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBookOpen, faCheckCircle, faCircle, faHome } from '@fortawesome/free-solid-svg-icons';
import { faYoutube } from '@fortawesome/free-brands-svg-icons';
import { Link, useNavigate } from 'react-router-dom';
import DashboardPopup from './DashboardPopup'; // Import the DashboardPopup component
import "./side-nav-math.css";
import QuizCalculatorMulti from "./QuizCalculatorMulti";
import QuizCalculatorAddTwo from "./QuizCalculatorAddTwo";
import QuizCalculatorSubstract from "./QuizCalculatorSubstract";
import QuizCalculatorDivision from "./QuizCalculatorDivision";
import QuizCalculatorAddThree from "./QuizCalculatorAddThree";
import QuizCalculatorThreeSubstract from "./QuizCalculatorThreeSubstract";
import QuizCalculatorThreeDivision from './QuizCalculatorThreeDivision';
import QuizCalculatorTwoSqure from './QuizCalculatorTwoSqure';
import QuizCalculatorAddtwostep from './QuizCalculatorAddtwostep';
import QuizCalculatorSubstractTwoStep from './QuizCalculatorSubstractTwoStep';
import QuizCalculatorAddFourtDigit from './QuizCalculatorAddFourtDigit';
import QuizCalculatorMultiFourDigit from './QuizCalculatorMultiFourDigit';
import QuizCalculatorFourDigitSubscraction from './QuizCalculatorFourDigitSubscraction';
import QuizCalculatorFourDigitDivision from './QuizCalculatorFourDigitDivision';
import QuizCalculatorOfSqureRootTwo from './QuizCalculatorOfSqureRootTwo';
import QuizCalculatorForPrimeNumber from './QuizCalculatorForPrimeNumber';
import QuizCalculatorForEvenNumber from './QuizCalculatorForEvenNumber';
import  QuizCalculatorMagicNumber from './QuizCalculatorMagicNumber';
import QuizCalculatorCubeNumber from './QuizCalculatorCubeNumber';
import QuizCalculatorForFourthRoot from './QuizCalculatorForFourthRoot';
import QuizCalculatorAddTwoDecimalPlace from './QuizCalculatorAddTwoDecimalPlace';
import QuizCalculatorMultiChoice from '../kbc/QuizCalculatorMultiChoice';
function AppSideNav() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSection, setExpandedSection] = useState(null); // Track expanded section
  const [completedCourses, setCompletedCourses] = useState(["0-0"]); // Track completed courses, including the first one by default

  const navigate = useNavigate();

  const [activeContent, setActiveContent] = useState({
    sectionIndex: 0,
    contentIndex: 0,
    title: "0. Two Digit Division",
    icon: faYoutube,
    video: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  });
  //const [completedCourses, setCompletedCourses] = useState([]); // Track completed courses
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const handlePopupOpen = () => {
    setIsPopupOpen(true); // Open popup
  };

  const handlePopupClose = () => {
    setIsPopupOpen(false); // Close popup
  };

  const handleConfirmNavigation = async () => {
    handlePopupClose(); // Close the popup
    try {
      navigate('/dashboard'); // Redirect to dashboard
    } catch (error) {
      console.error("Error navigating to dashboard:", error);
    }
  };

  const sections = [
    {
      title: "Maths Activities Basic",
      content: [
        { label: "0. Two Digit Division", video: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", icon: faYoutube },
        { label: "1. Multiplication of 11", video: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", icon: faYoutube },
        { label: "2. Add two 2 digit numbers", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "3. Add 2 digits in head and take a challenge", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "4. Subtract two 2 digit numbers using give and take technique", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "5. Subtract 2 digit numbers in your head and take a challenge", video: "https://i.vimeocdn.com/video/1159264676-465888ff3af497d7471ffadccb05295ee0fdf95d507d02e632de2ae76f63c183-d?mw=1800&mh=4320&q=70", icon: faYoutube },
        { label: "6. Fast addition using little bit of give and take", video: "https://i.vimeocdn.com/video/1159264676-465888ff3af497d7471ffadccb05295ee0fdf95d507d02e632de2ae76f63c183-d?mw=1800&mh=4320&q=70", icon: faYoutube },      
        { label: "7. Add 3-digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "8. Square of numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "9. Subtract 3 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "10. Division 3 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "11. Add 4 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "12. Subtract 4 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "13. Multiplication 4 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "14. Division 4 digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "15. Perfect square roots  of two digit numbers in your head", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "16. Generating Perfect Squares with Prime Number Results", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "17. Generating Perfect Squares with Even Number Results", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "18. Generating Perfect Magic Number", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "19. Generating Perfect cube root", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "20. Generating  Perfect fourth power", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        { label: "21. Two-digit number with two decimal places", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        // { label: "22. Three-digit number with three-digit decimal places", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      
        // { label: "23. Four-digit number with four decimal places", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },      

       
       
           
       
       

      ]
    },
    {
      title: "Maths Activities Advance Level",
      content: [
        { label: "Content 2A", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Content 2B", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
      ]
    },
    {
      title: "Maths Activities Expert level",
      content: [
        { label: "Content 3A", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Content 3B", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
      ]
    }
  ];

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleContentClick = (sectionIndex, contentIndex, content) => {
    setActiveContent({
      sectionIndex,
      contentIndex,
      title: content.label,
      icon: content.icon,
      video: content.video,
    });

    if (!completedCourses.includes(`${sectionIndex}-${contentIndex}`)) {
      setCompletedCourses([...completedCourses, `${sectionIndex}-${contentIndex}`]);
    }
  };

  return (
    <> 
     <div className="app-container">
      <div className={`sidebar-math ${isExpanded ? "expanded" : "collapsed"}`}>
        <div className="tutor-tabs-btn-group">
          <a href="#tutor-lesson-sidebar-tab-content">
            <FontAwesomeIcon style={{ color: '#ff5248' }} icon={faBookOpen} />
            <span className="Lesson-title"> Lesson List</span>
          </a>
        </div>

        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="section">
            <div className="section-title" onClick={() => toggleSection(sectionIndex)}>
              <FontAwesomeIcon /> {section.title} <span className="expend-icon-penal"> {expandedSection === sectionIndex ? "-" : "+"} </span>
            </div>
            {expandedSection === sectionIndex && (
              <div className="section-content tutor-lessons-under-topic">
                <ul>
                  {section.content.map((item, contentIndex) => (
                    <li
                      key={contentIndex}
                      className={`content-item ${activeContent.sectionIndex === sectionIndex && activeContent.contentIndex === contentIndex ? "active-content" : ""}`}
                    >
                      <a href="#!" onClick={() => handleContentClick(sectionIndex, contentIndex, item)} className="content-link">
                        <div className="content-info">
                          <div className="content-left">
                            <FontAwesomeIcon icon={item.icon} style={{ marginRight: "8px" }} />
                            <span>{item.label}</span>
                          </div>
                          <div className="content-right">
                            <span className="content-timing">5:32</span>
                            <FontAwesomeIcon
                              icon={completedCourses.includes(`${sectionIndex}-${contentIndex}`) ? faCheckCircle : faCircle}
                              className="completion-icon"
                            />
                          </div>
                        </div>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="content-side-bar">
        <div className="video-player-header">
          <button className="toggle-btn" onClick={toggleSidebar}>
            {isExpanded ? ">" : "<"}
          </button>
          {/* Home Icon and Go to Home Message */}
          <span  onClick={handlePopupOpen} className="go-home">
            <FontAwesomeIcon icon={faHome} />  Go to Course Dashboard
          </span>
          <span className="header-title-side-bar">
            <h3><FontAwesomeIcon icon={activeContent.icon} /> {activeContent.title}</h3>
          </span>
        </div>
        {/* <video src={activeContent.video} controls width="100%" autoPlay /> */}
        
        {/* Conditionally show QuizCalculatorMulti if "The Beauty of 11" is selected */}
        {activeContent.title === "0. Two Digit Division" && <QuizCalculatorDivision />}
        {activeContent.title === "1. Multiplication of 11" && <QuizCalculatorMultiChoice />}
        {activeContent.title === "2. Add two 2 digit numbers" && <QuizCalculatorAddtwostep />}
        {activeContent.title === "3. Add 2 digits in head and take a challenge" && <QuizCalculatorAddTwo />}
        {activeContent.title === "4. Subtract two 2 digit numbers using give and take technique" && <QuizCalculatorSubstractTwoStep />}
        {activeContent.title === "5. Subtract 2 digit numbers in your head and take a challenge" && <QuizCalculatorSubstract />}
        {activeContent.title === "6. Fast addition using little bit of give and take" && <QuizCalculatorAddTwo />}       
        {activeContent.title === "7. Add 3-digit numbers in your head" && <QuizCalculatorAddThree />}
        {activeContent.title === "8. Square of numbers in your head" && <QuizCalculatorTwoSqure />}
        {activeContent.title === "9. Subtract 3 digit numbers in your head" && <QuizCalculatorThreeSubstract />}
        {activeContent.title === "10. Division 3 digit numbers in your head" && <QuizCalculatorThreeDivision />}
        {activeContent.title === "11. Add 4 digit numbers in your head" && <QuizCalculatorAddFourtDigit />}
        {activeContent.title === "12. Subtract 4 digit numbers in your head" && <QuizCalculatorFourDigitSubscraction />}
        {activeContent.title === "13. Multiplication 4 digit numbers in your head" && <QuizCalculatorMultiFourDigit />}
        {activeContent.title === "14. Division 4 digit numbers in your head" && <QuizCalculatorFourDigitDivision />}
        {activeContent.title === "15. Perfect square roots  of two digit numbers in your head" && <QuizCalculatorOfSqureRootTwo/>}
        {activeContent.title === "16. Generating Perfect Squares with Prime Number Results" && <QuizCalculatorForPrimeNumber />}
        {activeContent.title === "17. Generating Perfect Squares with Even Number Results" && <QuizCalculatorForEvenNumber />}
        {activeContent.title === "18. Generating Perfect Magic Number" && <QuizCalculatorMagicNumber/>}
        {activeContent.title === "19. Generating Perfect cube root" && <QuizCalculatorCubeNumber/>}
        {activeContent.title === "20. Generating  Perfect fourth power" && <QuizCalculatorForFourthRoot/>}
        {activeContent.title === "21. Two-digit number with two decimal places" && <QuizCalculatorAddTwoDecimalPlace/>}

            
        
      </div>

    </div>
     {/* Render Popup if it's open */}
     {isPopupOpen && (
            <DashboardPopup 
              onClose={handlePopupClose} 
              onConfirm={handleConfirmNavigation} 
            />
          )}

  </>
   
  );
}

export default AppSideNav;
