import React, { useState } from 'react';
import './PurchaseHistory.css'; // Ensure you have this stylesheet
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import kbc from '../images/kbc.jpeg'
import class2to5 from '../images/class2to5.jpeg'
import class6to10 from '../images/class6to10.jpeg'

const PurchaseHistory = () => {
  // Sample purchase history data
  const [purchaseHistory, setPurchaseHistory] = useState([
    {
      id: 1,
      itemName: 'One-Time Maths Program (2-5) Grades Students',
      purchaseDate: '2024-12-01',
      logo: class2to5, // Replace with your logo URL
    },
    {
      id: 2,
      itemName: 'One-Time Maths Program (6-10) Grades Students',
      purchaseDate: '2024-10-02',
      logo: class6to10, // Replace with your logo URL
    },
    {
      id: 3,
      itemName: 'Monthly Maths Program (2-5) Grades Students',
      purchaseDate: '2024-10-03',
      logo: class2to5, // Replace with your logo URL
    },
    {
      id: 4,
      itemName: 'Monthly Maths Program (6-10) Grades Students',
      purchaseDate: '2024-10-01',
      logo: class6to10, // Replace with your logo URL
    },
    {
      id: 5,
      itemName: '"One-Time KBC Prep',
      purchaseDate: '2024-10-01',
      logo: kbc, // Replace with your logo URL
    },
    {
      id: 6,
      itemName: '"Monthly KBC Prep',
      purchaseDate: '2024-10-02',
      logo: kbc, // Replace with your logo URL
    },
    
  ]);

  // Handle delete purchase
  const handleDelete = (id) => {
    const updatedHistory = purchaseHistory.filter(item => item.id !== id);
    setPurchaseHistory(updatedHistory);
  };

  return (
    <div className="purchase-history-container">
      <h1>Purchase History</h1>

      {purchaseHistory.length === 0 ? (
        <p>No purchases found.</p>
      ) : (
        <div className="purchase-history-cards">
          {purchaseHistory.map((item) => (
            <div className="purchase-card" key={item.id}>
              <div className="card-header">
                <FontAwesomeIcon 
                  icon={faTrashAlt} 
                  className="delete-icon" 
                  onClick={() => handleDelete(item.id)} 
                />
              </div>
              <div className="card-body">
                <img src={item.logo} alt={`${item.itemName} logo`} className="item-logo" />
                <h3>{item.itemName}</h3>
                <p>Date of Purchase: {item.purchaseDate}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PurchaseHistory;
