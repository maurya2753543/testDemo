import React, { useState } from 'react';
import './MyProfileLogin.css';
import { Link, useNavigate } from 'react-router-dom';
import AppwriteService from '../appwrite/AppwriteService'; // Ensure this path is correct
import ClipLoader from "react-spinners/ClipLoader"; // Import the loader

const MyProfileLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false); // State for loader
  const navigate = useNavigate();

  // Initialize the Appwrite service
  const appwriteService = new AppwriteService();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true); // Show loader

    try {
      const session = await appwriteService.login({ email, password });
      if (session) {
        // console.log('User logged in successfully:', session);
        setLoading(false); // Hide loader

        setErrorMessage('');
        navigate('/dashboard/user'); // Redirect to dashboard after successful login
      }
    } catch (error) {
      console.error('Error during login:', error);
      setErrorMessage('Login failed. Please check your credentials.');
      setLoading(false); // Hide loader after error

    }
  };

  return (
    <div className="tutor-wrap tutor-page-wrap post-5 page type-page status-publish hentry">
      <div className="tutor-template-segment tutor-login-wrap">
        <div className="tutor-login-title">
          <h4>Please Sign-In to view this section</h4>
        </div>
        <div className="loader-container">
                <ClipLoader color={"#36d7b7"} loading={loading} size={50} />
              </div>
        {errorMessage && <p style={{ color: 'red', textAlign: 'center' }}>{errorMessage}</p>} {/* Error message display */}

        <div className="tutor-template-login-form">
          <div className="tutor-login-form-wrap">
            <form name="loginform" id="loginform" method="post" onSubmit={handleSubmit}>
              <p className="login-username">
                <input
                  type="text"
                  placeholder="Email Address"
                  name="log"
                  id="user_login"
                  className="input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <p className="login-password">
                <input
                  type="password"
                  placeholder="Password"
                  name="pwd"
                  id="user_pass"
                  className="input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <div className="tutor-login-remember-wrap">
                <p className="login-remember">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label htmlFor="rememberme">Remember Me</label>
                  <Link to="/dashboard/retrieve-password" className="forgot-password-link">
                    Forgot Password?
                  </Link>
                </p>
              </div>

              <p className="login-submit">
                <input type="submit" name="wp-submit" id="wp-submit" className="tutor-button1" value="Log In" />
                <input type="hidden" name="redirect_to" value="" />
              </p>

              <p className="tutor-form-register-wrap">
                <Link to="/dashboard/student-registration">Create a new account</Link>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyProfileLogin;
