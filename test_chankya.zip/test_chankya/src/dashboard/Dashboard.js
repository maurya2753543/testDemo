import React, {useEffect, useState } from 'react';
import Header from '../comman-header/Header';
import Footer from '../footer/Footer';
import TabLayout from './TabLayout';
import MyProfileLogin from './MyProfileLogin';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AppwriteService from '../appwrite/AppwriteService';

const Dashboard = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const appwriteService = new AppwriteService(); // Create an instance of AppwriteService

   // Check for session when component loads
   useEffect(() => {
    const checkSession = async () => {
      try {
        const currentUser = await appwriteService.account.get();
        if (currentUser) {
          setIsLoggedIn(true); // If session exists, set isLoggedIn to true
        }
      } catch (error) {
        console.log("No active session found, showing login page");
        setIsLoggedIn(false); // No session, show login
      }
    };
    checkSession();
  }, []);


  return (
    <>
   
      {/* <TabLayout />
      <TabContent /> */}
      {/* Show MyProfileLogin if not logged in, otherwise show TabLayout and TabContent */}
      {!isLoggedIn ? (
        <> 
           <Header />
        <MyProfileLogin onLoginSuccess={() => setIsLoggedIn(true)} />

        </>
      ) : (
        <div>
          {/* <DashboardContent /> */}
          <TabLayout />
      
          </div>

        
      )}
      <Footer />
    </>
  );
};

export default Dashboard;
