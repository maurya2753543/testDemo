import React from 'react';
import AppSideNav from '../math-genius/side-nav-math';

const Reviews = () => {
  return (
    <div>
      {/* <AppSideNav/> */}
    </div>
  );
};

export default Reviews;
