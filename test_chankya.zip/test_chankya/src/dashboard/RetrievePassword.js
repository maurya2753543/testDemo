import React, { useState } from 'react';
import './RetrievePassword.css'; // Import the CSS for the form
import Header from '../comman-header/Header';
import Footer from '../footer/Footer';
const RetrievePassword = () => {
  const [userLogin, setUserLogin] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here (e.g., send the data to an API)
    console.log('Form submitted:', userLogin);
  };

  return (
    <>
          <Header />
          <form method="post" className="tutor-ResetPassword lost_reset_password" onSubmit={handleSubmit}>
      {/* Hidden fields for nonce and action */}
      <input type="hidden" id="_tutor_nonce" name="_tutor_nonce" value="2380e86470" />
      <input type="hidden" name="_wp_http_referer" value="/dashboard/retrieve-password/" />
      <input type="hidden" name="tutor_action" value="tutor_retrieve_password" />

      <p>
        Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.
      </p>
      
      {/* Username or email input */}
      <div className="tutor-form-row">
        <div className="tutor-form-col-6">
          <div className="tutor-form-group">
            <label htmlFor="user_login">Username or email</label>
            <input
              type="text"
              name="user_login"
              id="user_login"
              value={userLogin}
              onChange={(e) => setUserLogin(e.target.value)}
              autoComplete="username"
              required
            />
          </div>
        </div>
      </div>

      <div className="clear"></div>

      {/* Submit button */}
      <div className="tutor-form-row-reset">
        <div className="tutor-form-col-6">
          <div className="tutor-form-group-reset">
            <button type="submit" className="tutor-button tutor-button-primary">
              Reset password
            </button>
          </div>
        </div>
      </div>
    </form>
    <Footer/>

    </>
   
  );
};

export default RetrievePassword;
