import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './header/NavBar'; // Assuming NavBar is inside a 'components' folder
import Connect from './connect/Connect'; // Connect page component
import Dashboard from './dashboard/Dashboard'; // Dashboard page component
import TabLayout from './dashboard/TabLayout';
import 'font-awesome/css/font-awesome.min.css';
import RetrievePassword from './dashboard/RetrievePassword';
import StudentRegistration from './dashboard/StudentRegistration';
import TabContent from './dashboard/DashbordContent';
import  MainHomeForm from './header/MainHomeForm';
import MathGgeniusProgram from './maths-genius-program-level1/MathGgeniusProgram';
import AppSideNav from './math-genius/side-nav-math';
import AppSideNavKBC from './kbc/side-nav-math-kbc';
import KBCGeniusProgram from './kbc/KBCGeniusProgram';
import Settings from './dashboard/Settings';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Function to handle successful login
  const handleLoginSuccess = () => {
    setIsLoggedIn(true); // Update state to indicate user is logged in
  };
  return (

    <Router>
      {/* NavBar is rendered on all routes */}
      
      <Routes>
        {/* Define your routes here */}
        <Route path="/" element={<NavBar />} />
        <Route path="/about-us" element={<Connect />} />     
        <Route path="/dashboard/retrieve-password" element={<RetrievePassword />} />
        <Route path="/dashboard/student-registration" element={<StudentRegistration />} /> 
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/user" element={<TabLayout />} />      
        <Route path="/dashboard/settings" element={<Settings />} />
        <Route path="/book-classes" element={<MainHomeForm />} />
        <Route path="/courses/maths-genius-level-1-5" element={<MathGgeniusProgram />} />        
        <Route path="/lesson/maths-chanakya-class-2-to-5/" element={<AppSideNav />} />
        <Route path="/lesson/maths-chanakya-kbc/" element={<AppSideNavKBC />} />

        <Route path="/courses/kbc-genius-level-quiz" element={<KBCGeniusProgram />} />


        

       

      </Routes>

      {/* <TabLayout /> */}
    
    </Router>
  );
}

export default App;
