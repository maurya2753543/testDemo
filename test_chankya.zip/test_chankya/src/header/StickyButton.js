import React, { useState, useRef, useEffect } from 'react';
import './StickyButton.css';
import emailjs from 'emailjs-com';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const StickyButton = () => {
  const [isPopupVisible, setPopupVisible] = useState(false);
  const [isArrowRotated, setArrowRotated] = useState(false);
  const [isContactFormVisible, setContactFormVisible] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [error, setError] = useState('');
  const formRef = useRef(null);

  const toggleArrow = () => {
    setArrowRotated(!isArrowRotated);
    setPopupVisible(!isPopupVisible);
    setContactFormVisible(false);
  };

  const handleContactClick = () => {
    setContactFormVisible(!isContactFormVisible);
  };

  const handleMouseLeave = () => {
    setPopupVisible(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (formRef.current && !formRef.current.contains(event.target)) {
        setContactFormVisible(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [formRef]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.phone || !formData.message) {
      setError('Please fill out all required fields.');
      return;
    }

    const templateParams = {
      user_name: formData.name,
      user_email: formData.email,
      user_phone: formData.phone,
      user_message: formData.message
    };

    emailjs.send('service_ndzw3dp', 'template_b09m1tv', templateParams, 'j9IeoZw8w6Mkpkxl6')
      .then((response) => {
        toast.success('Form submitted successfully!');
        setFormData({ name: '', email: '', phone: '', message: '' });
        setError('');
      })
      .catch((error) => {
        console.error('Error sending email:', error);
        toast.error('Failed to submit the form. Please try again.');
        setError('');
      });
  };

  return (
    <div className="mystickyelement-lists-wrap">
      <ToastContainer />
      <ul className="mystickyelements-lists mysticky">
        <li className="mystickyelements-minimize" onClick={toggleArrow} style={{ width: '90px' }}>
          <span
            className="mystickyelements-minimize"
            style={{
              background: '#000',
              color: '#fff',
              fontSize: '20px',
              width: '60px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '40px',
              transition: 'transform 0.3s',
              transform: isArrowRotated ? 'rotate(180deg)' : 'rotate(0deg)',
            }}
          >
            →
          </span>
        </li>

        <li
          id="mystickyelements-contact-form"
          className="mystickyelements-contact-form"
          style={{
            width: '90px',
            transform: isArrowRotated ? 'rotate(-90deg)' : 'rotate(0deg)',
            display: isPopupVisible ? 'none' : 'flex',
            transition: 'transform 0.3s',
          }}
        >
          <span className="contactus_btn">
            <span
              style={{
                backgroundColor: 'rgb(119, 97, 223)',
                color: '#fff',
                width: '110px',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '55px',
                transform: 'rotate(-90deg)',
                gap: '15px',
                padding: '0 10px 10px 10px',
                borderRadius: '10px 0 0 0',
              }}
              onMouseEnter={handleContactClick}
              onMouseLeave={handleMouseLeave}
            >
              <i className="far fa-envelope" style={{ fontSize: '15px' }}></i>
              Contact Us
            </span>
          </span>
        </li>

        {isContactFormVisible && (
          <div
            className="element-contact-form"
            ref={formRef}
            style={{ marginTop: '10px', display: isContactFormVisible ? 'block' : 'none' }}
            onMouseLeave={() => setContactFormVisible(false)}
          >
            <h3 className="contact-header">
              Contact Us
              <a href="javascript:void(0);" className="element-contact-close" onClick={handleContactClick}>
                <i className="fas fa-times"></i>
              </a>
            </h3>

            <form id="stickyelements-form" onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <input
                type="tel"
                name="phone"
                placeholder="Phone"
                value={formData.phone}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <textarea
                name="message"
                placeholder="Message"
                value={formData.message}
                onChange={handleChange}
                required
              ></textarea>
              <input
                type="submit"
                value="Submit"
                style={{ backgroundColor: '#7761DF', color: '#FFFFFF' }}
              />
            </form>
            {error && <span className="error alert-message">{error}</span>}
          </div>
        )}
      </ul>
    </div>
  );
};

export default StickyButton;
