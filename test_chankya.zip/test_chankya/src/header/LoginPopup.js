import React, { useState } from 'react';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa'; // For close button
import SignUp from './Registration';
import AppwriteService from '../appwrite/AppwriteService';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate

// Access environment variables (with fallback if not defined)
const apiEndpoint = process.env.REACT_APP_API_ENDPOINT || 'https://cloud.appwrite.io/v1';
const apiKey = process.env.REACT_APP_API_KEY || '66fb8c0f0024c89bdea5';

// Styled Components for Modal and Form
const ModalWrapper = styled.div`
  position: fixed;
  top: 0;
  right: 0;
  width: 400px;
  height: 100vh;
  background-color: #fff;
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
  padding: 20px;
  overflow-y: auto;
`;

const ModalContent = styled.div`
  position: relative;
  padding: 30px 50px;
`;

const CloseButton = styled(FaTimes)`
  position: absolute;
  top: -20px;
  right: 5px;
  cursor: pointer;
  background-color: #ff5248;
  color: white;
  padding: 8px;
  border-radius: 20px;
  font-weight: 700;
  margin-bottom: 230px;
  margin-left: 40px;
  margin-top: 20px;
`;

const Title = styled.h2`
  font-size: 30px;
  font-family: Open Sans;
  font-weight: 700;
  line-height: 27px;
  color: #1f2949;
`;

const Subtitle = styled.h4`
  font-size: 15px;
  margin-bottom: 20px;
  color: #555;
  font-weight: 500;
`;

const LoginForm = styled.form`
  display: flex;
  flex-direction: column;
  input {
    margin-bottom: 15px;
    padding: 15px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  input[type="text"]:focus,
  input[type="email"]:focus,
  input[type="password"]:focus {
    outline: none;
    background-color: transparent;
    border: 1px solid red;
  }

  button {
    padding: 15px;
    background-color: #ff5248;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    font-weight: 700;
    font-size: 18px;
  }
`;

const CheckboxWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
`;

const RememberMeLabel = styled.label`
  display: inline-flex;  
  font-size: 12px;
  cursor: pointer; 
  margin-top: 10px;

  span {
    margin-top: 5px;
  }
  
  input[type="checkbox"] {
    margin-right: 8px;
    width: 20px;
    height: 20px;
    border-radius: 3px;
    border: 2px solid #dadce0;
    transition: background-color 0.3s ease, color 0.3s ease;
  }
`;

const ForgotPasswordLink = styled.a`
  font-size: 12px;
  color: #797c7f;
  cursor: pointer;
  text-decoration: none;
  
  &:hover {
    color: black;
    font-weight: 400;
  }
`;

const Divider = styled.div`
  display: flex;
  align-items: center;
  text-align: center;
  margin: 36px 0;
  color: #797c7f;

  &:before, &:after {
    content: "";
    flex: 1;
    border-bottom: 1.5px dotted #000;
    margin: 0 10px;
  }

  span {
    white-space: nowrap;
    font-size: 16px;
    color: #000;
    z-index: 2;
  }
`;

const SignUpLink = styled.a`
  text-decoration: none;
  color: black;
  cursor: default;
  margin-top: 15px;
  display: inline-block;

  span {
    color: red;
    cursor: pointer;
    transition: background-color 0.3s ease;
    
    &:hover {
      color: black;
    }
  }
`;

const LoginPopup = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const navigate = useNavigate();

  const openSignUpModal = () => setIsSignUpOpen(true);
  const closeSignUpModal = () => setIsSignUpOpen(false);

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const appwriteService = new AppwriteService(apiEndpoint, apiKey);
      const response = await appwriteService.login({ email, password });
      console.log(response, 'response user i need');

      if (response) {
        navigate('/dashboard/user');
        setErrorMessage('');
      }
    } catch (error) {
      setErrorMessage('Login failed. Please check your credentials.');
      console.error('Error during login:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <ModalWrapper isOpen={isOpen}>
        <ModalContent>
          <CloseButton onClick={onClose} />
          <Title>Login</Title>
          <Subtitle>Hello there, haven’t we seen you before?</Subtitle>
          {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
          <LoginForm onSubmit={handleSubmit}>
            <input
              type="text"
              name="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <CheckboxWrapper>
              <RememberMeLabel>
                <input type="checkbox" id="rememberme" name="rememberme" />
                <span className="remember">Remember Me</span>
              </RememberMeLabel>
              <ForgotPasswordLink href="#">Forgot your password?</ForgotPasswordLink>
            </CheckboxWrapper>
            <button type="submit">Login Now</button>
          </LoginForm>
          <SignUpLink onClick={openSignUpModal}>
            New here? <span>Sign Up</span>
          </SignUpLink>
          <Divider><span>OR</span></Divider>
        </ModalContent>
      </ModalWrapper>
      <SignUp isOpen={isSignUpOpen} onClose={closeSignUpModal} />
    </>
  );
};

export default LoginPopup;
