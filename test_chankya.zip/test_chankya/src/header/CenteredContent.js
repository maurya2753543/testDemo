import React from 'react';
import './CenteredContent.css'; // Import your CSS styles
import { Link, useNavigate } from 'react-router-dom';

const CenteredContent = () => {
  return (
    <div className="centered-container">
      <div className="qubely-column-inner">
        <div style={{ height: '100px' }} aria-hidden="true" className="wp-block-spacer"></div>
        <div style={{ height: '100px' }} aria-hidden="true" className="wp-block-spacer"></div>
        
        <h1 className="has-text-align-center has-white-color has-text-color" style={{ fontSize: '18px' , color : '#ffff' }} >
        Ignite Your Child's Full Potential With Chanakya Programs
        </h1>

        <div className="wp-block-qubely-heading qubely-block-eecf43">
          <div className="qubely-block-heading">
            <div className="qubely-heading-container">
              <h1 className="qubely-heading-selector" style={{ fontSize: '50px' }}>
                India’s Best After-School Programs
              </h1>
            </div>
          </div>
        </div>

        <div className="wp-block-qubely-button qubely-block-2615c4">
          <div className="qubely-block-btn-wrapper">
            <div className="qubely-block-btn">
              <Link
                className="qubely-block-btn-anchor is-large"
                to="/book-classes"                
                target="_blank"
                rel="noopener noreferrer"
              >
                Book a Free Demo Class
              </Link>
            </div>
          </div>
        </div>

        <p></p>
      </div>
    </div>
  );
};

export default CenteredContent;
