import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

import './NavBar.css'; // Import your custom styles
import StickyButton from './StickyButton';
import LoginPopup from './LoginPopup';
import styled from 'styled-components';
import SignUp from './Registration';
import Footer from '../footer/Footer'; // Import the Footer component
import CenteredContent from './CenteredContent';
import TopStudentsGallery from '../header/TopStudentsGallery';
import ShowNotification from './ShowNotification';
import Feedback from './Feedback';
import AppwriteService from '../appwrite/AppwriteService'; //
import logo from '../images/Designer-modified.png';

const NavbarWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 20px;
  background-color: #333;
  color: white;
`;
const SvgCurve = styled.svg`
  width: 100%;
  height: auto;
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: -1; /* Ensure it stays behind other elements */
`;
const ProfileIcon = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background-color: red;
  color: white;
  font-weight: bold;
  border-radius: 50%;
  cursor: pointer;
  font-size: 16px; /* Adjusted font size */
  text-transform: uppercase;
`;

const DropdownMenu = styled.div`
  position: absolute;
  top: 60px;
  right: 40px;
  width: 200px;
  background-color: white;
  color: black;
  border-radius: 3px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  display: ${(props) => (props.show ? 'block' : 'none')};
  z-index: 10;

  div {
    padding: 9px 30px;
    cursor: pointer;

    &:hover {
      background-color: rgba(0, 0, 0, 0.05);
    }
  }
`;
const NavBar = () => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const openLogin = () => setIsLoginOpen(true);
  const closeLogin = () => setIsLoginOpen(false);
  const openSignUpModal = () => setIsSignUpOpen(true);
  const closeSignUpModal = () => setIsSignUpOpen(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [userProfile, setUserProfile] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phoneNumber: '',
    bio: '',
    registrationDate: ''
  });
  const [userInitials, setUserInitials] = useState(''); // State to store user initials
  const navigate = useNavigate();
  const toggleDropdown = () => setIsDropdownOpen((prev) => !prev);

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get(); // Fetch the current user's data

        const firstName = user.name.split(' ')[0] || ''; // Get first name from user.name
        const lastName = user.name.split(' ')[1] || ''; // Get last name from user.name

        setUserProfile({
          registrationDate: new Date(user.$createdAt).toLocaleString(),
          firstName,
          lastName,
          username: user.prefs?.username || '', // Optional username from preferences
          email: user.email || '',
          phoneNumber: user.prefs?.phoneNumber || 'Not Provided', // Optional phone number from preferences
          bio: user.prefs?.bio || 'Not Provided' // Optional bio from preferences
        });

        // Combine initials
        const initials = `${firstName.charAt(0).toUpperCase()}${lastName.charAt(0).toUpperCase()}`;
        setUserInitials(initials); // Set the initials for display in the profile icon

      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  
  const handleLogout = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.logout();
      navigate('/'); // Redirect to homepage after logout
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };
  const handleNavigation = async () => {


  }

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const appwriteService = new AppwriteService(); // Create an instance of AppwriteService

   // Check for session when component loads
   useEffect(() => {
    const checkSession = async () => {
      try {
        const currentUser = await appwriteService.account.get();
        if (currentUser) {
          setIsLoggedIn(true); // If session exists, set isLoggedIn to true
        }
      } catch (error) {
        console.log("No active session found, showing login page");
        setIsLoggedIn(false); // No session, show login
      }
    };
    checkSession();
  }, []);

  return (
    <>
    <div className="Main-section">

      <header id="masthead" className="site-header header-transparent disable-sticky">
        <div className="container-fluid">
          <div className="navbar-row1 d-flex align-items-center justify-content-between">
            {/* Logo Section */}
            <div className="logo-wrapper">
              <Link className="skillate-navbar-brand" to="/">
              <img
        className="enter-logo img-responsive"
        src={logo}
        alt="Logo"
        title="Logo"
      />
              </Link>
            </div>


            {/* Connect and Dashboard Menu (Centered) */}
            <div className="menu-center">
              <ul id="menu-main-menu" className="nav">
                <li className="menu-item">
                  <Link to="/about-us">ABOUT US</Link>
                </li>
                <li className="menu-item">
                  <Link to="/dashboard">DASHBOARD</Link>
                </li>
              </ul>
            </div>

            {/* Cart, Login, Sign Up (Right Aligned) */}
            <div className="d-flex align-items-center right-section">
              {/* Cart */}
              <div className="skillate-header-cart mr-lg-2 d-none d-lg-inline-block">
                <div id="site-header-cart" className="site-header-cart menu">
                  <span className="cart-icon">
                    <img
                      src="https://www.profved.com/wp-content/themes/skillate/images/cart-icon.svg"
                      alt="Cart Icon"
                    />
                    <a className="cart-contents" href="#modal-cart" title="View your shopping cart">
                      <span className="count">0</span>
                    </a>
                  </span>
                </div>
              </div>

              {isLoggedIn ? (
        <> 
           <div className="d-flex align-items-center right-section">
              {/* Profile Icon showing initials */}
              <ProfileIcon onClick={toggleDropdown}>
                {userInitials} {/* Display user initials here */}
              </ProfileIcon>

              <DropdownMenu show={isDropdownOpen}>
                <div onClick={() => handleNavigation('profile')}>My Profile</div>
                <div onClick={() => handleNavigation('enrolled-courses')}>Enrolled Courses</div>
                <div onClick={() => handleNavigation('wishlist')}>Wishlist</div>
                <div onClick={() => handleNavigation('reviews')}>Reviews</div>
                <div onClick={() => handleNavigation('my-quiz-attempts')}>My Quiz Attempts</div>
                <div onClick={() => handleNavigation('purchase-history')}>Purchase History</div>
                <div onClick={() => handleNavigation('settings')}>Settings</div>
                <div onClick={handleLogout}>Logout</div> {/* Logout Button */}
              </DropdownMenu>
            </div>

        </>
      ) : (
        <div>
          {/* <DashboardContent /> */}
          <div className="skillate-header-login ml-4">
                <div className="header-login-wrap">
                  <a href="#!" onClick={openLogin}>Login</a>
                  <span className='line_spe'>|</span>
                  <a href="#!" onClick={openSignUpModal} className="ml-3">Sign Up</a>
                </div>
              </div>
          </div>

        
      )}       

    

              {/* Login and Sign Up */}
             
            </div>
          </div>
       
        </div>
       
        <div className="ShowNotification">
        <ShowNotification />
 
        </div>

      </header>

      <CenteredContent />

      </div>

      {/* Conditionally render StickyButton based on isLoginOpen and isSignUpOpen */}
      {!isLoginOpen && !isSignUpOpen && <StickyButton />}

      <LoginPopup isOpen={isLoginOpen} onClose={closeLogin} />
      <SignUp isOpen={isSignUpOpen} onClose={closeSignUpModal} />
       
     
      <div className="feedback">
        <Feedback />
      </div>
      <div className="Top-galary">

      <TopStudentsGallery/>

      </div>

      <Footer /> {/* Add the Footer here */}
    </>
  );
};

export default NavBar;
