// src/appwrite/ProfileService.js
import { ID, Account, Client, Storage, Databases } from 'appwrite';

// Initialize Appwrite Client
const appwriteClient = new Client();

class ProfileService {
    account;
    storage;
    databases;

    constructor() {
        const endpoint = "https://cloud.appwrite.io/v1"; // Replace with your actual endpoint
        const projectId = "66fb8c0f0024c89bdea5"; // Replace with your actual project ID
        appwriteClient
            .setEndpoint(endpoint)
            .setProject(projectId);

        this.account = new Account(appwriteClient);
        this.storage = new Storage(appwriteClient); // Initialize storage for file uploads
        this.databases = new Databases(appwriteClient); // Initialize the Databases service
        console.log( this.databases ," this.databases")
        console.log(  this.storage ," this.databases")

    }

    // Save question to database
    async addQuestion(questionData) {
        try {
            const user = await this.account.get(); // Ensure the user is authenticated
            console.log(  user ," user")

           // if (!user) throw new Error('User not authenticated.');
    
            const response = await this.databases.createDocument(
                '671cb38600053ecae112', // Database ID
                '671cb38600053ecae112', // Collection ID
                ID.unique(), // Automatically generate a unique ID
                questionData // Document data
            );
            console.log('Question added:', response);
            return response;
        } catch (error) {
            console.error("Appwrite service :: addQuestion() :: ", error);
            throw error;
        }
    }
    
}

export default ProfileService;
