import { ID, Account, Client ,Databases } from 'appwrite';

// Initialize Appwrite Client
const appwriteClient = new Client();
const databases = new Databases(appwriteClient);

class AppwriteService {
    account;

    constructor() {
        const endpoint = "https://cloud.appwrite.io/v1"; // Replace with your actual endpoint
        const projectId = "66fb8c0f0024c89bdea5"; // Replace with your actual project ID
        appwriteClient
            .setEndpoint(endpoint)
            .setProject(projectId);

        this.account = new Account(appwriteClient);
        this.databases = new Databases(this.client);


    }



    async createDocument() {
        try {
          const result = await this.databases.createDocument(
            '67066720002ca9f5fdd8', // Replace with your database ID
            '671c9690000de24c7e8f', // Replace with your collection ID
            ID.unique(), // Generates a unique ID for the document
            {
              title: 'I am title',
              desc: 'I am desc'
            }
          );
          console.log('Document created successfully:', result);
          return result;
        } catch (error) {
          console.error('Error creating document:', error);
          throw error;
        }
      }
   // Function to save form data to Appwrite
  // Function to save form data to Appwrite
 // Function to save form data to Appwrite
async saveFormData(formData) {
    try {
        // Create a new document in the specified database and collection
        const response = await databases.createDocument(
            '67066720002ca9f5fdd8', // Replace with the actual database ID
            '67162f90001580581b79', // Replace with the actual collection ID
            ID.unique(), // Generate a unique document ID
            formData // The data to be saved in the document
        );

        console.log('Document created successfully:', response);
        return response; // Return the response for further handling
    } catch (error) {
        // Log the error and provide a user-friendly message
        console.error('Failed to create document:', error);
        
        // Check for specific error codes for more granular handling if needed
        if (error.code === 401) {
            throw new Error('Unauthorized: Please log in before saving data.');
        } else if (error.code === 404) {
            throw new Error('Database or collection not found.');
        } else {
            throw new Error('An error occurred while saving data: ' + error.message);
        }
    }
}


 

    // Create a new account
    async createAccount({ email, password, name }) {
        try {
            const userAccount = await this.account.create(ID.unique(), email, password, name);
            console.log('User account created:', userAccount);
            // Automatically log in the user after registration
            return this.login({ email, password });
        } catch (error) {
            console.error("Appwrite service :: createAccount() :: ", error);
            throw error;
        }
    }

    async login({ email, password }) {
        try {
            // Check if a session already exists
            const currentUser = await this.account.get();
            if (currentUser) {
                console.log("User is already logged in:", currentUser);
                return currentUser;
            }
        } catch (error) {
            // If no active session, the account.get() will throw an error
            // We can safely ignore the error if it's a "no session found" type
            if (error.response && error.response.code !== 401) {
                console.error("Error checking current session:", error);
                throw error;
            }
        }
    
        // No session exists, create a new session
        try {
            const session = await this.account.createEmailPasswordSession(email, password);
            console.log('Login successful:', session);
            return session;
        } catch (error) {
            console.error("Appwrite service :: login() :: ", error);
            throw error;
        }
    }
    

    // Log out
    async logout() {
        try {
            return await this.account.deleteSession('current');
        } catch (error) {
            console.error("Appwrite service :: logout() :: ", error);
        }
    }
    // get session 
    // Get current session
  async getSession() {
    try {
      const currentUser = await this.account.get();
      return currentUser;
    } catch (error) {
      console.error("No active session found:", error);
      throw error;
    }
  }

    // Send password recovery email
    async sendPasswordRecovery(email) {
        try {
            const response = await this.account.createRecovery(email, 'https://your-app.com/reset-password');
            console.log('Recovery email sent:', response);
            return response;
        } catch (error) {
            console.error("Appwrite service :: sendPasswordRecovery() :: ", error);
            throw error;
        }
    }

    // Complete password recovery
    async completePasswordRecovery(userId, secret, newPassword) {
        try {
            const response = await this.account.updateRecovery(userId, secret, newPassword, newPassword);
            console.log('Password updated successfully:', response);
            return response;
        } catch (error) {
            console.error("Appwrite service :: completePasswordRecovery() :: ", error);
            throw error;
        }
    }

    async updatePassword(oldPassword, newPassword) {
        try {
            // Check for existing session first
            const currentUser = await this.account.get(); // This will throw an error if not logged in
            // If there’s an active session, try to update the password
            const response = await this.account.updatePassword(newPassword); // Using the current session to update password
            console.log('Password updated successfully:', response);
            return response;
        } catch (error) {
            // If the error is due to invalid credentials
            if (error.code === 401) {
                console.error("Invalid credentials. Please check the email and password.", error);
                throw new Error("Invalid credentials. Please check the email and password.");
            } else {
                console.error("Appwrite service :: updatePassword() :: ", error);
                throw error; // Re-throw other errors for handling in the form component
            }
        }
    }
    
    
}

export default AppwriteService;
