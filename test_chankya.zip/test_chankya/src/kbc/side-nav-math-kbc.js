import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBookOpen, faCheckCircle, faCircle, faHome } from '@fortawesome/free-solid-svg-icons';
import { faYoutube } from '@fortawesome/free-brands-svg-icons';
import { Link, useNavigate } from 'react-router-dom';
import DashboardPopup from '../math-genius/DashboardPopup'; // Import the DashboardPopup component
import "./side-nav-math-kbc.css";
import QuizCalculatorMultiChoice from './QuizCalculatorMultiChoice';
import QuizCalculatorMugal from './QuizCalculatorMugal';
import ModernHistory from './ModernHistory';
import FamousScientists from './FamousScientists';
import GeographyKbc from './GeographyKbc'
function AppSideNavKBC() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSection, setExpandedSection] = useState(null); // Track expanded section
  const [completedCourses, setCompletedCourses] = useState(["0-0"]); // Track completed courses, including the first one by default

  const navigate = useNavigate();

  const [activeContent, setActiveContent] = useState({
    sectionIndex: 0,
    contentIndex: 0,
    title: "Ancient Indian History - Harappan Civilization (KBC 2000)",
    icon: faYoutube,
    video: "",
  });
  //const [completedCourses, setCompletedCourses] = useState([]); // Track completed courses
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const handlePopupOpen = () => {
    setIsPopupOpen(true); // Open popup
  };

  const handlePopupClose = () => {
    setIsPopupOpen(false); // Close popup
  };

  const handleConfirmNavigation = async () => {
    handlePopupClose(); // Close the popup
    try {
      navigate('/dashboard'); // Redirect to dashboard
    } catch (error) {
      console.error("Error navigating to dashboard:", error);
    }
  };

  const sections = [
    {
      title: "Historical and Cultural Activities && Current Affairs and Science Activitie",
      content: [
        { label: "Ancient Indian History - Harappan Civilization (KBC 2000)", video: "", icon: faYoutube },          
        { label: "Mughal Emperors and their Contributions (KBC 2001)", video: "", icon: faYoutube },          
        { label: "Modern History - Indian Independence Movement (KBC 2002)", video: "", icon: faYoutube },          
        { label: "Famous Scientists and their Inventions (KBC 2003)", video: "", icon: faYoutube },          
        { label: "Geography: Indian States and their Capitals (KBC 2004)", video: "", icon: faYoutube },          

        

      ]
    },
    {
      title: "KBC Pre Level 2",
      content: [
        { label: "Content 2A", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Content 2B", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
      ]
    },
    {
      title: "KBC Pre Level 3",
      content: [
        { label: "Content 3A", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Content 3B", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
      ]
    }
  ];

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleContentClick = (sectionIndex, contentIndex, content) => {
    setActiveContent({
      sectionIndex,
      contentIndex,
      title: content.label,
      icon: content.icon,
      video: content.video,
    });

    if (!completedCourses.includes(`${sectionIndex}-${contentIndex}`)) {
      setCompletedCourses([...completedCourses, `${sectionIndex}-${contentIndex}`]);
    }
  };

  return (
    <> 
     <div className="app-container">
      <div className={`sidebar-math ${isExpanded ? "expanded" : "collapsed"}`}>
        <div className="tutor-tabs-btn-group">
          <a href="#tutor-lesson-sidebar-tab-content">
            <FontAwesomeIcon style={{ color: '#ff5248' }} icon={faBookOpen} />
            <span className="Lesson-title"> Lesson List</span>
          </a>
        </div>

        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="section">
            <div className="section-title" onClick={() => toggleSection(sectionIndex)}>
              <FontAwesomeIcon /> {section.title} <span className="expend-icon-penal"> {expandedSection === sectionIndex ? "-" : "+"} </span>
            </div>
            {expandedSection === sectionIndex && (
              <div className="section-content tutor-lessons-under-topic">
                <ul>
                  {section.content.map((item, contentIndex) => (
                    <li
                      key={contentIndex}
                      className={`content-item ${activeContent.sectionIndex === sectionIndex && activeContent.contentIndex === contentIndex ? "active-content" : ""}`}
                    >
                      <a href="#!" onClick={() => handleContentClick(sectionIndex, contentIndex, item)} className="content-link">
                        <div className="content-info">
                          <div className="content-left">
                            <FontAwesomeIcon icon={item.icon} style={{ marginRight: "8px" }} />
                            <span>{item.label}</span>
                          </div>
                          <div className="content-right">
                            <span className="content-timing">120:M</span>
                            <FontAwesomeIcon
                              icon={completedCourses.includes(`${sectionIndex}-${contentIndex}`) ? faCheckCircle : faCircle}
                              className="completion-icon"
                            />
                          </div>
                        </div>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="content-side-bar">
        <div className="video-player-header">
          <button className="toggle-btn" onClick={toggleSidebar}>
            {isExpanded ? ">" : "<"}
          </button>
          {/* Home Icon and Go to Home Message */}
          <span  onClick={handlePopupOpen} className="go-home">
            <FontAwesomeIcon icon={faHome} />  Go to Course Dashboard
          </span>
          <span className="header-title-side-bar">
            <h3><FontAwesomeIcon icon={activeContent.icon} /> {activeContent.title}</h3>
          </span>
        </div>
        {/* <video src={activeContent.video} controls width="100%" autoPlay /> */}
        
        {/* Conditionally show QuizCalculatorMulti if "The Beauty of 11" is selected */}
        {activeContent.title === "Ancient Indian History - Harappan Civilization (KBC 2000)" && <QuizCalculatorMultiChoice />}
        {activeContent.title === "Mughal Emperors and their Contributions (KBC 2001)" && <QuizCalculatorMugal />}
        {activeContent.title === "Modern History - Indian Independence Movement (KBC 2002)" && <ModernHistory />}
        {activeContent.title === "Famous Scientists and their Inventions (KBC 2003)" && <FamousScientists/>}
        {activeContent.title === "Geography: Indian States and their Capitals (KBC 2004)" && <GeographyKbc/>}

       
       
       
        
      </div>

    </div>
     {/* Render Popup if it's open */}
     {isPopupOpen && (
            <DashboardPopup 
              onClose={handlePopupClose} 
              onConfirm={handleConfirmNavigation} 
            />
          )}

  </>
   
  );
}

export default AppSideNavKBC;
