import React from 'react';
import KbcHeader from './KbcHeader';
import Dashboard_Header from '../comman-header/Dashbord-header';
const KBCGenius = () => {
  return (
    <div>
      <Dashboard_Header />
     <KbcHeader />
    </div>
  );
};

export default KBCGenius;
