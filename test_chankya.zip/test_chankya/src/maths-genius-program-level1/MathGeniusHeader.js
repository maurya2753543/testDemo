import React from 'react';
import './MathGeniusHeader.css'; // Import your CSS file for styling
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import QuizCalTableContent from '../math-genius/QuizCalTableContent';


const MathGeniusHeader = () => {
    const navigate = useNavigate();

    const handleNavigationcourse = () => {
        navigate(`/lesson/maths-chanakya-class-2-to-5/`);        
      };

  return (
    <>
    <div className="main-container-math">
    <div className="container course-single-title-top">
      <div className="row">
        <div className="col-md-8">
          <h1 className="tutor-course-header-h1">Maths Program (2- 5 class) CBSE</h1>
          <h1 className="tutor-course-header-h1"> Numbers: Addition, subtraction, and mental arithmetic</h1>
         
        </div>
      </div>
      <div className="row mt-3">
        {/* Column for Course Level */}
        <div className="col text-center">
          <p className="color-math">Novice to Master Course Level</p>
          <h3 className="m-0">Low - Intermediate -  High</h3>
        </div>
        {/* Column for Video Tutorials */}
        <div className="col text-center1">
          <span className="color-math">Video Tutorials</span>
          <h3 className="m-0">351</h3>
        </div>
        {/* Column for Continue to Lesson Button */}
        <div className="col ">
          <button  onClick={() => handleNavigationcourse()} className="btn btn-custom">CONTINUE TO LESSON</button> <br />        

          <span  className="text_complate color-math">Complete all lessons to <br /> mark this course as complete.</span>

        </div>
     
      </div>
    </div>
    </div>
    <div style={{marginLeft: '30px'}}>
        <QuizCalTableContent />
      </div>
   
    </>
   
  );
};

export default MathGeniusHeader;
