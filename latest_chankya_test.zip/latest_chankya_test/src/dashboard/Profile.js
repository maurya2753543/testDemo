import React, { useState, useEffect } from 'react'; 
import styled from 'styled-components';
import AppwriteService from '../appwrite/AppwriteService'; // Import the AppwriteService

// Styled components
const ProfileContainer = styled.div`
  padding: 0px;  
  margin-left : 16px;
`;

const ProfileTitle = styled.h3`
  margin-bottom: 10px;
  color: #333; /* Darker color for the title */
`;

const ProfileContent = styled.div`
  display: flex;
  flex-direction: column; /* Stack items in a single column */
`;

const ProfileItem = styled.div`
  padding: 5px;
  box-sizing: border-box;

  .heading {
    font-weight: bold;
    margin-bottom: 5px;
    color: #555; /* Darker color for the headings */
  }

  .content {
    padding: 5px;
    p {
      margin: 0;
      color: #333; /* Dark color for the content text */
    }
  }
`;

const Profile = () => {
  // State to store user profile data
  const [userProfile, setUserProfile] = useState({
    registrationDate: '',
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phoneNumber: '',
    bio: ''
  });

  // Fetch user profile data from AppwriteService
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get(); // Fetch the current user's data
        setUserProfile({
          registrationDate: new Date(user.$createdAt).toLocaleString(), // Convert registration date to readable format
          firstName: user.name.split(' ')[0] || '', // Assuming first name is the first part of the name field
          lastName: user.name.split(' ')[1] || '', // Assuming last name is the second part
          username: user.prefs.username || '', // Assuming username is stored in user preferences
          email: user.email || '',
          phoneNumber: user.prefs.phoneNumber || 'Not Provided', // Assuming phone number is stored in preferences
          bio: user.prefs.bio || 'Not Provided' // Assuming bio is stored in preferences
        });
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []); // Empty dependency array ensures it only runs once when the component mounts

  return (
    <ProfileContainer>
      <ProfileTitle>My Profile</ProfileTitle>
      <ProfileContent>
        <ProfileItem>
          <div className="heading">Registration Date</div>
          <div className="content">
            <p>{userProfile.registrationDate}</p>
          </div>
        </ProfileItem>
        <ProfileItem>
          <div className="heading">First Name</div>
          <div className="content">
            <p>{userProfile.firstName}</p>
          </div>
        </ProfileItem>
        <ProfileItem>
          <div className="heading">Last Name</div>
          <div className="content">
            <p>{userProfile.lastName}</p>
          </div>
        </ProfileItem>
        <ProfileItem>
          <div className="heading">Username</div>
          <div className="content">
            <p>{userProfile.username}</p>
          </div>
        </ProfileItem>
        <ProfileItem>
          <div className="heading">Email</div>
          <div className="content">
            <p>{userProfile.email}</p>
          </div>
        </ProfileItem>
       
      </ProfileContent>
    </ProfileContainer>
  );
};

export default Profile;
