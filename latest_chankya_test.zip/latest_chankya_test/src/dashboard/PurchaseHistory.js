import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Chanakya_all_student from '../images/Chanakya_all_student.jpeg';
import Dashboard_Header from '../comman-header/Dashbord-header';
import AppwriteService from '../appwrite/AppwriteService'; 
import Header from '../comman-header/Header';
import { FaTimes } from 'react-icons/fa'; 
import storageService from '../appwrite/storageService'; 

const PaymentHistory = ({ onNavigate }) => {
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState({
    registrationDate: '',
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phoneNumber: '',
    bio: '',
  });

  const handleClose = () => {
    navigate('/dashboard'); 
  };

  const [paymentDetails, setPaymentDetails] = useState(null);
  const appwriteService = new AppwriteService(); 

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const user = await appwriteService.account.get(); 

        setUserProfile({
          registrationDate: new Date(user.$createdAt).toLocaleString(),
          firstName: user.name.split(' ')[0] || '', 
          lastName: user.name.split(' ')[1] || '',  
          username: user.prefs.username || '', 
          email: user.email || '', 
          phoneNumber: user.prefs.phoneNumber || 'Not Provided', 
          bio: user.prefs.bio || 'Not Provided', 
        });

        console.log("User Data:", user);
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []); 

  useEffect(() => {
    const storedPaymentDetails = storageService.getFromLocalStorage('paymentDetails'); 
    if (storedPaymentDetails) {
      console.log('Payment Details:', storedPaymentDetails);
      setPaymentDetails(storedPaymentDetails);
    } else {
      console.log('No payment details found in local storage.');
    }
  }, []);

  return (
    <>
      <div className="payment-success-container">
      
      

        {paymentDetails ? (
          <div className="payment-details-card" style={cardStyle}>
            <h2 style={{ textAlign: 'center' }}>Purchase History</h2>
            <div style={cardContentStyle}>
              <div className="payment-detail-row">
                <span className="detail-label">Name:</span>
                <span className="detail-value">{userProfile.firstName} {userProfile.lastName}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Email:</span>
                <span className="detail-value">{userProfile.email}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Course Name:</span>
                <span className="detail-value">{paymentDetails.name}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Course Title:</span>
                <span className="detail-value">{paymentDetails.Title}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Amount:</span>
                <span className="detail-value">{(paymentDetails.amount).toFixed(2)} Rs.</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Currency:</span>
                <span className="detail-value">{paymentDetails.currency}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Status:</span>
                <span className="detail-value">{paymentDetails.status}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Date & Time:</span>
                <span className="detail-value">{paymentDetails.time}</span>
              </div>
              <div className="payment-detail-row">
                <span className="detail-label">Transaction ID:</span>
                <span className="detail-value">{paymentDetails.paymentId}</span>
              </div>
            </div>
          </div>
        ) : (
          <p style={{ textAlign: 'center', marginTop: '20px' }}>No payment details available.</p>
        )}
      </div>
    </>
  );
};

// CSS Styles
const cardStyle = {
  width: '80%',
  margin: '20px auto',
  padding: '20px',
  borderRadius: '10px',
  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
  backgroundColor: '#ffffff',
};

const cardContentStyle = {
  display: 'flex',
  flexDirection: 'column',
  borderTop: '1px solid #eee',
  paddingTop: '10px',
};

export default PaymentHistory;
