import React, { useState } from 'react';
import './MyProfileLogin.css';
import { Link, useNavigate } from 'react-router-dom';
import AppwriteService from '../appwrite/AppwriteService'; // Ensure this path is correct
import ClipLoader from "react-spinners/ClipLoader"; // Import the loader
import LoginPopup from '../header/LoginPopup';
import ForgetPassword from '../header/ForgetPassword';
import styled from 'styled-components';
import SignUp from '../header/Registration';
import StickyButton from '../header/StickyButton';
import { ToastContainer, toast } from 'react-toastify';


const MyProfileLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false); // State for loader
  const navigate = useNavigate();
  const openLogin = () => setIsLoginOpen(true);
  const closeLogin = () => setIsLoginOpen(false);
  const openSignUpModal = () => setIsSignUpOpen(true);
  const openForgetPasswordModal = () => setIsForgetPasswordUpOpen(true);
  const closeForgetPasswordModal = () => setIsForgetPasswordUpOpen(false);

  const handleModalClose = () => {
    openForgetPasswordModal(false);
  };

  const closeSignUpModal = () => setIsSignUpOpen(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isForgetPasswordOpen, setIsForgetPasswordUpOpen] = useState(false);


  // Initialize the Appwrite service
  const appwriteService = new AppwriteService();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true); // Show loader

    try {
      const session = await appwriteService.login({ email, password });

      // session.createVerification("http://localhost:3000/home");
 
      // toast.success("Verification email has been sent!");
      if (session) {
        // console.log('User logged in successfully:', session);
        setLoading(false); // Hide loader

        setErrorMessage('');
        navigate('/dashboard/user'); // Redirect to dashboard after successful login
      }
    } catch (error) {
      console.error('Error during login:', error);
      setErrorMessage('Login failed. Please check your credentials.');
      setLoading(false); // Hide loader after error

    }
  };

  return (
    <div className="tutor-wrap tutor-page-wrap post-5 page type-page status-publish hentry">
      <div className="tutor-template-segment tutor-login-wrap">
        <div className="tutor-login-title">
          <h4>Please Sign-In to view this section</h4>
        </div>
        <div className="loader-container">
                <ClipLoader color={"#36d7b7"} loading={loading} size={50} />
              </div>
        {errorMessage && <p style={{ color: 'red', textAlign: 'center' }}>{errorMessage}</p>} {/* Error message display */}

        <div className="tutor-template-login-form">
          <div className="tutor-login-form-wrap">
            <form name="loginform" id="loginform" method="post" onSubmit={handleSubmit}>
              <p className="login-username">
                <input
                  type="text"
                  placeholder="Email Address"
                  name="log"
                  id="user_login"
                  className="input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <p className="login-password">
                <input
                  type="password"
                  placeholder="Password"
                  name="pwd"
                  id="user_pass"
                  className="input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  size="20"
                  required
                />
              </p>

              <div className="tutor-login-remember-wrap">
                <p className="login-remember">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label htmlFor="rememberme">Remember Me</label>
                  <Link  href="#!" onClick={openForgetPasswordModal}  className="forgot-password-link">
                    Forgot Password?
                  </Link>
                </p>
              </div>

              <p className="login-submit">
                <input type="submit" name="wp-submit" id="wp-submit" className="tutor-button1" value="Log In" />
                <input type="hidden" name="redirect_to" value="" />
              </p>

              <p className="tutor-form-register-wrap">
                <Link   href="#!" onClick={openSignUpModal} >Create a new account</Link>
              </p>
            </form>
          </div>
        </div>
      </div>
      {!isLoginOpen && !isSignUpOpen && <StickyButton />}
      <LoginPopup isOpen={isLoginOpen} onClose={closeLogin} />
      <SignUp isOpen={isSignUpOpen} onClose={closeSignUpModal} />
      <ForgetPassword isOpen={isForgetPasswordOpen} onClose={closeForgetPasswordModal}  />
    </div>
  );
};

export default MyProfileLogin;
