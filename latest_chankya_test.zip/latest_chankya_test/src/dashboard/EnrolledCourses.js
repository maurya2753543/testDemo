import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import kbc from '../images/kbc-prep.jpeg';
import class2to5 from '../images/grad2-5.png';
import AppwriteService from '../appwrite/AppwriteService'; // Import AppwriteService
import storageService from '../appwrite/storageService'; // Import your storage service

const EnrollCourseContainer = styled.div`
  padding: 20px;
`;

const CourseTitle = styled.h3`
  margin-bottom: 20px;
  color: #333;
`;

const DropdownContainer = styled.div`
  margin-bottom: 20px;
`;

const TabContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 20px;
  position: relative;

  ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;

    li {
      margin-right: 20px;

      a {
        text-decoration: none;
        padding: 10px 15px;
        color: black;
        border-radius: 5px;

        &.active {
          color: #ff5248;
          border-bottom: 2px solid;
        }
      }
    }
  }

  &::after {
    content: '';
    display: block;
    height: 2px;
    background-color: black;
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: -1;
  }
`;

const CourseCard = styled.div`
  display: flex;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 20px;
  cursor: pointer;
`;

const CourseThumbnail = styled.div`
  width: 50%;
  height: 200px;
  background-image: url(${(props) => props.img});
  background-size: cover;
  background-position: center;
`;

const CourseContent = styled.div`
  width: 50%;
  padding: 20px;
  display: flex;
  flex-direction: column;
`;

const ProgressBar = styled.div`
  background-color: #e0e0e0;
  border-radius: 5px;
  height: 5px;
  position: relative;

  .progress-filled {
    background-color: #ff5248;
    height: 100%;
    border-radius: 5px;
  }
`;

const WishlistButton = styled.button`
  background-color: #ff5248; /* Red background */
  color: white; /* White text */
  padding: 10px 20px; /* Vertical and horizontal padding */
  border: none; /* Remove default border */
  border-radius: 5px; /* Rounded corners */
  cursor: pointer; /* Change cursor on hover */
  margin: 10px 0; /* Margin for spacing */
  font-size: 16px; /* Font size */
  transition: background-color 0.3s; /* Smooth background transition */

  &:hover {
    background-color: #6f8cea; /* Darker red on hover */
  }
`;

const coursesData = {
  '2-10': [
    {
      title: "Maths Genius Level 2-10",
      totalLessons: 50,
      completedLessons: 25,
      progress: 50,
      thumbnail: class2to5,
    }
  ],
 
  'KBC': [
    {
      title: "KBC Genius Level Quiz",
      totalLessons: 100,
      completedLessons: 60,
      progress: 60,
      thumbnail: kbc,
    }
  ],
};

const EnrollCourse = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('allCourses');
  const [selectedGrade, setSelectedGrade] = useState('');
  const [showDemoMessage, setShowDemoMessage] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paymentDetails, setPaymentDetails] = useState(null);
  const [courseValidityMessage, setCourseValidityMessage] = useState('');

  const navigate = useNavigate();

  // useEffect(() => {
  //   const storedPaymentDetails = storageService.getFromLocalStorage('paymentDetails'); // Adjust the key as needed
  //   console.log(storedPaymentDetails, "storedPaymentDetails");

  //   // Check if the user has enrolled in the demo class and whether to show the message
  //   if (storedPaymentDetails) {
  //     setPaymentDetails(storedPaymentDetails);
  //     const paymentDate = new Date(storedPaymentDetails.time);
  //     const today = new Date();
  //     const diffDays = Math.floor((today - paymentDate) / (1000 * 60 * 60 * 24));

  //     // Show demo message if the user has been registered for 3 days
  //     if (diffDays >= 3) {
  //       setShowDemoMessage(true);
  //     }

  //     // Calculate course validity based on amount
  //     let validUntil = null;

  //     if (storedPaymentDetails.amount === 999) {
  //       validUntil = new Date(paymentDate);
  //       validUntil.setFullYear(validUntil.getFullYear() + 1); // Valid for 1 year
  //     } else if (storedPaymentDetails.amount === 99) {
  //       validUntil = new Date(paymentDate);
  //       validUntil.setMonth(validUntil.getMonth() + 1); // Valid for 1 month
  //     }

  //     // Check if the course is still valid
  //     if (validUntil && today <= validUntil) {
  //       setCourseValidityMessage(`Access valid until ${validUntil.toDateString()}`);
  //     } else {
  //       setCourseValidityMessage('Your course access has expired. Please renew.');
  //     }

  //     // Log the payment details
  //     console.log(`Payment ID: ${storedPaymentDetails.paymentId}`);
  //     console.log(`Title: ${storedPaymentDetails.title}`);
  //     console.log(`Amount: ₹${storedPaymentDetails.amount}`);
  //     console.log(`Payment Status: ${storedPaymentDetails.status}`);
  //   }
  // }, []);

  // Fetch user registration details
  // useEffect(() => {
  //   const fetchUserProfile = async () => {
  //     try {
  //       const appwriteService = new AppwriteService();
  //       const userData = await appwriteService.account.get();

  //       setUser(userData);
  //       const registrationDate = new Date(userData.registration);
  //       const today = new Date();
  //       const diffDays = Math.floor((today - registrationDate) / (1000 * 60 * 60 * 24));

  //       if (diffDays >= 3) {
  //         setShowDemoMessage(true);
  //       }
  //     } catch (error) {
  //       console.error("Failed to fetch user profile", error);
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   fetchUserProfile();
  // }, []);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const handleCourseClick = (course) => {
    if (selectedGrade) {
      navigate(`/courses/${course.title.replace(/\s+/g, '-').toLowerCase()}`); // Route to course page
    } else {
      alert("Please select a grade level before proceeding.");
    }
  };

  const handleGradeChange = (event) => {
    setSelectedGrade(event.target.value);
  };

  return (
    <>
      <EnrollCourseContainer>
        <CourseTitle>Enrolled Courses</CourseTitle>
        {showDemoMessage ? (
          <div>
            <CourseTitle>Thank you for participating in our demo class! To unlock the full course and continue your learning journey, please proceed with the payment.</CourseTitle>
            <WishlistButton onClick={onNavigate}>Add Course to Wishlist</WishlistButton>
          </div>
        ) : (
          <>
            {showDemoMessage && <p>{courseValidityMessage}</p>}

            <DropdownContainer>
              <label>Select Your Grade Level: </label>
              <select
                style={{ padding: "15px", marginTop: "10px" }}
                value={selectedGrade}
                onChange={handleGradeChange}
              >
                <option value="">-- Choose Your Grade --</option>
                <option value="2-10">Grade 2-10</option>
                <option value="KBC">KBC Prep</option>
              </select>
            </DropdownContainer>

            <TabContainer>
              <ul>
                <li>
                  <a
                    href="#"
                    className={activeTab === "allCourses" ? "active" : ""}
                    onClick={() => handleTabClick("allCourses")}
                  >
                    All Courses
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className={activeTab === "activeCourses" ? "active" : ""}
                    onClick={() => handleTabClick("activeCourses")}
                  >
                    Active Courses
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className={activeTab === "completedCourses" ? "active" : ""}
                    onClick={() => handleTabClick("completedCourses")}
                  >
                    Completed Courses
                  </a>
                </li>
              </ul>
            </TabContainer>

            {selectedGrade ? (
              coursesData[selectedGrade].map((course, index) => (
                <CourseCard key={index} onClick={() => handleCourseClick(course)}>
                  <CourseThumbnail img={course.thumbnail} />
                  <CourseContent>
                    <h3>{course.title}</h3>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span>Total Lessons: {course.totalLessons}</span>
                      <span>Completed Lessons: {course.completedLessons}</span>
                    </div>
                    <ProgressBar>
                      <div
                        className="progress-filled"
                        style={{ width: `${course.progress}%` }}
                      ></div>
                    </ProgressBar>
                  </CourseContent>
                </CourseCard>
              ))
            ) : (
              <p>Please select a grade level to view available courses.</p>
            )}
          </>
        )}
      </EnrollCourseContainer>
    </>
  );
};

export default EnrollCourse;
