import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import AppwriteService from '../appwrite/AppwriteService';
import { toast } from 'react-toastify';  // Import the toast function
import 'react-toastify/dist/ReactToastify.css';  // Import the styles for toast notifications

// Styled components
const FeedbackContainer = styled.div`
  padding: 20px;
  max-width: 800px;
  margin: auto;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
`;

const Button = styled.button`
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: ${(props) => (props.primary ? '#4caf50' : '#008cba')};
  color: white;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: ${(props) => (props.primary ? '#45a049' : '#007bb5')};
  }
`;

const Feedback = () => {
  const [formData, setFormData] = useState({
    comment: '',
    rating: '',
  });

  const databaseId = '671cb36f0034783418a7'; // Replace with your actual database ID
  const collectionId = '676fa97f0035e4e4e16d'; // Replace with your actual collection ID
  const documentId = 'unique_feedback_doc_id'; // Replace with a logic to manage user-specific documents

  // Handle form input change
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle save feedback
  const handleSave = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.databases.createDocument(
        databaseId,
        collectionId,
        documentId, // Make sure this is the correct ID or null if creating a new document
        {
          comment: formData.comment,
          rating: formData.rating,
        }
      );
      toast.success('Feedback saved successfully!');  // Show success toast
    } catch (error) {
      console.error('Error saving feedback:', error);
      toast.error('Failed to save feedback. Please try again.');  // Show error toast
    }
  };

  // Handle update feedback
  const handleUpdate = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.databases.updateDocument(
        databaseId,
        collectionId,
        documentId,
        formData
      );
      toast.success('Feedback updated successfully!');  // Show success toast
    } catch (error) {
      console.error('Error updating feedback:', error);
      toast.error('Failed to update feedback. Please try again.');  // Show error toast
    }
  };

  // Fetch the existing feedback when the component mounts
  useEffect(() => {
    const fetchFeedback = async () => {
      try {
        const appwriteService = new AppwriteService();
        const document = await appwriteService.databases.getDocument(
          databaseId,
          collectionId,
          documentId
        );
        setFormData({
          comment: document.comment || '',
          rating: document.rating || '',
        });
      } catch (error) {
        console.error('Error fetching feedback:', error);
      }
    };

    fetchFeedback();
  }, []);

  return (
    <FeedbackContainer>
      <h3>Feedback Form</h3>
      <form>
        <FormGroup>
          <label style={{ paddingLeft: '20px' }}>Feedback Text</label>
          <textarea
            name="comment"
            style={{ width: '60%', padding: '15px', marginLeft: '100px', height: '100px' }}
            value={formData.comment}
            onChange={handleInputChange}
            placeholder="Write your feedback..."
          ></textarea>
        </FormGroup>

        <FormGroup>
          <label style={{ paddingLeft: '20px' }}>Rating (1-5)</label>
          <select
            name="rating"
            style={{ width: '50%', padding: '15px', marginLeft: '100px' }}
            value={formData.rating}
            onChange={handleInputChange}
          >
            <option value="0">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
        </FormGroup>

        <ButtonGroup>
          <Button type="button" primary onClick={handleSave}>
            Save Feedback
          </Button>
          <Button type="button" onClick={handleUpdate}>
            Update Feedback
          </Button>
        </ButtonGroup>
      </form>
    </FeedbackContainer>
  );
};

export default Feedback;
