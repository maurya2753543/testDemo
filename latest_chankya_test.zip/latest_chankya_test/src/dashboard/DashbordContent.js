import React from 'react';
import styled from 'styled-components';

// Styled components
const DashboardContainer = styled.div`
   
  
`;

const DashboardTitle = styled.h3`
  font-size: 20px;
  margin: 0px;
  margin-bottom: 20px;
  color: #333; /* Darker text color for the title */
`;

const InfoCardsContainer = styled.div`
  display: flex;
  justify-content: space-between; /* Space out the cards */
`;

const InfoCard = styled.div`
  background-color: #000; /* Black background for cards */
  border-radius: 5px; /* Rounded corners */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
  padding: 30px;
  flex: 1; /* Take equal space */
  margin: 0 10px; /* Space between cards */

  &:first-child {
    margin-left: 0; /* Remove left margin for the first card */
  }
  
  &:last-child {
    margin-right: 0; /* Remove right margin for the last card */
  }

  p {
    margin: 0; /* Remove default margin */
    color: #fff; /* White text color */
    
    span {
      display: block; /* Stack the spans */
      text-align: start; /* Center text */
    }

    .tutor-dashboard-info-val {
      font-size: 24px; /* Larger font for values */
      font-weight: bold; /* Bold for emphasis */
      color: #fff; /* White text for values */
    }
  }
`;

const DashboardContent = () => {
  return (
    <DashboardContainer>
      <DashboardTitle>Dashboard</DashboardTitle>
      <InfoCardsContainer>
        <InfoCard>
          <p>
            <span>Enrolled Courses</span>
            <span className="tutor-dashboard-info-val">2</span>
          </p>
        </InfoCard>
        <InfoCard>
          <p>
            <span>Active Courses</span>
            <span className="tutor-dashboard-info-val">2</span>
          </p>
        </InfoCard>
        <InfoCard>
          <p>
            <span>Completed Courses</span>
            <span className="tutor-dashboard-info-val">0</span>
          </p>
        </InfoCard>
      </InfoCardsContainer>
    </DashboardContainer>
  );
};

export default DashboardContent;
