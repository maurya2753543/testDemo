import React, { useState } from 'react';
import './Wishlist.css'; // Assuming you have some styles here
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faTrash,faPlus } from '@fortawesome/free-solid-svg-icons';
import kbc from '../images/kbc-prep.jpeg';
import class2to5 from '../images/grad2-5.png';
import Chanakya_all_student from '../images/Chanakya_all_student.jpeg'
import { useNavigate } from 'react-router-dom'; // Import for navigation
import storageService from '../appwrite/storageService';


import axios from 'axios';

// Sample data for courses
const courses = [
  
  {
    id: 2,
    title: "Monthly Maths Program (2-10) Grades Students",
    grade: "(Grades 2-10)",
    imageUrl: class2to5,
    rating: 55.9,
    price: 99,
    actualPrice: 599,
    oneTime: "Monthly LMS FEE",
    feedback: "4.5/5 - Great course, highly recommend!",
  }, 
  {
    id: 4,
    title: "Monthly KBC Prep",
    grade: "All",
    imageUrl: kbc,
    rating: 55.9,
    price: 99,
    actualPrice: 599,
    oneTime: "Monthly",
    feedback: "4.8/5 - Very informative and well-structured.",
  },
 
];

const Wishlist = () => {
  const [cart, setCart] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  

  //add paymenent method
  const [responseId, setResponseId] = React.useState("");
  const [responseState, setResponseState] = React.useState([]);
  const navigate = useNavigate(); // Initialize navigate

  const handleAddToCart = (course) => {
    if (!cart.some(item => item.id === course.id)) {
      setCart((prevCart) => [...prevCart, course]);
      console.log(`Added to cart: ${course.title}`);
    } else {
      alert(`${course.title} is already in your cart!`);
    }
  };

  const filteredCourses = courses.filter(course =>
    course.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedCourse(null);
  };

  const handleSelectCourse = (course) => {
    setSelectedCourse(course);
  };

  const handleAddCard = () => {
    if (selectedCourse) {
      handleAddToCart(selectedCourse);
      handleCloseModal();
    }
  };
  // Format current date and time
  const getCurrentDateTime = () => {
    const now = new Date();
    const day = now.getDate().toString().padStart(2, '0');
    const month = (now.getMonth() + 1).toString().padStart(2, '0'); // Month is 0-indexed
    const year = now.getFullYear();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM'; // Determine AM or PM
    hours = hours % 12; // Convert to 12-hour format
    hours = hours ? hours : 12; // The hour '0' should be '12'

    return `${day}/${month}/${year} ${hours}.${minutes} ${ampm}`;
  };

 
  const loadScript = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement("script");

      script.src = src;

      script.onload = () => {
        resolve(true)
      }
      script.onerror = () => {
        resolve(false)
      }

      document.body.appendChild(script);
    })
  }

  const createRazorpayOrder = (amount , title) => {
    let data = JSON.stringify({
      amount: amount * 100,
      currency: "INR"
    })

    let config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "http://localhost:5000/orders",
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    }

    axios.request(config)
    .then((response) => {
      console.log(JSON.stringify(response.data, title))
      handleRazorpayScreen(response.data.amount ,title)
    })
    .catch((error) => {
      console.log("error at", error)
    })
  }

  const handleRazorpayScreen = async(amount , title) => {
    const res = await loadScript("https:/checkout.razorpay.com/v1/checkout.js")

    if (!res) {
      alert("Some error at razorpay screen loading")
      return;
    }
    const options = {
      key: 'rzp_test_GcZZFDPP0jHtC4',
      amount: amount,
      currency: 'INR',
      name: "Chanakya Learning Program",
      description: "Payment to Chanakya Learning Program",
      image: Chanakya_all_student,
      handler: function (response) {
        setResponseId(response.razorpay_payment_id);
        
        // Save payment details in local and session storage
        const paymentDetails = {
          paymentId: response.razorpay_payment_id,
          Title: title, // Set the description as the course title
          amount: amount / 100,
          currency: 'INR' ,
          name : "Chanakya Learning Program",
          status : "Completed",
          time : getCurrentDateTime(),
         
        };
        
        storageService.saveToLocalStorage('paymentDetails', paymentDetails);
        storageService.saveToSessionStorage('paymentDetails', paymentDetails);

        // Navigate to payment success page
        navigate('/payment-success');
      },
      prefill: {
        name: "Chanakya Learning Program",
        email: "neeraj03121996@gmail.com"
      },
      theme: {
        color: "#F4C430"
      }
    };

  

    const paymentObject = new window.Razorpay(options)
    paymentObject.open()
  }

  const paymentFetch = (e) => {
    e.preventDefault();

    const paymentId = e.target.paymentId.value;

    axios.get(`http://localhost:5000/payment/${paymentId}`)
    .then((response) => {
      console.log(response.data);
      setResponseState(response.data)
    })
    .catch((error) => {
      console.log("error occures", error)
    })
  } 

  const handleDelete = (id) => {
    setCart((prevCart) => prevCart.filter((course) => course.id !== id));
    console.log(`Deleted course with id: ${id}`);
  };

 

  return (
    <div className="wishlist-container">
      <h1>Your Wishlist </h1>
      <h4>Unlock Full Access!
      Pay once to gain unlimited access to all courses and start learning without limits.</h4>
      <div className="recommendation-section">
        <h2 className="wishlist_rec">Recommended Courses</h2>
        
        <div style={{ display: 'flex' }}>
          <input 
            type="text" 
            placeholder="Search courses..." 
            value={searchTerm} 
            onChange={(e) => setSearchTerm(e.target.value)} 
            style={{ width: '80%', marginRight: '10px' , padding : '10px' }}
          />
          <button className= "Recomendedbtn" onClick={handleOpenModal} >
            Recommended
          </button>
        </div>
               
      </div>

      <div className="wishlist-grid">
        {cart.length > 0 ? (
          cart.map((course) => {
            const discountPercentage = ((course.actualPrice - course.price) / course.actualPrice) * 100;

            return (
              <div className="course-item" key={course.id}>
                <div className="delete-icon" onClick={() => handleDelete(course.id)}>
                  <FontAwesomeIcon icon={faTrash} />
                </div>
                <img src={course.imageUrl} alt={course.title} className="course-image" />
                <h1 className="course-title">{course.title}</h1>
                <h1 className="course-title">{course.grade}</h1>
                <h1 className="course-title">{course.oneTime}</h1>
                <div className="course-info">
                  <div className="course-rating">
                    <span>↓</span>
                    <span>{discountPercentage.toFixed(2)}% off</span>
                  </div>
                  <div className="actual-price">₹{course.actualPrice.toFixed(2)}</div>
                  <div className="course-price">₹{course.price.toFixed(2)}</div>
                </div>
                <div className="course-feedback">
                  {course.feedback}
                  <div className="course-stars">
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#FFD700" />
                    <FontAwesomeIcon icon={faStar} color="#B0B0B0" />
                  </div>
                </div>
                
                 <button className="addcardbtn" onClick={() => createRazorpayOrder(course.price, course.title)}>
                  Buy now
                </button>
                
              </div>
            );
          })
        ) : (
          <p className="empty-cart-message">Cart is empty. Please add courses.</p>
        )}
      </div>

      {isModalOpen && (
        <div className="modal">
          <h2 style={{ color : 'white'}}>Select a Course</h2>
          <select onChange={(e) => handleSelectCourse(courses.find(course => course.id === Number(e.target.value)))}>
            <option value="">Select a course...</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>
                {course.title}
              </option>
            ))}
          </select>
          <div style={{ display: 'flex', alignItems: 'center' }}>
  <button className="addcardbtn" onClick={handleAddCard}>
    <FontAwesomeIcon icon={faPlus} style={{ marginRight: '8px' }} /> Add Card
  </button>
  <button className="Model-fa-icon" onClick={handleCloseModal} style={{ marginLeft: 'auto' }}>
    <FontAwesomeIcon icon={faTrash} />
  </button>
</div>
        </div>
      )}
    </div>
  );
};

export default Wishlist;
