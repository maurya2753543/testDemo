import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components';
import './Settings.css';
import AppwriteService from '../appwrite/AppwriteService';

// Styled components
const SettingsContainer = styled.div`
  padding: 20px;
  max-width: 800px;
  margin: auto;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
`;

const Button = styled.button`
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: ${(props) => (props.primary ? '#4caf50' : '#008cba')};
  color: white;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: ${(props) => (props.primary ? '#45a049' : '#007bb5')};
  }
`;

const Settings = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    name: '',
    phone: '',
    linkedln: '',
    facebook: '',
    bio: '',
  });

  const databaseId = '671cb36f0034783418a7';
  const collectionId = '671cb38600053ecae112';
  const documentId = 'unique_user_doc_id'; // Replace with a logic to manage user-specific documents

  // Fetch user profile data
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const response = await appwriteService.databases.getDocument(
          databaseId,
          collectionId,
          documentId
        );
        setFormData(response); // Populate form data with the saved profile
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  // Handle form input change
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle save profile
  const handleSave = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.databases.createDocument(
        databaseId,
        collectionId,
        documentId,
        formData
      );
      alert('Profile saved successfully!');
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Failed to save profile. Please try again.');
    }
  };

  // Handle update profile
  const handleUpdate = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.databases.updateDocument(
        databaseId,
        collectionId,
        documentId,
        formData
      );
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Error updating data:', error);
      alert('Failed to update profile. Please try again.');
    }
  };

  return (
    <SettingsContainer>
      <h3>Profile Settings</h3>
      <form>
        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>First Name</label>
          <input
                    style={{ width : '50%' , padding: '15px' , marginLeft : '100px'}}

            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            placeholder="First Name"
          />
        </FormGroup>
        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>Last Name</label>
          <input
                    style={{ width : '50%' , padding: '15px' , marginLeft : '100px'}}

            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            placeholder="Last Name"
          />
        </FormGroup>
      
        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>Phone No..</label>
          <input
                    style={{ width : '50%' , padding: '15px' , marginLeft : '100px'}}
                    type="number"
            name="phone"
            value={formData.phone}
            onChange={handleInputChange}
            placeholder="Phone Number"
          />
        </FormGroup>
        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>Linkedln id</label>
          <input
                    style={{ width : '50%' , padding: '15px' , marginLeft : '100px'}}
                    type="text"

            name="linkedln"
            value={formData.linkedln}
            onChange={handleInputChange}
            placeholder="Linkedln id"
          />
        </FormGroup>
        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>Facebook id</label>
          <input
                    style={{ width : '50%' , padding: '15px' , marginLeft : '92px'}}
                    type="text"

            name="facebook"
            value={formData.facebook}
            onChange={handleInputChange}
            placeholder="Facebook id"
          />
        </FormGroup>

        <FormGroup>
          <label style={{ paddingLeft : '20px'}}>Bio</label>
          <textarea
            name="bio"
            style={{ width : '50%' , padding: '15px' , marginLeft: '150px' , height : '100px'}}

            value={formData.bio}
            onChange={handleInputChange}
            placeholder="Write something about yourself..."
          ></textarea>
        </FormGroup>
        <ButtonGroup>
          <Button type="button" primary onClick={handleSave}>
            Save Profile
          </Button>
          <Button type="button" onClick={handleUpdate}>
            Update Profile
          </Button>
        </ButtonGroup>
      </form>
    </SettingsContainer>
  );
};

export default Settings;
