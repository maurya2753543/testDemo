import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faCog, faDashboard, faBoxes, faBookmark, faStarHalfAlt, faShoppingCart, faSignOutAlt, faGraduationCap } from '@fortawesome/free-solid-svg-icons';
import Dashboard_Header from '../comman-header/Dashbord-header';
import DashboardTopHeader from './DashboardTopHeader';
import './TabLayout.css'; // Optional, for custom styling
import Dashboard from './Dashboard'; // Import your Dashboard component
import Profile from './Profile'; // Import your Profile component
import EnrolledCourses from './EnrolledCourses'; // Import your EnrolledCourses component
import Wishlist from './Wishlist'; // Import your Wishlist component
import Reviews from './Reviews'; // Import your Reviews component
import MyQuizAttempts from './MyQuizAttempts'; // Import your MyQuizAttempts component
import PurchaseHistory from './PurchaseHistory'; // Import your PurchaseHistory component
import Settings from './Settings'; // Import your Settings component
import DashbordContent from './DashbordContent';
import ClipLoader from "react-spinners/ClipLoader"; // Import the loader
import AppwriteService from '../appwrite/AppwriteService';
import { Link, useNavigate } from 'react-router-dom';

const TabLayout = () => {
  const [loading, setLoading] = useState(false); // State for loader
  const [user] = useState({
    username: '',
    avatarUrl: 'https://secure.gravatar.com/avatar/f72172a0cf3d814741f44ae012b5cbe5?s=150&d=mm&r=g',
  });

  const [activeComponent, setActiveComponent] = useState(<DashbordContent />); // Default to Dashboard
  const navigate = useNavigate();

  const tabs = [
    { name: 'Dashboard', icon: faDashboard, component: <DashbordContent />, param: 'dashboard' },
    { name: 'My Profile', icon: faUser, component: <Profile />, param: 'profile' },
    { name: 'Enrolled Courses', icon: faGraduationCap, component: <EnrolledCourses onNavigate={() => handleTabClick('wishlist')} />, param: 'enrolled-courses' },
    { name: 'Wishlist', icon: faBookmark, component: <Wishlist />, param: 'wishlist' },
    { name: 'Reviews', icon: faStarHalfAlt, component: <Reviews />, param: 'reviews' },
    { name: 'My Quiz Attempts', icon: faBoxes, component: <MyQuizAttempts />, param: 'quiz-attempts' },
    { name: 'Purchase History', icon: faShoppingCart, component: <PurchaseHistory />, param: 'purchase-history' },
  ];

  const handleLogout = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.logout();
      navigate('/'); // Redirect to homepage after logout
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const handleTabClick = (tabName) => {
    const selectedTab = tabs.find(tab => tab.param === tabName);
    if (selectedTab) {
      setActiveComponent(selectedTab.component);
      setLoading(false);
    } else if (tabName === 'settings') {
      setActiveComponent(<Settings />); // Handle settings tab
      setLoading(false);
    }
  };

  return (
    <>
      <Dashboard_Header onTabClick={handleTabClick} />

      <div className="Main-container-tablayout">
        <div className="Top-header-dashboard">
          <DashboardTopHeader username={user.username} avatarUrl={user.avatarUrl} />
        </div>

        <div className="loader-container">
          <ClipLoader color={"#36d7b7"} loading={loading} size={50} />
        </div>

        <div className="tab-layout">
          {/* Sidebar */}
          <div className="sidebar">
            {tabs.map((tab) => (
              <button
                key={tab.name}
                onClick={() => handleTabClick(tab.param)}
                className={`tab-button ${activeComponent.type === tab.component.type ? 'active' : ''}`}
              >
                <FontAwesomeIcon icon={tab.icon} className="fa-icon" style={{ marginRight: '8px' }} />
                {tab.name}
              </button>
            ))}

            {/* Divider between settings and logout */}
            <div className="tutor-dashboard-menu-divider" />
            
            {/* Settings Button */}
            <button
              onClick={() => handleTabClick('settings')} // Open the Settings component on click
              className={`tab-button ${activeComponent.type === Settings ? 'active' : ''}`} // Add the 'active' class if the activeComponent is Settings
            >
              <FontAwesomeIcon icon={faCog} className="fa-icon" style={{ marginRight: '15px' }} />
              Settings
            </button>

            {/* Logout Button */}
            <button
              onClick={() => handleLogout()} // Placeholder for logout functionality
              className="tab-button"
            >
              <FontAwesomeIcon icon={faSignOutAlt} className="fa-icon" style={{ marginRight: '15px' }} />
              Logout
            </button>
          </div>

          {/* Right Content Area */}
          <div className="content">
            {activeComponent} {/* Render the currently active component */}
          </div>
        </div>
      </div>
    </>
  );
};

export default TabLayout;
