// src/components/AddQuestion.js
import React, { useState, useEffect } from 'react';
import ProfileService from '../appwrite/ProfileService'; // Import the ProfileService

const AddQuestion = () => {
  const [category, setCategory] = useState('');
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState([
    { text: '', isCorrect: false },
    { text: '', isCorrect: false },
    { text: '', isCorrect: false },
    { text: '', isCorrect: false },
  ]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const profileService = new ProfileService(); // Create an instance of ProfileService
  const databaseId = '671cb38600053ecae112'; // Database ID
  const collectionId = '671cb38600053ecae112'; // Collection ID

  // Check user authentication status
  useEffect(() => {
    const checkUserStatus = async () => {
      try {
        const accountDetails = await profileService.account.get();
        setUser(accountDetails);
      } catch (error) {
        console.error('User not authenticated', error);
        setUser(null);
      }
      setLoading(false);
    };
    checkUserStatus();
  }, []);

  // Handle form option change
  const handleOptionChange = (index, key, value) => {
    const updatedOptions = [...options];
    if (key === 'isCorrect') {
      updatedOptions.forEach((option, i) => (option.isCorrect = i === index));
    }
    updatedOptions[index][key] = value;
    setOptions(updatedOptions);
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newQuestion = {
      category,
      question,
      options,
    };

    try {
      await profileService.addQuestion(databaseId, collectionId, newQuestion); // Use the service to add question
      alert('Question added successfully!');
      setCategory('');
      setQuestion('');
      setOptions([
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
      ]);
    } catch (error) {
      console.error('Error saving question:', error);
      alert('Failed to add question.');
    }
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: 'auto' }}>
      {user ? (
        <>
          <h2>Add New Question</h2>
          <form onSubmit={handleSubmit}>
            <label>
              Select Category:
              <select value={category} onChange={(e) => setCategory(e.target.value)} required>
                <option value="">Choose Category</option>
                <option value="Current affairs">Current affairs</option>
                <option value="General knowledge">General knowledge</option>
                <option value="History">History</option>
                <option value="Geography">Geography</option>
                <option value="Sports">Sports</option>
              </select>
            </label>

            <label>
              Question:
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                required
                placeholder="Enter your question"
              />
            </label>

            <h3>Options</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap' }}>
              {options.map((option, index) => (
                <div key={index} style={{ width: '50%', padding: '5px', boxSizing: 'border-box' }}>
                  <input
                    type="text"
                    placeholder={`Option ${index + 1}`}
                    value={option.text}
                    onChange={(e) => handleOptionChange(index, 'text', e.target.value)}
                    required
                    style={{ width: '80%' }}
                  />
                  <label style={{ display: 'block', marginTop: '5px' }}>
                    <input
                      type="radio"
                      name="isCorrect"
                      checked={option.isCorrect}
                      onChange={() => handleOptionChange(index, 'isCorrect', true)}
                    />
                    Correct Answer
                  </label>
                </div>
              ))}
            </div>

            <button
              style={{
                padding: '10px',
                backgroundColor: 'red',
                color: 'white',
                borderRadius: '5px',
                marginTop: '20px',
                marginLeft: '25px',
                border : 'none',
                fontSize : '16px',
                fontWeight : '700',               
              
              }}
              type="submit"
            >
              Submit
            </button>
          </form>
        </>
      ) : (
        <p>User is not authenticated. Please log in.</p>
      )}
    </div>
  );
};

export default AddQuestion;
