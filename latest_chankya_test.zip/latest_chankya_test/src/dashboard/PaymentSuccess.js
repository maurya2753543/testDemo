import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Chanakya_all_student from '../images/Chanakya_all_student.jpeg';
import Dashboard_Header from '../comman-header/Dashbord-header';
import AppwriteService from '../appwrite/AppwriteService'; // Assuming you are using Appwrite for session handling
import Header from '../comman-header/Header';
import { FaTimes } from 'react-icons/fa'; // Import the FontAwesome icon
import storageService from '../appwrite/storageService'; // Import your storage service

const PaymentSuccess = ({ onNavigate }) => {
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState({
    registrationDate: '',
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phoneNumber: '',
    bio: '',
  });

  const handleClose = () => {
    navigate('/dashboard'); // Replace with your enroll page route
  };

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [paymentDetails, setPaymentDetails] = useState(null);
  const appwriteService = new AppwriteService(); // Create an instance of AppwriteService

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const user = await appwriteService.account.get(); // Fetch the current user's data

        setUserProfile({
          registrationDate: new Date(user.$createdAt).toLocaleString(),
          firstName: user.name.split(' ')[0] || '', // First name
          lastName: user.name.split(' ')[1] || '',  // Last name
          username: user.prefs.username || '', // Username
          email: user.email || '', // User email
          phoneNumber: user.prefs.phoneNumber || 'Not Provided', // Phone number
          bio: user.prefs.bio || 'Not Provided', // Bio
        });

        console.log("User Data:", user); // Log the fetched user data for debugging
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []); // Empty dependency array ensures it only runs once

  // Fetch payment details from local storage
  useEffect(() => {
    const storedPaymentDetails = storageService.getFromLocalStorage('paymentDetails'); // Adjust the key as needed
    if (storedPaymentDetails) {
      console.log('Payment Details:', storedPaymentDetails); // Log payment details to console
      setPaymentDetails(storedPaymentDetails);
    } else {
      console.log('No payment details found in local storage.');
    }
  }, []);

  

  return (
    <>
      {/* Conditionally render headers based on login status */}
      {isLoggedIn ? <Dashboard_Header /> : <Header />}
      <div className="payment-success-container">
        <button
          onClick={handleClose}
          className="close-btn"
          style={{
            position: 'absolute',
            top: '100px',
            right: '50px',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            color: 'black',
            fontSize: '24px',
          }}
        >
          <FaTimes />
        </button>
        <div style={{ justifyContent: 'flex-start', marginTop: '20px', display: 'flex', alignItems: 'center', width: '100%' }}>
          <div style={{ width: '40%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <img
              src={Chanakya_all_student}
              alt="Logo"
              style={{
                width: '50px',
                height: '50px',
                borderRadius: '50%',
                objectFit: 'cover',
              }}
            />
          </div>
          <h1 style={{ width: '60%', marginLeft: '10px' }}>Payment Successful</h1>
          <div>
            <h1 style={{ fontSize: '20px', margin: '30px 0 8px' }}>Reminder!</h1>
            <p style={{ margin: 0, fontSize: '16px' }}>
              Please take a screenshot of your payment details for your records.
            </p>
          </div>
        </div>

        {paymentDetails ? (
          <table className="payment-details-table" style={{ width: '80%', margin: '20px auto', borderCollapse: 'collapse', boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)', borderRadius: '10px', backgroundColor: '#f9f9f9' }}>
            <thead>
              <tr>
                <th style={{ padding: '12px', textAlign: 'center', backgroundColor: '#4CAF50', color: 'white' }}>Detail</th>
                <th style={{ padding: '12px', textAlign: 'center', backgroundColor: '#4CAF50', color: 'white' }}>Information</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Name</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{userProfile.firstName} {userProfile.lastName}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Email</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{userProfile.email}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Course Name</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.name}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Course Title</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.Title}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Amount</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{(paymentDetails.amount).toFixed(2)} Rs.</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Currency</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.currency}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Status</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.status}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Date & Time</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.time}</td>
              </tr>
              <tr>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>Transaction ID</td>
                <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>{paymentDetails.paymentId}</td>
              </tr>
            </tbody>
          </table>
        ) : (
          <p style={{ textAlign: 'center', marginTop: '20px' }}>No payment details available.</p>
        )}
      </div>
    </>
  );
};

export default PaymentSuccess;
