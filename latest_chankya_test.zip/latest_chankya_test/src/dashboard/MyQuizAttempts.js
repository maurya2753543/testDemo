import React from 'react';

const MyQuizAttempts = () => {
  return (
    <div>
      <h2>My MyQuizAttempts</h2>
      <p>Here is the MyQuizAttempts content.</p>
    </div>
  );
};

export default MyQuizAttempts;
