// storageService.js
const storageService = {
    saveToLocalStorage: (key, value) => {
      localStorage.setItem(key, JSON.stringify(value));
    },
  
    getFromLocalStorage: (key) => {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    },
  
    saveToSessionStorage: (key, value) => {
      sessionStorage.setItem(key, JSON.stringify(value));
    },
  
    getFromSessionStorage: (key) => {
      const data = sessionStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    },
  
    clearStorage: (key, type = 'local') => {
      if (type === 'local') {
        localStorage.removeItem(key);
      } else if (type === 'session') {
        sessionStorage.removeItem(key);
      }
    }
  };
  
  export default storageService;
  