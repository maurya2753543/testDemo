import React, { useState } from 'react';
import TimeDistance from './MagneticfieldQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
    <h3>Magnetic Field Formulas</h3>

<ul>
  <li><strong>Magnetic Field Strength (B)</strong> = μ₀ * (I / 2πr)</li>
  <li><strong>μ₀</strong> = Permeability of free space (4π × 10⁻⁷ T·m/A)</li>
  <li><strong>I</strong> = Current flowing through the wire</li>
  <li><strong>r</strong> = Distance from the center of the wire</li>
</ul>

<ul>
  <li><strong>Magnetic Field Due to a Solenoid (B)</strong> = μ₀ * n * I</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>n</strong> = Number of turns per unit length of the solenoid</li>
  <li><strong>I</strong> = Current flowing through the solenoid</li>
</ul>

<ul>
  <li><strong>Magnetic Moment (μ)</strong> = I * A</li>
  <li><strong>I</strong> = Current flowing through the loop</li>
  <li><strong>A</strong> = Area of the loop (πr² for circular loop)</li>
</ul>

<ul>
  <li><strong>Magnetic Field at the Center of a Circular Loop (B)</strong> = (μ₀ * I) / (2 * r)</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>I</strong> = Current flowing through the loop</li>
  <li><strong>r</strong> = Radius of the circular loop</li>
</ul>

<ul>
  <li><strong>Force on a Moving Charge in a Magnetic Field (F)</strong> = q * v * B * sin(θ)</li>
  <li><strong>q</strong> = Charge of the particle</li>
  <li><strong>v</strong> = Velocity of the particle</li>
  <li><strong>B</strong> = Magnetic field strength</li>
  <li><strong>θ</strong> = Angle between the velocity and magnetic field</li>
</ul>

<ul>
  <li><strong>Force Between Two Parallel Current-Carrying Wires (F)</strong> = (μ₀ * I₁ * I₂ * L) / (2π * d)</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>I₁, I₂</strong> = Currents in the two wires</li>
  <li><strong>L</strong> = Length of the wires</li>
  <li><strong>d</strong> = Distance between the wires</li>
</ul>

<ul>
  <li><strong>Magnetic Field at a Point on the Axial Line of a Bar Magnet (B)</strong> = (μ₀ * M) / (2π * r³)</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>M</strong> = Magnetic moment of the magnet</li>
  <li><strong>r</strong> = Distance from the center of the magnet along the axial line</li>
</ul>

<ul>
  <li><strong>Magnetic Field at a Point on the Equatorial Line of a Bar Magnet (B)</strong> = (μ₀ * M) / (4π * r³)</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>M</strong> = Magnetic moment of the magnet</li>
  <li><strong>r</strong> = Distance from the center of the magnet along the equatorial line</li>
</ul>

<ul>
  <li><strong>Magnetic Field Strength Inside a Solenoid (B)</strong> = μ₀ * n * I</li>
  <li><strong>μ₀</strong> = Permeability of free space</li>
  <li><strong>n</strong> = Number of turns per unit length of the solenoid</li>
  <li><strong>I</strong> = Current flowing through the solenoid</li>
</ul>

<ul>
  <li><strong>Magnetic Force on a Current-Carrying Wire (F)</strong> = I * L * B * sin(θ)</li>
  <li><strong>I</strong> = Current in the wire</li>
  <li><strong>L</strong> = Length of the wire in the magnetic field</li>
  <li><strong>B</strong> = Magnetic field strength</li>
  <li><strong>θ</strong> = Angle between the magnetic field and the current</li>
</ul>
<h3>Finite Beam of Current</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> I / 4π x (cos θ<sub>1</sub> + cos θ<sub>2</sub>) <sup>x</sup></li>
  <li><strong>I</strong> = Uniform current throughout the beam</li>
  <li><strong>x</strong> = Distance from the point of interest</li>
  <li><strong>θ<sub>1</sub></strong>, <strong>θ<sub>2</sub></strong> = Angles made by the line from the current to the point of interest</li>
</ul>

<h3>Infinite Wire</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> I / 2π x <sup>x</sup></li>
  <li><strong>I</strong> = Uniform current flowing through the wire</li>
  <li><strong>x</strong> = Radial distance from the wire</li>
</ul>

<h3>Infinite Cylindrical Wire</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> I / 2π x <sup>x</sup> (outside the wire)</li>
  <li><strong>B</strong> = μ<sub>0</sub> I x / 2π R<sup>2</sup> <sup>x</sup> (inside the wire)</li>
  <li><strong>I</strong> = Uniform current flowing through the wire</li>
  <li><strong>x</strong> = Distance from the center of the wire</li>
  <li><strong>R</strong> = Radius of the wire</li>
</ul>

<h3>Circular Loop</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> I R<sup>2</sup> / 2 (x<sup>2</sup> + R<sup>2</sup>)<sup>3/2</sup> <sup>x</sup></li>
  <li><strong>I</strong> = Uniform current flowing through the loop</li>
  <li><strong>R</strong> = Radius of the loop</li>
  <li><strong>x</strong> = Distance along the axis of the loop</li>
</ul>

<h3>Solenoid</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> n I / 2 (cos θ<sub>1</sub> + cos θ<sub>2</sub>) <sup>x</sup></li>
  <li><strong>n</strong> = Number of loops per unit length</li>
  <li><strong>I</strong> = Current flowing through the solenoid</li>
  <li><strong>θ<sub>1</sub></strong>, <strong>θ<sub>2</sub></strong> = Angles along the solenoid's axis</li>
</ul>

<h3>Infinite Solenoid</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = 0 (outside the solenoid)</li>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> n I <sup>x</sup> (inside the solenoid)</li>
  <li><strong>n</strong> = Number of loops per unit length</li>
  <li><strong>I</strong> = Current flowing through the solenoid</li>
</ul>

<h3>Circular Toroid</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> N I / 2π R</li>
  <li><strong>N</strong> = Number of turns in the toroid</li>
  <li><strong>I</strong> = Current flowing through the toroid</li>
  <li><strong>R</strong> = Radius of the circular toroid</li>
</ul>

<h3>Magnetic Dipole</h3>
<ul>
  <li><strong>Magnetic Field (B)</strong> = - μ<sub>0</sub> m / 4π r<sup>3</sup> (on the equatorial plane)</li>
  <li><strong>Magnetic Field (B)</strong> = μ<sub>0</sub> m / 2π x<sup>3</sup> (on the axial plane, where x ≫ R)</li>
  <li><strong>m</strong> = Magnetic dipole moment</li>
  <li><strong>r</strong> = Distance from the dipole on the equatorial plane</li>
  <li><strong>x</strong> = Distance from the dipole on the axial plane</li>
  <li><strong>R</strong> = Characteristic length scale of the dipole</li>
</ul>
<h3>Right-Hand Thumb Rule</h3>
<ul>
  <li><strong>Right-Hand Thumb Rule</strong>: It is used to determine the direction of the magnetic field around a current-carrying conductor.</li>
  <li><strong>Steps to use the Right-Hand Thumb Rule:</strong></li>
  <ul>
    <li>Hold the conductor with your right hand such that your thumb points in the direction of the current.</li>
    <li>The direction in which your fingers curl around the conductor gives the direction of the magnetic field.</li>
  </ul>
  <li><strong>Application</strong>: This rule helps in visualizing the magnetic field produced by straight current-carrying conductors, solenoids, or coils.</li>
</ul>

<h3>Left-Hand Thumb Rule</h3>
<ul>
  <li><strong>Left-Hand Thumb Rule</strong>: This rule is used to determine the direction of the force experienced by a moving charged particle or a current-carrying conductor in a magnetic field.</li>
  <li><strong>Steps to use the Left-Hand Thumb Rule:</strong></li>
  <ul>
    <li>Point your thumb in the direction of the current or motion of the positive charge.</li>
    <li>Point your fingers in the direction of the magnetic field.</li>
    <li>Your palm will face the direction of the force acting on the conductor or charged particle.</li>
  </ul>
  <li><strong>Application</strong>: This rule is useful in determining the direction of force on a current-carrying wire in a magnetic field (Lorentz force), and also for understanding the motion of charged particles in magnetic fields (e.g., in a motor or magnetic induction). </li>
</ul>





          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
