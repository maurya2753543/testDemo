import React from 'react';
import './OpticalPrismTable.css'; // Importing the CSS file

const OpticalPrismTable = () => {
  return (
    <div className="table-container">
      <h1>Optical Prisms Comparison</h1>
      <table className="prism-table">
        <thead>
          <tr>
            <th>Prism Type</th>
            <th>Function</th>
            <th>Application</th>
            <th>Light Interaction</th>
            <th>Common Uses</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Dispersion Prisms</td>
            <td>Disperse light into its component colors</td>
            <td>Spectroscopy</td>
            <td>Light is refracted and separated by wavelength</td>
            <td>Used in spectrometers to analyze light</td>
          </tr>
          <tr>
            <td>Deviation (Reflection) Prisms</td>
            <td>Change the direction of light by reflecting it</td>
            <td>Optical instruments</td>
            <td>Light undergoes total internal reflection</td>
            <td>Used in binoculars, periscopes, and cameras</td>
          </tr>
          <tr>
            <td>Rotation Prisms</td>
            <td>Rotate the polarization of light</td>
            <td>Polarimetry</td>
            <td>Rotates plane of polarization of incoming light</td>
            <td>Used in optical instruments to control polarization</td>
          </tr>
          <tr>
            <td>Displacement Prisms</td>
            <td>Displace light without changing its direction</td>
            <td>Beam steering</td>
            <td>Light shifts laterally without altering its angle</td>
            <td>Used in optical systems to shift light paths</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default OpticalPrismTable;
