import React, { useState } from "react";
import "./MagneticField.css"; // External CSS for styling
import MagneticfieldQuiz from './MagneticfieldQuiz';

const MagneticField = () => {
  const [linesVisible, setLinesVisible] = useState(false);

  const handleToggleLines = () => {
    setLinesVisible(!linesVisible);
  };

  return (
    <div className="container">
      <h1>Magnetic Field Lines of a Bar Magnet</h1>
      <div className="magnet">
        <div className="pole north">N</div>
        <div className="bar"></div>
        <div className="pole south">S</div>
      </div>
      <div className={`field-lines ${linesVisible ? "visible" : ""}`}>
        {/* Magnetic field lines (dotted lines) */}
        {linesVisible &&
          Array.from({ length: 20 }).map((_, index) => (
            <div
              key={index}
              className="field-line"
              style={{
                // Each line is emitted from the N pole and curves towards the S pole
                animationDelay: `${index * 0.1}s`, // Stagger the animation for effect
              }}
            >
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
              <div className="dot1"></div>
            </div>
          ))}
      </div>
      <button onClick={handleToggleLines} className="toggle-btn-mag">
        {linesVisible ? "Hide Field Lines" : "Show Field Lines"}
      </button>
      <p>
        <strong>Theory:</strong> A field of force that exists around a bar magnet is called its magnetic field. When iron filings are sprinkled around the bar magnet, they arrange in a pattern. The lines along which the iron filings orient themselves represent the magnetic field lines. These lines are closed curves and do not intersect each other. They are denser at the poles, indicating that the magnetic field is stronger there.
        Magnetic Field, Lorentz Force
    Let us suppose that there is a point charge q (moving with a velocity v and, located at r at a given time t) in presence of both the electric field E (r) and the magnetic field B (r). The force on an electric charge q due to both of them can be written as

    This force was given first by H.A. Lorentz based on the extensive experiments of Ampere and others. It is called the Lorentz force. You have already studied in detail the force due to the electric field. If we look at the interaction with the magnetic field, we find the following features:
    
    F = q [ E (r) + v × B (r)] º Felectric + Fmagnetic (4.3)
    <strong>(i)</strong> It depends on q, v and B (charge of the particle, the velocity and the magnetic field). Force on a negative charge is opposite to that on a positive charge.
  
    <strong>(ii)</strong> The magnetic force q [ v × B ] includes a vector product of velocity and magnetic field. The vector product makes the force due to magnetic...
     
      </p>
     

      <MagneticfieldQuiz />
    </div>
  );
};

export default MagneticField;
