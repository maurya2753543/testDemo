import React, { useState, useEffect } from "react";
import "./CycleAnimation.css";
import MotorcycleAnimation from './MotorcycleAnimation';
const CycleAnimation = () => {
  const [cycleSpeed, setCycleSpeed] = useState(15); // Cycle speed in km/h
  const [windSpeed, setWindSpeed] = useState(5); // Wind speed in km/h
  const [direction, setDirection] = useState("with"); // "with" or "against"
  const [time, setTime] = useState(0); // Time in hours
  const [distance, setDistance] = useState(0); // Distance in kilometers
  const [formula, setFormula] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prevTime) => {
        const newTime = prevTime + 0.1; // Increment time in hours
        const effectiveSpeed =
          direction === "with"
            ? cycleSpeed + windSpeed
            : cycleSpeed - windSpeed;

        if (effectiveSpeed > 0) {
          setDistance((newTime * effectiveSpeed).toFixed(2));
          setFormula(
            `Distance = Effective Speed × Time (Effective Speed = ${
              direction === "with"
                ? "Cycle Speed + Wind Speed"
                : "Cycle Speed - Wind Speed"
            })`
          );
        }
        return newTime;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [cycleSpeed, windSpeed, direction]);

  return (
    <div style={{ padding: "40px", margin: "10px" }}>
      <div className="roadCycle">
        {/* roadCycle Background */}
        <div className={`wind ${direction === "with" ? "wind-with" : "wind-against"}`}></div>

        {/* Cycle */}
        <div className={`cycle ${direction === "with" ? "cycle-with" : "cycle-against"}`}>
          <div className="frame"></div>
          <div className="front-wheel"></div>
          <div className="back-wheel"></div>
        </div>
      </div>

      {/* Controls */}
      <div style={{ marginTop: "20px" }}>
        <h2>Cycle and Wind Animation</h2>
        <p>
          <strong>Cycle Speed:</strong> {cycleSpeed} km/h
        </p>
        <p>
          <strong>Wind Speed:</strong> {windSpeed} km/h
        </p>
        <p>
          <strong>Direction:</strong>{" "}
          <button className="try-again-btn" onClick={() => setDirection("with")}>With Wind</button>{" "}
          <button className="try-again-btn" onClick={() => setDirection("against")}>Against Wind</button>
        </p>
        <p>
          <strong>Time:</strong> {time.toFixed(2)} hours
        </p>
        <p>
          <strong>Distance:</strong> {distance} km
        </p>
        <p>
          <strong>Formula:</strong> {formula}
        </p>
      </div>
      <MotorcycleAnimation />

    </div>
  );
};

export default CycleAnimation;
