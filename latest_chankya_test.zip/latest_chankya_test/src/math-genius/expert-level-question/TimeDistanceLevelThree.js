import React, { useState } from 'react';
import TimeDistance from './TimeDistanceLevelThree.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
          <h2>Time, Speed, and Distance Formulas</h2>
          <ul>
  <li><strong>Effective Speed</strong> = Train Speed ± Wind Speed</li>
  <li><strong>Distance</strong> = Effective Speed × Time</li>
  <li><strong>Time</strong> = Distance ÷ Effective Speed</li>
  <li><strong>Acceleration</strong> = (Final Velocity - Initial Velocity) ÷ Time</li>
  <li><strong>Braking Distance</strong> = (Initial Velocity²) ÷ (2 × Deceleration)</li>
  <li><strong>Force</strong> = Mass × Acceleration</li>
  <li><strong>Work</strong> = Force × Distance</li>
  <li><strong>Power</strong> = Work ÷ Time</li>
  <li><strong>Kinetic Energy</strong> = ½ × Mass × Velocity²</li>
  <li><strong>Rolling Resistance Force</strong> = Coefficient of Rolling Resistance × Weight</li>
  <li><strong>Traction Force</strong> = Engine Power ÷ Velocity</li>
  <li><strong>Engine Efficiency</strong> = (Output Power ÷ Input Power) × 100</li>
  <li><strong>Maximum Speed</strong> = (Engine Power ÷ Resistance Force)</li>
</ul>

<ul>
  <li><strong>Lift</strong> = ½ × Air Density × Velocity² × Wing Area × Lift Coefficient</li>
  <li><strong>Drag</strong> = ½ × Air Density × Velocity² × Drag Coefficient × Wing Area</li>
  <li><strong>Thrust</strong> = Force produced by engines (usually related to engine speed)</li>
  <li><strong>Weight</strong> = Mass × Gravity</li>
  <li><strong>Acceleration</strong> = (Final Velocity - Initial Velocity) ÷ Time</li>
  <li><strong>Time to Climb</strong> = Altitude Gain ÷ Climb Rate</li>
  <li><strong>Range</strong> = (Fuel Efficiency × Fuel Load) ÷ Drag</li>
  <li><strong>Fuel Burn</strong> = Thrust × Fuel Consumption Rate</li>
  <li><strong>Turn Radius</strong> = (Velocity²) ÷ (g × Tan(Angle of Bank))</li>
  <li><strong>Kinetic Energy</strong> = ½ × Mass × Velocity²</li>
  <li><strong>Power</strong> = Thrust × Velocity</li>
  <li><strong>Induced Drag</strong> = (Lift²) ÷ (π × Aspect Ratio × Efficiency Factor)</li>
  <li><strong>Engine Efficiency</strong> = (Output Thrust ÷ Input Power) × 100</li>
</ul>

          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
