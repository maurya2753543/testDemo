import React, { useState } from 'react';
import TimeDistance from './OhmsLawSimulatorQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
          <h2>Ohm's Law Formulas</h2>
         
<ul>
  <li><strong>Ohm's Law</strong> = V = I × R</li>
  <li><strong>V</strong> = Voltage across the resistor (Volts)</li>
  <li><strong>I</strong> = Current through the resistor (Amperes)</li>
  <li><strong>R</strong> = Resistance of the resistor (Ohms)</li>
  
  <li><strong>Power in an AC Circuit</strong> = P = V × I</li>
  <li><strong>P</strong> = Power dissipated (Watts)</li>
  
  <li><strong>Impedance in AC Circuit</strong> = Z = √(R² + (X<sub>L</sub> - X<sub>C</sub>)²)</li>
  <li><strong>Z</strong> = Total impedance (Ohms)</li>
  <li><strong>X<sub>L</sub></strong> = Inductive reactance (Ohms)</li>
  <li><strong>X<sub>C</sub></strong> = Capacitive reactance (Ohms)</li>
  
  <li><strong>Inductive Reactance</strong> = X<sub>L</sub> = 2πfL</li>
  <li><strong>f</strong> = Frequency of the AC supply (Hz)</li>
  <li><strong>L</strong> = Inductance of the coil (Henries)</li>
  
  <li><strong>Capacitive Reactance</strong> = X<sub>C</sub> = 1 / (2πfC)</li>
  <li><strong>C</strong> = Capacitance of the capacitor (Farads)</li>
  
  <li><strong>AC Power Factor</strong> = PF = cos(θ)</li>
  <li><strong>θ</strong> = Phase angle between current and voltage</li>
  
  <li><strong>RMS Voltage</strong> = V<sub>rms</sub> = V<sub>peak</sub> / √2</li>
  <li><strong>V<sub>rms</sub></strong> = Root mean square (RMS) voltage (Volts)</li>
  <li><strong>V<sub>peak</sub></strong> = Peak voltage (Volts)</li>
  
  <li><strong>RMS Current</strong> = I<sub>rms</sub> = I<sub>peak</sub> / √2</li>
  <li><strong>I<sub>rms</sub></strong> = Root mean square (RMS) current (Amperes)</li>
  <li><strong>I<sub>peak</sub></strong> = Peak current (Amperes)</li>
  
  <li><strong>Average Power in AC Circuit</strong> = P<sub>avg</sub> = V<sub>rms</sub> × I<sub>rms</sub> × PF</li>
  <li><strong>P<sub>avg</sub></strong> = Average power (Watts)</li>
  
  <li><strong>Resonant Frequency</strong> = f<sub>r</sub> = 1 / (2π√(LC))</li>
  <li><strong>L</strong> = Inductance (Henries)</li>
  <li><strong>C</strong> = Capacitance (Farads)</li>
  
  <li><strong>Q Factor (Quality Factor)</strong> = Q = f<sub>r</sub> / (Δf)</li>
  <li><strong>Δf</strong> = Bandwidth of the circuit (Hz)</li>
</ul>



          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
