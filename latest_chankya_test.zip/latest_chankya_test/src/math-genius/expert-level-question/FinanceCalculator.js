import React, { useState } from 'react';
import './FinanceCalculator.css';
import Financequiz from './Financequiz';

const FinanceCalculator = () => {
  // Simple Interest State
  const [principalSI, setPrincipalSI] = useState('');
  const [rateSI, setRateSI] = useState('');
  const [timeSI, setTimeSI] = useState('');
  const [interestSI, setInterestSI] = useState(null);

  // Compound Interest State
  const [principalCI, setPrincipalCI] = useState('');
  const [rateCI, setRateCI] = useState('');
  const [timeCI, setTimeCI] = useState('');
  const [compoundInterest, setCompoundInterest] = useState(null);
  const [timesCompounded, setTimesCompounded] = useState(1);

  // Loan EMI State
  const [loanAmount, setLoanAmount] = useState('');
  const [rateLoan, setRateLoan] = useState('');
  const [timeLoan, setTimeLoan] = useState('');
  const [emi, setEmi] = useState(null);

  // Simple Interest Calculation
  const handleCalculateSI = () => {
    const result = (parseFloat(principalSI) * parseFloat(rateSI) * parseFloat(timeSI)) / 100;
    setInterestSI(result);
  };

  // Compound Interest Calculation
  const handleCalculateCI = () => {
    const result = parseFloat(principalCI) * Math.pow(1 + (parseFloat(rateCI) / 100) / timesCompounded, timesCompounded * parseFloat(timeCI)) - parseFloat(principalCI);
    setCompoundInterest(result);
  };

  // Loan EMI Calculation
  const handleCalculateLoan = () => {
    const rateOfInterest = parseFloat(rateLoan) / 100 / 12;
    const months = parseFloat(timeLoan) * 12;
    const emiAmount = (parseFloat(loanAmount) * rateOfInterest * Math.pow(1 + rateOfInterest, months)) / (Math.pow(1 + rateOfInterest, months) - 1);
    setEmi(emiAmount);
  };

  return (
    <div className="calculator-container">
      <h1>Finance Calculator</h1>
      
      {/* Simple Interest Calculator */}
      <div className="calculator-box">
        <h2>Simple Interest Calculator</h2>
        <input
          type="number"
          placeholder="Principal (P)"
          value={principalSI}
          onChange={(e) => setPrincipalSI(e.target.value)}
        />
        <input
          type="number"
          placeholder="Rate of Interest (R)"
          value={rateSI}
          onChange={(e) => setRateSI(e.target.value)}
        />
        <input
          type="number"
          placeholder="Time (T in years)"
          value={timeSI}
          onChange={(e) => setTimeSI(e.target.value)}
        />
        <button className="next-btn" onClick={handleCalculateSI}>Calculate Simple Interest</button>
        {interestSI !== null && (
          <div className="result">
            <p>Simple Interest: ₹{interestSI}</p>
          </div>
        )}
      </div>

      {/* Compound Interest Calculator */}
      <div className="calculator-box">
        <h2>Compound Interest Calculator</h2>
        <input
          type="number"
          placeholder="Principal (P)"
          value={principalCI}
          onChange={(e) => setPrincipalCI(e.target.value)}
        />
        <input
          type="number"
          placeholder="Rate of Interest (R)"
          value={rateCI}
          onChange={(e) => setRateCI(e.target.value)}
        />
        <input
          type="number"
          placeholder="Time (T in years)"
          value={timeCI}
          onChange={(e) => setTimeCI(e.target.value)}
        />
        <input
          type="number"
          placeholder="Times Compounded per Year"
          value={timesCompounded}
          onChange={(e) => setTimesCompounded(e.target.value)}
        />
        <button className="next-btn" onClick={handleCalculateCI}>Calculate Compound Interest</button>
        {compoundInterest !== null && (
          <div className="result">
            <p>Compound Interest: ₹{compoundInterest.toFixed(2)}</p>
          </div>
        )}
      </div>

      {/* Loan EMI Calculator */}
      <div className="calculator-box">
        <h2>Loan EMI Calculator</h2>
        <input
          type="number"
          placeholder="Loan Amount"
          value={loanAmount}
          onChange={(e) => setLoanAmount(e.target.value)}
        />
        <input
          type="number"
          placeholder="Rate of Interest (R)"
          value={rateLoan}
          onChange={(e) => setRateLoan(e.target.value)}
        />
        <input
          type="number"
          placeholder="Time (T in years)"
          value={timeLoan}
          onChange={(e) => setTimeLoan(e.target.value)}
        />
        <button className="next-btn" onClick={handleCalculateLoan}>Calculate EMI</button>
        {emi !== null && (
          <div className="result">
            <p>EMI: ₹{emi.toFixed(2)}</p>
          </div>
        )}
      </div>
      <Financequiz />

    </div>
  );
};

export default FinanceCalculator;
