import React from 'react';
import './PrismTable.css'; // Importing the CSS file

const PrismTable = () => {
  return (
    <div className="table-container">
      <h1>Geometric Prisms Comparison</h1>
      <table className="prism-table">
        <thead>
          <tr>
            <th>Prism Type</th>
            <th>Base Shape</th>
            <th>Base Angle</th>
            <th>Base Symmetry</th>
            <th>Side Type</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Triangular Prism</td>
            <td>Triangle</td>
            <td>60° or 90° 
                </td>
                
            <td>Equilateral,
                 Isosceles,Scalene</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Square Prism</td>
            <td>Square</td>
            <td>90°</td>
            <td>Regular</td>
            <td>Square</td>
          </tr>
          <tr>
            <td>Rectangular Prism</td>
            <td>Rectangle</td>
            <td>90°</td>
            <td>Rectangular</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Pentagonal Prism</td>
            <td>Pentagon</td>
            <td>108°</td>
            <td>Regular</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Hexagonal Prism</td>
            <td>Hexagon</td>
            <td>120°</td>
            <td>Regular</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Octagonal Prism</td>
            <td>Octagon</td>
            <td>135°</td>
            <td>Regular</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Trapezoidal Prism</td>
            <td>Trapezoid</td>
            <td>Varies</td>
            <td>Irregular</td>
            <td>Rectangle</td>
          </tr>
          <tr>
            <td>Right Prism</td>
            <td>Any polygon</td>
            <td>90° (with vertical sides)</td>
            <td>Depends on polygon</td>
            <td>Perpendicular sides</td>
          </tr>
          <tr>
            <td>Oblique Prism</td>
            <td>Any parallelogram</td>
            <td>Varies</td>
            <td>Depends on parallelogram</td>
            <td>Slanted sides</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default PrismTable;
