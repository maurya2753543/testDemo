import React from 'react';
import './CombineApp.css';
import ConcaveMirror from './ConcaveMirror';
import ConvexLens from './ConvexLens';
import MirrorComparison from './MirrorComparison';
import MirrorQuiz from './MirrorQuiz';

const App = () => {
  return (
    <div>
              <h1 style={{margin : '20px'}}>Concave and Convex Mirrors</h1>
              <div className="app-container-mirror">
      
      <section>
        <h2>Concave Mirror</h2>
        <ConcaveMirror />
      </section>

      <section>
        <h2>Convex Lens</h2>
        <ConvexLens />
      </section>

      <section>
        <MirrorComparison />
      </section>
      <MirrorQuiz />
    </div>
    </div>
   
  );
};

export default App;
