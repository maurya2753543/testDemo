import React, { useState, useEffect } from "react";
import "./BoatAnimation.css";

const BoatAnimation = () => {
  const [boatSpeed, setBoatSpeed] = useState(30); // Boat speed in km/h
  const [currentSpeed, setCurrentSpeed] = useState(5); // River flow speed in km/h
  const [direction, setDirection] = useState("with"); // "with" or "against"
  const [time, setTime] = useState(0); // Time in hours
  const [distance, setDistance] = useState(0); // Distance in kilometers
  const [formula, setFormula] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prevTime) => {
        const newTime = prevTime + 0.1; // Increment time in hours
        const effectiveSpeed =
          direction === "with"
            ? boatSpeed + currentSpeed
            : boatSpeed - currentSpeed;

        if (effectiveSpeed > 0) {
          setDistance((newTime * effectiveSpeed).toFixed(2));
          setFormula(
            `Distance = Effective Speed × Time (Effective Speed = ${
              direction === "with"
                ? "Boat Speed + Current Speed"
                : "Boat Speed - Current Speed"
            })`
          );
        }
        return newTime;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [boatSpeed, currentSpeed, direction]);

  return (
    <>
     <div style={{ padding: "40px", margin: "10px" }}>
      <div className="river">
        {/* River */}
        <div className={`water ${direction === "with" ? "flow-with" : "flow-against"}`}></div>

        {/* Boat */}
        <div className={`boat ${direction === "with" ? "boat-with" : "boat-against"}`}>
          <div className="body"></div>
          <div className="sail"></div>
        </div>
      </div>

      {/* Controls */}
      <div style={{ marginTop: "20px" }}>
        <h2>Boat and River Animation</h2>
        <p>
          <strong>Boat Speed:</strong> {boatSpeed} km/h
        </p>
        <p>
          <strong>River Flow Speed:</strong> {currentSpeed} km/h
        </p>
        <p>
          <strong>Direction:</strong>{" "}
          <button className="next-btn" onClick={() => setDirection("with")}>With Current</button>{" "}
          <button className="next-btn" onClick={() => setDirection("against")}>Against Current</button>
        </p>
        <p>
          <strong>Time:</strong> {time.toFixed(2)} hours
        </p>
        <p>
          <strong>Distance:</strong> {distance} km
        </p>
        <p>
          <strong>Formula:</strong> {formula}
        </p>
      </div>
    </div>

    </>
   
    
  );
};

export default BoatAnimation;
