import React, { useState, useEffect } from "react";
import "./CarAnimation.css";
import BoatAnimation from "./BoatAnimation";
import TimeDistance from './TimeDistance';

const CarAnimation = () => {
  const [distance, setDistance] = useState(0); // in kilometers
  const [speed, setSpeed] = useState(60); // in km/h
  const [time, setTime] = useState(0); // in hours
  const [formula, setFormula] = useState("");

  useEffect(() => {
    // Update distance and time as the car "moves"
    const interval = setInterval(() => {
      setTime((prevTime) => {
        const newTime = prevTime + 0.1; // Increment time in hours (e.g., 0.1h = 6 minutes)
        setDistance((newTime * speed).toFixed(2)); // Distance = Speed × Time
        setFormula("Distance = Speed × Time");
        return newTime;
      });
    }, 1000);

    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, [speed]);

  return (
    <>
       <div style={{ padding: "40px", margin: "10px" }}>
      <div className="scene">
        {/* Road */}
        <div className="road"></div>

        {/* Car */}
        <div className="car">
          <div className="body"></div>
          <div className="wheel front-wheel"></div>
          <div className="wheel back-wheel"></div>
        </div>

        {/* Clouds */}
        <div className="cloud cloud1"></div>
        <div className="cloud cloud2"></div>
        <div className="cloud cloud3"></div>
      </div>

      {/* Information Section */}
      <div style={{ marginTop: "20px", padding: "20px", border: "1px solid #ccc", borderRadius: "8px", background: "#f9f9f9" }}>
        <h2>Time, Distance, and Speed in Action</h2>
        <p><strong>Speed:</strong> {speed} km/h</p>
        <p><strong>Time:</strong> {time.toFixed(2)} hours</p>
        <p><strong>Distance:</strong> {distance} km</p>
        <p><strong>Formula:</strong> {formula}</p>
      </div>
    </div>

<BoatAnimation />

<TimeDistance />
    </>
 
  );
};

export default CarAnimation;
