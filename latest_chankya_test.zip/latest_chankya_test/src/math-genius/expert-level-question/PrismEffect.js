import React, { useState } from 'react';
import './PrismEffect.css';
import PrismQuiz from './PrismQuiz';
import PrismTable from './PrismTable';
import OpticalPrismTable from './OpticalPrismTable'

const PrismDiagram = () => {
    const [showRays, setShowRays] = useState(false);

    const toggleRays = () => {
        setShowRays(!showRays);
    };

    return (
        <>
 <div className="diagram-container">
            <button onClick={toggleRays} className="toggle-button">
                {showRays ? 'Hide Rays' : 'Show Rays'}
            </button>
            <h1>Formation of a Spectrum: Light Rays Through a Prism</h1>
            <svg width="600" height="400" viewBox="0 0 600 400" className="prism-svg">
                {/* Prism with 7 colors */}
                <defs>
                    <linearGradient id="prismGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: 'red', stopOpacity: 1 }} />
                        <stop offset="14%" style={{ stopColor: 'orange', stopOpacity: 1 }} />
                        <stop offset="28%" style={{ stopColor: 'yellow', stopOpacity: 1 }} />
                        <stop offset="42%" style={{ stopColor: 'green', stopOpacity: 1 }} />
                        <stop offset="57%" style={{ stopColor: 'blue', stopOpacity: 1 }} />
                        <stop offset="71%" style={{ stopColor: 'indigo', stopOpacity: 1 }} />
                        <stop offset="85%" style={{ stopColor: 'violet', stopOpacity: 1 }} />
                    </linearGradient>
                </defs>
                <polygon
                    points="300,80 150,300 450,300"
                    fill="url(#prismGradient)"
                    stroke="blue"
                    strokeWidth="2"
                    className="prism-glow"
                />

                {/* Rays */}
                {showRays && (
                    <>
                        {/* Incident Ray */}
                        <line
                            x1="80"
                            y1="200"
                            x2="250"
                            y2="160"
                            stroke="purple"
                            strokeWidth="2"
                            strokeDasharray="5,5"
                            className="ray-glow"
                        />
                        <text x="60" y="200" fill="black" fontSize="10">
                            P
                        </text>
                        <text x="200" y="150" fill="black" fontSize="10">
                            Q
                        </text>
                        <text x="120" y="180" fill="black" fontSize="10">
                            PE (Incident Ray)
                        </text>

                        {/* Refracted Ray */}
                        <line
                            x1="250"
                            y1="160"
                            x2="350"
                            y2="240"
                            stroke="red"
                            strokeWidth="2"
                            strokeDasharray="5,5"
                            className="ray-glow"
                        />
                        <text x="270" y="180" fill="black" fontSize="10">
                            r (Angle of Refraction)
                        </text>
                        <text x="360" y="250" fill="black" fontSize="10">
                            EF (Refracted Ray)
                        </text>

                        {/* Emergent Ray */}
                        <line
                            x1="350"
                            y1="240"
                            x2="520"
                            y2="180"
                            stroke="magenta"
                            strokeWidth="2"
                            strokeDasharray="5,5"
                            className="ray-glow"
                        />
                        <text x="530" y="180" fill="black" fontSize="10">
                            R
                        </text>
                        <text x="400" y="220" fill="black" fontSize="10">
                            FS (Emergent Ray)
                        </text>

                        {/* Angles */}
                        <text x="300" y="100" fill="black" fontSize="10">
                            A (Angle of Prism)
                        </text>
                        <text x="250" y="140" fill="black" fontSize="10">
                            i (Angle of Incidence)
                        </text>
                        <text x="370" y="260" fill="black" fontSize="10">
                            e (Angle of Emergence)
                        </text>
                        <text x="420" y="200" fill="black" fontSize="10">
                            δ (Angle of Deviation)
                        </text>
                    </>
                )}
            </svg>

            {/* Legend */}
            <div className="legend">
                <h3>Legend</h3>
                <ul>
                    <li>PE: Incident Ray</li>
                    <li>EF: Refracted Ray</li>
                    <li>FS: Emergent Ray</li>
                    <li>A: Angle of Prism</li>
                    <li>i: Angle of Incidence</li>
                    <li>r: Angle of Refraction</li>
                    <li>e: Angle of Emergence</li>
                    <li>δ: Angle of Deviation</li>
                </ul>
            </div>
        </div>
        <div>
            <PrismTable />
            <OpticalPrismTable />

        </div>
        <div style={{marginTop : '100px'}}>
        <PrismQuiz />

        </div>

        </>
       
    );
};

export default PrismDiagram;
