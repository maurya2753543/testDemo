import React, { useState } from 'react';
import TimeDistance from './LadderClimbQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
          <h2>A man / Woman climbing a ladder Formulas</h2>
          <ul>
  <li><strong>Work Done Against Gravity</strong> = m × g × h</li>
  <li><strong>m</strong> = Mass of the man (kg)</li>
  <li><strong>g</strong> = Acceleration due to gravity (9.8 m/s²)</li>
  <li><strong>h</strong> = Vertical height climbed (m)</li>
  <li><strong>Vertical Component of Velocity</strong> = v × sin(θ)</li>
  <li><strong>Horizontal Component of Velocity</strong> = v × cos(θ)</li>
  <li><strong>Frictional Force at Base</strong> = μ × R</li>
  <li><strong>μ</strong> = Coefficient of friction</li>
  <li><strong>R</strong> = Reaction force at the base</li>
  <li><strong>Power Output While Climbing</strong> = (Work Done) ÷ Time</li>
  <li><strong>Work Done</strong> = m × g × h</li>
  <li><strong>Time</strong> = Time taken to climb (s)</li>
  <li><strong>Force Along Ladder</strong> = Weight × sin(θ)</li>
  <li><strong>Torque About the Base</strong> = Weight × Distance from base × cos(θ)</li>
  <li><strong>Height Reached</strong> = Length of ladder × sin(θ)</li>
  <li><strong>Distance from Wall</strong> = Length of ladder × cos(θ)</li>
  <li><strong>Force Required to Prevent Slipping</strong> = Weight × tan(θ)</li>
  <li><strong>Energy Used</strong> = Potential Energy Gained + Work Against Friction</li>
  <li><strong>Potential Energy Gained</strong> = m × g × h</li>
  <li><strong>Relative Motion Velocity</strong> = sqrt((v<sub>vertical</sub>)² + (v<sub>horizontal</sub>)²)</li>
  <li><strong>v<sub>vertical</sub></strong> = Vertical component of velocity</li>
  <li><strong>v<sub>horizontal</sub></strong> = Horizontal component of velocity</li>
</ul>


          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
