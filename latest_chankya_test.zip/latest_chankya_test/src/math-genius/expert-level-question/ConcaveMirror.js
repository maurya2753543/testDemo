import React, { useState } from 'react';
import './ConcaveMirror.css';

const ConcaveMirror = () => {
  const [animateRays, setAnimateRays] = useState(false);

  const handleClick = () => {
    setAnimateRays(!animateRays);
  };

  return (
    <div className="mirror-container">
      <div className="concave-mirror"></div>
      <div className={`rays ${animateRays ? 'active' : ''}`}>
        <div className="ray ray-left"></div>
        <div className="ray ray-center"></div>
        <div className="ray ray-right"></div>
      </div>
      <div className="intersection-point"></div>
      <button className="animate-btn" onClick={handleClick}>
        {animateRays ? 'Reset Rays' : 'Start Rays'}
      </button>
    </div>
  );
};

export default ConcaveMirror;
