import React, { useState } from 'react';
import TimeDistance from './PendulumQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
       <ul>
            <li>
                <strong>Time Period of a Simple Pendulum:</strong>{" "}
                <span>{`T = 2\\pi \\sqrt{\\frac{L}{g}}`}</span>
            </li>
            <li><strong>T</strong>: Time period (seconds)</li>
            <li><strong>L</strong>: Length of the pendulum (meters)</li>
            <li><strong>g</strong>: Acceleration due to gravity (m/s²)</li>

            <li>
                <strong>Frequency:</strong>{" "}
                <span>{`f = \\frac{1}{T}`}</span>
            </li>
            <li><strong>f</strong>: Frequency (Hz)</li>

            <li>
                <strong>Angular Frequency:</strong>{" "}
                <span>{`\\omega = \\sqrt{\\frac{g}{L}}`}</span>
            </li>
            <li><strong>\(\omega\)</strong>: Angular frequency (rad/s)</li>

            <li>
                <strong>Length of a Pendulum:</strong>{" "}
                <span>{`L = \\frac{g T^2}{4\\pi^2}`}</span>
            </li>

            <li>
                <strong>Time Period on a Different Planet:</strong>{" "}
                <span>{`T = 2\\pi \\sqrt{\\frac{L}{g_p}}`}</span>
            </li>
            <li><strong>g<sub>p</sub></strong>: Acceleration due to gravity on the planet (m/s²)</li>

            <li>
                <strong>Restoring Force:</strong>{" "}
                <span>{`F = -mg \\sin(\\theta)`}</span>
            </li>

            <li>
                <strong>Small Angle Approximation:</strong>{" "}
                <span>{`\\sin(\\theta) \\approx \\theta`}</span>
            </li>

            <li>
                <strong>Potential Energy of the Pendulum:</strong>{" "}
                <span>{`U = mgh`}</span>
            </li>
            <li><strong>U</strong>: Potential energy (J)</li>

            <li>
                <strong>Kinetic Energy of the Pendulum:</strong>{" "}
                <span>{`KE = \\frac{1}{2}mv^2`}</span>
            </li>
            <li><strong>KE</strong>: Kinetic energy (J)</li>

            <li>
                <strong>Total Mechanical Energy:</strong>{" "}
                <span>{`E = KE + U`}</span>
            </li>

            <li>
                <strong>Maximum Velocity:</strong>{" "}
                <span>{`v_{max} = \\sqrt{2g(L - h)}`}</span>
            </li>

            <li>
                <strong>Damped Oscillation Time Period:</strong>{" "}
                <span>{`T' = T \\sqrt{1 - \\frac{b^2}{4m^2}}`}</span>
            </li>

            <li>
                <strong>Oscillation for a Conical Pendulum:</strong>{" "}
                <span>{`T = 2\\pi \\sqrt{\\frac{L \\cos(\\theta)}{g}}`}</span>
            </li>
        </ul>

          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
