import React, { useState, useEffect } from "react";
import "./TrainAnimation.css";
import TimeDistanceLevelThree from './TimeDistanceLevelThree';
import AeroplaneAnimation from './AeroplaneAnimation';
const TrainAnimation = () => {
  const [speed, setSpeed] = useState(120); // Train speed in km/h
  const [windSpeed, setWindSpeed] = useState(15); // Wind speed in km/h
  const [direction, setDirection] = useState("with"); // "with" or "against"
  const [time, setTime] = useState(0); // Time in hours
  const [distance, setDistance] = useState(0); // Distance in kilometers
  const [formula, setFormula] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prevTime) => {
        const newTime = prevTime + 0.1; // Increment time in hours
        const effectiveSpeed =
          direction === "with" ? speed + windSpeed : speed - windSpeed;

        if (effectiveSpeed > 0) {
          setDistance((newTime * effectiveSpeed).toFixed(2));
          setFormula(
            `Distance = Effective Speed × Time (Effective Speed = ${
              direction === "with"
                ? "Speed + Wind Speed"
                : "Speed - Wind Speed"
            })`
          );
        }
        return newTime;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [speed, windSpeed, direction]);

  return (
    <div style={{ padding: "40px", margin: "10px" }}>
      <div className="scene">
        {/* Train Background */}
        <div className="station"></div>

        {/* Tracks */}
        <div className="tracks"></div>

        {/* Train */}
        <div
          className={`train ${direction === "with" ? "train-with" : "train-against"}`}
        >
          <div className="train-body"></div>
          <div className="train-wheels"></div>
          <div className="train-engine"></div>
        </div>

        {/* Clouds */}
        <div className="cloud cloud1"></div>
        <div className="cloud cloud2"></div>
        <div className="cloud cloud3"></div>
      </div>

      {/* Controls */}
      <div style={{ marginTop: "20px" }}>
        <h2>Train and Wind Animation</h2>
        <p>
          <strong>Train Speed:</strong> {speed} km/h
        </p>
        <p>
          <strong>Wind Speed:</strong> {windSpeed} km/h
        </p>
        <p>
          <strong>Direction:</strong>{" "}
          <button
            className="try-again-btn"
            onClick={() => setDirection("with")}
          >
            With Wind
          </button>{" "}
          <button
            className="try-again-btn"
            onClick={() => setDirection("against")}
          >
            Against Wind
          </button>
        </p>
        <p>
          <strong>Time:</strong> {time.toFixed(2)} hours
        </p>
        <p>
          <strong>Distance:</strong> {distance} km
        </p>
        <p>
          <strong>Formula:</strong> {formula}
        </p>
      </div>
      <AeroplaneAnimation />
      <TimeDistanceLevelThree />
    </div>
  );
};

export default TrainAnimation;
