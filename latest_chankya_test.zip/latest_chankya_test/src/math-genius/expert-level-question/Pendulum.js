import React, { useState } from "react";
import "./Pendulum.css";
import PendulumQuiz from "./PendulumQuiz";

const Pendulum = () => {
  const [angle, setAngle] = useState(30); // Initial angle in degrees
  const [length, setLength] = useState(1); // Pendulum length in meters
  const gravity = 9.8; // Acceleration due to gravity in m/s²

  // Calculate period of the pendulum
  const period = (2 * Math.PI * Math.sqrt(length / gravity)).toFixed(2);

  // Calculate restoring force
  const mass = 1; // Assuming mass of 1 kg for simplicity
  const restoringForce = (-mass * gravity * Math.sin((angle * Math.PI) / 180)).toFixed(2);

  // Handle changes
  const handleAngleChange = (e) => {
    setAngle(e.target.value);
  };

  const handleLengthChange = (e) => {
    setLength(e.target.value);
  };

  return (
    <div className="pendulum-container">
      <h1>Pendulum Simulation</h1>
      <div className="pendulum-box">
        <div
          className="pendulum"
          style={{
            transform: `rotate(${angle}deg)`,
            animation: `swing ${period}s infinite ease-in-out`,
          }}
        >
          <div className="pendulum-bob"></div>
        </div>
      </div>
      <div className="controls">
        <label>
          Angle (°):
          <input
            type="number"
            value={angle}
            onChange={handleAngleChange}
            min="-90"
            max="90"
          />
        </label>
        <label>
          Length (m):
          <input
            type="number"
            value={length}
            onChange={handleLengthChange}
            min="0.1"
          />
        </label>
      </div>
      <div className="info">
        <p>
          <strong>Period (T):</strong> {period} seconds
        </p>
        <p>
          <strong>Restoring Force (F):</strong> {restoringForce} N
        </p>
      </div>
      <PendulumQuiz />
    </div>
  );
};

export default Pendulum;
