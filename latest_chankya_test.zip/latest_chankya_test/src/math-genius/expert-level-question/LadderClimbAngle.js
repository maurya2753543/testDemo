import React, { useState } from 'react';
import './LadderClimbAngle.css';

const LadderClimb = () => {
  const [angle, setAngle] = useState(45); // Default angle in degrees
  const weight = 70; // Weight of the man in kg
  const ladderLength = 5; // Length of the ladder in meters
  const g = 9.8; // Acceleration due to gravity

  // Calculations
  const forceToPreventSlipping = (weight * g * Math.tan((angle * Math.PI) / 180)).toFixed(2);
  const torqueAtBase = (
    weight * g * ladderLength * Math.cos((angle * Math.PI) / 180)
  ).toFixed(2);

  return (
    <div className="ladder-climb-container-Angle">
      <h1>Adjust the Ladder Angle</h1>
      <div className="ladder-animation-Angle">
        <div
          className="ladder-Angle"
          style={{ transform: `rotate(-${90 - angle}deg)` }}
        ></div>
        <div className="man-Angle"></div>
      </div>

      <div className="controls">
        <label htmlFor="angleRange">Angle: {angle}°</label>
        <input
          id="angleRange"
          type="range"
          min="30"
          max="75"
          value={angle}
          onChange={(e) => setAngle(Number(e.target.value))}
        />
      </div>
      <div className="parameters">
        <p>
          <strong>Default Angle:</strong> {angle}°
        </p>
        <p>
          <strong>Weight of the Man:</strong> {weight} kg
        </p>
        <p>
          <strong>Ladder Length:</strong> {ladderLength} meters
        </p>
        <p>
          <strong>Acceleration Due to Gravity:</strong> {g} m/s²
        </p>
      </div>
      <div className="calculations">
        <ul>
          <li>
            <strong>Force Required to Prevent Slipping</strong>: {forceToPreventSlipping} N
          </li>
          <li>
            <strong>Torque About the Base</strong>: {torqueAtBase} Nm
          </li>
        </ul>
      </div>
    </div>
  );
};

export default LadderClimb;
