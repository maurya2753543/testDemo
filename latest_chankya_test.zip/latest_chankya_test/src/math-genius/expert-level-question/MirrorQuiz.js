import React, { useState } from 'react';
import TimeDistance from './MirrorQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
       <h2>Concave and Convex Lenses & Mirrors Formulas</h2>

<h3>Lens Formula</h3>
<ul>
  <li><strong>Lens Formula</strong> = 1/f = 1/v - 1/u</li>
  <li><strong>f</strong> = Focal Length</li>
  <li><strong>v</strong> = Image Distance</li>
  <li><strong>u</strong> = Object Distance</li>
</ul>

<h3>Magnification (Lenses)</h3>
<ul>
  <li><strong>Magnification (M)</strong> = Height of Image / Height of Object = v / u</li>
  <li><strong>Magnification (M)</strong> = Image Size / Object Size</li>
</ul>

<h3>Power of a Lens</h3>
<ul>
  <li><strong>Power of a Lens (P)</strong> = 1 / f</li>
  <li><strong>P</strong> = Power (in Diopters)</li>
  <li><strong>f</strong> = Focal Length (in meters)</li>
</ul>

<h3>Concave Lens Formulas</h3>
<ul>
  <li><strong>Concave Lens Magnification</strong> = Negative value (Image is virtual and diminished)</li>
  <li><strong>Image Distance</strong> = Negative (Image forms on the same side of the object)</li>
  <li><strong>Focal Length (Concave)</strong> = Negative value</li>
</ul>

<h3>Convex Lens Formulas</h3>
<ul>
  <li><strong>Convex Lens Magnification</strong> = Positive value (Image is real and magnified)</li>
  <li><strong>Image Distance</strong> = Positive (Image forms on the opposite side of the object)</li>
  <li><strong>Focal Length (Convex)</strong> = Positive value</li>
</ul>

<h3>Mirror Formula</h3>
<ul>
  <li><strong>Mirror Formula</strong> = 1/f = 1/v + 1/u</li>
  <li><strong>f</strong> = Focal Length</li>
  <li><strong>v</strong> = Image Distance</li>
  <li><strong>u</strong> = Object Distance</li>
</ul>

<h3>Magnification (Mirrors)</h3>
<ul>
  <li><strong>Magnification (M)</strong> = Height of Image / Height of Object = v / u</li>
  <li><strong>Magnification (M)</strong> = Image Size / Object Size</li>
</ul>

<h3>Concave Mirror Formulas</h3>
<ul>
  <li><strong>Concave Mirror Magnification</strong> = Positive or Negative value based on the position of the object (Image can be real or virtual)</li>
  <li><strong>Image Distance</strong> = Positive (for real image) or Negative (for virtual image)</li>
  <li><strong>Focal Length (Concave Mirror)</strong> = Negative value</li>
</ul>

<h3>Convex Mirror Formulas</h3>
<ul>
  <li><strong>Convex Mirror Magnification</strong> = Always negative (Image is virtual and diminished)</li>
  <li><strong>Image Distance</strong> = Negative (Image forms on the same side of the object)</li>
  <li><strong>Focal Length (Convex Mirror)</strong> = Positive value</li>
</ul>


          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
