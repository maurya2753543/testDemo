import React, { useState, useEffect } from "react";
import "./AeroplaneAnimation.css";

const AeroplaneAnimation = () => {
  const [speed, setSpeed] = useState(600); // Aeroplane speed in km/h
  const [windSpeed, setWindSpeed] = useState(50); // Wind speed in km/h
  const [direction, setDirection] = useState("with"); // "with" or "against"
  const [time, setTime] = useState(0); // Time in hours
  const [distance, setDistance] = useState(0); // Distance in kilometers
  const [formula, setFormula] = useState(""); // Formula description
  const [isRunning, setIsRunning] = useState(true); // Playback control (Running/Stopped)

  useEffect(() => {
    const interval = setInterval(() => {
      if (isRunning) {
        setTime((prevTime) => {
          const newTime = prevTime + 0.1; // Increment time in hours
          const effectiveSpeed =
            direction === "with" ? speed + windSpeed : speed - windSpeed;

          if (effectiveSpeed > 0) {
            setDistance((newTime * effectiveSpeed).toFixed(2));
            setFormula(
              `Distance = Effective Speed × Time (Effective Speed = ${
                direction === "with"
                  ? "Speed + Wind Speed"
                  : "Speed - Wind Speed"
              })`
            );
          }
          return newTime;
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [speed, windSpeed, direction, isRunning]);

  return (
    <div className="aeroplane-container">
      <div className="scene">
        {/* Sky Background */}
        <div className="sky"></div>

        {/* Clouds */}
        <div className="cloud cloud1"></div>
        <div className="cloud cloud2"></div>
        <div className="cloud cloud3"></div>

        {/* Birds */}
        <div className="bird bird1"></div>
        <div className="bird bird2"></div>
        <div className="bird bird3"></div>

        {/* Aeroplane */}
        <div
          className={`aeroplane ${direction === "with" ? "aeroplane-with" : "aeroplane-against"}`}
        >
          <div className="plane-body"></div>
          <div className="plane-wings"></div>
          <div className="plane-tail"></div>
        </div>
      </div>

      {/* Controls */}
      <div className="controls">
        <h2>Aeroplane and Wind Animation</h2>
        <p>
          <strong>Aeroplane Speed:</strong> {speed} km/h
        </p>
        <p>
          <strong>Wind Speed:</strong> {windSpeed} km/h
        </p>
        <p>
          <strong>Direction:</strong>{" "}
          <button className="button" onClick={() => setDirection("with")}>
            With Wind
          </button>{" "}
          <button className="button" onClick={() => setDirection("against")}>
            Against Wind
          </button>
        </p>
        <p>
          <strong>Time:</strong> {time.toFixed(2)} hours
        </p>
        <p>
          <strong>Distance:</strong> {distance} km
        </p>
        <p>
          <strong>Formula:</strong> {formula}
        </p>
        <button
          className="button"
          onClick={() => setIsRunning((prev) => !prev)}
        >
          {isRunning ? "Pause" : "Play"}
        </button>
      </div>
    </div>
  );
};

export default AeroplaneAnimation;
