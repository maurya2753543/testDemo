import React, { useState, useEffect, useRef } from 'react';
import './OhmsLawSimulator.css';
import OhmsLawSimulatorQuiz from './OhmsLawSimulatorQuiz';
const OhmsLawSimulator = () => {
  const [voltage, setVoltage] = useState(0); // Voltage in volts
  const [resistance, setResistance] = useState(1); // Resistance in ohms
  const [current, setCurrent] = useState(0); // Current in amperes
  const [dataPoints, setDataPoints] = useState([]); // To store voltage-current readings for graph
  const canvasRef = useRef(null); // Reference to the canvas element

  // Update current and record readings
  const calculateCurrent = () => {
    const newCurrent = voltage / resistance;
    setCurrent(newCurrent);

    // Add the new data point for graph
    setDataPoints((prevPoints) => [
      ...prevPoints,
      { voltage, current: newCurrent.toFixed(2) },
    ]);
  };

  // Draw the graph on the canvas
  const drawGraph = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Clear previous graph
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Set up the chart styles
    ctx.strokeStyle = '#007bff';
    ctx.fillStyle = 'rgba(0, 123, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]); // Dotted lines

    // Draw the axes
    ctx.beginPath();
    ctx.moveTo(50, 20); // Starting point for the x-axis
    ctx.lineTo(50, canvas.height - 30); // Ending point for the x-axis
    ctx.lineTo(canvas.width - 20, canvas.height - 30); // Ending point for the y-axis
    ctx.stroke();

    // Axis labels
    ctx.font = '14px Arial';
    ctx.fillStyle = '#000';
    ctx.fillText('Voltage (V)', canvas.width / 2 - 40, canvas.height - 10);
    ctx.fillText('Current (I)', 10, canvas.height / 2);

    // Plot the data points
    if (dataPoints.length > 0) {
      const maxVoltage = Math.max(...dataPoints.map((point) => point.voltage));
      const maxCurrent = Math.max(...dataPoints.map((point) => parseFloat(point.current)));

      const scaleX = (canvas.width - 80) / maxVoltage;
      const scaleY = (canvas.height - 60) / maxCurrent;

      ctx.beginPath();
      dataPoints.forEach((point, index) => {
        const x = 50 + point.voltage * scaleX;
        const y = canvas.height - 30 - point.current * scaleY;

        if (index === 0) {
          ctx.moveTo(x, y); // Start the line at the first point
        } else {
          ctx.lineTo(x, y); // Draw lines between points
        }

        // Draw intersection points
        ctx.arc(x, y, 4, 0, Math.PI * 2); // Draw dot at data point
        ctx.fillStyle = 'red';
        ctx.fill();
        ctx.stroke();
      });

      ctx.stroke();
      ctx.fillStyle = 'rgba(0, 123, 255, 0.2)';
      ctx.fill();
    }

    // Add Ammeter and Voltmeter data (assume fixed values for illustration)
    ctx.setLineDash([5, 2]); // Dash pattern for Ammeter/Voltmeter
    ctx.strokeStyle = '#28a745';
    ctx.beginPath();
    ctx.moveTo(50, 100);
    ctx.lineTo(canvas.width - 20, 100); // Ammeter line
    ctx.stroke();
    ctx.fillText('Ammeter', 10, 110);

    ctx.setLineDash([5, 2]); // Dash pattern for Voltmeter
    ctx.strokeStyle = '#dc3545';
    ctx.beginPath();
    ctx.moveTo(50, 150);
    ctx.lineTo(canvas.width - 20, 150); // Voltmeter line
    ctx.stroke();
    ctx.fillText('Voltmeter', 10, 160);
  };

  // Re-draw the graph whenever dataPoints change
  useEffect(() => {
    drawGraph();
  }, [dataPoints]);

  return (
    <div className="ohms-law-simulator">
      <h1>Ohm's Law Simulator</h1>

      {/* Circuit Diagram */}
      <div className="circuit-diagram">
        <div className="battery">Battery</div>
        <div className="resistor">Resistor (R = {resistance}Ω)</div>
        <div className="ammeter">Ammeter</div>
        <div className="voltmeter">Voltmeter</div>
      </div>

      {/* Controls */}
      <div className="controls">
        <label>
          Voltage (V):
          <input
            type="number"
            value={voltage}
            onChange={(e) => setVoltage(Number(e.target.value))}
          />
        </label>
        <label>
          Resistance (Ω):
          <input
            type="number"
            value={resistance}
            onChange={(e) => setResistance(Number(e.target.value))}
          />
        </label>
        <button onClick={calculateCurrent}>Calculate Current</button>
      </div>

      {/* Results */}
      <div className="results">
        <p>
          <strong>Current (I):</strong> {current.toFixed(2)} A
        </p>
        <p>
          <strong>Resistance (R):</strong> {resistance} Ω
        </p>
        <p>
          <strong>Voltage (V):</strong> {voltage} V
        </p>
      </div>

      {/* Graph */}
      <div className="graph-container">
        <h2>Graph: Voltage (V) vs Current (I)</h2>
        <canvas ref={canvasRef} width={600} height={400} />
      </div>
      <p><strong>Q1. Define electric current.</strong></p>
<p><strong>Ans:</strong> Electric current is defined as the rate of flow of electric charge in a conductor.</p>
<p>Where,</p>
<ul>
  <li><strong>I</strong> is the current in amperes</li>
  <li><strong>Q</strong> is the electric charge in coulombs</li>
  <li><strong>t</strong> is the time in seconds</li>
</ul>

<p><strong>Q2. What is the value of charge in 1 electron?</strong></p>
<p><strong>Ans:</strong> The value of charge in 1 electron is 1.6 × 10<sup>-19</sup> C.</p>

<p><strong>Q3. What is coulomb?</strong></p>
<p><strong>Ans:</strong> Coulomb is an SI unit of electric charge and is defined as the amount of charge present in 6.25 × 10<sup>18</sup> electrons.</p>

<p><strong>Q4. What is 1 volt?</strong></p>
<p><strong>Ans:</strong> If the work done in moving a charge of 1 Coulomb from one point to another is 1 Joule, then the potential difference between those two points is said to be 1 volt.</p>

<p><strong>Q5. What is 1 ohm?</strong></p>
<p><strong>Ans:</strong> The resistance of a conductor is said to be 1 ohm if a current of 1 ampere flows through it when a potential difference of 1 volt is applied across its ends.</p>

      <div style={{marginTop : '50px'}}>
      <OhmsLawSimulatorQuiz />

      </div>
    </div>
  );
};

export default OhmsLawSimulator;
