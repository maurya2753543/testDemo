import React, { useState } from 'react';
import TimeDistance from './TimeDistance.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
          <h2>Time, Speed, and Distance Formulas</h2>
          <ul>
            <li>Speed = Distance ÷ Time</li>
            <li>Distance = Speed × Time</li>
            <li>Time = Distance ÷ Speed</li>
            <li>Formula: Distance = Effective Speed × Time (Effective Speed = Boat Speed - Current Speed)</li>
            <li><strong>Effective Speed (Same Direction)</strong> = Motorcycle Speed + Wind Speed</li>
  <li><strong>Effective Speed (Opposite Direction)</strong> = Motorcycle Speed - Wind Speed</li>
  <li><strong>Distance (Same Direction)</strong> = (Motorcycle Speed + Wind Speed) × Time</li>
  <li><strong>Distance (Opposite Direction)</strong> = (Motorcycle Speed - Wind Speed) × Time</li>
  <li><strong>Time (Same Direction)</strong> = Distance ÷ (Motorcycle Speed + Wind Speed)</li>
  <li><strong>Time (Opposite Direction)</strong> = Distance ÷ (Motorcycle Speed - Wind Speed)</li>
          </ul>
          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
