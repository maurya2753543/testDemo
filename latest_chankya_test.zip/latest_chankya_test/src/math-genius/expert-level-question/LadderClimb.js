import React, { useState, useEffect } from 'react';
import './LadderClimb.css';
import LadderClimbQuiz from './LadderClimbQuiz';
import LadderClimbAngle from './LadderClimbAngle';

const LadderClimb = () => {
  const [direction, setDirection] = useState(null); // 'up' or 'down'
  const [position, setPosition] = useState(0); // Position of the man on the ladder (in %)
  const [speed, setSpeed] = useState(0); // Speed in % per second
  const [startTime, setStartTime] = useState(null);

  useEffect(() => {
    let climbInterval;

    if (direction) {
      setStartTime(Date.now());
      climbInterval = setInterval(() => {
        setPosition((prevPosition) => {
          if (direction === 'up' && prevPosition >= 100) {
            clearInterval(climbInterval);
            setDirection(null);
            return 100;
          }
          if (direction === 'down' && prevPosition <= 0) {
            clearInterval(climbInterval);
            setDirection(null);
            return 0;
          }
          return direction === 'up' ? prevPosition + 1 : prevPosition - 1;
        });
      }, 20); // Update position every 20ms for smooth animation
    } else {
      if (startTime) {
        const elapsedTime = (Date.now() - startTime) / 1000; // Time in seconds
        setSpeed((Math.abs(position - (direction === 'up' ? 0 : 100)) / elapsedTime).toFixed(2)); // Speed calculation
      }
    }

    return () => clearInterval(climbInterval);
  }, [direction]);

  return (
    <div className="ladder-container">
      <div className="ladder">
        <div
          className="man"
          style={{ bottom: `${position}%` }} // Move the man based on position
        ></div>
      </div>
      <div className="button-container">
        <button
          className="climb-button"
          onClick={() => setDirection(direction === 'up' ? null : 'up')}
        >
          {direction === 'up' ? 'Stop Going Up' : 'Go Up'}
        </button>
        <button
          className="climb-button"
          onClick={() => setDirection(direction === 'down' ? null : 'down')}
        >
          {direction === 'down' ? 'Stop Going Down' : 'Go Down'}
        </button>
      </div>
      <div className="stats">
        <p>Position: {position}%</p>
        <p>Speed: {direction ? 'Calculating...' : `${speed} %/s`}</p>
      </div>

       <LadderClimbAngle />
      <LadderClimbQuiz />
    </div>
  );
};

export default LadderClimb;
