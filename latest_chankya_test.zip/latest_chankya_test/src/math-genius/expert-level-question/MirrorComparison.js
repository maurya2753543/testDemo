import React from 'react';

const MirrorComparison = () => {
  const data = [
    { feature: 'Shape', concave: 'Inward-curved, like the inside of a sphere', convex: 'Outward-curved, like the outside of a sphere' },
    { feature: 'Focus', concave: 'Real, in front of the mirror', convex: 'Virtual, behind the mirror' },
    { feature: 'Reflection of Light', concave: 'Converging rays', convex: 'Diverging rays' },
    { feature: 'Image Formation', concave: 'Can form real or virtual images', convex: 'Always forms virtual, upright, diminished images' },
    { feature: 'Focal Length', concave: 'Positive focal length', convex: 'Negative focal length' },
    { feature: 'Magnification', concave: 'Varies (can be magnified or diminished)', convex: 'Always diminished' },
    { feature: 'Applications', concave: 'Shaving mirrors, telescopes, headlights', convex: 'Rear-view mirrors, security mirrors' },
  ];

  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    margin: '20px 0',
    fontFamily: 'Arial, sans-serif',
    textAlign: 'left',
  };

  const thStyle = {
    backgroundColor: '#007bff',
    color: 'white',
    padding: '10px',
    textTransform: 'uppercase',
    border: '1px solid #ddd',
  };

  const tdStyle = {
    padding: '10px',
    border: '1px solid #ddd',
  };

  const oddRowStyle = {
    backgroundColor: '#f4f4f4',
  };

  const hoverStyle = {
    backgroundColor: '#e7f3ff',
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: 'auto', textAlign: 'center' }}>
      <h1 style={{ fontSize: '24px', color: '#333', textTransform: 'uppercase', marginBottom: '20px' }}>Concave vs Convex Mirror</h1>
      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>Feature</th>
            <th style={thStyle}>Concave Mirror</th>
            <th style={thStyle}>Convex Mirror</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr
              key={index}
              style={index % 2 === 0 ? oddRowStyle : null}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = hoverStyle.backgroundColor)}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = index % 2 === 0 ? oddRowStyle.backgroundColor : 'transparent')}
            >
              <td style={tdStyle}>{row.feature}</td>
              <td style={tdStyle}>{row.concave}</td>
              <td style={tdStyle}>{row.convex}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MirrorComparison;
