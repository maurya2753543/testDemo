import React, { useState } from 'react';
import './ConvexLens.css';

const ConvexMirror = () => {
  const [animateRays, setAnimateRays] = useState(false);

  const handleClick = () => {
    setAnimateRays(!animateRays);
  };

  return (
    <div className="mirror-container">
      <div className="convex-mirror"></div>
      <div className={`rays ${animateRays ? 'active' : ''}`}>
        <div className="ray ray1"></div>
        <div className="ray ray2"></div>
        <div className="ray ray3"></div>
      </div>
      <button className="animate-btn" onClick={handleClick}>
        {animateRays ? 'Stop Rays' : 'Start Rays'}
      </button>
    </div>
  );
};

export default ConvexMirror;
