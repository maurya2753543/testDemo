import React, { useState } from 'react';
import TimeDistance from './PrismQuiz.json';
import '../TimeQuiz.css';

const QuizApp = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isAnswered, setIsAnswered] = useState(false); 
  const [isCorrect, setIsCorrect] = useState(false); 
  const [showFormulas, setShowFormulas] = useState(false); // To show/hide formulas

  const handleAnswerClick = (option) => {
    const correctAnswer = TimeDistance[currentQuestionIndex].answer;
    setIsAnswered(true);

    if (option === correctAnswer) {
      setScore(score + 1);
      setIsCorrect(true);
      setFeedback("Correct! 🎉");
    } else {
      setIsCorrect(false);
      setFeedback(`Wrong! The correct answer was ${correctAnswer}.`);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < TimeDistance.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setIsAnswered(false);
      setIsCorrect(false);
      setFeedback("");
    }
  };

  const handleTryAgain = () => {
    setIsAnswered(false);
    setIsCorrect(false);
    setFeedback("");
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <div className="quiz-container">
      <h1>Time Learning Quiz</h1>

      {/* Formula Icon */}
      <div className="formula-icon" onClick={toggleFormulas}>
      See Formula 📘
      </div>

      {/* Formula Modal */}
      {showFormulas && (
        <div className="formula-modal">
            <h1>Prism-related formulas</h1>
       <ul>
  <li><strong>Refractive Index</strong> = n = c / v</li>
  <li><strong>n</strong> = Refractive index of the medium</li>
  <li><strong>c</strong> = Speed of light in a vacuum (m/s)</li>
  <li><strong>v</strong> = Speed of light in the medium (m/s)</li>
  
  <li><strong>Snell's Law</strong> = n₁ × sin(θ₁) = n₂ × sin(θ₂)</li>
  <li><strong>n₁, n₂</strong> = Refractive indices of the two media</li>
  <li><strong>θ₁, θ₂</strong> = Angles of incidence and refraction</li>
  
  <li><strong>Critical Angle</strong> = θ<sub>c</sub> = sin⁻¹(1 / n)</li>
  <li><strong>n</strong> = Refractive index of the denser medium</li>
  
  <li><strong>Minimum Angle of Deviation</strong> = D<sub>min</sub> = (A × (n - 1))</li>
  <li><strong>D<sub>min</sub></strong> = Minimum deviation angle (degrees)</li>
  <li><strong>A</strong> = Refracting angle of the prism (degrees)</li>
  <li><strong>n</strong> = Refractive index of the prism</li>
  
  <li><strong>Refractive Index Using Angle of Deviation</strong> = n = (sin((A + D) / 2)) / (sin(A / 2))</li>
  <li><strong>A</strong> = Angle of the prism</li>
  <li><strong>D</strong> = Angle of deviation</li>
  
  <li><strong>Dispersion Formula</strong> = Δλ = λ₁ - λ₂</li>
  <li><strong>Δλ</strong> = Range of wavelengths (nm)</li>
  <li><strong>λ₁, λ₂</strong> = Wavelengths of light at different ends of the spectrum</li>
  
  <li><strong>Angular Dispersion</strong> = δ = (n<sub>v</sub> - n<sub>r</sub>) × A</li>
  <li><strong>n<sub>v</sub>, n<sub>r</sub></strong> = Refractive indices for violet and red light</li>
  <li><strong>A</strong> = Angle of the prism</li>
  
  <li><strong>Deviation for Thin Prisms</strong> = δ = (n - 1) × A</li>
  <li><strong>n</strong> = Refractive index of the material</li>
  <li><strong>A</strong> = Angle of the prism</li>
  
  <li><strong>Prism Power</strong> = P = 100 × (n - 1) × (A / d)</li>
  <li><strong>P</strong> = Prism power (diopters)</li>
  <li><strong>d</strong> = Base-to-apex distance of the prism (cm)</li>
  <li><strong>A</strong> = Angle of the prism</li>
  
  <li><strong>Total Deviation in Prism</strong> = δ = θ₁ + θ₂ - A</li>
  <li><strong>θ₁</strong> = Angle of incidence</li>
  <li><strong>θ₂</strong> = Angle of emergence</li>
  <li><strong>A</strong> = Angle of the prism</li>
  
  <li><strong>Refractive Index from Wavelength</strong> = n = A + (B / λ²)</li>
  <li><strong>A, B</strong> = Material constants</li>
  <li><strong>λ</strong> = Wavelength of light (m)</li>
</ul>




          <button onClick={toggleFormulas}>Close</button>
        </div>
      )}

      <div className="question-section">
        <p>Question {currentQuestionIndex + 1}: {TimeDistance[currentQuestionIndex].question}</p>
        <h6>Please take a copy and a pen to calculate and solve the problem.</h6>
        <h6>Click the correct option</h6>

        {TimeDistance[currentQuestionIndex].image && (
          <img src={TimeDistance[currentQuestionIndex].image} alt="Clock" />
        )}
      </div>
      <div className="options-section">
        {TimeDistance[currentQuestionIndex].options.map((option, index) => (
          <button 
            key={index} 
            onClick={() => handleAnswerClick(option)} 
            disabled={isAnswered} 
          >
            {option}
          </button>
        ))}
      </div>
      <div className="feedback-section">
        {feedback && <p>{feedback}</p>}
      </div>
      <div className="score-section">
        <p>Score: {score}</p>
      </div>

      <div className="action-section">
        {isAnswered && isCorrect && (
          <button className="next-btn" onClick={handleNextQuestion}>
            Next
          </button>
        )}
        {isAnswered && !isCorrect && (
          <button className="try-again-btn" onClick={handleTryAgain}>
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizApp;
