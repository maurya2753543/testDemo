import React from 'react';
import './AdditionVideoSteptwonumber.css'; // Import the CSS file

const MathSubtraction = () => {
  const examples = [
    {
      title: "Example 1: Simple Subtraction Without Borrowing",
      problem: "54 - 23",
      steps: [
        "Step 1: Subtract the ones place. 4 - 3 = 1. Write 1 in the ones place of the answer.",
        "Step 2: Subtract the tens place. 5 - 2 = 3. Write 3 in the tens place of the answer.",
        "Answer: 31",
      ],
    },
    {
      title: "Example 2: Subtraction With Borrowing",
      problem: "62 - 38",
      steps: [
        "Step 1: Subtract the ones place. 2 - 8 is not possible, so we need to borrow 1 from the tens place.",
        "Step 2: Borrow 1 from the 6 in the tens place, making it 5. Now, 12 - 8 = 4. Write 4 in the ones place.",
        "Step 3: Subtract the tens place. 5 - 3 = 2. Write 2 in the tens place.",
        "Answer: 24",
      ],
    },
    {
      title: "Example 3: Practice Problem Without Borrowing",
      problem: "73 - 31",
      steps: [
        "Step 1: Subtract the ones place. 3 - 1 = 2. Write 2 in the ones place.",
        "Step 2: Subtract the tens place. 7 - 3 = 4. Write 4 in the tens place.",
        "Answer: 42",
      ],
    },
    {
      title: "Example 4: Challenge Problem With Borrowing",
      problem: "81 - 47",
      steps: [
        "Step 1: Subtract the ones place. 1 - 7 is not possible, so borrow 1 from the tens place.",
        "Step 2: Borrow 1 from 8 in the tens place, making it 7. Now, 11 - 7 = 4. Write 4 in the ones place.",
        "Step 3: Subtract the tens place. 7 - 4 = 3. Write 3 in the tens place.",
        "Answer: 34",
      ],
    },
  ];

  return (
    <div className="math-container">
      <h1>Learn Two-Digit Subtraction</h1>
      {examples.map((example, index) => (
        <div className="card" key={index}>
          <h2>{example.title}</h2>
          <p>Problem: {example.problem}</p>
          {example.steps.map((step, stepIndex) => (
            <p key={stepIndex}>{step}</p>
          ))}
        </div>
      ))}
    </div>
  );
};

export default MathSubtraction;
