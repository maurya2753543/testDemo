import React from 'react';
import './AdditionVideoSteptwonumber.css'; // Import the CSS file

const MathMultiplication = () => {
  const examples = [
    {
      title: "Example 1: Multiply 23 by 11",
      problem: "23 × 11",
      steps: [
        "Step 1: Write down the two-digit number. 23.",
        "Step 2: Add the digits of 23 together. 2 + 3 = 5.",
        "Step 3: Place the sum between the original digits. 253.",
        "Answer: 253.",
      ],
    },
    {
      title: "Example 2: Multiply 47 by 11",
      problem: "47 × 11",
      steps: [
        "Step 1: Write down the two-digit number. 47.",
        "Step 2: Add the digits of 47 together. 4 + 7 = 11.",
        "Step 3: Write the 1 from 11 between 4 and 7, and carry over the other 1 to the next left digit. 517.",
        "Answer: 517.",
      ],
    },
    {
      title: "Example 3: Multiply 36 by 11",
      problem: "36 × 11",
      steps: [
        "Step 1: Write down the two-digit number. 36.",
        "Step 2: Add the digits of 36 together. 3 + 6 = 9.",
        "Step 3: Place the sum between the original digits. 396.",
        "Answer: 396.",
      ],
    },
    {
      title: "Example 4: Multiply 89 by 11",
      problem: "89 × 11",
      steps: [
        "Step 1: Write down the two-digit number. 89.",
        "Step 2: Add the digits of 89 together. 8 + 9 = 17.",
        "Step 3: Write the 7 between 8 and 9, carry over the 1. 979.",
        "Answer: 979.",
      ],
    },
  ];

  return (
    <div className="math-container">
      <h1>Learn Multiplication by 11</h1>
      {examples.map((example, index) => (
        <div className="card" key={index}>
          <h2>{example.title}</h2>
          <p>Problem: {example.problem}</p>
          {example.steps.map((step, stepIndex) => (
            <p key={stepIndex}>{step}</p>
          ))}
        </div>
      ))}
    </div>
  );
};

export default MathMultiplication;
