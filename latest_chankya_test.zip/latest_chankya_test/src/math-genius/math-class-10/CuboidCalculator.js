import React, { useState } from "react";
import { motion } from "framer-motion";
import "./CuboidCalculator.css"; // Make sure to create and style this CSS file
import Cuboid from '../../kbc/kbc-level-seven/Cuboid';

const CuboidCalculator = () => {
  const [length, setLength] = useState(""); // Length input
  const [width, setWidth] = useState(""); // Width input
  const [height, setHeight] = useState(""); // Height input
  const [volume, setVolume] = useState(null); // Calculated Volume
  const [lateralSurfaceArea, setLateralSurfaceArea] = useState(null); // Calculated Lateral Surface Area
  const [totalSurfaceArea, setTotalSurfaceArea] = useState(null); // Calculated Total Surface Area
  const [diagonal, setDiagonal] = useState(null); // Calculated Diagonal

  // Function to calculate Volume, Surface Areas, and Diagonal
  const calculateCuboid = () => {
    if (length && width && height) {
      const l = parseFloat(length);
      const w = parseFloat(width);
      const h = parseFloat(height);

      // Calculate Volume
      const calculatedVolume = l * w * h;

      // Calculate Lateral Surface Area
      const calculatedLateralSurfaceArea = 2 * h * (l + w);

      // Calculate Total Surface Area
      const calculatedTotalSurfaceArea = 2 * (l * w + l * h + h * w);

      // Calculate Diagonal
      const calculatedDiagonal = Math.sqrt(l * l + w * w + h * h);

      setVolume(calculatedVolume.toFixed(2)); // Display with 2 decimal places
      setLateralSurfaceArea(calculatedLateralSurfaceArea.toFixed(2)); // Display with 2 decimal places
      setTotalSurfaceArea(calculatedTotalSurfaceArea.toFixed(2)); // Display with 2 decimal places
      setDiagonal(calculatedDiagonal.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for length, width, and height.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="cuboid-container">
      <h1>Cuboid Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={length}
          onChange={(e) => setLength(e.target.value)}
          placeholder="Enter Length"
        />
        <input
          type="number"
          value={width}
          onChange={(e) => setWidth(e.target.value)}
          placeholder="Enter Width"
        />
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter Height"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateCuboid}>
        Calculate
      </button>

      {/* Display Results */}
      {volume && lateralSurfaceArea && totalSurfaceArea && diagonal && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Volume: {volume} cubic units</p>
          <p>Lateral Surface Area: {lateralSurfaceArea} square units</p>
          <p>Total Surface Area: {totalSurfaceArea} square units</p>
          <p>Diagonal: {diagonal} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Cuboid Visualization */}
      <div className="cuboid-visualization">
        <motion.div
          className="cuboid"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="cuboid-body">
            <span className="label length">Length</span>
            <span className="label width">Width</span>
            <span className="label height">Height</span>
            <span className="label diagonal">Diagonal</span>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Cuboid Formulas:</h2>
          <p>Volume = Length × Width × Height</p>
          <p>Lateral Surface Area = 2 × Height × (Length + Width)</p>
          <p>Total Surface Area = 2 × (Length × Width + Length × Height + Height × Width)</p>
          <p>Diagonal = √(Length² + Width² + Height²)</p>
        </div>
      )}
    </div>
    <div style={{marginTop: '40px'}}>
      <Cuboid />

    </div>
    </>
   
  );
};

export default CuboidCalculator;
