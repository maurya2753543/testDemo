import React, { useState } from "react";
import { motion } from "framer-motion";
import "./CardProbability.css";
import CardProbability from '../../kbc/kbc-level-seven/CardProbability';


const CardProbabilityQuiz = () => {
  const [drawnCard, setDrawnCard] = useState(null);
  const [remainingCards, setRemainingCards] = useState([
    "10♦", "J♦", "Q♦", "K♦", "A♦",
  ]);
  const [probabilities, setProbabilities] = useState({});

  // Calculate probabilities based on scenarios
  const calculateProbabilities = () => {
    const totalCards = 52;
    const redKings = 2;
    const faceCards = 12;
    const redFaceCards = 6;
    const jackOfHearts = 1;
    const spades = 13;
    const queenOfDiamonds = 1;

    setProbabilities({
      redKing: (redKings / totalCards).toFixed(2),
      faceCard: (faceCards / totalCards).toFixed(2),
      redFaceCard: (redFaceCards / totalCards).toFixed(2),
      jackOfHearts: (jackOfHearts / totalCards).toFixed(2),
      spade: (spades / totalCards).toFixed(2),
      queenOfDiamonds: (queenOfDiamonds / totalCards).toFixed(2),
    });
  };

  const handleDrawCard = () => {
    if (remainingCards.length === 0) return;
    const randomIndex = Math.floor(Math.random() * remainingCards.length);
    const card = remainingCards[randomIndex];
    setDrawnCard(card);
    setRemainingCards((prev) => prev.filter((_, i) => i !== randomIndex));
  };

  const resetDeck = () => {
    setRemainingCards(["10♦", "J♦", "Q♦", "K♦", "A♦"]);
    setDrawnCard(null);
    setProbabilities({});
  };

  return (
    <>
      <div className="card-probability-container">
      <h1>Card Probability Calculator</h1>

      <motion.div
        className="card-draw-area"
        animate={{ scale: drawnCard ? 1.2 : 1 }}
        transition={{ duration: 0.5 }}
      >
        {drawnCard ? (
          <motion.div
            className="drawn-card"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {drawnCard}
          </motion.div>
        ) : (
          <p>Click "Draw a Card" to pick a random card</p>
        )}
      </motion.div>

      <button className="button-card" onClick={handleDrawCard} disabled={remainingCards.length === 0}>
        Draw a Card
      </button>
      <button className="button-card" onClick={calculateProbabilities}>Calculate Probabilities</button>
      <button className="button-card" onClick={resetDeck}>Reset Deck</button>

      <div className="probabilities">
        <h2>Probabilities:</h2>
        {probabilities.redKing && (
          <ul>
            <li>
              Probability of a red king: {probabilities.redKing}
            </li>
            <li>
              Probability of a face card: {probabilities.faceCard}
            </li>
            <li>
              Probability of a red face card: {probabilities.redFaceCard}
            </li>
            <li>
              Probability of the jack of hearts: {probabilities.jackOfHearts}
            </li>
            <li>
              Probability of a spade: {probabilities.spade}
            </li>
            <li>
              Probability of the queen of diamonds: {probabilities.queenOfDiamonds}
            </li>
          </ul>
        )}
      </div>
    </div>
    <div style={{marginTop : "40px"}}>
      <CardProbability />
    </div>
    </>
  
  );
};

export default CardProbabilityQuiz;
