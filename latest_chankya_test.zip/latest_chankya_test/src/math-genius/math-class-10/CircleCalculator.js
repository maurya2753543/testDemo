import React, { useState } from "react";
import { motion } from "framer-motion";
import "./CircleCalculator.css"; // Ensure proper styles
import CircleDimensions from '../../kbc/kbc-level-seven/CircleDimensions';

const CircleCalculator = () => {
  const [radius, setRadius] = useState(""); // Radius input
  const [area, setArea] = useState(null); // Calculated area
  const [circumference, setCircumference] = useState(null); // Calculated circumference
  const [showResults, setShowResults] = useState(false); // Toggle results visibility
  const [showFormulas, setShowFormulas] = useState(false); // Toggle formulas visibility

  // Function to calculate Circle Area and Circumference
  const calculateCircle = () => {
    if (radius) {
      const r = parseFloat(radius);

      // Area = π * r²
      const calculatedArea = Math.PI * Math.pow(r, 2);

      // Circumference = 2 * π * r
      const calculatedCircumference = 2 * Math.PI * r;

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setCircumference(calculatedCircumference.toFixed(2)); // Display with 2 decimal places
      setShowResults(true); // Show results after calculation
    } else {
      alert("Please enter a valid value for Radius.");
    }
  };

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  const hideResults = () => {
    setShowResults(false); // Hide results
    setArea(null); // Reset area
    setCircumference(null); // Reset circumference
  };

  return (
    <>
     <div className="circle-calculator-container">
      <h1>Circle Calculator</h1>

      <div className="circle-input-container">
        <input
          type="number"
          value={radius}
          onChange={(e) => setRadius(e.target.value)}
          placeholder="Enter Radius (r)"
        />
      </div>

      {/* Calculate Button */}
      <button className="circle-calculate-button" onClick={calculateCircle}>
        Calculate
      </button>

      {/* Display Results */}
      {showResults && (
        <div className="circle-result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Circumference: {circumference} units</p>
          <button className="circle-hide-results" onClick={hideResults}>
            Hide Results
          </button>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="circle-formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Circle Visualization with Animation */}
      <div className="circle-visualization">
        <motion.div
          className="circle-animation"
          animate={{
            scale: [1, 1.2, 1], // Pulsating effect
          }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <div className="circle-body">
            {/* Label for radius */}
            <div className="circle-label radius" style={{ top: "50%", left: "50%" }}>
              r: {radius ? radius : "0"}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="circle-formula-container">
          <button className="circle-close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Circle Formulas:</h2>
          <p>Area = π × r²</p>
          <p>Circumference = 2 × π × r</p>
        </div>
      )}
    </div>
    <div style={{ marginTop : '40px'}}>
       <CircleDimensions />
    </div>
    </>
   
  );
};

export default CircleCalculator;
