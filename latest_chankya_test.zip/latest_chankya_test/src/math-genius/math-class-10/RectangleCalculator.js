import React, { useState } from "react";
import { motion } from "framer-motion";
import "./RectangleCalculator.css";
import Rectangle from '../../kbc/kbc-level-seven/Rectangle';

const RectangleCalculator = () => {
  const [length, setLength] = useState(""); // Length input
  const [breadth, setBreadth] = useState(""); // Breadth input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter
  const [diagonal, setDiagonal] = useState(null); // Calculated diagonal

  // Function to calculate Area, Perimeter, and Diagonal
  const calculateRectangle = () => {
    if (length && breadth) {
      const l = parseFloat(length);
      const b = parseFloat(breadth);

      const calculatedArea = l * b; // Area = length × breadth
      const calculatedPerimeter = 2 * (l + b); // Perimeter = 2(length + breadth)
      const calculatedDiagonal = Math.sqrt(l * l + b * b); // Diagonal = √(length² + breadth²)

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
      setDiagonal(calculatedDiagonal.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for Length and Breadth.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="rectangle-container">
      <h1>Rectangle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={length}
          onChange={(e) => setLength(e.target.value)}
          placeholder="Enter Length (l)"
        />
        <input
          type="number"
          value={breadth}
          onChange={(e) => setBreadth(e.target.value)}
          placeholder="Enter Breadth (b)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateRectangle}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && diagonal && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
          <p>Diagonal: {diagonal} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Rectangle Visualization */}
      <div className="rectangle-visualization">
        <motion.div
          className="rectangle"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="rectangle-body">
            {/* <span className="label length">l</span>
            <span className="label breadth">b</span> */}
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Rectangle Formulas:</h2>
          <p>Area = length × breadth</p>
          <p>Perimeter = 2 × (length + breadth)</p>
          <p>Diagonal = √(length² + breadth²)</p>
        </div>
      )}
    </div>
  
    <div style={{marginTop : '40px'}}>
         <Rectangle />
    </div>

    </>
   
  );
};

export default RectangleCalculator;
