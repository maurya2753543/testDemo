import React, { useState } from "react";
import { motion } from "framer-motion";
import "./IsoscelesTriangleCalculator.css";
import IsoscelesTriangle from '../../kbc/kbc-level-seven/IsoscelesTriangle';

const IsoscelesTriangleCalculator = () => {
  const [side, setSide] = useState(""); // Side input
  const [base, setBase] = useState(""); // Base input
  const [height, setHeight] = useState(""); // Height input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter

  // Function to calculate Area and Perimeter
  const calculateIsoscelesTriangle = () => {
    if (side && base && height) {
      const s = parseFloat(side);
      const b = parseFloat(base);
      const h = parseFloat(height);

      const calculatedArea = (h * b) / 2; // Area = (height × base) / 2
      const calculatedPerimeter = 2 * s + b; // Perimeter = 2 × side + base

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for Side, Base, and Height.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
      <div className="isosceles-triangle-container">
      {/* Updated Title */}
      <h1>Isosceles Triangle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={side}
          onChange={(e) => setSide(e.target.value)}
          placeholder="Enter Side (s)"
        />
        <input
          type="number"
          value={base}
          onChange={(e) => setBase(e.target.value)}
          placeholder="Enter Base (b)"
        />
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter Height (h)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateIsoscelesTriangle}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Isosceles Triangle Visualization */}
      <div className="triangle-visualization">
        <motion.div
          className="triangle"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          {/* <div className="triangle-body">
            <span className="label side">s</span>
            <span className="label base">b</span>
            <span className="label height">h</span>
          </div> */}
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Isosceles Triangle Formulas:</h2>
          <p>Area = (height × base) / 2</p>
          <p>Perimeter = 2 × side + base</p>
        </div>
      )}
    </div>
    <div style={{marginTop : '40px'}}>
        <IsoscelesTriangle />
    </div>
    </>
  
  );
};

export default IsoscelesTriangleCalculator;
