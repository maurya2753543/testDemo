import React, { useState } from 'react';
import './UnderstandingMean.css';
import Statistics from '../../kbc/kbc-level-seven/Statistics';

const UnderstandingMean = () => {
  const [data, setData] = useState([]);
  const [method, setMethod] = useState('direct');
  const [mean, setMean] = useState(null);
  const [median, setMedian] = useState(null);
  const [mode, setMode] = useState(null);
    const [showFormulas, setShowFormulas] = useState(false);
  
 // Toggle formula visibility
 const toggleFormulas = () => {
  setShowFormulas(!showFormulas);
};
  // Handle data change
  const handleDataChange = (event, index, field) => {
    const newData = [...data];
    newData[index][field] = event.target.value;
    setData(newData);
  };

  // Add a new row
  const addRow = () => {
    setData([...data, { xi: '', fi: '' }]);
  };

  // Remove a row
  const removeRow = (index) => {
    const newData = data.filter((_, i) => i !== index);
    setData(newData);
  };

  // Calculate mean
  const calculateMean = () => {
    if (method === 'direct') {
      const sumFiXi = data.reduce((acc, row) => acc + parseFloat(row.xi) * parseFloat(row.fi), 0);
      const sumFi = data.reduce((acc, row) => acc + parseFloat(row.fi), 0);
      setMean(sumFiXi / sumFi);
    }
    // Add calculations for Assumed Mean and Step Deviation methods here
  };

  // Calculate median
  const calculateMedian = () => {
    const n = data.reduce((acc, row) => acc + parseFloat(row.fi), 0);
    const cumulativeFreq = data.reduce(
      (acc, row, index) => [...acc, (acc[index - 1] || 0) + parseFloat(row.fi)],
      []
    );
    const medianClassIndex = cumulativeFreq.findIndex(cum => cum >= n / 2);
  
    // Check if medianClassIndex is valid before destructuring
    if (medianClassIndex !== -1) {
      const { xi, fi } = data[medianClassIndex];
      setMedian(xi); // Update with proper formula
    } else {
      setMedian('Not found'); // Handle error gracefully
    }
  };
  
  // Calculate mode
  const calculateMode = () => {
    // Implement the mode calculation using the provided formula
    setMode(data[0].xi); // Example - replace with correct logic
  };

  return (
    <>
     <div className="app-UnderstandingMean">
      <h1>Statistics Calculator</h1>
      <div className="method-selector">
        <button onClick={() => setMethod('direct')}>Direct Method</button>
        <button onClick={() => setMethod('assumed')}>Assumed Mean</button>
        <button onClick={() => setMethod('step-deviation')}>Step Deviation</button>
      </div>
      <div className="input-container">
        <h2>Enter Data</h2>
        <table>
          <thead>
            <tr>
              <th>Xi</th>
              <th>Fi</th>
              <th>Actions</th> {/* Add column for actions */}
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              <tr key={index}>
                <td>
                  <input
                    type="number"
                    value={row.xi}
                    onChange={(event) => handleDataChange(event, index, 'xi')}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    value={row.fi}
                    onChange={(event) => handleDataChange(event, index, 'fi')}
                  />
                </td>
                <td>
                  <button className="button-app-UnderstandingMean" onClick={() => removeRow(index)}>Remove</button> {/* Remove button */}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="button-app-UnderstandingMean" onClick={addRow}>Add Row</button>
      </div>
      <div className="button-container">
        <button className="button-app-UnderstandingMean" onClick={calculateMean}>Calculate Mean</button>
        <button className="button-app-UnderstandingMean" onClick={calculateMedian}>Calculate Median</button>
        <button className="button-app-UnderstandingMean" onClick={calculateMode}>Calculate Mode</button>
      </div>
      <div className="result-container">
        {mean !== null && <p>Mean: {mean}</p>}
        {median !== null && <p>Median: {median}</p>}
        {mode !== null && <p>Mode: {mode}</p>}
      </div>
      <button className="formula-icon" onClick={toggleFormulas}>
        Show Formulas
      </button>

      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h3>Mean of Grouped Data:</h3>
<h4>1. Direct Method:</h4>
<p>
  Mean (x̄) = <sup>∑fi xi</sup> / <sub>∑fi</sub>
</p>
<p>
  Where:
  <ul>
    <li>∑fi xi = the sum of observations from value i = 1 to n</li>
    <li>∑fi = the number of observations from value i = 1 to n</li>
  </ul>
</p>

<h4>2. Assumed Mean Method:</h4>
<p>
  Mean (x̄) = a + (<sup>∑fi di</sup> / <sub>∑fi</sub>)
</p>
<p>
  Where:
  <ul>
    <li>a = assumed mean</li>
    <li>di = deviation of a from each xi (di = xi – a)</li>
  </ul>
</p>

<h4>3. Step Deviation Method:</h4>
<p>
  Mean (x̄) = a + h × (<sup>∑fi ui</sup> / <sub>∑fi</sub>)
</p>
<p>
  Where:
  <ul>
    <li>ui = (xi – a) / h</li>
    <li>h = class size</li>
  </ul>
</p>

<h3>Mode of Grouped Data:</h3>
<p>
  Mode = l + <sup>(f1 – f0)</sup> / <sub>(2f1 – f0 – f2)</sub> × h
</p>
<p>
  Where:
  <ul>
    <li>l = lower limit of the modal class</li>
    <li>h = size of the class interval</li>
    <li>f1 = frequency of the modal class</li>
    <li>f0 = frequency of the class preceding the modal class</li>
    <li>f2 = frequency of the class succeeding the modal class</li>
  </ul>
</p>

<h3>Median of Grouped Data:</h3>
<p>
  Median = l + <sup>(n / 2 – cf)</sup> / <sub>f</sub> × h
</p>
<p>
  Where:
  <ul>
    <li>l = lower limit of the median class</li>
    <li>n = number of observations</li>
    <li>cf = cumulative frequency of the class preceding the median class</li>
    <li>f = frequency of the median class</li>
    <li>h = class size</li>
  </ul>
</p>

        </div>
      )}
    </div>
    <div style={{marginTop : '40px'}}>
   <Statistics />
    </div>
    
    </>
   
  );
};

export default UnderstandingMean;
