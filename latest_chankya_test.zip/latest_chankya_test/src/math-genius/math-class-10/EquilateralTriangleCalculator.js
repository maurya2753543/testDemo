import React, { useState } from "react";
import { motion } from "framer-motion";
import "./EquilateralTriangleCalculator.css";
import EquilateralTriangle from '../../kbc/kbc-level-seven/EquilateralTriangle';

const EquilateralTriangleCalculator = () => {
  const [side, setSide] = useState(""); // Side input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter

  // Function to calculate Area and Perimeter
  const calculateEquilateralTriangle = () => {
    if (side) {
      const s = parseFloat(side);

      const calculatedArea = (Math.sqrt(3) / 4) * Math.pow(s, 2); // Area = (√3 / 4) * side²
      const calculatedPerimeter = 3 * s; // Perimeter = 3 * side

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter a valid value for Side.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="equilateral-triangle-container">
      <h1>Equilateral Triangle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={side}
          onChange={(e) => setSide(e.target.value)}
          placeholder="Enter Side (s)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateEquilateralTriangle}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Equilateral Triangle Visualization */}
      <div className="triangle-visualization">
        <motion.div
          className="triangle"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="triangle-body">
            <span className="label side">s</span>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Equilateral Triangle Formulas:</h2>
          <p>Area = (√3 / 4) × side²</p>
          <p>Perimeter = 3 × side</p>
        </div>
      )}
    </div>

    <div style={{marginTop : '40px'}}>
   <EquilateralTriangle />
    </div>
    </>
   
  );
};

export default EquilateralTriangleCalculator;
