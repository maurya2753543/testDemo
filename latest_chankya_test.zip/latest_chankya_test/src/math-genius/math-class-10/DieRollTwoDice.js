import React, { useState } from "react";
import { motion } from "framer-motion";
import "./DieRoll.css";

const DieRollTwoDice = () => {
  const [rollResults, setRollResults] = useState([null, null]); // Store the results of two dice rolls
  const [isRolling, setIsRolling] = useState(false); // Track the rolling state
  const [inputNumber, setInputNumber] = useState(""); // User input for number
  const [greaterProbability, setGreaterProbability] = useState(null); // Probability for sum > input
  const [lessOrEqualProbability, setLessOrEqualProbability] = useState(null); // Probability for sum <= input

  // Simulate rolling two dice
  const rollDice = () => {
    setIsRolling(true);

    setTimeout(() => {
      const result1 = Math.floor(Math.random() * 6) + 1; // Random number between 1 and 6 for die 1
      const result2 = Math.floor(Math.random() * 6) + 1; // Random number between 1 and 6 for die 2
      setRollResults([result1, result2]);
      setIsRolling(false);
    }, 1000);
  };

  // Calculate probabilities for two dice
  const calculateProbabilities = () => {
    const totalOutcomes = 36; // Total possible outcomes (6x6)
    const userNumber = parseInt(inputNumber);

    if (userNumber >= 2 && userNumber <= 12) {
      // Outcomes greater than the input sum
      let greaterOutcomes = 0;
      let lessOrEqualOutcomes = 0;

      for (let die1 = 1; die1 <= 6; die1++) {
        for (let die2 = 1; die2 <= 6; die2++) {
          const sum = die1 + die2;
          if (sum > userNumber) greaterOutcomes++;
          if (sum <= userNumber) lessOrEqualOutcomes++;
        }
      }

      setGreaterProbability((greaterOutcomes / totalOutcomes).toFixed(2));
      setLessOrEqualProbability((lessOrEqualOutcomes / totalOutcomes).toFixed(2));
    } else {
      alert("Please enter a number between 2 and 12.");
    }
  };

  return (
    <>
      <div className="die-roll-container">
        <h1>Two Dice Roll Simulator & Probability Calculator</h1>

        {/* Die Animation */}
        <motion.div
          className={`die ${isRolling ? "rolling" : ""}`}
          animate={{ rotateY: isRolling ? [0, 180, 360] : 0 }}
          transition={{ duration: 1, ease: "easeInOut" }}
        >
          <div className="die-face">1st :- {rollResults[0] || "Die 1"} , </div>
          <div className="die-face">2nd :- {rollResults[1] || "Die 2"}</div>
        </motion.div>

        {/* Button to roll the dice */}
        <button onClick={rollDice} disabled={isRolling} className="roll-button">
          {isRolling ? "Rolling..." : "Roll Dice"}
        </button>

        {/* Dice Roll Results */}
        {!isRolling && rollResults[0] && rollResults[1] && (
          <div className="roll-results">
            <h2>Dice Roll Results:</h2>
            <p>Die 1: {rollResults[0]}</p>
            <p>Die 2: {rollResults[1]}</p>
            <p>Total: {rollResults[0] + rollResults[1]}</p>
          </div>
        )}
      </div>


      <div className="input-container-prob">
        <h2>Enter a Number (2-12) to Calculate Probabilities:</h2>
        <input
          type="number"
          min="2"
          max="12"
          value={inputNumber}
          onChange={(e) => setInputNumber(e.target.value)}
        />
        <button onClick={calculateProbabilities} className="calculate-button-prob">
          Calculate Probabilities
        </button>

        {greaterProbability && lessOrEqualProbability && (
          <div className="probability-results">
            <h3>Calculated Probabilities:</h3>
            <p>Probability of getting a number greater than {inputNumber}: {greaterProbability}</p>
            <p>Probability of getting a number less than or equal to {inputNumber}: {lessOrEqualProbability}</p>
          </div>
        )}
      </div>
    </>
  );
};

export default DieRollTwoDice;
