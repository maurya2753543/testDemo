import React, { useState } from "react";
import { motion } from "framer-motion";
import "./RightAngledTriangleCalculator.css"; // Make sure the CSS file matches
import RightAngledTriangle from '../../kbc/kbc-level-seven/RightAngledTriangle';


const RightAngledTriangleCalculator = () => {
  const [legA, setLegA] = useState(""); // First leg input
  const [legB, setLegB] = useState(""); // Second leg input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter
  const [hypotenuse, setHypotenuse] = useState(null); // Calculated hypotenuse

  // Function to calculate Area, Perimeter, and Hypotenuse
  const calculateRightAngledTriangle = () => {
    if (legA && legB) {
      const a = parseFloat(legA);
      const b = parseFloat(legB);

      // Calculate area
      const calculatedArea = (a * b) / 2;

      // Calculate hypotenuse (using Pythagoras' theorem)
      const calculatedHypotenuse = Math.sqrt(a * a + b * b);

      // Calculate perimeter
      const calculatedPerimeter = a + b + calculatedHypotenuse;

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setHypotenuse(calculatedHypotenuse.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for both legs.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
    <div className="right-angled-triangle-container">
      <h1>Right-Angled Triangle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={legA}
          onChange={(e) => setLegA(e.target.value)}
          placeholder="Enter Leg A"
        />
        <input
          type="number"
          value={legB}
          onChange={(e) => setLegB(e.target.value)}
          placeholder="Enter Leg B"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateRightAngledTriangle}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && hypotenuse && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
          <p>Hypotenuse: {hypotenuse} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Right-Angled Triangle Visualization */}
      <div className="triangle-visualization">
        <motion.div
          className="triangle"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="triangle-body">
            {/* <span className="label legA">leg A</span>
            <span className="label legB">leg B</span>
            <span className="label hypotenuse">hypotenuse</span> */}
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Right-Angled Triangle Formulas:</h2>
          <p>Area = (leg₁ × leg₂) / 2</p>
          <p>Perimeter = leg₁ + leg₂ + √(leg₁² + leg₂²)</p>
          <p>Hypotenuse = √(leg₁² + leg₂²)</p>
        </div>
      )}
    </div>
    <div style={{marginTop : '40px'}}>
         <RightAngledTriangle />
    </div>


    </>
    
  );
};

export default RightAngledTriangleCalculator;
