import React, { useState } from "react";
import "./FrustumCalculator.css";
import FrustumofCone from '../../kbc/kbc-level-seven/FrustumofCone';

const AppFrustum = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [radius1, setRadius1] = useState(""); // R (top radius)
  const [radius2, setRadius2] = useState(""); // r (bottom radius)
  const [height, setHeight] = useState("");  // h (vertical height)
  const [slantHeight, setSlantHeight] = useState(""); // l (slant height)
  const [CSA, setCSA] = useState("");
  const [TSA, setTSA] = useState("");
  const [volume, setVolume] = useState("");

  const calculateFrustum = () => {
    const R = parseFloat(radius1);
    const r = parseFloat(radius2);
    const h = parseFloat(height);
    const l = parseFloat(slantHeight);

    if (isNaN(R) || isNaN(r) || isNaN(h) || isNaN(l)) {
      alert("Please enter valid numbers for all fields.");
      return;
    }

    // CSA = πl(R + r)
    const calculatedCSA = Math.PI * l * (R + r);
    setCSA(calculatedCSA.toFixed(2));

    // TSA = CSA + π(R² + r²)
    const calculatedTSA = calculatedCSA + Math.PI * (R ** 2 + r ** 2);
    setTSA(calculatedTSA.toFixed(2));

    // Volume = (1/3)πh(R² + r² + Rr)
    const calculatedVolume = (1 / 3) * Math.PI * h * (R ** 2 + r ** 2 + R * r);
    setVolume(calculatedVolume.toFixed(2));
  };

  const handleOpenPopup = () => {
    setShowPopup(true);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  return (
    <>
    <div className="app">
      <h1>Frustum of a Cone Calculator</h1>
      <div className="animation-container">
        <div className="cone-container">
          <div className="cone">
            <div className="radius-line"></div>
            <div className="height-line"></div>
            <div className="annotations">
              <div className="r">R</div>
              <div className="h">H</div>
              <div className="l">L</div>
            </div>
          </div>
        </div>
        <div className="transform-text">Transforming to...</div>
        <div className="frustum-container">
          <div className="frustum">
            <div className="radius-line"></div>
            <div className="height-line"></div>
            <div className="annotations">
              <div className="r">R</div>
              <div className="r-small">r</div>
              <div className="h">H</div>
              <div className="l">L</div>
            </div>
          </div>
        </div>
      </div>

      <button onClick={handleOpenPopup} className="open-popup-btn">
        Show Formulas
      </button>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h2>Frustum of a Cone Formulas</h2>
            <ul style={{ listStyleType: "none", padding: 0, lineHeight: "2" }}>
        <li>
          <strong>Volume:</strong>{" "}
          <span>
            V = (1/3) &pi; h (R<sup>2</sup> + r<sup>2</sup> + Rr)
          </span>
        </li>
        <li>
          <strong>Curved Surface Area (CSA):</strong>{" "}
          <span>CSA = &pi; l (R + r)</span>
        </li>
        <li>
          <strong>Total Surface Area (TSA):</strong>{" "}
          <span>TSA = &pi; l (R + r) + &pi; R<sup>2</sup> + &pi; r<sup>2</sup></span>
        </li>
        <li>
          <strong>Slant Height:</strong>{" "}
          <span>l = &#8730;(h<sup>2</sup> + (R - r)<sup>2</sup>)</span>
        </li>
      </ul>
            <button className="close-popup-btn" onClick={handleClosePopup}>
              &times;
            </button>
          </div>
        </div>
      )}
    </div>
    <div className="Frustum-con">
     <h1>Frustum Calculator</h1>
     <div>
       <label>
         Top Radius (R):
         <input
           type="number"
           value={radius1}
           onChange={(e) => setRadius1(e.target.value)}
         />
       </label>
     </div>
     <div>
       <label>
         Bottom Radius (r):
         <input
           type="number"
           value={radius2}
           onChange={(e) => setRadius2(e.target.value)}
         />
       </label>
     </div>
     <div>
       <label>
         Height (h):
         <input
           type="number"
           value={height}
           onChange={(e) => setHeight(e.target.value)}
         />
       </label>
     </div>
     <div>
       <label>
         Slant Height (l):
         <input
           type="number"
           value={slantHeight}
           onChange={(e) => setSlantHeight(e.target.value)}
         />
       </label>
     </div>
     <button  className="open-popup-btn" onClick={calculateFrustum}>Calculate</button>
     <div>
       <h2>Results:</h2>
       <p>Curved Surface Area (CSA): {CSA} units²</p>
       <p>Total Surface Area (TSA): {TSA} units²</p>
       <p>Volume: {volume} units³</p>
     </div>
   </div>

   <div style={{marginTop : '40px'}}>
    <FrustumofCone />
    </div>
    </>
    
  );

  
   
    
};

export default AppFrustum;
