import React, { useState } from "react";
import { motion } from "framer-motion";
import "./ConeCalculator.css"; // Ensure proper styles
import Cone from '../../kbc/kbc-level-seven/Cone';

const ConeCalculator = () => {
  const [radius, setRadius] = useState(""); // Radius input
  const [height, setHeight] = useState(""); // Height input
  const [volume, setVolume] = useState(null); // Calculated volume
  const [curvedSurfaceArea, setCurvedSurfaceArea] = useState(null); // Calculated curved surface area
  const [totalSurfaceArea, setTotalSurfaceArea] = useState(null); // Calculated total surface area
  const [slantHeight, setSlantHeight] = useState(null); // Calculated slant height

  // Function to calculate Cone Volume, Surface Area, and Slant Height
  const calculateCone = () => {
    if (radius && height) {
      const r = parseFloat(radius);
      const h = parseFloat(height);

      // Volume = (1/3) * π * r² * h
      const calculatedVolume = (1 / 3) * Math.PI * Math.pow(r, 2) * h;

      // Curved Surface Area = π * r * h
      const calculatedCurvedSurfaceArea = Math.PI * r * h;

      // Slant Height = sqrt(r² + h²)
      const calculatedSlantHeight = Math.sqrt(Math.pow(r, 2) + Math.pow(h, 2));

      // Total Surface Area = π * r * (l + h)
      const calculatedTotalSurfaceArea = Math.PI * r * (calculatedSlantHeight + h);

      setVolume(calculatedVolume.toFixed(2)); // Display with 2 decimal places
      setCurvedSurfaceArea(calculatedCurvedSurfaceArea.toFixed(2)); // Display with 2 decimal places
      setTotalSurfaceArea(calculatedTotalSurfaceArea.toFixed(2)); // Display with 2 decimal places
      setSlantHeight(calculatedSlantHeight.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for Radius and Height.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="cone-container">
      <h1>Cone Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={radius}
          onChange={(e) => setRadius(e.target.value)}
          placeholder="Enter Radius (r)"
        />
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter Height (h)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateCone}>
        Calculate
      </button>

      {/* Display Results */}
      {volume && curvedSurfaceArea && totalSurfaceArea && slantHeight && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Volume: {volume} cubic units</p>
          <p>Curved Surface Area: {curvedSurfaceArea} square units</p>
          <p>Total Surface Area: {totalSurfaceArea} square units</p>
          <p>Slant Height: {slantHeight} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Cone Visualization with animation */}
      <div className="con-visualization-cal">
        <motion.div
          className="con-cal"
          animate={{ rotateY: [0, 360] }} // Rotation on Y-axis
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="cone-body">
            {/* Labels for r, h, and l */}
            <div className="label radius" style={{ top: "60%", left: "50%" }}>
              {/* r: {radius ? radius : "0"} */}
            </div>
            <div className="label height" style={{ top: "5%", left: "60%" }}>
              {/* h: {height ? height : "0"} */}
            </div>
            <div className="label slant-height" style={{ bottom: "20%", right: "20%", color: 'black' }}>
              {/* l */}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Cone Formulas:</h2>
          <p>Volume = (1/3) × π × r² × h</p>
          <p>Curved Surface Area = π × r × h</p>
          <p>Total Surface Area = π × r × (l + h)</p>
          <p>Slant Height = √(r² + h²)</p>
        </div>
      )}
    </div>
    <div style={{ marginTop: '40px'}}>
    <Cone />
    </div>
    </>
   
  );
};

export default ConeCalculator;
