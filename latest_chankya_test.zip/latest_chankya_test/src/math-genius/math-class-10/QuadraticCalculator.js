import React, { useState } from "react";
import "./QuadraticCalculator.css";
import QuadraticEquation from '../../kbc/kbc-level-seven/QuadraticEquation';

const QuadraticCalculator = () => {
  const [a, setA] = useState(""); // Coefficient a
  const [b, setB] = useState(""); // Coefficient b
  const [c, setC] = useState(""); // Coefficient c
  const [roots, setRoots] = useState(null); // Calculated roots
  const [discriminant, setDiscriminant] = useState(null); // Discriminant
  const [error, setError] = useState(null); // Error messages
  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };
  // Function to calculate the roots of the quadratic equation
  const calculateRoots = () => {
    if (!a || !b || !c) {
      setError("Please enter valid values for a, b, and c.");
      setRoots(null);
      return;
    }

    const aVal = parseFloat(a);
    const bVal = parseFloat(b);
    const cVal = parseFloat(c);

    if (aVal === 0) {
      setError("Coefficient 'a' cannot be 0 in a quadratic equation.");
      setRoots(null);
      return;
    }

    const discriminant = Math.pow(bVal, 2) - 4 * aVal * cVal; // b² - 4ac
    setDiscriminant(discriminant);

    if (discriminant > 0) {
      // Two distinct real roots
      const root1 = (-bVal + Math.sqrt(discriminant)) / (2 * aVal);
      const root2 = (-bVal - Math.sqrt(discriminant)) / (2 * aVal);
      setRoots([root1.toFixed(2), root2.toFixed(2)]);
      setError(null);
    } else if (discriminant === 0) {
      // One real root
      const root = -bVal / (2 * aVal);
      setRoots([root.toFixed(2)]);
      setError(null);
    } else {
      // No real roots
      setRoots(null);
      setError("The equation has no real roots.");
    }
  };

  return (
    <>
    <div className="quadratic-container">
      <h1>Quadratic Equation Calculator</h1>

      {/* Input fields for coefficients */}
      <div className="input-container">
        <input
          type="number"
          value={a}
          onChange={(e) => setA(e.target.value)}
          placeholder="Enter coefficient a"
        />
        <input
          type="number"
          value={b}
          onChange={(e) => setB(e.target.value)}
          placeholder="Enter coefficient b"
        />
        <input
          type="number"
          value={c}
          onChange={(e) => setC(e.target.value)}
          placeholder="Enter coefficient c"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button-cal" onClick={calculateRoots}>
        Calculate Roots
      </button>
      
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Display Results */}
      {error && <div className="error">{error}</div>}
      {roots && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Discriminant (b² - 4ac): {discriminant}</p>
          <p>Root(s): {roots.join(", ")}</p>
        </div>
      )}

      {/* Formula Display */}
      {showFormulas && (
        <div className="formula-container">
        <button className="close-formulas" onClick={toggleFormulas}>
              Close
            </button>
          <h2>Quadratic Formula:</h2>
          <p>Standard Form of Quadratic Equation: ax<sup>2</sup> + bx + c = 0, a ≠ 0</p>

<p>Quadratic Formula: -b &plusmn; &radic;D &divide; 2a or -b &plusmn; &radic;b<sup>2</sup> - 4ac &divide; 2a</p>

<p>Discriminant: D = b<sup>2</sup> - 4ac</p>

<p>Sum of Roots: &minus;b &divide; a</p>

<p>Product of Roots: c &divide; a</p>

          <p>
  x = &minus;b &plusmn; &radic;&nbsp;(b<sup>2</sup> &minus; 4ac) &divide; 2a
</p>

        </div>
      )}
     
    </div>
      <div style={{marginTop : '40px'}}>
        <QuadraticEquation />

      </div>
    </>
    
  );
};

export default QuadraticCalculator;
