import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './TriangleCalculator.css';
import TrinomatryArea from '../../kbc/kbc-level-seven/TrinomatryArea';


const TriangleCalculator = () => {
  // States for side lengths, calculated angles, area, and formula visibility
  const [sideA, setSideA] = useState(5);
  const [sideB, setSideB] = useState(6);
  const [sideC, setSideC] = useState(7);
  const [area, setArea] = useState(null);
  const [angles, setAngles] = useState({ angleA: null, angleB: null, angleC: null });
  const [showFormulas, setShowFormulas] = useState(false);

  // Heron's Formula for Area
  const calculateArea = (a, b, c) => {
    const s = (a + b + c) / 2;
    return Math.sqrt(s * (s - a) * (s - b) * (s - c));
  };

  // Law of Cosines for angles
  const calculateAngles = (a, b, c) => {
    const angleA = Math.acos((Math.pow(b, 2) + Math.pow(c, 2) - Math.pow(a, 2)) / (2 * b * c)) * (180 / Math.PI);
    const angleB = Math.acos((Math.pow(a, 2) + Math.pow(c, 2) - Math.pow(b, 2)) / (2 * a * c)) * (180 / Math.PI);
    const angleC = 180 - angleA - angleB; // Triangle sum property
    return { angleA, angleB, angleC };
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const newValue = parseFloat(value);

    if (name === 'sideA') setSideA(newValue);
    if (name === 'sideB') setSideB(newValue);
    if (name === 'sideC') setSideC(newValue);
  };

  // Perform calculations on button click
  const handleCalculate = () => {
    const newArea = calculateArea(sideA, sideB, sideC);
    const newAngles = calculateAngles(sideA, sideB, sideC);

    setArea(newArea);
    setAngles(newAngles);
  };

  // Toggle formula visibility
  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="triangle-container">
      <h1>Triangle Area & Angle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          name="sideA"
          value={sideA}
          onChange={handleInputChange}
          placeholder="Side A"
        />
        <input
          type="number"
          name="sideB"
          value={sideB}
          onChange={handleInputChange}
          placeholder="Side B"
        />
        <input
          type="number"
          name="sideC"
          value={sideC}
          onChange={handleInputChange}
          placeholder="Side C"
        />
      </div>

      <button className="calculate" onClick={handleCalculate}>
        Calculate
      </button>

      {area !== null && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area.toFixed(2)} square units</p>
          <p>Angle A: {angles.angleA.toFixed(2)}°</p>
          <p>Angle B: {angles.angleB.toFixed(2)}°</p>
          <p>Angle C: {angles.angleC.toFixed(2)}°</p>
        </div>
      )}

      <motion.div
        className="triangle"
        animate={{
          rotate: angles.angleA ? angles.angleA : 0,
          scaleX: 1,
        }}
        transition={{ type: 'spring', stiffness: 100 }}
      >
        <div className="triangle-shape"></div>
      </motion.div>

      <button className="formula-icon" onClick={toggleFormulas}>
        Show Formulas
      </button>

      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h3>Triangle Area Formula (Heron's Formula):</h3>
          <p>Area = √[s(s - a)(s - b)(s - c)]</p>
          <h3>Triangle Angle Formulas (Law of Cosines):</h3>
          <p>Angle A = cos⁻¹[(b² + c² - a²) / (2bc)]</p>
          <p>Angle B = cos⁻¹[(a² + c² - b²) / (2ac)]</p>
          <p>Angle C = 180° - (Angle A + Angle B)</p>
        </div>
      )}
    </div>
    <div style={{marginTop : '40px'}}>
    <TrinomatryArea />

    </div>
    </>
   
  );
};

export default TriangleCalculator;
