import React, { useState } from "react";
import { motion } from "framer-motion";
import "./HemisphereCalculator.css"; // Make sure to create the appropriate CSS file
import Hemisphere from '../../kbc/kbc-level-seven/Hemisphere';

const HemisphereCalculator = () => {
  const [radius, setRadius] = useState(""); // Radius input
  const [volume, setVolume] = useState(null); // Calculated volume
  const [surfaceArea, setSurfaceArea] = useState(null); // Calculated surface area

  // Function to calculate Volume and Surface Area of Hemisphere
  const calculateHemisphere = () => {
    if (radius) {
      const r = parseFloat(radius);

      // Volume = (2/3) * π * r³
      const calculatedVolume = (2 / 3) * Math.PI * Math.pow(r, 3);

      // Surface Area = 3 * π * r²
      const calculatedSurfaceArea = 3 * Math.PI * Math.pow(r, 2);

      setVolume(calculatedVolume.toFixed(2)); // Display with 2 decimal places
      setSurfaceArea(calculatedSurfaceArea.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter a valid value for Radius.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="hemisphere-container">
      <h1>Hemisphere Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={radius}
          onChange={(e) => setRadius(e.target.value)}
          placeholder="Enter Radius (r)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateHemisphere}>
        Calculate
      </button>

      {/* Display Results */}
      {volume && surfaceArea && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Volume: {volume} cubic units</p>
          <p>Surface Area: {surfaceArea} square units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Hemisphere Visualization */}
      <div className="hemisphere-visualization">
        <motion.div
          className="hemisphere-cal"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="hemisphere-body">
            <span className="label radius">r</span>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Hemisphere Formulas:</h2>
          <p>Volume = (2/3) × π × r³</p>
          <p>Surface Area = 3 × π × r²</p>
        </div>
      )}
    </div>

    <div style={{marginTop : '40px'}}>
      <Hemisphere />
    </div>

    </>
   
  );
};

export default HemisphereCalculator;
