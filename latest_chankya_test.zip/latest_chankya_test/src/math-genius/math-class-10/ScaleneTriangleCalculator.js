import React, { useState } from "react";
import { motion } from "framer-motion";
import "./ScaleneTriangleCalculator.css";
import ScaleneTriangle from '../../kbc/kbc-level-seven/ScaleneTriangle';



const ScaleneTriangleCalculator = () => {
  const [height, setHeight] = useState(""); // Height input
  const [base, setBase] = useState(""); // Base input
  const [sideA, setSideA] = useState(""); // Side A input
  const [sideB, setSideB] = useState(""); // Side B input
  const [sideC, setSideC] = useState(""); // Side C input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter

  // Function to calculate Area and Perimeter
  const calculateScaleneTriangle = () => {
    if (height && base && sideA && sideB && sideC) {
      const h = parseFloat(height);
      const b = parseFloat(base);
      const a = parseFloat(sideA);
      const c = parseFloat(sideB);

      const calculatedArea = (h * b) / 2; // Area = (height × base) / 2
      const calculatedPerimeter = a + b + c; // Perimeter = sideA + sideB + sideC

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for Height, Base, and Sides.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="scalene-triangle-container">
      <h1>Scalene Triangle Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter Height (h)"
        />
        <input
          type="number"
          value={base}
          onChange={(e) => setBase(e.target.value)}
          placeholder="Enter Base (b)"
        />
        <input
          type="number"
          value={sideA}
          onChange={(e) => setSideA(e.target.value)}
          placeholder="Enter Side A"
        />
        <input
          type="number"
          value={sideB}
          onChange={(e) => setSideB(e.target.value)}
          placeholder="Enter Side B"
        />
        <input
          type="number"
          value={sideC}
          onChange={(e) => setSideC(e.target.value)}
          placeholder="Enter Side C"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateScaleneTriangle}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Scalene Triangle Visualization */}
      <div className="triangle-visualization">
        <motion.div
          className="triangle"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="triangle-body">
            {/* <span className="label height">h</span>
            <span className="label base">b</span>
            <span className="label sideA">a</span>
            <span className="label sideB">b</span>
            <span className="label sideC">c</span> */}
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Scalene Triangle Formulas:</h2>
          <p>Area = (height × base) / 2</p>
          <p>Perimeter = side A + side B + side C</p>
        </div>
      )}
    </div>
    <div style={{marginTop : '40px'}}>
           <ScaleneTriangle />
    </div>
    </>
   
  );
};

export default ScaleneTriangleCalculator;
