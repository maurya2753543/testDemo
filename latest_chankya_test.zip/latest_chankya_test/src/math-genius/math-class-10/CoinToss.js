import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './CoinToss.css';  // Ensure to style the coin and container
import Cointossed from '../../kbc/kbc-level-seven/Cointossed';

const CoinToss = () => {
  const [tossResult, setTossResult] = useState(null); // Store the result of the toss
  const [isTossing, setIsTossing] = useState(false); // Check if the coin is tossing

  // Function to simulate coin toss
  const tossCoin = () => {
    setIsTossing(true); // Set the tossing state to true

    // After the animation completes, set the toss result
    setTimeout(() => {
      const result = Math.random() < 0.5 ? 'Head' : 'Tail'; // Randomly choose Head or Tail
      setTossResult(result);
      setIsTossing(false); // Stop tossing animation
    }, 1000); // Duration of toss animation
  };

  return (
    <>
 <div className="coin-toss-container">
      <h1>Coin Toss Simulator</h1>

      {/* Coin Toss Animation */}
      <motion.div
        className={`coin ${isTossing ? 'tossing' : ''}`} // Add tossing class for animation
        animate={{ rotateY: isTossing ? [0, 180, 360] : 0 }} // Rotate coin on Y-axis
        transition={{ duration: 1, ease: 'easeInOut' }} // Duration and easing
      >
        <div className={`coin-side ${tossResult === 'Head' ? 'head' : 'tail'}`}>
          {tossResult || 'Tossing...'}
        </div>
      </motion.div>

      {/* Button to toss the coin */}
      <button onClick={tossCoin} disabled={isTossing} className="toss-button">
        {isTossing ? 'Tossing...' : 'Toss Coin'}
      </button>

      {/* Probability of heads or tails */}
      {!isTossing && tossResult && (
        <div className="probability">
          <h2>Probability:</h2>
          <p>Probability of getting a head: 1/2</p>
          <p>Probability of getting a tail: 1/2</p>
        </div>
      )}
    </div>
    <div style={{ marginTop: '40px'}}>
      <Cointossed />
        </div>
    </>
   
  );
};

export default CoinToss;
