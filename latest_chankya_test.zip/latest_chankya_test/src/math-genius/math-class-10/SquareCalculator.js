import React, { useState } from "react";
import { motion } from "framer-motion";
import "./SquareCalculator.css";
import Square from '../../kbc/kbc-level-seven/Square';

const SquareCalculator = () => {
  const [side, setSide] = useState(""); // Side length input
  const [area, setArea] = useState(null); // Calculated area
  const [perimeter, setPerimeter] = useState(null); // Calculated perimeter
  const [showFormulas, setShowFormulas] = useState(false); // Toggle formulas display

  // Function to calculate Area and Perimeter
  const calculateSquare = () => {
    if (side) {
      const s = parseFloat(side);

      const calculatedArea = Math.pow(s, 2); // Area = side²
      const calculatedPerimeter = 4 * s; // Perimeter = 4 × side

      setArea(calculatedArea.toFixed(2)); // Display with 2 decimal places
      setPerimeter(calculatedPerimeter.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter a valid value for Side length.");
    }
  };

  // Toggle formulas visibility
  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="square-container">
      <h1>Square Calculator</h1>

      {/* Input field for Side length */}
      <div className="input-container">
        <input
          type="number"
          value={side}
          onChange={(e) => setSide(e.target.value)}
          placeholder="Enter Side Length (s)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateSquare}>
        Calculate
      </button>

      {/* Display Results */}
      {area && perimeter && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Area: {area} square units</p>
          <p>Perimeter: {perimeter} units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Square Visualization */}
      <div className="square-visualization">
        <motion.div
          className="square"
          animate={{ rotate: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="square-body">
            <span className="label side">s</span>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Square Formulas:</h2>
          <p>Area = side²</p>
          <p>Perimeter = 4 × side</p>
        </div>
      )}
    </div>
     <div style={{marginTop : '40px'}}>
      <Square />

    </div>
    </>
   
  );
};

export default SquareCalculator;
