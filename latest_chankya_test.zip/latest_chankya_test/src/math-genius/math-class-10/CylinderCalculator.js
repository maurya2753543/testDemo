import React, { useState } from "react";
import { motion } from "framer-motion";
import "./CylinderCalculator.css";
import Cylinder from '../../kbc/kbc-level-seven/Cylinder';


const CylinderCalculator = () => {
 

  const [radius, setRadius] = useState(""); // Radius input
  const [height, setHeight] = useState(""); // Height input
  const [volume, setVolume] = useState(null); // Calculated volume
  const [surfaceArea, setSurfaceArea] = useState(null); // Calculated surface area

  // Function to calculate Volume and Surface Area
  const calculateCylinder = () => {
    if (radius && height) {
      const r = parseFloat(radius);
      const h = parseFloat(height);

      const calculatedVolume = Math.PI * r * r * h; // Volume = πr²h
      const calculatedSurfaceArea = 2 * Math.PI * r * h + 2 * Math.PI * r * r; // Surface Area = 2πrh + 2πr²

      setVolume(calculatedVolume.toFixed(2)); // Display with 2 decimal places
      setSurfaceArea(calculatedSurfaceArea.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter valid values for Radius and Height.");
    }
  };

  const [showFormulas, setShowFormulas] = useState(false);

  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="cylinder-container">
      <h1>2D Cylinder Calculator</h1>

      <div className="input-container">
        <input
          type="number"
          value={radius}
          onChange={(e) => setRadius(e.target.value)}
          placeholder="Enter Radius (r)"
        />
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter Height (h)"
        />
      </div>
      
       {/* Calculate Button */}
       <button className="calculate-button" onClick={calculateCylinder}>
        Calculate
      </button>
       {/* Display Results */}
       {volume && surfaceArea && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Volume: {volume} cubic units</p>
          <p>Surface Area: {surfaceArea} square units</p>
        </div>
      )}


      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      <div className="cylinder-visualization">
        <motion.div
          className="cylinder-cal"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="cylinder-base top"></div>
          <div className="cylinder-body">
            <div className="dotted-line"></div>
            <span className="label-cal radius">r</span>
            <span className="label-cal height">h</span>
          </div>
          <div className="cylinder-base bottom"></div>
        </motion.div>
      </div>

      {showFormulas && (
        <div className="formula-container">
              <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Cylinder Formulas:</h2>
          <p>Volume = π × r² × h</p>
          <p>Surface Area = 2 × π × r × (r + h)</p>
          <p>Curved Surface Area = 2 × π × r × h</p>
        </div>
      )}
    </div>
    <div style={{ marginTop : '40px'}}>
  <Cylinder />
    </div>
    </>
   
  );
};

export default CylinderCalculator;
