import React, { useState } from "react";
import { motion } from "framer-motion";
import "./SphereCalculator.css";
import Sphere from '../../kbc/kbc-level-seven/Sphere';

const SphereCalculator = () => {
  const [radius, setRadius] = useState(""); // Radius input
  const [volume, setVolume] = useState(null); // Calculated volume
  const [surfaceArea, setSurfaceArea] = useState(null); // Calculated surface area
  const [showFormulas, setShowFormulas] = useState(false); // Toggle formulas display

  // Function to calculate Volume and Surface Area
  const calculateSphere = () => {
    if (radius) {
      const r = parseFloat(radius);

      const calculatedVolume = (4 / 3) * Math.PI * Math.pow(r, 3); // Volume = (4/3)πr³
      const calculatedSurfaceArea = 4 * Math.PI * Math.pow(r, 2); // Surface Area = 4πr²

      setVolume(calculatedVolume.toFixed(2)); // Display with 2 decimal places
      setSurfaceArea(calculatedSurfaceArea.toFixed(2)); // Display with 2 decimal places
    } else {
      alert("Please enter a valid value for Radius.");
    }
  };

  // Toggle formulas visibility
  const toggleFormulas = () => {
    setShowFormulas(!showFormulas);
  };

  return (
    <>
     <div className="sphere-container">
      <h1>2D Sphere Calculator</h1>

      {/* Input field for Radius */}
      <div className="input-container">
        <input
          type="number"
          value={radius}
          onChange={(e) => setRadius(e.target.value)}
          placeholder="Enter Radius (r)"
        />
      </div>

      {/* Calculate Button */}
      <button className="calculate-button" onClick={calculateSphere}>
        Calculate
      </button>

      {/* Display Results */}
      {volume && surfaceArea && (
        <div className="result-container">
          <h2>Results:</h2>
          <p>Volume: {volume} cubic units</p>
          <p>Surface Area: {surfaceArea} square units</p>
        </div>
      )}

      {/* Toggle Formulas Button */}
      <button className="formula-toggle" onClick={toggleFormulas}>
        {showFormulas ? "Hide Formulas" : "Show Formulas"}
      </button>

      {/* Sphere Visualization */}
      <div className="sphere-visualization">
        <motion.div
          className="sphere"
          animate={{ rotateY: [0, 360] }}
          transition={{ repeat: Infinity, duration: 5 }}
        >
          <div className="sphere-body">
            <span className="label radius">r</span>
          </div>
        </motion.div>
      </div>

      {/* Formulas Display */}
      {showFormulas && (
        <div className="formula-container">
          <button className="close-formulas" onClick={toggleFormulas}>
            Close
          </button>
          <h2>Sphere Formulas:</h2>
          <p>Volume = (4/3) × π × r³</p>
          <p>Surface Area = 4 × π × r²</p>
        </div>
      )}
    </div>
      <div style={{marginTop : '40px'}}>
  <Sphere />
       </div>
    </>
   
  );
};

export default SphereCalculator;
