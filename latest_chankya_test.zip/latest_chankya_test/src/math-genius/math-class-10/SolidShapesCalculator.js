import React, { useState } from "react";
import "./SolidShapesCalculator.css";
import CombinationofSolids from '../../kbc/kbc-level-seven/CombinationofSolids';

const SolidShapesCalculator = () => {
  const [showPopup, setShowPopup] = useState(false);

  const handleOpenPopup = () => setShowPopup(true);
  const handleClosePopup = () => setShowPopup(false);

  return (
    <>
      <div className="app">
        <h1>Combination of Solids</h1>

        <div className="shapes-container">
          {/* Circus Tent */}
          <div className="shape-item">
            <h2>Circus Tent</h2>
            <p>
              A circus tent is a combination of a cylinder and a cone. Some
              circus tents may also include a cuboid and a cone.
            </p>
            <div className="animation-container">
              <div className="cylinder"></div>
              <div className="cone"></div>
            </div>
          </div>

          {/* Ice Cream Cone */}
          <div className="shape-item">
            <h2>Ice Cream Cone</h2>
            <p>An ice cream cone combines a cone and a hemisphere.</p>
            <div className="animation-container">
              <div className="cone"></div>
              <div className="hemisphere"></div>
            </div>
          </div>

          {/* Dome */}
          <div className="shape-item">
            <h2>Dome on a Solid Shape</h2>
            <p>
              A dome is the upper half of a hemisphere. It can be combined with
              buildings or tents to create a unique structure.
            </p>
            <div className="animation-container">
              <div className="cuboid"></div>
              <div className="hemisphere"></div>
            </div>
          </div>
        </div>

        <button onClick={handleOpenPopup} className="open-popup-btn">
          Show Formulas
        </button>

        {showPopup && (
          <div className="popup">
            <div className="popup-content">
              <h2>Formulas for Combined Solids</h2>
              <ul style={{ listStyleType: "none", padding: 0, lineHeight: "2" }}>
                <li>
                  <strong>Circus Tent (Cylinder + Cone):</strong>
                  <br />
                  <span>Volume = &pi; r<sup>2</sup>h + (1/3)&pi; r<sup>2</sup>h</span>
                  <br />
                  <span>CSA = 2&pi; rh + &pi; rl</span>
                </li>
                <li>
                  <strong>Ice Cream Cone (Cone + Hemisphere):</strong>
                  <br />
                  <span>
                    Volume = (1/3)&pi; r<sup>2</sup>h + (2/3)&pi; r<sup>3</sup>
                  </span>
                  <br />
                  <span>CSA = &pi; rl + 2&pi; r<sup>2</sup></span>
                </li>
                <li>
                  <strong>Dome on a Solid Shape:</strong>
                  <br />
                  <span>
                    Volume = Solid Volume + (2/3)&pi; r<sup>3</sup>
                  </span>
                  <br />
                  <span>CSA = Solid CSA + &pi; r<sup>2</sup></span>
                </li>
              </ul>
              <button className="close-popup-btn" onClick={handleClosePopup}>
                &times;
              </button>
            </div>
          </div>
        )}
      </div>

      <div style={{marginTop : '40px'}}>
  <CombinationofSolids />
      </div>
    </>
  );
};

export default SolidShapesCalculator;
