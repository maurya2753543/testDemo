import React, { useState } from "react";
import { motion } from "framer-motion";
import "./DieRoll.css";
import DieRollTwoDice from './DieRollTwoDice';
import DieRoll from '../../kbc/kbc-level-seven/DieRoll';

const DieRollcal = () => {
  const [rollResult, setRollResult] = useState(null); // Store the result of the roll
  const [isRolling, setIsRolling] = useState(false); // Track the rolling state
  const [inputNumber, setInputNumber] = useState(""); // User input for number
  const [greaterProbability, setGreaterProbability] = useState(null); // Probability for numbers > input
  const [lessOrEqualProbability, setLessOrEqualProbability] = useState(null); // Probability for numbers <= input

  // Simulate die roll
  const rollDie = () => {
    setIsRolling(true);

    setTimeout(() => {
      const result = Math.floor(Math.random() * 6) + 1; // Random number between 1 and 6
      setRollResult(result);
      setIsRolling(false);
    }, 1000);
  };

  // Calculate probabilities based on user input
  const calculateProbabilities = () => {
    const totalOutcomes = 6; // Total die outcomes (1 to 6)
    const userNumber = parseInt(inputNumber);

    if (userNumber >= 1 && userNumber <= 6) {
      const greaterOutcomes = totalOutcomes - userNumber; // Outcomes greater than input
      const lessOrEqualOutcomes = userNumber; // Outcomes less than or equal to input

      setGreaterProbability((greaterOutcomes / totalOutcomes).toFixed(2));
      setLessOrEqualProbability((lessOrEqualOutcomes / totalOutcomes).toFixed(2));
    } else {
      alert("Please enter a number between 1 and 6.");
    }
  };

  return (
    <>
      <div className="die-roll-container">
        <h1>Die Roll Simulator & Probability Calculator</h1>

        {/* Die Animation */}
        <motion.div
          className={`die ${isRolling ? "rolling" : ""}`}
          animate={{ rotateY: isRolling ? [0, 180, 360] : 0 }}
          transition={{ duration: 1, ease: "easeInOut" }}
        >
          <div className="die-face">{rollResult || "Rolling..."}</div>
        </motion.div>

        {/* Button to roll the die */}
        <button onClick={rollDie} disabled={isRolling} className="roll-button">
          {isRolling ? "Rolling..." : "Roll Die"}
        </button>

        {/* Probability Display */}
        {!isRolling && rollResult && (
          <div className="probability">
            <h2>Die Roll Result:</h2>
            <p>You rolled a {rollResult}</p>
          </div>
        )}
      </div>

      <div className="input-container-prob">
        <h2>Enter a Number (1-6) to Calculate Probabilities:</h2>
        <input
          type="number"
          min="1"
          max="6"
          value={inputNumber}
          onChange={(e) => setInputNumber(e.target.value)}
        />
        <button onClick={calculateProbabilities} className="calculate-button-prob">
          Calculate Probabilities
        </button>

        {greaterProbability && lessOrEqualProbability && (
          <div className="probability-results">
            <h3>Calculated Probabilities:</h3>
            <p>Probability of getting a number greater than {inputNumber}: {greaterProbability}</p>
            <p>Probability of getting a number less than or equal to {inputNumber}: {lessOrEqualProbability}</p>
          </div>
        )}
      </div>
      <DieRollTwoDice />

      <div style={{marginTop : '40px'}}>
        <DieRoll />
    </div>
    </>
  );
};

export default DieRollcal;
