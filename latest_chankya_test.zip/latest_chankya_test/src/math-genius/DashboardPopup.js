import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./DashboardPopup.css"; // Create a CSS file for styling

const DashboardPopup = ({ onClose }) => {
  const navigate = useNavigate(); // Initialize useNavigate

  const handleOkClick = () => {
    navigate('/dashboard'); // Navigate to the dashboard
  };

  return (
    <div className="dashboard-popup-overlay">
      <div className="dashboard-popup-content">
        <p>Are you sure you want to go to the Dashboard page?</p> {/* Confirmation message */}
        <button className="dashboard-popup-button" onClick={handleOkClick}>OK</button> {/* OK button */}
        <button className="dashboard-popup-button-close" onClick={onClose}>Close</button> {/* Close button */}
      </div>
    </div>
  );
};

export default DashboardPopup;
