import React, { useState } from 'react';
import './EnglishBook.css';

const grammarRules = [
  { 
    "title": "Pronouns", 
    "content": "Pronouns are words that replace nouns or noun phrases. There are several types of pronouns, including personal, possessive, demonstrative, indefinite, reflexive, and relative.",
    "examples": [
      "She is going to the store.", 
      "They are my friends."
    ]
  },
  { 
    "title": "Subject Pronouns",
    "content": "Subject pronouns are used when the pronoun is the subject of the sentence. You can remember subject pronouns easily by filling in the blank subject space for a simple sentence.",
    "examples": [
      "___ did the job. (I, he, she, we, they, who, whoever, etc.)"
    ]
  },
  { 
    "title": "Pronouns",
    "content": "Pronouns are words that replace nouns or noun phrases. There are several types of pronouns, including personal, possessive, demonstrative, indefinite, reflexive, and relative.",
    "examples": [
      "She is going to the store.", 
      "They are my friends."
    ]
  },
  { 
    "title": "Conjunctions", 
    "content": "Conjunctions are used to connect ideas or short phrases. Examples of conjunctions include 'and', 'because', 'but', and 'so'.",
    "examples": [
      "I want to go, but I have to work.",
      "He likes tea and coffee."
    ]
  },
  { 
    "title": "Subject Pronouns with to be Verbs", 
    "content": "Subject pronouns are used if they rename the subject, following to be verbs like is, are, was, were, am, will be, had been.",
    "examples": [
      "It is he.",
      "This is she speaking.",
      "It is we who are responsible for the decision."
    ]
  },
  { 
    "title": "Pronouns after Who", 
    "content": "When who refers to a personal pronoun (I, you, he, she, we, they), it takes the verb that agrees with that pronoun.",
    "examples": [
      "It is I who am sorry.",
      "It is you who are mistaken."
    ]
  },
  { 
    "title": "Object Pronouns", 
    "content": "Object pronouns include me, him, herself, us, them, themselves, and are used as the direct object, indirect object, or object of a preposition.",
    "examples": [
      "Jean saw him.",
      "Give her the book.",
      "Are you talking to me?"
    ]
  },
  { 
    "title": "Pronouns Who, That, and Which", 
    "content": "Pronouns who, that, and which become singular or plural depending on the subject. If the subject is singular, use a singular verb, and if plural, use a plural verb.",
    "examples": [
      "He is the only one of those men who is always on time.",
      "He is one of those men who are always on time."
    ]
  },
  { 
    "title": "Singular Pronouns with Singular Verbs", 
    "content": "Singular pronouns like I, he, she, everyone, each, etc., require singular verbs, even if followed by of.",
    "examples": [
      "Each of the girls sings well.",
      "Either of us is capable of doing the job."
    ]
  },
  { 
    "title": "Pronouns After Than or As", 
    "content": "To decide whether to use the subject or object pronoun after than or as, mentally complete the sentence.",
    "examples": [
      "Tranh is as smart as she is.",
      "Zoe is taller than I am."
    ]
  },
  { 
    "title": "Possessive Pronouns", 
    "content": "Possessive pronouns like yours, his, hers, its, ours, theirs, and whose never need apostrophes.",
    "examples": [
      "It's been a cold morning.",
      "The thermometer reached its highest reading."
    ]
  },
  { 
    "title": "Apostrophes in It's and Who's", 
    "content": "The only time it's has an apostrophe is when it is a contraction for it is or it has. The only time who's has an apostrophe is when it means who is or who has.",
    "examples": [
      "It's been a cold morning.",
      "He's the one who's always on time."
    ]
  },
  { 
    "title": "Reflexive Pronouns", 
    "content": "Reflexive pronouns are used when both the subject and object of a verb are the same person or thing.",
    "examples": [
      "Joe helped himself.",
      "Joe bought it for himself."
    ]
  },
  { 
    "title": "Singular They", 
    "content": "When gender-neutral language is desired, use they, them, their, etc., with singular nouns or pronouns.",
    "examples": [
      "Someone has to do it, and they have to do it well.",
      "If you see anyone on the trail, tell them to be careful."
    ]
  },
  { 
    "title": "Avoiding Gendered Pronouns", 
    "content": "When rewriting is not practical and gender-neutrality is desired, use they, them, their, etc., to avoid using gendered pronouns.",
    "examples": [
      "No one realizes when their time is up.",
      "Tell anyone you see on the trail to be careful."
    ]
  },
  { 
    "title": "Pronouns with And", 
    "content": "When a pronoun is linked with a noun by and, mentally remove the and + noun phrase to avoid errors.",
    "examples": [
      "She and her friend came over.",
      "I invited him and his wife."
    ]
  },
  { 
    "title": "Conjunctions", 
    "content": "Conjunctions are used to connect ideas or short phrases. Examples of conjunctions include 'and', 'because', 'but', and 'so'.",
    "examples": [
      "I want to go, but I have to work.",
      "He likes tea and coffee."
    ]
  },
  {  
    "title": "Coordinating Conjunctions", 
    "content": "Coordinating conjunctions connect words, phrases, or clauses that are of equal importance. The most common coordinating conjunctions are for, and, nor, but, or, yet, and so.",
    "examples": [
      "I want to go to the park, but it's raining.",
      "She studied hard, yet she failed the test."
    ]
  },
  {  
    "title": "Subordinating Conjunctions", 
    "content": "Subordinating conjunctions connect a dependent clause to an independent clause, showing a relationship between the two. Common subordinating conjunctions include because, although, since, if, and unless.",
    "examples": [
      "She went to bed early because she was tired.",
      "I'll go if you want to come."
    ]
  },
  {  
    "title": "Correlative Conjunctions", 
    "content": "Correlative conjunctions are pairs of conjunctions that work together to connect words, phrases, or clauses. Some common pairs are either/or, neither/nor, both/and, not only/but also.",
    "examples": [
      "He is not only smart but also hardworking.",
      "Either you leave now, or you'll be late."
    ]
  },
  {  
    "title": "Coordinating Conjunctions", 
    "content": "Coordinating conjunctions connect words, phrases, or clauses that are of equal importance. The most common coordinating conjunctions are for, and, nor, but, or, yet, and so.",
    "examples": [
      "I want to go to the park, but it's raining.",
      "She studied hard, yet she failed the test."
    ]
  },
  {  
    "title": "Subordinating Conjunctions", 
    "content": "Subordinating conjunctions connect a dependent clause to an independent clause, showing a relationship between the two. Common subordinating conjunctions include because, although, since, if, and unless.",
    "examples": [
      "She went to bed early because she was tired.",
      "I'll go if you want to come."
    ]
  },
  {  
    "title": "Correlative Conjunctions", 
    "content": "Correlative conjunctions are pairs of conjunctions that work together to connect words, phrases, or clauses. Some common pairs are either/or, neither/nor, both/and, not only/but also.",
    "examples": [
      "He is not only smart but also hardworking.",
      "Either you leave now, or you'll be late."
    ]
  },
  {  
    "title": "Conjunctions of Time", 
    "content": "Conjunctions of time connect clauses that describe when an action takes place. Common conjunctions of time include when, before, after, while, and until.",
    "examples": [
      "She called me when she arrived.",
      "I will wait here until you come back."
    ]
  },
  {  
    "title": "Conjunctions of Condition", 
    "content": "Conjunctions of condition link a dependent clause that expresses a condition with the main clause. Common conjunctions of condition are if, unless, and provided that.",
    "examples": [
      "I will go if you go.",
      "You won't pass unless you study."
    ]
  },
  {  
    "title": "Conjunctions of Contrast", 
    "content": "Conjunctions of contrast show a difference or opposition between two ideas. Common conjunctions of contrast include although, though, even though, and whereas.",
    "examples": [
      "Although it was raining, they went for a walk.",
      "She likes coffee, whereas he prefers tea."
    ]
  },
  {  
    "title": "Conjunctions of Purpose", 
    "content": "Conjunctions of purpose connect clauses that show the intention or goal behind an action. Some common conjunctions of purpose are so that, in order that, and for the purpose of.",
    "examples": [
      "She studied hard so that she could pass the exam.",
      "He worked overtime in order that he could finish the project."
    ]
  },
  {  
    "title": "Conjunctions of Result", 
    "content": "Conjunctions of result connect clauses showing the outcome of an action. Common conjunctions of result include so, as a result, and consequently.",
    "examples": [
      "She was tired, so she went to bed early.",
      "The meeting ran late, and as a result, we missed the train."
    ]
  },
  { 
    "title": "Adjectives and Adverbs", 
    "content": "Adjectives describe, identify, and quantify people or things. They usually come before a noun. Adverbs modify verbs, adjectives, and other adverbs. They usually come after the verb.",
    "examples": [
      "She wore a red dress. (Adjective)",
      "He ran quickly. (Adverb)"
    ]
  },
  {  
    "title": "Adjectives of Quantity", 
    "content": "Adjectives of quantity describe the amount or quantity of something. Common adjectives of quantity include some, few, many, all, several, enough, and much.",
    "examples": [
      "I have many books.",
      "There were enough cookies for everyone."
    ]
  },
  {  
    "title": "Adjectives of Quality", 
    "content": "Adjectives of quality describe the quality or characteristics of a noun. Some examples include good, bad, beautiful, ugly, tall, short, and clever.",
    "examples": [
      "She is a good dancer.",
      "It was a beautiful day."
    ]
  },
  {  
    "title": "Demonstrative Adjectives", 
    "content": "Demonstrative adjectives are used to point out specific things. Common demonstrative adjectives include this, that, these, and those.",
    "examples": [
      "This book is interesting.",
      "Those shoes are expensive."
    ]
  },
  {  
    "title": "Possessive Adjectives", 
    "content": "Possessive adjectives show ownership or possession. They include my, your, his, her, its, our, and their.",
    "examples": [
      "This is my car.",
      "Their house is large."
    ]
  },
  {  
    "title": "Interrogative Adjectives", 
    "content": "Interrogative adjectives are used to ask questions about nouns. The common interrogative adjectives are which, what, and whose.",
    "examples": [
      "Which color do you prefer?",
      "What book are you reading?"
    ]
  },
  {  
    "title": "Comparative Adjectives", 
    "content": "Comparative adjectives compare two nouns. They are formed by adding -er or using more/less. Common comparative adjectives include bigger, smaller, taller, more expensive, and less interesting.",
    "examples": [
      "My car is faster than hers.",
      "This book is more interesting than the other one."
    ]
  },
  {  
    "title": "Superlative Adjectives", 
    "content": "Superlative adjectives compare more than two nouns and show the highest degree of quality. They are formed by adding -est or using most/least. Examples include tallest, biggest, best, and least expensive.",
    "examples": [
      "He is the tallest player on the team.",
      "This is the best pizza I've ever had."
    ]
  },
  {  
    "title": "Adverbs of Manner", 
    "content": "Adverbs of manner describe how an action is performed. They are typically formed by adding -ly to adjectives. Examples include quickly, slowly, easily, and carefully.",
    "examples": [
      "She sings beautifully.",
      "He drives very carefully."
    ]
  },
  {  
    "title": "Adverbs of Frequency", 
    "content": "Adverbs of frequency tell us how often something happens. Common adverbs of frequency include always, usually, often, sometimes, rarely, and never.",
    "examples": [
      "She always arrives on time.",
      "I rarely go to the gym."
    ]
  },
  {  
    "title": "Adverbs of Time", 
    "content": "Adverbs of time tell us when something happens. Common adverbs of time include now, then, yesterday, today, tomorrow, and recently.",
    "examples": [
      "I will finish my homework tomorrow.",
      "We met him yesterday."
    ]
  },
  {  
    "title": "Adverbs of Place", 
    "content": "Adverbs of place describe where an action happens. Examples include here, there, everywhere, nowhere, and upstairs.",
    "examples": [
      "She looked everywhere for her keys.",
      "We are staying here tonight."
    ]
  },
  {  
    "title": "Adverbs of Degree", 
    "content": "Adverbs of degree describe the intensity or extent of an action, adjective, or another adverb. Common adverbs of degree include very, quite, too, enough, and almost.",
    "examples": [
      "He is very tall.",
      "She was quite tired after the race."
    ]
  },
  {  
    "title": "Intensifying Adverbs", 
    "content": "Intensifying adverbs emphasize the degree of an action or quality. Examples include really, extremely, absolutely, and totally.",
    "examples": [
      "The movie was really exciting.",
      "I am absolutely sure about this."
    ]
  },
  {  
    "title": "Adverbs of Probability", 
    "content": "Adverbs of probability show how likely something is to happen. Common adverbs of probability include probably, certainly, possibly, and definitely.",
    "examples": [
      "He will probably come to the party.",
      "She will certainly win the competition."
    ]
  },
  {  
    "title": "Conjunctive Adverbs", 
    "content": "Conjunctive adverbs connect independent clauses and indicate the relationship between them. Common conjunctive adverbs include however, therefore, moreover, consequently, and otherwise.",
    "examples": [
      "He didn't study for the exam; however, he passed.",
      "She didn't like the movie; therefore, she left early."
    ]
  },
  { 
    "title": "Articles", 
    "content": "English has two articles: 'the' and 'a/an'. 'The' is used to refer to specific or particular nouns, while 'a/an' is used to modify non-specific or non-particular nouns.",
    "examples": [
      "I have the book you wanted.",
      "She is a doctor."
    ]
  },
  {  
    "title": "Indefinite Articles (A, An)", 
    "content": "Indefinite articles 'a' and 'an' are used when referring to a non-specific or general noun. 'A' is used before consonant sounds, and 'an' is used before vowel sounds.",
    "examples": [
      "She adopted a cat yesterday.",
      "I saw an elephant at the zoo."
    ]
  },
  {  
    "title": "Definite Article (The)", 
    "content": "The definite article 'the' is used to refer to a specific noun or a noun that is already known to the reader or listener. It can refer to singular or plural nouns.",
    "examples": [
      "The dog that you saw is mine.",
      "We visited the museum yesterday."
    ]
  },
  {  
    "title": "Indefinite Articles with Singular Nouns", 
    "content": "Indefinite articles 'a' and 'an' are used before singular, countable nouns when we are not talking about a specific item.",
    "examples": [
      "I want to buy a car.",
      "She is looking for an apartment."
    ]
  },
  {  
    "title": "Definite Article with Singular and Plural Nouns", 
    "content": "The definite article 'the' can be used with both singular and plural nouns when referring to specific items known to both the speaker and the listener.",
    "examples": [
      "The book on the table is mine.",
      "The teachers at the school are friendly."
    ]
  },
  {  
    "title": "Indefinite Articles with Uncountable Nouns", 
    "content": "Indefinite articles 'a' and 'an' are not used with uncountable nouns. Instead, expressions like 'some' or 'a little' are used.",
    "examples": [
      "I need some water.",
      "She has a little sugar in her coffee."
    ]
  },
  {  
    "title": "The Use of 'A' vs 'An'", 
    "content": "'A' is used before words that begin with a consonant sound, while 'an' is used before words that begin with a vowel sound. It is the sound, not the letter, that determines the choice of article.",
    "examples": [
      "He is a teacher.",
      "She is an engineer.",
      "I saw a uniform.",
      "I ate an apple."
    ]
  },
  {  
    "title": "The Use of 'The' with Unique Nouns", 
    "content": "We use 'the' with nouns that are unique or one of a kind, such as 'the sun', 'the moon', 'the earth', and 'the president'.",
    "examples": [
      "The sun rises in the east.",
      "We are all part of the earth."
    ]
  },
  {  
    "title": "The Use of 'The' with Superlatives", 
    "content": "'The' is used with superlative adjectives to indicate that something is at the highest or lowest level of comparison.",
    "examples": [
      "She is the best player on the team.",
      "This is the worst movie I've ever seen."
    ]
  },
  {  
    "title": "The Use of 'The' with Specific Nouns", 
    "content": "Use 'the' when both the speaker and listener know which specific noun is being referred to. This could be a noun mentioned earlier or a noun with particular meaning in the context.",
    "examples": [
      "I met a boy yesterday. The boy was very friendly.",
      "We saw a car parked outside. The car was blue."
    ]
  },
  {  
    "title": "The Omission of Articles with Plural and Uncountable Nouns", 
    "content": "Articles are not used with plural or uncountable nouns when talking about things in general.",
    "examples": [
      "I like apples.",
      "She drinks coffee every morning."
    ]
  },
  {  
    "title": "Indefinite Articles with Jobs and Professions", 
    "content": "Indefinite articles are used when referring to jobs or professions in a general sense, not a specific person.",
    "examples": [
      "He is a doctor.",
      "She wants to be an artist."
    ]
  },
  {  
    "title": "Using 'The' with Names of Countries", 
    "content": "Certain country names are preceded by 'the' because they are plural or include words like 'republic', 'kingdom', or 'states'.",
    "examples": [
      "I visited the United States.",
      "They are from the Netherlands."
    ]
  },
  {  
    "title": "Using 'The' with Specific Locations", 
    "content": "'The' is used before names of specific locations, such as rivers, oceans, mountain ranges, and famous buildings or landmarks.",
    "examples": [
      "We went to the Eiffel Tower.",
      "The Amazon is the longest river in the world."
    ]
  },
  { 
    "title": "Subject-verb agreement", 
    "content": "Subjects and verbs should agree in number and person.",
    "examples": [
      "The dog runs fast.",
      "They run every morning."
    ]
  },
  {
    "title": "Singular Subjects with Singular Verbs",
    "content": "When the subject is singular, the verb must also be singular. For most verbs, add 's' or 'es' to the base form of the verb in the present tense.",
    "examples": [
      "The dog runs quickly.",
      "She sings beautifully."
    ]
  },
  {
    "title": "Plural Subjects with Plural Verbs",
    "content": "When the subject is plural, the verb must also be plural. In the present tense, plural subjects use the base form of the verb.",
    "examples": [
      "The dogs run quickly.",
      "They sing beautifully."
    ]
  },
  {
    "title": "Compound Subjects with 'And'",
    "content": "When two or more subjects are connected by 'and', the verb should be plural.",
    "examples": [
      "Tom and Jane are coming to the party.",
      "The teacher and the students were excited."
    ]
  },
  {
    "title": "Compound Subjects with 'Or' or 'Nor'",
    "content": "When two or more subjects are connected by 'or' or 'nor', the verb agrees with the subject closest to the verb.",
    "examples": [
      "Either the dog or the cat has to go outside.",
      "Neither the teacher nor the students were available."
    ]
  },
  {
    "title": "Subjects with Collective Nouns",
    "content": "Collective nouns (e.g., team, group, family) take singular verbs when the group acts as a unit. However, if the individual members of the group act separately, a plural verb is used.",
    "examples": [
      "The team is playing well.",
      "The family is having dinner together.",
      "The family are arguing about the plans."
    ]
  },
  {
    "title": "Indefinite Pronouns as Subjects",
    "content": "Indefinite pronouns such as 'everyone', 'someone', 'anyone', 'nobody', and 'everybody' take singular verbs.",
    "examples": [
      "Everyone is invited to the party.",
      "Someone has left their keys."
    ]
  },
  {
    "title": "Subjects with 'Each' or 'Every'",
    "content": "When 'each' or 'every' is used as the subject, it takes a singular verb.",
    "examples": [
      "Each of the students has a book.",
      "Every player is practicing hard."
    ]
  },
  {
    "title": "Subjects with 'None'",
    "content": "'None' can take either a singular or plural verb, depending on the context. If 'none' refers to a singular noun, use a singular verb; if it refers to a plural noun, use a plural verb.",
    "examples": [
      "None of the cake is left.",
      "None of the students were absent."
    ]
  },
  {
    "title": "Subjects with Fractions or Percentages",
    "content": "When fractions or percentages are used as the subject, the verb agrees with the noun that follows the 'of' phrase.",
    "examples": [
      "Three-fourths of the cake has been eaten.",
      "Fifty percent of the students are absent."
    ]
  },
  {
    "title": "Subjects with 'There' or 'Here'",
    "content": "When the sentence begins with 'there' or 'here', the verb must agree with the subject that follows it.",
    "examples": [
      "There is a book on the table.",
      "Here are the books you asked for."
    ]
  },
  {
    "title": "Subjects with 'Some' and 'Any'",
    "content": "When 'some' or 'any' is the subject, the verb agrees with the noun that follows.",
    "examples": [
      "Some of the water is spilled.",
      "Some of the books are missing."
    ]
  },
  {
    "title": "Subjects with 'Data'",
    "content": "The word 'data' is technically plural (from Latin), but it is often treated as singular in everyday use. However, it can also be treated as plural in scientific or technical contexts.",
    "examples": [
      "The data shows a significant trend.",
      "The data are being analyzed."
    ]
  },
  {
    "title": "Subjects with Titles or Names",
    "content": "When a title or name of a book, movie, or work of art is the subject, it takes a singular verb, regardless of whether it seems plural.",
    "examples": [
      "The Lord of the Rings is a great movie.",
      "The Beatles is a famous band."
    ]
  },
  {
    "title": "Subjects with 'I' and 'You'",
    "content": "'I' and 'you' are always followed by plural verbs, even when referring to a singular person.",
    "examples": [
      "I am going to the store.",
      "You are doing a great job."
    ]
  },
  {
    "title": "Subjects with 'None of the' (uncountable nouns)",
    "content": "When 'none of' is followed by an uncountable noun, the verb is singular.",
    "examples": [
      "None of the water is cold.",
      "None of the information is useful."
    ]
  },
  {
    "title": "Subjects with 'Either' and 'Neither'",
    "content": "'Either' and 'neither' are usually singular when they refer to one of two options.",
    "examples": [
      "Either the dog or the cat has eaten the food.",
      "Neither of the students is absent today."
    ]
  },

  { 
    "title": "Tenses", 
    "content": "Tenses should be consistent.",
    "examples": [
      "She ate dinner last night.",
      "I am reading a book."
    ]
  },
  {
    "title": "Present Simple",
    "content": "The present simple tense is used to describe general truths, habits, and routines. It is also used for scheduled events.",
    "examples": [
      "She goes to the gym every day.",
      "The sun rises in the east.",
      "The train leaves at 8:00 AM."
    ]
  },
  {
    "title": "Present Continuous",
    "content": "The present continuous tense is used for actions happening right now or for temporary actions. It is formed by using 'am/is/are' + verb-ing.",
    "examples": [
      "I am reading a book.",
      "They are playing soccer.",
      "She is studying for her exams."
    ]
  },
  {
    "title": "Present Perfect",
    "content": "The present perfect tense is used to describe actions that happened at an unspecified time before now or actions that started in the past and continue in the present.",
    "examples": [
      "I have visited Paris twice.",
      "She has just finished her homework.",
      "They have lived here for ten years."
    ]
  },
  {
    "title": "Present Perfect Continuous",
    "content": "The present perfect continuous tense is used to describe actions that started in the past and are still continuing or actions that have recently stopped but have visible results.",
    "examples": [
      "I have been studying for three hours.",
      "They have been working on the project all day.",
      "She has been feeling unwell."
    ]
  },
  {
    "title": "Past Simple",
    "content": "The past simple tense is used for actions that happened at a specific time in the past and are now finished. It is formed by adding '-ed' to regular verbs, or using the past form of irregular verbs.",
    "examples": [
      "I visited the museum yesterday.",
      "She graduated last year.",
      "They went to the concert last night."
    ]
  },
  {
    "title": "Past Continuous",
    "content": "The past continuous tense is used to describe actions that were happening at a particular moment in the past or actions that were interrupted by another event.",
    "examples": [
      "I was reading when the phone rang.",
      "They were watching TV at 9:00 PM.",
      "She was studying when her friend arrived."
    ]
  },
  {
    "title": "Past Perfect",
    "content": "The past perfect tense is used to describe an action that was completed before another action in the past. It is formed by using 'had' + past participle.",
    "examples": [
      "I had finished my homework before I went out.",
      "She had already left when I arrived.",
      "They had lived in that house for ten years before they moved."
    ]
  },
  {
    "title": "Past Perfect Continuous",
    "content": "The past perfect continuous tense is used to show that an action was happening continuously up to a point in the past or just before another event in the past.",
    "examples": [
      "I had been studying for two hours when she called.",
      "They had been playing soccer before it started raining.",
      "She had been waiting for an hour when I finally arrived."
    ]
  },
  {
    "title": "Future Simple",
    "content": "The future simple tense is used to describe actions that will happen in the future. It is formed by using 'will' + base verb.",
    "examples": [
      "I will call you tomorrow.",
      "They will travel to Japan next year.",
      "She will finish her project next week."
    ]
  },
  {
    "title": "Future Continuous",
    "content": "The future continuous tense is used to describe actions that will be in progress at a specific time in the future. It is formed by using 'will be' + verb-ing.",
    "examples": [
      "I will be working at 9:00 PM.",
      "They will be studying when we arrive.",
      "She will be traveling to Paris this time next week."
    ]
  },
  {
    "title": "Future Perfect",
    "content": "The future perfect tense is used to describe an action that will be completed before a specific point in the future. It is formed by using 'will have' + past participle.",
    "examples": [
      "I will have finished my homework by tomorrow.",
      "They will have arrived by 6:00 PM.",
      "She will have completed the project by next week."
    ]
  },
  {
    "title": "Future Perfect Continuous",
    "content": "The future perfect continuous tense is used to describe an action that will continue up to a point in the future and emphasizes the duration of the action.",
    "examples": [
      "By next year, I will have been living here for ten years.",
      "She will have been working for three hours by the time I arrive.",
      "They will have been studying for two hours when the exam starts."
    ]
  },
  {
    "title": "Used to",
    "content": "The phrase 'used to' is used to describe actions or situations that were habitual in the past but no longer occur. It is used with the base form of the verb.",
    "examples": [
      "I used to play soccer every weekend.",
      "She used to live in New York.",
      "They used to go to the beach during the summer."
    ]
  },
  {
    "title": "Be Going To",
    "content": "'Be going to' is used to talk about plans or intentions in the future or to predict something based on current evidence.",
    "examples": [
      "I am going to visit my grandparents next weekend.",
      "They are going to start a new project soon.",
      "It’s going to rain this afternoon."
    ]
  },
  { 
    "title": "Capitalization", 
    "content": "Capitalization should be used where needed.",
    "examples": [
      "I live in New York.",
      "My friend's name is Alice."
    ]
  },
  {
    "title": "First Word of a Sentence",
    "content": "The first word of a sentence should always be capitalized.",
    "examples": [
      "She went to the store.",
      "I will call you later.",
      "The dog is playing in the yard."
    ]
  },
  {
    "title": "Pronoun 'I'",
    "content": "The pronoun 'I' is always capitalized, regardless of its position in the sentence.",
    "examples": [
      "I am going to the concert.",
      "When I was young, I loved to play outside.",
      "Do you think I should go?"
    ]
  },
  {
    "title": "Proper Nouns",
    "content": "Proper nouns, which refer to specific people, places, or things, should always be capitalized.",
    "examples": [
      "He lives in New York City.",
      "Albert Einstein was a famous scientist.",
      "We visited the Eiffel Tower last summer."
    ]
  },
  {
    "title": "Days of the Week and Months",
    "content": "The names of days of the week and months of the year are always capitalized.",
    "examples": [
      "We will meet on Monday.",
      "She was born in December.",
      "The meeting is scheduled for Friday."
    ]
  },
  {
    "title": "Names of Holidays",
    "content": "The names of holidays are always capitalized.",
    "examples": [
      "We celebrate Christmas with our family.",
      "Happy New Year!",
      "They are planning a party for Independence Day."
    ]
  },
  {
    "title": "Geographical Names",
    "content": "Names of countries, cities, continents, oceans, and other geographical locations should be capitalized.",
    "examples": [
      "She is traveling to Italy next summer.",
      "They live in London.",
      "The Pacific Ocean is the largest ocean on Earth."
    ]
  },
  {
    "title": "Titles of Books, Movies, and Works of Art",
    "content": "The titles of books, movies, songs, paintings, and other works of art should be capitalized. The first and last words of the title, as well as any important words in between, should be capitalized.",
    "examples": [
      "I am reading 'The Great Gatsby'.",
      "My favorite movie is 'The Lion King'.",
      "She is studying 'Mona Lisa' in art history class."
    ]
  },
  {
    "title": "Titles of People",
    "content": "Titles that precede a person's name, such as Mr., Mrs., Dr., and President, should be capitalized.",
    "examples": [
      "Dr. Smith is the best doctor in the hospital.",
      "Mrs. Johnson will give the speech at the conference.",
      "President Obama gave a powerful speech."
    ]
  },
  {
    "title": "Academic Degrees",
    "content": "Academic degrees, such as Bachelor's Degree, Master's Degree, and PhD, should be capitalized when they appear after a person's name or as part of a formal title.",
    "examples": [
      "He has a Master's Degree in Engineering.",
      "She earned her PhD in Psychology.",
      "Mr. Robert, PhD, will be joining us for the lecture."
    ]
  },
  {
    "title": "First and Last Words in Titles",
    "content": "In a title or headline, always capitalize the first and last word, regardless of the part of speech.",
    "examples": [
      "The Catcher in the Rye",
      "A Tale of Two Cities",
      "The Lord of the Rings"
    ]
  },
  {
    "title": "Acronyms and Initialisms",
    "content": "Acronyms and initialisms, such as NASA, USA, and FBI, should always be capitalized.",
    "examples": [
      "He works for NASA.",
      "The FBI is investigating the case.",
      "She is a member of the UN."
    ]
  },
  {
    "title": "The Word 'The' in Names",
    "content": "When 'The' is part of a title or name, it should be capitalized.",
    "examples": [
      "The White House is located in Washington, D.C.",
      "I visited The Louvre during my trip to Paris.",
      "They are watching The Office on Netflix."
    ]
  },
  {
    "title": "Religions and Religious Terms",
    "content": "Names of religions, deities, and religious terms should be capitalized.",
    "examples": [
      "She practices Christianity.",
      "They are learning about Hinduism in history class.",
      "Buddhism is a major religion in Asia."
    ]
  },
  {
    "title": "Nationalities and Languages",
    "content": "Nationalities, ethnic groups, and languages should be capitalized.",
    "examples": [
      "He is of Italian descent.",
      "They speak Spanish at home.",
      "She loves Japanese cuisine."
    ]
  },
  {
    "title": "Capitalization in Salutations",
    "content": "In a letter or email, the first word of the salutation and the title of the person addressed should be capitalized.",
    "examples": [
      "Dear Mr. Smith,",
      "Hello, Dr. Johnson,",
      "To Whom It May Concern:"
    ]
  },
  {
    "title": "Season Names",
    "content": "Season names such as spring, summer, autumn, and winter are generally not capitalized unless they are part of a proper noun or title.",
    "examples": [
      "I love autumn the most.",
      "Summer is my favorite season.",
      "They are traveling to the Winter Wonderland festival."
    ]
  },
  { 
    "title": "Prepositions", 
    "content": "The right preposition should be used.",
    "examples": [
      "The cat is under the table.",
      "She is sitting on the chair."
    ]
  },
  {
    "title": "Prepositions of Time",
    "content": "Prepositions of time show relationships with time. Common prepositions include at, on, in, before, after, during, and since.",
    "examples": [
      "The meeting is at 3 PM.",
      "I will see you on Monday.",
      "She has been working here since 2010.",
      "We will leave after lunch.",
      "He went to the gym during the summer."
    ]
  },
  {
    "title": "Prepositions of Place",
    "content": "Prepositions of place describe the location of something. Common prepositions include at, on, in, under, over, between, and near.",
    "examples": [
      "The book is on the table.",
      "She lives in New York.",
      "The keys are under the couch.",
      "The ball is between the two chairs.",
      "He sat next to her during the movie."
    ]
  },
  {
    "title": "Prepositions of Direction",
    "content": "Prepositions of direction show movement toward something. Common prepositions include to, into, onto, and toward.",
    "examples": [
      "She walked to the store.",
      "He jumped into the pool.",
      "The car turned onto the street.",
      "They headed toward the park."
    ]
  },
  {
    "title": "Prepositions of Manner",
    "content": "Prepositions of manner describe how an action is done. Common prepositions include by, with, and in.",
    "examples": [
      "He travels by car.",
      "She wrote the letter with a pen.",
      "They danced in the rain."
    ]
  },
  {
    "title": "Prepositions of Cause, Reason, and Purpose",
    "content": "These prepositions show cause, reason, or purpose. Common prepositions include for, because of, and due to.",
    "examples": [
      "She was absent for illness.",
      "The flight was delayed because of the weather.",
      "The meeting was postponed due to the power outage."
    ]
  },
  {
    "title": "Prepositions of Agent",
    "content": "Prepositions of agent show who or what performs the action. Common prepositions include by.",
    "examples": [
      "The book was written by the author.",
      "The project was completed by the team.",
      "The song was sung by a famous artist."
    ]
  },
  {
    "title": "Prepositions of Accompaniment",
    "content": "These prepositions show who or what someone is with. Common prepositions include with and without.",
    "examples": [
      "She went to the party with her friends.",
      "I can't do it without your help.",
      "They traveled with their parents."
    ]
  },
  {
    "title": "Prepositions of Comparison",
    "content": "Prepositions of comparison show how two things are similar or different. Common prepositions include like and as.",
    "examples": [
      "She sings like a professional.",
      "He acted as if nothing had happened.",
      "This book is like the one I read last year."
    ]
  },
  {
    "title": "Prepositions of Instrument/Means",
    "content": "Prepositions of instrument/means show how an action is performed. Common prepositions include by, with, and through.",
    "examples": [
      "She cut the paper with scissors.",
      "The problem was solved by analyzing the data.",
      "He communicated through email."
    ]
  },
  {
    "title": "Prepositions of Place and Movement",
    "content": "Some prepositions indicate both place and movement. Common prepositions include at, in, on, into, and out of.",
    "examples": [
      "He is at the door.",
      "She walked into the room.",
      "The dog jumped out of the box.",
      "I placed the book on the shelf."
    ]
  },
  {
    "title": "Prepositions of Time with Duration",
    "content": "Prepositions of time show a period or duration. Common prepositions include for, during, and since.",
    "examples": [
      "She has been waiting for two hours.",
      "We went on vacation during the summer.",
      "They haven't seen each other since last year."
    ]
  },
  {
    "title": "Prepositions of Distance",
    "content": "Prepositions of distance show the extent or measurement of space. Common prepositions include from, to, and between.",
    "examples": [
      "The store is five miles from here.",
      "The hotel is located between the park and the museum.",
      "I live far from my workplace."
    ]
  },
  {
    "title": "Prepositions with Adjectives",
    "content": "Some adjectives require a specific preposition to complete their meaning. Common prepositions include for, to, of, and with.",
    "examples": [
      "She is good at painting.",
      "I am interested in learning Spanish.",
      "He is angry with me.",
      "They are afraid of the dark."
    ]
  },
  {
    "title": "Prepositions of Location",
    "content": "Prepositions of location specify where something is situated. Common prepositions include in, on, at, under, above, and beside.",
    "examples": [
      "The restaurant is at the corner of the street.",
      "The cat is hiding under the table.",
      "There is a picture on the wall.",
      "She lives in the city."
    ]
  },
  {
    "title": "Prepositions of Support or Opposition",
    "content": "Prepositions of support or opposition show agreement or disagreement. Common prepositions include for, against, in favor of, and opposed to.",
    "examples": [
      "He is for the new policy.",
      "She is against the idea of traveling.",
      "They are in favor of the new proposal.",
      "The committee is opposed to the changes."
    ]
  },
  {
    "title": "Prepositions of Condition",
    "content": "Prepositions of condition show a relationship based on a particular situation. Common prepositions include on and if.",
    "examples": [
      "On condition that you finish your homework, you can go out.",
      "If it rains, the event will be postponed."
    ]
  },
  { 
    "title": "Punctuation", 
    "content": "Sentences should be punctuated.",
    "examples": [
      "I like to read books.",
      "She went to the store, and I stayed home."
    ]
  },
  {
    "title": "Period (.)",
    "content": "A period is used to mark the end of a declarative sentence, indirect questions, and abbreviations.",
    "examples": [
      "She loves to read books.",
      "The event was scheduled for Monday.",
      "The CEO will attend the meeting tomorrow.",
      "The address is 123 Main St., Springfield."
    ]
  },
  {
    "title": "Comma (,)",
    "content": "A comma is used to separate items in a list, before conjunctions in compound sentences, and after introductory phrases.",
    "examples": [
      "I bought apples, oranges, bananas, and grapes.",
      "We went to the park, and we played soccer.",
      "After the meeting, we went for lunch.",
      "In the morning, I like to drink coffee."
    ]
  },
  {
    "title": "Question Mark (?)",
    "content": "A question mark is used at the end of a direct question.",
    "examples": [
      "What time is the meeting?",
      "Are you coming to the party tonight?",
      "Where did you go on vacation?"
    ]
  },
  {
    "title": "Exclamation Mark (!)",
    "content": "An exclamation mark is used to express strong feelings or a high volume of speech.",
    "examples": [
      "That’s amazing!",
      "Watch out!",
      "I can’t believe it!"
    ]
  },
  {
    "title": "Colon (:)",
    "content": "A colon is used to introduce a list, explanation, or a quote.",
    "examples": [
      "She bought the following items: milk, eggs, and bread.",
      "He had one goal: to win the championship.",
      "He said: 'We will succeed together.'"
    ]
  },
  {
    "title": "Semicolon (;)",
    "content": "A semicolon is used to connect two independent clauses that are closely related or to separate items in a complex list.",
    "examples": [
      "I went to the store; I forgot to buy milk.",
      "The meeting was productive; however, we didn't finalize the plan.",
      "The tour will take us to Paris, France; London, England; and Rome, Italy."
    ]
  },
  {
    "title": "Apostrophe (')",
    "content": "An apostrophe is used to show possession or in contractions to indicate missing letters.",
    "examples": [
      "The cat's toy is missing.",
      "It's a beautiful day.",
      "That is John's book."
    ]
  },
  {
    "title": "Quotation Marks (\" \")",
    "content": "Quotation marks are used to indicate direct speech, quotes, or titles of short works.",
    "examples": [
      "He said, 'I’ll be back soon.'",
      "The article is titled 'The Future of Technology.'",
      "She asked, 'Can you help me with this task?'"
    ]
  },
  {
    "title": "Parentheses ()",
    "content": "Parentheses are used to include additional information or clarifications within a sentence.",
    "examples": [
      "The event (which was scheduled for 3 PM) was postponed.",
      "She bought a new car (a red sedan).",
      "I saw John at the store (he was buying groceries)."
    ]
  },
  {
    "title": "Dash (–)",
    "content": "A dash is used to show a break in thought, set off parenthetical phrases, or to indicate an abrupt change in the sentence.",
    "examples": [
      "I can't believe it – it’s unbelievable!",
      "He arrived late – just in time for the meeting.",
      "The movie – which we loved – was fantastic."
    ]
  },
  {
    "title": "Hyphen (-)",
    "content": "A hyphen is used to join two or more words together to form a compound word or to break a word at the end of a line.",
    "examples": [
      "She is a well-known author.",
      "I have a part-time job.",
      "Please check the updated e-book."
    ]
  },
  {
    "title": "Ellipsis (...)",
    "content": "An ellipsis is used to indicate an omission or a pause in speech.",
    "examples": [
      "I’m not sure... I think we should wait.",
      "She paused before answering... 'I don’t know.'",
      "The list includes apples, oranges, and... bananas."
    ]
  },
  {
    "title": "Brackets []",
    "content": "Brackets are used to enclose added or explanatory words within a quotation or to clarify meaning.",
    "examples": [
      "He said, 'The meeting [was] moved to Tuesday.'",
      "The article [written in 2020] was published last week.",
      "They were going to Paris [in 2019]."
    ]
  },
  {
    "title": "Slash (/)",
    "content": "A slash is used to indicate alternatives, fractions, or to separate lines of poetry.",
    "examples": [
      "Please select your male/female option.",
      "He walked 3/4 of the way.",
      "The poem is about love/heartbreak."
    ]
  },
  {
    "title": "Comma with Direct Address",
    "content": "A comma is used to separate the name of a person or thing being directly addressed.",
    "examples": [
      "John, can you help me with this?",
      "Please, Sarah, join us for dinner.",
      "I’m so proud of you, Mark!"
    ]
  },
  {
    "title": "Comma with Coordinate Adjectives",
    "content": "A comma is used between coordinate adjectives (adjectives that equally describe a noun).",
    "examples": [
      "It was a long, tiring day.",
      "She wore a bright, colorful dress.",
      "They bought a new, expensive car."
    ]
  },
  {
    "title": "Comma with Non-essential Elements",
    "content": "Commas are used to separate non-essential elements, such as non-restrictive clauses, appositives, and participial phrases.",
    "examples": [
      "My brother, who lives in New York, is visiting us this week.",
      "The cake, decorated with flowers, was beautiful.",
      "The teacher, exhausted from the day’s work, went home early."
    ]
  },
  {
    "title": "Comma with Dates, Addresses, and Titles",
    "content": "Commas are used to separate elements in dates, addresses, and titles.",
    "examples": [
      "The event will take place on March 5, 2023.",
      "She lives at 123 Main St., Springfield.",
      "Dr. John Smith, PhD, will speak at the seminar."
    ]
  },
  { 
    "title": "Sentence structure", 
    "content": "Complete sentences should be used.",
    "examples": [
      "I enjoy swimming.",
      "He is studying for the exam."
    ]
  },
  {
    "title": "Simple Sentence",
    "content": "A simple sentence consists of a single independent clause with a subject and a predicate. It expresses a complete thought.",
    "examples": [
      "She runs every morning.",
      "The dog barked loudly.",
      "I like to read books."
    ]
  },
  {
    "title": "Compound Sentence",
    "content": "A compound sentence consists of two or more independent clauses joined by a coordinating conjunction (for, and, nor, but, or, yet, so) or a semicolon.",
    "examples": [
      "I wanted to go for a walk, but it started raining.",
      "She studied hard, and she passed the exam.",
      "The team won the match; however, they were exhausted."
    ]
  },
  {
    "title": "Complex Sentence",
    "content": "A complex sentence contains one independent clause and at least one dependent clause, joined by a subordinating conjunction (because, although, if, since, unless, etc.).",
    "examples": [
      "I stayed home because it was raining.",
      "She couldn't attend the party since she was sick.",
      "If you study hard, you will succeed."
    ]
  },
  {
    "title": "Compound-Complex Sentence",
    "content": "A compound-complex sentence contains at least two independent clauses and at least one dependent clause.",
    "examples": [
      "Although it was raining, I went for a walk, and I enjoyed the fresh air.",
      "She didn’t come to the party because she was sick, but her sister attended.",
      "We decided to go on vacation after we finished our work, and we had a great time."
    ]
  },
  {
    "title": "Declarative Sentence",
    "content": "A declarative sentence makes a statement or expresses an idea and ends with a period.",
    "examples": [
      "The sun sets in the west.",
      "I enjoy playing tennis.",
      "This is a beautiful painting."
    ]
  },
  {
    "title": "Interrogative Sentence",
    "content": "An interrogative sentence asks a question and ends with a question mark.",
    "examples": [
      "What time is the meeting?",
      "Did you finish your homework?",
      "Are you going to the party tonight?"
    ]
  },
  {
    "title": "Imperative Sentence",
    "content": "An imperative sentence gives a command, makes a request, or offers an invitation. It ends with a period or exclamation mark.",
    "examples": [
      "Please close the door.",
      "Stop talking!",
      "Come here right now."
    ]
  },
  {
    "title": "Exclamatory Sentence",
    "content": "An exclamatory sentence expresses strong emotion and ends with an exclamation mark.",
    "examples": [
      "What a beautiful day!",
      "I can't believe we won the game!",
      "Wow! That’s incredible!"
    ]
  },
  {
    "title": "Loose Sentence",
    "content": "A loose sentence begins with the main clause followed by additional details or information. The sentence structure is more straightforward.",
    "examples": [
      "I went to the store, bought some fruit, and came back home.",
      "She finished her homework, took a nap, and then went to the gym.",
      "The dog ran to the park, chased after a ball, and played with other dogs."
    ]
  },
  {
    "title": "Periodic Sentence",
    "content": "A periodic sentence withholds the main clause until the end, creating suspense or emphasis.",
    "examples": [
      "After hours of walking, climbing, and exploring, we finally reached the summit.",
      "Despite the rain, the traffic, and the late start, we made it on time.",
      "Only when she had finished all her work, did she relax and enjoy herself."
    ]
  },
  {
    "title": "Balanced Sentence",
    "content": "A balanced sentence features two parts that are equal in structure and length, often creating a sense of symmetry.",
    "examples": [
      "It was the best of times, it was the worst of times.",
      "To err is human; to forgive, divine.",
      "She loves to read books, and he loves to write stories."
    ]
  },
  {
    "title": "Cumulative Sentence",
    "content": "A cumulative sentence begins with a main clause followed by additional details or information that expand on the idea.",
    "examples": [
      "The car raced down the street, its engine roaring and tires screeching.",
      "The children played in the park, running, laughing, and climbing the jungle gym.",
      "The movie was a hit, drawing large crowds and earning rave reviews."
    ]
  },
  {
    "title": "Inverted Sentence",
    "content": "An inverted sentence flips the usual word order (subject-verb-object) for emphasis, style, or rhetorical effect.",
    "examples": [
      "Never have I seen such a beautiful sight.",
      "Up the hill rolled the large truck.",
      "On the desk sat a pile of books."
    ]
  },
  {
    "title": "Nominalization",
    "content": "Nominalization is the process of turning verbs or adjectives into nouns, often used in formal or academic writing.",
    "examples": [
      "The discovery of new methods is crucial to advancing science.",
      "The establishment of new policies improved the system.",
      "The realization of her mistake made her feel guilty."
    ]
  },
  {
    "title": "Elliptical Sentence",
    "content": "An elliptical sentence omits certain words that are implied by context, often used in casual speech.",
    "examples": [
      "She can play the piano, and he, the guitar.",
      "I love chocolate; my sister, vanilla.",
      "He is good at math; I, at science."
    ]
  },
  {
    "title": "Parallel Structure",
    "content": "Parallel structure involves using the same grammatical form within a sentence or across multiple sentences for balance and clarity.",
    "examples": [
      "She enjoys reading, writing, and painting.",
      "He likes to swim, run, and bike.",
      "The teacher asked for their names, addresses, and phone numbers."
    ]
  },
  { 
    "title": "Word order", 
    "content": "Word order should be switched for questions.",
    "examples": [
      "Are you coming to the party?",
      "What is your name?"
    ]
  },
  {
    "title": "Basic Word Order (SVO)",
    "content": "In English, the basic word order for a sentence is Subject-Verb-Object (SVO). The subject comes first, followed by the verb, and then the object.",
    "examples": [
      "She (subject) ate (verb) the cake (object).",
      "John (subject) plays (verb) soccer (object).",
      "They (subject) are reading (verb) books (object)."
    ]
  },
  {
    "title": "Questions (Inversion)",
    "content": "In questions, the word order is inverted, with the auxiliary verb coming before the subject in yes/no questions, and wh-words preceding the subject in information questions.",
    "examples": [
      "Are you (auxiliary verb) coming (verb) to the party (subject)?",
      "What (wh-word) is (verb) your name (subject)?",
      "Did (auxiliary verb) she (subject) arrive (verb) early (object)?"
    ]
  },
  {
    "title": "Negative Sentences",
    "content": "In negative sentences, the word order remains the same as in affirmative sentences, but a negative word (like 'not' or 'never') is added after the auxiliary verb or main verb.",
    "examples": [
      "She does (auxiliary verb) not (negative) like (verb) chocolate (object).",
      "I have (auxiliary verb) never (negative) seen (verb) this movie (object).",
      "They are (auxiliary verb) not (negative) coming (verb) today (object)."
    ]
  },
  {
    "title": "Adjective Order",
    "content": "When multiple adjectives describe a noun, there is a specific order in which the adjectives should appear. The general order is: Quantity/Opinion, Size, Age, Shape, Color, Proper adjective, Purpose/Qualifier.",
    "examples": [
      "She bought three (quantity) beautiful (opinion) large (size) red (color) cars (noun).",
      "I found an old (age) round (shape) wooden (material) table (noun).",
      "We stayed in a small (size) cozy (opinion) country (proper adjective) house (noun)."
    ]
  },
  {
    "title": "Adverb Placement",
    "content": "Adverbs typically come after the verb or at the end of a sentence. However, adverbs of frequency (e.g., always, often) usually come before the main verb.",
    "examples": [
      "She sings (verb) beautifully (adverb).",
      "They arrived (verb) late (adverb).",
      "I always (adverb) drink coffee in the morning (object).",
      "He runs (verb) fast (adverb)."
    ]
  },
  {
    "title": "Time Expressions",
    "content": "In sentences with time expressions, the usual order is time-place-manner. The time expression usually comes first, followed by the action and the place.",
    "examples": [
      "I will go to the gym tomorrow (time) at 6 PM (time).",
      "She is meeting her friend in the park (place) after work (time).",
      "We studied for the test yesterday (time) in the library (place)."
    ]
  },
  {
    "title": "Inversion for Emphasis",
    "content": "Inversion can also be used for emphasis, often after adverbial phrases or negative expressions. The auxiliary verb comes before the subject.",
    "examples": [
      "Never have I seen such a beautiful sunset.",
      "Seldom do they attend the meetings.",
      "Hardly had I finished my meal when the phone rang."
    ]
  },
  {
    "title": "Object Placement (Object Pronouns)",
    "content": "When object pronouns are used, they typically appear after the verb or the subject in some cases for emphasis.",
    "examples": [
      "I gave him (object pronoun) the book.",
      "She sent me (object pronoun) an email.",
      "They invited us (object pronoun) to the party."
    ]
  },
  {
    "title": "Prepositional Phrase Placement",
    "content": "Prepositional phrases can be placed at the beginning or the end of a sentence, though the most common placement is at the end.",
    "examples": [
      "The book is on the table (prepositional phrase at the end).",
      "On the table (prepositional phrase at the beginning), the book was placed.",
      "She went to the store (prepositional phrase at the end) after work."
    ]
  },
  {
    "title": "Direct and Indirect Objects",
    "content": "When both a direct and indirect object are used, the indirect object generally comes before the direct object. However, when using a preposition, the indirect object can come after the direct object.",
    "examples": [
      "I gave him (indirect object) a gift (direct object).",
      "She sent me (indirect object) a letter (direct object).",
      "He gave a gift (direct object) to her (indirect object)."
    ]
  },
  {
    "title": "Negative Adverbs",
    "content": "In negative adverb placement, adverbs such as 'never,' 'seldom,' and 'hardly' are placed at the beginning of a sentence for emphasis, followed by inversion of the subject and verb.",
    "examples": [
      "Never have I seen such a beautiful painting.",
      "Seldom does she visit us.",
      "Hardly ever do we go to the beach."
    ]
  },
  {
    "title": "Relative Clauses",
    "content": "Relative clauses give more information about a noun. The relative pronoun (who, which, that, whose) usually comes after the noun it refers to.",
    "examples": [
      "The book that I bought yesterday is amazing.",
      "She is the woman who helped me with the project.",
      "The car which broke down last week has been repaired."
    ]
  },
  {
    "title": "Infinitive and Gerund Placement",
    "content": "When using infinitives or gerunds, their position depends on the sentence. Infinitives often come after verbs, adjectives, or nouns, while gerunds can function as subjects or objects.",
    "examples": [
      "I want to go (infinitive) to the concert.",
      "She enjoys swimming (gerund) in the pool.",
      "It’s important to study (infinitive) every day."
    ]
  },
  { 
    "title": "Double negatives", 
    "content": "Double negatives should be avoided.",
    "examples": [
      "I don't know anything. (Correct)",
      "I don't know nothing. (Incorrect)"
    ]
  },
  {
    "title": "What is a Double Negative?",
    "content": "A double negative occurs when two negative words are used in the same sentence. In standard English, double negatives are usually avoided because they can lead to confusion, as they may cancel each other out, making the sentence positive.",
    "examples": [
      "I don't need no help (double negative: 'don't' and 'no').",
      "He didn't say nothing (double negative: 'didn't' and 'nothing')."
    ]
  },
  {
    "title": "Double Negatives in Standard English",
    "content": "In standard English, using two negatives in the same sentence often results in a positive meaning. To avoid this, it is better to use one negative word.",
    "examples": [
      "I don't need any help (corrected from 'I don't need no help').",
      "He didn't say anything (corrected from 'He didn't say nothing')."
    ]
  },
  {
    "title": "Double Negatives for Emphasis (Non-standard)",
    "content": "In some dialects and informal speech, double negatives are used for emphasis, intensifying the negation. However, this usage is considered non-standard in formal English.",
    "examples": [
      "I ain't never seen nothing like that before (non-standard for emphasis).",
      "She don't know nothing about it (non-standard for emphasis)."
    ]
  },
  {
    "title": "Avoiding Double Negatives in Formal Writing",
    "content": "In formal writing and speech, double negatives should be avoided as they can create ambiguity or unintended meaning. Stick to one negative word for clarity.",
    "examples": [
      "He doesn't have any doubts (corrected from 'He doesn't have no doubts').",
      "I can't find anything (corrected from 'I can't find nothing')."
    ]
  },
  {
    "title": "Double Negatives in Questions",
    "content": "In questions, double negatives are also often used in non-standard speech. However, in formal speech, questions should avoid double negatives and should focus on a clear single negative expression.",
    "examples": [
      "Didn’t you hear nothing? (non-standard)",
      "Didn't you hear anything? (standard)"
    ]
  },
  {
    "title": "Double Negatives with 'Not' and 'No'",
    "content": "A common double negative involves using 'not' with 'no.' In formal English, it is better to avoid this structure, using one of the negative terms in isolation.",
    "examples": [
      "I don’t know nothing about it (non-standard with 'not' and 'no').",
      "I don’t know anything about it (standard, corrected)."
    ]
  },
  {
    "title": "Double Negatives with 'Never' and 'Nothing'",
    "content": "Using both 'never' and 'nothing' together is a common example of a double negative. In standard English, one of these should be omitted.",
    "examples": [
      "I never seen nothing like that (non-standard).",
      "I’ve never seen anything like that (standard)."
    ]
  },
  {
    "title": "Double Negatives with 'Barely' and 'Hardly'",
    "content": "Using 'barely' or 'hardly' in combination with another negative word creates a double negative. It is typically used informally, but it should be avoided in standard English.",
    "examples": [
      "She barely don't know what happened (non-standard).",
      "She hardly knows what happened (standard)."
    ]
  },
  {
    "title": "Double Negatives in British English",
    "content": "In some varieties of British English, double negatives are used more freely and often to emphasize the negation. This usage is considered informal and should be avoided in more formal contexts.",
    "examples": [
      "I can’t find no one to help (informal British English).",
      "I can’t find anyone to help (standard English)."
    ]
  },
  {
    "title": "Clarifying Meaning with Double Negatives",
    "content": "Sometimes, double negatives can make the meaning unclear or lead to misunderstanding. It’s important to use double negatives sparingly and make sure they do not unintentionally convey a positive meaning.",
    "examples": [
      "I don’t need no advice (ambiguous: could mean 'I don't need any advice' or 'I do need advice').",
      "I don’t need any advice (clear meaning)."
    ]
  },
  {
    "title": "Negative Concord (African American Vernacular English)",
    "content": "In African American Vernacular English (AAVE) and some other non-standard dialects, double negatives are used as a grammatical structure to reinforce the negation, a phenomenon called negative concord.",
    "examples": [
      "I ain't got no money (negative concord in AAVE).",
      "I don't have any money (standard English)."
    ]
  },
  { 
    "title": "Active vs. Passive Voice", 
    "content": "Active voice and passive voice should be used appropriately.",
    "examples": [
      "She wrote the letter. (Active)",
      "The letter was written by her. (Passive)"
    ]
  },
  {
    "title": "What is Active Voice?",
    "content": "In active voice, the subject of the sentence performs the action expressed by the verb. This structure makes sentences clearer and more direct.",
    "examples": [
      "The cat chased the mouse.",
      "She completed the project on time.",
      "They built a new school in the village."
    ]
  },
  {
    "title": "What is Passive Voice?",
    "content": "In passive voice, the subject of the sentence receives the action of the verb. The focus is placed on the action or the object, rather than who is performing the action.",
    "examples": [
      "The mouse was chased by the cat.",
      "The project was completed on time by her.",
      "A new school was built in the village by them."
    ]
  },
  {
    "title": "Active Voice vs. Passive Voice",
    "content": "Active voice emphasizes the subject performing the action, while passive voice emphasizes the action or the object receiving the action. Passive voice is often used when the doer is unknown, irrelevant, or less important.",
    "examples": [
      "Active: The teacher explained the lesson.",
      "Passive: The lesson was explained by the teacher."
    ]
  },
  {
    "title": "When to Use Active Voice",
    "content": "Active voice is generally preferred in writing because it is more straightforward, direct, and easier to understand. It is commonly used in everyday conversation, news writing, and most types of formal and informal writing.",
    "examples": [
      "She writes the report every month.",
      "The manager approved the proposal.",
      "The students solved the problems."
    ]
  },
  {
    "title": "When to Use Passive Voice",
    "content": "Passive voice is used when the focus is on the action or result, rather than the subject. It is often used in scientific writing, formal documents, and when the doer of the action is unknown or unimportant.",
    "examples": [
      "The report is written every month.",
      "The proposal was approved by the manager.",
      "The problems were solved by the students."
    ]
  },
  {
    "title": "Changing Active to Passive Voice",
    "content": "To change a sentence from active to passive voice, swap the object and the subject, and adjust the verb to a form of 'to be' followed by the past participle of the main verb.",
    "examples": [
      "Active: The chef cooked the dinner.",
      "Passive: The dinner was cooked by the chef."
    ]
  },
  {
    "title": "Passive Voice with 'By' Agent",
    "content": "In passive voice, the agent (the doer of the action) can be omitted if it is unknown, irrelevant, or unnecessary. However, when included, it is typically introduced with the word 'by.'",
    "examples": [
      "Active: The committee approved the new policy.",
      "Passive: The new policy was approved by the committee.",
      "Passive (without agent): The new policy was approved."
    ]
  },
  {
    "title": "Avoiding Overuse of Passive Voice",
    "content": "While passive voice has its uses, overusing it can lead to vague and wordy writing. It is important to balance passive and active voice for clarity and readability.",
    "examples": [
      "Passive: The cake was baked by me and then eaten by my friends. (wordy)",
      "Active: I baked the cake and my friends ate it. (more direct)"
    ]
  },
  {
    "title": "Passive Voice in Formal Writing",
    "content": "In formal writing, such as research papers, technical documents, and legal writing, passive voice is often used to maintain objectivity or to emphasize the process or result rather than the person performing the action.",
    "examples": [
      "Active: The researchers conducted the experiment.",
      "Passive: The experiment was conducted by the researchers."
    ]
  },
  {
    "title": "The Use of Passive Voice in Scientific Writing",
    "content": "In scientific writing, passive voice is commonly used to emphasize the action or experiment rather than the researcher or subject performing the action.",
    "examples": [
      "Active: We observed the chemical reaction.",
      "Passive: The chemical reaction was observed."
    ]
  },
  {
    "title": "When the Subject is Unknown or Irrelevant",
    "content": "In cases where the subject is unknown or irrelevant to the context, passive voice is often used to avoid mentioning the doer of the action.",
    "examples": [
      "Active: Someone cleaned the office.",
      "Passive: The office was cleaned."
    ]
  },
  {
    "title": "Imperative Sentences in Active and Passive Voice",
    "content": "In imperative sentences, which give commands or requests, the subject is usually implied (you). Passive constructions can be used to focus on the action rather than the subject.",
    "examples": [
      "Active: Close the door.",
      "Passive: Let the door be closed."
    ]
  },
  {
    "title": "Question Forms in Active and Passive Voice",
    "content": "In questions, both active and passive voices are possible. In passive questions, the subject and verb are switched, and the auxiliary verb 'by' is often included to clarify the agent.",
    "examples": [
      "Active: Did you write the report?",
      "Passive: Was the report written by you?"
    ]
  },
  {
    "title": "Emphasizing the Action in Passive Voice",
    "content": "When you want to emphasize the action rather than who is performing it, passive voice is useful. This is often the case in news reporting or formal announcements.",
    "examples": [
      "Active: The police arrested the suspect.",
      "Passive: The suspect was arrested."
    ]
  },
  {
    "title": "Passive Voice in Advertisements",
    "content": "In advertisements, passive voice can be used to focus on the product or result rather than the company or person responsible for the action.",
    "examples": [
      "Active: The company will launch a new product next month.",
      "Passive: A new product will be launched next month."
    ]
  }
];

const Book = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const [isPageTurning, setIsPageTurning] = useState(false);

  const handleNext = () => {
    if (currentPage < grammarRules.length - 1 && !isPageTurning) {
      setIsPageTurning(true);
      setTimeout(() => {
        setCurrentPage(currentPage + 1);
        setIsPageTurning(false);
      }, 500); // Animation duration
    }
  };

  const handlePrev = () => {
    if (currentPage > 0 && !isPageTurning) {
      setIsPageTurning(true);
      setTimeout(() => {
        setCurrentPage(currentPage - 1);
        setIsPageTurning(false);
      }, 500); // Animation duration
    }
  };

  const { title, content, examples } = grammarRules[currentPage];

  return (
    <div className="book-container">
      <div className={`book ${isPageTurning ? 'turning' : ''}`}>
        <div className="book-spine"></div>
        <div className="book-page front">
          <h2>{title}</h2>
          <p>{content}</p>
          <ul>
            {examples.map((example, index) => (
              <li key={index}>{example}</li>
            ))}
          </ul>
        </div>
        <div className="book-page back">
          <h2>{title}</h2>
          <p>{content}</p>
        </div>
      </div>
      <div className="controls">
        <button className="button-book" onClick={handlePrev} disabled={currentPage === 0} >{'<'}</button>
        <button className="button-book" onClick={handleNext} disabled={currentPage === grammarRules.length - 1} >{'>'}</button>
      </div>
    </div>
  );
};

export default Book;
