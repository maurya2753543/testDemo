import React from 'react';
import EnglishQuiz from './EnglishQuiz'; // Import the Quiz component

  
const App = () => {
  return (
    <div>
      <EnglishQuiz  />
    </div>
  );
};

export default App;
