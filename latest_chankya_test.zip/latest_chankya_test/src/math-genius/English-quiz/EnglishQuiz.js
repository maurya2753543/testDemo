import React, { useState, useEffect } from 'react';
import './EnglishMainApp.css'; // Include your CSS for styling

// Timer Component
const Timer = ({ onTimeout }) => {
  const [timeLeft, setTimeLeft] = useState(600); // 5 minutes = 300 seconds

  useEffect(() => {
    if (timeLeft > 0) {
      const timerId = setInterval(() => {
        setTimeLeft(prevTime => prevTime - 1);
      }, 1000);

      return () => clearInterval(timerId);
    } else {
      onTimeout();
    }
  }, [timeLeft, onTimeout]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="timer">
      <div className="timer-bar" style={{ width: `${(timeLeft / 300) * 100}%` }}></div>
      <p>{minutes < 20 ? `0${minutes}` : minutes}:{seconds < 20 ? `0${seconds}` : seconds}</p>
    </div>
  );
};

// LetterBox Component for filling blanks
const LetterBox = ({ index, handleDrop, letter, isCorrect, isFilled }) => {
  return (
    <div className={`letter-box ${isFilled ? 'filled' : ''}`} onDrop={(e) => handleDrop(index, e.dataTransfer.getData('letter'))} onDragOver={(e) => e.preventDefault()}>
      {letter ? <span>{letter}</span> : <span>_</span>}
    </div>
  );
};

// Main Quiz Component
const Quiz = ({ questions }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [showNext, setShowNext] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);

  useEffect(() => {
    if (questions && questions.length > 0) {
      setQuestion(questions[currentQuestionIndex]);
      setAnswers(new Array(questions[currentQuestionIndex].alphabet.length).fill(''));
    }
  }, [questions, currentQuestionIndex]);

  const handleDrop = (index, letter) => {
    const updatedAnswers = [...answers];
    updatedAnswers[index] = letter;
    setAnswers(updatedAnswers);

    if (!updatedAnswers.includes('') && !showNext) {
      checkAnswer(updatedAnswers);
    }
  };

  const checkAnswer = (updatedAnswers) => {
    let correct = 0;
    updatedAnswers.forEach((answer, index) => {
      if (answer === question.missing_letters[index]) {
        correct += 1;
      }
    });
    if (correct === question.missing_letters.length) {
      setIsCorrect(true);
      setShowNext(true);
    } else {
      setIsCorrect(false);
    }
  };

  const handleSubmit = () => {
    let correct = 0;
    answers.forEach((answer, index) => {
      if (answer === question.missing_letters[index]) {
        correct += 1;
      }
    });
    setScore(correct);
    setIsSubmitted(true);
  };

  const onTimeout = () => {
    setShowNext(true);
    alert("Time's up! Submitting your answers.");
    handleSubmit();
  };

  // Avoid rendering if question data is not available
  if (!question) {
    return <div>Loading...</div>;
  }

  return (
    <div className="quiz-container-az">
        <h1>Drag and drop the letter in blank space</h1>

      <h1>Question {currentQuestionIndex + 1}: {question.question}</h1>
      <Timer onTimeout={onTimeout} />
      <div className="question">
        {question.alphabet.map((letter, index) => (
          <LetterBox
            key={index}
            index={index}
            handleDrop={handleDrop}
            letter={answers[index]}
            isCorrect={isCorrect}
            isFilled={answers[index] !== ''}
          />
        ))}
      </div>
      <div className="letters">
        <div className="letter-grid">
          {['A', 'B', 'C', 'D', 'E', 'F', 'G'].map((letter) => (
            <div
              key={letter}
              draggable
              onDragStart={(e) => e.dataTransfer.setData('letter', letter)}
              className="letter-item"
            >
              {letter}
            </div>
          ))}
        </div>
        <div className="letter-grid">
          {['H', 'I', 'J', 'K', 'L', 'M', 'N'].map((letter) => (
            <div
              key={letter}
              draggable
              onDragStart={(e) => e.dataTransfer.setData('letter', letter)}
              className="letter-item"
            >
              {letter}
            </div>
          ))}
        </div>
        <div className="letter-grid">
          {['O', 'P', 'Q', 'R', 'S', 'T', 'U'].map((letter) => (
            <div
              key={letter}
              draggable
              onDragStart={(e) => e.dataTransfer.setData('letter', letter)}
              className="letter-item"
            >
              {letter}
            </div>
          ))}
        </div>
        <div className="letter-grid">
          {['V', 'W', 'X', 'Y', 'Z'].map((letter) => (
            <div
              key={letter}
              draggable
              onDragStart={(e) => e.dataTransfer.setData('letter', letter)}
              className="letter-item"
            >
              {letter}
            </div>
          ))}
        </div>
      </div>

      {showNext && !isSubmitted && (
        <button className="submit-btn" onClick={handleSubmit}>Submit</button>
      )}
      {isSubmitted && <h2>Score: {score} / {question.missing_letters.length}</h2>}
      {isCorrect === false && !isSubmitted && (
        <button className="try-again-btn" onClick={() => setAnswers(new Array(question.alphabet.length).fill(''))}>Try Again</button>
      )}
      {isSubmitted && currentQuestionIndex + 1 < questions.length && (
        <button className="next-btn" onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}>
          Next Question
        </button>
      )}
    </div>
  );
};

const questions = [
    {
      question: "Fill the sequence from A to Z",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    },
    {
        question: "Complete the sequence: A _ C _ E",
        alphabet: ['A', 'B', 'C', 'D', 'E'],
        missing_letters: ['A', 'B', 'C', 'D', 'E']
      },
      {
        question: "Complete the sequence: F _ H _ J _ L",
        alphabet: ['F', 'G', 'H', 'I', 'J', 'K', 'L'],
        missing_letters: ['F', 'G', 'H', 'I', 'J', 'K', 'L']
      },
      {
        question: "Fill the sequence: O _ P _ Q _ R _ S",
        alphabet: ['O', 'P', 'Q', 'R', 'S'],
        missing_letters: ['O', 'P', 'Q', 'R', 'S']
      },
      {
        question: "Complete the sequence: A _ B _ C _ D _ E",
        alphabet: ['A', 'B', 'C', 'D', 'E'],
        missing_letters: ['A', 'B', 'C', 'D', 'E']
      },
      {
        question: "Fill the sequence: J _ L _ N _ P",
        alphabet: ['J', 'K', 'L', 'M', 'N', 'O', 'P'],
        missing_letters: ['J', 'K', 'L', 'M', 'N', 'O', 'P']
      },
      {
        question: "Complete the sequence: T _ V _ X _ Z",
        alphabet: ['T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
        missing_letters: ['T', 'U', 'V', 'W', 'X', 'Y', 'Z']
      },
      {
        question: "Fill the sequence: D _ F _ G _ I _ K",
        alphabet: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'],
        missing_letters: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K']
      },
      {
        question: "Complete the sequence: A _ D _ G _ J",
        alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'],
        missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
      },
      {
        question: "Fill the sequence: Z _ W _ V _ T",
        alphabet: ['Z', 'Y', 'X', 'W', 'V', 'U', 'T'],
        missing_letters: ['Z', 'Y', 'X', 'W', 'V', 'U', 'T']
      },
      {
        question: "Complete the sequence: M _ O _ Q _ S",
        alphabet: ['M', 'N', 'O', 'P', 'Q', 'R', 'S'],
        missing_letters: ['M', 'N', 'O', 'P', 'Q', 'R', 'S']
      },
      {
        question: "Fill the sequence: K _ L _ M _ N",
        alphabet: ['K', 'L', 'M', 'N', 'O'],
        missing_letters: ['K', 'L', 'M', 'N', 'O']
      },
      {
        question: "Complete the sequence: H _ K _ M _ P",
        alphabet: ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
        missing_letters: ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P']
      },
      {
        question: "Fill the sequence: B _ E _ H _ K",
        alphabet: ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'],
        missing_letters: ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K']
      },
      {
        question: "Complete the sequence: A _ E _ I _ O",
        alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'],
        missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O']
      },
      {
        question: "Fill the sequence: D _ H _ K _ O",
        alphabet: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'],
        missing_letters: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O']
      },
      {
        question: "Complete the sequence: L _ O _ R _ T",
        alphabet: ['L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T'],
        missing_letters: ['L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']
      },
      {
        question: "Fill the sequence: P _ R _ T _ W",
        alphabet: ['P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W'],
        missing_letters: ['P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W']
      },
      {
        question: "Complete the sequence: B _ D _ G _ I",
        alphabet: ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'],
        missing_letters: ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
      },
      {
        question: "Fill the sequence: J _ K _ N _ O",
        alphabet: ['J', 'K', 'L', 'M', 'N', 'O', 'P'],
        missing_letters: ['J', 'K', 'L', 'M', 'N', 'O', 'P']
      },
      {
        question: "Complete the sequence: W _ X _ Y _ Z",
        alphabet: ['W', 'X', 'Y', 'Z'],
        missing_letters: ['W', 'X', 'Y', 'Z']
      },
      {
        question: "Fill the sequence: L _ M _ O _ P",
        alphabet: ['L', 'M', 'N', 'O', 'P'],
        missing_letters: ['L', 'M', 'N', 'O', 'P']
      },
    {
      question: "Fill in the missing letters: A _ C _ E",
      alphabet: ['A', 'B', 'C', 'D', 'E'],
      missing_letters: ['A', 'B', 'C', 'D', 'E']
    },
    {
      question: "Fill the sequence from A to M",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']
    },
    {
      question: "Fill in the missing letters: A _ E _ I _ O _ U",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
      missing_letters: ['A', 'E', 'I', 'O', 'U']
    },
    {
      question: "Fill the missing sequence: _ B _ D _ F _ H _ J _",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
    },
    {
      question: "Fill in the missing letters: D _ F _ H _ J",
      alphabet: ['D', 'E', 'F', 'G', 'H', 'I', 'J'],
      missing_letters: ['D', 'E', 'F', 'G', 'H', 'I', 'J']
    },
    {
      question: "Complete the sequence: A _ C _ E _ G",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    },
    {
      question: "Fill the sequence: Q _ S _ U _ W _",
      alphabet: ['Q', 'R', 'S', 'T', 'U', 'V', 'W'],
      missing_letters: ['Q', 'R', 'S', 'T', 'U', 'V', 'W']
    },
    {
      question: "Fill in the missing letters: M _ O _ P _ Q",
      alphabet: ['M', 'N', 'O', 'P', 'Q'],
      missing_letters: ['M', 'N', 'O', 'P', 'Q']
    },
    {
      question: "Complete the alphabet sequence: A _ C _ E _ G _",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    },
    {
      question: "Fill the missing letters: Z _ Y _ X",
      alphabet: ['X', 'Y', 'Z'],
      missing_letters: ['X', 'Y', 'Z']
    },
    {
      question: "Complete the sequence: B _ D _ F _ H",
      alphabet: ['B', 'C', 'D', 'E', 'F', 'G', 'H'],
      missing_letters: ['B', 'C', 'D', 'E', 'F', 'G', 'H']
    },
    {
      question: "Fill in the missing letters: T _ V _ W _ X",
      alphabet: ['T', 'U', 'V', 'W', 'X'],
      missing_letters: ['T', 'U', 'V', 'W', 'X']
    },
    {
      question: "Complete the sequence: G _ I _ K _ M",
      alphabet: ['G', 'H', 'I', 'J', 'K', 'L', 'M'],
      missing_letters: ['G', 'H', 'I', 'J', 'K', 'L', 'M']
    },
    {
      question: "Fill in the missing letters: J _ L _ N _ P",
      alphabet: ['J', 'K', 'L', 'M', 'N', 'O', 'P'],
      missing_letters: ['J', 'K', 'L', 'M', 'N', 'O', 'P']
    },
    {
      question: "Fill the sequence: A _ E _ I _ O _ U _",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
      missing_letters: ['A', 'E', 'I', 'O', 'U']
    },
    {
      question: "Complete the sequence: D _ G _ J _ M",
      alphabet: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'],
      missing_letters: ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']
    },
    {
      question: "Fill the missing sequence: _ B _ D _ F _ H",
      alphabet: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'],
      missing_letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
    },
    {
      question: "Fill in the missing letters: E _ G _ I _ K",
      alphabet: ['E', 'F', 'G', 'H', 'I', 'J', 'K'],
      missing_letters: ['E', 'F', 'G', 'H', 'I', 'J', 'K']
    },
    {
      question: "Complete the sequence: F _ H _ J _ L",
      alphabet: ['F', 'G', 'H', 'I', 'J', 'K', 'L'],
      missing_letters: ['F', 'G', 'H', 'I', 'J', 'K', 'L']
    },
    {
      question: "Fill the sequence: O _ P _ Q _ R _ S",
      alphabet: ['O', 'P', 'Q', 'R', 'S'],
      missing_letters: ['O', 'P', 'Q', 'R', 'S']
    },
  ];
  
const App = () => {
  return (
    <div className="App">
      <Quiz questions={questions} />
    </div>
  );
};

export default App;
