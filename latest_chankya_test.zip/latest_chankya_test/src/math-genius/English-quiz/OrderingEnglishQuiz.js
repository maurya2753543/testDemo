import React, { useState, useEffect } from 'react';
import '../../kbc/OrderQuizApp.css';


import OrderQuizAppEnglish from './OrderQuizAppEnglish.json';

const QuizAppLevel5 = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [options, setOptions] = useState([]);
  const [userAnswers, setUserAnswers] = useState(Array(4).fill(''));
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timer, setTimer] = useState(3600); // 2 hours in seconds

  const currentQuestion = OrderQuizAppEnglish[currentIndex];

  // Shuffle options when question changes
  useEffect(() => {
    setOptions(shuffleArray([...currentQuestion.answers]));
  }, [currentQuestion]);

  // Countdown Timer
  useEffect(() => {
    const interval = setInterval(() => {
      if (timer > 0) {
        setTimer((prev) => prev - 1);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [timer]);

  // Format Timer
  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  // Shuffle Function
  const shuffleArray = (array) => array.sort(() => Math.random() - 0.5);

  // Drag and Drop Handlers
  const handleDragStart = (e, answer) => e.dataTransfer.setData('text', answer);
  const handleDrop = (e, index) => {
    const draggedAnswer = e.dataTransfer.getData('text');
    const updatedAnswers = [...userAnswers];
    updatedAnswers[index] = draggedAnswer;
    setUserAnswers(updatedAnswers);
  };

  const handleDragOver = (e) => e.preventDefault();

  // Check if all answers are filled
  const isAllFilled = userAnswers.every((answer) => answer !== '');

  // Handle Submit
  const handleSubmit = () => {
    const correctOrder = currentQuestion.correctOrder;
    const isAnswerCorrect = userAnswers.every(
      (ans, idx) => ans === correctOrder[idx]
    );
    setIsCorrect(isAnswerCorrect);
    setIsSubmitted(true);
  };

  // Next Question
  const handleNextQuestion = () => {
    setCurrentIndex((prev) => prev + 1);
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
    setIsCorrect(false);
  };
  const resetQuiz = () => {
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
  };

  return (
    <div className="quiz-app">
      <h2>Time Left: {formatTime(timer)}</h2>
      <div className="progress-bar">
        <div
          className="progress"
          style={{ width: `${(timer / 3600) * 100}%` }}
        ></div>
      </div>
      <h3>{currentQuestion.question}</h3>

      {/* Options */}
      <div className="options">
        {options.map((option, index) => (
          <div
            key={index}
            draggable
            onDragStart={(e) => handleDragStart(e, option)}
            className="option"
          >
            {option}
          </div>
        ))}
      </div>

      {/* Answer Boxes */}
      <div className="answer-boxes">
        {userAnswers.map((answer, index) => (
          <div
            key={index}
            className="answer-box"
            onDrop={(e) => handleDrop(e, index)}
            onDragOver={handleDragOver}
          >
            {answer || 'Drop Here'}
          </div>
        ))}
      </div>

      {/* Submit Button */}
      {isAllFilled && !isSubmitted && (
        <button className='submit-btn' onClick={handleSubmit}>Submit</button>
      )}

      {/* Results */}
      {isSubmitted && (
        <div>
          {isCorrect ? (
            <>
              <p>Correct Answer!</p>
              
              {currentIndex < OrderQuizAppEnglish.length - 1 && (
                <button className='submit-btn' onClick={handleNextQuestion}>Next Question</button>
              )}
            </>
          ) : (
            <>
             <p>Incorrect!.</p>
            <button className="reset-btn" onClick={resetQuiz}>
            Try Again
          </button>
            </>
           
          )}
        </div>
      )}
    </div>
  );
};

export default QuizAppLevel5;
