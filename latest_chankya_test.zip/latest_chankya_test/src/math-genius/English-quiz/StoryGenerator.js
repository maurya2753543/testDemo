import React, { useState, useEffect } from "react";
import "./StoryGenerator.css";
import stories from "./Story.json";

const QuizApp = () => {
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const [errorMessage, setErrorMessage] = useState(""); // State to manage the error message
  const [timer, setTimer] = useState(3600); // 1 hour in seconds
  const [results, setResults] = useState([]);
  const [showResults, setShowResults] = useState(false);

  const currentStory = stories[currentStoryIndex];
  const currentQuestion = currentStory.questions[currentQuestionIndex];

  // Timer logic
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setShowResults(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Handle answer selection
  const handleAnswerSelection = (option) => {
    setSelectedAnswer(option);
    setErrorMessage(""); // Clear error message on new selection
  };

  // Handle Next Button
  const handleNext = () => {
    if (selectedAnswer === currentQuestion.correctAnswer) {
      setResults((prev) => [...prev, { storyId: currentStory.storyId, correct: true }]);
      if (currentQuestionIndex + 1 < currentStory.questions.length) {
        setCurrentQuestionIndex((prev) => prev + 1);
      } else if (currentStoryIndex + 1 < stories.length) {
        setCurrentStoryIndex((prev) => prev + 1);
        setCurrentQuestionIndex(0);
      } else {
        setShowResults(true);
      }
      setSelectedAnswer("");
    } else {
      setErrorMessage("Incorrect! Please try again.");
    }
  };

  // Timer Formatting
  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  return (
    <div className="quiz-container-story">
      {!showResults ? (
        <>
          <h1>{currentStory.title}</h1>
          <p className="story-text">{currentStory.storyText}</p>
          <div className="timer-bar" style={{ width: `${(timer / 3600) * 100}%` }} />
          <p>Time Remaining: {formatTime(timer)}</p>
          <div className="question-section">
            <p className="question-number">
              Question {currentQuestionIndex + 1}/{currentStory.questions.length}
            </p>
            <p className="question-text">{currentQuestion.question}</p>
            <div className="options-container">
              {currentQuestion.options.map((option, index) => (
                <label key={index} className="option-box">
                  <input
                  style={{width : '10px'}}
                    type="radio"
                    name="answer"
                    value={option}
                    onChange={() => handleAnswerSelection(option)}
                    checked={selectedAnswer === option}
                  />
                  {option}
                </label>
              ))}
            </div>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
          </div>
          <button className="button" onClick={handleNext} disabled={!selectedAnswer}>
            Next
          </button>
        </>
      ) : (
        <div className="result">
          <h1>Quiz Results</h1>
          <p>
            You answered {results.filter((result) => result.correct).length} out of{" "}
            {stories.reduce((acc, story) => acc + story.questions.length, 0)} questions correctly.
          </p>
        </div>
      )}
    </div>
  );
};

export default QuizApp;
