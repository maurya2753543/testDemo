// Timer.js
import React, { useState, useEffect } from 'react';

const Timer = ({ onTimeout }) => {
  const [time, setTime] = useState(300); // 5 minutes in seconds

  useEffect(() => {
    if (time === 0) {
      onTimeout();
      return;
    }
    const interval = setInterval(() => setTime(prev => prev - 1), 1000);
    return () => clearInterval(interval);
  }, [time, onTimeout]);

  return (
    <div>
      <h3>Time Left: {Math.floor(time / 60)}:{time % 60}</h3>
    </div>
  );
};

export default Timer;
