// LetterBox.js
import React from 'react';
import { useDrag, useDrop } from 'react-dnd';

const LetterBox = ({ index, handleDrop, currentLetter }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'letter',
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'letter',
    drop: (item) => handleDrop(index, item.index),
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }));

  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const dropLetter = (letter) => {
    handleDrop(index, letter);
  };

  return (
    <div ref={drag} style={{ display: 'inline-block', margin: '10px' }}>
      {letters.map((letter) => (
        <div
          key={letter}
          onClick={() => dropLetter(letter)}
          style={{
            padding: '10px',
            cursor: 'pointer',
            backgroundColor: isDragging ? 'lightgreen' : 'lightblue',
            border: isOver ? '2px dashed #000' : 'none',
          }}
        >
          {letter}
        </div>
      ))}
    </div>
  );
};

export default LetterBox;
