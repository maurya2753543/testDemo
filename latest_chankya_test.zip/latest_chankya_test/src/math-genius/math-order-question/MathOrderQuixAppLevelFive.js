import React, { useState, useEffect } from 'react';
import '../../kbc/OrderQuizApp.css';
import OrderQuizApp from './MathOrderQuixAppLevelFive.json';
import { FaCalculator } from 'react-icons/fa'; // Importing a beautiful icon from react-icons
import WhiteboardCalculatorCubeSqure from '../WhiteboardCalculatorCubeSqure';
const QuizApp = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [options, setOptions] = useState([]);
  const [userAnswers, setUserAnswers] = useState(Array(4).fill(''));
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timer, setTimer] = useState(7200); // 2 hours in seconds
  const [isFormulaOpen, setIsFormulaOpen] = useState(false); // State for popup

  const currentQuestion = OrderQuizApp[currentIndex];

  // Shuffle options when question changes
  useEffect(() => {
    setOptions(shuffleArray([...currentQuestion.answers]));
  }, [currentQuestion]);

  // Countdown Timer
  useEffect(() => {
    const interval = setInterval(() => {
      if (timer > 0) {
        setTimer((prev) => prev - 1);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [timer]);

  // Format Timer
  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  // Shuffle Function
  const shuffleArray = (array) => array.sort(() => Math.random() - 0.5);

  // Drag and Drop Handlers
  const handleDragStart = (e, answer) => e.dataTransfer.setData('text', answer);
  const handleDrop = (e, index) => {
    const draggedAnswer = e.dataTransfer.getData('text');
    const updatedAnswers = [...userAnswers];
    updatedAnswers[index] = draggedAnswer;
    setUserAnswers(updatedAnswers);
  };

  const handleDragOver = (e) => e.preventDefault();

  // Check if all answers are filled
  const isAllFilled = userAnswers.every((answer) => answer !== '');

  // Handle Submit
  const handleSubmit = () => {
    const correctOrder = currentQuestion.correctOrder;
    const isAnswerCorrect = userAnswers.every(
      (ans, idx) => ans === correctOrder[idx]
    );
    setIsCorrect(isAnswerCorrect);
    setIsSubmitted(true);
  };

  // Next Question
  const handleNextQuestion = () => {
    setCurrentIndex((prev) => prev + 1);
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
    setIsCorrect(false);
  };
  
  const resetQuiz = () => {
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
  };

  // Toggle Formula Popup
  const toggleFormulaPopup = () => {
    setIsFormulaOpen(!isFormulaOpen);
  };

  return (
    <div className="quiz-app">
      {/* Top Right "See Formula" Button */}
      <div className="see-formula-btn" onClick={toggleFormulaPopup}>    
        <span>See Formula </span>             

        <FaCalculator size={20} title="See Formula" />
       
      </div>

      <h2>Time Left: {formatTime(timer)}</h2>
      <div className="progress-bar">
        <div
          className="progress"
          style={{ width: `${(timer / 7200) * 100}%` }}
        ></div>
      </div>
      <h3>{currentQuestion.question}</h3>

      {/* Options */}
      <div className="options">
        {options.map((option, index) => (
          <div
            key={index}
            draggable
            onDragStart={(e) => handleDragStart(e, option)}
            className="option"
          >
            {option}
          </div>
        ))}
      </div>

      {/* Answer Boxes */}
      <div className="answer-boxes">
        {userAnswers.map((answer, index) => (
          <div
            key={index}
            className="answer-box"
            onDrop={(e) => handleDrop(e, index)}
            onDragOver={handleDragOver}
          >
            {answer || 'Drop Here'}
          </div>
        ))}
      </div>

      {/* Submit Button */}
      {isAllFilled && !isSubmitted && (
        <button className='submit-btn' onClick={handleSubmit}>Submit</button>
      )}

      {/* Results */}
      {isSubmitted && (
        <div>
          {isCorrect ? (
            <>
              <p>Correct Answer!</p>
              
              {currentIndex < OrderQuizApp.length - 1 && (
                <button className='submit-btn' onClick={handleNextQuestion}>Next Question</button>
              )}
            </>
          ) : (
            <>
              <p>Incorrect!.</p>
              <button className="reset-btn" onClick={resetQuiz}>
                Try Again
              </button>
              <WhiteboardCalculatorCubeSqure />
            </>
          )}
        </div>
      )}

      {/* Formula Popup */}
      {isFormulaOpen && (
        <div className="formula-popup">
          <div className="formula-content">
            <h4>Mathematical Formulas</h4>
            <ul>
  <li><strong>Time Addition/Subtraction:</strong> Example: 3 hours 45 minutes + 2 hours 30 minutes = 6 hours 15 minutes, 5 hours 30 minutes - 2 hours 15 minutes = 3 hours 15 minutes</li>
  <li><strong>Time Multiplication/Division:</strong> Example: 2 hours × 3 = 6 hours, 12 hours ÷ 4 = 3 hours</li>
  <li><strong>Time Conversion (Hours to Minutes/Seconds):</strong> Example: 2 hours = 120 minutes, 1 hour = 3600 seconds</li>
  <li><strong>Time Conversion (Minutes to Seconds):</strong> Example: 1 minute = 60 seconds, 5 minutes = 300 seconds</li>
  <li><strong>Time Conversion (Seconds to Minutes):</strong> Example: 120 seconds = 2 minutes, 3600 seconds = 60 minutes</li>
  <li><strong>Rounding Time:</strong> Example: Round(2.75 hours) = 3 hours, Round(1.25 hours) = 1 hour</li>
  <li><strong>Percentage of Time:</strong> Example: 50% of 8 hours = 4 hours, 30% of 5 hours = 1 hour 30 minutes</li>
  <li><strong>Handling Time Format:</strong> Example: 2 hours 45 minutes = 2.75 hours, 3 hours 50 minutes = 3.83 hours</li>
</ul>


            <button className="close-btn" onClick={toggleFormulaPopup}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuizApp;
