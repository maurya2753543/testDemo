import React, { useState, useEffect } from 'react';
import '../../kbc/OrderQuizApp.css';
import OrderQuizApp from './MathOrderQuixAppLevelSix.json';
import { FaCalculator } from 'react-icons/fa'; // Importing a beautiful icon from react-icons
import WhiteboardCalculatorCubeSqure from '../WhiteboardCalculatorCubeSqure';
const QuizApp = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [options, setOptions] = useState([]);
  const [userAnswers, setUserAnswers] = useState(Array(4).fill(''));
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timer, setTimer] = useState(7200); // 2 hours in seconds
  const [isFormulaOpen, setIsFormulaOpen] = useState(false); // State for popup

  const currentQuestion = OrderQuizApp[currentIndex];

  // Shuffle options when question changes
  useEffect(() => {
    setOptions(shuffleArray([...currentQuestion.answers]));
  }, [currentQuestion]);

  // Countdown Timer
  useEffect(() => {
    const interval = setInterval(() => {
      if (timer > 0) {
        setTimer((prev) => prev - 1);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [timer]);

  // Format Timer
  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  // Shuffle Function
  const shuffleArray = (array) => array.sort(() => Math.random() - 0.5);

  // Drag and Drop Handlers
  const handleDragStart = (e, answer) => e.dataTransfer.setData('text', answer);
  const handleDrop = (e, index) => {
    const draggedAnswer = e.dataTransfer.getData('text');
    const updatedAnswers = [...userAnswers];
    updatedAnswers[index] = draggedAnswer;
    setUserAnswers(updatedAnswers);
  };

  const handleDragOver = (e) => e.preventDefault();

  // Check if all answers are filled
  const isAllFilled = userAnswers.every((answer) => answer !== '');

  // Handle Submit
  const handleSubmit = () => {
    const correctOrder = currentQuestion.correctOrder;
    const isAnswerCorrect = userAnswers.every(
      (ans, idx) => ans === correctOrder[idx]
    );
    setIsCorrect(isAnswerCorrect);
    setIsSubmitted(true);
  };

  // Next Question
  const handleNextQuestion = () => {
    setCurrentIndex((prev) => prev + 1);
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
    setIsCorrect(false);
  };
  
  const resetQuiz = () => {
    setUserAnswers(Array(4).fill(''));
    setIsSubmitted(false);
  };

  // Toggle Formula Popup
  const toggleFormulaPopup = () => {
    setIsFormulaOpen(!isFormulaOpen);
  };

  return (
    <div className="quiz-app">
      {/* Top Right "See Formula" Button */}
      <div className="see-formula-btn" onClick={toggleFormulaPopup}>    
        <span>See Formula </span>             

        <FaCalculator size={20} title="See Formula" />
       
      </div>

      <h2>Time Left: {formatTime(timer)}</h2>
      <div className="progress-bar">
        <div
          className="progress"
          style={{ width: `${(timer / 7200) * 100}%` }}
        ></div>
      </div>
      <h3>{currentQuestion.question}</h3>

      {/* Options */}
      <div className="options">
        {options.map((option, index) => (
          <div
            key={index}
            draggable
            onDragStart={(e) => handleDragStart(e, option)}
            className="option"
          >
            {option}
          </div>
        ))}
      </div>

      {/* Answer Boxes */}
      <div className="answer-boxes">
        {userAnswers.map((answer, index) => (
          <div
            key={index}
            className="answer-box"
            onDrop={(e) => handleDrop(e, index)}
            onDragOver={handleDragOver}
          >
            {answer || 'Drop Here'}
          </div>
        ))}
      </div>

      {/* Submit Button */}
      {isAllFilled && !isSubmitted && (
        <button className='submit-btn' onClick={handleSubmit}>Submit</button>
      )}

      {/* Results */}
      {isSubmitted && (
        <div>
          {isCorrect ? (
            <>
              <p>Correct Answer!</p>
              
              {currentIndex < OrderQuizApp.length - 1 && (
                <button className='submit-btn' onClick={handleNextQuestion}>Next Question</button>
              )}
            </>
          ) : (
            <>
              <p>Incorrect!.</p>
              <button className="reset-btn" onClick={resetQuiz}>
                Try Again
              </button>
              <WhiteboardCalculatorCubeSqure />
            </>
          )}
        </div>
      )}

      {/* Formula Popup */}
      {isFormulaOpen && (
        <div className="formula-popup">
          <div className="formula-content">
            <h4>Mathematical Formulas</h4>
            <ul> <li><strong>Finding Factors of a Number:</strong> Example: Factors of 12 = 1, 2, 3, 4, 6, 12</li> <li><strong>Prime Factorization:</strong> Example: Prime factors of 18 = 2, 3, 3 (18 = 2 × 3 × 3)</li> <li><strong>Common Factors:</strong> Example: Common factors of 12 and 18 = 1, 2, 3, 6</li> <li><strong>Greatest Common Factor (GCF):</strong> Example: GCF of 36 and 48 = 12</li> <li><strong>Least Common Multiple (LCM):</strong> Example: LCM of 6 and 8 = 24</li> <li><strong>Factor Pair Calculation:</strong> Example: Factor pairs of 36 = (1, 36), (2, 18), (3, 12), (4, 9), (6, 6)</li> </ul>
            <button className="close-btn" onClick={toggleFormulaPopup}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuizApp;
