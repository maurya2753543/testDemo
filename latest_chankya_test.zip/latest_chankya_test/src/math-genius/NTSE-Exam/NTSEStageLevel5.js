import React, { useState, useEffect } from "react";
import "./NTSEStageLevel5.css"; // Assuming this is the main CSS file
import img_question_one from "../../images/img_question_one.png";
import img_question_two from "../../images/img_question_two.png";
import ima_question_three from "../../images/ima_question_three.png";
import img_question_four from "../../images/img_question_four.png";
import img_question_five from "../../images/img_question_five.png";
import img_question_six from "../../images/img_question_six.png";
import img_seven from "../../images/img_seven.png";
import img_eight from "../../images/img_eight.png";
import img_ten from "../../images/img_ten.png";
import img_eleven from "../../images/img_eleven.png";
import img_12 from "../../images/img_12.png";
import img_13 from "../../images/img_13.png";
import img_14 from "../../images/img_14.png";
import img_15 from "../../images/img_15.png";
import img_17 from "../../images/img_17.png";
import img_16 from "../../images/img_16.png";
import img_18 from "../../images/img_18.png";
import img_19 from "../../images/img_19.png";
import img_20 from "../../images/img_20.png";
import img_21 from "../../images/img_21.png";





const quizData = [
  {
    "question": "Study the following table carefully and answer the questions: Number of students in different classes of XYZ Primary school:",
    "image": img_question_one,
    "subQuestions": [
      {
        "question": "The difference between the sum of all the students in all the classes in 2017 and 2018 is:",
        "options": [
          { "answer": "20", "correct": false },
          { "answer": "25", "correct": true },
          { "answer": "60", "correct": false },
          { "answer": "65", "correct": false }
        ]
      },
      {
        "question": "The sum of all the students in class III in all the years is what percent of the sum of all students of class I in all the years approximately?",
        "options": [
          { "answer": "150 %", "correct": false },
          { "answer": "180 %", "correct": false },
          { "answer": "130 %", "correct": false },
          { "answer": "135 %", "correct": true }

        ]
      },
      {
        "question": "The square of sum of all the students of all classes in year 2018 is:",
        "options": [
          { "answer": "1950", "correct": false },
          { "answer": "180 %", "correct": false },
          { "answer": "135 %", "correct": true },

          { "answer": "130 %", "correct": false }
        ]
      }
    ]
  },
  {
    "question": "In which of the following question a group of three pictures are given. You have to find out the fourth picture. You have to select the answer from (a), (b), (c) and (d):",
    "image": img_question_two,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "A", "correct": false },
          { "answer": "B", "correct": false },
          { "answer": "C", "correct": false },
          { "answer": "D", "correct": true }
        ]
      },
    
    ]
  },
  {
    "question": "Select the correct picture. You have to select the answer from (a), (b), (c) and (d):",
    "image": ima_question_three,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "A", "correct": false },
          { "answer": "B", "correct": false },
          { "answer": "C", "correct": false },
          { "answer": "D", "correct": true }
        ]
      },
    
    ]
  },
  {
    "question": "Select the correct picture. You have to select the answer from (a), (b), (c) and (d):",
    "image": img_question_four,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "A", "correct": false },
          { "answer": "B", "correct": true },
          { "answer": "C", "correct": false },
          { "answer": "D", "correct": false}
        ]
      },
    
    ]
  },
  {
    "question": "In which of the following question a group of three pictures are given. You have to find out the fourth picture. You have to select the answer from (a), (b), (c) and (d):",
    "image": img_question_five,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "A", "correct": false },
          { "answer": "B", "correct": false },
          { "answer": "C", "correct": false },
          { "answer": "D", "correct": true }
        ]
      },
    
    ]
  },
  {
    "question": "Find out the correct one which is different from three others and choose the correct option.",
    "image": img_question_six,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "1", "correct": false },
          { "answer": "2", "correct": false },
          { "answer": "3", "correct": true },
          { "answer": "4", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_seven,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "9", "correct": false },
          { "answer": "7", "correct": false },
          { "answer": "3", "correct": true },
          { "answer": "5", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_eight,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "70", "correct": true },
          { "answer": "80", "correct": false },
          { "answer": "90", "correct": false },
          { "answer": "40", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_ten,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "412", "correct": false },
          { "answer": "441", "correct": true },
          { "answer": "412", "correct": false },
          { "answer": "490", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_eleven,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "K7", "correct": false },
          { "answer": "K8", "correct": true },
          { "answer": "K1", "correct": false },
          { "answer": "K6", "correct": false }
        ]
      },
    
    ]
  }, 
 
  {
    "question": " Find out the correct alternative.",
    "image": img_12,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "6", "correct": true },
          { "answer": "4", "correct": false },
          { "answer": "9", "correct": false },
          { "answer": "5", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_13,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "14", "correct": false },
          { "answer": "9", "correct": false },
          { "answer": "10", "correct": true },
          { "answer": "5", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_14,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "91", "correct": false },
          { "answer": "9", "correct": true },
          { "answer": "14", "correct": false },
          { "answer": "15", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_15,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "7", "correct": true },
          { "answer": "4", "correct": false },
          { "answer": "9", "correct": false },
          { "answer": "5", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_16,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "5/4", "correct": true },
          { "answer": "4/9", "correct": false },
          { "answer": "9/8", "correct": false },
          { "answer": "5/13", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_17,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "140", "correct": false },
          { "answer": "190", "correct": false },
          { "answer": "100", "correct": true },
          { "answer": "150", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_18,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "JL11", "correct": false },
          { "answer": "JL22", "correct": true },
          { "answer": "KL21", "correct": false },
          { "answer": "KL18", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_19,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "62", "correct": true },
          { "answer": "24", "correct": false },
          { "answer": "94", "correct": false },
          { "answer": "54", "correct": false }
        ]
      },
    
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_20,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "2031", "correct": true },
          { "answer": "409", "correct": false },
          { "answer": "9098", "correct": false },
          { "answer": "1", "correct": false }
        ]
      },
    
      
    ]
  },
  {
    "question": " Find out the correct alternative.",
    "image": img_21,
    "subQuestions": [
      {
        "question": "Select the correct picture.",
        "options": [
          { "answer": "A", "correct": false },
          { "answer": "B", "correct": false },
          { "answer": "C", "correct": true },
          { "answer": "D", "correct": false }
        ]
      },
    
      
    ]
  },
  
];

const NTSE5 = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentSubQuestionIndex, setCurrentSubQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [quizStarted, setQuizStarted] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(30 * 30); // 1 hour in seconds
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);

  const startQuiz = () => setQuizStarted(true);

  const handleAnswerSubmit = () => {
    const currentMainQuestion = quizData[currentQuestionIndex];
    if (!currentMainQuestion || !currentMainQuestion.subQuestions) return;

    const currentSubQuestion = currentMainQuestion.subQuestions[currentSubQuestionIndex];
    if (currentSubQuestion && currentSubQuestion.options[selectedAnswer]?.correct) {
      setScore(score + 1);
    } else {
      setWrongAnswers(wrongAnswers + 1);
    }
    setIsAnswerSubmitted(true);
  };

  const handleNextQuestion = () => {
    const currentMainQuestion = quizData[currentQuestionIndex];
    if (!currentMainQuestion || !currentMainQuestion.subQuestions) return;

    if (currentSubQuestionIndex < currentMainQuestion.subQuestions.length - 1) {
      setCurrentSubQuestionIndex(currentSubQuestionIndex + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    } else if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setCurrentSubQuestionIndex(0);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    } else {
      setShowResult(true);
    }
  };

  const restartQuiz = () => {
    setQuizStarted(false);
    setCurrentQuestionIndex(0);
    setCurrentSubQuestionIndex(0);
    setScore(0);
    setWrongAnswers(0);
    setShowResult(false);
    setTimeRemaining(30 * 30);
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 30);
    const seconds = time % 30;
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  const progressPercentage = ((30 * 60 - timeRemaining) / (30 * 60)) * 100;

  useEffect(() => {
    if (quizStarted && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining((prevTime) => prevTime - 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [quizStarted, timeRemaining]);

  const progressColor = timeRemaining <= 300 ? "red" : "blue"; // Change color to red when less than 5 minutes remain

  if (!quizStarted) {
    return (
      <div className="quiz-start-container">
        <h1>Welcome!</h1>
        <button onClick={startQuiz}>Start Quiz</button>
      </div>
    );
  }

  if (showResult) {
    return (
      <div className="result-container">
        <h1>Quiz Completed</h1>
        <p>Score: {score}</p>
        <p>Wrong Answers: {wrongAnswers}</p>
        <button className="restart-button" onClick={restartQuiz}>Restart Quiz</button>
      </div>
    );
  }

  const currentMainQuestion = quizData[currentQuestionIndex];
  const currentSubQuestion = currentMainQuestion?.subQuestions?.[currentSubQuestionIndex];

  return (
    <div className="quiz-container">
      <div className="timer-container">
        <div className="progress-bar" style={{ width: `${progressPercentage}%`, backgroundColor: progressColor }}></div>
        <p>Time Remaining: {formatTime(timeRemaining)}</p>
      </div>
      <div className="question-container">
        <h2>
          Main Question {currentQuestionIndex + 1}/{quizData.length}: {currentMainQuestion?.question}
        </h2>
        <img src={currentMainQuestion?.image || img_question_one} alt="Question Illustration" className="question-image" />
        <h3>
          Sub-Question {currentSubQuestionIndex + 1}/{currentMainQuestion?.subQuestions?.length}:{" "}
          {currentSubQuestion?.question}
        </h3>
        <div className="options-container">
          {currentSubQuestion?.options?.map((option, index) => (
            <div key={index} className="option-item">
              <label className="radio-option">
                <input
                  type="radio"
                  style={{width : '15px'}}
                  name="option"
                  value={index}
                  checked={selectedAnswer === index}
                  onChange={() => setSelectedAnswer(index)}
                />
                {option.answer}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div className="button-container">
        <button onClick={handleAnswerSubmit} disabled={selectedAnswer === null || isAnswerSubmitted}>Submit</button>
        <button onClick={handleNextQuestion} disabled={!isAnswerSubmitted}>Next</button>
        <button onClick={() => setShowResult(true)}>End Quiz</button>
      </div>
    </div>
  );
};

export default NTSE5;
