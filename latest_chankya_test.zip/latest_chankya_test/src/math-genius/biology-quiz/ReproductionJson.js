export const quizQuestions = [
    {
      "id": 1,
      "question": "What is the main method of reproduction in flowering plants?",
      "options": [
        "Asexual reproduction",
        "Sexual reproduction",
        "Budding",
        "Binary fission"
      ],
      "correct": "Sexual reproduction"
    },
    {
      "id": 2,
      "question": "Which part of a flower is responsible for producing pollen?",
      "options": [
        "Petals",
        "Stigma",
        "Anther",
        "Ovary"
      ],
      "correct": "Anther"
    },
    {
      "id": 3,
      "question": "In which part of the animal body does fertilization occur?",
      "options": [
        "Ovary",
        "Uterus",
        "Fallopian tubes",
        "Vagina"
      ],
      "correct": "Fallopian tubes"
    },
    {
      "id": 4,
      "question": "What is the main difference between asexual and sexual reproduction?",
      "options": [
        "Asexual reproduction involves one parent, while sexual reproduction involves two parents.",
        "Asexual reproduction produces genetically diverse offspring.",
        "Sexual reproduction involves mitosis, while asexual reproduction involves meiosis.",
        "Asexual reproduction requires external fertilization."
      ],
      "correct": "Asexual reproduction involves one parent, while sexual reproduction involves two parents."
    },
    {
      "id": 5,
      "question": "What is the term for the process by which plants make seeds?",
      "options": [
        "Pollination",
        "Fertilization",
        "Germination",
        "Photosynthesis"
      ],
      "correct": "Pollination"
    },
    {
      "id": 6,
      "question": "Which type of reproduction occurs in Hydra and some plants like strawberries?",
      "options": [
        "Sexual reproduction",
        "Asexual reproduction",
        "Binary fission",
        "Budding"
      ],
      "correct": "Budding"
    },
    {
      "id": 7,
      "question": "Which of the following animals uses external fertilization?",
      "options": [
        "Frogs",
        "Humans",
        "Elephants",
        "Dogs"
      ],
      "correct": "Frogs"
    },
    {
      "id": 8,
      "question": "Which term refers to the union of male and female gametes?",
      "options": [
        "Fertilization",
        "Pollination",
        "Regeneration",
        "Budding"
      ],
      "correct": "Fertilization"
    },
    {
      "id": 9,
      "question": "Which method of reproduction involves only one parent organism?",
      "options": [
        "Sexual reproduction",
        "Asexual reproduction",
        "Mating",
        "Cross-pollination"
      ],
      "correct": "Asexual reproduction"
    },
    {
      "id": 10,
      "question": "Which structure in a flower receives pollen during pollination?",
      "options": [
        "Stigma",
        "Style",
        "Ovary",
        "Anther"
      ],
      "correct": "Stigma"
    },
    {
      "id": 11,
      "question": "What type of reproduction does a starfish undergo when it regenerates a lost arm?",
      "options": [
        "Budding",
        "Asexual reproduction",
        "Sexual reproduction",
        "Fragmentation"
      ],
      "correct": "Fragmentation"
    },
    {
      "id": 12,
      "question": "What is the result of sexual reproduction in animals?",
      "options": [
        "Cloning",
        "Genetically identical offspring",
        "Genetically diverse offspring",
        "Regeneration"
      ],
      "correct": "Genetically diverse offspring"
    },
    {
      "id": 13,
      "question": "Which animal is known for its ability to reproduce through parthenogenesis?",
      "options": [
        "Bees",
        "Sharks",
        "Komodo dragons",
        "All of the above"
      ],
      "correct": "All of the above"
    },
    {
      "id": 14,
      "question": "Which plant part contains the female gametes?",
      "options": [
        "Anther",
        "Stigma",
        "Ovary",
        "Pollen"
      ],
      "correct": "Ovary"
    },
    {
      "id": 15,
      "question": "What is the process by which animals reproduce by external fertilization?",
      "options": [
        "Egg-laying",
        "Live birth",
        "Internal fertilization",
        "External fertilization"
      ],
      "correct": "External fertilization"
    },
    {
      "id": 16,
      "question": "Which method of reproduction involves the development of offspring from an unfertilized egg?",
      "options": [
        "Sexual reproduction",
        "Parthenogenesis",
        "Binary fission",
        "Fragmentation"
      ],
      "correct": "Parthenogenesis"
    },
    {
      "id": 17,
      "question": "In which type of environment do animals like frogs typically carry out external fertilization?",
      "options": [
        "On land",
        "In water",
        "In trees",
        "Underground"
      ],
      "correct": "In water"
    },
    {
      "id": 18,
      "question": "What is the primary function of pollinators?",
      "options": [
        "To fertilize flowers",
        "To carry pollen between flowers",
        "To grow new plants",
        "To disperse seeds"
      ],
      "correct": "To carry pollen between flowers"
    },
    {
      "id": 19,
      "question": "Which of these plants reproduces via runners?",
      "options": [
        "Carrot",
        "Strawberry",
        "Cactus",
        "Sunflower"
      ],
      "correct": "Strawberry"
    },
    {
      "id": 20,
      "question": "In what way do amphibians typically reproduce?",
      "options": [
        "Eggs laid in water and fertilized externally",
        "Live birth",
        "Eggs laid on land and fertilized internally",
        "Budding"
      ],
      "correct": "Eggs laid in water and fertilized externally"
    },
    {
        "id": 21,
        "question": "What is the term for asexual reproduction in which new individuals are formed from a part of the parent organism?",
        "options": [
          "Budding",
          "Fission",
          "Fragmentation",
          "Regeneration"
        ],
        "correct": "Budding"
      },
      {
        "id": 22,
        "question": "Which of the following plants reproduce by vegetative propagation?",
        "options": [
          "Banana",
          "Apple",
          "Orange",
          "Coconut"
        ],
        "correct": "Banana"
      },
      {
        "id": 23,
        "question": "Which is a characteristic of sexual reproduction?",
        "options": [
          "Involves two parents",
          "Offspring are genetically identical to the parent",
          "Occurs through binary fission",
          "Does not require gametes"
        ],
        "correct": "Involves two parents"
      },
      {
        "id": 24,
        "question": "What is the function of the male gamete (sperm) in sexual reproduction?",
        "options": [
          "To fertilize the egg",
          "To carry nutrients to the offspring",
          "To produce seeds",
          "To form new roots"
        ],
        "correct": "To fertilize the egg"
      },
      {
        "id": 25,
        "question": "In flowering plants, what structure develops into the fruit after fertilization?",
        "options": [
          "Stigma",
          "Style",
          "Ovary",
          "Anther"
        ],
        "correct": "Ovary"
      },
      {
        "id": 26,
        "question": "Which type of cell division results in the formation of gametes?",
        "options": [
          "Mitosis",
          "Meiosis",
          "Binary fission",
          "Budding"
        ],
        "correct": "Meiosis"
      },
      {
        "id": 27,
        "question": "Which of the following is an example of internal fertilization?",
        "options": [
          "Fish",
          "Frogs",
          "Humans",
          "Corals"
        ],
        "correct": "Humans"
      },
      {
        "id": 28,
        "question": "What is the term for the fusion of male and female gametes to form a zygote?",
        "options": [
          "Regeneration",
          "Fertilization",
          "Budding",
          "Fragmentation"
        ],
        "correct": "Fertilization"
      },
      {
        "id": 29,
        "question": "Which of these organisms can reproduce both sexually and asexually?",
        "options": [
          "Starfish",
          "Coral",
          "Hydra",
          "Earthworm"
        ],
        "correct": "Hydra"
      },
      {
        "id": 30,
        "question": "In animals, what does external fertilization typically require?",
        "options": [
          "Water",
          "Oxygen",
          "Heat",
          "High light levels"
        ],
        "correct": "Water"
      },
      {
        "id": 31,
        "question": "Which of these animals exhibits ovoviviparity, where the eggs hatch inside the mother's body?",
        "options": [
          "Sharks",
          "Frogs",
          "Birds",
          "Reptiles"
        ],
        "correct": "Sharks"
      },
      {
        "id": 32,
        "question": "What type of asexual reproduction occurs in bacteria?",
        "options": [
          "Budding",
          "Fission",
          "Fragmentation",
          "Regeneration"
        ],
        "correct": "Fission"
      },
      {
        "id": 33,
        "question": "Which part of a flower becomes the seed after fertilization?",
        "options": [
          "Ovary",
          "Style",
          "Stigma",
          "Anther"
        ],
        "correct": "Ovary"
      },
      {
        "id": 34,
        "question": "Which of the following is a form of asexual reproduction that involves the growth of a new organism from a piece of the parent?",
        "options": [
          "Budding",
          "Fragmentation",
          "Regeneration",
          "Mitosis"
        ],
        "correct": "Fragmentation"
      },
      {
        "id": 35,
        "question": "What is the primary role of the placenta in mammals?",
        "options": [
          "To protect the developing embryo",
          "To produce eggs",
          "To remove waste from the embryo",
          "To provide oxygen and nutrients to the embryo"
        ],
        "correct": "To provide oxygen and nutrients to the embryo"
      },
      {
        "id": 36,
        "question": "In which group of animals does parental care of offspring typically include both parents?",
        "options": [
          "Birds",
          "Amphibians",
          "Reptiles",
          "Insects"
        ],
        "correct": "Birds"
      },
      {
        "id": 37,
        "question": "What is the main advantage of sexual reproduction over asexual reproduction?",
        "options": [
          "Sexual reproduction is faster",
          "Sexual reproduction produces genetically diverse offspring",
          "Sexual reproduction requires fewer resources",
          "Sexual reproduction produces identical offspring"
        ],
        "correct": "Sexual reproduction produces genetically diverse offspring"
      },
      {
        "id": 38,
        "question": "Which of the following types of animals does NOT engage in parental care?",
        "options": [
          "Frogs",
          "Turtles",
          "Birds",
          "Mammals"
        ],
        "correct": "Turtles"
      },
      {
        "id": 39,
        "question": "Which of the following is NOT a method of seed dispersal in plants?",
        "options": [
          "Wind",
          "Water",
          "Electricity",
          "Animals"
        ],
        "correct": "Electricity"
      },
      {
        "id": 40,
        "question": "Which of the following organisms undergoes regeneration as a form of asexual reproduction?",
        "options": [
          "Sea star",
          "Human",
          "Cow",
          "Frog"
        ],
        "correct": "Sea star"
      },
      {
        "id": 41,
        "question": "In which type of reproduction are offspring genetically identical to the parent?",
        "options": [
          "Asexual reproduction",
          "Sexual reproduction",
          "Cloning",
          "Fragmentation"
        ],
        "correct": "Asexual reproduction"
      },
      {
        "id": 42,
        "question": "Which of the following plants reproduce through spores?",
        "options": [
          "Mosses",
          "Apple trees",
          "Cucumber plants",
          "Sunflowers"
        ],
        "correct": "Mosses"
      },
      {
        "id": 43,
        "question": "In which stage of sexual reproduction does meiosis occur?",
        "options": [
          "Sperm and egg formation",
          "Fertilization",
          "Zygote development",
          "Embryo development"
        ],
        "correct": "Sperm and egg formation"
      },
      {
        "id": 44,
        "question": "What is the process by which the male and female gametes combine to form a zygote?",
        "options": [
          "Fertilization",
          "Pollination",
          "Budding",
          "Metamorphosis"
        ],
        "correct": "Fertilization"
      },
      {
        "id": 45,
        "question": "In plants, what structure holds the pollen and is crucial for pollination?",
        "options": [
          "Stigma",
          "Anther",
          "Ovary",
          "Sepal"
        ],
        "correct": "Anther"
      },
      {
        "id": 46,
        "question": "Which of the following animals exhibits viviparity, where offspring are born live?",
        "options": [
          "Human",
          "Bird",
          "Reptile",
          "Fish"
        ],
        "correct": "Human"
      },
      {
        "id": 47,
        "question": "What is the term for the process in which an organism grows a new part to replace a lost one?",
        "options": [
          "Regeneration",
          "Fission",
          "Mitosis",
          "Budding"
        ],
        "correct": "Regeneration"
      },
      {
        "id": 48,
        "question": "Which of the following organisms shows external fertilization?",
        "options": [
          "Frogs",
          "Mammals",
          "Reptiles",
          "Birds"
        ],
        "correct": "Frogs"
      },
      {
        "id": 49,
        "question": "What is the term for the structure in plants where fertilization takes place?",
        "options": [
          "Ovary",
          "Anther",
          "Pollen tube",
          "Stigma"
        ],
        "correct": "Ovary"
      },
      {
        "id": 50,
        "question": "Which type of asexual reproduction occurs in yeast cells?",
        "options": [
          "Budding",
          "Fission",
          "Fragmentation",
          "Cloning"
        ],
        "correct": "Budding"
      },
      {
        "id": 51,
        "question": "In humans, how many chromosomes are typically found in each gamete (egg or sperm)?",
        "options": [
          "46",
          "23",
          "92",
          "48"
        ],
        "correct": "23"
      },
      {
        "id": 52,
        "question": "Which of the following structures in the human female reproductive system holds the developing embryo?",
        "options": [
          "Ovary",
          "Uterus",
          "Fallopian tube",
          "Vagina"
        ],
        "correct": "Uterus"
      },
      {
        "id": 53,
        "question": "In asexual reproduction, which of the following methods results in the formation of new organisms from fragments of the parent organism?",
        "options": [
          "Budding",
          "Fission",
          "Fragmentation",
          "Cloning"
        ],
        "correct": "Fragmentation"
      },
      {
        "id": 54,
        "question": "What is the primary method of asexual reproduction in hydra?",
        "options": [
          "Budding",
          "Fission",
          "Spore formation",
          "Binary fission"
        ],
        "correct": "Budding"
      },
      {
        "id": 55,
        "question": "Which of the following organisms is an example of an oviparous animal, where offspring are born from eggs?",
        "options": [
          "Chicken",
          "Human",
          "Shark",
          "Horse"
        ],
        "correct": "Chicken"
      },
      {
        "id": 56,
        "question": "Which of the following methods of seed dispersal involves animals carrying seeds to new locations?",
        "options": [
          "Wind dispersal",
          "Water dispersal",
          "Animal dispersal",
          "Explosion"
        ],
        "correct": "Animal dispersal"
      },
      {
        "id": 57,
        "question": "Which of the following is a major advantage of sexual reproduction?",
        "options": [
          "It produces genetically identical offspring",
          "It allows for rapid population growth",
          "It leads to genetic diversity",
          "It does not require a mate"
        ],
        "correct": "It leads to genetic diversity"
      },
      {
        "id": 58,
        "question": "In what way does the process of pollination benefit plants?",
        "options": [
          "It helps in the dispersal of seeds",
          "It enables fertilization",
          "It attracts herbivores",
          "It increases photosynthesis"
        ],
        "correct": "It enables fertilization"
      },
      {
        "id": 59,
        "question": "Which of the following reproductive processes is common in plants that do not produce flowers?",
        "options": [
          "Spore formation",
          "Budding",
          "Fission",
          "Cloning"
        ],
        "correct": "Spore formation"
      },
      {
        "id": 60,
        "question": "What is the process of producing offspring from an unfertilized egg called?",
        "options": [
          "Parthenogenesis",
          "Regeneration",
          "Cloning",
          "Budding"
        ],
        "correct": "Parthenogenesis"
      },
      {
        "id": 61,
        "question": "In a flower, the structure that produces pollen is called:",
        "options": [
          "Stigma",
          "Anther",
          "Ovary",
          "Style"
        ],
        "correct": "Anther"
      },
      {
        "id": 62,
        "question": "In the human female reproductive system, fertilization normally occurs in which of the following structures?",
        "options": [
          "Ovary",
          "Uterus",
          "Cervix",
          "Fallopian tube"
        ],
        "correct": "Fallopian tube"
      },
      {
        "id": 63,
        "question": "What is the term for the process of fusion of male and female gametes to form a zygote?",
        "options": [
          "Fertilization",
          "Pollination",
          "Mitosis",
          "Meiosis"
        ],
        "correct": "Fertilization"
      },
      {
        "id": 64,
        "question": "Which of the following is the first step in sexual reproduction in animals?",
        "options": [
          "Fertilization",
          "Gamete formation",
          "Zygote formation",
          "Cleavage"
        ],
        "correct": "Gamete formation"
      },
      {
        "id": 65,
        "question": "In which type of sexual reproduction does external fertilization occur?",
        "options": [
          "Mammals",
          "Birds",
          "Amphibians",
          "Reptiles"
        ],
        "correct": "Amphibians"
      },
      {
        "id": 66,
        "question": "The male gametes in plants are produced in the:",
        "options": [
          "Anther",
          "Ovary",
          "Pollen tube",
          "Style"
        ],
        "correct": "Anther"
      },
      {
        "id": 67,
        "question": "Which process ensures the genetic variability of offspring in sexual reproduction?",
        "options": [
          "Meiosis",
          "Mitosis",
          "Fission",
          "Budding"
        ],
        "correct": "Meiosis"
      },
      {
        "id": 68,
        "question": "In humans, the process of spermatogenesis occurs in the:",
        "options": [
          "Seminal vesicles",
          "Prostate gland",
          "Testes",
          "Penis"
        ],
        "correct": "Testes"
      },
      {
        "id": 69,
        "question": "Which of the following is a characteristic of external fertilization?",
        "options": [
          "Zygote develops inside the female body",
          "Fertilization occurs inside the female",
          "Large number of gametes are produced",
          "Internal fertilization occurs"
        ],
        "correct": "Large number of gametes are produced"
      },
      {
        "id": 70,
        "question": "Which one of the following methods of asexual reproduction involves the splitting of a parent organism into two or more parts?",
        "options": [
          "Budding",
          "Binary fission",
          "Regeneration",
          "Vegetative propagation"
        ],
        "correct": "Binary fission"
      },
      {
        "id": 71,
        "question": "In flowering plants, the transfer of pollen from one flower to another is called:",
        "options": [
          "Pollination",
          "Fertilization",
          "Germination",
          "Transpiration"
        ],
        "correct": "Pollination"
      },
      {
        "id": 72,
        "question": "The embryo sac in an angiosperm is formed from:",
        "options": [
          "Megaspore",
          "Microspore",
          "Ovary",
          "Anther"
        ],
        "correct": "Megaspore"
      },
      {
        "id": 73,
        "question": "In humans, the haploid number of chromosomes in a gamete is:",
        "options": [
          "23",
          "46",
          "92",
          "48"
        ],
        "correct": "23"
      },
      {
        "id": 74,
        "question": "Which of the following is the primary function of the placenta in humans?",
        "options": [
          "Nutrient and gas exchange",
          "Reproduction",
          "Segregation of chromosomes",
          "Secretion of estrogen"
        ],
        "correct": "Nutrient and gas exchange"
      },
      {
        "id": 75,
        "question": "In a plant, the process of double fertilization results in the formation of:",
        "options": [
          "Embryo and endosperm",
          "Only embryo",
          "Only endosperm",
          "Seed coat and embryo"
        ],
        "correct": "Embryo and endosperm"
      },
      {
        "id": 76,
        "question": "What is the process of asexual reproduction in hydra called?",
        "options": [
          "Budding",
          "Fission",
          "Regeneration",
          "Cloning"
        ],
        "correct": "Budding"
      },
      {
        "id": 77,
        "question": "Which of the following hormones is responsible for the maturation of eggs in females?",
        "options": [
          "Progesterone",
          "Testosterone",
          "Estrogen",
          "Oxytocin"
        ],
        "correct": "Estrogen"
      },
      {
        "id": 78,
        "question": "In which of the following animals does internal fertilization occur?",
        "options": [
          "Frog",
          "Fish",
          "Insect",
          "Mammal"
        ],
        "correct": "Mammal"
      },
      {
        "id": 79,
        "question": "What is the term used for the process by which a plant produces new plants from its vegetative parts?",
        "options": [
          "Fragmentation",
          "Vegetative propagation",
          "Budding",
          "Fission"
        ],
        "correct": "Vegetative propagation"
      },
      {
        "id": 80,
        "question": "The male reproductive organ of a flower is the:",
        "options": [
          "Pistil",
          "Stigma",
          "Stamen",
          "Ovary"
        ],
        "correct": "Stamen"
      },
      {
        "id": 81,
        "question": "Which of the following is true about meiosis?",
        "options": [
          "It results in two identical daughter cells",
          "It produces haploid cells from diploid cells",
          "It occurs only in somatic cells",
          "It is a type of asexual reproduction"
        ],
        "correct": "It produces haploid cells from diploid cells"
      },
      {
        "id": 82,
        "question": "Which of the following is the term for the fusion of male and female gametes?",
        "options": [
          "Pollination",
          "Fertilization",
          "Meiosis",
          "Mitosis"
        ],
        "correct": "Fertilization"
      },
      {
        "id": 83,
        "question": "Which of the following types of organisms can reproduce via regeneration?",
        "options": [
          "Starfish",
          "Human",
          "Bird",
          "Elephant"
        ],
        "correct": "Starfish"
      },
      {
        "id": 84,
        "question": "What is the correct sequence of events in human embryonic development?",
        "options": [
          "Fertilization → Zygote → Morula → Blastula → Embryo",
          "Fertilization → Blastula → Zygote → Morula → Embryo",
          "Zygote → Morula → Blastula → Embryo → Fertilization",
          "Morula → Zygote → Blastula → Embryo → Fertilization"
        ],
        "correct": "Fertilization → Zygote → Morula → Blastula → Embryo"
      },
      {
        "id": 85,
        "question": "The process by which a new plant is produced from the part of the parent plant, such as a leaf or root, is called:",
        "options": [
          "Vegetative propagation",
          "Fission",
          "Binary fission",
          "Spore formation"
        ],
        "correct": "Vegetative propagation"
      },
      {
        "id": 86,
        "question": "Which of the following statements is true for parthenogenesis?",
        "options": [
          "It is a form of sexual reproduction",
          "It results in offspring from an unfertilized egg",
          "It only occurs in mammals",
          "It involves fertilization by a male"
        ],
        "correct": "It results in offspring from an unfertilized egg"
      },
      {
        "id": 87,
        "question": "Which of the following is true about the menstrual cycle?",
        "options": [
          "It is controlled by the hormone insulin",
          "Ovulation occurs on the 14th day of the cycle",
          "It occurs only during pregnancy",
          "It is controlled by testosterone"
        ],
        "correct": "Ovulation occurs on the 14th day of the cycle"
      },
      {
        "id": 88,
        "question": "In humans, which part of the male reproductive system produces seminal fluid?",
        "options": [
          "Testes",
          "Seminal vesicles",
          "Epididymis",
          "Prostate gland"
        ],
        "correct": "Seminal vesicles"
      },
      {
        "id": 89,
        "question": "The fusion of two haploid gametes results in the formation of:",
        "options": [
          "Zygote",
          "Gamete",
          "Chiasma",
          "Fertility"
        ],
        "correct": "Zygote"
      },
      {
        "id": 90,
        "question": "Which of the following is asexual reproduction in plants?",
        "options": [
          "Fragmentation",
          "Pollination",
          "Grafting",
          "Fertilization"
        ],
        "correct": "Fragmentation"
      }
  ]
  