import React, { useState } from "react"; 
import { motion } from "framer-motion";
import { FaBrain } from "react-icons/fa";  // Use an icon related to brain or control
import { Gi3dMeeple } from 'react-icons/gi';  // Another valid icon related to neurons
import ControlandcoordinationQuiz from './ControlandcoordinationQuiz';

const ControlAndCoordination = () => {
  const [triggerAnimation, setTriggerAnimation] = useState(false);

  const handleReload = () => {
    // Toggle the animation state to trigger re-render and restart animations
    setTriggerAnimation(!triggerAnimation);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        Control and Coordination
      </h1>

      {/* Reload Button */}
      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <button
          onClick={handleReload}
          style={{
            padding: "10px 20px",
            fontSize: "16px",
            cursor: "pointer",
            borderRadius: "5px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
          }}
        >
          Reload Animations
        </button>
      </div>

      {/* Step 1: Nervous System */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1 }}
        style={{ textAlign: "center" }}
      >
        <h3>Step 1: Nervous System</h3>
        <p>
          The nervous system controls and coordinates the body’s response to internal and external stimuli.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaBrain size={50} color="blue" />
        </motion.div>
      </motion.div>

      {/* Step 2: Endocrine System */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 1 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 2: Endocrine System</h3>
        <p>
          The endocrine system releases hormones that help regulate processes such as growth, metabolism, and mood.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <Gi3dMeeple size={50} color="green" />
        </motion.div>
      </motion.div>

      {/* Step 3: Reflex Actions */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 2 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 3: Reflex Actions</h3>
        <p>
          Reflex actions are automatic and rapid responses to stimuli that do not involve the brain.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaBrain size={50} color="purple" />
        </motion.div>
      </motion.div>

      {/* Step 4: Coordination between Nervous and Endocrine Systems */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, y: triggerAnimation ? 0 : 50 }}
        transition={{ duration: 1, delay: 3 }}
        style={{
          textAlign: "center",
          marginTop: "40px",
          padding: "20px",
          border: "1px solid #ccc",
          borderRadius: "10px",
        }}
      >
        <h3>Step 4: Coordination between Nervous and Endocrine Systems</h3>
        <p>
          Both the nervous and endocrine systems work together to maintain homeostasis and regulate bodily functions.
        </p>
      </motion.div>
      
      <ControlandcoordinationQuiz />
    </div>
  );
};

export default ControlAndCoordination;
