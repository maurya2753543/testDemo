export const quizQuestions = [
    {
        id: 1,
        question: "Which is the first step in crop production?",
        options: [
            "Sowing",
            "Soil preparation",
            "Irrigation",
            "Harvesting"
        ],
        correct: "Soil preparation"
    },
    {
        id: 2,
        question: "What is the process of loosening and turning the soil called?",
        options: [
            "Harvesting",
            "Ploughing",
            "Threshing",
            "Weeding"
        ],
        correct: "Ploughing"
    },
    {
        id: 3,
        question: "Which of the following is used to replenish soil nutrients?",
        options: [
            "Fertilizers",
            "Pesticides",
            "Herbicides",
            "Insecticides"
        ],
        correct: "Fertilizers"
    },
    {
        id: 4,
        question: "What is the main purpose of irrigation in crop production?",
        options: [
            "To prevent soil erosion",
            "To supply water to crops",
            "To increase soil fertility",
            "To remove weeds"
        ],
        correct: "To supply water to crops"
    },
    {
        id: 5,
        question: "Which crop is an example of a Rabi crop?",
        options: [
            "Wheat",
            "Rice",
            "Maize",
            "Cotton"
        ],
        correct: "Wheat"
    },
    {
        id: 6,
        question: "Which of these is a traditional method of irrigation?",
        options: [
            "Drip irrigation",
            "Sprinkler irrigation",
            "Chain pump",
            "Perforated pipe system"
        ],
        correct: "Chain pump"
    },
    {
        id: 7,
        question: "What is the removal of weeds from a crop field known as?",
        options: [
            "Threshing",
            "Weeding",
            "Harvesting",
            "Ploughing"
        ],
        correct: "Weeding"
    },
    {
        id: 8,
        question: "Which type of crop requires less water for growth?",
        options: [
            "Paddy",
            "Wheat",
            "Rice",
            "Sugarcane"
        ],
        correct: "Wheat"
    },
    {
        id: 9,
        question: "What is the process of separating grains from chaff called?",
        options: [
            "Threshing",
            "Winnowing",
            "Harvesting",
            "Sowing"
        ],
        correct: "Threshing"
    },
    {
        id: 10,
        question: "Which tool is commonly used for sowing seeds?",
        options: [
            "Plough",
            "Seed drill",
            "Cultivator",
            "Harvester"
        ],
        correct: "Seed drill"
    },
    {
        id: 11,
        question: "Which microorganism is used in the production of biofertilizers?",
        options: [
            "Algae",
            "Bacteria",
            "Fungi",
            "Protozoa"
        ],
        correct: "Bacteria"
    },
    {
        id: 12,
        question: "Which farming method involves growing different crops in alternate seasons?",
        options: [
            "Mixed farming",
            "Crop rotation",
            "Organic farming",
            "Subsistence farming"
        ],
        correct: "Crop rotation"
    },
    {
        id: 13,
        question: "What is a major disadvantage of excessive use of chemical fertilizers?",
        options: [
            "Increase in soil fertility",
            "Soil and water pollution",
            "Faster growth of crops",
            "Improved pest resistance"
        ],
        correct: "Soil and water pollution"
    },
    {
        id: 14,
        question: "Which type of irrigation system is best for conserving water?",
        options: [
            "Canal irrigation",
            "Drip irrigation",
            "Flood irrigation",
            "Sprinkler irrigation"
        ],
        correct: "Drip irrigation"
    },
    {
        id: 15,
        question: "What is the scientific name for the green pigment in plants responsible for photosynthesis?",
        options: [
            "Carotene",
            "Xanthophyll",
            "Chlorophyll",
            "Anthocyanin"
        ],
        correct: "Chlorophyll"
    },
    {
        id: 16,
        question: "Which nutrient is essential for plant growth and is absorbed from the soil?",
        options: [
            "Oxygen",
            "Nitrogen",
            "Carbon dioxide",
            "Hydrogen"
        ],
        correct: "Nitrogen"
    },
    {
        id: 17,
        question: "Which equipment is used to level the soil after ploughing?",
        options: [
            "Harrow",
            "Seed drill",
            "Cultivator",
            "Sickle"
        ],
        correct: "Harrow"
    },
    {
        id: 18,
        question: "Which term refers to the technique of growing crops without soil?",
        options: [
            "Hydroponics",
            "Aquaculture",
            "Aeroponics",
            "Horticulture"
        ],
        correct: "Hydroponics"
    },
    {
        id: 19,
        question: "Which is the main purpose of crop rotation?",
        options: [
            "To reduce water usage",
            "To avoid soil exhaustion",
            "To improve pest control",
            "To increase yield in one season"
        ],
        correct: "To avoid soil exhaustion"
    },
    {
        id: 20,
        question: "What is the process of applying water to crops through artificial means called?",
        options: [
            "Irrigation",
            "Harvesting",
            "Cultivation",
            "Weeding"
        ],
        correct: "Irrigation"
    },
    {
        id: 21,
        question: "Which crop is typically grown during the Kharif season?",
        options: [
            "Wheat",
            "Rice",
            "Barley",
            "Mustard"
        ],
        correct: "Rice"
    },
    {
        id: 22,
        question: "What is the primary purpose of using pesticides in agriculture?",
        options: [
            "To increase soil fertility",
            "To kill harmful pests",
            "To improve seed quality",
            "To enhance water absorption"
        ],
        correct: "To kill harmful pests"
    },
    {
        id: 23,
        question: "Which method is used to protect crops from being eaten by birds and animals?",
        options: [
            "Weeding",
            "Fencing",
            "Crop rotation",
            "Irrigation"
        ],
        correct: "Fencing"
    },
    {
        id: 24,
        question: "Which nutrient is primarily responsible for plant root development?",
        options: [
            "Phosphorus",
            "Nitrogen",
            "Potassium",
            "Calcium"
        ],
        correct: "Phosphorus"
    },
    {
        id: 25,
        question: "What is the process of separating seeds from the husks called?",
        options: [
            "Winnowing",
            "Threshing",
            "Ploughing",
            "Sowing"
        ],
        correct: "Winnowing"
    },
    {
        id: 26,
        question: "Which microorganism helps in nitrogen fixation in soil?",
        options: [
            "Rhizobium",
            "E. coli",
            "Aspergillus",
            "Lactobacillus"
        ],
        correct: "Rhizobium"
    },
    {
        id: 27,
        question: "Which of these tools is traditionally used for ploughing fields?",
        options: [
            "Spade",
            "Plough",
            "Tiller",
            "Sickle"
        ],
        correct: "Plough"
    },
    {
        id: 28,
        question: "What is the method of planting seeds directly into the soil called?",
        options: [
            "Transplantation",
            "Direct sowing",
            "Broadcasting",
            "Seed drilling"
        ],
        correct: "Direct sowing"
    },
    {
        id: 29,
        question: "Which type of irrigation system uses pipes with small holes to deliver water directly to plant roots?",
        options: [
            "Sprinkler irrigation",
            "Drip irrigation",
            "Canal irrigation",
            "Flood irrigation"
        ],
        correct: "Drip irrigation"
    },
    {
        id: 30,
        question: "Which crop is known as a cash crop?",
        options: [
            "Sugarcane",
            "Wheat",
            "Paddy",
            "Maize"
        ],
        correct: "Sugarcane"
    },
    {
        id: 31,
        question: "What is the process of harvesting crops using machinery called?",
        options: [
            "Manual harvesting",
            "Mechanized harvesting",
            "Threshing",
            "Winnowing"
        ],
        correct: "Mechanized harvesting"
    },
    {
        id: 32,
        question: "Which of the following is an organic fertilizer?",
        options: [
            "Compost",
            "Urea",
            "Ammonium nitrate",
            "Potash"
        ],
        correct: "Compost"
    },
    {
        id: 33,
        question: "What is the purpose of crop insurance for farmers?",
        options: [
            "To increase crop yield",
            "To cover losses from crop failure",
            "To provide subsidies for seeds",
            "To promote irrigation techniques"
        ],
        correct: "To cover losses from crop failure"
    },
    {
        id: 34,
        question: "Which type of soil is best for growing cotton?",
        options: [
            "Black soil",
            "Sandy soil",
            "Clay soil",
            "Alluvial soil"
        ],
        correct: "Black soil"
    },
    {
        id: 35,
        question: "What is the name of the farming method where two or more crops are grown together in the same field?",
        options: [
            "Mixed cropping",
            "Crop rotation",
            "Monoculture",
            "Organic farming"
        ],
        correct: "Mixed cropping"
    },
    {
        id: 36,
        question: "Which of the following is an example of a horticultural crop?",
        options: [
            "Wheat",
            "Tomato",
            "Maize",
            "Rice"
        ],
        correct: "Tomato"
    },
    {
        id: 37,
        question: "Which stage in crop production involves the removal of excess water?",
        options: [
            "Irrigation",
            "Drainage",
            "Ploughing",
            "Sowing"
        ],
        correct: "Drainage"
    },
    {
        id: 38,
        question: "Which chemical element is essential for photosynthesis?",
        options: [
            "Nitrogen",
            "Carbon dioxide",
            "Oxygen",
            "Hydrogen"
        ],
        correct: "Carbon dioxide"
    },
    {
        id: 39,
        question: "Which disease affects rice crops and is caused by a fungus?",
        options: [
            "Blight",
            "Rust",
            "Powdery mildew",
            "Bacterial wilt"
        ],
        correct: "Blight"
    },
    {
        id: 40,
        question: "Which machinery is used for planting seeds uniformly in a field?",
        options: [
            "Harvester",
            "Seed drill",
            "Plough",
            "Cultivator"
        ],
        correct: "Seed drill"
    },
    {
        id: 41,
        question: "What is the process of turning soil to prepare it for sowing called?",
        options: [
            "Ploughing",
            "Harvesting",
            "Winnowing",
            "Manuring"
        ],
        correct: "Ploughing"
    },
    {
        id: 42,
        question: "Which type of farming involves growing only one type of crop over a large area?",
        options: [
            "Crop rotation",
            "Mixed farming",
            "Monoculture",
            "Organic farming"
        ],
        correct: "Monoculture"
    },
    {
        id: 43,
        question: "Which irrigation technique is best suited for arid and semi-arid regions?",
        options: [
            "Flood irrigation",
            "Canal irrigation",
            "Drip irrigation",
            "Sprinkler irrigation"
        ],
        correct: "Drip irrigation"
    },
    {
        id: 44,
        question: "Which crop requires standing water during most of its growth phase?",
        options: [
            "Maize",
            "Rice",
            "Wheat",
            "Millet"
        ],
        correct: "Rice"
    },
    {
        id: 45,
        question: "What is crop rotation primarily used for?",
        options: [
            "To conserve soil nutrients",
            "To increase water retention",
            "To improve irrigation efficiency",
            "To maximize pesticide use"
        ],
        correct: "To conserve soil nutrients"
    },
    {
        id: 46,
        question: "Which practice involves growing leguminous crops to improve soil fertility?",
        options: [
            "Mixed cropping",
            "Crop rotation",
            "Mulching",
            "Weeding"
        ],
        correct: "Crop rotation"
    },
    {
        id: 47,
        question: "What is the scientific name of the Green Revolution pioneer crop in India?",
        options: [
            "Oryza sativa (Rice)",
            "Triticum aestivum (Wheat)",
            "Zea mays (Maize)",
            "Gossypium hirsutum (Cotton)"
        ],
        correct: "Triticum aestivum (Wheat)"
    },
    {
        id: 48,
        question: "Which method helps to control weeds without chemicals?",
        options: [
            "Mulching",
            "Spraying herbicides",
            "Manuring",
            "Over-irrigation"
        ],
        correct: "Mulching"
    },
    {
        id: 49,
        question: "What is the main benefit of using vermicompost in agriculture?",
        options: [
            "It increases water retention in soil",
            "It adds organic nutrients to soil",
            "It eliminates all pests",
            "It boosts seed germination rate"
        ],
        correct: "It adds organic nutrients to soil"
    },
    {
        id: 50,
        question: "Which of the following crops is grown mainly for making oil?",
        options: [
            "Mustard",
            "Wheat",
            "Potato",
            "Sugarcane"
        ],
        correct: "Mustard"
    },
    {
        id: 51,
        question: "Which nutrient deficiency leads to stunted growth in plants?",
        options: [
            "Nitrogen",
            "Phosphorus",
            "Potassium",
            "Calcium"
        ],
        correct: "Nitrogen"
    },
    {
        id: 52,
        question: "Which of the following is NOT a Rabi crop?",
        options: [
            "Wheat",
            "Gram",
            "Pea",
            "Paddy"
        ],
        correct: "Paddy"
    },
    {
        id: 53,
        question: "What is the main purpose of manuring in crop production?",
        options: [
            "To kill weeds",
            "To provide nutrients to the soil",
            "To improve water absorption",
            "To prevent pests"
        ],
        correct: "To provide nutrients to the soil"
    },
    {
        id: 54,
        question: "Which instrument is used to measure rainfall in agricultural studies?",
        options: [
            "Barometer",
            "Anemometer",
            "Rain gauge",
            "Thermometer"
        ],
        correct: "Rain gauge"
    },
    {
        id: 55,
        question: "Which type of soil is best for cultivating wheat?",
        options: [
            "Loamy soil",
            "Black soil",
            "Sandy soil",
            "Clay soil"
        ],
        correct: "Loamy soil"
    },
    {
        id: 56,
        question: "Which farming practice conserves water by reducing evaporation?",
        options: [
            "Irrigation",
            "Mulching",
            "Weeding",
            "Ploughing"
        ],
        correct: "Mulching"
    },
    {
        id: 57,
        question: "What is the common term for urea used in agriculture?",
        options: [
            "Pesticide",
            "Fertilizer",
            "Weedicide",
            "Insecticide"
        ],
        correct: "Fertilizer"
    },
    {
        id: 58,
        question: "Which crop requires a cold climate and moderate rainfall to grow?",
        options: [
            "Cotton",
            "Wheat",
            "Maize",
            "Sugarcane"
        ],
        correct: "Wheat"
    },
    {
        id: 59,
        question: "What is the major goal of sustainable agriculture?",
        options: [
            "To maximize crop production using chemicals",
            "To preserve natural resources while ensuring food security",
            "To eliminate pests using synthetic pesticides",
            "To replace all crops with genetically modified varieties"
        ],
        correct: "To preserve natural resources while ensuring food security"
    },
    {
        id: 60,
        question: "Which type of farming avoids the use of synthetic chemicals and pesticides?",
        options: [
            "Subsistence farming",
            "Commercial farming",
            "Organic farming",
            "Intensive farming"
        ],
        correct: "Organic farming"
    },
    {
        id: 61,
        question: "Which of the following is a major advantage of using organic fertilizers?",
        options: [
            "They are cheaper than synthetic fertilizers",
            "They help improve soil structure and fertility over time",
            "They require less labor to apply",
            "They provide instant nutrients to plants"
        ],
        correct: "They help improve soil structure and fertility over time"
    },
    {
        id: 62,
        question: "What is the primary purpose of using green manure in farming?",
        options: [
            "To control pests",
            "To provide organic matter to the soil",
            "To improve water drainage",
            "To speed up seed germination"
        ],
        correct: "To provide organic matter to the soil"
    },
    {
        id: 63,
        question: "Which of the following methods is most effective for preventing soil erosion?",
        options: [
            "Terracing",
            "Deep ploughing",
            "Burning of stubble",
            "Over-irrigation"
        ],
        correct: "Terracing"
    },
    {
        id: 64,
        question: "What is the key difference between Kharif and Rabi crops?",
        options: [
            "Kharif crops are grown in winter, and Rabi crops are grown in summer",
            "Kharif crops are grown in summer, and Rabi crops are grown in winter",
            "Kharif crops are harvested in winter, and Rabi crops are harvested in summer",
            "Kharif crops require less water than Rabi crops"
        ],
        correct: "Kharif crops are grown in summer, and Rabi crops are grown in winter"
    },
    {
        id: 65,
        question: "What is the primary advantage of drip irrigation over flood irrigation?",
        options: [
            "It is cheaper to set up",
            "It reduces water wastage by delivering water directly to the plant roots",
            "It requires less maintenance",
            "It can be used for a wider variety of crops"
        ],
        correct: "It reduces water wastage by delivering water directly to the plant roots"
    },
    {
        id: 66,
        question: "Which of the following is considered a leguminous crop?",
        options: [
            "Wheat",
            "Rice",
            "Peas",
            "Sugarcane"
        ],
        correct: "Peas"
    },
    {
        id: 67,
        question: "What is the function of bio-pesticides in crop management?",
        options: [
            "To provide nutrients to plants",
            "To control pests without harmful chemicals",
            "To increase the water-holding capacity of soil",
            "To enhance seed germination rates"
        ],
        correct: "To control pests without harmful chemicals"
    },
    {
        id: 68,
        question: "Which of the following is the best practice for reducing weed growth in a field?",
        options: [
            "Frequent tilling",
            "Mulching",
            "Over-watering",
            "Excessive use of chemical fertilizers"
        ],
        correct: "Mulching"
    },
    {
        id: 69,
        question: "Which of the following crops is typically grown during the Rabi season in India?",
        options: [
            "Rice",
            "Maize",
            "Cotton",
            "Barley"
        ],
        correct: "Barley"
    },
    {
        id: 70,
        question: "What is the primary function of nitrogen in crop production?",
        options: [
            "To promote root growth",
            "To assist in photosynthesis",
            "To help form proteins and chlorophyll",
            "To improve the taste of the fruit"
        ],
        correct: "To help form proteins and chlorophyll"
    },
    {
        id: 71,
        question: "Which of the following is an example of intercropping?",
        options: [
            "Growing corn and wheat in separate fields",
            "Growing maize with beans in the same field",
            "Using crop rotation",
            "Planting only one crop in a large field"
        ],
        correct: "Growing maize with beans in the same field"
    },
    {
        id: 72,
        question: "Which type of crop requires a high level of irrigation and is typically grown in tropical regions?",
        options: [
            "Cotton",
            "Wheat",
            "Rice",
            "Barley"
        ],
        correct: "Rice"
    },
    {
        id: 73,
        question: "What is the main purpose of crop rotation?",
        options: [
            "To increase pest resistance",
            "To balance the soil’s nutrient levels and prevent soil depletion",
            "To decrease water usage",
            "To control weeds effectively"
        ],
        correct: "To balance the soil’s nutrient levels and prevent soil depletion"
    },
    {
        id: 74,
        question: "What is the ideal temperature range for wheat cultivation?",
        options: [
            "10°C to 15°C",
            "15°C to 20°C",
            "25°C to 30°C",
            "30°C to 35°C"
        ],
        correct: "15°C to 20°C"
    },
    {
        id: 75,
        question: "Which of the following is the best method to prevent pest damage in organic farming?",
        options: [
            "Using synthetic pesticides",
            "Using chemical insecticides",
            "Using natural predators like ladybugs",
            "Monoculture farming"
        ],
        correct: "Using natural predators like ladybugs"
    },
    {
        id: 76,
        question: "What is the primary function of phosphorus in crop growth?",
        options: [
            "To encourage flowering and fruiting",
            "To promote leaf growth",
            "To improve water absorption",
            "To prevent diseases"
        ],
        correct: "To encourage flowering and fruiting"
    },
    {
        id: 77,
        question: "What type of soil is ideal for growing sugarcane?",
        options: [
            "Black soil",
            "Sandy soil",
            "Clay soil",
            "Loamy soil"
        ],
        correct: "Black soil"
    },
    {
        id: 78,
        question: "Which method of planting is most commonly used for crops like paddy (rice)?",
        options: [
            "Broadcasting",
            "Drilling",
            "Transplanting",
            "Direct sowing"
        ],
        correct: "Transplanting"
    },
    {
        id: 79,
        question: "Which type of farming involves growing both crops and livestock?",
        options: [
            "Intensive farming",
            "Mixed farming",
            "Monoculture",
            "Hydroponics"
        ],
        correct: "Mixed farming"
    },
    {
        id: 80,
        question: "Which nutrient is primarily responsible for promoting healthy root development in plants?",
        options: [
            "Nitrogen",
            "Phosphorus",
            "Potassium",
            "Sulfur"
        ],
        correct: "Phosphorus"
    }
];
