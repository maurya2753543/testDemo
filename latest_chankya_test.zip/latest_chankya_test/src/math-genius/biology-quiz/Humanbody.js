import React from "react";
import "./Humanbody.css";
import men from "../../images/humanfun.jpg";
import women from "../../images/femalebody.jpg";
import HumanbodyQuiz from "./HumanbodyQuiz"

const ImageView = () => {
  const imagePath = "images/humanfun.jpg"; // Update the path based on your project structure

  return (
    <>
     <div className="image-viewer-container">
      <h2>Image Mele Viewer</h2>
      <div className="image-wrapper">
        <img src={men} alt="Human Fun" className="responsive-image" />
      </div>
    </div>
    <div className="image-viewer-container">
      <h2>Image Female Viewer</h2>
      <div className="image-wrapper">
        <img src={women} alt="Human Fun" className="responsive-image" />
      </div>
    </div>

    <HumanbodyQuiz />
    </>
   
    
  );
};

export default ImageView;
