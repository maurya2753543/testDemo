import React, { useState, useEffect } from "react";
import { quizQuestions } from "./OurenvironmentJson";
import "../../math-genius/chemistry-quiz/LitmusQuiz.css";

const LitmusQuiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState("");
  const [isCorrect, setIsCorrect] = useState(null);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds
  const [quizCompleted, setQuizCompleted] = useState(false);

  // Format timeLeft into MM:SS
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
  };

  useEffect(() => {
    if (quizCompleted) return; // Prevent the timer if the quiz is completed

    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, [quizCompleted]);

  const handleOptionChange = (option) => {
    setSelectedOption(option);
    setIsCorrect(null); // Reset feedback
  };

  const checkAnswer = () => {
    const isAnswerCorrect =
      selectedOption === quizQuestions[currentQuestion].correct;
    if (isAnswerCorrect) {
      setCorrectAnswers((prev) => prev + 1);
    }
    setIsCorrect(isAnswerCorrect);
  };

  const nextQuestion = () => {
    if (currentQuestion === quizQuestions.length - 1) {
      setQuizCompleted(true);
    } else {
      setSelectedOption("");
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    }
  };

  const progressPercentage = (timeLeft / 600) * 100;

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedOption("");
    setIsCorrect(null);
    setCorrectAnswers(0);
    setTimeLeft(600); // Reset the time to 10 minutes
    setQuizCompleted(false);
  };

  const renderResult = () => {
    return (
      <div className="result">
        <h2>Quiz Completed</h2>
        <p>
          You answered {correctAnswers} out of {quizQuestions.length} questions correctly.
        </p>
        <p>
          You got {quizQuestions.length - correctAnswers} not Attempt and questions wrong.
        </p>
        <button onClick={restartQuiz} className="retry-button">
          Try Again
        </button>
      </div>
    );
  };

  if (quizCompleted || timeLeft === 0) {
    return renderResult();
  }

  return (
    <div className="quiz-container-litum">
      <h1>Mastering  A Quiz</h1>
      {/* Timer Section */}
      <div className="timer-section">
        <p className="timer-text">
          <strong>Time Remaining: {formatTime(timeLeft)}</strong>
        </p>
        <div
          className="progress-bar"
          style={{
            width: `${progressPercentage}%`,
            backgroundColor: timeLeft < 120 ? "red" : "#4caf50", // Turns red in the last 2 minutes
            height: "10px",
            borderRadius: "5px",
          }}
        ></div>
      </div>
      {/* Question Section */}
      <div className="question-section">
        <h2>
          Question {currentQuestion + 1}/{quizQuestions.length}:{" "}
          {quizQuestions[currentQuestion].question}
        </h2>
        <div className="options">
          {quizQuestions[currentQuestion].options.map((option, index) => (
            <label key={index} className="option">
              <input
                style={{ width: "10px" }}
                type="radio"
                name="option"
                value={option}
                checked={selectedOption === option}
                onChange={() => handleOptionChange(option)}
              />
              {option}
            </label>
          ))}
        </div>
      </div>
      {/* Feedback Section */}
      <div className="feedback">
        {isCorrect === true && <p className="correct">Correct! 🎉</p>}
        {isCorrect === false && <p className="incorrect">Wrong answer. Try again!</p>}
      </div>
      {/* Action Buttons */}
      <div className="action-buttons">
        {isCorrect === true ? (
          <button onClick={nextQuestion} className="next-button">
            Next
          </button>
        ) : (
          <button
            onClick={checkAnswer}
            className="check-button"
            disabled={!selectedOption}
          >
            {isCorrect === false ? "Try Again" : "Check Answer"}
          </button>
        )}
      </div>
    </div>
  );
};

export default LitmusQuiz;
