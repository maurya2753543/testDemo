import React, { useState } from "react"; 
import { motion } from "framer-motion"; 
import { FaSeedling, FaTree } from "react-icons/fa"; 
import FloweringPlantsManagementQuiz from './FloweringPlantsManagementQuiz'; // Quiz component placeholder

const FloweringPlantsManagement = () => {
  // State to trigger re-render
  const [key, setKey] = useState(0);

  // Function to reload animations
  const reloadAnimations = () => {
    setKey((prevKey) => prevKey + 1); // Increment key to force re-render
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        Flowering Plants and Their Growth Cycle
      </h1>
      <button
        onClick={reloadAnimations}
        style={{
          display: "block",
          margin: "0 auto 20px",
          padding: "10px 20px",
          fontSize: "16px",
          backgroundColor: "#007bff",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Reload Animations
      </button>

      {/* Wrapping all animations in a keyed container */}
      <div key={key}>
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          style={{ textAlign: "center" }}
        >
          <p>
            Flowering plants go through several stages from seedling to full bloom, contributing to ecosystems and agriculture.
          </p>
        </motion.div>

        {/* Step 1: Seed Germination */}
        <motion.div
          initial={{ opacity: 0, x: -100 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 1 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "30px",
          }}
        >
          <FaSeedling size={50} color="green" style={{ marginRight: "20px" }} />
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1 }}
          >
            <p style={{ margin: 0 }}>Seed Germination and Growth</p>
          </motion.div>
        </motion.div>

        {/* Step 2: Flower Bud Formation */}
        <motion.div
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 1.5 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "30px",
          }}
        >
          <FaSeedling size={50} color="pink" style={{ marginRight: "20px" }} />
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1 }}
          >
            <p style={{ margin: 0 }}>Flower Buds Begin to Form</p>
          </motion.div>
        </motion.div>

        {/* Step 3: Pollination */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 2 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "40px",
          }}
        >
          <FaTree size={60} color="forestgreen" style={{ marginRight: "20px" }} />
          <motion.div>
            <p style={{ margin: 0, textAlign: "center" }}>
              Pollination Brings New Life to the Flowers
            </p>
          </motion.div>
        </motion.div>

        {/* Step 4: Flower Bloom */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3 }}
          style={{
            textAlign: "center",
            marginTop: "40px",
            padding: "20px",
            border: "1px solid #ccc",
            borderRadius: "10px",
          }}
        >
          <h3>Flower Bloom and Growth</h3>
          <p>
            As the flower blooms, it contributes to pollination, supporting biodiversity and natural growth.
          </p>
        </motion.div>
      </div>
      <FloweringPlantsManagementQuiz />
    </div>
  );
};

export default FloweringPlantsManagement;
