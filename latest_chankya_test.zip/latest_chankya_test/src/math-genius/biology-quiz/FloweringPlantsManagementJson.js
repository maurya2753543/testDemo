export const quizQuestions = [
    {
        "question": "What is the first stage in the life cycle of flowering plants?",
        "options": [
          "Flower Bloom",
          "Seed Germination",
          "Pollination",
          "Flower Bud Formation"
        ],
        "answer": "Seed Germination"
      },
      {
        "question": "Which of the following is responsible for transferring pollen between flowers?",
        "options": [
          "Root System",
          "Wind",
          "Pollinators",
          "Sunlight"
        ],
        "answer": "Pollinators"
      },
      {
        "question": "What is formed after successful pollination in flowering plants?",
        "options": [
          "Fruit",
          "Flower Buds",
          "Seeds",
          "Flowers"
        ],
        "answer": "Fruit"
      },
      {
        "question": "Which part of the plant supports the flower during its bloom?",
        "options": [
          "Roots",
          "Stem",
          "Leaves",
          "Branches"
        ],
        "answer": "Stem"
      },
      {
        "question": "What role do flowering plants play in the ecosystem?",
        "options": [
          "Support animal life",
          "Contribute to food chains",
          "Provide oxygen through photosynthesis",
          "All of the above"
        ],
        "answer": "All of the above"
      },
      {
        "question": "What triggers the flower blooming process in most plants?",
        "options": [
          "Temperature",
          "Watering",
          "Pollination",
          "Soil Quality"
        ],
        "answer": "Temperature"
      },
      {
        "question": "Which of the following is a necessary condition for seed germination?",
        "options": [
          "Darkness",
          "High temperatures",
          "Water",
          "Cold weather"
        ],
        "answer": "Water"
      },
      {
        "question": "In which part of the plant does photosynthesis occur, helping it grow and develop flowers?",
        "options": [
          "Roots",
          "Leaves",
          "Stem",
          "Flowers"
        ],
        "answer": "Leaves"
      },
      {
        "question": "Which of the following factors is most important for the success of pollination?",
        "options": [
          "Moisture",
          "Wind",
          "Temperature",
          "Attraction to the flowers"
        ],
        "answer": "Attraction to the flowers"
      },
      {
        "question": "What happens after a flower blooms in a flowering plant?",
        "options": [
          "The plant dies",
          "It starts producing seeds",
          "It begins to grow new roots",
          "The stem shrivels up"
        ],
        "answer": "It starts producing seeds"
      },
      {
        "question": "What is the process by which flowers reproduce in flowering plants?",
        "options": [
          "Germination",
          "Pollination",
          "Fertilization",
          "Seedling"
        ],
        "answer": "Pollination"
      },
      {
        "question": "Which part of the flower attracts pollinators?",
        "options": [
          "Petals",
          "Sepals",
          "Stigma",
          "Anthers"
        ],
        "answer": "Petals"
      },
      {
        "question": "What is the male reproductive part of a flower called?",
        "options": [
          "Stigma",
          "Pistil",
          "Stamen",
          "Ovary"
        ],
        "answer": "Stamen"
      },
      {
        "question": "Which part of the flower becomes the fruit?",
        "options": [
          "Stamen",
          "Ovary",
          "Pistil",
          "Anther"
        ],
        "answer": "Ovary"
      },
      {
        "question": "What is the role of the pollen in the fertilization process of flowering plants?",
        "options": [
          "To create seeds",
          "To nourish the plant",
          "To transfer male genetic material to the female part",
          "To protect the seeds"
        ],
        "answer": "To transfer male genetic material to the female part"
      },
      {
        "question": "Which of the following is NOT a type of pollination in flowering plants?",
        "options": [
          "Self-pollination",
          "Cross-pollination",
          "Wind-pollination",
          "Root-pollination"
        ],
        "answer": "Root-pollination"
      },
      {
        "question": "Which of these factors helps flowers to attract pollinators?",
        "options": [
          "Bright colors",
          "Sweet scent",
          "Nectar",
          "All of the above"
        ],
        "answer": "All of the above"
      },
      {
        "question": "Which of the following flowering plants are commonly pollinated by bees?",
        "options": [
          "Cacti",
          "Roses",
          "Daisies",
          "Sunflowers"
        ],
        "answer": "Sunflowers"
      },
      {
        "question": "What is the role of the anther in a flower?",
        "options": [
          "To produce pollen",
          "To produce nectar",
          "To attract pollinators",
          "To protect the ovary"
        ],
        "answer": "To produce pollen"
      },
      {
        "question": "Which plant structure protects the developing seeds in flowering plants?",
        "options": [
          "Ovary",
          "Seed coat",
          "Stem",
          "Fruit"
        ],
        "answer": "Seed coat"
      },
      {
        "question": "What is the main function of the flower's petals?",
        "options": [
          "To produce pollen",
          "To attract pollinators",
          "To protect the seeds",
          "To support the stem"
        ],
        "answer": "To attract pollinators"
      },
      {
        "question": "What part of the flower develops into the fruit?",
        "options": [
          "Ovary",
          "Style",
          "Stigma",
          "Anther"
        ],
        "answer": "Ovary"
      },
      {
        "question": "Which part of the plant is responsible for photosynthesis?",
        "options": [
          "Root",
          "Stem",
          "Leaf",
          "Flower"
        ],
        "answer": "Leaf"
      },
      {
        "question": "What is pollination?",
        "options": [
          "The process of seed formation",
          "The transfer of pollen from one flower to another",
          "The growth of roots from seeds",
          "The absorption of water by the plant"
        ],
        "answer": "The transfer of pollen from one flower to another"
      },
      {
        "question": "Which of the following is a characteristic of a perfect flower?",
        "options": [
          "It contains both male and female reproductive organs",
          "It only contains female reproductive organs",
          "It only contains male reproductive organs",
          "It lacks petals"
        ],
        "answer": "It contains both male and female reproductive organs"
      },
      {
        "question": "What is the male reproductive organ of a flower called?",
        "options": [
          "Stigma",
          "Anther",
          "Style",
          "Pistil"
        ],
        "answer": "Anther"
      },
      {
        "question": "What is the function of the stigma in a flower?",
        "options": [
          "To produce pollen",
          "To catch and hold pollen",
          "To protect the ovules",
          "To support the flower structure"
        ],
        "answer": "To catch and hold pollen"
      },
      {
        "question": "Which process leads to the formation of seeds in flowering plants?",
        "options": [
          "Photosynthesis",
          "Fertilization",
          "Germination",
          "Respiration"
        ],
        "answer": "Fertilization"
      },
      {
        "question": "What part of the plant carries water and nutrients from the roots to the leaves?",
        "options": [
          "Xylem",
          "Phloem",
          "Cortex",
          "Cuticle"
        ],
        "answer": "Xylem"
      },
      {
        "question": "What is the function of the seed coat?",
        "options": [
          "To provide nutrients to the seed",
          "To protect the seed from damage and drying out",
          "To help the seed absorb water",
          "To store food for the seed"
        ],
        "answer": "To protect the seed from damage and drying out"
      },
      {
        "question": "What is the primary function of chloroplasts in the leaves of a plant?",
        "options": [
          "To absorb sunlight for photosynthesis",
          "To transport water and minerals",
          "To store food",
          "To produce pollen"
        ],
        "answer": "To absorb sunlight for photosynthesis"
      },
      {
        "question": "Which of the following is the correct sequence of events in the life cycle of a flowering plant?",
        "options": [
          "Pollination → Fertilization → Germination → Seedling",
          "Seedling → Germination → Fertilization → Pollination",
          "Germination → Seedling → Pollination → Fertilization",
          "Pollination → Germination → Fertilization → Seedling"
        ],
        "answer": "Pollination → Fertilization → Germination → Seedling"
      },
      {
        "question": "What is the main role of the phloem in plants?",
        "options": [
          "Transport of water and minerals",
          "Transport of food from leaves to other parts",
          "Transport of oxygen to roots",
          "Support the plant structure"
        ],
        "answer": "Transport of food from leaves to other parts"
      },
      {
        "question": "Which part of the flower becomes the seed after fertilization?",
        "options": [
          "Ovary",
          "Pollen grain",
          "Style",
          "Ovum"
        ],
        "answer": "Ovum"
      },
      {
        "question": "Which of the following is not a characteristic of angiosperms (flowering plants)?",
        "options": [
          "Presence of seeds",
          "Presence of flowers",
          "Presence of vascular tissue",
          "No presence of xylem and phloem"
        ],
        "answer": "No presence of xylem and phloem"
      },
      {
        "question": "What is the process by which a pollen grain fuses with an ovule to form a zygote?",
        "options": [
          "Germination",
          "Fertilization",
          "Pollination",
          "Mitosis"
        ],
        "answer": "Fertilization"
      },
      {
        "question": "Which structure in a flower is responsible for producing male gametes?",
        "options": [
          "Anther",
          "Pistil",
          "Ovary",
          "Stigma"
        ],
        "answer": "Anther"
      },
      {
        "question": "Which of the following is a feature of double fertilization in flowering plants?",
        "options": [
          "One sperm cell fuses with the egg cell to form a zygote, while the other fuses with two polar nuclei to form endosperm",
          "Two sperm cells fuse with the egg cell to form the zygote",
          "The sperm cell divides to form two zygotes",
          "The egg cell divides to form two embryos"
        ],
        "answer": "One sperm cell fuses with the egg cell to form a zygote, while the other fuses with two polar nuclei to form endosperm"
      },
      {
        "question": "Which of the following is a correct function of the root in flowering plants?",
        "options": [
          "To absorb water and minerals",
          "To produce flowers",
          "To produce fruits",
          "To carry out photosynthesis"
        ],
        "answer": "To absorb water and minerals"
      },
      {
        "question": "What is the role of auxins in plant growth?",
        "options": [
          "To promote cell elongation and growth",
          "To promote flower formation",
          "To prevent water loss",
          "To regulate transpiration"
        ],
        "answer": "To promote cell elongation and growth"
      },
      {
        "question": "In which part of the flower does fertilization occur?",
        "options": [
          "Ovary",
          "Anther",
          "Stigma",
          "Style"
        ],
        "answer": "Ovary"
      },
      {
        "question": "Which part of the plant is primarily responsible for absorbing water and minerals from the soil?",
        "options": [
          "Root",
          "Stem",
          "Leaf",
          "Flower"
        ],
        "answer": "Root"
      },
      {
        "question": "Which of the following is a characteristic feature of monocot plants?",
        "options": [
          "Presence of two cotyledons",
          "Parallel-veined leaves",
          "Vascular bundles in a ring",
          "Taproot system"
        ],
        "answer": "Parallel-veined leaves"
      },
      {
        "question": "Which of the following is the male reproductive part of a flower?",
        "options": [
          "Stigma",
          "Anther",
          "Ovary",
          "Pistil"
        ],
        "answer": "Anther"
      },
      {
        "question": "What is the function of the stigma in a flower?",
        "options": [
          "To produce pollen",
          "To attract pollinators",
          "To receive pollen",
          "To produce seeds"
        ],
        "answer": "To receive pollen"
      },
      {
        "question": "Which of the following best describes the process of pollination?",
        "options": [
          "Fusion of male and female gametes",
          "Transfer of pollen from anther to stigma",
          "Absorption of water by roots",
          "Formation of fruits from flowers"
        ],
        "answer": "Transfer of pollen from anther to stigma"
      },
      {
        "question": "In dicot plants, the leaves typically have which type of venation?",
        "options": [
          "Parallel venation",
          "Reticulate venation",
          "Circular venation",
          "Radial venation"
        ],
        "answer": "Reticulate venation"
      },
      {
        "question": "Which hormone is responsible for the formation of fruit in plants?",
        "options": [
          "Auxin",
          "Cytokinin",
          "Gibberellin",
          "Ethylene"
        ],
        "answer": "Auxin"
      },
      {
        "question": "Which part of the flower develops into a fruit after fertilization?",
        "options": [
          "Ovary",
          "Stigma",
          "Anther",
          "Style"
        ],
        "answer": "Ovary"
      },
      {
        "question": "Which of the following is the characteristic feature of a flower's corolla?",
        "options": [
          "It contains the male reproductive organs",
          "It attracts pollinators",
          "It houses the ovules",
          "It produces nectar"
        ],
        "answer": "It attracts pollinators"
      },
      {
        "question": "Which of the following is a method of asexual reproduction in plants?",
        "options": [
          "Grafting",
          "Pollination",
          "Fertilization",
          "Seed dispersal"
        ],
        "answer": "Grafting"
      },
      {
        "question": "Which of the following is responsible for transporting water in a plant?",
        "options": [
          "Phloem",
          "Xylem",
          "Cortex",
          "Epidermis"
        ],
        "answer": "Xylem"
      },
      {
        "question": "Which of the following plants is an example of a dioecious plant?",
        "options": [
          "Cucumber",
          "Papaya",
          "Pea",
          "Mustard"
        ],
        "answer": "Papaya"
      },
      {
        "question": "Which of the following is a feature of the plant group known as angiosperms?",
        "options": [
          "Seeds are exposed",
          "They have flowers and produce seeds within fruits",
          "They lack vascular tissues",
          "Their seeds are not enclosed in any protective covering"
        ],
        "answer": "They have flowers and produce seeds within fruits"
      },
      {
        "question": "What type of venation is found in the leaves of most monocot plants?",
        "options": [
          "Parallel venation",
          "Reticulate venation",
          "Pinnate venation",
          "Circular venation"
        ],
        "answer": "Parallel venation"
      },
      {
        "question": "In flowering plants, which structure contains the female gametes?",
        "options": [
          "Ovary",
          "Anther",
          "Stigma",
          "Style"
        ],
        "answer": "Ovary"
      },
      {
        "question": "Which of the following is not a function of the stem in plants?",
        "options": [
          "Transport water and minerals",
          "Carry out photosynthesis",
          "Store food",
          "Reproduce sexually"
        ],
        "answer": "Reproduce sexually"
      },
      {
        "question": "Which of the following is true about the vascular cambium in plants?",
        "options": [
          "It is responsible for the lateral growth of the plant",
          "It produces xylem and phloem during primary growth",
          "It is located in the roots only",
          "It is responsible for leaf development"
        ],
        "answer": "It is responsible for the lateral growth of the plant"
      },
      {
        "question": "What is the main function of phloem in plants?",
        "options": [
          "Transport water and minerals",
          "Transport food from leaves to other parts of the plant",
          "Transport hormones",
          "Transport oxygen to roots"
        ],
        "answer": "Transport food from leaves to other parts of the plant"
      },
      {
        "question": "What is the correct sequence of events during fertilization in plants?",
        "options": [
          "Pollen grain germinates, pollen tube forms, sperm nuclei fuse with egg cell",
          "Sperm nuclei fuse with egg cell, pollen tube forms, pollen grain germinates",
          "Egg cell is produced, pollen grain germinates, sperm nuclei fuse with egg cell",
          "Pollen tube forms, pollen grain germinates, sperm nuclei fuse with egg cell"
        ],
        "answer": "Pollen grain germinates, pollen tube forms, sperm nuclei fuse with egg cell"
      },
      {
        "question": "Which of the following is a characteristic feature of a plant with a C4 photosynthetic pathway?",
        "options": [
          "It has a single cell for photosynthesis",
          "It is adapted to hot and dry environments",
          "It has a high rate of transpiration",
          "It uses only chloroplasts for carbon fixation"
        ],
        "answer": "It is adapted to hot and dry environments"
      },
      {
        "question": "What type of placentation is found in the flower of a tomato?",
        "options": [
          "Axile placentation",
          "Marginal placentation",
          "Parietal placentation",
          "Free central placentation"
        ],
        "answer": "Axile placentation"
      },
      {
        "question": "In which part of the flower does the process of meiosis occur to form haploid cells?",
        "options": [
          "Anther",
          "Ovary",
          "Stigma",
          "Style"
        ],
        "answer": "Anther"
      },
      {
        "question": "Which of the following hormones is primarily responsible for the process of seed dormancy?",
        "options": [
          "Auxins",
          "Gibberellins",
          "Abscisic acid",
          "Cytokinins"
        ],
        "answer": "Abscisic acid"
      },
      {
        "question": "Which structure is responsible for the formation of pollen in a flower?",
        "options": [
          "Anther",
          "Stigma",
          "Ovary",
          "Pistil"
        ],
        "answer": "Anther"
      },
      {
        "question": "Which of the following is a correct characteristic of a gymnosperm?",
        "options": [
          "It has enclosed seeds",
          "It has unisexual cones",
          "It has flowers for reproduction",
          "It produces seeds in fruits"
        ],
        "answer": "It has unisexual cones"
      },
      {
        "question": "Which of the following plants uses CAM (Crassulacean Acid Metabolism) for photosynthesis?",
        "options": [
          "Cactus",
          "Rice",
          "Wheat",
          "Maize"
        ],
        "answer": "Cactus"
      },
      {
        "question": "What type of venation is found in the leaves of the plant 'Cotton'?",
        "options": [
          "Parallel venation",
          "Reticulate venation",
          "Pinnate venation",
          "Circular venation"
        ],
        "answer": "Reticulate venation"
      },
      {
        "question": "Which of the following is true about double fertilization in flowering plants?",
        "options": [
          "One sperm cell fuses with the egg cell, and the other fuses with two polar nuclei",
          "It involves only the fusion of the sperm cell and egg cell",
          "It results in the formation of only the zygote",
          "It is absent in monocots"
        ],
        "answer": "One sperm cell fuses with the egg cell, and the other fuses with two polar nuclei"
      },
      {
        "question": "Which of the following is true regarding the process of transpiration in plants?",
        "options": [
          "It only occurs during the daytime",
          "It helps in nutrient transport",
          "It increases the temperature of the plant",
          "It decreases the pressure in the xylem"
        ],
        "answer": "It helps in nutrient transport"
      },
      {
        "question": "Which of the following is the function of the cuticle in plant leaves?",
        "options": [
          "Prevent water loss",
          "Increase photosynthesis",
          "Absorb sunlight",
          "Support the leaf structure"
        ],
        "answer": "Prevent water loss"
      },
      {
        "question": "What is the primary role of the cotyledons in a seed?",
        "options": [
          "Storage of food for the developing embryo",
          "Formation of the seed coat",
          "Absorption of water during germination",
          "Attraction of pollinators"
        ],
        "answer": "Storage of food for the developing embryo"
      },
      {
        "question": "Which of the following is not a characteristic of a dicot plant?",
        "options": [
          "Two cotyledons",
          "Veins in the leaves are reticulate",
          "Presence of vascular bundles in a ring",
          "Parallel venation in leaves"
        ],
        "answer": "Parallel venation in leaves"
      },
      {
        "question": "Which of the following is not a part of the pistil in a flower?",
        "options": [
          "Stigma",
          "Style",
          "Ovary",
          "Anther"
        ],
        "answer": "Anther"
      },
      {
        "question": "Which type of flower is described as having both male and female reproductive organs?",
        "options": [
          "Unisexual flower",
          "Bisexual flower",
          "Incomplete flower",
          "Monoecious flower"
        ],
        "answer": "Bisexual flower"
      },
      {
        "question": "In which plant group are seeds not enclosed in a fruit?",
        "options": [
          "Angiosperms",
          "Gymnosperms",
          "Bryophytes",
          "Pteridophytes"
        ],
        "answer": "Gymnosperms"
      },
      {
        "question": "What is the function of the pollen tube in flowering plants?",
        "options": [
          "To carry water to the ovary",
          "To transport sperm cells to the ovule",
          "To produce pollen",
          "To protect the ovary"
        ],
        "answer": "To transport sperm cells to the ovule"
      },
      {
        "question": "Which of the following is the function of the root cap?",
        "options": [
          "Protection of the growing root tip",
          "Absorption of water",
          "Storage of food",
          "Anchoring the plant to the soil"
        ],
        "answer": "Protection of the growing root tip"
      },
      {
        "question": "Which type of root system is characteristic of monocot plants?",
        "options": [
          "Fibrous root system",
          "Tap root system",
          "Adventitious root system",
          "None of the above"
        ],
        "answer": "Fibrous root system"
      },
      {
        "question": "Which of the following is true regarding xylem in plants?",
        "options": [
          "It is involved in the transport of food",
          "It is composed of living cells",
          "It transports water and minerals from roots to leaves",
          "It is found only in angiosperms"
        ],
        "answer": "It transports water and minerals from roots to leaves"
      },
      {
        "question": "Which of the following structures is responsible for the formation of the endosperm during fertilization?",
        "options": [
          "Ovum",
          "Central cell",
          "Egg cell",
          "Nucleus of the polar cell"
        ],
        "answer": "Central cell"
      },
      {
        "question": "In which part of the flower does meiosis occur during gametogenesis?",
        "options": [
          "Anther",
          "Ovary",
          "Pistil",
          "Stigma"
        ],
        "answer": "Anther"
      },
      {
        "question": "Which of the following is not a characteristic of dicotyledonous plants?",
        "options": [
          "Presence of two cotyledons",
          "Leaf venation is parallel",
          "Presence of vascular bundles in a ring",
          "Presence of a tap root system"
        ],
        "answer": "Leaf venation is parallel"
      },
      {
        "question": "What is the role of gibberellins in plants?",
        "options": [
          "Stimulating seed germination",
          "Inhibiting root growth",
          "Promoting leaf abscission",
          "Preventing flowering"
        ],
        "answer": "Stimulating seed germination"
      },
      {
        "question": "Which of the following is true about pollination in angiosperms?",
        "options": [
          "It is the transfer of pollen from the anther to the stigma",
          "It occurs after fertilization",
          "It involves only wind and water",
          "It occurs only in bisexual flowers"
        ],
        "answer": "It is the transfer of pollen from the anther to the stigma"
      },
      {
        "question": "Which of the following processes occurs during the development of a seed?",
        "options": [
          "Formation of the zygote",
          "Fertilization",
          "Seed coat formation",
          "Germination"
        ],
        "answer": "Seed coat formation"
      },
      {
        "question": "Which of the following is a characteristic feature of a monocot seed?",
        "options": [
          "Presence of two cotyledons",
          "Reticulate venation in leaves",
          "Parallel venation in leaves",
          "Presence of a tap root system"
        ],
        "answer": "Parallel venation in leaves"
      },
      {
        "question": "Which type of placentation is found in the flower of a mustard plant?",
        "options": [
          "Axile placentation",
          "Parietal placentation",
          "Marginal placentation",
          "Basal placentation"
        ],
        "answer": "Parietal placentation"
      },
      {
        "question": "What is the main difference between a gymnosperm and an angiosperm?",
        "options": [
          "Gymnosperms have flowers, while angiosperms do not",
          "Gymnosperms produce seeds in cones, while angiosperms produce seeds in fruits",
          "Angiosperms produce seeds in cones, while gymnosperms produce seeds in fruits",
          "Gymnosperms are non-vascular, while angiosperms are vascular"
        ],
        "answer": "Gymnosperms produce seeds in cones, while angiosperms produce seeds in fruits"
      },
      {
        "question": "Which of the following is true regarding the process of transpiration?",
        "options": [
          "It occurs only during the day",
          "It results in water loss and cooling of the plant",
          "It helps in the uptake of minerals from the soil",
          "It occurs through the stomata of the root"
        ],
        "answer": "It results in water loss and cooling of the plant"
      },
      {
        "question": "Which of the following is the correct sequence of stages during seed germination?",
        "options": [
          "Imbibition, lag phase, radicle emergence, shoot emergence",
          "Lag phase, imbibition, radicle emergence, shoot emergence",
          "Radicle emergence, shoot emergence, lag phase, imbibition",
          "Shoot emergence, radicle emergence, imbibition, lag phase"
        ],
        "answer": "Imbibition, lag phase, radicle emergence, shoot emergence"
      },
      {
        "question": "Which of the following is a function of the phloem in plants?",
        "options": [
          "Transport of water",
          "Transport of sugars from leaves to other parts of the plant",
          "Storage of food",
          "Formation of new cells"
        ],
        "answer": "Transport of sugars from leaves to other parts of the plant"
      },
      {
        "question": "Which of the following is true regarding the flower structure in angiosperms?",
        "options": [
          "The ovary is a part of the stamen",
          "The stigma is located at the base of the flower",
          "The style connects the ovary to the stigma",
          "The anther is located at the base of the pistil"
        ],
        "answer": "The style connects the ovary to the stigma"
      },
      {
        "question": "What is the role of auxins in plant growth?",
        "options": [
          "Stimulating fruit ripening",
          "Inhibiting root growth",
          "Promoting stem elongation",
          "Inhibiting leaf senescence"
        ],
        "answer": "Promoting stem elongation"
      },
      {
        "question": "Which type of reproduction is observed in mosses and ferns?",
        "options": [
          "Asexual reproduction",
          "Sexual reproduction",
          "Both sexual and asexual reproduction",
          "Vegetative reproduction"
        ],
        "answer": "Both sexual and asexual reproduction"
      },
      {
        "question": "Which of the following is true regarding double fertilization in angiosperms?",
        "options": [
          "One sperm cell fuses with the egg cell to form the zygote, and the other sperm cell fuses with the polar nuclei to form the endosperm",
          "Only one sperm cell fuses with the egg cell to form the zygote",
          "It occurs in the roots of the plant",
          "It results in the formation of pollen"
        ],
        "answer": "One sperm cell fuses with the egg cell to form the zygote, and the other sperm cell fuses with the polar nuclei to form the endosperm"
      },
      {
        "question": "What is the function of the ovule in a flower?",
        "options": [
          "To produce pollen",
          "To protect the seeds",
          "To house the female gamete for fertilization",
          "To form the flower petals"
        ],
        "answer": "To house the female gamete for fertilization"
      },
      {
        "question": "Which of the following is a primary function of the leaf in a plant?",
        "options": [
          "Transport of water",
          "Photosynthesis",
          "Formation of seeds",
          "Protection of roots"
        ],
        "answer": "Photosynthesis"
      },
      {
        "question": "Which of the following structures are found in the angiosperm seed?",
        "options": [
          "Endosperm, seed coat, and cotyledons",
          "Seed coat, pollen, and ovary",
          "Pollen, style, and anther",
          "Stem, leaf, and root"
        ],
        "answer": "Endosperm, seed coat, and cotyledons"
      }
]