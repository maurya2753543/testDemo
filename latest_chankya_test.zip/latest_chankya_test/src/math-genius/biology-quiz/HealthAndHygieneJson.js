export const quizQuestions = [
    {
        "id": 1,
        "question": "What is the most effective way to prevent the spread of infectious diseases?",
        "options": [
          "Washing hands frequently with soap",
          "Taking antibiotics regularly",
          "Eating balanced meals",
          "Drinking plenty of water"
        ],
        "correctAnswer": "Washing hands frequently with soap"
      },
      {
        "id": 2,
        "question": "Which of the following is essential for maintaining personal hygiene?",
        "options": [
          "Showering regularly",
          "Wearing the same clothes for days",
          "Not brushing teeth",
          "Skipping meals"
        ],
        "correctAnswer": "Showering regularly"
      },
      {
        "id": 3,
        "question": "What is the recommended duration for washing your hands to effectively remove germs?",
        "options": [
          "5 seconds",
          "10 seconds",
          "20 seconds",
          "30 seconds"
        ],
        "correctAnswer": "20 seconds"
      },
      {
        "id": 4,
        "question": "Which of these habits helps prevent foodborne illnesses?",
        "options": [
          "Washing fruits and vegetables before eating",
          "Eating raw meat",
          "Not refrigerating food",
          "Drinking unfiltered water"
        ],
        "correctAnswer": "Washing fruits and vegetables before eating"
      },
      {
        "id": 5,
        "question": "How can you ensure the cleanliness of your living space?",
        "options": [
          "By vacuuming and dusting regularly",
          "By leaving trash around",
          "By avoiding the use of cleaning products",
          "By never opening windows"
        ],
        "correctAnswer": "By vacuuming and dusting regularly"
      },
      {
        "id": 6,
        "question": "What is a proper way to maintain oral hygiene?",
        "options": [
          "Brushing teeth twice a day",
          "Using a toothbrush once a week",
          "Not flossing",
          "Drinking sugary drinks frequently"
        ],
        "correctAnswer": "Brushing teeth twice a day"
      },
      {
        "id": 7,
        "question": "What is the primary benefit of a balanced diet?",
        "options": [
          "It improves overall health and immune function",
          "It increases body weight",
          "It prevents sleep",
          "It only helps with weight loss"
        ],
        "correctAnswer": "It improves overall health and immune function"
      },
      {
        "id": 8,
        "question": "Which of the following is a basic principle of hand hygiene?",
        "options": [
          "Using hand sanitizer only",
          "Scrubbing hands with soap for 20 seconds",
          "Washing hands once a day",
          "Washing hands with cold water only"
        ],
        "correctAnswer": "Scrubbing hands with soap for 20 seconds"
      },
      {
        "id": 9,
        "question": "Which of the following can help prevent the spread of respiratory diseases?",
        "options": [
          "Wearing a mask in crowded places",
          "Avoiding exercise",
          "Staying indoors all the time",
          "Consuming large amounts of vitamin C"
        ],
        "correctAnswer": "Wearing a mask in crowded places"
      },
      {
        "id": 10,
        "question": "Why is regular exercise important for hygiene and health?",
        "options": [
          "It keeps the body fit and boosts the immune system",
          "It leads to excessive sweating",
          "It causes dehydration",
          "It increases your appetite"
        ],
        "correctAnswer": "It keeps the body fit and boosts the immune system"
      },
      {
        "id": 11,
        "question": "What is the ideal water temperature for washing hands to remove germs effectively?",
        "options": [
          "Cold water",
          "Warm or hot water",
          "Ice-cold water",
          "Water with soap only"
        ],
        "correctAnswer": "Warm or hot water"
      },
      {
        "id": 12,
        "question": "Which of the following is a consequence of poor personal hygiene?",
        "options": [
          "Increased risk of infections",
          "Better physical appearance",
          "Improved social life",
          "Higher energy levels"
        ],
        "correctAnswer": "Increased risk of infections"
      },
      {
        "id": 13,
        "question": "What should be the primary focus when practicing proper sanitation at home?",
        "options": [
          "Cleaning floors and surfaces regularly",
          "Avoiding garbage collection",
          "Storing food uncovered",
          "Not disinfecting high-touch areas"
        ],
        "correctAnswer": "Cleaning floors and surfaces regularly"
      },
      {
        "id": 14,
        "question": "Which of the following is an effective way to prevent the spread of germs after sneezing?",
        "options": [
          "Covering your mouth with your elbow",
          "Sneezing into your hands",
          "Sneezing into the air",
          "Not covering your mouth at all"
        ],
        "correctAnswer": "Covering your mouth with your elbow"
      },
      {
        "id": 15,
        "question": "How often should you change your bed sheets to maintain hygiene?",
        "options": [
          "Once every two weeks",
          "Once a month",
          "Every 3-4 days",
          "Once a year"
        ],
        "correctAnswer": "Once every two weeks"
      },
      {
        "id": 16,
        "question": "What is the main purpose of using hand sanitizers?",
        "options": [
          "To clean hands without water",
          "To moisturize skin",
          "To remove makeup",
          "To cool down the skin"
        ],
        "correctAnswer": "To clean hands without water"
      },
      {
        "id": 17,
        "question": "What is the best way to dispose of used tissues after sneezing or coughing?",
        "options": [
          "Throw them in the trash immediately",
          "Reuse them",
          "Leave them on the table",
          "Flush them down the toilet"
        ],
        "correctAnswer": "Throw them in the trash immediately"
      },
      {
        "id": 18,
        "question": "Which of the following is a major risk factor for developing skin infections?",
        "options": [
          "Using clean towels regularly",
          "Not showering after sweating",
          "Wearing breathable fabrics",
          "Regular hand washing"
        ],
        "correctAnswer": "Not showering after sweating"
      },
      {
        "id": 19,
        "question": "Which of the following is the best way to protect your skin from harmful UV rays?",
        "options": [
          "Wearing sunscreen with SPF 30 or higher",
          "Applying moisturizer only",
          "Staying in the shade during peak hours",
          "Wearing dark-colored clothes"
        ],
        "correctAnswer": "Wearing sunscreen with SPF 30 or higher"
      },
      {
        "id": 20,
        "question": "What is the recommended way to maintain oral health during the day?",
        "options": [
          "Brushing teeth after every meal",
          "Brushing teeth once a day only",
          "Eating sugary snacks frequently",
          "Skipping brushing in the morning"
        ],
        "correctAnswer": "Brushing teeth after every meal"
      },
      {
        "id": 21,
        "question": "How often should you clean your cell phone to prevent the spread of germs?",
        "options": [
          "Every week",
          "Once a month",
          "After every use",
          "Once every three months"
        ],
        "correctAnswer": "Every week"
      },
      {
        "id": 22,
        "question": "Which of the following is considered a proper hygiene practice for handling food?",
        "options": [
          "Washing your hands before preparing food",
          "Touching food with dirty hands",
          "Leaving food uncovered",
          "Using the same knife for raw and cooked food"
        ],
        "correctAnswer": "Washing your hands before preparing food"
      },
      {
        "id": 23,
        "question": "Which of the following is a sign of dehydration?",
        "options": [
          "Clear urine",
          "Dark yellow urine",
          "Normal body temperature",
          "Increased energy levels"
        ],
        "correctAnswer": "Dark yellow urine"
      },
      {
        "id": 24,
        "question": "What is the recommended way to dispose of expired or unused medicines?",
        "options": [
          "Flush them down the toilet",
          "Throw them in the trash",
          "Return them to a pharmacy",
          "Use them later"
        ],
        "correctAnswer": "Return them to a pharmacy"
      },
      {
        "id": 25,
        "question": "How can you minimize the spread of germs when in public places?",
        "options": [
          "By washing hands after touching common surfaces",
          "By touching everything with bare hands",
          "By ignoring coughs and sneezes",
          "By avoiding hand sanitizers"
        ],
        "correctAnswer": "By washing hands after touching common surfaces"
      },
      {
        "id": 26,
        "question": "Which of the following should you do before preparing food?",
        "options": [
          "Wash your hands thoroughly",
          "Wear gloves only",
          "Avoid washing hands",
          "Clean the kitchen counter once a day"
        ],
        "correctAnswer": "Wash your hands thoroughly"
      },
      {
        "id": 27,
        "question": "Which of these is important to reduce the risk of infectious diseases during travel?",
        "options": [
          "Drinking bottled water",
          "Avoiding water from the tap",
          "Not washing hands frequently",
          "Eating unpeeled fruits"
        ],
        "correctAnswer": "Drinking bottled water"
      },
      {
        "id": 28,
        "question": "What should you do if you are feeling unwell and have flu symptoms?",
        "options": [
          "Stay home and rest",
          "Go to work/school",
          "Continue exercising",
          "Go to a crowded place"
        ],
        "correctAnswer": "Stay home and rest"
      },
      {
        "id": 29,
        "question": "Which is a key habit for maintaining proper personal hygiene during the cold weather?",
        "options": [
          "Covering your mouth and nose when coughing or sneezing",
          "Wearing the same clothes for days",
          "Avoiding showers to stay warm",
          "Not washing your hands frequently"
        ],
        "correctAnswer": "Covering your mouth and nose when coughing or sneezing"
      },
      {
        "id": 30,
        "question": "What is the proper way to wash your hands after using the toilet?",
        "options": [
          "Using soap and water for at least 20 seconds",
          "Using soap only without water",
          "Rinsing hands with water only",
          "Washing hands with hand sanitizer only"
        ],
        "correctAnswer": "Using soap and water for at least 20 seconds"
      },
      {
        "id": 31,
        "question": "Why is it important to clean your feet regularly?",
        "options": [
          "To prevent infections and odor",
          "To make them softer",
          "To improve circulation",
          "To make your shoes fit better"
        ],
        "correctAnswer": "To prevent infections and odor"
      },
      {
        "id": 32,
        "question": "What is the best way to keep your workplace clean and hygienic?",
        "options": [
          "Wipe down surfaces regularly and avoid sharing personal items",
          "Leave food items exposed",
          "Share personal items with coworkers",
          "Avoid cleaning common areas"
        ],
        "correctAnswer": "Wipe down surfaces regularly and avoid sharing personal items"
      },
      {
        "id": 33,
        "question": "Which of the following can help improve indoor air quality?",
        "options": [
          "Opening windows to let in fresh air",
          "Using air fresheners frequently",
          "Avoiding cleaning",
          "Keeping windows closed at all times"
        ],
        "correctAnswer": "Opening windows to let in fresh air"
      },
      {
        "id": 34,
        "question": "Which of the following is an effective method to reduce the spread of COVID-19?",
        "options": [
          "Wearing a mask in public places",
          "Shaking hands frequently",
          "Going to crowded places",
          "Not washing hands regularly"
        ],
        "correctAnswer": "Wearing a mask in public places"
      },
      {
        "id": 35,
        "question": "What is the best practice to avoid the transmission of viruses?",
        "options": [
          "Avoiding close contact with sick people",
          "Not washing hands",
          "Shaking hands with everyone",
          "Breathing into your hands"
        ],
        "correctAnswer": "Avoiding close contact with sick people"
      },
      {
        "id": 36,
        "question": "What is the primary reason for sanitizing commonly touched objects like doorknobs?",
        "options": [
          "To remove dirt and dust",
          "To prevent the spread of germs",
          "To improve the appearance",
          "To make them shiny"
        ],
        "correctAnswer": "To prevent the spread of germs"
      },
      {
        "id": 37,
        "question": "What should you do before handling food?",
        "options": [
          "Wash your hands with soap and water",
          "Touch raw meat directly",
          "Use the same utensils for different foods",
          "Keep food at room temperature"
        ],
        "correctAnswer": "Wash your hands with soap and water"
      },
      {
        "id": 38,
        "question": "How can you maintain good respiratory hygiene?",
        "options": [
          "By covering your mouth and nose when coughing or sneezing",
          "By avoiding exercise",
          "By staying indoors all the time",
          "By not washing your hands"
        ],
        "correctAnswer": "By covering your mouth and nose when coughing or sneezing"
      },
      {
        "id": 39,
        "question": "Which of the following is the best way to reduce stress and improve hygiene?",
        "options": [
          "Engaging in regular exercise and proper sleep",
          "Skipping meals and staying awake",
          "Staying isolated",
          "Avoiding showers"
        ],
        "correctAnswer": "Engaging in regular exercise and proper sleep"
      },
      {
        "id": 40,
        "question": "What is the correct way to dispose of waste to keep the environment clean?",
        "options": [
          "By separating recyclable waste from non-recyclable waste",
          "By throwing everything into one bin",
          "By burning waste materials",
          "By leaving waste on the ground"
        ],
        "correctAnswer": "By separating recyclable waste from non-recyclable waste"
      },
      {
        "id": 41,
        "question": "What is the most effective way to prevent the spread of infectious diseases?",
        "options": [
          "Washing hands regularly",
          "Taking antibiotics",
          "Consuming vitamins",
          "Drinking herbal teas"
        ],
        "correctAnswer": "Washing hands regularly"
      },
      {
        "id": 42,
        "question": "Which of the following actions helps in preventing the development of antibiotic resistance?",
        "options": [
          "Taking the full prescribed course of antibiotics",
          "Stopping antibiotics as soon as symptoms disappear",
          "Self-prescribing antibiotics for minor illnesses",
          "Sharing antibiotics with family members"
        ],
        "correctAnswer": "Taking the full prescribed course of antibiotics"
      },
      {
        "id": 43,
        "question": "Why is it important to practice personal hygiene during menstruation?",
        "options": [
          "To prevent infections and maintain comfort",
          "To avoid embarrassment",
          "To avoid getting pregnant",
          "To improve skin appearance"
        ],
        "correctAnswer": "To prevent infections and maintain comfort"
      },
      {
        "id": 44,
        "question": "What is the best method for cleaning reusable water bottles?",
        "options": [
          "Wash them with soap and water regularly",
          "Wipe them with a cloth",
          "Use only water to rinse them",
          "Leave them in sunlight"
        ],
        "correctAnswer": "Wash them with soap and water regularly"
      },
      {
        "id": 45,
        "question": "How can you protect yourself from foodborne illnesses?",
        "options": [
          "By cooking food at the proper temperature",
          "By eating food past its expiration date",
          "By not washing fruits and vegetables",
          "By storing food in the refrigerator only"
        ],
        "correctAnswer": "By cooking food at the proper temperature"
      },
      {
        "id": 46,
        "question": "Which of the following is the correct way to use a tissue when sneezing or coughing?",
        "options": [
          "Cover your nose and mouth, then dispose of the tissue immediately",
          "Reuse the tissue",
          "Keep the tissue in your pocket",
          "Wash the tissue after use"
        ],
        "correctAnswer": "Cover your nose and mouth, then dispose of the tissue immediately"
      },
      {
        "id": 47,
        "question": "What is the primary purpose of a face mask during a pandemic?",
        "options": [
          "To reduce the spread of germs from coughing or sneezing",
          "To improve airflow to the lungs",
          "To keep warm",
          "To avoid skin irritation"
        ],
        "correctAnswer": "To reduce the spread of germs from coughing or sneezing"
      },
      {
        "id": 48,
        "question": "Which of the following is an example of proper hand hygiene?",
        "options": [
          "Washing hands with soap for at least 20 seconds",
          "Washing hands with water only",
          "Using hand sanitizer on dirty hands",
          "Washing hands only when visible dirt is present"
        ],
        "correctAnswer": "Washing hands with soap for at least 20 seconds"
      },
      {
        "id": 49,
        "question": "How can you prevent the spread of lice?",
        "options": [
          "By not sharing personal items such as hats or combs",
          "By washing your hair daily",
          "By using hair gel regularly",
          "By avoiding brushing your hair"
        ],
        "correctAnswer": "By not sharing personal items such as hats or combs"
      },
      {
        "id": 50,
        "question": "Why is it important to maintain good sleep hygiene?",
        "options": [
          "To improve sleep quality and overall health",
          "To avoid getting sick",
          "To lose weight",
          "To avoid dehydration"
        ],
        "correctAnswer": "To improve sleep quality and overall health"
      },
      {
        "id": 51,
        "question": "Which of the following is a sign that you need to seek medical help for a wound?",
        "options": [
          "The wound is not healing and shows signs of infection",
          "The wound is slightly red",
          "The wound has a scab forming",
          "The wound feels sore but is not swollen"
        ],
        "correctAnswer": "The wound is not healing and shows signs of infection"
      },
      {
        "id": 52,
        "question": "What is the best way to prevent dehydration in hot weather?",
        "options": [
          "Drink plenty of water and avoid alcohol",
          "Consume caffeinated drinks",
          "Exercise in the sun",
          "Avoid drinking liquids"
        ],
        "correctAnswer": "Drink plenty of water and avoid alcohol"
      },
      {
        "id": 53,
        "question": "Which of the following is a preventive measure for maintaining good mental health?",
        "options": [
          "Engaging in regular physical activity",
          "Ignoring emotional needs",
          "Overworking without breaks",
          "Isolating yourself from others"
        ],
        "correctAnswer": "Engaging in regular physical activity"
      },
      {
        "id": 54,
        "question": "What should you do if you develop a rash after using a new skin product?",
        "options": [
          "Stop using the product and consult a healthcare provider",
          "Ignore the rash and continue using the product",
          "Apply more of the product to treat the rash",
          "Use the product with other skincare products"
        ],
        "correctAnswer": "Stop using the product and consult a healthcare provider"
      },
      {
        "id": 55,
        "question": "What is the first step in dealing with a choking incident?",
        "options": [
          "Try to help the person cough",
          "Call for medical assistance immediately",
          "Perform the Heimlich maneuver",
          "Give the person water to drink"
        ],
        "correctAnswer": "Try to help the person cough"
      },
      {
        "id": 56,
        "question": "Which of the following foods should be avoided to maintain a healthy diet?",
        "options": [
          "Foods high in saturated fats and sugars",
          "Fruits and vegetables",
          "Whole grains",
          "Lean proteins"
        ],
        "correctAnswer": "Foods high in saturated fats and sugars"
      },
      {
        "id": 57,
        "question": "How can you reduce the risk of developing a cold?",
        "options": [
          "By washing your hands frequently and avoiding close contact with sick people",
          "By avoiding exercise and staying indoors",
          "By increasing sugar intake",
          "By reducing water intake"
        ],
        "correctAnswer": "By washing your hands frequently and avoiding close contact with sick people"
      },
      {
        "id": 58,
        "question": "What is the primary reason for wearing gloves when handling food?",
        "options": [
          "To prevent contamination from your hands",
          "To keep the food cold",
          "To improve the taste of the food",
          "To make the food look better"
        ],
        "correctAnswer": "To prevent contamination from your hands"
      },
      {
        "id": 59,
        "question": "Which of the following is a good practice for maintaining oral hygiene?",
        "options": [
          "Brushing teeth at least twice a day",
          "Brushing teeth only when food is stuck",
          "Skipping flossing",
          "Drinking sugary beverages"
        ],
        "correctAnswer": "Brushing teeth at least twice a day"
      },
      {
        "id": 60,
        "question": "What is the best way to ensure a healthy environment in your home?",
        "options": [
          "Regularly cleaning and ventilating the home",
          "Leaving rooms uncleaned",
          "Avoiding any form of cleaning",
          "Using strong chemical cleaners only"
        ],
        "correctAnswer": "Regularly cleaning and ventilating the home"
      }
]