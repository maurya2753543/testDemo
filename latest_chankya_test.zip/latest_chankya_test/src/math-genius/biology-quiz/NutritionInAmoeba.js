import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaHandSparkles } from "react-icons/fa";
import { GiSpoon } from "react-icons/gi";
import NutritionInAmoebaQuiz from './NutritionInAmoebaQuiz';

const NutritionInAmoeba = () => {
  const [triggerAnimation, setTriggerAnimation] = useState(false);

  const handleReload = () => {
    // Toggle the animation state to trigger re-render and restart animations
    setTriggerAnimation(!triggerAnimation);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        Nutrition in Amoeba
      </h1>

      {/* Reload Button */}
      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <button
          onClick={handleReload}
          style={{
            padding: "10px 20px",
            fontSize: "16px",
            cursor: "pointer",
            borderRadius: "5px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
          }}
        >
          Reload Animations
        </button>
      </div>

      {/* Step 1: Ingestion */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1 }}
        style={{ textAlign: "center" }}
      >
        <h3>Step 1: Ingestion</h3>
        <p>
          The amoeba captures food particles by extending its pseudopodia and
          engulfing them through phagocytosis.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaHandSparkles size={50} color="green" />
        </motion.div>
      </motion.div>

      {/* Step 2: Digestion */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 1 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 2: Digestion</h3>
        <p>
          The engulfed food is enclosed in a food vacuole where digestive
          enzymes break it down into smaller molecules.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <GiSpoon size={50} color="brown" />
        </motion.div>
      </motion.div>

      {/* Step 3: Absorption */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 2 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 3: Absorption</h3>
        <p>
          Nutrients from the digested food are absorbed into the amoeba's
          cytoplasm, providing energy and growth.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaHandSparkles size={50} color="orange" />
        </motion.div>
      </motion.div>

      {/* Step 4: Egestion */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, y: triggerAnimation ? 0 : 50 }}
        transition={{ duration: 1, delay: 3 }}
        style={{
          textAlign: "center",
          marginTop: "40px",
          padding: "20px",
          border: "1px solid #ccc",
          borderRadius: "10px",
        }}
      >
        <h3>Step 4: Egestion</h3>
        <p>
          Waste material that could not be digested is expelled from the cell
          through exocytosis.
        </p>
      </motion.div>
      <NutritionInAmoebaQuiz />
    </div>
  );
};

export default NutritionInAmoeba;
