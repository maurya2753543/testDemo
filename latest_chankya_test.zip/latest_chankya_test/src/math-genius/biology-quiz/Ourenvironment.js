import React, { useState } from "react"; 
import { motion } from "framer-motion"; 
import { FaLeaf } from "react-icons/fa"; // Environment related icon
import { GiTreeGrowth } from 'react-icons/gi'; // Tree growth icon
import OurenvironmentQuiz from './OurenvironmentQuiz';

const OurEnvironment = () => {
  const [triggerAnimation, setTriggerAnimation] = useState(false);

  const handleReload = () => {
    // Toggle the animation state to trigger re-render and restart animations
    setTriggerAnimation(!triggerAnimation);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        Our Environment
      </h1>

      {/* Reload Button */}
      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <button
          onClick={handleReload}
          style={{
            padding: "10px 20px",
            fontSize: "16px",
            cursor: "pointer",
            borderRadius: "5px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
          }}
        >
          Reload Animations
        </button>
      </div>

      {/* Step 1: Introduction to Environment */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1 }}
        style={{ textAlign: "center" }}
      >
        <h3>Step 1: Introduction to Environment</h3>
        <p>
          The environment includes both the living and non-living components of Earth. It includes air, water, soil, plants, and animals.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaLeaf size={50} color="green" />
        </motion.div>
      </motion.div>

      {/* Step 2: Ecosystem */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 1 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 2: Ecosystem</h3>
        <p>
          An ecosystem consists of all the living organisms and the physical environment with which they interact.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <GiTreeGrowth size={50} color="brown" />
        </motion.div>
      </motion.div>

      {/* Step 3: Pollution */}
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, x: triggerAnimation ? 0 : -100 }}
        transition={{ duration: 1, delay: 2 }}
        style={{ textAlign: "center", marginTop: "40px" }}
      >
        <h3>Step 3: Pollution</h3>
        <p>
          Pollution refers to the harmful substances introduced into the environment, damaging it and affecting living organisms.
        </p>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: triggerAnimation ? 1 : 0 }}
          transition={{ duration: 1 }}
          style={{ margin: "20px" }}
        >
          <FaLeaf size={50} color="gray" />
        </motion.div>
      </motion.div>

      {/* Step 4: Conservation Efforts */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, y: triggerAnimation ? 0 : 50 }}
        transition={{ duration: 1, delay: 3 }}
        style={{
          textAlign: "center",
          marginTop: "40px",
          padding: "20px",
          border: "1px solid #ccc",
          borderRadius: "10px",
        }}
      >
        <h3>Step 4: Conservation Efforts</h3>
        <p>
          Conservation efforts aim to preserve and protect natural resources, wildlife, and the environment for future generations.
        </p>
      </motion.div>

      {/* Additional animated section for deeper engagement */}
      <motion.div
        initial={{ opacity: 0, rotate: 180 }}
        animate={{ opacity: triggerAnimation ? 1 : 0, rotate: triggerAnimation ? 0 : 180 }}
        transition={{ duration: 1.5, delay: 4 }}
        style={{
          textAlign: "center",
          padding: "20px",
          backgroundColor: "#f9f9f9",
          marginTop: "40px",
          borderRadius: "8px",
        }}
      >
        <h3>Step 5: Sustainable Development</h3>
        <p>
          Sustainable development focuses on meeting the needs of the present without compromising the ability of future generations to meet their own needs.
        </p>
      </motion.div>

      {/* Add quiz component */}
      <OurenvironmentQuiz />
    </div>
  );
};

export default OurEnvironment;
