import React, { useState, useEffect } from 'react';
import { Tooltip } from 'react-tooltip';  // Corrected import
import './BigWatch.css'; // Add custom styles for the watch
import TimeLearn from './TimeLearn';
import TimeQuiz from './TimeQuiz';
const Watch = () => {
  const [time, setTime] = useState(new Date());
  const [startTime] = useState(new Date()); // Track when the student starts learning
  const [elapsedTime, setElapsedTime] = useState(0); // Elapsed time in seconds
  const [clickedTime, setClickedTime] = useState(null); // Time displayed when a number is clicked

  // Function to update time every second
  useEffect(() => {
    const intervalId = setInterval(() => {
      setTime(new Date());
      setElapsedTime(Math.floor((new Date() - startTime) / 1000)); // Update elapsed time in seconds
    }, 1000);

    return () => clearInterval(intervalId);
  }, [startTime]);

  // Calculate the rotation of the hands based on the time
  const hour = time.getHours() % 12; // 12-hour format
  const minute = time.getMinutes();
  const second = time.getSeconds();

  // Rotation angles for each hand
  const hourDegree = (360 / 12) * hour + (360 / 12) * (minute / 60); 
  const minuteDegree = (360 / 60) * minute;
  const secondDegree = (360 / 60) * second;

  // Convert elapsed time to HH:MM:SS format
  const formatElapsedTime = (elapsedTime) => {
    const hours = Math.floor(elapsedTime / 3600);
    const minutes = Math.floor((elapsedTime % 3600) / 60);
    const seconds = elapsedTime % 60;
    return `${hours}:${minutes < 10 ? `0${minutes}` : minutes}:${seconds < 10 ? `0${seconds}` : seconds}`;
  };

  // Handle click on number to show corresponding time
  const handleNumberClick = (number) => {
    const clickedHour = number;
    const clickedMinute = time.getMinutes();
    const clickedSecond = time.getSeconds();

    // Set the time to show when a number is clicked
    setClickedTime(`${clickedHour}:${clickedMinute < 10 ? `0${clickedMinute}` : clickedMinute}:${clickedSecond < 10 ? `0${clickedSecond}` : clickedSecond}`);
  };

  return (
    <>
     <div className="watch-container">
      <div className="watch-face">
        <div className="numbers">
          {[...Array(12)].map((_, i) => {
            const number = i + 1;
            return (
              <div
                key={i}
                className="number"
                style={{
                  transform: `rotate(${(360 / 12) * i}deg) translateY(-80px)`,
                }}
                onClick={() => handleNumberClick(number)} // Add click handler
              >
                {number}
              </div>
            );
          })}
        </div>

        <div
          className="hand hour"
          style={{ transform: `rotate(${hourDegree}deg)` }}
          data-tip={`Time: ${hour}:${minute < 10 ? `0${minute}` : minute}:${second < 10 ? `0${second}` : second}`}
        ></div>
        <div
          className="hand minute"
          style={{ transform: `rotate(${minuteDegree}deg)` }}
          data-tip={`Time: ${hour}:${minute < 10 ? `0${minute}` : minute}:${second < 10 ? `0${second}` : second}`}
        ></div>
        <div
          className="hand second"
          style={{ transform: `rotate(${secondDegree}deg)` }}
          data-tip={`Time: ${hour}:${minute < 10 ? `0${minute}` : minute}:${second < 10 ? `0${second}` : second}`}
        ></div>
      </div>

      {/* Display current time and student learning time */}
      <div className="learn-time">
        <p>
          Current Time: {hour}:{minute < 10 ? `0${minute}` : minute}:
          {second < 10 ? `0${second}` : second} 
        </p>
        <p>Student Learn Time: {formatElapsedTime(elapsedTime)}</p>
      </div>

      {/* Display the time when a number is clicked */}
      {clickedTime && (
        <div className="clicked-time">
          <p>Clicked Time: {clickedTime}</p>
        </div>
      )}

      <Tooltip place="top" type="dark" effect="solid" />
    </div>

    <TimeLearn />
    <div style={{ margin : '40px' , padding : '20px'}}>
    <TimeQuiz />

    </div>
    </>
   
  );
};

export default Watch;
