import React from 'react';
import './AdditionVideoSteptwonumber.css'; // Import the CSS file

const MathAddition = () => {
  const examples = [
    {
      title: "Example 1: Simple Addition Without Carrying",
      problem: "23 + 45",
      steps: [
        "Step 1: Add the ones place. 3 + 5 = 8. Write 8 in the ones place of the answer.",
        "Step 2: Add the tens place. 2 + 4 = 6. Write 6 in the tens place of the answer.",
        "Answer: 68",
      ],
    },
    {
      title: "Example 2: Addition With Carrying",
      problem: "47 + 58",
      steps: [
        "Step 1: Add the ones place. 7 + 8 = 15. Write 5 in the ones place and carry over 1.",
        "Step 2: Add the tens place. 4 + 5 + 1 = 10. Write 0 in the tens place and carry over 1.",
        "Answer: 105",
      ],
    },
    {
      title: "Example 3: Practice Problem",
      problem: "36 + 27",
      steps: [
        "Step 1: Add the ones place. 6 + 7 = 13. Write 3 and carry over 1.",
        "Step 2: Add the tens place. 3 + 2 + 1 = 6. Write 6.",
        "Answer: 63",
      ],
    },
    {
      title: "Example 4: Challenge Problem",
      problem: "89 + 76",
      steps: [
        "Step 1: Add the ones place. 9 + 6 = 15. Write 5 and carry over 1.",
        "Step 2: Add the tens place. 8 + 7 + 1 = 16. Write 6 and carry over 1.",
        "Answer: 165",
      ],
    },
  ];

  return (
    <div className="math-container">
      <h1>Learn Addition</h1>
      {examples.map((example, index) => (
        <div className="card" key={index}>
          <h2>{example.title}</h2>
          <p>Problem: {example.problem}</p>
          {example.steps.map((step, stepIndex) => (
            <p key={stepIndex}>{step}</p>
          ))}
        </div>
      ))}
    </div>
  );
};

export default MathAddition;
