import React, { useState } from "react";
import { motion } from "framer-motion";
import CarbonAndCompoundsQuiz from './CarbonAndCompoundsQuiz'; // Assuming you have a quiz component for this

const CarbonAndCompounds = () => {
  const [compoundType, setCompoundType] = useState(""); // Tracks the selected compound type

  // Styles for atoms
  const atomStyles = {
    width: 50,
    height: 50,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
    fontWeight: "bold",
    position: "absolute",
  };

  const renderBondLines = () => {
    if (compoundType === "Methane") {
      return (
        <>
          {/* Bonds for Methane (CH₄) */}
          <line x1="200" y1="200" x2="300" y2="100" stroke="black" strokeWidth="2" />
          <line x1="200" y1="200" x2="300" y2="300" stroke="black" strokeWidth="2" />
          <line x1="200" y1="200" x2="100" y2="200" stroke="black" strokeWidth="2" />
          <line x1="200" y1="200" x2="400" y2="200" stroke="black" strokeWidth="2" />
        </>
      );
    } else if (compoundType === "Ethene") {
      return (
        <>
          {/* Bonds for Ethene (C₂H₄) */}
          <line x1="200" y1="200" x2="300" y2="200" stroke="black" strokeWidth="2" />
        </>
      );
    } else if (compoundType === "Ethanol") {
      return (
        <>
          {/* Bonds for Ethanol (C₂H₅OH) */}
          <line x1="200" y1="200" x2="300" y2="200" stroke="black" strokeWidth="2" />
          <line x1="300" y1="200" x2="400" y2="200" stroke="black" strokeWidth="2" />
        </>
      );
    }
    return null;
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center" }}>Carbon and its Compounds Animation</h1>

      {/* Buttons for different compounds */}
      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <button
          onClick={() => setCompoundType("Methane")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#3498db",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Methane (CH₄)
        </button>
        <button
          onClick={() => setCompoundType("Ethene")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#e74c3c",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Ethene (C₂H₄)
        </button>
        <button
          onClick={() => setCompoundType("Ethanol")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#2ecc71",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Ethanol (C₂H₅OH)
        </button>
      </div>

      {/* Dynamic compound animations */}
      <div style={{ position: "relative", height: "400px", width: "100%", background: "#f0f0f0", overflow: "hidden" }}>
        <svg width="100%" height="400">
          {renderBondLines()}
        </svg>

        {/* Atoms */}
        {compoundType === "Methane" && (
          <>
            {/* Carbon Atom */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#2ecc71",
                left: "200px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              C
            </div>

            {/* Hydrogen Atoms */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "100px", top: "200px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "300px", top: "100px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "300px", top: "300px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "400px", top: "200px" }}
            >
              H
            </motion.div>
          </>
        )}

        {compoundType === "Ethene" && (
          <>
            {/* Carbon Atoms */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#2ecc71",
                left: "200px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              C
            </div>
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#2ecc71",
                left: "300px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              C
            </div>

            {/* Hydrogen Atoms */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "100px", top: "200px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "400px", top: "200px" }}
            >
              H
            </motion.div>
          </>
        )}

        {compoundType === "Ethanol" && (
          <>
            {/* Carbon Atoms */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#2ecc71",
                left: "200px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              C
            </div>
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#2ecc71",
                left: "300px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              C
            </div>

            {/* Hydrogen Atoms */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "100px", top: "200px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "400px", top: "200px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "300px", top: "300px" }}
            >
              H
            </motion.div>

            {/* Oxygen Atom */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#e74c3c",
                left: "400px",
                top: "300px",
                transform: "translate(-50%, -50%)",
              }}
            >
              O
            </div>
          </>
        )}
      </div>
      <CarbonAndCompoundsQuiz />
    </div>
  );
};

export default CarbonAndCompounds;
