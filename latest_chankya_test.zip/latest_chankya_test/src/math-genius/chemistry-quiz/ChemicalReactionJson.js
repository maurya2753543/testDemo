export const quizQuestions = [
    {
        "question": "What is a combination reaction?",
        "options": [
            "A reaction where two or more reactants combine to form one product",
            "A reaction where a compound breaks down into two or more products",
            "A reaction that releases energy in the form of heat",
            "A reaction that does not involve any changes in chemical bonds"
        ],
       correct: "A reaction where two or more reactants combine to form one product"
    },
    {
        "question": "Which of the following is an example of a combination reaction?",
        "options": [
            "2H₂ + O₂ → 2H₂O",
            "2NaCl → 2Na + Cl₂",
            "CaCO₃ → CaO + CO₂",
            "H₂O → H₂ + O₂"
        ],
       correct: "2H₂ + O₂ → 2H₂O"
    },
    {
        "question": "Which reaction is an example of a decomposition reaction?",
        "options": [
            "2Na + Cl₂ → 2NaCl",
            "CaCO₃ → CaO + CO₂",
            "H₂ + O₂ → H₂O",
            "N₂ + 3H₂ → 2NH₃"
        ],
       correct: "CaCO₃ → CaO + CO₂"
    },
    {
        "question": "Which of the following best describes a decomposition reaction?",
        "options": [
            "A compound breaks down into two or more simpler substances",
            "Two elements combine to form a new compound",
            "A single element undergoes oxidation",
            "A compound releases energy during a reaction"
        ],
       correct: "A compound breaks down into two or more simpler substances"
    },
    {
        "question": "What happens during a decomposition reaction?",
        "options": [
            "Two or more reactants combine to form one product",
            "A compound breaks down into simpler substances",
            "A single substance is oxidized",
            "Energy is released in the form of light"
        ],
       correct: "A compound breaks down into simpler substances"
    },
    {
        "question": "Which of the following is an example of a combination reaction?",
        "options": [
            "2NaCl → 2Na + Cl₂",
            "Fe + S → FeS",
            "2H₂O → 2H₂ + O₂",
            "H₂ + O₂ → H₂O"
        ],
       correct: "Fe + S → FeS"
    },
    {
        "question": "What type of reaction is represented by the equation: 2H₂ + O₂ → 2H₂O?",
        "options": [
            "Combination reaction",
            "Decomposition reaction",
            "Single displacement reaction",
            "Double displacement reaction"
        ],
       correct: "Combination reaction"
    },
    {
        "question": "Which of the following is a characteristic of a decomposition reaction?",
        "options": [
            "Formation of a single product",
            "Breaking down of a compound into simpler substances",
            "Combining elements to form a compound",
            "No change in the reactants"
        ],
       correct: "Breaking down of a compound into simpler substances"
    },
    {
        "question": "Which substance is produced in a decomposition reaction of potassium chlorate (2KClO₃ → 2KCl + 3O₂)?",
        "options": [
            "Oxygen",
            "Carbon dioxide",
            "Sodium chloride",
            "Hydrogen"
        ],
       correct: "Oxygen"
    },
    {
        "question": "What is produced when magnesium burns in oxygen (2Mg + O₂ → 2MgO)?",
        "options": [
            "Magnesium oxide",
            "Magnesium hydroxide",
            "Magnesium chloride",
            "Ozone"
        ],
       correct: "Magnesium oxide"
    },
    {
        "question": "Which of the following reactions is a decomposition reaction?",
        "options": [
            "C + O₂ → CO₂",
            "H₂O → H₂ + O₂",
            "Na + Cl₂ → NaCl",
            "Fe + S → FeS"
        ],
       correct: "H₂O → H₂ + O₂"
    },
    {
        "question": "Which of the following best defines a combination reaction?",
        "options": [
            "A reaction where two or more reactants form a single product",
            "A reaction that produces heat energy",
            "A reaction that involves the breakdown of a substance",
            "A reaction where two compounds exchange ions"
        ],
       correct: "A reaction where two or more reactants form a single product"
    },
    {
        "question": "Which equation represents a combination reaction?",
        "options": [
            "2Na + Cl₂ → 2NaCl",
            "CaO + H₂O → Ca(OH)₂",
            "2H₂O → 2H₂ + O₂",
            "NaCl → Na + Cl₂"
        ],
       correct: "2Na + Cl₂ → 2NaCl"
    },
    {
        "question": "In which of the following reactions is a new compound formed?",
        "options": [
            "2NaCl → 2Na + Cl₂",
            "C + O₂ → CO₂",
            "CaCO₃ → CaO + CO₂",
            "H₂O → H₂ + O₂"
        ],
       correct: "C + O₂ → CO₂"
    },
    {
        "question": "Which of the following is an example of a combination reaction?",
        "options": [
            "2H₂ + O₂ → 2H₂O",
            "2NaCl → 2Na + Cl₂",
            "CaCO₃ → CaO + CO₂",
            "H₂ + O₂ → H₂O"
        ],
       correct: "2H₂ + O₂ → 2H₂O"
    },
    {
        "question": "Which of the following reactions is an example of decomposition?",
        "options": [
            "2H₂O → 2H₂ + O₂",
            "Na + Cl₂ → NaCl",
            "H₂ + O₂ → H₂O",
            "Fe + S → FeS"
        ],
       correct: "2H₂O → 2H₂ + O₂"
    },
    {
        "question": "What is the result of the decomposition of water?",
        "options": [
            "Hydrogen and oxygen",
            "Oxygen and carbon dioxide",
            "Water and hydrogen",
            "Hydrogen and carbon dioxide"
        ],
       correct: "Hydrogen and oxygen"
    },
    {
        "question": "What is the product of a combination reaction between hydrogen and oxygen?",
        "options": [
            "H₂O",
            "H₂O₂",
            "O₂",
            "H₂"
        ],
       correct: "H₂O"
    },
    {
        "question": "Which of the following reactions shows the formation of a new compound?",
        "options": [
            "2H₂ + O₂ → 2H₂O",
            "CaCO₃ → CaO + CO₂",
            "C + O₂ → CO₂",
            "NaCl → Na + Cl₂"
        ],
       correct: "2H₂ + O₂ → 2H₂O"
    },
    {
        "question": "What is an exothermic reaction?",
        "options": [
            "A reaction that absorbs heat from the surroundings",
            "A reaction that releases heat to the surroundings",
            "A reaction that does not change temperature",
            "A reaction that requires electricity to proceed"
        ],
       correct: "A reaction that releases heat to the surroundings"
    },
    {
        "question": "Which of the following is an example of an exothermic reaction?",
        "options": [
            "Burning of wood",
            "Melting of ice",
            "Evaporation of water",
            "Photosynthesis"
        ],
       correct: "Burning of wood"
    },
    {
        "question": "Which of the following is an example of an endothermic reaction?",
        "options": [
            "Combustion of gasoline",
            "Formation of rust",
            "Photosynthesis",
            "Freezing of water"
        ],
       correct: "Photosynthesis"
    },
    {
        "question": "What happens to the temperature of the surroundings during an exothermic reaction?",
        "options": [
            "The temperature decreases",
            "The temperature remains constant",
            "The temperature increases",
            "The temperature fluctuates"
        ],
       correct: "The temperature increases"
    },
    {
        "question": "What happens to the temperature of the surroundings during an endothermic reaction?",
        "options": [
            "The temperature increases",
            "The temperature decreases",
            "The temperature remains constant",
            "The temperature fluctuates"
        ],
       correct: "The temperature decreases"
    },
    {
        "question": "Which of the following reactions is exothermic?",
        "options": [
            "Dissolving ammonium nitrate in water",
            "Burning of hydrogen",
            "Boiling water",
            "Melting ice"
        ],
       correct: "Burning of hydrogen"
    },
    {
        "question": "In which reaction is energy absorbed from the surroundings?",
        "options": [
            "Condensation",
            "Freezing",
            "Evaporation",
            "Combustion"
        ],
       correct: "Evaporation"
    },
    {
        "question": "What occurs during an exothermic reaction?",
        "options": [
            "Energy is released",
            "Energy is absorbed",
            "Energy remains constant",
            "Energy is converted into mass"
        ],
       correct: "Energy is released"
    },
    {
        "question": "Which of the following is not an example of an endothermic process?",
        "options": [
            "Boiling water",
            "Photosynthesis",
            "Dissolving sugar in water",
            "Condensation"
        ],
       correct: "Condensation"
    },
    {
        "question": "What type of reaction is the formation of a chemical bond in a molecule?",
        "options": [
            "Exothermic",
            "Endothermic",
            "Neutral",
            "Catalytic"
        ],
       correct: "Exothermic"
    },
    {
        "question": "Which of the following reactions is endothermic?",
        "options": [
            "Burning of natural gas",
            "Combustion of propane",
            "Ice melting",
            "Rusting of iron"
        ],
       correct: "Ice melting"
    },
    {
        "question": "Which of the following describes an exothermic reaction?",
        "options": [
            "Absorbs energy",
            "Releases energy",
            "No energy change",
            "Requires constant energy input"
        ],
       correct: "Releases energy"
    },
    {
        "question": "What happens to the temperature of the surroundings during the process of photosynthesis?",
        "options": [
            "The temperature increases",
            "The temperature decreases",
            "The temperature stays the same",
            "The temperature fluctuates"
        ],
       correct: "The temperature decreases"
    },
    {
        "question": "Which of the following reactions releases heat energy?",
        "options": [
            "Baking soda reacting with vinegar",
            "Ice melting",
            "Water evaporating",
            "Combustion of methane"
        ],
       correct: "Combustion of methane"
    },
    {
        "question": "What type of reaction is the dissolving of ammonium nitrate in water?",
        "options": [
            "Exothermic",
            "Endothermic",
            "Neutral",
            "Precipitation"
        ],
       correct: "Endothermic"
    },
    {
        "question": "What is the primary characteristic of an exothermic reaction?",
        "options": [
            "Heat is absorbed",
            "Heat is released",
            "Energy is constant",
            "Temperature does not change"
        ],
       correct: "Heat is released"
    },
    {
        "question": "Which reaction is endothermic?",
        "options": [
            "Burning of wood",
            "Condensation of steam",
            "Boiling of water",
            "Freezing of water"
        ],
       correct: "Boiling of water"
    },
    {
        "question": "Which of the following describes the process of ice melting?",
        "options": [
            "Exothermic reaction",
            "Endothermic reaction",
            "Neither",
            "Spontaneous reaction"
        ],
       correct: "Endothermic reaction"
    },
    {
        "question": "Which of the following best describes an exothermic reaction?",
        "options": [
            "Absorbs heat from the surroundings",
            "Releases heat to the surroundings",
            "Does not involve energy changes",
            "Requires constant heat input"
        ],
       correct: "Releases heat to the surroundings"
    },
    {
        "question": "What is a displacement reaction?",
        "options": [
            "A reaction where two compounds exchange ions",
            "A reaction where a more reactive element displaces a less reactive element from its compound",
            "A reaction where two elements combine to form a compound",
            "A reaction where a compound breaks into simpler substances"
        ],
       correct: "A reaction where a more reactive element displaces a less reactive element from its compound"
    },
    {
        "question": "Which of the following is an example of a displacement reaction?",
        "options": [
            "Zn + CuSO₄ → ZnSO₄ + Cu",
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "H₂ + O₂ → H₂O",
            "CaO + H₂O → Ca(OH)₂"
        ],
       correct: "Zn + CuSO₄ → ZnSO₄ + Cu"
    },
    {
        "question": "In a displacement reaction, which element is typically displaced?",
        "options": [
            "The less reactive element",
            "The more reactive element",
            "Both elements",
            "Neither element"
        ],
       correct: "The less reactive element"
    },
    {
        "question": "What is a double displacement reaction?",
        "options": [
            "A reaction where two elements exchange places",
            "A reaction where two compounds exchange ions to form new compounds",
            "A reaction where one compound breaks down into two simpler compounds",
            "A reaction where a more reactive element displaces a less reactive one"
        ],
       correct: "A reaction where two compounds exchange ions to form new compounds"
    },
    {
        "question": "Which of the following is an example of a double displacement reaction?",
        "options": [
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "Cu + 2AgNO₃ → Cu(NO₃)₂ + 2Ag",
            "H₂ + O₂ → H₂O",
            "Na + Cl₂ → NaCl"
        ],
       correct: "NaCl + AgNO₃ → NaNO₃ + AgCl"
    },
    {
        "question": "In a double displacement reaction, which particles are exchanged?",
        "options": [
            "Cations and anions",
            "Two elements",
            "Molecules",
            "Electrons"
        ],
       correct: "Cations and anions"
    },
    {
        "question": "What is formed during a double displacement reaction?",
        "options": [
            "A precipitate",
            "A gas",
            "A new element",
            "A compound"
        ],
       correct: "A precipitate"
    },
    {
        "question": "Which of the following compounds is formed in the double displacement reaction: AgNO₃ + NaCl → AgCl + NaNO₃?",
        "options": [
            "Silver chloride (AgCl)",
            "Silver nitrate (AgNO₃)",
            "Sodium nitrate (NaNO₃)",
            "Sodium chloride (NaCl)"
        ],
       correct: "Silver chloride (AgCl)"
    },
    {
        "question": "Which of the following is a characteristic of a displacement reaction?",
        "options": [
            "The exchange of ions between two compounds",
            "One element replaces another in a compound",
            "Two elements react to form a compound",
            "Formation of a gas as a product"
        ],
       correct: "One element replaces another in a compound"
    },
    {
        "question": "Which reaction occurs in the following: Zn + CuSO₄ → ZnSO₄ + Cu?",
        "options": [
            "Double displacement",
            "Combination",
            "Displacement",
            "Decomposition"
        ],
       correct: "Displacement"
    },
    {
        "question": "What happens in a double displacement reaction when two ionic compounds react?",
        "options": [
            "They form a solid precipitate",
            "They combine to form a gas",
            "They release heat",
            "They decompose into their elements"
        ],
       correct: "They form a solid precipitate"
    },
    {
        "question": "Which of the following is true about displacement reactions?",
        "options": [
            "The more reactive element replaces a less reactive element in a compound",
            "The ions in two compounds switch places to form new compounds",
            "Both reactants combine to form one product",
            "Two compounds exchange electrons"
        ],
       correct: "The more reactive element replaces a less reactive element in a compound"
    },
    {
        "question": "Which is a common product of a double displacement reaction?",
        "options": [
            "Water",
            "Gas",
            "Precipitate",
            "Oxygen"
        ],
       correct: "Precipitate"
    },
    {
        "question": "What is the main difference between a displacement and a double displacement reaction?",
        "options": [
            "Displacement involves the formation of a precipitate, while double displacement does not",
            "In displacement, one element replaces another in a compound, while in double displacement, two compounds exchange ions",
            "Displacement reactions do not release energy, while double displacement does",
            "There is no difference between the two"
        ],
       correct: "In displacement, one element replaces another in a compound, while in double displacement, two compounds exchange ions"
    },
    {
        "question": "Which reaction occurs when sodium chloride reacts with silver nitrate?",
        "options": [
            "Displacement reaction",
            "Double displacement reaction",
            "Decomposition reaction",
            "Synthesis reaction"
        ],
       correct: "Double displacement reaction"
    },
    {
        "question": "In a double displacement reaction, what is typically formed when one of the products is insoluble?",
        "options": [
            "A gas",
            "A precipitate",
            "A liquid",
            "A new ionic compound"
        ],
       correct: "A precipitate"
    },
    {
        "question": "What happens to the ions during a double displacement reaction?",
        "options": [
            "They stay in their original compounds",
            "They switch places to form new compounds",
            "They combine with electrons",
            "They remain unchanged"
        ],
       correct: "They switch places to form new compounds"
    },
    {
        "question": "Which of the following reactions is an example of a double displacement reaction?",
        "options": [
            "Fe + CuSO₄ → FeSO₄ + Cu",
            "H₂ + Cl₂ → 2HCl",
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "C + O₂ → CO₂"
        ],
       correct: "NaCl + AgNO₃ → NaNO₃ + AgCl"
    },
    {
        "question": "Which of the following best describes a displacement reaction?",
        "options": [
            "Two elements combine to form a new compound",
            "A more reactive element replaces a less reactive element in a compound",
            "Two ionic compounds exchange their ions",
            "A compound breaks down into simpler compounds"
        ],
       correct: "A more reactive element replaces a less reactive element in a compound"
    },
    {
        "question": "Which of the following is an example of a displacement reaction?",
        "options": [
            "Zn + CuSO₄ → ZnSO₄ + Cu",
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "H₂ + O₂ → H₂O",
            "CaO + H₂O → Ca(OH)₂"
        ],
       correct: "Zn + CuSO₄ → ZnSO₄ + Cu"
    },
    {
        "question": "What is the driving force in a displacement reaction?",
        "options": [
            "Formation of a precipitate",
            "Release of energy",
            "A more reactive element displacing a less reactive element",
            "Absorption of heat"
        ],
       correct: "A more reactive element displacing a less reactive element"
    },
    {
        "question": "In the reaction Zn + CuSO₄ → ZnSO₄ + Cu, which element undergoes displacement?",
        "options": [
            "Zn displaces Cu",
            "Cu displaces Zn",
            "CuSO₄ displaces ZnSO₄",
            "None of the above"
        ],
       correct: "Zn displaces Cu"
    },
    {
        "question": "Which reaction is an example of a double displacement reaction?",
        "options": [
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "Fe + CuSO₄ → FeSO₄ + Cu",
            "H₂ + O₂ → H₂O",
            "Na + Cl₂ → NaCl"
        ],
       correct: "NaCl + AgNO₃ → NaNO₃ + AgCl"
    },
    {
        "question": "In a double displacement reaction, which ions typically exchange places?",
        "options": [
            "Cations",
            "Anions",
            "Both cations and anions",
            "Electrons"
        ],
       correct: "Both cations and anions"
    },
    {
        "question": "In the reaction NaCl + AgNO₃ → NaNO₃ + AgCl, what type of product is formed?",
        "options": [
            "A gas",
            "A precipitate",
            "A liquid",
            "A new compound"
        ],
       correct: "A precipitate"
    },
    {
        "question": "Which of the following is true for displacement reactions?",
        "options": [
            "Two compounds exchange their ions",
            "A more reactive element displaces a less reactive element",
            "Two elements combine to form a compound",
            "The reaction occurs only in the presence of heat"
        ],
       correct: "A more reactive element displaces a less reactive element"
    },

    // Balancing Chemical Equations
    {
        "question": "What is the first step in balancing a chemical equation?",
        "options": [
            "Count the number of atoms of each element",
            "Write the products and reactants",
            "Balance the oxygen atoms",
            "Balance the hydrogen atoms"
        ],
       correct: "Count the number of atoms of each element"
    },
    {
        "question": "What is the balanced form of the equation: C₄H₁₀ + O₂ → CO₂ + H₂O?",
        "options": [
            "2C₄H₁₀ + 13O₂ → 8CO₂ + 10H₂O",
            "C₄H₁₀ + 5O₂ → 4CO₂ + 2H₂O",
            "C₄H₁₀ + 2O₂ → 4CO₂ + H₂O",
            "C₄H₁₀ + 6O₂ → 4CO₂ + 4H₂O"
        ],
       correct: "2C₄H₁₀ + 13O₂ → 8CO₂ + 10H₂O"
    },
    {
        "question": "What is the balanced form of the equation: N₂ + H₂ → NH₃?",
        "options": [
            "N₂ + 3H₂ → 2NH₃",
            "N₂ + 2H₂ → NH₃",
            "2N₂ + 3H₂ → 2NH₃",
            "N₂ + H₂ → NH₃"
        ],
       correct: "N₂ + 3H₂ → 2NH₃"
    },
    {
        "question": "What is the correct balanced equation for the combustion of methane (CH₄)?",
        "options": [
            "CH₄ + 2O₂ → CO₂ + 2H₂O",
            "CH₄ + O₂ → CO₂ + H₂O",
            "CH₄ + 3O₂ → CO₂ + 2H₂O",
            "CH₄ + 4O₂ → 2CO₂ + 2H₂O"
        ],
       correct: "CH₄ + 2O₂ → CO₂ + 2H₂O"
    },
    {
        "question": "In balancing a chemical equation, what must be conserved?",
        "options": [
            "Mass and charge",
            "Energy",
            "Electrons only",
            "Only the atoms on the reactant side"
        ],
       correct: "Mass and charge"
    },
    {
        "question": "What is the balanced equation for the reaction of sodium with water?",
        "options": [
            "2Na + 2H₂O → 2NaOH + H₂",
            "2Na + H₂O → 2NaOH + H₂",
            "Na + 2H₂O → NaOH + H₂",
            "Na + H₂O → NaOH + H₂"
        ],
       correct: "2Na + 2H₂O → 2NaOH + H₂"
    },

    // Combination and Decomposition Reactions
    {
        "question": "Which of the following reactions is an example of a combination reaction?",
        "options": [
            "2Na + Cl₂ → 2NaCl",
            "CaCO₃ → CaO + CO₂",
            "H₂O → H₂ + O₂",
            "C + O₂ → CO₂"
        ],
       correct: "2Na + Cl₂ → 2NaCl"
    },
    {
        "question": "Which of the following is a characteristic of a decomposition reaction?",
        "options": [
            "Two reactants combine to form one product",
            "One reactant breaks into two or more products",
            "Two ionic compounds exchange their ions",
            "A more reactive element displaces a less reactive element"
        ],
       correct: "One reactant breaks into two or more products"
    },
    {
        "question": "What is the product of the decomposition of potassium chlorate (2KClO₃)?",
        "options": [
            "KCl + O₂",
            "KClO₄ + O₂",
            "KCl + Cl₂",
            "K + Cl₂"
        ],
       correct: "KCl + O₂"
    },
    {
        "question": "Which reaction represents a combination reaction?",
        "options": [
            "H₂ + O₂ → H₂O",
            "2Na + Cl₂ → 2NaCl",
            "CaO + H₂O → Ca(OH)₂",
            "C + O₂ → CO₂"
        ],
       correct: "H₂ + O₂ → H₂O"
    },
    {
        "question": "Which of the following is the decomposition reaction of water?",
        "options": [
            "2H₂O → 2H₂ + O₂",
            "H₂O → H₂O₂",
            "H₂ + O₂ → H₂O",
            "2H₂O → 2H₂ + O"
        ],
       correct: "2H₂O → 2H₂ + O₂"
    },
    {
        "question": "What is formed when calcium carbonate (CaCO₃) undergoes thermal decomposition?",
        "options": [
            "CaO + CO₂",
            "CaCl₂ + O₂",
            "CaO + O₂",
            "Ca + CO₂"
        ],
       correct: "CaO + CO₂"
    },
    {
        "question": "Which of the following is a combination reaction?",
        "options": [
            "CaO + H₂O → Ca(OH)₂",
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "CaCO₃ → CaO + CO₂",
            "2H₂O → 2H₂ + O₂"
        ],
       correct: "CaO + H₂O → Ca(OH)₂"
    },
    {
        "question": "In a displacement reaction, what happens when a less reactive element is placed in a compound?",
        "options": [
            "No reaction occurs",
            "A new compound is formed",
            "The more reactive element displaces the less reactive one",
            "The less reactive element displaces the more reactive one"
        ],
       correct: "No reaction occurs"
    },
    {
        "question": "Which reaction is an example of a displacement reaction between a metal and an acid?",
        "options": [
            "Zn + HCl → ZnCl₂ + H₂",
            "NaOH + HCl → NaCl + H₂O",
            "Fe + O₂ → Fe₂O₃",
            "CuSO₄ + NaCl → Na₂SO₄ + CuCl₂"
        ],
       correct: "Zn + HCl → ZnCl₂ + H₂"
    },
    {
        "question": "What happens during a double displacement reaction?",
        "options": [
            "Two compounds exchange their ions to form two new compounds",
            "One element replaces another in a compound",
            "One element combines with another element to form a compound",
            "A compound decomposes into two or more elements"
        ],
       correct: "Two compounds exchange their ions to form two new compounds"
    },
    {
        "question": "Which of the following reactions represents a double displacement reaction that produces a precipitate?",
        "options": [
            "NaCl + AgNO₃ → NaNO₃ + AgCl",
            "H₂ + O₂ → H₂O",
            "Fe + CuSO₄ → FeSO₄ + Cu",
            "HCl + NaOH → NaCl + H₂O"
        ],
       correct: "NaCl + AgNO₃ → NaNO₃ + AgCl"
    },
    {
        "question": "Which element is displaced in the reaction: Fe + CuSO₄ → FeSO₄ + Cu?",
        "options": [
            "Iron displaces copper",
            "Copper displaces iron",
            "Iron displaces sulfate",
            "Copper displaces sulfate"
        ],
       correct: "Iron displaces copper"
    },

    // Balancing Chemical Equations
    {
        "question": "When balancing a chemical equation, what should be adjusted?",
        "options": [
            "The coefficients of each compound",
            "The subscripts of the chemical formulas",
            "The reactants only",
            "The number of atoms on the product side"
        ],
       correct: "The coefficients of each compound"
    },
    {
        "question": "What is the balanced form of the equation: C₆H₁₂ + O₂ → CO₂ + H₂O?",
        "options": [
            "C₆H₁₂ + 9O₂ → 6CO₂ + 6H₂O",
            "C₆H₁₂ + 6O₂ → 6CO₂ + 6H₂O",
            "C₆H₁₂ + 6O₂ → CO₂ + H₂O",
            "C₆H₁₂ + 3O₂ → CO₂ + H₂O"
        ],
       correct: "C₆H₁₂ + 9O₂ → 6CO₂ + 6H₂O"
    },
    {
        "question": "Which equation represents a properly balanced combustion reaction?",
        "options": [
            "C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O",
            "C₈H₁₈ + 12O₂ → 8CO₂ + 9H₂O",
            "C₈H₁₈ + 8O₂ → 4CO₂ + 4H₂O",
            "C₈H₁₈ + 16O₂ → 10CO₂ + 12H₂O"
        ],
       correct: "C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O"
    },
    {
        "question": "Which of the following is an incorrect method for balancing chemical equations?",
        "options": [
            "Adjust the coefficients of compounds",
            "Change the subscripts of chemical formulas",
            "Start with the most complex molecules",
            "Balance hydrogen and oxygen atoms last"
        ],
       correct: "Change the subscripts of chemical formulas"
    },
    {
        "question": "What is the balanced form of the equation: Na + Cl₂ → NaCl?",
        "options": [
            "2Na + Cl₂ → 2NaCl",
            "Na + Cl₂ → NaCl",
            "Na + 2Cl₂ → 2NaCl",
            "2Na + 2Cl₂ → 2NaCl"
        ],
       correct: "2Na + Cl₂ → 2NaCl"
    },

    // Combination and Decomposition Reactions
    {
        "question": "Which of the following is an example of a combination reaction?",
        "options": [
            "2H₂ + O₂ → 2H₂O",
            "CaCO₃ → CaO + CO₂",
            "H₂O₂ → H₂O + O₂",
            "N₂ + 3H₂ → 2NH₃"
        ],
       correct: "2H₂ + O₂ → 2H₂O"
    },
    {
        "question": "What is the product of the decomposition of water?",
        "options": [
            "H₂O₂",
            "H₂ + O₂",
            "H₂O",
            "O₂"
        ],
       correct: "H₂ + O₂"
    },
    {
        "question": "Which compound undergoes decomposition in the reaction: 2NaClO₃ → 2NaCl + 3O₂?",
        "options": [
            "Sodium chloride",
            "Sodium chlorate",
            "Oxygen",
            "Sodium oxide"
        ],
       correct: "Sodium chlorate"
    },
    {
        "question": "What type of reaction is represented by: 2KClO₃ → 2KCl + 3O₂?",
        "options": [
            "Combination reaction",
            "Decomposition reaction",
            "Single displacement reaction",
            "Double displacement reaction"
        ],
       correct: "Decomposition reaction"
    },
    {
        "question": "Which of the following is a characteristic of a combination reaction?",
        "options": [
            "Two reactants combine to form a single product",
            "One compound decomposes into two or more products",
            "Two compounds exchange their ions",
            "A single compound undergoes displacement"
        ],
       correct: "Two reactants combine to form a single product"
    },
    {
        "question": "What is the result of the reaction: CaO + H₂O → Ca(OH)₂?",
        "options": [
            "Formation of an acid",
            "Formation of a base",
            "Formation of a salt",
            "Formation of a precipitate"
        ],
       correct: "Formation of a base"
    },
    {
        "question": "Which of the following is an example of a decomposition reaction?",
        "options": [
            "CaCO₃ → CaO + CO₂",
            "Na + Cl₂ → NaCl",
            "2H₂ + O₂ → 2H₂O",
            "H₂O₂ → H₂O + O₂"
        ],
       correct: "CaCO₃ → CaO + CO₂"
    }
];
