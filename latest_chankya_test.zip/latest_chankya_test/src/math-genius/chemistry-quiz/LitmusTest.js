import React, { useState } from "react";
import "./LitmusTest.css";
import LitmusQuiz from './LitmusQuiz';

const LitmusTest = () => {
  const [redLitmusColor, setRedLitmusColor] = useState("red");
  const [blueLitmusColor, setBlueLitmusColor] = useState("blue");
  const [purpleLitmusColor, setPurpleLitmusColor] = useState("purple");

  const testLitmus = (paper, pH) => {
    if (paper === "red") {
      setRedLitmusColor(
        pH < 4.5 ? "darkred" : pH > 7 ? "blue" : "#800080"
      );
    } else if (paper === "blue") {
      setBlueLitmusColor(
        pH < 7 ? "rgb(255, 0, 0)" : pH > 8.3 ? "darkblue" : "blue"
      );
    } else if (paper === "purple") {
      setPurpleLitmusColor(
        pH < 7 ? "red" : pH > 7 ? "blue" : "purple"
      );
    }
  };

  return (
    <div className="litmus-test">
      <h1>Litmus Paper Test</h1>
      <div className="litmus-container">
        <div
          className="litmus-paper"
          style={{ backgroundColor: redLitmusColor }}
        >
          <p style={{color : 'white'}} >Red Litmus Paper</p>
          <button onClick={() => testLitmus("red", 3)}>Dip in pH 3</button>
          <button onClick={() => testLitmus("red", 7)}>Dip in pH 7</button>
          <button onClick={() => testLitmus("red", 9)}>Dip in pH 9</button>
        </div>
        <div
          className="litmus-paper"
          style={{ backgroundColor: blueLitmusColor }}
        >
          <p style={{color : 'white'}}>Blue Litmus Paper</p>
          <button onClick={() => testLitmus("blue", 3)}>Dip in pH 3</button>
          <button onClick={() => testLitmus("blue", 7)}>Dip in pH 7</button>
          <button onClick={() => testLitmus("blue", 9)}>Dip in pH 9</button>
        </div>
        <div
          className="litmus-paper"
          style={{ backgroundColor: purpleLitmusColor }}
        >
          <p style={{color : 'white'}}>Purple Litmus Paper</p>
          <button onClick={() => testLitmus("purple", 3)}>Dip in pH 3</button>
          <button onClick={() => testLitmus("purple", 7)}>Dip in pH 7</button>
          <button onClick={() => testLitmus("purple", 9)}>Dip in pH 9</button>
        </div>
      </div>
      <LitmusQuiz />
    </div>
  );
};

export default LitmusTest;
