import React, { useState, useEffect } from 'react';
import './PhysicalAndChemicalChanges.css';
import PhysicalAndChemicalChangesQuiz from './PhysicalAndChemicalChangesQuiz';
const PhysicalAndChemicalChanges = () => {
  const [changeType, setChangeType] = useState(null); // null, 'physical', 'chemical'

  const startPhysicalChange = () => setChangeType('physical');
  const startChemicalChange = () => setChangeType('chemical');

  useEffect(() => {
    if (changeType) {
      setTimeout(() => setChangeType(null), 5000); // Reset after 5 seconds
    }
  }, [changeType]);

  return (
    <div className="change-container">
      <h2>Physical and Chemical Changes</h2>

      <div className="change-info">
        <button onClick={startPhysicalChange} className="start-button">Start Physical Change</button>
        <button onClick={startChemicalChange} className="start-button">Start Chemical Change</button>
      </div>

      <div className="changes">
        {/* Physical Change Animation */}
        {changeType === 'physical' && (
          <div className="physical-change" style={{ animation: 'changeShape 3s forwards' }}>
            Ice
          </div>
        )}

        {/* Chemical Change Animation */}
        {changeType === 'chemical' && (
          <div className="chemical-change">
            <div className="substance1" style={{ animation: 'moveSubstances 3s forwards' }}>Liquid A</div>
            <div className="substance2" style={{ animation: 'moveSubstances 3s forwards 1s' }}>Liquid B</div>
            <div className="product" style={{ animation: 'formProduct 3s forwards 2s' }}>Gas</div>
          </div>
        )}
      </div>
      <PhysicalAndChemicalChangesQuiz />
    </div>
  );
};

export default PhysicalAndChemicalChanges;
