import React from "react";
import { motion } from "framer-motion";
import ReactionTypesTwo from './ReactionTypesTwo';
const ReactionTypes = () => {
  const energyVariants = {
    initial: { opacity: 0, scale: 0.5 },
    animate: { opacity: 1, scale: 1, transition: { duration: 1 } },
    exit: { opacity: 0, scale: 0.5, transition: { duration: 1 } },
  };

  const heatArrowVariants = {
    initial: { opacity: 0, x: -50 },
    animate: { opacity: 1, x: 0, transition: { duration: 1 } },
    exit: { opacity: 0, x: -50, transition: { duration: 1 } },
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Chemical Reactions: Exothermic vs Endothermic</h1>

      {/* Exothermic Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Exothermic Reaction</h2>
        <p>
          Exothermic reactions release energy, usually in the form of heat or
          light. Examples include combustion, neutralization, and the reaction
          between water and calcium oxide.
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Example: CH₄ + 2O₂ → CO₂ + 2H₂O + Energy (Heat)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0",
            position: "relative",
          }}
        >
          {/* Reactants */}
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            CH₄
          </motion.div>
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#6EC2F0",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            O₂
          </motion.div>

          {/* Energy Arrow */}
          <motion.div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              color: "#FFD700",
              fontWeight: "bold",
              fontSize: "1.2rem",
            }}
            variants={heatArrowVariants}
            initial="initial"
            animate="animate"
          >
            🔥 Energy Released
          </motion.div>
        </motion.div>
      </div>

      {/* Endothermic Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Endothermic Reaction</h2>
        <p>
          Endothermic reactions absorb heat from their surroundings to produce
          products. Examples include boiling water and photosynthesis.
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Example: H₂O (liquid) + Heat → H₂O (gas)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0",
            position: "relative",
          }}
        >
          {/* Reactants */}
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            H₂O (liquid)
          </motion.div>

          {/* Energy Arrow */}
          <motion.div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              color: "#FF6F61",
              fontWeight: "bold",
              fontSize: "1.2rem",
            }}
            variants={heatArrowVariants}
            initial="initial"
            animate="animate"
          >
            🌡️ Heat Absorbed
          </motion.div>
        </motion.div>
        <ReactionTypesTwo />
      </div>
    </div>
  );
};

export default ReactionTypes;
