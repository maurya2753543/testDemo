import React, { useState } from "react";
import { motion } from "framer-motion";
import ChemicalBondingQuiz from './ChemicalBondingQuiz';

const ChemicalBonding = () => {
  const [bondType, setBondType] = useState(""); // Tracks the selected bond type

  // Styles for atoms
  const atomStyles = {
    width: 50,
    height: 50,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
    fontWeight: "bold",
    position: "absolute",
  };

  const renderBondLines = () => {
    if (bondType === "H2O") {
      return (
        <>
          {/* Bonds */}
          <line
            x1="200" // Hydrogen 1 center x
            y1="200" // Hydrogen 1 center y
            x2="300" // Oxygen center x
            y2="200" // Oxygen center y
            stroke="black"
            strokeWidth="2"
          />
          <line
            x1="400" // Hydrogen 2 center x
            y1="200" // Hydrogen 2 center y
            x2="300" // Oxygen center x
            y2="200" // Oxygen center y
            stroke="black"
            strokeWidth="2"
          />
        </>
      );
    } else if (bondType === "HCl") {
      return (
        <line
          x1="200" // Hydrogen center x
          y1="200" // Hydrogen center y
          x2="400" // Chlorine center x
          y2="200" // Chlorine center y
          stroke="black"
          strokeWidth="2"
        />
      );
    } else if (bondType === "H2SO4") {
      return (
        <>
          {/* Bonds */}
          <line
            x1="300" // Sulfur center x
            y1="200" // Sulfur center y
            x2="200" // Oxygen 1 center x
            y2="100" // Oxygen 1 center y
            stroke="black"
            strokeWidth="2"
          />
          <line
            x1="300" // Sulfur center x
            y1="200" // Sulfur center y
            x2="400" // Oxygen 2 center x
            y2="100" // Oxygen 2 center y
            stroke="black"
            strokeWidth="2"
          />
        </>
      );
    }
    return null;
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center" }}>Chemical Bonding Animation</h1>

      {/* Buttons for different bonds */}
      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <button
          onClick={() => setBondType("H2O")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#3498db",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          H₂O Bond
        </button>
        <button
          onClick={() => setBondType("HCl")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#e74c3c",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          HCl Bond
        </button>
        <button
          onClick={() => setBondType("H2SO4")}
          style={{
            margin: "0 10px",
            padding: "10px 20px",
            backgroundColor: "#2ecc71",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          H₂SO₄ Bond
        </button>
      </div>

      {/* Dynamic bond animations */}
      <div style={{ position: "relative", height: "400px", width: "100%", background: "#f0f0f0", overflow: "hidden" }}>
        <svg width="100%" height="400">
          {renderBondLines()}
        </svg>

        {/* Atoms */}
        {bondType === "H2O" && (
          <>
            {/* Hydrogen Atoms */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "200px", top: "200px" }}
            >
              H
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "400px", top: "200px" }}
            >
              H
            </motion.div>

            {/* Oxygen Atom */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#e74c3c",
                left: "300px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              O
            </div>
          </>
        )}

        {bondType === "HCl" && (
          <>
            {/* Hydrogen Atom */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#3498db", left: "200px", top: "200px" }}
            >
              H
            </motion.div>

            {/* Chlorine Atom */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#e74c3c",
                left: "400px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              Cl
            </div>
          </>
        )}

        {bondType === "H2SO4" && (
          <>
            {/* Sulfur Atom */}
            <div
              style={{
                ...atomStyles,
                backgroundColor: "#f1c40f",
                left: "300px",
                top: "200px",
                transform: "translate(-50%, -50%)",
              }}
            >
              S
            </div>

            {/* Oxygen Atoms */}
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#e74c3c", left: "200px", top: "100px" }}
            >
              O
            </motion.div>
            <motion.div
              style={{ ...atomStyles, backgroundColor: "#e74c3c", left: "400px", top: "100px" }}
            >
              O
            </motion.div>
          </>
        )}
      </div>
      <ChemicalBondingQuiz />
    </div>
  );
};

export default ChemicalBonding;
