import React from "react";
import { motion } from "framer-motion";
import ReactionTypes from './ReactionTypes';
import ChemicalReactionQuiz from './ChemicalReactionQuiz';
const ChemicalReaction = () => {
  // Variants for animation
  const reactantVariant = {
    initial: { opacity: 0, y: -50 },
    animate: { opacity: 1, y: 0, transition: { duration: 1 } },
    exit: { opacity: 0, y: 50, transition: { duration: 1 } }
  };

  const productVariant = {
    initial: { opacity: 0, scale: 0.5 },
    animate: { opacity: 1, scale: 1, transition: { duration: 1 } },
    exit: { opacity: 0, scale: 0.5, transition: { duration: 1 } }
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Chemical Reactions</h1>

      {/* Combination Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Combination Reaction</h2>
        <p>
          A combination reaction occurs when two or more reactants unite to
          form a single product. Example:
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Magnesium Oxide (MgO) + Carbon Dioxide (CO₂) → Magnesium Carbonate
          (MgCO₃)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0"
          }}
        >
          <motion.div
            style={{
              width: "100px",
              height: "100px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={reactantVariant}
            initial="initial"
            animate="animate"
          >
            MgO
          </motion.div>

          <motion.div
            style={{
              width: "100px",
              height: "100px",
              backgroundColor: "#6EC2F0",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={reactantVariant}
            initial="initial"
            animate="animate"
          >
            CO₂
          </motion.div>

          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FFD700",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={productVariant}
            initial="initial"
            animate="animate"
          >
            MgCO₃
          </motion.div>
        </motion.div>
      </div>

      {/* Decomposition Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Decomposition Reaction</h2>
        <p>
          A decomposition reaction occurs when a single compound breaks down
          into two or more components. Example:
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Water (H₂O) → Hydrogen (H₂) + Oxygen (O₂)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0"
          }}
        >
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FFD700",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={productVariant}
            initial="initial"
            animate="animate"
          >
            H₂O
          </motion.div>

          <motion.div
            style={{
              width: "100px",
              height: "100px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={reactantVariant}
            initial="initial"
            animate="animate"
          >
            H₂
          </motion.div>

          <motion.div
            style={{
              width: "100px",
              height: "100px",
              backgroundColor: "#6EC2F0",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold"
            }}
            variants={reactantVariant}
            initial="initial"
            animate="animate"
          >
            O₂
          </motion.div>
        </motion.div>
        <ReactionTypes />

      </div>
           <ChemicalReactionQuiz />

    </div>
  );
};

export default ChemicalReaction;
