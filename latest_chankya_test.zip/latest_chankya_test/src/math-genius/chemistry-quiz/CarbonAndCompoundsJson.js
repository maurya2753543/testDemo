export const quizQuestions = [
    {
      "question": "What is the chemical formula of methane?",
      "options": [
        "CH4",
        "C2H6",
        "CO2",
        "C6H12O6"
      ],
      correct: "CH4"
    },
    {
      "question": "Which of the following is a characteristic of carbon compounds?",
      "options": [
        "They are always ionic",
        "They can form covalent bonds",
        "They are always gases",
        "They do not contain hydrogen"
      ],
      correct: "They can form covalent bonds"
    },
    {
      "question": "Which of the following is an example of a carbon compound?",
      "options": [
        "Water",
        "Sodium chloride",
        "Methane",
        "Oxygen"
      ],
      correct: "Methane"
    },
    {
      "question": "What is the bonding type in carbon compounds like methane (CH4)?",
      "options": [
        "Ionic Bond",
        "Covalent Bond",
        "Metallic Bond",
        "Hydrogen Bond"
      ],
      correct: "Covalent Bond"
    },
    {
      "question": "What is the main characteristic of hydrocarbons?",
      "options": [
        "They only contain carbon",
        "They contain carbon and hydrogen",
        "They are water-soluble",
        "They contain oxygen and nitrogen"
      ],
      correct: "They contain carbon and hydrogen"
    },
    {
      "question": "Which of the following is a property of carbon atoms?",
      "options": [
        "They can form 2 covalent bonds",
        "They can form 4 covalent bonds",
        "They can only bond with hydrogen",
        "They can only bond with oxygen"
      ],
      correct: "They can form 4 covalent bonds"
    },
    {
      "question": "What is the general formula of alkanes?",
      "options": [
        "CnH2n+2",
        "CnH2n",
        "CnH2n-2",
        "CnH2n+1"
      ],
      correct: "CnH2n+2"
    },
    {
      "question": "Which allotrope of carbon is used as a lubricant?",
      "options": [
        "Diamond",
        "Graphite",
        "Fullerene",
        "Coal"
      ],
      correct: "Graphite"
    },
    {
      "question": "What type of bond is present in ethene (C2H4)?",
      "options": [
        "Single bond",
        "Double bond",
        "Triple bond",
        "Ionic bond"
      ],
      correct: "Double bond"
    },
    {
      "question": "Which functional group is present in alcohols?",
      "options": [
        "-COOH",
        "-OH",
        "-CHO",
        "-C=O"
      ],
      correct: "-OH"
    },
    {
      "question": "What is the main component of natural gas?",
      "options": [
        "Ethane",
        "Propane",
        "Methane",
        "Butane"
      ],
      correct: "Methane"
    },
    {
      "question": "Which of the following is a saturated hydrocarbon?",
      "options": [
        "Ethene",
        "Ethyne",
        "Methane",
        "Benzene"
      ],
      correct: "Methane"
    },
    {
      "question": "What is the name of the compound with the formula CH3COOH?",
      "options": [
        "Ethanol",
        "Acetic acid",
        "Methanoic acid",
        "Propanoic acid"
      ],
      correct: "Acetic acid"
    },
    {
      "question": "Which of the following compounds is aromatic?",
      "options": [
        "Ethene",
        "Ethyne",
        "Benzene",
        "Methanol"
      ],
      correct: "Benzene"
    },
    {
      "question": "What is the process of breaking down a large hydrocarbon molecule into smaller ones called?",
      "options": [
        "Cracking",
        "Polymerization",
        "Distillation",
        "Oxidation"
      ],
      correct: "Cracking"
    },
    {
      "question": "Which of the following is a test for unsaturation in hydrocarbons?",
      "options": [
        "Limewater test",
        "Bromine water test",
        "Flame test",
        "Silver nitrate test"
      ],
      correct: "Bromine water test"
    },
    {
      "question": "What is the structure of a benzene molecule?",
      "options": [
        "Straight chain",
        "Cyclic with single bonds",
        "Cyclic with alternating double bonds",
        "Cyclic with triple bonds"
      ],
      correct: "Cyclic with alternating double bonds"
    },
    {
      "question": "What is the name of the process used to make soaps?",
      "options": [
        "Esterification",
        "Saponification",
        "Neutralization",
        "Combustion"
      ],
      correct: "Saponification"
    },
    {
      "question": "Which of the following compounds can undergo addition reactions?",
      "options": [
        "Ethane",
        "Ethene",
        "Methane",
        "Propane"
      ],
      correct: "Ethene"
    },
    {
      "question": "What is the hybridization of carbon atoms in ethyne (C2H2)?",
      "options": [
        "sp3",
        "sp2",
        "sp",
        "None of the above"
      ],
      correct: "sp"
    },
    {
      "question": "What is the molecular formula of butane?",
      "options": [
        "C4H10",
        "C4H8",
        "C4H6",
        "C4H12"
      ],
      correct: "C4H10"
    },
    {
      "question": "Which of the following is an isomer of butane?",
      "options": [
        "Ethane",
        "Propane",
        "Isobutane",
        "Pentane"
      ],
      correct: "Isobutane"
    },
    {
      "question": "Which of the following is a property of diamond?",
      "options": [
        "Conducts electricity",
        "High melting point",
        "Soft and slippery",
        "Weak bonds"
      ],
      correct: "High melting point"
    },
    {
      "question": "Which reagent is used to oxidize ethanol to acetic acid?",
      "options": [
        "Bromine water",
        "Potassium dichromate",
        "Sodium hydroxide",
        "Hydrogen chloride"
      ],
      correct: "Potassium dichromate"
    },
    {
      "question": "What is the IUPAC name of CH3CH2OH?",
      "options": [
        "Methanol",
        "Ethanol",
        "Propanol",
        "Butanol"
      ],
      correct: "Ethanol"
    },
    {
      "question": "Which compound is formed when ethanol reacts with acetic acid?",
      "options": [
        "Acetaldehyde",
        "Acetone",
        "Ethyl acetate",
        "Methanol"
      ],
      correct: "Ethyl acetate"
    },
    {
      "question": "Which type of covalent bond is present in methane (CH4)?",
      "options": [
        "Single bond",
        "Double bond",
        "Triple bond",
        "Ionic bond"
      ],
      correct: "Single bond"
    },
    {
      "question": "What is the name of the simplest ketone?",
      "options": [
        "Methanol",
        "Ethanol",
        "Propanone",
        "Methanal"
      ],
      correct: "Propanone"
    },
    {
      "question": "Which compound is used as a dry cleaning solvent?",
      "options": [
        "Acetone",
        "Toluene",
        "Tetrachloromethane",
        "Methanol"
      ],
      correct: "Tetrachloromethane"
    },
    {
      "question": "What is the general formula of alkenes?",
      "options": [
        "CnH2n+2",
        "CnH2n",
        "CnH2n-2",
        "CnH2n+1"
      ],
      correct: "CnH2n"
    },
    {
      "question": "Which gas is evolved when sodium carbonate reacts with ethanoic acid?",
      "options": [
        "Hydrogen",
        "Carbon dioxide",
        "Oxygen",
        "Methane"
      ],
      correct: "Carbon dioxide"
    },
    {
      "question": "What is the molecular formula of benzene?",
      "options": [
        "C6H12",
        "C6H10",
        "C6H6",
        "C5H10"
      ],
      correct: "C6H6"
    },
    {
      "question": "Which of the following is a property of graphite?",
      "options": [
        "Hard",
        "Conducts electricity",
        "Non-lustrous",
        "Poor thermal conductor"
      ],
      correct: "Conducts electricity"
    },
    {
      "question": "Which of the following is used to detect the presence of carbon dioxide in a reaction?",
      "options": [
        "Litmus paper",
        "Limewater",
        "Bromine water",
        "Potassium dichromate"
      ],
      correct: "Limewater"
    },
    {
      "question": "Which compound is used in making alcoholic beverages?",
      "options": [
        "Methanol",
        "Ethanol",
        "Propanol",
        "Butanol"
      ],
      correct: "Ethanol"
    },
    {
      "question": "What is the hybridization of carbon in methane (CH4)?",
      "options": [
        "sp",
        "sp2",
        "sp3",
        "None of the above"
      ],
      correct: "sp3"
    },
    {
      "question": "What is the main product of the combustion of hydrocarbons?",
      "options": [
        "Carbon dioxide and water",
        "Carbon monoxide",
        "Methane",
        "Oxygen"
      ],
      correct: "Carbon dioxide and water"
    },
    {
      "question": "Which of the following is an unsaturated hydrocarbon?",
      "options": [
        "Methane",
        "Ethene",
        "Propane",
        "Butane"
      ],
      correct: "Ethene"
    },
    {
      "question": "What is the name of the process in which monomers combine to form polymers?",
      "options": [
        "Cracking",
        "Polymerization",
        "Hydrolysis",
        "Saponification"
      ],
      correct: "Polymerization"
    },
    {
      "question": "Which of the following compounds contains a triple bond?",
      "options": [
        "Ethene",
        "Ethyne",
        "Methane",
        "Propane"
      ],
      correct: "Ethyne"
    },
    {
      "question": "Which compound is formed when a carboxylic acid reacts with an alcohol?",
      "options": [
        "Ether",
        "Ester",
        "Ketone",
        "Aldehyde"
      ],
      correct: "Ester"
    },
    {
      "question": "Which of the following compounds has a functional group -CHO?",
      "options": [
        "Alcohol",
        "Carboxylic acid",
        "Aldehyde",
        "Ketone"
      ],
      correct: "Aldehyde"
    },
    {
      "question": "What is the molecular formula of ethene?",
      "options": [
        "C2H4",
        "C2H6",
        "C3H6",
        "C2H2"
      ],
      correct: "C2H4"
    },
    {
      "question": "What is the IUPAC name of acetylene?",
      "options": [
        "Ethene",
        "Ethyne",
        "Methyne",
        "Propene"
      ],
      correct: "Ethyne"
    },
    {
      "question": "Which gas is evolved when ethanol reacts with sodium?",
      "options": [
        "Carbon dioxide",
        "Oxygen",
        "Hydrogen",
        "Methane"
      ],
      correct: "Hydrogen"
    },
    {
      "question": "Which of the following compounds is used in the manufacture of perfumes?",
      "options": [
        "Esters",
        "Ketones",
        "Alcohols",
        "Aldehydes"
      ],
      correct: "Esters"
    },
    {
      "question": "Which type of isomerism is shown by butane and isobutane?",
      "options": [
        "Chain isomerism",
        "Position isomerism",
        "Functional isomerism",
        "Geometric isomerism"
      ],
      correct: "Chain isomerism"
    },
    {
      "question": "Which of the following is a saturated hydrocarbon?",
      "options": [
        "Ethene",
        "Propyne",
        "Methane",
        "Ethyne"
      ],
      correct: "Methane"
    },
    {
      "question": "What is the functional group present in carboxylic acids?",
      "options": [
        "-CO",
        "-CHO",
        "-COOH",
        "-OH"
      ],
      correct: "-COOH"
    },
    {
      "question": "Which compound is known as vinegar in daily life?",
      "options": [
        "Acetic acid",
        "Ethanol",
        "Methanol",
        "Propanoic acid"
      ],
      correct: "Acetic acid"
    },
    {
      "question": "What is the molecular formula of propane?",
      "options": [
        "C2H6",
        "C3H8",
        "C4H10",
        "C3H6"
      ],
      correct: "C3H8"
    },
    {
      "question": "What is the main use of acetylene (ethyne) gas?",
      "options": [
        "Fuel in vehicles",
        "Welding and cutting",
        "Solvent",
        "Perfume production"
      ],
      correct: "Welding and cutting"
    },
    {
      "question": "Which compound is formed when ethene reacts with hydrogen in the presence of a catalyst?",
      "options": [
        "Ethane",
        "Ethyne",
        "Methane",
        "Propene"
      ],
      correct: "Ethane"
    },
    {
      "question": "What is the IUPAC name of formaldehyde?",
      "options": [
        "Methanal",
        "Ethanol",
        "Propanone",
        "Acetaldehyde"
      ],
      correct: "Methanal"
    },
    {
      "question": "Which of the following is a property of diamond?",
      "options": [
        "Good conductor of electricity",
        "Soft and brittle",
        "Hardest natural substance",
        "Low melting point"
      ],
      correct: "Hardest natural substance"
    },
    {
      "question": "Which compound is used in soaps and detergents as a cleaning agent?",
      "options": [
        "Ester",
        "Sodium stearate",
        "Acetic acid",
        "Propanone"
      ],
      correct: "Sodium stearate"
    },
    {
      "question": "What is the general formula for alkynes?",
      "options": [
        "CnH2n",
        "CnH2n+2",
        "CnH2n-2",
        "CnH2n+1"
      ],
      correct: "CnH2n-2"
    },
    {
      "question": "Which of the following compounds does NOT contain carbon?",
      "options": [
        "Carbon dioxide",
        "Methane",
        "Sodium chloride",
        "Ethanol"
      ],
      correct: "Sodium chloride"
    },
    {
      "question": "What is the common name of trichloromethane?",
      "options": [
        "Formalin",
        "Chloroform",
        "Acetone",
        "Vinegar"
      ],
      correct: "Chloroform"
    },
    {
      "question": "Which process is used to break large hydrocarbon molecules into smaller ones?",
      "options": [
        "Polymerization",
        "Cracking",
        "Hydration",
        "Dehydration"
      ],
      correct: "Cracking"
    },
    {
      "question": "What is the shape of the methane molecule (CH4)?",
      "options": [
        "Linear",
        "Tetrahedral",
        "Trigonal planar",
        "Square planar"
      ],
      correct: "Tetrahedral"
    },
    {
      "question": "Which of the following is used in the preservation of biological specimens?",
      "options": [
        "Ethanol",
        "Formalin",
        "Propanone",
        "Glycerol"
      ],
      correct: "Formalin"
    },
    {
      "question": "What is the term for hydrocarbons containing only single bonds?",
      "options": [
        "Alkenes",
        "Alkynes",
        "Alkanes",
        "Arenes"
      ],
      correct: "Alkanes"
    },
    {
      "question": "What is the functional group in alcohols?",
      "options": [
        "-CO",
        "-OH",
        "-COOH",
        "-CHO"
      ],
      correct: "-OH"
    },
    {
      "question": "Which process converts an alcohol into an aldehyde?",
      "options": [
        "Hydrogenation",
        "Oxidation",
        "Reduction",
        "Dehydration"
      ],
      correct: "Oxidation"
    },
    {
      "question": "What is the product when ethanol is dehydrated in the presence of concentrated sulfuric acid?",
      "options": [
        "Ethene",
        "Ethanoic acid",
        "Methanol",
        "Ethanone"
      ],
      correct: "Ethene"
    },
    {
      "question": "What is the boiling point of ethanol?",
      "options": [
        "78°C",
        "100°C",
        "65°C",
        "50°C"
      ],
      correct: "78°C"
    },
    {
      "question": "Which property of ethanol makes it suitable as a solvent?",
      "options": [
        "High boiling point",
        "Miscibility with water",
        "Low melting point",
        "Odorous nature"
      ],
      correct: "Miscibility with water"
    },
    {
      "question": "What is the main functional group in ethanoic acid?",
      "options": [
        "Hydroxyl group (-OH)",
        "Carboxyl group (-COOH)",
        "Carbonyl group (-C=O)",
        "Methyl group (-CH3)"
      ],
      correct: "Carboxyl group (-COOH)"
    },
    {
      "question": "Which chemical test is used to confirm the presence of ethanoic acid?",
      "options": [
        "Lime water test",
        "Sodium bicarbonate test",
        "Tollen's test",
        "Iodine test"
      ],
      correct: "Sodium bicarbonate test"
    },
    {
      "question": "What is the primary component of vinegar?",
      "options": [
        "Ethanol",
        "Ethanoic acid",
        "Formic acid",
        "Methanoic acid"
      ],
      correct: "Ethanoic acid"
    },
    {
      "question": "What type of reaction is involved in the formation of an ester from ethanol and ethanoic acid?",
      "options": [
        "Neutralization",
        "Esterification",
        "Oxidation",
        "Reduction"
      ],
      correct: "Esterification"
    },
    {
      "question": "What is the use of ethanoic acid in food preservation?",
      "options": [
        "Increases shelf life",
        "Enhances flavor",
        "Acts as an antimicrobial agent",
        "All of the above"
      ],
      correct: "All of the above"
    },
    {
      "question": "What is the main action of detergents in cleaning?",
      "options": [
        "Reducing surface tension",
        "Breaking hydrogen bonds",
        "Oxidizing stains",
        "Acting as an emulsifier"
      ],
      correct: "Reducing surface tension"
    },
    {
      "question": "Which part of a soap molecule dissolves grease or oil?",
      "options": [
        "Hydrophilic head",
        "Hydrophobic tail",
        "Carbon backbone",
        "Ionic group"
      ],
      correct: "Hydrophobic tail"
    },
    {
      "question": "What is the byproduct in the saponification process?",
      "options": [
        "Ethanol",
        "Glycerol",
        "Methanol",
        "Water"
      ],
      correct: "Glycerol"
    },
    {
      "question": "Which type of water reduces the efficiency of soaps?",
      "options": [
        "Soft water",
        "Hard water",
        "Distilled water",
        "Rainwater"
      ],
      correct: "Hard water"
    },
    {
      "question": "What is the molecular formula of ethanoic acid?",
      "options": [
        "C3H6O2",
        "C2H4O2",
        "C2H6O",
        "CH4O"
      ],
      correct: "C2H4O2"
    },
    {
      "question": "Which of the following compounds is formed during the fermentation of sugar to produce ethanol?",
      "options": [
        "Lactic acid",
        "Acetone",
        "Carbon dioxide",
        "Methanol"
      ],
      correct: "Carbon dioxide"
    },
    {
      "question": "What happens to soap in hard water?",
      "options": [
        "It forms scum",
        "It lathers easily",
        "It dissolves quickly",
        "It evaporates"
      ],
      correct: "It forms scum"
    },
    {
      "question": "Which property makes detergents more effective in hard water compared to soaps?",
      "options": [
        "Ability to lower surface tension",
        "Does not form insoluble salts",
        "Non-biodegradable",
        "High boiling point"
      ],
      correct: "Does not form insoluble salts"
    },
    {
      "question": "What is the primary use of ethanol in medical applications?",
      "options": [
        "As a solvent",
        "As a disinfectant",
        "As a fuel",
        "As a flavoring agent"
      ],
      correct: "As a disinfectant"
    },
    {
      "question": "What is the pH range of ethanoic acid?",
      "options": [
        "2-3",
        "4-5",
        "6-7",
        "7-8"
      ],
      correct: "2-3"
    },
    {
      "question": "Which of the following is an advantage of synthetic detergents over soaps?",
      "options": [
        "Biodegradability",
        "Lower cost",
        "Works in hard water",
        "No environmental impact"
      ],
      correct: "Works in hard water"
    },
    {
      "question": "What is the characteristic smell of esters formed from ethanol and ethanoic acid?",
      "options": [
        "Fruity",
        "Pungent",
        "Sour",
        "Odorless"
      ],
      correct: "Fruity"
    },
    {
      "question": "Which compound is commonly used as an antifreeze in automobiles?",
      "options": [
        "Ethanol",
        "Methanol",
        "Ethanoic acid",
        "Propylene glycol"
      ],
      correct: "Ethanol"
    },
    {
      "question": "Which of the following is the IUPAC name of acetic acid?",
      "options": [
        "Methanoic acid",
        "Ethanoic acid",
        "Propanoic acid",
        "Formic acid"
      ],
      correct: "Ethanoic acid"
    },
    {
      "question": "Ethanol reacts with sodium to form which of the following products?",
      "options": [
        "Sodium acetate and water",
        "Sodium ethoxide and hydrogen gas",
        "Sodium hydroxide and hydrogen gas",
        "Sodium ethanoate and hydrogen gas"
      ],
      correct: "Sodium ethoxide and hydrogen gas"
    },
    {
      "question": "What is the molecular formula of glucose?",
      "options": [
        "C6H12O6",
        "C2H4O2",
        "CH3COOH",
        "C12H22O11"
      ],
      correct: "C6H12O6"
    },
    {
      "question": "What type of bonds are primarily present in hydrocarbons?",
      "options": [
        "Ionic bonds",
        "Covalent bonds",
        "Hydrogen bonds",
        "Metallic bonds"
      ],
      correct: "Covalent bonds"
    },
    {
      "question": "The functional group present in methanol is:",
      "options": [
        "Hydroxyl (-OH)",
        "Aldehyde (-CHO)",
        "Carboxyl (-COOH)",
        "Ketone (-C=O)"
      ],
      correct: "Hydroxyl (-OH)"
    },
    {
      "question": "Which compound is commonly known as wood spirit?",
      "options": [
        "Ethanol",
        "Methanol",
        "Propanol",
        "Butanol"
      ],
      correct: "Methanol"
    },
    {
      "question": "Which of the following tests is used to distinguish ethanol from ethanoic acid?",
      "options": [
        "Sodium bicarbonate test",
        "Bromine water test",
        "Litmus test",
        "Fehling's test"
      ],
      correct: "Sodium bicarbonate test"
    },
    {
      "question": "Saponification is a process used to manufacture:",
      "options": [
        "Ethanol",
        "Soap",
        "Detergent",
        "Ethanoic acid"
      ],
      correct: "Soap"
    },
    {
      "question": "Which of the following compounds does not undergo saponification?",
      "options": [
        "Fats",
        "Oils",
        "Esters",
        "Ethanol"
      ],
      correct: "Ethanol"
    },
    {
      "question": "Which of the following is a disadvantage of synthetic detergents?",
      "options": [
        "Forms scum in hard water",
        "Non-biodegradable",
        "Requires more water",
        "High cost"
      ],
      correct: "Non-biodegradable"
    },
    {
      "question": "The substance responsible for the characteristic fruity smell of ripe fruits is:",
      "options": [
        "Alcohols",
        "Aldehydes",
        "Esters",
        "Ketones"
      ],
      correct: "Esters"
    },
    {
      "question": "What happens when ethanoic acid is heated with ethanol in the presence of a few drops of concentrated sulfuric acid?",
      "options": [
        "Ester is formed",
        "Soap is formed",
        "Alcohol is oxidized",
        "Hydrocarbon is formed"
      ],
      correct: "Ester is formed"
    },
    {
      "question": "What is the common name of ethanoic acid?",
      "options": [
        "Formic acid",
        "Acetic acid",
        "Propionic acid",
        "Butyric acid"
      ],
      correct: "Acetic acid"
    },
    {
      "question": "What is the primary use of methanol in industries?",
      "options": [
        "As a beverage",
        "As a fuel",
        "As an antiseptic",
        "As a solvent"
      ],
      correct: "As a fuel"
    },
    {
      "question": "The reaction of ethanoic acid with sodium bicarbonate produces:",
      "options": [
        "Sodium hydroxide",
        "Carbon dioxide",
        "Hydrogen gas",
        "Methane"
      ],
      correct: "Carbon dioxide"
    },
    {
      "question": "Which of the following compounds is responsible for the cleansing action of soaps?",
      "options": [
        "Hydrophilic head",
        "Hydrophobic tail",
        "Sodium ions",
        "Potassium ions"
      ],
      correct: "Hydrophobic tail"
    },
    {
      "question": "The presence of which element in detergents makes them more effective in hard water?",
      "options": [
        "Phosphorus",
        "Sulfur",
        "Calcium",
        "Sodium"
      ],
      correct: "Phosphorus"
    },
    {
      "question": "Which of the following is a property of ethanol?",
      "options": [
        "It has no odor",
        "It burns with a blue flame",
        "It reacts violently with water",
        "It forms scum with hard water"
      ],
      correct: "It burns with a blue flame"
    },
    {
      "question": "What is the molecular formula of propanone (acetone)?",
      "options": [
        "C3H6O",
        "C2H6O",
        "C4H10O",
        "C3H8O"
      ],
      correct: "C3H6O"
    },
    {
      "question": "Which of the following is not an organic compound?",
      "options": [
        "Methane",
        "Ethanol",
        "Sodium chloride",
        "Acetic acid"
      ],
      correct: "Sodium chloride"
    }
  
  ]
  