import React, { useState } from "react";
import "./PeriodicTableCreate.css"; // Create a CSS file for styling

const elements = [
    { symbol: "H", name: "Hydrogen", atomicNumber: 1, atomicMass: "1.00794", application: "Fuel cells, welding,Hydrogen is the most abundant element in the universe and is found in the air, water, and electronics", block: "S" },
    { symbol: "He", name: "Helium", atomicNumber: 2, atomicMass: "4.002602", application: "Balloons, cryogenics,Helium is a colorless, odorless, non-toxic, inert gas", block: "S" },
    { symbol: "Li", name: "Lithium", atomicNumber: 3, atomicMass: "6.94", application: "Batteries, alloys,A soft, silvery-white metal", block: "S" },
    { symbol: "Be", name: "Beryllium", atomicNumber: 4, atomicMass: "9.012182", application: "Aerospace materials, A silvery-white, lustrous, relatively soft metal", block: "S" },
    { symbol: "B", name: "Boron", atomicNumber: 5, atomicMass: "10.81", application: "Glass, detergents,In its crystalline form it is a brittle, dark, lustrous metalloid; in its amorphous form it is a brown powder. As the lightest element of the boron group it has three valence electrons for forming covalent bonds, resulting in many compounds such as boric acid, the mineral sodium borate, and the ultra-hard crystals of boron carbide and boron nitride.", block: "P" },
    { symbol: "C", name: "Carbon", atomicNumber: 6, atomicMass: "12.011", application: "Organic chemistry, fuel", block: "P" },
    { symbol: "N", name: "Nitrogen", atomicNumber: 7, atomicMass: "14.007", application: "Fertilizers, cooling systems", block: "P" },
    { symbol: "O", name: "Oxygen", atomicNumber: 8, atomicMass: "15.999", application: "Respiration, water formation", block: "P" },
    { symbol: "F", name: "Fluorine", atomicNumber: 9, atomicMass: "18.9984032", application: "Toothpaste, refrigerants", block: "P" },
    { symbol: "Ne", name: "Neon", atomicNumber: 10, atomicMass: "20.1797", application: "Neon signs, lighting", block: "P" },
    { symbol: "Na", name: "Sodium", atomicNumber: 11, atomicMass: "22.98976928", application: "Table salt, soap, highly reactive metal. Sodium is an alkali metal", block: "S" },
    { symbol: "Mg", name: "Magnesium", atomicNumber: 12, atomicMass: "24.305", application: "Alloys, fireworks, shiny grey , aluminium alloys, die-casting (alloyed with zinc),[59] removing sulfur in the production of iron and steel", block: "S" },
    { symbol: "Al", name: "Aluminum", atomicNumber: 13, atomicMass: "26.9815385", application: "Packaging, aerospace", block: "P" },
    { symbol: "Si", name: "Silicon", atomicNumber: 14, atomicMass: "28.085", application: "Electronics, glass", block: "P" },
    { symbol: "P", name: "Phosphorus", atomicNumber: 15, atomicMass: "30.973762", application: "Fertilizers, matches", block: "P" },
    { symbol: "S", name: "Sulfur", atomicNumber: 16, atomicMass: "32.06", application: "Rubber, gunpowder", block: "P" },
    { symbol: "Cl", name: "Chlorine", atomicNumber: 17, atomicMass: "35.45", application: "Disinfectants, PVC", block: "P" },
    { symbol: "Ar", name: "Argon", atomicNumber: 18, atomicMass: "39.948", application: "Lighting, welding", block: "P" },
    { symbol: "K", name: "Potassium", atomicNumber: 19, atomicMass: "39.0983", application: "Fertilizers, fireworks,Medical use Potassium citrate Potassium citrate is used to treat a kidney stone condition called renal tubular acidosis", block: "S" },
    { symbol: "Ca", name: "Calcium", atomicNumber: 20, atomicMass: "40.078", application: "Bones, cement,The largest use of metallic calcium is in steelmaking, due to its strong chemical affinity for oxygen and sulfur", block: "S" },
    { symbol: "Sc", name: "Scandium", atomicNumber: 21, atomicMass: "44.955912", application: "Aerospace, alloys", block: "D" },
    { symbol: "Ti", name: "Titanium", atomicNumber: 22, atomicMass: "47.867", application: "Aerospace, implants", block: "D" },
    { symbol: "V", name: "Vanadium", atomicNumber: 23, atomicMass: "50.9415", application: "Steel, catalysts", block: "D" },
    { symbol: "Cr", name: "Chromium", atomicNumber: 24, atomicMass: "51.9961", application: "Stainless steel, pigments", block: "D" },
    { symbol: "Mn", name: "Manganese", atomicNumber: 25, atomicMass: "54.938044", application: "Steel, batteries", block: "D" },
    { symbol: "Fe", name: "Iron", atomicNumber: 26, atomicMass: "55.845", application: "Steel, magnets", block: "D" },
    { symbol: "Co", name: "Cobalt", atomicNumber: 27, atomicMass: "58.933194", application: "Batteries, alloys", block: "D" },
    { symbol: "Ni", name: "Nickel", atomicNumber: 28, atomicMass: "58.6934", application: "Coins, batteries", block: "D" },
    { symbol: "Cu", name: "Copper", atomicNumber: 29, atomicMass: "63.546", application: "Wiring, coins", block: "D" },
    { symbol: "Zn", name: "Zinc", atomicNumber: 30, atomicMass: "65.38", application: "Galvanization, alloys", block: "D" },
    { symbol: "Ga", name: "Gallium", atomicNumber: 31, atomicMass: "69.723", application: "Electronics, LEDs", block: "P" },
    { symbol: "Ge", name: "Germanium", atomicNumber: 32, atomicMass: "72.63", application: "Electronics, optics", block: "P" },
    { symbol: "As", name: "Arsenic", atomicNumber: 33, atomicMass: "74.921595", application: "Pesticides, semiconductors", block: "P" },
    { symbol: "Se", name: "Selenium", atomicNumber: 34, atomicMass: "78.96", application: "Glass, electronics", block: "P" },
    { symbol: "Br", name: "Bromine", atomicNumber: 35, atomicMass: "79.904", application: "Flame retardants, pesticides", block: "P" },
    { symbol: "Kr", name: "Krypton", atomicNumber: 36, atomicMass: "83.798", application: "Lighting, lasers", block: "P" },
    { symbol: "Rb", name: "Rubidium", atomicNumber: 37, atomicMass: "85.4678", application: "Research, electronics", block: "s" },
    { symbol: "Sr", name: "Strontium", atomicNumber: 38, atomicMass: "87.62", application: "Fireworks, magnets", block: "s" },
    { symbol: "Y", name: "Yttrium", atomicNumber: 39, atomicMass: "88.90584", application: "LEDs, ceramics", block: "d" },
    { symbol: "Zr", name: "Zirconium", atomicNumber: 40, atomicMass: "91.224", application: "Nuclear reactors", block: "d" },
    { symbol: "Nb", name: "Niobium", atomicNumber: 41, atomicMass: "92.90637", application: "Steel, superconductors", block: "d" },
    { symbol: "Mo", name: "Molybdenum", atomicNumber: 42, atomicMass: "95.95", application: "Alloys, catalysts", block: "d" },
    { symbol: "Tc", name: "Technetium", atomicNumber: 43, atomicMass: "98", application: "Medical imaging", block: "d" },
    { symbol: "Ru", name: "Ruthenium", atomicNumber: 44, atomicMass: "101.07", application: "Electronics, catalysts", block: "d" },
    { symbol: "Rh", name: "Rhodium", atomicNumber: 45, atomicMass: "102.90550", application: "Catalytic converters", block: "d" },
    { symbol: "Pd", name: "Palladium", atomicNumber: 46, atomicMass: "106.42", application: "Jewelry, catalysts", block: "d" },
    { symbol: "Ag", name: "Silver", atomicNumber: 47, atomicMass: "107.8682", application: "Jewelry, electronics", block: "d" },
    { symbol: "Cd", name: "Cadmium", atomicNumber: 48, atomicMass: "112.414", application: "Batteries, pigments", block: "d" },
    { symbol: "In", name: "Indium", atomicNumber: 49, atomicMass: "114.818", application: "LCDs, electronics", block: "p" },
    { symbol: "Sn", name: "Tin", atomicNumber: 50, atomicMass: "118.71", application: "Solder, alloys", block: "p" },
    { symbol: "Sb", name: "Antimony", atomicNumber: 51, atomicMass: "121.760", application: "Flame retardants, alloys", block: "p" },
    { symbol: "Te", name: "Tellurium", atomicNumber: 52, atomicMass: "127.60", application: "Thermoelectric devices", block: "p" },
    { symbol: "I", name: "Iodine", atomicNumber: 53, atomicMass: "126.90447", application: "Antiseptics, nutrition", block: "p" },
    { symbol: "Xe", name: "Xenon", atomicNumber: 54, atomicMass: "131.293", application: "Lighting, anesthesia", block: "p" },
    { symbol: "Cs", name: "Cesium", atomicNumber: 55, atomicMass: "132.90545196", application: "Atomic clocks, drilling fluids", block: "s" },
    { symbol: "Ba", name: "Barium", atomicNumber: 56, atomicMass: "137.327", application: "X-rays, glassmaking", block: "s" },
    { symbol: "La", name: "Lanthanum", atomicNumber: 57, atomicMass: "138.90547", application: "Alloys, glass", block: "f" },
    { symbol: "Ce", name: "Cerium", atomicNumber: 58, atomicMass: "140.116", application: "Polishing, catalysts", block: "f" },
    { symbol: "Pr", name: "Praseodymium", atomicNumber: 59, atomicMass: "140.90766", application: "Magnets, lighting", block: "f" },
    { symbol: "Nd", name: "Neodymium", atomicNumber: 60, atomicMass: "144.242", application: "Magnets, lasers", block: "f" },
    { symbol: "Pm", name: "Promethium", atomicNumber: 61, atomicMass: "145", application: "Nuclear batteries", block: "f" },
    { symbol: "Sm", name: "Samarium", atomicNumber: 62, atomicMass: "150.36", application: "Magnets, nuclear reactors", block: "f" },
    { symbol: "Eu", name: "Europium", atomicNumber: 63, atomicMass: "151.964", application: "LEDs, phosphors", block: "f" },
    { symbol: "Gd", name: "Gadolinium", atomicNumber: 64, atomicMass: "157.25", application: "MRI contrast agents", block: "f" },
    { symbol: "Tb", name: "Terbium", atomicNumber: 65, atomicMass: "158.92535", application: "Phosphors, electronics", block: "f" },
    { symbol: "Dy", name: "Dysprosium", atomicNumber: 66, atomicMass: "162.500", application: "Magnets, lasers", block: "f" },
    { symbol: "Ho", name: "Holmium", atomicNumber: 67, atomicMass: "164.93033", application: "Lasers, alloys", block: "f" },
    { symbol: "Er", name: "Erbium", atomicNumber: 68, atomicMass: "167.259", application: "Lasers, amplifiers", block: "f" },
    { symbol: "Tm", name: "Thulium", atomicNumber: 69, atomicMass: "168.93422", application: "X-rays, lasers", block: "f" },
    { symbol: "Yb", name: "Ytterbium", atomicNumber: 70, atomicMass: "173.045", application: "Lasers, alloys", block: "f" },
    { symbol: "Lu", name: "Lutetium", atomicNumber: 71, atomicMass: "174.9668", application: "Catalysts, PET scanners", block: "f" },
    { symbol: "Hf", name: "Hafnium", atomicNumber: 72, atomicMass: "178.49", application: "Nuclear reactors", block: "d" },
    { symbol: "Ta", name: "Tantalum", atomicNumber: 73, atomicMass: "180.94788", application: "Electronics, alloys", block: "d" },
    { symbol: "W", name: "Tungsten", atomicNumber: 74, atomicMass: "183.84", application: "Bulbs, cutting tools", block: "d" },
    { symbol: "Re", name: "Rhenium", atomicNumber: 75, atomicMass: "186.207", application: "Catalysts, turbines", block: "d" },
    { symbol: "Os", name: "Osmium", atomicNumber: 76, atomicMass: "190.23", application: "Pens, alloys", block: "d" },
    { symbol: "Ir", name: "Iridium", atomicNumber: 77, atomicMass: "192.217", application: "Electronics, spark plugs", block: "d" },
    { symbol: "Pt", name: "Platinum", atomicNumber: 78, atomicMass: "195.084", application: "Jewelry, catalysts", block: "d" },
    { symbol: "Au", name: "Gold", atomicNumber: 79, atomicMass: "196.966569", application: "Jewelry, electronics", block: "d" },
    { symbol: "Hg", name: "Mercury", atomicNumber: 80, atomicMass: "200.592", application: "Thermometers, lighting", block: "d" },
    { symbol: "Tl", name: "Thallium", atomicNumber: 81, atomicMass: "204.38", application: "Electronics, optics,It is a silvery-white post-transition metal that is not found free in nature. When isolated, thallium resembles tin, but discolors when exposed to air,Soluble thallium salts, highly toxic and they were historically used in rat poisons and insecticides", block: "p" },
    { symbol: "Pb", name: "Lead", atomicNumber: 82, atomicMass: "207.2", application: "Batteries, radiation shielding", block: "p" },
    { symbol: "Bi", name: "Bismuth", atomicNumber: 83, atomicMass: "208.98040", application: "Medications, pigments", block: "p" },
    { symbol: "Po", name: "Polonium", atomicNumber: 84, atomicMass: "209", application: "Nuclear batteries", block: "p" },
    { symbol: "At", name: "Astatine", atomicNumber: 85, atomicMass: "210", application: "Research, medicine", block: "p" },
    { symbol: "Rn", name: "Radon", atomicNumber: 86, atomicMass: "222", application: "Cancer therapy", block: "p" },
    { symbol: "Fr", name: "Francium", atomicNumber: 87, atomicMass: "223", application: "Research", block: "s" },
    { symbol: "Ra", name: "Radium", atomicNumber: 88, atomicMass: "226", application: "Cancer treatment", block: "s" },
    { symbol: "Ac", name: "Actinium", atomicNumber: 89, atomicMass: "227", application: "Medicine, research", block: "f" },
    { symbol: "Th", name: "Thorium", atomicNumber: 90, atomicMass: "232.0377", application: "Nuclear reactors, Thorium is a weakly radioactive light silver metal which tarnishes olive grey when it is exposed to air, forming thorium dioxide; it is moderately soft, malleable, and has a high melting point", block: "f" },
    { symbol: "Pa", name: "Protactinium", atomicNumber: 91, atomicMass: "231.03588", application: "Research", block: "f" },
    { symbol: "U", name: "Uranium", atomicNumber: 92, atomicMass: "238.02891", application: "Nuclear fuel", block: "f" },
    { symbol: "Np", name: "Neptunium", atomicNumber: 93, atomicMass: "237", application: "Nuclear research", block: "f" },
    { symbol: "Pu", name: "Plutonium", atomicNumber: 94, atomicMass: "244", application: "Nuclear weapons", block: "f" },
    { symbol: "Am", name: "Americium", atomicNumber: 95, atomicMass: "243", application: "Smoke detectors", block: "f" },
    { symbol: "Cm", name: "Curium", atomicNumber: 96, atomicMass: "247", application: "Nuclear batteries", block: "f" },
    { symbol: "Bk", name: "Berkelium", atomicNumber: 97, atomicMass: "247", application: "Research, harmless to humans,22 milligrams of berkelium (as nitrate) prepared at HFIR in 2009 at a cost of approximately one million dollars, used for the synthesis of tennessine in, is synthesized in minute quantities in dedicated high-flux nuclear reactors", block: "f" },
    { symbol: "Cf", name: "Californium", atomicNumber: 98, atomicMass: "251", application: "Radiography, Electronic Configuration :- [Rn] 5f⁷ 6d¹ s², Metallic Character :- Metals ,Specific Name :- Actinoids ,Physical State:- Solid , Discovery:- 1944", block: "f" },
    { symbol: "Es", name: "Einsteinium", atomicNumber: 99, atomicMass: "252", application: "Research, Einsteinium was discovered as a component of the debris of the first hydrogen bomb explosion in 1952", block: "f" },
    { symbol: "Fm", name: "Fermium", atomicNumber: 100, atomicMass: "257", application: "Research, Electronic Configuration :- [Rn] 5f¹² s², Metallic Character :- Metals ,Specific Name :- Actinoids ,Physical State:- Solid , Discovery:- 1952", block: "f" },
    { symbol: "Md", name: "Mendelevium", atomicNumber: 101, atomicMass: "258", application: "Research, Electronic Configuration :- [Rn] 5f¹³ s², Metallic Character :- Metals ,Specific Name :- Actinoids ,Physical State:- Solid , Discovery:- 1955", block: "f" },
    { symbol: "No", name: "Nobelium", atomicNumber: 102, atomicMass: "259", application: "Research, , Electronic Configuration :- [Rn] 5f¹⁴ s², Metallic Character :- Metals ,Specific Name :- Actinoids ,Physical State:- Solid , Discovery:- 1958", block: "f" },
    { symbol: "Lr", name: "Lawrencium", atomicNumber: 103, atomicMass: "262", application: "Research,  particle accelerators by bombarding lighter elements with charged particles. Fourteen isotopes of lawrencium are currently known; the most stable is 266Lr with half-life 11 hours, but the shorter-lived 260Lr (half-life 2.7 minutes) is most commonly used in chemistry because it can be produced on a larger scale", block: "f" },
    { symbol: "Rf", name: "Rutherfordium", atomicNumber: 104, atomicMass: "267", application: "Research, As a synthetic element, it is not found in nature and can only be made in a particle accelerator. It is radioactive; the most stable known isotope, 267Rf, has a half-life of about 48 minutes", block: "d" },
    { symbol: "Db", name: "Dubnium", atomicNumber: 105, atomicMass: "270", application: "Research, Dubnium is a synthetic chemical element; it has symbol Db and atomic number 105. It is highly radioactive: the most stable known isotope, dubnium-268, has a half-life of about 16 hours", block: "d" },
    { symbol: "Sg", name: "Seaborgium", atomicNumber: 106, atomicMass: "271", application: "Research,  It is named after the American nuclear chemist Glenn T. Seaborg. As a synthetic element, it can be created in a laboratory but is not found in nature.", block: "d" },
    { symbol: "Bh", name: "Bohrium", atomicNumber: 107, atomicMass: "274", application: "Research, are highly radioactive; the most stable known isotope is 270Bh with a half-life of approximately 2.4 minutes, though the unconfirmed 278Bh may have a longer half-life of about 11.5 minutes.", block: "d" },
    { symbol: "Hs", name: "Hassium", atomicNumber: 108, atomicMass: "277", application: "Research, It is highly radioactive: its most stable known isotopes have half-lives of approximately ten seconds.[a] One of its isotopes, 270Hs, has magic numbers of protons and neutrons for deformed nuclei, giving it greater stability against spontaneous fission. Hassium is a superheavy element;", block: "d" },
    { symbol: "Mt", name: "Meitnerium", atomicNumber: 109, atomicMass: "278", application: "Research, The most stable known isotope, meitnerium-278, has a half-life of 4.5 seconds, although the unconfirmed meitnerium-282 may have a longer half-life of 67 seconds. The element was first synthesized in August 1982 by the GSI Helmholtz Centre for Heavy Ion Research near", block: "d" },
    { symbol: "Ds", name: "Darmstadtium", atomicNumber: 110, atomicMass: "281", application: "Research, It is extremely radioactive: the most stable known isotope, darmstadtium-281, has a half-life of approximately 14 seconds. Darmstadtium was first created in November 1994", block: "d" },
    { symbol: "Rg", name: "Roentgenium", atomicNumber: 111, atomicMass: "282", application: "Research,has a half-life of 130 seconds, fact that roentgenium (and its parents) decays very quickly", block: "d" },
    { symbol: "Cn", name: "Copernicium", atomicNumber: 112, atomicMass: "285", application: "Research,  Its known isotopes are extremely radioactive, and have only been created in a laboratory", block: "d" },
    { symbol: "Nh", name: "Nihonium", atomicNumber: 113, atomicMass: "286", application: "Scientific research, Very few properties of nihonium or its compounds have been measured; this is due to its extremely limited and expensive production[109] and the fact it decays very quickly. Properties of nihonium mostly remain unknown and only predictions are available.", block: "p" },
    { symbol: "Fl", name: "Flerovium", atomicNumber: 114, atomicMass: "289", application: "Scientific research", block: "p" },
    { symbol: "Mc", name: "Moscovium", atomicNumber: 115, atomicMass: "290", application: "Scientific research, , Electronic Configuration :- [Rn] 5f¹⁴ 6d¹⁰ 7s² 7p³ , Discovery :- 2010 ,Discovered By :- Scientists from the Joint Institute for Nuclear Research, Russia, and the USA.", block: "p" },
    { symbol: "Lv", name: "Livermorium", atomicNumber: 116, atomicMass: "293", application: "Scientific research, Electronic Configuration :-[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁴ , Discovery :- 2000 ,Discovered By :- Scientists from the Joint Institute for Nuclear Research, Russia, and the USA.", block: "p" },
    { symbol: "Ts", name: "Tennessine", atomicNumber: 117, atomicMass: "294", application: "Scientific research , Electronic Configuration :- [Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁵ , Discovery :- 2010 ,Discovered By :- Scientists from the Joint Institute for Nuclear Research, Russia, and the USA. ", block: "p" },
    { symbol: "Og", name: "Oganesson", atomicNumber: 118, atomicMass: "294", application: "Scientific research, Electronic Configuration :- [Rn] 7s² 7p⁶ 5f¹⁴ 6d¹⁰,  Discovery :- 2006 , Discovered By :- Joint Institute for Nuclear Research and Lawrence Livermore National Laboratory ", block: "p" }

];

const PeriodicTable = () => {

    const [tooltip, setTooltip] = useState({ visible: false, x: 0, y: 0, content: "" });

  const handleMouseOver = (event, element) => {
    const { clientX, clientY } = event;
    setTooltip({
      visible: true,
      x: clientX -10,
      y: clientY +100,
      content: `Name: ${element.name}\nAtomic Mass: ${element.atomicMass}\nApplication: ${element.application} \nAtomicNumber: ${element.atomicNumber}\nBlock: ${element.block}`,
    });
  };

  const handleMouseOut = () => {
    setTooltip({ visible: false, x: 0, y: 0, content: "" });
  };

  return (
    <>
    <h1>Periodic table</h1>
    <div className="periodic-table">
    {elements.map((element) => (
      <div
        key={element.atomicNumber}
        className="element"
        onMouseOver={(e) => handleMouseOver(e, element)}
        onMouseOut={handleMouseOut}
      >
        {element.symbol}
      </div>
    ))}
    {tooltip.visible && (
      <div
        className="tooltip"
        style={{ top: tooltip.y, left: tooltip.x }}
      >
        {tooltip.content.split("\n").map((line, index) => (
          <div key={index}>{line}</div>
        ))}
      </div>
    )}
  </div>
    </>
   
  );
};

export default PeriodicTable;
