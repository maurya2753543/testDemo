export const quizQuestions =[
    {
        "question": "Which bond is the strongest among the following?",
        "options": [
            "Ionic bond",
            "Covalent bond",
            "Hydrogen bond",
            "Van der Waals forces"
        ],
       correct: "Covalent bond"
    },
    {
        "question": "What type of bond is formed in NaCl?",
        "options": [
            "Ionic bond",
            "Covalent bond",
            "Metallic bond",
            "Hydrogen bond"
        ],
       correct: "Ionic bond"
    },
    {
        "question": "Which molecule exhibits hydrogen bonding?",
        "options": [
            "CH4",
            "H2O",
            "CO2",
            "N2"
        ],
       correct: "H2O"
    },
    {
        "question": "What is the geometry of methane (CH4)?",
        "options": [
            "Linear",
            "Trigonal planar",
            "Tetrahedral",
            "Bent"
        ],
       correct: "Tetrahedral"
    },
    {
        "question": "Which of the following molecules is polar?",
        "options": [
            "CO2",
            "CH4",
            "HCl",
            "CCl4"
        ],
       correct: "HCl"
    },
    {
        "question": "What type of bond is present in O2?",
        "options": [
            "Single bond",
            "Double bond",
            "Triple bond",
            "Ionic bond"
        ],
       correct: "Double bond"
    },
    {
        "question": "Which element is most electronegative?",
        "options": [
            "Oxygen",
            "Nitrogen",
            "Fluorine",
            "Chlorine"
        ],
       correct: "Fluorine"
    },
    {
        "question": "Which of the following represents a coordinate covalent bond?",
        "options": [
            "H-H",
            "NH3 → H+",
            "Na+ Cl-",
            "C=C"
        ],
       correct: "NH3 → H+"
    },
    {
        "question": "Which compound is ionic?",
        "options": [
            "H2O",
            "NaF",
            "CH4",
            "Cl2"
        ],
       correct: "NaF"
    },
    {
        "question": "Which molecule has a bent structure?",
        "options": [
            "CO2",
            "H2O",
            "BF3",
            "CH4"
        ],
       correct: "H2O"
    },
    {
        "question": "Which bond angle is correct for NH3?",
        "options": [
            "109.5°",
            "120°",
            "104.5°",
            "107°"
        ],
       correct: "107°"
    },
    {
        "question": "What is the hybridization of carbon in ethene (C2H4)?",
        "options": [
            "sp",
            "sp2",
            "sp3",
            "dsp2"
        ],
       correct: "sp2"
    },
    {
        "question": "What is the bond angle in a molecule with sp3 hybridization?",
        "options": [
            "90°",
            "109.5°",
            "120°",
            "180°"
        ],
       correct: "109.5°"
    },
    {
        "question": "Which type of bonding occurs in metallic bonds?",
        "options": [
            "Sharing of electrons",
            "Transfer of electrons",
            "Delocalization of electrons",
            "Hydrogen bonding"
        ],
       correct: "Delocalization of electrons"
    },
    {
        "question": "Which molecule is non-polar despite having polar bonds?",
        "options": [
            "HCl",
            "CH4",
            "CO2",
            "NH3"
        ],
       correct: "CO2"
    },
    {
        "question": "What type of bond is formed between two chlorine atoms in a Cl2 molecule?",
        "options": [
            "Ionic bond",
            "Single covalent bond",
            "Double covalent bond",
            "Metallic bond"
        ],
       correct: "Single covalent bond"
    },
    {
        "question": "Which molecule has a linear structure?",
        "options": [
            "NH3",
            "H2O",
            "CO2",
            "CH4"
        ],
       correct: "CO2"
    },
    {
        "question": "Which of the following elements does not form hydrogen bonds?",
        "options": [
            "Oxygen",
            "Nitrogen",
            "Fluorine",
            "Carbon"
        ],
       correct: "Carbon"
    },
    {
        "question": "What is the bond order of O2?",
        "options": [
            "1",
            "2",
            "3",
            "4"
        ],
       correct: "2"
    },
    {
        "question": "What causes a molecule to be polar?",
        "options": [
            "Symmetrical charge distribution",
            "Asymmetrical charge distribution",
            "Presence of double bonds",
            "High molecular weight"
        ],
       correct: "Asymmetrical charge distribution"
    },
    {
        "question": "Which compound has the highest lattice energy?",
        "options": [
            "NaCl",
            "MgO",
            "KCl",
            "LiF"
        ],
       correct: "MgO"
    },
    {
        "question": "Which molecule has sp hybridization?",
        "options": [
            "C2H2",
            "C2H4",
            "CH4",
            "CO2"
        ],
       correct: "C2H2"
    },
    {
        "question": "What is the shape of the BF3 molecule?",
        "options": [
            "Tetrahedral",
            "Trigonal planar",
            "Linear",
            "Trigonal pyramidal"
        ],
       correct: "Trigonal planar"
    },
    {
        "question": "Which bond is the most polar?",
        "options": [
            "C-H",
            "C-Cl",
            "H-F",
            "N-O"
        ],
       correct: "H-F"
    },
    {
        "question": "What type of bond exists in graphite between the layers?",
        "options": [
            "Covalent bonds",
            "Ionic bonds",
            "Metallic bonds",
            "Van der Waals forces"
        ],
       correct: "Van der Waals forces"
    },
    {
        "question": "Which compound has delocalized π-electrons?",
        "options": [
            "C2H6",
            "C6H6",
            "CH3OH",
            "CH4"
        ],
       correct: "C6H6"
    },
    {
        "question": "What is the formal charge on the oxygen atom in O3 (ozone)?",
        "options": [
            "-1",
            "0",
            "+1",
            "+2"
        ],
       correct: "-1"
    },
    {
        "question": "Which molecule contains a triple bond?",
        "options": [
            "N2",
            "O2",
            "H2",
            "F2"
        ],
       correct: "N2"
    },
    {
        "question": "Which of the following molecules is planar?",
        "options": [
            "CH4",
            "C2H4",
            "NH3",
            "H2O"
        ],
       correct: "C2H4"
    },
    {
        "question": "What is the bond angle in the water (H2O) molecule?",
        "options": [
            "90°",
            "104.5°",
            "120°",
            "180°"
        ],
       correct: "104.5°"
    },
    {
        "question": "Which of the following molecules exhibits resonance?",
        "options": [
            "O3 (ozone)",
            "CO2",
            "H2O",
            "CH4"
        ],
       correct: "O3 (ozone)"
    },
    {
        "question": "In a molecule with an expanded octet, how many electrons can the central atom accommodate?",
        "options": [
            "8 electrons",
            "10 electrons",
            "12 electrons",
            "16 electrons"
        ],
       correct: "12 electrons"
    },
    {
        "question": "Which of the following compounds contains an ionic bond but also exhibits covalent character?",
        "options": [
            "NaCl",
            "MgO",
            "LiF",
            "NH4NO3"
        ],
       correct: "NH4NO3"
    },
    {
        "question": "In the molecular orbital theory, which of the following is true for a bond order of zero?",
        "options": [
            "The molecule is unstable and does not exist.",
            "The molecule exists but has no net bond between atoms.",
            "The molecule is stable with a non-zero bond order.",
            "The molecule has a weak bond and may dissociate."
        ],
       correct: "The molecule is unstable and does not exist."
    },
    {
        "question": "What is the hybridization of the central atom in the molecule SF6?",
        "options": [
            "sp3",
            "sp2",
            "sp3d2",
            "d2sp3"
        ],
       correct: "sp3d2"
    },
    {
        "question": "Which of the following molecules has the highest bond dissociation energy?",
        "options": [
            "H2",
            "N2",
            "O2",
            "Cl2"
        ],
       correct: "N2"
    },
    {
        "question": "In the molecular orbital theory, how many unpaired electrons are present in the O2 molecule?",
        "options": [
            "1",
            "2",
            "3",
            "4"
        ],
       correct: "2"
    },
    {
        "question": "What type of bond is present in a molecule of formaldehyde (CH2O)?",
        "options": [
            "Single covalent bond",
            "Double covalent bond",
            "Triple covalent bond",
            "Ionic bond"
        ],
       correct: "Double covalent bond"
    },
    {
        "question": "Which of the following molecules adopts a square planar geometry?",
        "options": [
            "SF4",
            "XeF4",
            "Cl2O",
            "PCl5"
        ],
       correct: "XeF4"
    },
    {
        "question": "Which of the following is a property of metallic bonding?",
        "options": [
            "Delocalized electrons move freely between atoms.",
            "Electrons are localized around specific atoms.",
            "Electrons form rigid bonds between atoms.",
            "Atoms share electrons in a fixed, non-moving position."
        ],
       correct: "Delocalized electrons move freely between atoms."
    },
    {
        "question": "What is the molecular geometry of the ClO3− ion?",
        "options": [
            "Trigonal planar",
            "Tetrahedral",
            "Trigonal pyramidal",
            "Bent"
        ],
       correct: "Trigonal pyramidal"
    },
    {
        "question": "Which of the following elements does not follow the octet rule in its most stable form?",
        "options": [
            "Boron",
            "Carbon",
            "Oxygen",
            "Nitrogen"
        ],
       correct: "Boron"
    },
    {
        "question": "What is the bond angle in the methane (CH4) molecule?",
        "options": [
            "90°",
            "120°",
            "109.5°",
            "180°"
        ],
       correct: "109.5°"
    },
    {
        "question": "Which of the following ions has the same electronic configuration as the noble gas Argon (Ar)?",
        "options": [
            "Na+",
            "Mg2+",
            "Cl−",
            "Ca2+"
        ],
       correct: "Cl−"
    },
    {
        "question": "In a molecule of HCN (hydrogen cyanide), what is the hybridization of the central carbon atom?",
        "options": [
            "sp",
            "sp2",
            "sp3",
            "d2sp3"
        ],
       correct: "sp"
    },
    {
        "question": "Which of the following compounds exhibits an sp3d hybridization?",
        "options": [
            "BF3",
            "SF6",
            "PCl5",
            "H2O"
        ],
       correct: "PCl5"
    },
    {
        "question": "Which of the following molecules has the highest bond dissociation energy?",
        "options": [
            "H2",
            "N2",
            "O2",
            "Cl2"
        ],
       correct: "N2"
    },
    {
        "question": "What is the hybridization of the central atom in the molecule IF5?",
        "options": [
            "sp3",
            "sp3d",
            "sp3d2",
            "d2sp3"
        ],
       correct: "sp3d2"
    },
    {
        "question": "Which of the following species has the smallest bond angle?",
        "options": [
            "NH3",
            "H2O",
            "CH4",
            "CO2"
        ],
       correct: "H2O"
    },
    {
        "question": "Which of the following molecules exhibits resonance?",
        "options": [
            "CO2",
            "N2",
            "O3",
            "CH4"
        ],
       correct: "O3"
    },
    {
        "question": "Which of the following is the correct order of electronegativity?",
        "options": [
            "F > Cl > Br > I",
            "I > Br > Cl > F",
            "Cl > F > I > Br",
            "Br > I > F > Cl"
        ],
       correct: "F > Cl > Br > I"
    },
    {
        "question": "Which of the following molecules has an odd number of electrons and is paramagnetic?",
        "options": [
            "O2",
            "N2",
            "C2",
            "F2"
        ],
       correct: "O2"
    },
    {
        "question": "What is the bond order of O2 (oxygen molecule) according to molecular orbital theory?",
        "options": [
            "1",
            "2",
            "3",
            "4"
        ],
       correct: "2"
    },
    {
        "question": "Which of the following compounds is an example of a coordinate bond?",
        "options": [
            "NaCl",
            "H2O",
            "NH3",
            "H3O+"
        ],
       correct: "H3O+"
    },
    {
        "question": "What is the shape of the SO2 molecule?",
        "options": [
            "Linear",
            "Bent",
            "Trigonal planar",
            "Tetrahedral"
        ],
       correct: "Bent"
    },
    {
        "question": "Which of the following ions has the same electronic configuration as the nearest noble gas?",
        "options": [
            "Na+",
            "Mg2+",
            "Cl−",
            "O2−"
        ],
       correct: "Na+"
    },
    {
        "question": "What is the hybridization of the central atom in the ClF3 molecule?",
        "options": [
            "sp",
            "sp2",
            "sp3d",
            "sp3d2"
        ],
       correct: "sp3d"
    },
    {
        "question": "Which of the following molecules adopts a trigonal bipyramidal geometry?",
        "options": [
            "SF4",
            "ClF3",
            "PCl5",
            "XeF6"
        ],
       correct: "PCl5"
    },
    {
        "question": "Which of the following ions will exhibit a distorted tetrahedral geometry due to lone pair repulsion?",
        "options": [
            "NH3",
            "H2O",
            "CH4",
            "SiCl4"
        ],
       correct: "H2O"
    },
    {
        "question": "Which of the following molecules has a bond order of 3 according to molecular orbital theory?",
        "options": [
            "O2",
            "B2",
            "N2",
            "F2"
        ],
       correct: "N2"
    },
    {
        "question": "Which of the following molecules is least likely to exhibit a covalent bond?",
        "options": [
            "HCl",
            "NaCl",
            "H2O",
            "N2"
        ],
       correct: "NaCl"
    },
    {
        "question": "Which of the following statements is true for ionic compounds?",
        "options": [
            "They have low melting points.",
            "They conduct electricity in solid form.",
            "They are soluble in non-polar solvents.",
            "They are formed by the transfer of electrons."
        ],
       correct: "They are formed by the transfer of electrons."
    },
    {
        "question": "Which of the following compounds is formed by the sharing of electrons between atoms?",
        "options": [
            "NaCl",
            "H2O",
            "MgO",
            "CaCl2"
        ],
       correct: "H2O"
    },
    {
        "question": "What is the bond order of NO (Nitric Oxide) according to molecular orbital theory?",
        "options": [
            "1",
            "1.5",
            "2",
            "2.5"
        ],
       correct: "2.5"
    },
    {
        "question": "In which of the following molecules does the central atom undergo sp3d2 hybridization?",
        "options": [
            "XeF4",
            "SF6",
            "ClF3",
            "PF5"
        ],
       correct: "SF6"
    },
    {
        "question": "Which of the following statements is correct for the bonding in methane (CH4)?",
        "options": [
            "CH4 has sp3 hybridization and a tetrahedral geometry.",
            "CH4 has sp hybridization and a linear geometry.",
            "CH4 has sp3d2 hybridization and octahedral geometry.",
            "CH4 has sp2 hybridization and trigonal planar geometry."
        ],
       correct: "CH4 has sp3 hybridization and a tetrahedral geometry."
    },
    {
        "question": "Which of the following molecules has the shortest bond length?",
        "options": [
            "H2",
            "Cl2",
            "O2",
            "N2"
        ],
       correct: "N2"
    },
    {
        "question": "What is the correct bond angle for a molecule of water (H2O)?",
        "options": [
            "104.5°",
            "120°",
            "109.5°",
            "180°"
        ],
       correct: "104.5°"
    },
    {
        "question": "Which of the following molecules has the highest dipole moment?",
        "options": [
            "CO2",
            "HCl",
            "SO2",
            "CH4"
        ],
       correct: "SO2"
    },
    {
        "question": "Which of the following statements is true for the molecular orbital diagram of O2?",
        "options": [
            "O2 has 12 bonding electrons and 8 anti-bonding electrons.",
            "O2 has 8 bonding electrons and 12 anti-bonding electrons.",
            "O2 has 10 bonding electrons and 6 anti-bonding electrons.",
            "O2 has 6 bonding electrons and 10 anti-bonding electrons."
        ],
       correct: "O2 has 10 bonding electrons and 6 anti-bonding electrons."
    },
    {
        "question": "In which molecule does the central atom exhibit sp3d hybridization?",
        "options": [
            "BF3",
            "PCl5",
            "SiCl4",
            "NH3"
        ],
       correct: "PCl5"
    },
    {
        "question": "Which of the following molecules has an expanded octet?",
        "options": [
            "SO2",
            "CO2",
            "ClF3",
            "CH4"
        ],
       correct: "ClF3"
    },
    {
        "question": "Which of the following ions has a magnetic moment?",
        "options": [
            "Fe2+",
            "Ni2+",
            "Cu2+",
            "Zn2+"
        ],
       correct: "Fe2+"
    },
    {
        "question": "Which of the following molecules shows a bond order of 1 according to molecular orbital theory?",
        "options": [
            "O2+",
            "N2",
            "CO",
            "B2"
        ],
       correct: "O2+"
    },
    {
        "question": "What is the geometry of the ClF3 molecule?",
        "options": [
            "Tetrahedral",
            "Bent",
            "Trigonal bipyramidal",
            "T-shaped"
        ],
       correct: "T-shaped"
    },
    {
        "question": "Which of the following compounds has an ionic bond?",
        "options": [
            "NaCl",
            "H2O",
            "SO2",
            "CO2"
        ],
       correct: "NaCl"
    },
    {
        "question": "In which of the following molecules does the central atom have an oxidation state of +7?",
        "options": [
            "H2SO4",
            "KMnO4",
            "ClO3−",
            "CrO3"
        ],
       correct: "KMnO4"
    },
    {
        "question": "Which of the following molecules exhibits both sigma and pi bonding?",
        "options": [
            "H2O",
            "CH4",
            "C2H4",
            "O2"
        ],
       correct: "C2H4"
    },
    {
        "question": "Which of the following is true about the bond order in molecular orbital theory for the molecule O2−?",
        "options": [
            "Bond order is 1",
            "Bond order is 2",
            "Bond order is 3",
            "Bond order is 2.5"
        ],
       correct: "Bond order is 1"
    },
    {
        "question": "What is the correct order of increasing electronegativity for the following elements: Cl, F, O, N?",
        "options": [
            "F < Cl < O < N",
            "Cl < O < N < F",
            "O < N < F < Cl",
            "F < O < N < Cl"
        ],
       correct: "Cl < O < N < F"
    },
    {
        "question": "What is the molecular geometry of ammonia (NH3)?",
        "options": [
            "Tetrahedral",
            "Trigonal planar",
            "Trigonal pyramidal",
            "Linear"
        ],
       correct: "Trigonal pyramidal"
    },
    {
        "question": "Which of the following compounds has a linear structure?",
        "options": [
            "CO2",
            "H2O",
            "CH4",
            "NH3"
        ],
       correct: "CO2"
    },
    {
        "question": "In which molecule does the central atom undergo sp3d2 hybridization?",
        "options": [
            "PCl5",
            "ClF3",
            "SF6",
            "XeF4"
        ],
       correct: "SF6"
    },
    {
        "question": "Which of the following bonds is formed by the overlap of two p-orbitals?",
        "options": [
            "σ bond",
            "π bond",
            "δ bond",
            "τ bond"
        ],
       correct: "π bond"
    },
    {
        "question": "Which molecule has a bond order of 2 according to molecular orbital theory?",
        "options": [
            "O2",
            "N2",
            "O2−",
            "N2+"
        ],
       correct: "N2"
    },
    {
        "question": "The hybridization of the central atom in SO2 is?",
        "options": [
            "sp3",
            "sp2",
            "sp",
            "sp3d"
        ],
       correct: "sp2"
    },
    {
        "question": "What is the bond order of the ion O2− according to molecular orbital theory?",
        "options": [
            "0",
            "1",
            "2",
            "3"
        ],
       correct: "1"
    },
    {
        "question": "Which of the following molecules has a resonance structure?",
        "options": [
            "CO2",
            "SO2",
            "CH4",
            "N2"
        ],
       correct: "SO2"
    },
    {
        "question": "Which of the following species has the highest bond dissociation energy?",
        "options": [
            "H2",
            "Cl2",
            "F2",
            "I2"
        ],
       correct: "F2"
    },
    {
        "question": "Which of the following has a polar covalent bond?",
        "options": [
            "NaCl",
            "O2",
            "HCl",
            "N2"
        ],
       correct: "HCl"
    },
    {
        "question": "Which of the following molecules exhibits a bent structure?",
        "options": [
            "CO2",
            "H2O",
            "CH4",
            "BF3"
        ],
       correct: "H2O"
    },
    {
        "question": "In which molecule is the central atom sp hybridized?",
        "options": [
            "CCl4",
            "CO2",
            "CH4",
            "C2H2"
        ],
       correct: "C2H2"
    },
    {
        "question": "What is the molecular geometry of the CO2 molecule?",
        "options": [
            "Tetrahedral",
            "Bent",
            "Linear",
            "Trigonal planar"
        ],
       correct: "Linear"
    },
    {
        "question": "Which of the following molecules has the highest electronegativity difference between its atoms?",
        "options": [
            "NaCl",
            "H2O",
            "HF",
            "CH4"
        ],
       correct: "HF"
    },
    {
        "question": "What is the molecular shape of the XeF4 molecule?",
        "options": [
            "Square planar",
            "Tetrahedral",
            "Octahedral",
            "Trigonal bipyramidal"
        ],
       correct: "Square planar"
    },
    {
        "question": "Which of the following ions has the same number of electrons as Ne?",
        "options": [
            "Mg2+",
            "Na+",
            "Cl−",
            "O2−"
        ],
       correct: "Na+"
    },
    {
        "question": "What is the oxidation state of chlorine in ClO3−?",
        "options": [
            "+3",
            "+5",
            "+7",
            "−1"
        ],
       correct: "+5"
    },
    {
        "question": "Which molecule exhibits an ionic bond?",
        "options": [
            "NaCl",
            "H2O",
            "CH4",
            "SO2"
        ],
       correct: "NaCl"
    },
    {
        "question": "Which of the following molecules exhibits sp3d hybridization?",
        "options": [
            "PCl5",
            "SO2",
            "XeF4",
            "CO2"
        ],
       correct: "PCl5"
    },
    {
        "question": "Which of the following has the highest bond order?",
        "options": [
            "O2−",
            "O2+",
            "O2",
            "N2"
        ],
       correct: "N2"
    },
    {
        "question": "Which of the following molecules has a tetrahedral geometry?",
        "options": [
            "NH3",
            "CO2",
            "CH4",
            "SO2"
        ],
       correct: "CH4"
    }
]
