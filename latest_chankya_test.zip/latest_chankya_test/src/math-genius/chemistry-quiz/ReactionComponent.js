import React, { useState, useEffect } from 'react';
import './ReactionComponent.css';
const ReactionComponent = () => {
  const [reactionStarted, setReactionStarted] = useState(false);

  const startReaction = () => {
    setReactionStarted(true);
  };

  useEffect(() => {
    // Trigger a reset after 5 seconds to show the reaction again
    if (reactionStarted) {
      setTimeout(() => setReactionStarted(false), 5000); // resets after 5 seconds
    }
  }, [reactionStarted]);

  return (
    <div className="reaction-container">
      <div className="molecule hydrogen" style={{ animation: reactionStarted ? 'moveHydrogen 3s forwards' : '' }}>
        H2
      </div>
      <div className="molecule oxygen" style={{ animation: reactionStarted ? 'moveOxygen 3s forwards' : '' }}>
        O2
      </div>
      {reactionStarted && (
        <div className="molecule water" style={{ animation: 'formWater 3s forwards' }}>
          H2O
        </div>
      )}
      <button onClick={startReaction} className="start-button">
        Start Reaction
      </button>
    </div>
  );
};

export default ReactionComponent;
