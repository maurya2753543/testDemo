export const quizQuestions = [ 


    {
        "question": "What is the charge of a proton?",
        "options": [
          "Negative",
          "Positive",
          "Neutral",
          "None"
        ],
        correct: "Positive"
      },
      {
        "question": "Which of the following subatomic particles is found in the nucleus of an atom?",
        "options": [
          "Electron",
          "Proton",
          "Neutron",
          "Both Proton and Neutron"
        ],
        correct: "Both Proton and Neutron"
      },
      {
        "question": "What is the mass of an electron?",
        "options": [
          "1 amu",
          "0.5 amu",
          "1/1836 amu",
          "1.67 × 10^-27 kg"
        ],
        correct: "1/1836 amu"
      },
      {
        "question": "Which model of the atom proposed that electrons move in fixed orbits around the nucleus?",
        "options": [
          "Bohr Model",
          "Thomson Model",
          "Rutherford Model",
          "Heisenberg Model"
        ],
        correct: "Bohr Model"
      },
      {
        "question": "What is the atomic number of an element?",
        "options": [
          "The number of protons in the nucleus",
          "The number of neutrons in the nucleus",
          "The number of electrons in the atom",
          "The sum of protons and neutrons in the nucleus"
        ],
        correct: "The number of protons in the nucleus"
      },
      {
        "question": "Which subatomic particle determines the chemical behavior of an element?",
        "options": [
          "Proton",
          "Neutron",
          "Electron",
          "None of the above"
        ],
        correct: "Electron"
      },
      {
        "question": "What is the maximum number of electrons that can occupy the second energy level (shell) in an atom?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "8"
      },
      {
        "question": "Which quantum number describes the shape of an electron’s orbital?",
        "options": [
          "Principal quantum number",
          "Azimuthal quantum number",
          "Magnetic quantum number",
          "Spin quantum number"
        ],
        correct: "Azimuthal quantum number"
      },
      {
        "question": "What is the principal quantum number (n) for an electron in the third energy level?",
        "options": [
          "1",
          "2",
          "3",
          "4"
        ],
        correct: "3"
      },
      {
        "question": "Which particle is responsible for the negative charge of an atom?",
        "options": [
          "Proton",
          "Neutron",
          "Electron",
          "All of the above"
        ],
        correct: "Electron"
      },
      {
        "question": "How many neutrons are in an isotope of carbon-14?",
        "options": [
          "6",
          "8",
          "14",
          "20"
        ],
        correct: "8"
      },
      {
        "question": "What is the term used to describe the energy levels around the nucleus where electrons are likely to be found?",
        "options": [
          "Orbitals",
          "Shells",
          "Quanta",
          "Excited States"
        ],
        correct: "Shells"
      },
      {
        "question": "What is the maximum number of electrons that can occupy the first energy level (shell) in an atom?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "2"
      },
      {
        "question": "Which of the following is true about the Rutherford Model of the atom?",
        "options": [
          "Electrons orbit the nucleus in fixed paths",
          "The atom is a solid mass with no empty space",
          "The atom has a small, dense nucleus",
          "Electrons are scattered throughout the atom"
        ],
        correct: "The atom has a small, dense nucleus"
      },
      {
        "question": "What is the charge of a neutron?",
        "options": [
          "Positive",
          "Negative",
          "Neutral",
          "None"
        ],
        correct: "Neutral"
      },
      {
        "question": "What does the atomic mass of an element represent?",
        "options": [
          "The total number of protons",
          "The sum of protons and neutrons",
          "The number of electrons",
          "The number of isotopes"
        ],
        correct: "The sum of protons and neutrons"
      },
      {
        "question": "Which of the following determines the isotope of an element?",
        "options": [
          "Number of electrons",
          "Number of protons",
          "Number of neutrons",
          "Number of energy levels"
        ],
        correct: "Number of neutrons"
      },
      {
        "question": "What is the name of the cloud model of the atom?",
        "options": [
          "Bohr Model",
          "Quantum Mechanical Model",
          "Thomson Model",
          "Rutherford Model"
        ],
        correct: "Quantum Mechanical Model"
      },
      {
        "question": "Which quantum number describes the orientation of an electron’s orbital?",
        "options": [
          "Principal quantum number",
          "Azimuthal quantum number",
          "Magnetic quantum number",
          "Spin quantum number"
        ],
        correct: "Magnetic quantum number"
      },
      {
        "question": "Who is credited with discovering the electron?",
        "options": [
          "Isaac Newton",
          "Niels Bohr",
          "J.J. Thomson",
          "Ernest Rutherford"
        ],
        correct: "J.J. Thomson"
      },
      {
        "question": "What is the mass number of an element?",
        "options": [
          "The number of protons in an atom",
          "The number of neutrons in an atom",
          "The sum of protons and neutrons in an atom",
          "The total number of electrons in an atom"
        ],
        correct: "The sum of protons and neutrons in an atom"
      },
      {
        "question": "Which of the following represents an isotope of carbon?",
        "options": [
          "Carbon-12 and Carbon-14",
          "Carbon-12 and Oxygen-16",
          "Carbon-13 and Nitrogen-14",
          "Carbon-14 and Neon-20"
        ],
        correct: "Carbon-12 and Carbon-14"
      },
      {
        "question": "Which particle has no charge in an atom?",
        "options": [
          "Electron",
          "Proton",
          "Neutron",
          "Both Electron and Proton"
        ],
        correct: "Neutron"
      },
      {
        "question": "The atomic number of an element is determined by the number of which particle?",
        "options": [
          "Protons",
          "Electrons",
          "Neutrons",
          "Isotopes"
        ],
        correct: "Protons"
      },
      {
        "question": "What is the maximum number of electrons that can be present in the second shell (energy level) of an atom?",
        "options": [
          "2",
          "4",
          "8",
          "18"
        ],
        correct: "8"
      },
      {
        "question": "What rule states that atoms tend to gain, lose, or share electrons to achieve a full outer shell of 8 electrons?",
        "options": [
          "Valence Shell Electron Pair Repulsion (VSEPR) Theory",
          "Octet Rule",
          "Hund's Rule",
          "Aufbau Principle"
        ],
        correct: "Octet Rule"
      },
      {
        "question": "What is the charge of an atom with 10 protons and 12 electrons?",
        "options": [
          "Positive",
          "Negative",
          "Neutral",
          "Unstable"
        ],
        correct: "Negative"
      },
      {
        "question": "Which of the following statements is true about isotopes?",
        "options": [
          "Isotopes have the same number of protons but different numbers of neutrons",
          "Isotopes have the same number of neutrons but different numbers of protons",
          "Isotopes have different numbers of electrons",
          "Isotopes have the same mass number"
        ],
        correct: "Isotopes have the same number of protons but different numbers of neutrons"
      },
      {
        "question": "Which of the following is an example of an isotope of hydrogen?",
        "options": [
          "Hydrogen-1",
          "Hydrogen-2 (Deuterium)",
          "Hydrogen-3 (Tritium)",
          "All of the above"
        ],
        correct: "All of the above"
      },
      {
        "question": "How many electrons can the third energy level of an atom hold?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "18"
      },
      {
        "question": "What happens when an atom gains an electron?",
        "options": [
          "It becomes positively charged",
          "It becomes negatively charged",
          "Its atomic number increases",
          "Its mass number decreases"
        ],
        correct: "It becomes negatively charged"
      },
      {
        "question": "Which of the following elements satisfies the octet rule when it forms a compound?",
        "options": [
          "Sodium (Na)",
          "Chlorine (Cl)",
          "Helium (He)",
          "Hydrogen (H)"
        ],
        correct: "Chlorine (Cl)"
      },
      {
        "question": "Which of the following statements about atomic structure is false?",
        "options": [
          "The atomic number is the number of protons in an atom.",
          "Mass number is the total number of protons and neutrons.",
          "Isotopes of an element have the same number of neutrons.",
          "The number of protons and neutrons is always equal in an atom."
        ],
        correct: "The number of protons and neutrons is always equal in an atom."
      },
      {
        "question": "What is the atomic number of oxygen (O)?",
        "options": [
          "6",
          "8",
          "10",
          "16"
        ],
        correct: "8"
      },
      {
        "question": "Which of the following is true about the mass number of an atom?",
        "options": [
          "It is the sum of the protons, neutrons, and electrons",
          "It is always equal to the number of protons",
          "It can change depending on the number of neutrons",
          "It is the same for all isotopes of an element"
        ],
        correct: "It can change depending on the number of neutrons"
      },
      {
        "question": "Which element has an atomic number of 12?",
        "options": [
          "Sodium (Na)",
          "Magnesium (Mg)",
          "Aluminum (Al)",
          "Silicon (Si)"
        ],
        correct: "Magnesium (Mg)"
      },
      {
        "question": "Which of the following best describes an isotope?",
        "options": [
          "Atoms of the same element with different numbers of protons",
          "Atoms of the same element with different numbers of neutrons",
          "Atoms of different elements with the same number of protons",
          "Atoms with the same number of electrons"
        ],
        correct: "Atoms of the same element with different numbers of neutrons"
      },
      {
        "question": "What is the electron configuration for an oxygen atom (atomic number 8)?",
        "options": [
          "1s^2 2s^2 2p^4",
          "1s^2 2s^2 2p^2",
          "1s^2 2s^2 2p^6",
          "1s^2 2s^2"
        ],
        correct: "1s^2 2s^2 2p^4"
      },
      {
        "question": "How many valence electrons are in an atom of neon (Ne)?",
        "options": [
          "1",
          "2",
          "8",
          "10"
        ],
        correct: "8"
      },
      {
        "question": "What is the octet rule?",
        "options": [
          "Atoms prefer to have 8 protons in their nucleus",
          "Atoms prefer to have 8 neutrons in their nucleus",
          "Atoms prefer to have 8 electrons in their outer shell",
          "Atoms prefer to have 8 electrons in their inner shell"
        ],
        correct: "Atoms prefer to have 8 electrons in their outer shell"
      },
      {
        "question": "Which of the following elements follows the octet rule when forming bonds?",
        "options": [
          "Hydrogen (H)",
          "Oxygen (O)",
          "Helium (He)",
          "Sodium (Na)"
        ],
        correct: "Oxygen (O)"
      },
      {
        "question": "An atom of carbon has an atomic number of 6. How many electrons does it have?",
        "options": [
          "6",
          "8",
          "12",
          "14"
        ],
        correct: "6"
      },
      {
        "question": "What is the atomic number of an atom that has 13 protons?",
        "options": [
          "13",
          "26",
          "12",
          "14"
        ],
        correct: "13"
      },
      {
        "question": "If an element has an atomic number of 15, how many electrons does it have in its neutral state?",
        "options": [
          "15",
          "8",
          "30",
          "16"
        ],
        correct: "15"
      },
      {
        "question": "Which of the following particles is responsible for the mass number of an atom?",
        "options": [
          "Protons and neutrons",
          "Electrons",
          "Protons",
          "Neutrons"
        ],
        correct: "Protons and neutrons"
      },
      {
        "question": "What is the number of neutrons in a sodium (Na) atom with a mass number of 23?",
        "options": [
          "11",
          "12",
          "23",
          "22"
        ],
        correct: "12"
      },
      {
        "question": "Which of the following statements about the atomic number is true?",
        "options": [
          "It represents the number of protons in an atom",
          "It is the sum of protons and neutrons in an atom",
          "It is the number of electrons in an atom",
          "It varies between isotopes of the same element"
        ],
        correct: "It represents the number of protons in an atom"
      },
      {
        "question": "What is the most common isotope of hydrogen?",
        "options": [
          "Hydrogen-1",
          "Hydrogen-2",
          "Hydrogen-3",
          "Hydrogen-4"
        ],
        correct: "Hydrogen-1"
      },
      {
        "question": "Which of the following isotopes of oxygen has a mass number of 18?",
        "options": [
          "Oxygen-16",
          "Oxygen-17",
          "Oxygen-18",
          "Oxygen-19"
        ],
        correct: "Oxygen-18"
      },
      {
        "question": "Which of the following elements would most likely form an anion?",
        "options": [
          "Magnesium (Mg)",
          "Chlorine (Cl)",
          "Sodium (Na)",
          "Calcium (Ca)"
        ],
        correct: "Chlorine (Cl)"
      },
      {
        "question": "What is the mass number of an atom with 6 protons, 6 neutrons, and 6 electrons?",
        "options": [
          "6",
          "12",
          "18",
          "24"
        ],
        correct: "12"
      },
      {
        "question": "How many protons, neutrons, and electrons are in an atom of sulfur-32 (atomic number 16)?",
        "options": [
          "16 protons, 16 neutrons, 16 electrons",
          "16 protons, 32 neutrons, 16 electrons",
          "16 protons, 16 neutrons, 32 electrons",
          "32 protons, 16 neutrons, 16 electrons"
        ],
        correct: "16 protons, 16 neutrons, 16 electrons"
      },
      {
        "question": "Which statement is true about electrons in an atom?",
        "options": [
          "Electrons are located in the nucleus",
          "Electrons have a positive charge",
          "Electrons move in energy levels or shells around the nucleus",
          "Electrons have the same mass as neutrons"
        ],
        correct: "Electrons move in energy levels or shells around the nucleus"
      },
      {
        "question": "What is the octet rule used to predict?",
        "options": [
          "The number of electrons in an atom's nucleus",
          "The number of neutrons in an atom",
          "The bonding behavior of an atom in a molecule",
          "The number of protons in an atom"
        ],
        correct: "The bonding behavior of an atom in a molecule"
      },
      {
        "question": "What is the difference between an isotope and an ion?",
        "options": [
          "Isotopes have different numbers of neutrons, ions have different numbers of electrons",
          "Isotopes have different numbers of protons, ions have different numbers of neutrons",
          "Isotopes have the same number of protons, ions have different numbers of protons",
          "Isotopes have the same mass number, ions have different atomic numbers"
        ],
        correct: "Isotopes have different numbers of neutrons, ions have different numbers of electrons"
      },
      {
        "question": "Which of the following is the isotope of chlorine with a mass number of 35?",
        "options": [
          "Chlorine-33",
          "Chlorine-34",
          "Chlorine-35",
          "Chlorine-36"
        ],
        correct: "Chlorine-35"
      },
      {
        "question": "How many valence electrons are in an atom of chlorine (Cl)?",
        "options": [
          "7",
          "8",
          "9",
          "6"
        ],
        correct: "7"
      },
      {
        "question": "Which of the following elements has the same number of protons and electrons in its neutral state?",
        "options": [
          "Carbon",
          "Neon",
          "Sodium",
          "Chlorine"
        ],
        correct: "Neon"
      },
      {
        "question": "What is the mass number of an atom of nitrogen (atomic number 7) with 7 neutrons?",
        "options": [
          "7",
          "14",
          "15",
          "21"
        ],
        correct: "14"
      },
      {
        "question": "What is the atomic number of an element?",
        "options": [
          "The number of protons in the nucleus",
          "The number of neutrons in the nucleus",
          "The number of electrons in an atom",
          "The sum of protons and neutrons"
        ],
        correct: "The number of protons in the nucleus"
      },
      {
        "question": "What does the mass number of an atom represent?",
        "options": [
          "The number of protons",
          "The number of neutrons",
          "The total number of protons and neutrons",
          "The number of electrons"
        ],
        correct: "The total number of protons and neutrons"
      },
      {
        "question": "Isotopes of an element have the same number of:",
        "options": [
          "Protons",
          "Neutrons",
          "Electrons",
          "Neutrons and Protons"
        ],
        correct: "Protons"
      },
      {
        "question": "Which of the following is a correct representation of an isotope?",
        "options": [
          "C-12 and C-14",
          "Na-23 and Na-24",
          "O-16 and O-18",
          "All of the above"
        ],
        correct: "All of the above"
      },
      {
        "question": "What is the maximum number of electrons that can occupy the third shell of an atom?",
        "options": [
          "8",
          "18",
          "32",
          "2"
        ],
        correct: "18"
      },
      {
        "question": "Which rule states that electrons fill orbitals from lower energy to higher energy?",
        "options": [
          "Hund's Rule",
          "Aufbau Principle",
          "Pauli Exclusion Principle",
          "Octet Rule"
        ],
        correct: "Aufbau Principle"
      },
      {
        "question": "The maximum number of electrons in the second shell of an atom is:",
        "options": [
          "8",
          "18",
          "2",
          "10"
        ],
        correct: "8"
      },
      {
        "question": "What is the atomic number of Carbon?",
        "options": [
          "6",
          "12",
          "14",
          "8"
        ],
        correct: "6"
      },
      {
        "question": "What is the general term for the sum of protons and neutrons in an atom?",
        "options": [
          "Mass number",
          "Atomic number",
          "Isotope number",
          "Electron number"
        ],
        correct: "Mass number"
      },
      {
        "question": "How many neutrons are in the isotope Carbon-14?",
        "options": [
          "6",
          "8",
          "10",
          "14"
        ],
        correct: "8"
      },
      {
        "question": "Which of the following atoms satisfies the octet rule?",
        "options": [
          "He",
          "Li",
          "Na",
          "F"
        ],
        correct: "F"
      },
      {
        "question": "Which of the following elements will have the same atomic number?",
        "options": [
          "Isotopes of oxygen",
          "Different elements",
          "Atoms of the same molecule",
          "Atoms of the same ion"
        ],
        correct: "Isotopes of oxygen"
      },
      {
        "question": "The number of protons and neutrons in an atom is the:",
        "options": [
          "Mass number",
          "Atomic number",
          "Electron number",
          "Isotope number"
        ],
        correct: "Mass number"
      },
      {
        "question": "Which of the following elements has an atomic number of 15?",
        "options": [
          "Phosphorus",
          "Silicon",
          "Sulfur",
          "Sodium"
        ],
        correct: "Phosphorus"
      },
      {
        "question": "Which of the following is true for an atom of oxygen-16 and oxygen-18?",
        "options": [
          "They have the same number of protons",
          "They have the same mass number",
          "They have different chemical properties",
          "They have the same number of neutrons"
        ],
        correct: "They have the same number of protons"
      },
      {
        "question": "Which element satisfies the octet rule with a full outer shell of 8 electrons?",
        "options": [
          "Oxygen",
          "Neon",
          "Sodium",
          "Hydrogen"
        ],
        correct: "Neon"
      },
      {
        "question": "The number of protons in an atom is equal to its:",
        "options": [
          "Atomic number",
          "Mass number",
          "Neutron number",
          "Electron number"
        ],
        correct: "Atomic number"
      },
      {
        "question": "How many electrons can occupy the first shell of an atom?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "2"
      },
      {
        "question": "The Octet Rule is applicable to which element?",
        "options": [
          "Noble gases",
          "Metals",
          "Non-metals",
          "All elements"
        ],
        correct: "Noble gases"
      },
      {
        "question": "Which of the following is a characteristic of an isotope?",
        "options": [
          "Same number of neutrons",
          "Different number of neutrons",
          "Same number of protons",
          "Different atomic number"
        ],
        correct: "Different number of neutrons"
      },
      {
        "question": "What is the mass number of an atom with 6 protons and 8 neutrons?",
        "options": [
          "14",
          "6",
          "8",
          "16"
        ],
        correct: "14"
      },
      {
        "question": "What does the atomic number of an element represent?",
        "options": [
          "The number of neutrons in an atom",
          "The number of protons in the nucleus",
          "The total number of electrons",
          "The total number of protons and neutrons"
        ],
        correct: "The number of protons in the nucleus"
      },
      {
        "question": "Isotopes of the same element differ in their:",
        "options": [
          "Number of protons",
          "Number of neutrons",
          "Number of electrons",
          "Chemical properties"
        ],
        correct: "Number of neutrons"
      },
      {
        "question": "The mass number of an element is equal to:",
        "options": [
          "The number of protons",
          "The number of neutrons",
          "The sum of protons and neutrons",
          "The number of electrons"
        ],
        correct: "The sum of protons and neutrons"
      },
      {
        "question": "The atomic number of an atom is 12. What is the number of electrons in its neutral state?",
        "options": [
          "12",
          "6",
          "24",
          "18"
        ],
        correct: "12"
      },
      {
        "question": "Which of the following atoms will satisfy the octet rule?",
        "options": [
          "Li",
          "Be",
          "Ne",
          "H"
        ],
        correct: "Ne"
      },
      {
        "question": "The number of protons and electrons in a neutral atom is always equal to its:",
        "options": [
          "Mass number",
          "Atomic number",
          "Electron configuration",
          "Neutron number"
        ],
        correct: "Atomic number"
      },
      {
        "question": "The maximum number of electrons in the third shell is:",
        "options": [
          "8",
          "18",
          "32",
          "2"
        ],
        correct: "18"
      },
      {
        "question": "Which of the following is an example of an isotope of hydrogen?",
        "options": [
          "Hydrogen",
          "Deuterium",
          "Tritium",
          "Both B and C"
        ],
        correct: "Both B and C"
      },
      {
        "question": "Which principle states that electrons fill orbitals from lower to higher energy?",
        "options": [
          "Pauli Exclusion Principle",
          "Hund's Rule",
          "Aufbau Principle",
          "Octet Rule"
        ],
        correct: "Aufbau Principle"
      },
      {
        "question": "Which of the following atoms will follow the octet rule?",
        "options": [
          "Helium",
          "Lithium",
          "Beryllium",
          "Sodium"
        ],
        correct: "Helium"
      },
      {
        "question": "What is the atomic number of Chlorine?",
        "options": [
          "17",
          "18",
          "19",
          "16"
        ],
        correct: "17"
      },
      {
        "question": "Which element has an atomic number of 7?",
        "options": [
          "Nitrogen",
          "Oxygen",
          "Carbon",
          "Hydrogen"
        ],
        correct: "Nitrogen"
      },
      {
        "question": "What is the number of neutrons in an isotope of chlorine with a mass number of 37?",
        "options": [
          "18",
          "20",
          "19",
          "17"
        ],
        correct: "20"
      },
      {
        "question": "The number of electrons in the outermost shell of an atom is referred to as:",
        "options": [
          "Valence electrons",
          "Core electrons",
          "Orbitals",
          "Neutrons"
        ],
        correct: "Valence electrons"
      },
      {
        "question": "Which of the following elements has the largest atomic number?",
        "options": [
          "Carbon",
          "Oxygen",
          "Nitrogen",
          "Helium"
        ],
        correct: "Oxygen"
      },
      {
        "question": "An atom of Carbon has how many protons?",
        "options": [
          "12",
          "6",
          "10",
          "8"
        ],
        correct: "6"
      },
      {
        "question": "Which of the following pairs are isotopes of each other?",
        "options": [
          "Oxygen-16 and Oxygen-18",
          "Oxygen-18 and Nitrogen-18",
          "Hydrogen and Carbon",
          "Sodium-23 and Sodium-24"
        ],
        correct: "Oxygen-16 and Oxygen-18"
      },
      {
        "question": "The octet rule is most commonly observed in which type of elements?",
        "options": [
          "Metals",
          "Non-metals",
          "Noble gases",
          "Transition elements"
        ],
        correct: "Noble gases"
      },
      {
        "question": "What is the number of protons in the isotope Carbon-12?",
        "options": [
          "12",
          "6",
          "14",
          "8"
        ],
        correct: "6"
      },
      {
        "question": "What defines the atomic number of an element?",
        "options": [
          "Number of neutrons",
          "Number of protons",
          "Sum of protons and neutrons",
          "Number of electrons"
        ],
        correct: "Number of protons"
      },
      {
        "question": "What is the mass number of an atom?",
        "options": [
          "Number of protons",
          "Number of electrons",
          "Number of neutrons",
          "Sum of protons and neutrons"
        ],
        correct: "Sum of protons and neutrons"
      },
      {
        "question": "What is the atomic number of Hydrogen?",
        "options": [
          "1",
          "2",
          "3",
          "0"
        ],
        correct: "1"
      },
      {
        "question": "Which rule describes that atoms tend to gain, lose, or share electrons to have eight electrons in the outermost shell?",
        "options": [
          "Octet Rule",
          "Aufbau Principle",
          "Hund's Rule",
          "Pauli Exclusion Principle"
        ],
        correct: "Octet Rule"
      },
      {
        "question": "Isotopes of an element differ in their:",
        "options": [
          "Atomic number",
          "Mass number",
          "Electrons",
          "Both atomic number and mass number"
        ],
        correct: "Mass number"
      },
      {
        "question": "What is the number of neutrons in Carbon-14?",
        "options": [
          "6",
          "7",
          "8",
          "14"
        ],
        correct: "8"
      },
      {
        "question": "Which of the following elements satisfy the octet rule?",
        "options": [
          "Sodium",
          "Helium",
          "Oxygen",
          "All of the above"
        ],
        correct: "Helium"
      },
      {
        "question": "What is the number of electrons in the first shell of an atom?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "2"
      },
      {
        "question": "What is the correct symbol for the isotope of carbon with a mass number of 12?",
        "options": [
          "C-12",
          "C-14",
          "C-16",
          "C-18"
        ],
        correct: "C-12"
      },
      {
        "question": "Which of the following elements has an atomic number of 7?",
        "options": [
          "Carbon",
          "Nitrogen",
          "Oxygen",
          "Hydrogen"
        ],
        correct: "Nitrogen"
      },
      {
        "question": "Which of the following is true for isotopes of the same element?",
        "options": [
          "Same number of protons and neutrons",
          "Different number of protons",
          "Same number of protons",
          "Different number of protons"
        ],
        correct: "Same number of protons"
      },
      {
        "question": "What is the maximum number of electrons in the third shell?",
        "options": [
          "2",
          "8",
          "18",
          "32"
        ],
        correct: "18"
      },
      {
        "question": "The atomic number is equal to the number of:",
        "options": [
          "Neutrons",
          "Protons",
          "Electrons",
          "Both protons and neutrons"
        ],
        correct: "Protons"
      },
      {
        "question": "How many neutrons does a chlorine atom with mass number 37 have?",
        "options": [
          "18",
          "19",
          "20",
          "17"
        ],
        correct: "20"
      },
      {
        "question": "What is the atomic number of Neon?",
        "options": [
          "8",
          "10",
          "12",
          "14"
        ],
        correct: "10"
      },
      {
        "question": "Which of the following elements has 18 electrons in its neutral state?",
        "options": [
          "Neon",
          "Oxygen",
          "Sodium",
          "Chlorine"
        ],
        correct: "Neon"
      },
      {
        "question": "What is the number of protons in an oxygen atom?",
        "options": [
          "8",
          "16",
          "12",
          "6"
        ],
        correct: "8"
      },
      {
        "question": "Which element has the atomic number 16?",
        "options": [
          "Oxygen",
          "Sulfur",
          "Nitrogen",
          "Carbon"
        ],
        correct: "Sulfur"
      },
      {
        "question": "Which of the following is an isotope of Carbon?",
        "options": [
          "Carbon-12",
          "Carbon-14",
          "Both A and B",
          "None of the above"
        ],
        correct: "Both A and B"
      },
      {
        "question": "Which element satisfies the octet rule in its ionic form?",
        "options": [
          "Oxygen",
          "Fluorine",
          "Neon",
          "Sodium"
        ],
        correct: "Neon"
      }
    
]