import React from "react";
import { motion } from "framer-motion";
import ReactionComponent from './ReactionComponent';
const ReactionTypes = () => {
  const energyVariants = {
    initial: { opacity: 0, scale: 0.5 },
    animate: { opacity: 1, scale: 1, transition: { duration: 1 } },
    exit: { opacity: 0, scale: 0.5, transition: { duration: 1 } },
  };

  const displacementArrowVariants = {
    initial: { opacity: 0, x: -50 },
    animate: { opacity: 1, x: 0, transition: { duration: 1 } },
    exit: { opacity: 0, x: -50, transition: { duration: 1 } },
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Chemical Reactions: Displacement vs Double Displacement</h1>

      {/* Displacement Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Displacement Reaction</h2>
        <p>
          A displacement reaction occurs when a more reactive element replaces a
          less reactive element in a compound. For example, zinc displaces copper
          in copper sulfate.
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Example: CuSO₄ (aq) + Zn (s) → ZnSO₄ (aq) + Cu (s)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0",
            position: "relative",
          }}
        >
          {/* Reactants */}
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            CuSO₄
          </motion.div>
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#6EC2F0",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            Zn
          </motion.div>

          {/* Energy Arrow */}
          <motion.div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              color: "#FFD700",
              fontWeight: "bold",
              fontSize: "1.2rem",
            }}
            variants={displacementArrowVariants}
            initial="initial"
            animate="animate"
          >
            🔄 Displacement
          </motion.div>
        </motion.div>
      </div>

      {/* Double Displacement Reaction */}
      <div style={{ margin: "30px 0" }}>
        <h2>Double Displacement Reaction</h2>
        <p>
          A double displacement reaction occurs when parts of two ionic compounds
          are exchanged to form two new compounds. For example, sodium sulfate and
          barium chloride react to form barium sulfate and sodium chloride.
        </p>
        <p style={{ fontStyle: "italic", fontWeight: "bold" }}>
          Example: Na₂SO₄ (aq) + BaCl₂ (aq) → BaSO₄ (s) + 2NaCl (aq)
        </p>
        <motion.div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "20px",
            margin: "20px 0",
            position: "relative",
          }}
        >
          {/* Reactants */}
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#FF6F61",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            Na₂SO₄
          </motion.div>
          <motion.div
            style={{
              width: "120px",
              height: "120px",
              backgroundColor: "#6EC2F0",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              fontWeight: "bold",
            }}
            variants={energyVariants}
            initial="initial"
            animate="animate"
          >
            BaCl₂
          </motion.div>

          {/* Energy Arrow */}
          <motion.div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              color: "#FFD700",
              fontWeight: "bold",
              fontSize: "1.2rem",
            }}
            variants={displacementArrowVariants}
            initial="initial"
            animate="animate"
          >
            ↔ Exchange of Ions
          </motion.div>
        </motion.div>
      </div>
      <ReactionComponent />
    </div>
  );
};

export default ReactionTypes;
