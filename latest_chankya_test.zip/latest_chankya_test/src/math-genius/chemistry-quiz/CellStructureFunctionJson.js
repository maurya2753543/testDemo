export const quizQuestions = [  
    {
        "question": "What is the smallest unit of life in a cell?",
        "options": [
          "Atom",
          "Molecule",
          "Organelle",
          "Cell"
        ],
        correct: "Cell"
    },
    {
        "question": "Which part of the cell contains genetic material?",
        "options": [
          "Nucleus",
          "Mitochondria",
          "Cytoplasm",
          "Golgi apparatus"
        ],
        correct: "Nucleus"
    },
    {
        "question": "Rutherford’s alpha-particle scattering experiment was responsible for the discovery of:",
        "options": [
          "Atomic nucleus",
          "Electron",
          "Proton",
          "Neutron"
        ],
        correct: "Atomic nucleus"
    },
    {
        "question": "Isotopes of an element have:",
        "options": [
          "The same physical properties",
          "Different chemical properties",
          "Different number of neutrons",
          "Different atomic numbers"
        ],
        correct: "Different number of neutrons"
    },
    {
        "question": "Number of valence electrons in Cl⁻ ion is:",
        "options": [
          "16",
          "8",
          "17",
          "18"
        ],
        correct: "8"
    },
    {
        "question": "Which one of the following is a correct electronic configuration of sodium?",
        "options": [
          "2, 8",
          "8, 2, 1",
          "2, 1, 8",
          "2, 8, 1"
        ],
        correct: "2, 8, 1"
    },
    {
        "question": "Which subatomic particle contributes to the atomic number of an element?",
        "options": [
          "Proton",
          "Electron",
          "Neutron",
          "All of the above"
        ],
        correct: "Proton"
    },
    {
        "question": "Who proposed the plum pudding model of the atom?",
        "options": [
          "Ernest Rutherford",
          "J.J. Thomson",
          "Niels Bohr",
          "James Chadwick"
        ],
        correct: "J.J. Thomson"
    },
    {
        "question": "What is the charge of an electron?",
        "options": [
          "Positive",
          "Negative",
          "Neutral",
          "Depends on the atom"
        ],
        correct: "Negative"
    },
    {
        "question": "What is the mass of a neutron compared to a proton?",
        "options": [
          "Equal to proton",
          "Less than proton",
          "More than proton",
          "Zero mass"
        ],
        correct: "Equal to proton"
    },
    {
        "question": "Which particle was discovered by James Chadwick?",
        "options": [
          "Electron",
          "Proton",
          "Neutron",
          "Positron"
        ],
        correct: "Neutron"
    },
    {
        "question": "Which of the following is true about isotopes?",
        "options": [
          "Same atomic number, different mass number",
          "Same mass number, different atomic number",
          "Different physical properties, same chemical properties",
          "All isotopes are radioactive"
        ],
        correct: "Same atomic number, different mass number"
    },
    {
        "question": "In a neutral atom, the number of protons is equal to the number of:",
        "options": [
          "Neutrons",
          "Electrons",
          "Nucleons",
          "Isotopes"
        ],
        correct: "Electrons"
    },
    {
        "question": "Which of the following particles has negligible mass?",
        "options": [
          "Electron",
          "Proton",
          "Neutron",
          "Nucleus"
        ],
        correct: "Electron"
    },
    {
        "question": "What is the charge on a chloride ion (Cl⁻)?",
        "options": [
          "-1",
          "0",
          "+1",
          "-2"
        ],
        correct: "-1"
    },
    {
        "question": "What is the number of neutrons in Carbon-14?",
        "options": [
          "6",
          "7",
          "8",
          "14"
        ],
        correct: "8"
    },
    {
        "question": "Which scientist developed the modern atomic theory?",
        "options": [
          "John Dalton",
          "J.J. Thomson",
          "Niels Bohr",
          "Ernest Rutherford"
        ],
        correct: "John Dalton"
    },
    {
        "question": "Which of the following has the highest bond angle?",
        "options": [
            "H2O",
            "NH3",
            "CH4",
            "BF3"
        ],
        correct: "BF3"
    },
    {
        "question": "The pH of a 0.001 M HCl solution is:",
        "options": [
            "1",
            "2",
            "3",
            "4"
        ],
        correct: "3"
    },
    {
        "question": "Which of the following is an example of a state function?",
        "options": [
            "Heat (q)",
            "Work (w)",
            "Enthalpy (H)",
            "None of the above"
        ],
        correct: "Enthalpy (H)"
    },
    {
        "question": "Which of the following pairs are isoelectronic?",
        "options": [
            "Na⁺ and Mg²⁺",
            "Cl⁻ and Ar",
            "O²⁻ and S²⁻",
            "N³⁻ and F⁻"
        ],
        correct: "Cl⁻ and Ar"
    },
    {
        "question": "What is the oxidation number of sulfur in H₂SO₄?",
        "options": [
            "+4",
            "+6",
            "-2",
            "+2"
        ],
        correct: "+6"
    },
    {
        "question": "The hybridization of carbon in diamond is:",
        "options": [
            "sp",
            "sp2",
            "sp3",
            "None of these"
        ],
        correct: "sp3"
    },
    {
        "question": "Which gas is evolved when zinc reacts with dilute sulfuric acid?",
        "options": [
            "Oxygen",
            "Hydrogen",
            "Carbon dioxide",
            "Nitrogen"
        ],
        correct: "Hydrogen"
    },
    {
        "question": "Which of the following compounds does not exhibit hydrogen bonding?",
        "options": [
            "H2O",
            "NH3",
            "HCl",
            "HF"
        ],
        correct: "HCl"
    },
    {
        "question": "The first law of thermodynamics is a statement of:",
        "options": [
            "Law of conservation of momentum",
            "Law of conservation of energy",
            "Law of conservation of mass",
            "None of the above"
        ],
        correct: "Law of conservation of energy"
    },
    {
        "question": "Which among the following is the most stable carbocation?",
        "options": [
            "CH3⁺",
            "C2H5⁺",
            "C6H5CH2⁺",
            "(CH3)3C⁺"
        ],
        correct: "(CH3)3C⁺"
    },
    {
        "question": "The rate constant of a first-order reaction is 0.693 min⁻¹. The time taken to complete 50% of the reaction is:",
        "options": [
            "0.1 min",
            "1 min",
            "10 min",
            "None of these"
        ],
        correct: "1 min"
    },
    {
        "question": "Which of the following is not a colligative property?",
        "options": [
            "Boiling point elevation",
            "Freezing point depression",
            "Osmotic pressure",
            "Viscosity"
        ],
        correct: "Viscosity"
    },
    {
        "question": "What is the shape of PCl₅ according to VSEPR theory?",
        "options": [
            "Tetrahedral",
            "Square planar",
            "Trigonal bipyramidal",
            "Octahedral"
        ],
        correct: "Trigonal bipyramidal"
    },
    {
        "question": "Which of the following oxides is amphoteric?",
        "options": [
            "Na2O",
            "Al2O3",
            "SiO2",
            "SO2"
        ],
        correct: "Al2O3"
    },
    {
        "question": "What is the equivalent weight of KMnO₄ in an acidic medium?",
        "options": [
            "Molar mass",
            "Molar mass/2",
            "Molar mass/3",
            "Molar mass/5"
        ],
        correct: "Molar mass/5"
    },
    {
        "question": "Which of the following has the highest ionization energy?",
        "options": [
            "Oxygen",
            "Nitrogen",
            "Fluorine",
            "Sulfur"
        ],
       correct: "Fluorine"
    },
    {
        "question": "Which of the following compounds will show geometrical isomerism?",
        "options": [
            "Butane",
            "2-Butene",
            "Propane",
            "Methane"
        ],
       correct: "2-Butene"
    },
    {
        "question": "The SI unit of molar conductivity is:",
        "options": [
            "S cm⁻¹ mol⁻¹",
            "S m² mol⁻¹",
            "S m⁻¹ mol⁻¹",
            "S cm² mol⁻¹"
        ],
       correct: "S m² mol⁻¹"
    },
    {
        "question": "What is the main component of natural gas?",
        "options": [
            "Ethane",
            "Methane",
            "Propane",
            "Butane"
        ],
       correct: "Methane"
    },
    {
        "question": "Which reagent is used to distinguish between aldehydes and ketones?",
        "options": [
            "Fehling's solution",
            "Benedict's solution",
            "Tollens' reagent",
            "All of the above"
        ],
       correct: "Tollens' reagent"
    },
    {
        "question": "Which gas is liberated when zinc reacts with hydrochloric acid?",
        "options": [
            "Oxygen",
            "Hydrogen",
            "Carbon dioxide",
            "Chlorine"
        ],
       correct: "Hydrogen"
    },
    {
        "question": "The equivalent weight of H₂SO₄ in its reaction with NaOH is:",
        "options": [
            "Molar mass/1",
            "Molar mass/2",
            "Molar mass/3",
            "Molar mass/4"
        ],
       correct: "Molar mass/2"
    },
    {
        "question": "Which among the following is not an electrolyte?",
        "options": [
            "NaCl",
            "Glucose",
            "KNO₃",
            "H₂SO₄"
        ],
       correct: "Glucose"
    },
    {
        "question": "What is the shape of XeF₄ according to VSEPR theory?",
        "options": [
            "Square planar",
            "Tetrahedral",
            "Trigonal bipyramidal",
            "Octahedral"
        ],
       correct: "Square planar"
    },
    {
        "question": "Which of the following is an example of a Lewis acid?",
        "options": [
            "H₂O",
            "NH₃",
            "BF₃",
            "CH₄"
        ],
       correct: "BF₃"
    },
    {
        "question": "Which of the following is the most abundant element in Earth's crust?",
        "options": [
            "Silicon",
            "Aluminum",
            "Oxygen",
            "Iron"
        ],
        correct: "Oxygen"
    },
    {
        "question": "Which type of hybridization is involved in methane (CH₄)?",
        "options": [
            "sp",
            "sp²",
            "sp³",
            "None"
        ],
        correct: "sp³"
    },
    {
        "question": "Which of the following is a primary standard substance in titration?",
        "options": [
            "NaOH",
            "K₂Cr₂O₇",
            "H₂SO₄",
            "HCl"
        ],
        correct: "K₂Cr₂O₇"
    },
    {
        "question": "The bond order of nitrogen (N₂) molecule is:",
        "options": [
            "1",
            "2",
            "3",
            "4"
        ],
        correct: "3"
    },
    {
        "question": "Which of the following is used in the preparation of soap?",
        "options": [
            "Ethanol",
            "Glycerol",
            "Fatty acids",
            "Acetic acid"
        ],
        correct: "Fatty acids"
    },
    {
        "question": "What is the IUPAC name of CH₃COOH?",
        "options": [
            "Methanoic acid",
            "Ethanoic acid",
            "Propanoic acid",
            "Acetic acid"
        ],
        correct: "Ethanoic acid"
    },
    {
        "question": "The number of moles of solute in 1 liter of a 1 M solution is:",
        "options": [
            "0.5 moles",
            "1 mole",
            "2 moles",
            "None of these"
        ],
        correct: "1 mole"
    },
    {
        "question": "Which of the following is an example of an alloy?",
        "options": [
            "Iron",
            "Bronze",
            "Copper",
            "Gold"
        ],
        correct: "Bronze"
    },
    {
        "question": "Which element forms the basis of organic chemistry?",
        "options": [
            "Oxygen",
            "Nitrogen",
            "Carbon",
            "Hydrogen"
        ],
        correct: "Carbon"
    },
    {
        "question": "Which of the following compounds is aromatic?",
        "options": [
            "Cyclohexane",
            "Benzene",
            "Methane",
            "Ethene"
        ],
        correct: "Benzene"
    }
    
    

]