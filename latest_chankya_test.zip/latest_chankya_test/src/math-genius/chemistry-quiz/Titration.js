import React, { useState } from 'react';
import './Titration.css';
import TitrationQuiz from './TitrationQuiz';
const Titration = () => {
  const [result, setResult] = useState('');
  const [isTitrating, setIsTitrating] = useState(false); // To control the titration state
  const [liquidHeight, setLiquidHeight] = useState(0); // To track the liquid height

  const neutralizationReaction =
    'HCl(aq) + NaOH(aq) → NaCl(aq) + H2O(l)\n\n' +
    'One mole of HCl would be fully neutralized by one mole of NaOH.\n\n' +
    'If hydrochloric acid is reacted with barium hydroxide, the mole ratio is 2:1:\n\n' +
    '2HCl(aq) + Ba(OH)2(aq) → BaCl2(aq) + 2H2O(l)\n\n' +
    'Two moles of HCl are required to neutralize one mole of Ba(OH)2.';

  const handleStartTitration = () => {
    setResult('');
    setIsTitrating(true);
    setLiquidHeight(0);
    let progress = 0;

    // Simulate titration progress (update liquid height and result text)
    const interval = setInterval(() => {
      if (progress < 100) {
        progress += 10;
        setLiquidHeight(progress);
      } else {
        clearInterval(interval); // Stop when the titration reaches 100%
      }
    }, 500);

    // Set the neutralization reaction result when the titration starts
    setResult(`Titration in progress...\n\nNeutralization Reaction:\n${neutralizationReaction}`);
  };

  const handleStopTitration = () => {
    setIsTitrating(false);
    setResult('Titration stopped.');
  };

  return (
    <>
     <div className="titration-container">
      <h1 style={{marginTop : '140px'}}>Titration Experiment</h1>
      <div className="button-container">
        <button className="start-button" onClick={handleStartTitration} disabled={isTitrating}>
          Start Titration
        </button>
        <button className="stop-button" onClick={handleStopTitration} disabled={!isTitrating}>
          Stop Titration
        </button>
      </div>

      <div className="flask-animation">
        <div className="buret">
          <div className="liquid" style={{ height: `${liquidHeight}%` }}></div>
        </div>
        <div className="flask">
          <div className="indicator"></div>
        </div>
      </div>

      <pre className="result-text">{result}</pre>
    </div>
    <div style={{marginTop: '130px'}}>
    <TitrationQuiz />

    </div>

    </>
   
  );
};

export default Titration;
