export const quizQuestions = [ {
    "question": "What is the definition of matter?",
    "options": [
      "Anything that has mass and occupies space",
      "Anything that is visible to the naked eye",
      "Anything that is in motion",
      "Anything that can be touched"
    ],
    correct: "Anything that has mass and occupies space"
  },
  {
    "question": "Which of the following is NOT a state of matter?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Plasma"
  },
  {
    "question": "What is a characteristic of matter in the solid state?",
    "options": [
      "Has a fixed shape but no fixed volume",
      "Has no fixed shape and no fixed volume",
      "Has a fixed shape and fixed volume",
      "Expands to fill the container"
    ],
    correct: "Has a fixed shape and fixed volume"
  },
  {
    "question": "In which state does matter have a fixed volume but no fixed shape?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Liquid"
  },
  {
    "question": "What characteristic defines the gas state of matter?",
    "options": [
      "Has a fixed volume and fixed shape",
      "Has no fixed volume or shape",
      "Has a fixed shape but no fixed volume",
      "Is the most dense state of matter"
    ],
    correct: "Has no fixed volume or shape"
  },
  {
    "question": "Which of the following statements about matter in the gas state is true?",
    "options": [
      "Molecules are closely packed together",
      "Molecules are spread far apart and move freely",
      "Molecules are tightly packed but can move around",
      "Molecules are closely packed but vibrate in place"
    ],
    correct: "Molecules are spread far apart and move freely"
  },
  {
    "question": "Which state of matter has molecules that vibrate but do not move around?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "What happens to the shape and volume of matter when it changes from solid to liquid?",
    "options": [
      "The volume changes but the shape stays the same",
      "The shape and volume remain the same",
      "The shape changes but the volume stays the same",
      "Both shape and volume change"
    ],
    correct: "The shape changes but the volume stays the same"
  },
  {
    "question": "Which of the following is an example of matter in the liquid state?",
    "options": [
      "Water",
      "Ice",
      "Air",
      "Iron"
    ],
    correct: "Water"
  },
  {
    "question": "What is a common characteristic of matter in the gas state?",
    "options": [
      "Takes the shape of the container but not the volume",
      "Has a fixed shape and volume",
      "Expands to fill the container",
      "Is the most dense state of matter"
    ],
    correct: "Expands to fill the container"
  },
  {
    "question": "At which temperature do most substances transition from a solid to a liquid?",
    "options": [
      "Below freezing point",
      "At absolute zero",
      "At boiling point",
      "At the melting point"
    ],
    correct: "At the melting point"
  },
  {
    "question": "Which state of matter is the least dense?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "Which of the following is an example of matter in the solid state?",
    "options": [
      "Water",
      "Air",
      "Ice",
      "Oil"
    ],
    correct: "Ice"
  },
  {
    "question": "What happens to the particles of matter when it changes from gas to liquid?",
    "options": [
      "Particles lose energy and move closer together",
      "Particles gain energy and move farther apart",
      "Particles lose energy and spread farther apart",
      "Particles stay in the same position"
    ],
    correct: "Particles lose energy and move closer together"
  },
  {
    "question": "What is the main difference between liquid and gas states of matter?",
    "options": [
      "Liquids have a fixed volume, gases do not",
      "Liquids take the shape of the container, gases do not",
      "Liquids expand to fill the container, gases do not",
      "Liquids have molecules that are more spread out than gases"
    ],
    correct: "Liquids have a fixed volume, gases do not"
  },
  {
    "question": "What happens to the volume of matter when it changes from solid to gas?",
    "options": [
      "The volume decreases",
      "The volume increases",
      "The volume stays the same",
      "The volume changes unpredictably"
    ],
    correct: "The volume increases"
  },
  {
    "question": "What defines the liquid state of matter?",
    "options": [
      "Particles are in fixed positions",
      "Particles are loosely packed but can slide past each other",
      "Particles are tightly packed and vibrate in place",
      "Particles move freely and spread apart"
    ],
    correct: "Particles are loosely packed but can slide past each other"
  },
  {
    "question": "Which of the following is an example of matter in the gas state?",
    "options": [
      "Helium",
      "Water",
      "Iron",
      "Oil"
    ],
    correct: "Helium"
  },
  {
    "question": "Which state of matter is considered to have the most energy?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Plasma"
  },
  {
    "question": "What is the state of matter where molecules are closely packed but can move around?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Liquid"
  },
  {
    "question": "Which of the following changes describes the transition from liquid to gas?",
    "options": [
      "Melting",
      "Freezing",
      "Evaporation",
      "Condensation"
    ],
    correct: "Evaporation"
  },
  {
    "question": "What occurs when matter changes from gas to liquid?",
    "options": [
      "Condensation",
      "Freezing",
      "Boiling",
      "Sublimation"
    ],
    correct: "Condensation"
  },
  {
    "question": "What happens to the volume of a gas when it is cooled?",
    "options": [
      "The volume decreases",
      "The volume increases",
      "The volume stays the same",
      "The volume fluctuates"
    ],
    correct: "The volume decreases"
  },
  {
    "question": "Which property of matter is best demonstrated by the liquid state?",
    "options": [
      "Has a definite volume but no definite shape",
      "Has a definite volume and shape",
      "Has no definite volume or shape",
      "Has a fixed shape and volume"
    ],
    correct: "Has a definite volume but no definite shape"
  },
  {
    "question": "At what temperature does water freeze?",
    "options": [
      "0°C",
      "100°C",
      "32°F",
      "273K"
    ],
    correct: "0°C"
  },
  {
    "question": "Which state of matter is commonly referred to as the 'fourth state' due to its unique properties?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Plasma"
  },
  {
    "question": "Which of the following is an example of matter in the gas state?",
    "options": [
      "Water vapor",
      "Ice",
      "Oxygen gas",
      "Salt"
    ],
    correct: "Water vapor"
  },
  {
    "question": "Which state of matter has particles that vibrate but do not move from place to place?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "In which state of matter do particles move freely and spread out to fill the container?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "What defines a plasma state of matter?",
    "options": [
      "Particles move freely with no fixed shape or volume",
      "Particles are tightly packed and vibrate in place",
      "Particles are in a gas phase with some ions and electrons",
      "Particles are tightly packed but can slide past each other"
    ],
    correct: "Particles are in a gas phase with some ions and electrons"
  },
  {
    "question": "Which of the following is an example of matter in the plasma state?",
    "options": [
      "Lightning",
      "Air",
      "Water",
      "Ice"
    ],
    correct: "Lightning"
  },
  {
    "question": "What happens when a substance transitions from gas to solid?",
    "options": [
      "Sublimation",
      "Freezing",
      "Deposition",
      "Condensation"
    ],
    correct: "Deposition"
  },
  {
    "question": "What happens to matter when its temperature is increased?",
    "options": [
      "Its molecules move slower",
      "Its volume increases",
      "Its molecules vibrate less",
      "Its volume decreases"
    ],
    correct: "Its volume increases"
  },
  {
    "question": "When matter changes from a solid to a liquid, what process is this called?",
    "options": [
      "Melting",
      "Evaporation",
      "Sublimation",
      "Condensation"
    ],
    correct: "Melting"
  },
  {
    "question": "Which of the following describes the properties of matter in the gas state?",
    "options": [
      "Has no fixed shape or volume",
      "Has a fixed volume but no fixed shape",
      "Has both fixed shape and volume",
      "Has a fixed shape but no fixed volume"
    ],
    correct: "Has no fixed shape or volume"
  },
  {
    "question": "Which of the following can change its shape easily?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "All of the above"
    ],
    correct: "Liquid"
  },
  {
    "question": "Which state of matter is commonly found in the Earth's atmosphere?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "In which state of matter do particles move the most freely?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "Which statement is true about liquids?",
    "options": [
      "Liquids have no definite shape and no definite volume",
      "Liquids have both a definite shape and volume",
      "Liquids have a definite shape but no definite volume",
      "Liquids have a definite volume but no definite shape"
    ],
    correct: "Liquids have a definite volume but no definite shape"
  },
  {
    "question": "What is the boiling point of water at standard pressure?",
    "options": [
      "0°C",
      "32°F",
      "100°C",
      "212°F"
    ],
    correct: "100°C"
  },
  {
    "question": "What is the state of matter where molecules are tightly packed in a fixed position?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "Which of the following is the process of a solid turning into a liquid?",
    "options": [
      "Freezing",
      "Melting",
      "Sublimation",
      "Condensation"
    ],
    correct: "Melting"
  },
  {
    "question": "In which state of matter do particles have the least amount of kinetic energy?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "Which of the following is an example of matter in the gas state?",
    "options": [
      "Water vapor",
      "Ice",
      "Oxygen",
      "Mercury"
    ],
    correct: "Water vapor"
  },
  {
    "question": "Which of the following processes involves the transition from a gas directly to a solid?",
    "options": [
      "Sublimation",
      "Deposition",
      "Condensation",
      "Melting"
    ],
    correct: "Deposition"
  },
  {
    "question": "At which temperature does water freeze at standard pressure?",
    "options": [
      "0°C",
      "100°C",
      "273K",
      "32°F"
    ],
    correct: "0°C"
  },
  {
    "question": "Which statement is true for gases?",
    "options": [
      "Gases have fixed volume and shape",
      "Gases have a fixed shape but no fixed volume",
      "Gases have no fixed shape or volume",
      "Gases have a fixed volume but no fixed shape"
    ],
    correct: "Gases have no fixed shape or volume"
  },
  {
    "question": "What happens when a gas is cooled?",
    "options": [
      "The gas expands",
      "The gas contracts",
      "The gas turns into a solid",
      "The gas melts"
    ],
    correct: "The gas contracts"
  },
  {
    "question": "What is the term used for the transition of a solid to a gas without passing through the liquid state?",
    "options": [
      "Sublimation",
      "Evaporation",
      "Melting",
      "Deposition"
    ],
    correct: "Sublimation"
  },
  {
    "question": "Which state of matter is characterized by particles that are very far apart and move freely?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "What is the primary characteristic of a liquid?",
    "options": [
      "Fixed volume and shape",
      "Fixed shape but not volume",
      "Fixed volume but no fixed shape",
      "No fixed volume or shape"
    ],
    correct: "Fixed volume but no fixed shape"
  },
  {
    "question": "Which of the following is a direct example of plasma?",
    "options": [
      "Water",
      "Lightning",
      "Air",
      "Ice"
    ],
    correct: "Lightning"
  },
  {
    "question": "When a substance changes from gas to liquid, what is this process called?",
    "options": [
      "Melting",
      "Condensation",
      "Sublimation",
      "Freezing"
    ],
    correct: "Condensation"
  },
  {
    "question": "Which state of matter is most common in stars?",
    "options": [
      "Solid",
      "Gas",
      "Plasma",
      "Liquid"
    ],
    correct: "Plasma"
  },
  {
    "question": "Which of the following properties is associated with gases?",
    "options": [
      "High density",
      "Low density",
      "Definite volume",
      "Fixed shape"
    ],
    correct: "Low density"
  },
  {
    "question": "What is the boiling point of water at standard pressure?",
    "options": [
      "0°C",
      "32°F",
      "100°C",
      "212°F"
    ],
    correct: "100°C"
  },
  {
    "question": "Which of the following describes matter in the solid state?",
    "options": [
      "Fixed shape and volume",
      "Fixed shape but no fixed volume",
      "No fixed shape or volume",
      "No fixed shape but fixed volume"
    ],
    correct: "Fixed shape and volume"
  },
  {
    "question": "What is an example of a substance that can exist in all three states of matter (solid, liquid, gas)?",
    "options": [
      "Water",
      "Iron",
      "Oxygen",
      "Carbon dioxide"
    ],
    correct: "Water"
  },
  {
    "question": "What happens to the particles in a substance when it is heated?",
    "options": [
      "They move slower",
      "They move faster",
      "They stay in the same position",
      "They become more packed"
    ],
    correct: "They move faster"
  },
  {
    "question": "What is the process of changing from a liquid to a gas?",
    "options": [
      "Evaporation",
      "Condensation",
      "Sublimation",
      "Freezing"
    ],
    correct: "Evaporation"
  },
  {
    "question": "Which of the following is a characteristic of matter in the solid state?",
    "options": [
      "Definite shape but no definite volume",
      "Definite shape and volume",
      "No definite shape or volume",
      "No definite shape but definite volume"
    ],
    correct: "Definite shape and volume"
  },
  {
    "question": "What is the transition of matter from liquid to solid called?",
    "options": [
      "Condensation",
      "Freezing",
      "Sublimation",
      "Evaporation"
    ],
    correct: "Freezing"
  },
  {
    "question": "What is an example of matter in the gas state?",
    "options": [
      "Water vapor",
      "Ice",
      "Sand",
      "Iron"
    ],
    correct: "Water vapor"
  },
  {
    "question": "What happens when a gas is compressed?",
    "options": [
      "The volume increases",
      "The volume decreases",
      "The pressure decreases",
      "The gas becomes a solid"
    ],
    correct: "The volume decreases"
  },
  {
    "question": "In which state of matter are the particles most widely spaced?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "At which temperature does water freeze?",
    "options": [
      "100°C",
      "0°C",
      "32°F",
      "273K"
    ],
    correct: "0°C"
  },
  {
    "question": "What is the process of changing from a gas to a liquid?",
    "options": [
      "Condensation",
      "Evaporation",
      "Sublimation",
      "Freezing"
    ],
    correct: "Condensation"
  },
  {
    "question": "What state of matter has a definite shape and volume?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "What happens to the volume of a gas when it is heated at constant pressure?",
    "options": [
      "Volume decreases",
      "Volume increases",
      "Volume stays the same",
      "Volume fluctuates"
    ],
    correct: "Volume increases"
  },
  {
    "question": "Which of the following is the best example of plasma?",
    "options": [
      "Sun",
      "Ice",
      "Water",
      "Air"
    ],
    correct: "Sun"
  },
  {
    "question": "What is the process of changing from a solid to a gas without passing through the liquid phase?",
    "options": [
      "Sublimation",
      "Deposition",
      "Melting",
      "Condensation"
    ],
    correct: "Sublimation"
  },
  {
    "question": "Which of the following is a characteristic of matter in the solid state?",
    "options": [
      "Definite shape but no definite volume",
      "Definite shape and volume",
      "No definite shape or volume",
      "No definite shape but definite volume"
    ],
    correct: "Definite shape and volume"
  },
  {
    "question": "What is the transition of matter from liquid to solid called?",
    "options": [
      "Condensation",
      "Freezing",
      "Sublimation",
      "Evaporation"
    ],
    correct: "Freezing"
  },
  {
    "question": "What is an example of matter in the gas state?",
    "options": [
      "Water vapor",
      "Ice",
      "Sand",
      "Iron"
    ],
    correct: "Water vapor"
  },
  {
    "question": "What happens when a gas is compressed?",
    "options": [
      "The volume increases",
      "The volume decreases",
      "The pressure decreases",
      "The gas becomes a solid"
    ],
    correct: "The volume decreases"
  },
  {
    "question": "In which state of matter are the particles most widely spaced?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "At which temperature does water freeze?",
    "options": [
      "100°C",
      "0°C",
      "32°F",
      "273K"
    ],
    correct: "0°C"
  },
  {
    "question": "What is the process of changing from a gas to a liquid?",
    "options": [
      "Condensation",
      "Evaporation",
      "Sublimation",
      "Freezing"
    ],
    correct: "Condensation"
  },
  {
    "question": "What state of matter has a definite shape and volume?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "What happens to the volume of a gas when it is heated at constant pressure?",
    "options": [
      "Volume decreases",
      "Volume increases",
      "Volume stays the same",
      "Volume fluctuates"
    ],
    correct: "Volume increases"
  },
  {
    "question": "Which of the following is the best example of plasma?",
    "options": [
      "Sun",
      "Ice",
      "Water",
      "Air"
    ],
    correct: "Sun"
  },
  {
    "question": "What is the process of changing from a solid to a gas without passing through the liquid phase?",
    "options": [
      "Sublimation",
      "Deposition",
      "Melting",
      "Condensation"
    ],
    correct: "Sublimation"
  },
  {
    "question": "What is the main difference between a gas and a liquid?",
    "options": [
      "Gases have a fixed volume, but liquids do not",
      "Liquids have a definite shape, but gases do not",
      "Gases do not have a fixed shape or volume, but liquids do",
      "Both have a fixed shape and volume"
    ],
    correct: "Gases do not have a fixed shape or volume, but liquids do"
  },
  {
    "question": "What is the process where a gas changes to a liquid?",
    "options": [
      "Evaporation",
      "Condensation",
      "Sublimation",
      "Freezing"
    ],
    correct: "Condensation"
  },
  {
    "question": "Which of the following describes the state of matter with tightly packed molecules that can only vibrate in place?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Solid"
  },
  {
    "question": "What happens when a solid is heated?",
    "options": [
      "It becomes a gas",
      "It becomes a liquid",
      "It shrinks",
      "It remains unchanged"
    ],
    correct: "It becomes a liquid"
  },
  {
    "question": "Which state of matter has the most freedom of particle movement?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "What is the term used for the process of a liquid changing into a gas?",
    "options": [
      "Evaporation",
      "Condensation",
      "Sublimation",
      "Melting"
    ],
    correct: "Evaporation"
  },
  {
    "question": "In which state do particles have the highest energy?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Plasma"
  },
  {
    "question": "Which of the following processes involves the change from gas to solid?",
    "options": [
      "Evaporation",
      "Sublimation",
      "Deposition",
      "Freezing"
    ],
    correct: "Deposition"
  },
  {
    "question": "Which of the following is an example of matter in the plasma state?",
    "options": [
      "Sun",
      "Water",
      "Ice",
      "Gas"
    ],
    correct: "Sun"
  },
  {
    "question": "What is the term used for the change of a solid directly into a gas?",
    "options": [
      "Deposition",
      "Condensation",
      "Sublimation",
      "Evaporation"
    ],
    correct: "Sublimation"
  },
  {
    "question": "What state of matter has a definite volume but no definite shape?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Liquid"
  },
  {
    "question": "What is the boiling point of water in degrees Celsius?",
    "options": [
      "100°C",
      "32°C",
      "212°C",
      "0°C"
    ],
    correct: "100°C"
  },
  {
    "question": "Which of the following occurs when a liquid turns into a gas?",
    "options": [
      "Freezing",
      "Evaporation",
      "Condensation",
      "Deposition"
    ],
    correct: "Evaporation"
  },
  {
    "question": "Which of the following best describes a gas?",
    "options": [
      "Fixed shape and volume",
      "Fixed volume but no fixed shape",
      "No fixed shape or volume",
      "Fixed shape but no fixed volume"
    ],
    correct: "No fixed shape or volume"
  },
  {
    "question": "Which state of matter has particles that are very far apart and move freely?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Gas"
  },
  {
    "question": "Which of the following is the primary property of a solid?",
    "options": [
      "Fixed shape and volume",
      "Fixed volume but no fixed shape",
      "No fixed shape or volume",
      "No fixed shape but fixed volume"
    ],
    correct: "Fixed shape and volume"
  },
  {
    "question": "What happens to the volume of a gas when it is compressed?",
    "options": [
      "Volume decreases",
      "Volume increases",
      "Volume remains the same",
      "Volume fluctuates"
    ],
    correct: "Volume decreases"
  },
  {
    "question": "Which process describes the transition from a gas to a liquid?",
    "options": [
      "Condensation",
      "Freezing",
      "Evaporation",
      "Melting"
    ],
    correct: "Condensation"
  },
  {
    "question": "Which state of matter has the highest kinetic energy?",
    "options": [
      "Solid",
      "Liquid",
      "Gas",
      "Plasma"
    ],
    correct: "Plasma"
  },
  {
    "question": "At what temperature does water boil at standard atmospheric pressure?",
    "options": [
      "100°C",
      "0°C",
      "32°F",
      "273K"
    ],
    correct: "100°C"
  }
]
