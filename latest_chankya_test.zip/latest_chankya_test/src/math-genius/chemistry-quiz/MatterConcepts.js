import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaCube, FaTachometerAlt, FaCloud, FaWater } from "react-icons/fa"; // Icons for the animation
import MatterConceptsQuiz from './MatterConceptsQuiz'; // Quiz component placeholder

const MatterConcepts = () => {
  // State to trigger re-render
  const [key, setKey] = useState(0);

  // Function to reload animations
  const reloadAnimations = () => {
    setKey((prevKey) => prevKey + 1); // Increment key to force re-render
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        Matter: Definition, Characteristics, and States
      </h1>
      <button
        onClick={reloadAnimations}
        style={{
          display: "block",
          margin: "0 auto 20px",
          padding: "10px 20px",
          fontSize: "16px",
          backgroundColor: "#007bff",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Reload Animations
      </button>

      {/* Wrapping all animations in a keyed container */}
      <div key={key}>
        {/* Introduction */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          style={{ textAlign: "center" }}
        >
          <p>
            Matter is anything that has mass and occupies space. It exists in three primary states: solid, liquid, and gas.
          </p>
        </motion.div>

        {/* Step 1: Characteristics of Matter */}
        <motion.div
          initial={{ opacity: 0, x: -100 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 1 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "30px",
          }}
        >
          <FaCube size={50} color="blue" style={{ marginRight: "20px" }} />
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1 }}
          >
            <p style={{ margin: 0 }}>Matter has mass and occupies space.</p>
          </motion.div>
        </motion.div>

        {/* Step 2: Solid State */}
        <motion.div
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 1.5 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "30px",
          }}
        >
          <FaTachometerAlt size={50} color="orange" style={{ marginRight: "20px" }} />
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1 }}
          >
            <p style={{ margin: 0 }}>In the solid state, matter has a fixed shape and volume.</p>
          </motion.div>
        </motion.div>

        {/* Step 3: Liquid State */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 2 }}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "40px",
          }}
        >
          <FaWater size={60} color="green" style={{ marginRight: "20px" }} />
          <motion.div>
            <p style={{ margin: 0, textAlign: "center" }}>
              In the liquid state, matter has a fixed volume but no fixed shape.
            </p>
          </motion.div>
        </motion.div>

        {/* Step 4: Gas State */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3 }}
          style={{
            textAlign: "center",
            marginTop: "40px",
            padding: "20px",
            border: "1px solid #ccc",
            borderRadius: "10px",
          }}
        >
          <FaCloud size={50} color="lightblue" style={{ marginRight: "20px" }} />
          <p>
            In the gas state, matter has neither a fixed shape nor a fixed volume.
          </p>
        </motion.div>
      </div>
      <MatterConceptsQuiz />
    </div>
  );
};

export default MatterConcepts;
