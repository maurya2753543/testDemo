export const quizQuestions = [
    {
      "question": "What is titration used for in chemistry?",
      "options": [
        "To determine the concentration of a solution",
        "To measure the temperature of a reaction",
        "To determine the mass of a substance",
        "To identify the boiling point of a solution"
      ],
     correct: "To determine the concentration of a solution"
    },
    {
      "question": "Which of the following is a common titrant in acid-base titrations?",
      "options": [
        "Sodium chloride",
        "Potassium hydroxide",
        "Sodium hydroxide",
        "Hydrochloric acid"
      ],
     correct: "Sodium hydroxide"
    },
    {
      "question": "What is the endpoint of a titration?",
      "options": [
        "When the solution reaches its boiling point",
        "When the titrant is completely added",
        "When the indicator changes color",
        "When the solute dissolves completely"
      ],
     correct: "When the indicator changes color"
    },
    {
      "question": "What is the purpose of an indicator in titration?",
      "options": [
        "To change the color at the endpoint",
        "To dissolve the solute",
        "To slow down the reaction",
        "To increase the rate of the reaction"
      ],
     correct: "To change the color at the endpoint"
    },
    {
      "question": "Which of the following is a common indicator used in acid-base titrations?",
      "options": [
        "Methyl orange",
        "Iodine solution",
        "Bromine",
        "Iron(III) chloride"
      ],
     correct: "Methyl orange"
    },
    {
      "question": "What does the titration curve represent?",
      "options": [
        "The change in temperature over time",
        "The change in concentration of the titrant",
        "The change in volume of the titrant",
        "The change in pH of the solution during titration"
      ],
     correct: "The change in pH of the solution during titration"
    },
    {
      "question": "What is the molarity of a solution?",
      "options": [
        "The amount of solute in a given volume of solution",
        "The volume of solute in a given mass of solution",
        "The temperature of the solution",
        "The color intensity of the solution"
      ],
     correct: "The amount of solute in a given volume of solution"
    },
    {
      "question": "In a titration, what does the volume of the titrant added correspond to?",
      "options": [
        "The concentration of the unknown solution",
        "The mass of the unknown solution",
        "The density of the unknown solution",
        "The temperature of the unknown solution"
      ],
     correct: "The concentration of the unknown solution"
    },
    {
      "question": "Which is the correct equation for titration calculations?",
      "options": [
        "M₁V₁ = M₂V₂",
        "M₁V₁ = P₂V₂",
        "M₁V₁ = N₂V₂",
        "M₁V₁ = C₂V₂"
      ],
     correct: "M₁V₁ = M₂V₂"
    },
    {
      "question": "What happens at the equivalence point in an acid-base titration?",
      "options": [
        "The solution becomes saturated",
        "The acid and base are in equal concentrations",
        "The solution turns cloudy",
        "The indicator changes color"
      ],
     correct: "The acid and base are in equal concentrations"
    },
    {
      "question": "Which of the following is a strong acid commonly used in titrations?",
      "options": [
        "Acetic acid",
        "Hydrochloric acid",
        "Citric acid",
        "Lactic acid"
      ],
     correct: "Hydrochloric acid"
    },
    {
      "question": "Which of the following is a strong base commonly used in titrations?",
      "options": [
        "Ammonia",
        "Sodium hydroxide",
        "Potassium carbonate",
        "Calcium carbonate"
      ],
     correct: "Sodium hydroxide"
    },
    {
      "question": "What is a standard solution in titration?",
      "options": [
        "A solution with an unknown concentration",
        "A solution with a known concentration",
        "A solution that changes color during the titration",
        "A solution that reacts with the titrant"
      ],
     correct: "A solution with a known concentration"
    },
    {
      "question": "What is the significance of the titration volume?",
      "options": [
        "It determines the pH of the solution",
        "It helps to calculate the concentration of the unknown solution",
        "It identifies the solubility of the solute",
        "It determines the rate of reaction"
      ],
     correct: "It helps to calculate the concentration of the unknown solution"
    },
    {
      "question": "What is the purpose of rinsing the burette before use in titration?",
      "options": [
        "To clean the burette",
        "To prevent contamination of the solution",
        "To ensure accurate measurements",
        "All of the above"
      ],
     correct: "All of the above"
    },
    {
      "question": "Which of the following is NOT a factor affecting the titration process?",
      "options": [
        "Concentration of the titrant",
        "Volume of the unknown solution",
        "The shape of the container",
        "The type of indicator used"
      ],
     correct: "The shape of the container"
    },
    {
      "question": "Which of the following is an example of a redox titration?",
      "options": [
        "Titration between an acid and a base",
        "Titration between a metal and an acid",
        "Titration between iodine and sodium thiosulfate",
        "Titration between sodium hydroxide and hydrochloric acid"
      ],
     correct: "Titration between iodine and sodium thiosulfate"
    },
    {
      "question": "In a titration, which type of solution is typically used as the analyte?",
      "options": [
        "The solution with a known concentration",
        "The solution with an unknown concentration",
        "The solvent",
        "The reagent"
      ],
     correct: "The solution with an unknown concentration"
    },
    {
      "question": "Which of the following is a feature of a burette used in titration?",
      "options": [
        "It is graduated for accurate measurement",
        "It holds the titrant",
        "It is used to measure the volume of the analyte",
        "Both A and B"
      ],
     correct: "Both A and B"
    },
    {
      "question": "What does the term 'molarity' refer to in titration?",
      "options": [
        "The mass of solute per liter of solution",
        "The volume of solute per liter of solution",
        "The concentration of a solution in terms of moles per liter",
        "The pressure of the solution"
      ],
     correct: "The concentration of a solution in terms of moles per liter"
    },
    {
        "question": "What is the primary purpose of titration in analytical chemistry?",
        "options": [
          "To measure the solubility of a substance",
          "To determine the concentration of a solution",
          "To determine the boiling point of a solution",
          "To identify the pH of a solution"
        ],
       correct: "To determine the concentration of a solution"
      },
      {
        "question": "Which of the following substances is commonly used as a titrant in acid-base titrations?",
        "options": [
          "Potassium permanganate",
          "Sodium hydroxide",
          "Iodine solution",
          "Sodium chloride"
        ],
       correct: "Sodium hydroxide"
      },
      {
        "question": "Which of the following is a characteristic of a good titration indicator?",
        "options": [
          "It should change color sharply at the equivalence point",
          "It should dissolve completely in water",
          "It should have a neutral pH",
          "It should be colorless"
        ],
       correct: "It should change color sharply at the equivalence point"
      },
      {
        "question": "What is the effect of dilution on the titration results?",
        "options": [
          "Dilution increases the volume of titrant required",
          "Dilution has no effect on the titration",
          "Dilution decreases the volume of titrant required",
          "Dilution affects only the rate of reaction"
        ],
       correct: "Dilution increases the volume of titrant required"
      },
      {
        "question": "In an acid-base titration, what does the color change of the indicator signify?",
        "options": [
          "The titrant has been completely used up",
          "The analyte has reached a specific pH",
          "The analyte has been neutralized",
          "The solution is saturated"
        ],
       correct: "The analyte has been neutralized"
      },
      {
        "question": "Which of the following statements is true about the equivalence point in a titration?",
        "options": [
          "The amounts of acid and base are equal in moles",
          "The indicator changes color at the equivalence point",
          "The volume of titrant is zero",
          "The pH of the solution is always 7 at the equivalence point"
        ],
       correct: "The amounts of acid and base are equal in moles"
      },
      {
        "question": "What is the normality of a solution?",
        "options": [
          "The number of moles of solute in one liter of solution",
          "The volume of solute in one liter of solution",
          "The number of equivalents of solute in one liter of solution",
          "The mass of solute in one liter of solution"
        ],
       correct: "The number of equivalents of solute in one liter of solution"
      },
      {
        "question": "What would happen if you added too much titrant in a titration?",
        "options": [
          "The titration will fail",
          "You will overestimate the concentration of the solution",
          "You will underestimate the concentration of the solution",
          "The volume of the solution will increase"
        ],
       correct: "You will overestimate the concentration of the solution"
      },
      {
        "question": "What is the main purpose of using a burette during titration?",
        "options": [
          "To accurately measure the volume of titrant added",
          "To hold the analyte solution",
          "To mix the solution",
          "To heat the solution"
        ],
       correct: "To accurately measure the volume of titrant added"
      },
      {
        "question": "In a redox titration, what does the titrant do?",
        "options": [
          "It reacts with the analyte to change its oxidation state",
          "It only dissolves the solute",
          "It changes the pH of the solution",
          "It is used as a buffer"
        ],
       correct: "It reacts with the analyte to change its oxidation state"
      },
      {
        "question": "What is the product of the following reaction: 2Na + Cl2 → ?",
        "options": [
          "NaCl",
          "NaCl2",
          "NaCl3",
          "Na2Cl"
        ],
       correct: "NaCl"
      },
      {
        "question": "Which of the following is the correct formula for sulfuric acid?",
        "options": [
          "H2SO4",
          "H2S",
          "SO3",
          "HSO3"
        ],
       correct: "H2SO4"
      },
      {
        "question": "What is the unit of electric charge?",
        "options": [
          "Coulomb",
          "Ampere",
          "Volt",
          "Ohm"
        ],
       correct: "Coulomb"
      },
      {
        "question": "What is the derivative of sin(x)?",
        "options": [
          "cos(x)",
          "-cos(x)",
          "sin(x)",
          "-sin(x)"
        ],
       correct: "cos(x)"
      },
      {
        "question": "What is the value of π up to 3 decimal places?",
        "options": [
          "3.142",
          "3.141",
          "3.140",
          "3.143"
        ],
       correct: "3.142"
      },
      {
        "question": "Which of the following is a type of isomerism in organic chemistry?",
        "options": [
          "Structural isomerism",
          "Geometrical isomerism",
          "Optical isomerism",
          "All of the above"
        ],
       correct: "All of the above"
      },
      {
        "question": "The half-life of a substance is 10 minutes. How much time will it take for the substance to reduce to one-eighth of its original amount?",
        "options": [
          "30 minutes",
          "20 minutes",
          "10 minutes",
          "60 minutes"
        ],
       correct: "30 minutes"
      },
      {
        "question": "What is the dimension of velocity?",
        "options": [
          "[M L T^-1]",
          "[M T^-1]",
          "[M L^2 T^-1]",
          "[L T^-1]"
        ],
       correct: "[L T^-1]"
      },
      {
        "question": "Which of the following statements is correct for a non-inverting amplifier?",
        "options": [
          "Output is in phase with input",
          "Output is 180 degrees out of phase with input",
          "Input is directly proportional to output",
          "None of the above"
        ],
       correct: "Output is in phase with input"
      },
      {
        "question": "Which element has the highest ionization energy?",
        "options": [
          "Oxygen",
          "Fluorine",
          "Neon",
          "Helium"
        ],
       correct: "Helium"
      },
      {
        "question": "If a sphere has a radius of 3 cm, what is its volume?",
        "options": [
          "36π cm³",
          "81π cm³",
          "108π cm³",
          "9π cm³"
        ],
       correct: "36π cm³"
      },
      {
        "topic": "Coordination Compounds",
        "questions": [
          {
            "question": "Which of the following is an example of a coordination compound?",
            "options": [
              "NaCl",
              "CuSO4",
              "[Cu(NH3)4]2+",
              "H2O"
            ],
           correct: "[Cu(NH3)4]2+"
          },
          {
            "question": "What is the coordination number of the central metal ion in [Fe(CO)5]?",
            "options": [
              "4",
              "5",
              "6",
              "2"
            ],
           correct: "5"
          }
        ]
      },
      {
        "topic": "Haloalkanes and Haloarenes",
        "questions": [
          {
            "question": "Which of the following is the correct formula for chlorobenzene?",
            "options": [
              "C6H5Cl",
              "C6H6Cl",
              "C6H5Cl2",
              "C6H4Cl"
            ],
           correct: "C6H5Cl"
          },
          {
            "question": "What is the main method for preparing alkyl halides?",
            "options": [
              "Electrolysis of alcohols",
              "Halogenation of alkanes",
              "Hydrogenation of alkenes",
              "Addition of halogen to alkenes"
            ],
           correct: "Halogenation of alkanes"
          }
        ]
      },
      {
        "topic": "Alcohols, Phenols, and Ethers",
        "questions": [
          {
            "question": "Which of the following is the simplest alcohol?",
            "options": [
              "Methanol",
              "Ethanol",
              "Isopropyl alcohol",
              "Butanol"
            ],
           correct: "Methanol"
          },
          {
            "question": "Phenols are stronger acids than alcohols because of which effect?",
            "options": [
              "Inductive effect",
              "Resonance effect",
              "Hydrogen bonding",
              "Electrophilic effect"
            ],
           correct: "Resonance effect"
          }
        ]
      },
      {
        "topic": "Aldehydes, Ketones, and Carboxylic Acids",
        "questions": [
          {
            "question": "Which of the following is a method of preparing aldehydes?",
            "options": [
              "Reduction of esters",
              "Oxidation of alcohols",
              "Reduction of carboxylic acids",
              "Oxidation of ketones"
            ],
           correct: "Oxidation of alcohols"
          },
          {
            "question": "Which reagent is used in the preparation of carboxylic acids from alcohols?",
            "options": [
              "Chromic acid",
              "Sulfuric acid",
              "Hydrochloric acid",
              "Potassium permanganate"
            ],
           correct: "Chromic acid"
          }
        ]
      },
      {
        "topic": "Amines",
        "questions": [
          {
            "question": "Which of the following is a primary amine?",
            "options": [
              "CH3NH2",
              "C2H5NH2",
              "C6H5NH2",
              "CH3CH2NH2"
            ],
           correct: "CH3NH2"
          },
          {
            "question": "Amines are basic due to which of the following reasons?",
            "options": [
              "Lone pair of electrons on nitrogen",
              "Presence of a double bond",
              "Availability of hydrogen atoms",
              "None of the above"
            ],
           correct: "Lone pair of electrons on nitrogen"
          }
        ]
      },
      {
        "topic": "Biomolecules",
        "questions": [
          {
            "question": "Which of the following is a protein structure?",
            "options": [
              "Amino acid",
              "Polypeptide chain",
              "Fatty acid",
              "Glucose"
            ],
           correct: "Polypeptide chain"
          },
          {
            "question": "Which of the following biomolecules is involved in the storage and transmission of genetic information?",
            "options": [
              "DNA",
              "RNA",
              "Protein",
              "Lipids"
            ],
           correct: "DNA"
          }
        ]
      },
      {
        "topic": "Chemical Kinetics",
        "questions": [
          {
            "question": "The rate of reaction is defined as the change in the concentration of reactants or products with respect to time. What is the unit of rate constant for a second-order reaction?",
            "options": [
              "s⁻¹",
              "L/mol·s",
              "mol/L·s",
              "L²/mol²·s"
            ],
           correct: "L/mol·s"
          },
          {
            "question": "Which of the following is the correct formula for calculating the rate of reaction?",
            "options": [
              "Rate = k[A]^n",
              "Rate = k[A][B]",
              "Rate = k[A][B]^2",
              "Rate = k[A]^2"
            ],
           correct: "Rate = k[A]^n"
          }
        ]
      },
      {
        "topic": "d and f block elements",
        "questions": [
          {
            "question": "Which of the following is a characteristic property of transition metals?",
            "options": [
              "High melting points",
              "Form colored compounds",
              "Have variable oxidation states",
              "All of the above"
            ],
           correct: "All of the above"
          },
          {
            "question": "Which of the following elements is a lanthanide?",
            "options": [
              "Ce",
              "Fe",
              "Ni",
              "Na"
            ],
           correct: "Ce"
          }
        ]
      },
      {
        "topic": "Solutions",
        "questions": [
          {
            "question": "What is the molarity of a solution prepared by dissolving 10g of NaOH in 500mL of water?",
            "options": [
              "1 mol/L",
              "2 mol/L",
              "0.5 mol/L",
              "0.2 mol/L"
            ],
           correct: "0.5 mol/L"
          },
          {
            "question": "What is Raoult's Law associated with?",
            "options": [
              "Vapor pressure of solutions",
              "Boiling point of solutions",
              "Freezing point of solutions",
              "None of the above"
            ],
           correct: "Vapor pressure of solutions"
          }
        ]
      },
      {
        "topic": "Electrochemistry",
        "questions": [
          {
            "question": "In electrochemical cells, which electrode is the site of reduction?",
            "options": [
              "Anode",
              "Cathode",
              "Electrolyte",
              "Salt bridge"
            ],
           correct: "Cathode"
          },
          {
            "question": "What is the standard electrode potential of the hydrogen electrode?",
            "options": [
              "0 V",
              "1.0 V",
              "0.5 V",
              "2.0 V"
            ],
           correct: "0 V"
          }
        ]
      },
      {
        "topic": "Coordination Compounds",
        "questions": [
          {
            "question": "Which of the following is the correct geometry for [Ni(CO)4]?",
            "options": [
              "Tetrahedral",
              "Square planar",
              "Octahedral",
              "Linear"
            ],
           correct: "Tetrahedral"
          },
          {
            "question": "The oxidation state of the central metal ion in [CuCl4]2- is:",
            "options": [
              "0",
              "+1",
              "+2",
              "+3"
            ],
           correct: "+2"
          },
          {
            "question": "Which of the following ligands is a bidentate ligand?",
            "options": [
              "NH3",
              "C2O4 2-",
              "Cl-",
              "H2O"
            ],
           correct: "C2O4 2-"
          }
        ]
      },
      {
        "topic": "Haloalkanes and Haloarenes",
        "questions": [
          {
            "question": "Which of the following is an example of a tertiary haloalkane?",
            "options": [
              "CH3Cl",
              "C2H5Cl",
              "(CH3)3CCl",
              "C6H5Cl"
            ],
           correct: "(CH3)3CCl"
          },
          {
            "question": "Which of the following is the correct method for the preparation of chlorobenzene?",
            "options": [
              "Direct chlorination of benzene",
              "Chlorination of toluene",
              "Bromination of phenol",
              "Reaction of benzene with chlorine and UV light"
            ],
           correct: "Direct chlorination of benzene"
          }
        ]
      },
      {
        "topic": "Alcohols, Phenols, and Ethers",
        "questions": [
          {
            "question": "Which of the following reactions is used to prepare ethers?",
            "options": [
              "Hydrogenation of alkenes",
              "Dehydration of alcohols",
              "Reduction of ketones",
              "Halogenation of alcohols"
            ],
           correct: "Dehydration of alcohols"
          },
          {
            "question": "The compound C6H5OH is commonly known as:",
            "options": [
              "Phenol",
              "Benzene",
              "Toluene",
              "Benzoic acid"
            ],
           correct: "Phenol"
          }
        ]
      },
      {
        "topic": "Aldehydes, Ketones, and Carboxylic Acids",
        "questions": [
          {
            "question": "Which of the following compounds is a ketone?",
            "options": [
              "Acetone",
              "Formaldehyde",
              "Acetic acid",
              "Propionaldehyde"
            ],
           correct: "Acetone"
          },
          {
            "question": "Which of the following reactions is used to distinguish between aldehydes and ketones?",
            "options": [
              "Tollens' test",
              "Baeyer’s test",
              "Finkelstein reaction",
              "Reimer-Tiemann reaction"
            ],
           correct: "Tollens' test"
          }
        ]
      },
      {
        "topic": "Amines",
        "questions": [
          {
            "question": "Which of the following is the simplest amine?",
            "options": [
              "Aniline",
              "Methylamine",
              "Ethylamine",
              "Dimethylamine"
            ],
           correct: "Methylamine"
          },
          {
            "question": "What is the basic nature of amines attributed to?",
            "options": [
              "Lone pair of electrons on nitrogen",
              "Electrophilic attack",
              "Availability of hydrogen ions",
              "None of the above"
            ],
           correct: "Lone pair of electrons on nitrogen"
          }
        ]
      },
      {
        "topic": "Biomolecules",
        "questions": [
          {
            "question": "Which of the following is an example of a polysaccharide?",
            "options": [
              "Glucose",
              "Fructose",
              "Cellulose",
              "Sucrose"
            ],
           correct: "Cellulose"
          },
          {
            "question": "Which biomolecule is primarily responsible for storing genetic information?",
            "options": [
              "Proteins",
              "Carbohydrates",
              "DNA",
              "Lipids"
            ],
           correct: "DNA"
          }
        ]
      },
      {
        "topic": "Chemical Kinetics",
        "questions": [
          {
            "question": "In a reaction A + B → C, the rate law is given as Rate = k[A][B]. What is the order of this reaction?",
            "options": [
              "Zero order",
              "First order",
              "Second order",
              "Third order"
            ],
           correct: "Second order"
          },
          {
            "question": "The rate constant for a first-order reaction has units of:",
            "options": [
              "mol/L·s",
              "L/mol·s",
              "s⁻¹",
              "mol/L"
            ],
           correct: "s⁻¹"
          }
        ]
      },
      {
        "topic": "d and f block elements",
        "questions": [
          {
            "question": "Which of the following elements is part of the f-block elements?",
            "options": [
              "Titanium",
              "Lanthanum",
              "Iron",
              "Copper"
            ],
           correct: "Lanthanum"
          },
          {
            "question": "Which of the following properties is common to both transition and inner transition metals?",
            "options": [
              "High electrical conductivity",
              "Low melting points",
              "High ionization energy",
              "None of the above"
            ],
           correct: "High electrical conductivity"
          }
        ]
      },
      {
        "topic": "Solutions",
        "questions": [
          {
            "question": "Which of the following is a colligative property of solutions?",
            "options": [
              "Boiling point elevation",
              "Density",
              "Color",
              "Viscosity"
            ],
           correct: "Boiling point elevation"
          },
          {
            "question": "What is the molarity of a solution that contains 10g of NaOH in 250mL of water?",
            "options": [
              "0.4 mol/L",
              "0.2 mol/L",
              "0.8 mol/L",
              "1.0 mol/L"
            ],
           correct: "0.4 mol/L"
          }
        ]
      },
      {
        "topic": "Electrochemistry",
        "questions": [
          {
            "question": "What is the standard electrode potential of the half-reaction Ag+ + e- → Ag?",
            "options": [
              "0.80 V",
              "0.15 V",
              "1.0 V",
              "0.45 V"
            ],
           correct: "0.80 V"
          },
          {
            "question": "Which of the following is the correct unit for electrochemical potential?",
            "options": [
              "Joules",
              "Coulombs",
              "Volts",
              "Amps"
            ],
           correct: "Volts"
          }
        ]
      },
      {
        "topic": "Coordination Compounds",
        "questions": [
          {
            "question": "Which of the following is an example of a bidentate ligand?",
            "options": [
              "NH3",
              "C2O4 2-",
              "Cl-",
              "H2O"
            ],
           correct: "C2O4 2-"
          },
          {
            "question": "Which metal ion in [Fe(CN)6]4- has an oxidation state of +2?",
            "options": [
              "Fe",
              "Cu",
              "Cr",
              "Co"
            ],
           correct: "Fe"
          },
          {
            "question": "In the complex [Ni(CO)4], which is the coordination number of the central metal ion?",
            "options": [
              "2",
              "4",
              "6",
              "8"
            ],
           correct: "4"
          },
          {
            "question": "Which of the following is an example of a heteroleptic complex?",
            "options": [
              "[Ni(NH3)6]2+",
              "[Fe(CO)5]",
              "[CoCl2(NH3)4]",
              "[Cu(NH3)4]2+"
            ],
           correct: "[CoCl2(NH3)4]"
          }
        ]
      },
      {
        "topic": "Haloalkanes and Haloarenes",
        "questions": [
          {
            "question": "Which of the following is the main product of the reaction between alkyl halide and KOH in ethanol?",
            "options": [
              "Alcohol",
              "Ether",
              "Alkene",
              "Haloalkane"
            ],
           correct: "Alkene"
          },
          {
            "question": "Which of the following is a major reaction when haloalkanes react with sodium in dry ether?",
            "options": [
              "Elimination reaction",
              "Addition reaction",
              "Wurtz reaction",
              "Substitution reaction"
            ],
           correct: "Wurtz reaction"
          },
          {
            "question": "Which of the following compounds undergoes nucleophilic substitution easily?",
            "options": [
              "CH3Cl",
              "C6H5Cl",
              "C6H5CH2Cl",
              "CH3CH2Cl"
            ],
           correct: "CH3Cl"
          },
          {
            "question": "What is the intermediate formed in the nucleophilic substitution reaction of haloalkanes?",
            "options": [
              "Carbocation",
              "Carbanion",
              "Free radical",
              "None of the above"
            ],
           correct: "Carbocation"
          }
        ]
      },
      {
        "topic": "Alcohols, Phenols, and Ethers",
        "questions": [
          {
            "question": "Which of the following is the functional group of alcohol?",
            "options": [
              "–OH",
              "–COOH",
              "–NH2",
              "–CHO"
            ],
           correct: "–OH"
          },
          {
            "question": "Which of the following reactions is used to convert alcohols into aldehydes?",
            "options": [
              "Oxidation",
              "Reduction",
              "Hydrogenation",
              "Dehydration"
            ],
           correct: "Oxidation"
          },
          {
            "question": "Which compound is produced when phenol reacts with bromine water?",
            "options": [
              "Bromobenzene",
              "2,4,6-Tribromophenol",
              "Phenyl bromide",
              "Benzyl alcohol"
            ],
           correct: "2,4,6-Tribromophenol"
          },
          {
            "question": "Which of the following is used for the preparation of ethers from alcohols?",
            "options": [
              "Dehydration with sulfuric acid",
              "Reduction with lithium",
              "Electrophilic substitution",
              "Nucleophilic substitution"
            ],
           correct: "Dehydration with sulfuric acid"
          }
        ]
      },
      {
        "topic": "Aldehydes, Ketones, and Carboxylic Acids",
        "questions": [
          {
            "question": "Which of the following reactions is used for the preparation of aldehydes from alcohols?",
            "options": [
              "Oxidation",
              "Reduction",
              "Nucleophilic addition",
              "Electrophilic substitution"
            ],
           correct: "Oxidation"
          },
          {
            "question": "What is the main product when aldehydes react with Grignard reagents?",
            "options": [
              "Ketones",
              "Alcohols",
              "Carboxylic acids",
              "Esters"
            ],
           correct: "Alcohols"
          },
          {
            "question": "Which of the following compounds undergoes nucleophilic acyl substitution?",
            "options": [
              "Aldehyde",
              "Ketone",
              "Carboxylic acid",
              "Alcohol"
            ],
           correct: "Carboxylic acid"
          },
          {
            "question": "Which of the following is a strong oxidizing agent that can oxidize alcohols to carboxylic acids?",
            "options": [
              "K2Cr2O7",
              "NaOH",
              "LiAlH4",
              "FeCl3"
            ],
           correct: "K2Cr2O7"
          }
        ]
      },
      {
        "topic": "Amines",
        "questions": [
          {
            "question": "Which of the following is a primary amine?",
            "options": [
              "Aniline",
              "Dimethylamine",
              "Methylamine",
              "Ethylamine"
            ],
           correct: "Methylamine"
          },
          {
            "question": "Which of the following compounds is prepared by reduction of nitro compounds?",
            "options": [
              "Primary amines",
              "Secondary amines",
              "Tertiary amines",
              "None of the above"
            ],
           correct: "Primary amines"
          },
          {
            "question": "Which of the following methods is used for the preparation of aryl amines?",
            "options": [
              "Reduction of nitro compounds",
              "Reaction with diazonium salts",
              "Electrophilic substitution",
              "Friedel-Crafts reaction"
            ],
           correct: "Reduction of nitro compounds"
          },
          {
            "question": "Which of the following amines is a strong base?",
            "options": [
              "Aniline",
              "Methylamine",
              "Dimethylamine",
              "Ammonia"
            ],
           correct: "Dimethylamine"
          }
        ]
      },
      {
        "topic": "Biomolecules",
        "questions": [
          {
            "question": "Which of the following biomolecules is involved in storing and transmitting genetic information?",
            "options": [
              "Proteins",
              "Lipids",
              "Carbohydrates",
              "Nucleic acids"
            ],
           correct: "Nucleic acids"
          },
          {
            "question": "Which of the following is a characteristic feature of proteins?",
            "options": [
              "They are made of nucleotides",
              "They contain sugars",
              "They are made of amino acids",
              "They are made of fatty acids"
            ],
           correct: "They are made of amino acids"
          },
          {
            "question": "Which of the following is the function of enzymes?",
            "options": [
              "Store energy",
              "Act as catalysts",
              "Transmit genetic information",
              "Form structural components"
            ],
           correct: "Act as catalysts"
          },
          {
            "question": "What is the primary function of DNA in a cell?",
            "options": [
              "Synthesize proteins",
              "Store energy",
              "Store genetic information",
              "Catalyze chemical reactions"
            ],
           correct: "Store genetic information"
          }
        ]
      },
      {
        "topic": "Chemical Kinetics",
        "questions": [
          {
            "question": "In a reaction A → B, the rate law is given as Rate = k[A]. What is the order of the reaction?",
            "options": [
              "Zero order",
              "First order",
              "Second order",
              "Third order"
            ],
           correct: "First order"
          },
          {
            "question": "What is the effect of increasing temperature on the rate of a reaction?",
            "options": [
              "Decreases the rate",
              "Increases the rate",
              "Does not affect the rate",
              "Increases the activation energy"
            ],
           correct: "Increases the rate"
          },
          {
            "question": "The rate constant for a second-order reaction has units of:",
            "options": [
              "mol/L·s",
              "L/mol·s",
              "s⁻¹",
              "mol/L"
            ],
           correct: "L/mol·s"
          },
          {
            "question": "The half-life of a first-order reaction is independent of the initial concentration. What does this imply?",
            "options": [
              "The rate is constant",
              "The reaction is zero order",
              "The rate constant is constant",
              "None of the above"
            ],
           correct: "The rate constant is constant"
          }
        ]
      },
      {
        "topic": "Coordination Compounds",
        "questions": [
          {
            "question": "What is the oxidation state of the central metal ion in [Cr(H2O)6]3+?",
            "options": [
              "0",
              "+3",
              "+6",
              "+2"
            ],
           correct: "+3"
          },
          {
            "question": "Which of the following ligands is a strong field ligand?",
            "options": [
              "Cl-",
              "H2O",
              "CO",
              "OH-"
            ],
           correct: "CO"
          },
          {
            "question": "Which of the following complexes is an example of a square planar geometry?",
            "options": [
              "[NiCl4]2-",
              "[Ni(CO)4]",
              "[CuCl4]2-",
              "[PtCl4]2-"
            ],
           correct: "[PtCl4]2-"
          },
          {
            "question": "In the complex [Cr(NH3)6]3+, what is the coordination number of Cr?",
            "options": [
              "4",
              "6",
              "2",
              "3"
            ],
           correct: "6"
          }
        ]
      },
      {
        "topic": "Haloalkanes and Haloarenes",
        "questions": [
          {
            "question": "Which of the following undergoes nucleophilic substitution in the presence of NaOH?",
            "options": [
              "C2H5Br",
              "C6H5Cl",
              "C6H5CH2Br",
              "C2H5Cl"
            ],
           correct: "C2H5Br"
          },
          {
            "question": "What is the major product when 2-bromobutane reacts with sodium in dry ether?",
            "options": [
              "2,2-Dimethylpropane",
              "Butene",
              "Butane",
              "Propane"
            ],
           correct: "Butane"
          },
          {
            "question": "Which of the following is an example of a haloarene?",
            "options": [
              "C6H5Cl",
              "C2H5Cl",
              "C2H5Br",
              "CH3Cl"
            ],
           correct: "C6H5Cl"
          },
          {
            "question": "Which of the following is a strong electrophilic reagent used in the halogenation of aromatic compounds?",
            "options": [
              "Cl2",
              "Br2",
              "I2",
              "F2"
            ],
           correct: "Cl2"
          }
        ]
      },
      {
        "topic": "Alcohols, Phenols, and Ethers",
        "questions": [
          {
            "question": "Which of the following alcohols cannot be oxidized to an aldehyde?",
            "options": [
              "Methanol",
              "Ethanol",
              "Isopropyl alcohol",
              "Butanol"
            ],
           correct: "Methanol"
          },
          {
            "question": "Which of the following compounds is formed when an alcohol is treated with PCl5?",
            "options": [
              "Alkyl chloride",
              "Alkene",
              "Ether",
              "Aldehyde"
            ],
           correct: "Alkyl chloride"
          },
          {
            "question": "Which of the following compounds is an acidic substance?",
            "options": [
              "Phenol",
              "Toluene",
              "Chlorobenzene",
              "Benzene"
            ],
           correct: "Phenol"
          },
          {
            "question": "Which reagent is used to distinguish between ethanol and phenol?",
            "options": [
              "NaOH",
              "FeCl3",
              "H2SO4",
              "NaHCO3"
            ],
           correct: "FeCl3"
          }
        ]
      },
      {
        "topic": "Aldehydes, Ketones, and Carboxylic Acids",
        "questions": [
          {
            "question": "Which of the following reagents is used to convert aldehydes into carboxylic acids?",
            "options": [
              "K2Cr2O7",
              "NaOH",
              "NaBH4",
              "LiAlH4"
            ],
           correct: "K2Cr2O7"
          },
          {
            "question": "Which of the following compounds gives a positive result in the Tollens' test?",
            "options": [
              "Aldehyde",
              "Ketone",
              "Carboxylic acid",
              "Alcohol"
            ],
           correct: "Aldehyde"
          },
          {
            "question": "Which of the following compounds does not undergo nucleophilic addition?",
            "options": [
              "Aldehyde",
              "Ketone",
              "Carboxylic acid",
              "All of the above"
            ],
           correct: "Carboxylic acid"
          },
          {
            "question": "Which of the following reactions is used to reduce ketones to secondary alcohols?",
            "options": [
              "Hydrogenation",
              "Reduction with LiAlH4",
              "Reduction with NaBH4",
              "Oxidation"
            ],
           correct: "Reduction with NaBH4"
          }
        ]
      },
      {
        "topic": "Amines",
        "questions": [
          {
            "question": "Which of the following is the most basic amine?",
            "options": [
              "Aniline",
              "Methylamine",
              "Dimethylamine",
              "Tertiary butylamine"
            ],
           correct: "Dimethylamine"
          },
          {
            "question": "Which of the following is used to prepare amines from nitro compounds?",
            "options": [
              "Reduction",
              "Electrophilic substitution",
              "Hydrolysis",
              "Decarboxylation"
            ],
           correct: "Reduction"
          },
          {
            "question": "Which of the following is a method for the preparation of aryl amines?",
            "options": [
              "Reduction of nitro compounds",
              "Electrophilic substitution",
              "Dehydration of alcohols",
              "Hydrogenation of ketones"
            ],
           correct: "Reduction of nitro compounds"
          },
          {
            "question": "Which of the following is the most reactive amine?",
            "options": [
              "Tertiary amine",
              "Secondary amine",
              "Primary amine",
              "Aromatic amine"
            ],
           correct: "Primary amine"
          }
        ]
      },
      {
        "topic": "Biomolecules",
        "questions": [
          {
            "question": "Which of the following is the monomer unit of proteins?",
            "options": [
              "Amino acids",
              "Nucleotides",
              "Fatty acids",
              "Monosaccharides"
            ],
           correct: "Amino acids"
          },
          {
            "question": "Which of the following biomolecules is the primary source of energy for living organisms?",
            "options": [
              "Carbohydrates",
              "Proteins",
              "Nucleic acids",
              "Lipids"
            ],
           correct: "Carbohydrates"
          },
          {
            "question": "Which of the following is responsible for the genetic coding in living organisms?",
            "options": [
              "RNA",
              "DNA",
              "Proteins",
              "Carbohydrates"
            ],
           correct: "DNA"
          },
          {
            "question": "Which of the following is the functional group present in all amino acids?",
            "options": [
              "–COOH",
              "–NH2",
              "–OH",
              "–CHO"
            ],
           correct: "–COOH"
          }
        ]
      },
      {
        "topic": "Chemical Kinetics",
        "questions": [
          {
            "question": "In the first-order reaction A → B, the half-life is independent of the concentration of A. What does this imply?",
            "options": [
              "The reaction is zero order",
              "The reaction is second order",
              "The rate constant is constant",
              "The reaction is first order"
            ],
           correct: "The reaction is first order"
          },
          {
            "question": "Which of the following factors increases the rate of a reaction?",
            "options": [
              "Decreasing concentration",
              "Lowering temperature",
              "Increasing surface area",
              "Lowering pressure"
            ],
           correct: "Increasing surface area"
          },
          {
            "question": "The rate of a reaction is directly proportional to the concentration of the reactants raised to the power of 2. What is the order of the reaction?",
            "options": [
              "Zero order",
              "First order",
              "Second order",
              "Third order"
            ],
           correct: "Second order"
          },
          {
            "question": "The rate constant for a first-order reaction has units of:",
            "options": [
              "mol/L·s",
              "L/mol·s",
              "s⁻¹",
              "mol/L"
            ],
           correct: "s⁻¹"
          }
        ]
      }
  ]
  