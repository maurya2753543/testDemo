export const quizQuestions = [
    // Physical and Chemical Changes
    {
        "question": "Which of the following is a physical change?",
        "options": [
            "Burning wood",
            "Dissolving sugar in water",
            "Rusting of iron",
            "Cooking an egg"
        ],
        correct: "Dissolving sugar in water"
    },
    {
        "question": "What is a key characteristic of a chemical change?",
        "options": [
            "No new substance is formed",
            "The change is reversible",
            "A new substance with different properties is formed",
            "The physical state of the substance does not change"
        ],
        correct: "A new substance with different properties is formed"
    },
    {
        "question": "Which of the following processes is a chemical change?",
        "options": [
            "Melting ice",
            "Dissolving salt in water",
            "Burning paper",
            "Freezing water"
        ],
        correct: "Burning paper"
    },
    {
        "question": "Which of the following is NOT an example of a physical change?",
        "options": [
            "Boiling water",
            "Breaking glass",
            "Dissolving salt in water",
            "Iron rusting"
        ],
        correct: "Iron rusting"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Crushing a can",
            "Freezing water",
            "Baking a cake",
            "Dissolving sugar in water"
        ],
        correct: "Baking a cake"
    },
    {
        "question": "When ice melts, what type of change occurs?",
        "options": [
            "Chemical change",
            "Physical change",
            "Both chemical and physical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following is a sign of a chemical change?",
        "options": [
            "Change in size or shape",
            "Formation of a precipitate",
            "Change in state of matter",
            "All of the above"
        ],
        correct: "Formation of a precipitate"
    },
    {
        "question": "When a log burns, which type of change occurs?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "What happens when a chemical change occurs?",
        "options": [
            "The substance's physical state changes",
            "Energy is absorbed or released",
            "A new substance is formed",
            "The chemical bonds are not altered"
        ],
        correct: "A new substance is formed"
    },
    {
        "question": "Which of the following is true about a physical change?",
        "options": [
            "It involves the formation of a new substance",
            "The change is usually irreversible",
            "It only affects the physical properties",
            "The chemical bonds are broken"
        ],
        correct: "It only affects the physical properties"
    },
    {
        "question": "Which of the following is an example of a reversible physical change?",
        "options": [
            "Burning a candle",
            "Dissolving sugar in tea",
            "Rusting of iron",
            "Cooking an egg"
        ],
        correct: "Dissolving sugar in tea"
    },
    {
        "question": "Which process is an example of a chemical change?",
        "options": [
            "Cutting a piece of wood",
            "Boiling water",
            "Corroding of a metal",
            "Melting wax"
        ],
        correct: "Corroding of a metal"
    },
    {
        "question": "Which of the following statements is true about a physical change?",
        "options": [
            "It results in the formation of a new substance",
            "It involves the rearrangement of atoms",
            "The composition of the substance remains unchanged",
            "The substance’s properties change completely"
        ],
        correct: "The composition of the substance remains unchanged"
    },
    {
        "question": "What is an example of a physical change that is also reversible?",
        "options": [
            "Baking a cake",
            "Dissolving salt in water",
            "Burning wood",
            "Rusting of iron"
        ],
        correct: "Dissolving salt in water"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Dissolving sugar in water",
            "Melting ice",
            "Burning gasoline",
            "Freezing water"
        ],
        correct: "Burning gasoline"
    },
    {
        "question": "Which of the following is NOT a physical change?",
        "options": [
            "Cutting a paper",
            "Tearing a cloth",
            "Burning coal",
            "Freezing water"
        ],
        correct: "Burning coal"
    },
    {
        "question": "What is formed during a chemical change?",
        "options": [
            "A new substance with different properties",
            "A substance in the same state of matter",
            "A change in color only",
            "No change occurs"
        ],
        correct: "A new substance with different properties"
    },
    {
        "question": "Which of the following is an indicator of a chemical change?",
        "options": [
            "Change in shape",
            "Change in color",
            "Change in temperature",
            "All of the above"
        ],
        correct: "All of the above"
    },
    {
        "question": "What happens when a substance undergoes a chemical change?",
        "options": [
            "It changes its physical properties only",
            "The new substance retains the properties of the original substance",
            "A new substance with different properties is formed",
            "It cannot be reversed"
        ],
        correct: "A new substance with different properties is formed"
    },
    {
        "question": "Which of the following processes involves a physical change?",
        "options": [
            "Dissolving salt in water",
            "Burning a candle",
            "Decomposing hydrogen peroxide",
            "Baking a cake"
        ],
        correct: "Dissolving salt in water"
    },
    {
        "question": "What is a physical change in matter?",
        "options": [
            "A change that forms a new substance",
            "A change in which the substance remains the same",
            "A change in the chemical structure of the substance",
            "A change that absorbs energy"
        ],
        correct: "A change in which the substance remains the same"
    },
    {
        "question": "What type of change occurs when a piece of paper is torn?",
        "options": [
            "Chemical change",
            "Physical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Dissolving sugar in water",
            "Boiling water",
            "Cooking an egg",
            "Freezing water"
        ],
        correct: "Cooking an egg"
    },
    {
        "question": "Which of the following is a characteristic of a chemical change?",
        "options": [
            "It is easily reversible",
            "It results in the formation of new products",
            "It does not release energy",
            "It only changes the physical state of matter"
        ],
        correct: "It results in the formation of new products"
    },
    {
        "question": "Which of the following is NOT an example of a chemical change?",
        "options": [
            "The rusting of iron",
            "The burning of wood",
            "The freezing of water",
            "The digestion of food"
        ],
        correct: "The freezing of water"
    },
    {
        "question": "When water is heated and changes into steam, it is an example of:",
        "options": [
            "Chemical change",
            "Physical change",
            "Both chemical and physical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following changes is irreversible?",
        "options": [
            "Freezing water",
            "Burning a matchstick",
            "Dissolving sugar in water",
            "Melting wax"
        ],
        correct: "Burning a matchstick"
    },
    {
        "question": "Which of the following reactions is an example of a chemical change?",
        "options": [
            "Boiling water",
            "Burning paper",
            "Shredding paper",
            "Melting ice"
        ],
        correct: "Burning paper"
    },
    {
        "question": "When a nail rusts, what type of change occurs?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "Which of the following is an example of a chemical change in the kitchen?",
        "options": [
            "Baking bread",
            "Melting butter",
            "Freezing water",
            "Boiling pasta"
        ],
        correct: "Baking bread"
    },
    {
        "question": "Which of the following is true about physical changes?",
        "options": [
            "The substance changes into a new substance",
            "The change is reversible",
            "It results in the formation of a new substance",
            "The chemical properties are altered"
        ],
        correct: "The change is reversible"
    },
    {
        "question": "Which of the following changes occurs during a physical change?",
        "options": [
            "Breaking a glass",
            "Burning wood",
            "Rusting of iron",
            "Cooking an egg"
        ],
        correct: "Breaking a glass"
    },
    {
        "question": "Which of the following is an example of a reversible chemical change?",
        "options": [
            "Burning paper",
            "Melting ice",
            "Dissolving salt in water",
            "Photosynthesis in plants"
        ],
        correct: "Photosynthesis in plants"
    },
    {
        "question": "Which of the following is a characteristic of a physical change?",
        "options": [
            "The original substance is converted into a different substance",
            "The change is irreversible",
            "The chemical composition of the substance does not change",
            "New substances with different properties are formed"
        ],
        correct: "The chemical composition of the substance does not change"
    },
    {
        "question": "Which of the following indicates a chemical change has occurred?",
        "options": [
            "The substance changes color",
            "The substance changes state",
            "The substance is dissolved in a solvent",
            "The substance is melted"
        ],
        correct: "The substance changes color"
    },
    {
        "question": "What happens when a chemical reaction occurs?",
        "options": [
            "Only the physical state changes",
            "New substances with different properties are formed",
            "The molecules break but no new substance is formed",
            "The chemical bonds are not affected"
        ],
        correct: "New substances with different properties are formed"
    },
    {
        "question": "Which of the following is an example of a chemical change in the human body?",
        "options": [
            "Breaking down food during digestion",
            "Muscle contraction",
            "Breathing",
            "Sweating"
        ],
        correct: "Breaking down food during digestion"
    },
    {
        "question": "Which of the following is a physical change?",
        "options": [
            "Melting butter",
            "Baking a cake",
            "Rusting of iron",
            "Burning a matchstick"
        ],
        correct: "Melting butter"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Tearing a piece of paper",
            "Freezing water",
            "Baking a cake",
            "Boiling water"
        ],
        correct: "Baking a cake"
    },
    {
        "question": "Which of the following is NOT a sign of a chemical change?",
        "options": [
            "Color change",
            "Formation of a precipitate",
            "Change in temperature",
            "Change in shape"
        ],
        correct: "Change in shape"
    },
    {
        "question": "Which process involves a chemical change?",
        "options": [
            "Cutting a fruit",
            "Boiling water",
            "Rusting of iron",
            "Melting wax"
        ],
        correct: "Rusting of iron"
    },
    {
        "question": "Which of the following is a reversible physical change?",
        "options": [
            "Dissolving sugar in water",
            "Burning wood",
            "Cooking an egg",
            "Decomposing hydrogen peroxide"
        ],
        correct: "Dissolving sugar in water"
    },
    {
        "question": "When a piece of paper burns, it undergoes a:",
        "options": [
            "Chemical change",
            "Physical change",
            "Both chemical and physical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "Which of the following is an example of a physical change?",
        "options": [
            "Dissolving salt in water",
            "Baking bread",
            "Cooking rice",
            "Rusting of iron"
        ],
        correct: "Dissolving salt in water"
    },
    {
        "question": "Which of the following reactions is a chemical change?",
        "options": [
            "Melting ice",
            "Boiling water",
            "Dissolving sugar in water",
            "Electrolysis of water"
        ],
        correct: "Electrolysis of water"
    },
    {
        "question": "What type of change occurs when a metal is corroded?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "Which of the following is a sign of a physical change?",
        "options": [
            "Formation of gas",
            "Color change",
            "Change in size or shape",
            "Change in temperature"
        ],
        correct: "Change in size or shape"
    },
    {
        "question": "Which of the following is an example of a physical change that absorbs energy?",
        "options": [
            "Melting ice",
            "Rusting of iron",
            "Combustion of gasoline",
            "Burning a candle"
        ],
        correct: "Melting ice"
    },
    {
        "question": "Which of the following changes is irreversible?",
        "options": [
            "Boiling water",
            "Tearing a paper",
            "Breaking a glass",
            "Burning wood"
        ],
        correct: "Burning wood"
    },
    {
        "question": "What type of change occurs when a piece of wood is burned?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "Which of the following processes is an example of a chemical change?",
        "options": [
            "Dissolving salt in water",
            "Melting chocolate",
            "Roasting coffee beans",
            "Freezing water"
        ],
        correct: "Roasting coffee beans"
    },
    {
        "question": "Which of the following changes is associated with the release of energy?",
        "options": [
            "Boiling water",
            "Dissolving sugar in tea",
            "Rusting of iron",
            "Burning coal"
        ],
        correct: "Burning coal"
    },
    {
        "question": "Which of the following is an example of a reversible chemical change?",
        "options": [
            "Freezing water",
            "Evaporation of water",
            "Formation of ozone from oxygen",
            "Boiling water"
        ],
        correct: "Formation of ozone from oxygen"
    },
    {
        "question": "Which of the following is a physical property?",
        "options": [
            "Ability to rust",
            "Flammability",
            "Solubility in water",
            "Ability to form a precipitate"
        ],
        correct: "Solubility in water"
    },
    {
        "question": "When water evaporates from a pond, it is an example of:",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Boiling water",
            "Dissolving sugar in water",
            "Burning paper",
            "Melting ice"
        ],
        correct: "Burning paper"
    },
    {
        "question": "Which of the following is NOT an example of a physical change?",
        "options": [
            "Tearing paper",
            "Chopping wood",
            "Melting wax",
            "Rusting of iron"
        ],
        correct: "Rusting of iron"
    },
    {
        "question": "Which process involves a change in the chemical composition of the substance?",
        "options": [
            "Freezing water",
            "Cutting paper",
            "Burning wood",
            "Dissolving salt in water"
        ],
        correct: "Burning wood"
    },
    {
        "question": "What type of change is involved when sugar dissolves in water?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following reactions is a physical change?",
        "options": [
            "Boiling water",
            "Baking bread",
            "Combustion of fuel",
            "Rusting of iron"
        ],
        correct: "Boiling water"
    },
    {
        "question": "Which of the following is an irreversible change?",
        "options": [
            "Crushing a can",
            "Melting ice",
            "Burning a matchstick",
            "Dissolving salt in water"
        ],
        correct: "Burning a matchstick"
    },
    {
        "question": "Which of the following is a chemical change?",
        "options": [
            "Melting butter",
            "Breaking a glass",
            "Rusting of iron",
            "Boiling water"
        ],
        correct: "Rusting of iron"
    },
    {
        "question": "Which of the following processes is a reversible physical change?",
        "options": [
            "Burning paper",
            "Boiling water",
            "Baking a cake",
            "Rusting of iron"
        ],
        correct: "Boiling water"
    },
    {
        "question": "Which of the following is an example of a physical change?",
        "options": [
            "Souring of milk",
            "Burning of wood",
            "Melting of wax",
            "Cooking an egg"
        ],
        correct: "Melting of wax"
    },
    {
        "question": "What occurs during a chemical change?",
        "options": [
            "The substance retains its identity",
            "Energy is released or absorbed",
            "The substance does not change",
            "The shape or size changes"
        ],
        correct: "Energy is released or absorbed"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Melting ice",
            "Tearing paper",
            "Ripping a fabric",
            "Burning wood"
        ],
        correct: "Burning wood"
    },
    {
        "question": "Which of the following changes involves a permanent change?",
        "options": [
            "Freezing water",
            "Dissolving salt in water",
            "Boiling water",
            "Burning coal"
        ],
        correct: "Burning coal"
    },
    {
        "question": "When a piece of paper is torn, the process is an example of:",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following changes is irreversible?",
        "options": [
            "Melting ice",
            "Burning a candle",
            "Freezing water",
            "Boiling an egg"
        ],
        correct: "Burning a candle"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Dissolving sugar in water",
            "Freezing water",
            "Rusting of iron",
            "Breaking a bottle"
        ],
        correct: "Rusting of iron"
    },
    {
        "question": "Which type of change occurs when water freezes?",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "Which of the following is an example of a reversible chemical change?",
        "options": [
            "Freezing water",
            "Electrolysis of water",
            "Burning a paper",
            "Cooking food"
        ],
        correct: "Electrolysis of water"
    },
    {
        "question": "Which of the following processes is an example of a physical change?",
        "options": [
            "Evaporation of water",
            "Burning wood",
            "Rusting of iron",
            "Digestion of food"
        ],
        correct: "Evaporation of water"
    },
    {
        "question": "When a piece of metal is heated and expands, it is undergoing a:",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Physical change"
    },
    {
        "question": "When a candle burns, it undergoes:",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Both physical and chemical change"
    },
    {
        "question": "Which of the following processes is an example of a chemical change?",
        "options": [
            "Freezing water",
            "Boiling water",
            "Burning wood",
            "Melting ice"
        ],
        correct: "Burning wood"
    },
    {
        "question": "Which of the following is a sign of a chemical change?",
        "options": [
            "Change in state",
            "Release of gas",
            "Change in shape",
            "Change in size"
        ],
        correct: "Release of gas"
    },
    {
        "question": "Which of the following is a physical change?",
        "options": [
            "Rusting of iron",
            "Burning of paper",
            "Melting of wax",
            "Cooking of food"
        ],
        correct: "Melting of wax"
    },
    {
        "question": "What happens to the chemical properties of a substance in a physical change?",
        "options": [
            "They change",
            "They remain the same",
            "They disappear",
            "They become unimportant"
        ],
        correct: "They remain the same"
    },
    {
        "question": "Which of the following processes is a chemical change?",
        "options": [
            "Dissolving salt in water",
            "Breaking a glass",
            "Burning of fuel",
            "Cutting paper"
        ],
        correct: "Burning of fuel"
    },
    {
        "question": "Which of the following is NOT a physical change?",
        "options": [
            "Melting of ice",
            "Boiling of water",
            "Dissolving sugar in water",
            "Cooking of food"
        ],
        correct: "Cooking of food"
    },
    {
        "question": "Which of the following is an irreversible physical change?",
        "options": [
            "Freezing water",
            "Boiling water",
            "Melting of wax",
            "Breaking of glass"
        ],
        correct: "Breaking of glass"
    },
    {
        "question": "Which of the following is a characteristic of chemical changes?",
        "options": [
            "Energy is absorbed or released",
            "The substance retains its identity",
            "No new substance is formed",
            "The change can be reversed easily"
        ],
        correct: "Energy is absorbed or released"
    },
    {
        "question": "Which of the following processes is a reversible chemical change?",
        "options": [
            "Boiling of water",
            "Burning of paper",
            "Electrolysis of water",
            "Rusting of iron"
        ],
        correct: "Electrolysis of water"
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "options": [
            "Melting of ice",
            "Dissolving sugar in water",
            "Cooking of an egg",
            "Freezing of water"
        ],
        correct: "Cooking of an egg"
    },
    {
        "question": "Which of the following occurs during a chemical change?",
        "options": [
            "Change in shape",
            "Change in size",
            "Formation of a new substance",
            "Change in temperature"
        ],
        correct: "Formation of a new substance"
    },
    {
        "question": "Which of the following is NOT a sign of a chemical change?",
        "options": [
            "Change in color",
            "Formation of a precipitate",
            "Release of light",
            "Change in temperature"
        ],
        correct: "Change in temperature"
    },
    {
        "question": "Which of the following is a physical change?",
        "options": [
            "Burning of paper",
            "Rusting of iron",
            "Freezing of water",
            "Digestion of food"
        ],
        correct: "Freezing of water"
    },
    {
        "question": "When a metal reacts with acid and produces gas, it is an example of:",
        "options": [
            "Physical change",
            "Chemical change",
            "Both physical and chemical change",
            "Neither"
        ],
        correct: "Chemical change"
    },
    {
        "question": "Which of the following changes occurs without changing the chemical composition of a substance?",
        "options": [
            "Evaporation of water",
            "Burning of paper",
            "Corrosion of iron",
            "Digestion of food"
        ],
        correct: "Evaporation of water"
    },
    {
        "question": "Which of the following is an example of an exothermic chemical change?",
        "options": [
            "Melting of ice",
            "Freezing of water",
            "Rusting of iron",
            "Burning of wood"
        ],
        correct: "Burning of wood"
    },
    {
        "question": "Which of the following is a characteristic of physical changes?",
        "options": [
            "A new substance is formed",
            "The substance retains its identity",
            "Energy is absorbed or released",
            "The change cannot be reversed"
        ],
        correct: "The substance retains its identity"
    },
    {
        "question": "Which of the following is an example of a reversible physical change?",
        "options": [
            "Burning wood",
            "Boiling of water",
            "Rusting of iron",
            "Cooking of food"
        ],
        correct: "Boiling of water"
    }
];
