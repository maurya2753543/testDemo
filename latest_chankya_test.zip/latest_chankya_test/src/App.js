import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './header/NavBar'; // Assuming NavBar is inside a 'components' folder
import Connect from './connect/Connect'; // Connect page component
import Dashboard from './dashboard/Dashboard'; // Dashboard page component
import TabLayout from './dashboard/TabLayout';
import 'font-awesome/css/font-awesome.min.css';
import RetrievePassword from './dashboard/RetrievePassword';
import StudentRegistration from './dashboard/StudentRegistration';
import TabContent from './dashboard/DashbordContent';
import  MainHomeForm from './header/MainHomeForm';
import MathGgeniusProgram from './maths-genius-program-level1/MathGgeniusProgram';
import AppSideNav from './math-genius/side-nav-math';
import AppSideNavKBC from './kbc/side-nav-math-kbc';
import KBCGeniusProgram from './kbc/KBCGeniusProgram';
import Settings from './dashboard/Settings';
import ProtectedRoute from './ProtectedRoute';
import PaymentSuccess from './dashboard/PaymentSuccess';
import ResetPassword from './header/ResetPassword';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Function to handle successful login
  const handleLoginSuccess = () => {
    setIsLoggedIn(true); // Update state to indicate user is logged in
  };
  const isUserAuthenticated = () => {
    // Replace with your authentication logic (e.g., checking JWT token or user state)
    return !!localStorage.getItem('authToken');
  };
  
  return (

    // <Router>
    //   {/* NavBar is rendered on all routes */}
      
    //   <Routes>
    //     {/* Define your routes here */}
    //     <Route path="/" element={<NavBar />} />
    //     <Route path="/about-us" element={<Connect />} />     
    //     <Route path="/dashboard/retrieve-password" element={<RetrievePassword />} />
    //     <Route path="/dashboard/student-registration" element={<StudentRegistration />} /> 
    //     <Route path="/dashboard" element={<Dashboard />} />
    //     <Route path="/dashboard/user" element={<TabLayout />} />      
    //     <Route path="/dashboard/settings" element={<Settings />} />
    //     <Route path="/book-classes" element={<MainHomeForm />} />
    //     <Route path="/courses/maths-genius-level-2-5" element={<MathGgeniusProgram />} />        
    //     <Route path="/lesson/maths-chanakya-class-2-to-5/" element={<AppSideNav />} />
    //     <Route path="/lesson/page-chanakya-kbc/" element={<AppSideNavKBC />} />

    //     <Route path="/courses/kbc-genius-level-quiz" element={<KBCGeniusProgram />} />


        

       

    //   </Routes>

    //   {/* <TabLayout /> */}
    
    // </Router>
    <Router>
  <Routes>
    <Route path="/" element={<NavBar />} />
    <Route path="/score-dashbord" element={<Connect />} />    
    
    {/* Protected routes */}
    <Route
      path="/dashboard"
      element={
        <ProtectedRoute element={Dashboard} isAuthenticated={isUserAuthenticated} />
      }
    />
    <Route
      path="/dashboard/user"
      element={
        <ProtectedRoute element={TabLayout} isAuthenticated={isUserAuthenticated} />
      }
    />
    <Route
      path="/dashboard/settings"
      element={
        <ProtectedRoute element={Settings} isAuthenticated={isUserAuthenticated} />
      }
    />
    <Route
      path="/lesson/maths-chanakya-class-2-to-10/"
      element={
        <ProtectedRoute element={AppSideNav} isAuthenticated={isUserAuthenticated} />
      }
    />
    <Route
      path="/lesson/page-chanakya-kbc/"
      element={
        <ProtectedRoute element={AppSideNavKBC} isAuthenticated={isUserAuthenticated} />
      }
    />
    {/* Other public routes */}
    {/* <Route path="/dashboard" element={<Dashboard />} /> */}
    <Route path="/courses/maths-genius-level-2-10" element={<MathGgeniusProgram />} />
    <Route path="/courses/kbc-genius-level-quiz" element={<KBCGeniusProgram />} />
    <Route path="/payment-success" element={<PaymentSuccess />} />
    <Route path="/reset-password" element={<ResetPassword />} />

  </Routes>
</Router>

  );
}

export default App;
