import React, { useState, useEffect } from 'react';
import './KbcHeader.css'; // Import your CSS file for styling
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import KbcContentTopicFor from '../math-genius/KbcContentTopicFor';
import AppwriteService from '../appwrite/AppwriteService';


const KbcHeader = () => {
    const navigate = useNavigate();
    const [name, setName] = useState('');

    const handleNavigationcourse = () => {
        navigate(`/lesson/page-chanakya-kbc/`);        
      };

      
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get();
      
        setName(user.name);
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);
  return (
    <>
    <div className="main-container-math">
    <div className="container course-single-title-top">
      <div className="row">
        <div className="col-md-8">
          <h1 className="tutor-course-header-h1">Hi {name},  Brain Bank: The KBC Experience! && UPSE Exam</h1>
          <h1 className="tutor-course-header-h1">KBC Quest: Knowledge Is Wealth </h1>
         
        </div>
      </div>
      <div className="row mt-3">
        {/* Column for Course Level */}
        <div className="col text-center">
          <p className="color-math">Novice to Master Course Level</p>
          <h3 className="m-0">Low - Intermediate -  High</h3>
        </div>
        {/* Column for Video Tutorials */}
        <div className="col text-center1">
          <span className="color-math">Quiz Tutorials</span>
          <h3 className="m-0">60</h3>
        </div>
        {/* Column for Continue to Lesson Button */}
        <div className="col ">
          <button  onClick={() => handleNavigationcourse()} className="btn btn-custom">CONTINUE TO LESSON</button> <br />        

          <span  className="text_complate color-math">Complete all this course as mark complete.</span>

        </div>
     
      </div>
    </div>
    </div>
    <div style={{marginLeft: '30px'}}>
        <KbcContentTopicFor/>
      </div>
   
    </>
   
  );
};

export default KbcHeader;
