import React, { useState, useEffect } from 'react';
import quizData from './QuizmatchColumnLevelTwo.json'; // Ensure the path is correct for your JSON file
import './QuizmatchColumn.css';

const LineMatchingQuiz = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userOrder, setUserOrder] = useState([]);
  const [showSubmit, setShowSubmit] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(7200); // 2 hours in seconds
  const [isCorrect, setIsCorrect] = useState(null); // Track if the answer is correct
  const [message, setMessage] = useState(''); // Message to display (Correct/Incorrect)

  // Fetch the current question
  const currentQuestion = quizData[currentQuestionIndex];

  // Timer function
  useEffect(() => {
    if (timeRemaining > 0) {
      const timerInterval = setInterval(() => {
        setTimeRemaining((prevTime) => prevTime - 1);
      }, 1000);
      return () => clearInterval(timerInterval);
    }
  }, [timeRemaining]);

  // Format the remaining time into minutes and seconds
  const formatTime = () => {
    const hours = Math.floor(timeRemaining / 3600);
    const minutes = Math.floor((timeRemaining % 3600) / 60);
    const seconds = timeRemaining % 60;
    return `${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  // Handle user's selection for each answer
  const handleSelectChange = (index, selectedValue) => {
    const updatedOrder = [...userOrder];
    updatedOrder[index] = selectedValue;
    setUserOrder(updatedOrder);

    // Check if user has selected answers for all options
    if (updatedOrder.length === currentQuestion.questions.length) {
      setShowSubmit(true);
    }
  };

  // Handle the submit button
  const handleSubmit = () => {
    const isCorrectAnswer = currentQuestion.questions.every(
      (question, index) => question.options.find(option => option.answer === userOrder[index] && option.isCorrect)
    );

    if (isCorrectAnswer) {
      setIsCorrect(true);
      setMessage('Correct! You can proceed to the next question.');
    } else {
      setIsCorrect(false);
      setMessage('Incorrect match. Please try again!');
    }
  };

  // Handle the "Next" button click
  const handleNext = () => {
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setUserOrder([]);
      setShowSubmit(false);
      setIsCorrect(null);
      setMessage('');
    }
  };

  // Handle the reset button
  const handleReset = () => {
    setCurrentQuestionIndex(0);
    setUserOrder([]);
    setShowSubmit(false);
    setIsCorrect(null);
    setMessage('');
    setTimeRemaining(7200); // Reset time to 2 hours
  };

  return (
    <div className="quiz-container">
      <h2>{currentQuestion.commonQuestion}</h2>

      {/* Display timer */}
      <div className="timer">
        <h3>Time Remaining: {formatTime()}</h3>
      </div>

      <div className="matching-grid">
        {/* Column A: Show questions (countries) */}
        <div className="column column-a">
          <h3>Questions</h3>
          {currentQuestion.questions.map((question, index) => (
            <div key={index} className="question-item">
              <p>{question.painting}</p>
            </div>
          ))}
        </div>

        {/* Column B: Show dropdown options */}
        <div className="column column-b">
          <h3>Select the Correct Capital</h3>
          {currentQuestion.questions.map((question, index) => (
            <select
              key={index}
              onChange={(e) => handleSelectChange(index, e.target.value)}
              value={userOrder[index] || ''}
              className="matching-dropdown"
            >
              <option value="" disabled>
                Select Capital
              </option>
              {question.options.map((option, i) => (
                <option key={i} value={option.answer}>
                  {option.answer}
                </option>
              ))}
            </select>
          ))}
        </div>
      </div>
       {/* Submit Button */}
       {showSubmit && (
        <button onClick={handleSubmit} className="submit-button">
          Submit
        </button>
      )}
      {!isCorrect && (
        <button  style={{ marginLeft : '100px', 
          padding : '15px' , width : '150px'}}  onClick={handleReset} className="reset-button">
          Restart Quiz
        </button>
      )}
      {isCorrect && currentQuestionIndex < quizData.length - 1 && (
        <button style={{ marginLeft : '100px', 
        padding : '15px' , width : '150px'}} onClick={handleNext} className="reset-button" >
          Next  → 
        </button>
      )}

     

      {/* Show Message */}
      <div className="message">
        {message && <p>{message}</p>}
      </div>

      {/* Show Next button if the answer is correct */}
     

      {/* Show restart button after incorrect answer */}
      

      {/* Show restart button after the last question */}
      {currentQuestionIndex === quizData.length - 1 && showSubmit && isCorrect && (
        <button onClick={handleReset} className="reset-button">
          Restart Quiz
        </button>
      )}
    </div>
  );
};

export default LineMatchingQuiz;
