import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBookOpen, faCheckCircle, faCircle, faHome } from '@fortawesome/free-solid-svg-icons';
import { faYoutube } from '@fortawesome/free-brands-svg-icons';
import {  useNavigate } from 'react-router-dom';
import DashboardPopup from '../math-genius/DashboardPopup'; // Import the DashboardPopup component
import "./side-nav-math-kbc.css";
import QuizCalculatorMultiChoice from './QuizCalculatorMultiChoice';
import QuizCalculatorMugal from './QuizCalculatorMugal';
import ModernHistory from './ModernHistory';
import FamousScientists from './FamousScientists';
import GeographyKbc from './GeographyKbc';
import GeographyRiver from './GeographyRiver';
import IndianConstitution from './IndianConstitution';
import PhysicsLaws from './PhysicsLaws';
import BiologicalKbc from './BiologicalKbc';
import OrderQuizApp from './OrderQuizApp';
import QuizArrangeLevel1 from './QuizArrangeLevel1';
import OrderQuizAppLevel2 from './OrderQuizAppLevel2';
import OrderQuizAppLevel3 from './OrderQuizAppLevel3';
import OrderQuizAppLevel4 from './OrderQuizAppLevel4';
import OrderQuizAppLevel5 from './OrderQuizAppLevel5';
import QuizmatchColumn from './QuizmatchColumn';
import QuizmatchColumnLevelTwo from './QuizmatchColumnLevelTwo';
import QuizmatchColumnLevelThree from './QuizmatchColumnLevelThree';
import QuizmatchColumnLevelFour from './QuizmatchColumnLevelFour';
import QuizmatchColumnLevelFive from './QuizmatchColumnLevelFive';
import QuizmatchColumnLevelSix from './QuizmatchColumnLevelSix';
import Pythagorean from './Pythagorean';
import Chemistry from './kbc-level-two/Chemistry';
import NobelPrizewinner from'./kbc-level-two/NobelPrizewinner';
import FamousAuther from './kbc-level-two/FamousAuther';
import Sports from './kbc-level-two/Sports';
import ClassicalDances from './kbc-level-two/ClassicalDances';
import MajorGlobalEvents from './kbc-level-two/MajorGlobalEvents';
import WorldMap from './WorldMap';
import WorldMapStatewise from './WorldMapStatewise';
import FamousBattles from './kbc-level-two/FamousBattles';
import PoliticalScience from './kbc-level-two/PoliticalScience';
import SpaceScience from './kbc-level-two/SpaceScience';
import ComputerFundamentals from './kbc-level-two/ComputerFundamentals';
import FamousEnvironmentalists from './kbc-level-three/FamousEnvironmentalists';
import BasicConceptsGDP from './kbc-level-three/BasicConceptsGDP';
import TheirTributaries from './kbc-level-three/TheirTributaries';
import IndianGods from './kbc-level-three/IndianGods';
import WorldWarHistory from './kbc-level-three/WorldWarHistory';
import ImportantFreedom from './kbc-level-three/ImportantFreedom';
import SpaceExplorations from './kbc-level-three/SpaceExplorations';
import Monuments from './kbc-level-three/Monuments';
import FolkDances from './kbc-level-three/FolkDances';
import ConstitutionAmendments from './kbc-level-three/ConstitutionAmendments';
import EnvironmentalScience from './kbc-level-four/EnvironmentalScience';
import FamousMathematicians from './kbc-level-four/FamousMathematicians';
import RenaissancePeriod from './kbc-level-four/RenaissancePeriod';
import LiteratureNobel from './kbc-level-four/LiteratureNobel';
import GreatEmperors from './kbc-level-four/GreatEmperors';
import ArtandArchitecture from './kbc-level-four/ArtandArchitecture';
import MajorIndianFestivals from './kbc-level-four/MajorIndianFestivals';
import TheoryofRelativity from './kbc-level-four/TheoryofRelativity';
import EconomicPlanning from './kbc-level-four/EconomicPlanning';
import ISROMissions from './kbc-level-four/ISROMissions';
import SignificantGlobalMovements from './kbc-level-five/SignificantGlobalMovements';
import ResearchAchievements from './kbc-level-five/ResearchAchievements';
import CulturalHeritage from './kbc-level-five/CulturalHeritage';
import FamousGlobalLeaders from './kbc-level-five/FamousGlobalLeaders';
import EndangeredSpecies from './kbc-level-five/EndangeredSpecies';
import BasicEconomic from './kbc-level-five/BasicEconomic';
import AncientGreek from './kbc-level-five/AncientGreek';
import RecentScientific from './kbc-level-five/RecentScientific';
import IndianArmedForces from './kbc-level-five/IndianArmedForces';
import BlackHoles from './kbc-level-five/BlackHoles';
import Indiagovernment from './kbc-level-six/Indiagovernment';
import SummitsandConferences from './kbc-level-six/SummitsandConferences';
import GovernmentSchemes from './kbc-level-six/GovernmentSchemes';
import IndianCulture from './kbc-level-six/IndianCulture';
import ModernIndianHistory from './kbc-level-six/ModernIndianHistory';
import ScienceTechnologyCurrentAffairs from './kbc-level-six/ScienceTechnologyCurrentAffairs';
import EmpressofIndia from './kbc-level-six/EmpressofIndia';
import WorldHistory from './kbc-level-six/WorldHistory';
import EnvironmentBiodiversity from './kbc-level-six/EnvironmentBiodiversity';
import FastestFingerFirst from './kbc-level-six/FastestFingerFirst';




function AppSideNavKBC() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSection, setExpandedSection] = useState(null); // Track expanded section
  const [completedCourses, setCompletedCourses] = useState(["0-0"]); // Track completed courses, including the first one by default

  const navigate = useNavigate();

  const [activeContent, setActiveContent] = useState({
    sectionIndex: 0,
    contentIndex: 0,
    title: "Ancient Indian History - Harappan Civilization (KBC 2000)",
    icon: faYoutube,
    
  });
  //const [completedCourses, setCompletedCourses] = useState([]); // Track completed courses
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const handlePopupOpen = () => {
    setIsPopupOpen(true); // Open popup
  };

  const handlePopupClose = () => {
    setIsPopupOpen(false); // Close popup
  };

  const handleConfirmNavigation = async () => {
    handlePopupClose(); // Close the popup
    try {
      navigate('/dashboard'); // Redirect to dashboard
    } catch (error) {
      console.error("Error navigating to dashboard:", error);
    }
  };

  const sections = [
    {
      title: "Historical and Cultural Activities && Current Affairs and Science Activitie",
      content: [
        { label: "Ancient Indian History - Harappan Civilization (KBC 2000)", icon: faYoutube },          
        { label: "Mughal Emperors and their Contributions (KBC 2001)", icon: faYoutube },          
        { label: "Modern History - Indian Independence Movement (KBC 2002)", icon: faYoutube },          
        { label: "Famous Scientists and their Inventions (KBC 2003)", icon: faYoutube },          
        { label: "Geography: World All States and their Capitals (KBC 2004)", icon: faYoutube },          
        { label: "World Geography:Currency,Language,Famous for, Rivers, Mountains, and Deserts (KBC 2005)", icon: faYoutube },          
        { label: "Constitution of India: Important Articles (KBC 2006)", icon: faYoutube },          
        { label: "Science: Basic Physics Laws - Newton's Laws && All Law (KBC 2007)", icon: faYoutube },          
        { label: "Biology: Human Anatomy - Digestive System (KBC 2008)", icon: faYoutube },          
        { label: "Mathematics: Pythagorean Theorem and Applications (KBC 2009)", icon: faYoutube },          

        
               
       

      ]
    },
    {
      title: "KBC Pre Level 2",
      content: [
        { label: "Chemistry: Periodic Table Elements and their Properties (KBC 2010)", icon: faYoutube },
        { label: "Current Affairs: Recent Nobel Prize Winners (KBC 2011)", icon: faYoutube },     
        { label: "Famous Indian Authors, All Authors, and their Works (KBC 2012)", icon: faYoutube },     
        { label: "Sports: Cricket World Cup Winners by Year (KBC 2013)", icon: faYoutube },     
        { label: "Indian Classical Dances and Their Origins (KBC 2014)", icon: faYoutube },     
        { label: "Current Affairs: Major Global Events - Olympics (KBC 2015)", icon: faYoutube },     
        { label: "Famous Battles in Indian History - Panipat, Plassey (KBC 2016)", icon: faYoutube },     
        { label: "Political Science: Indian Parliament Structure (KBC 2017)", icon: faYoutube },     
        { label: "Space Science: Solar System and Planets (KBC 2018)", icon: faYoutube },     
        { label: "Technology: Computer Fundamentals and Internet (KBC 2019)", icon: faYoutube },     

        
        
       
      ]
    },
    {
      title: "KBC Pro Level 3",
      content: [
        { label: "Environment: Famous Environmentalists (KBC 2020)", icon: faYoutube },
        { label: "Economics: Basic Concepts of GDP, Inflation (KBC 2021)", icon: faYoutube },
        { label: "Indian Rivers and their Tributaries (KBC 2022)", icon: faYoutube },
        { label: "Mythology: Indian Gods and Goddesses (KBC 2023)", icon: faYoutube },
        { label: "World War History - Key Events and Figures (KBC 2001)", icon: faYoutube },
        { label: "Important Freedom Fighters of India (KBC 2002)", icon: faYoutube },
        { label: "Space Explorations and Missions (KBC 2005)", icon: faYoutube },
        { label: "Global Famous Landmarks and Monuments (KBC 2003)", icon: faYoutube },
        { label: "Folk Dances from Different States of India (KBC 2007)", icon: faYoutube },
        { label: "Indian Constitution Amendments and Articles (KBC 2008)", icon: faYoutube },

                         
        
      ]
    },
    {
      title: "KBC Pro Level 4",
      content: [
        { label: "Environmental Science: Global Warming (KBC 2010)", icon: faYoutube },
        { label: "Famous Mathematicians and their Theorems (KBC 2006)", icon: faYoutube },
        { label: "Renaissance Period and Key Figures (KBC 2011)", icon: faYoutube },
        { label: "Literature: Nobel Prize Winners in Literature (KBC 2014)", icon: faYoutube },
        { label: "Great Emperors and Conquerors of the World (KBC 2015)", icon: faYoutube },
        { label: "Art and Architecture of India (KBC 2016)", icon: faYoutube },
        { label: "Major Indian Festivals and Their Significance (KBC 2018)", icon: faYoutube },
        { label: "Physics: Theory of Relativity (KBC 2019)", icon: faYoutube },
        { label: "Economic Planning in India (KBC 2021)", icon: faYoutube },
        { label: "Science and Technology - ISRO Missions (KBC 2017)", icon: faYoutube },

        
        
        
        
        


       
        
      ]
    },
    {
      title: "KBC Pro Level 5",
      content: [
        { label: "Significant Global Movements - Civil Rights (KBC 2020)", icon: faYoutube },
        { label: "Indian Space Research Achievements (KBC 2022)", icon: faYoutube },
        { label: "Cultural Heritage Sites in India (KBC 2013)", icon: faYoutube },
        { label: "Famous Global Leaders in History (KBC 2004)", icon: faYoutube },
        { label: "Endangered Species and Conservation (KBC 2012)", icon: faYoutube },
        { label: "Indian Economy: Basic Economic Terms (KBC 2009)", icon: faYoutube },
        { label: "Ancient Greek and Roman Mythology (KBC 2000)", icon: faYoutube },
        { label: "Recent Scientific Breakthroughs (KBC 2008)", icon: faYoutube },
        { label: "Indian Armed Forces: Major Operations (KBC 2014)", icon: faYoutube },
        { label: "Space Science: Black Holes and Stars (KBC 2016)", icon: faYoutube },

        
        
        
        
        


       
        
      ]
    },
    {
      title: "KBC Pro Level 6",
      content: [
        { label: "India-government-politics-current-affairs", icon: faYoutube },
        { label: "Summits and Conferences in Current Affairs MCQs", icon: faYoutube },
        { label: "The Enigma of Black Holes", icon: faYoutube },

        { label: "Government Schemes [India & States]", icon: faYoutube },
        { label: "Indian Culture MCQs", icon: faYoutube },
        { label: "Science & Technology Current Affairs MCQs", icon: faYoutube },
        { label: "Empress of India MCQs", icon: faYoutube },
        { label: "World History MCQs", icon: faYoutube },
        { label: "Environment & Biodiversity MCQs", icon: faYoutube },
        { label: "Modern Indian History MCQs", icon: faYoutube },
        { label: "Fastest Finger First KBC", icon: faYoutube },

        
        
        
        
        


       
        
      ]
    },
    {
      title: "KBC Arrange Order Question ( Practice Questions ) ",
      content: [
      
       
        { label: "Arrange Order Question", icon: faYoutube },
        { label: "Arrange Order Question Level One", icon: faYoutube },
        { label: "Arrange Order Question Level Two", icon: faYoutube },
        { label: "Arrange Order Question Level Three", icon: faYoutube },
        { label: "Arrange Order Question Level Four", icon: faYoutube },
        { label: "Arrange Order Question Level Five", icon: faYoutube },


       
      ]
    },
    {
      title: "KBC Match Order  Question ( Practice Questions ) ",
      content: [
      
       
        { label: "Match Order Question level One", icon: faYoutube },
        { label: "Match Order Question level Two", icon: faYoutube },
        { label: "Match Order Question level Three", icon: faYoutube },
        { label: "Match Order Question level Four", icon: faYoutube },
        { label: "Match Order Question level Five", icon: faYoutube },
        { label: "Match Order Question level Six", icon: faYoutube },

        
      ]
    },
    {
      title: "World Map with Country Area Tooltip ( Practice Questions ) ",
      content: [
      
       
        { label: "World Map with Country Area Tooltip", icon: faYoutube },
        { label: "Interactive India States Map", icon: faYoutube },

       
        
      ]
    },
    {
      title: "KBC Glory: The Quick Final Challenge (SCORE TRACKER Graph)  ",
      content: [
      
       
        { label: "The Quick Final Challenge Level 1", icon: faYoutube },

       
        
      ]
    }

    


   // QuizmatchColumn

  ];

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleContentClick = (sectionIndex, contentIndex, content) => {
    setActiveContent({
      sectionIndex,
      contentIndex,
      title: content.label,
      icon: content.icon,
      video: content.video,
    });

    if (!completedCourses.includes(`${sectionIndex}-${contentIndex}`)) {
      setCompletedCourses([...completedCourses, `${sectionIndex}-${contentIndex}`]);
    }
  };

  return (
    <> 
     <div className="app-container">
      <div className={`sidebar-math ${isExpanded ? "expanded" : "collapsed"}`}>
        <div className="tutor-tabs-btn-group">
          <a href="#tutor-lesson-sidebar-tab-content">
            <FontAwesomeIcon style={{ color: '#ff5248' }} icon={faBookOpen} />
            <span className="Lesson-title"> Lesson List</span>
          </a>
        </div>

        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="section">
            <div className="section-title" onClick={() => toggleSection(sectionIndex)}>
              <FontAwesomeIcon /> {section.title} <span className="expend-icon-penal"> {expandedSection === sectionIndex ? "-" : "+"} </span>
            </div>
            {expandedSection === sectionIndex && (
              <div className="section-content tutor-lessons-under-topic">
                <ul>
                  {section.content.map((item, contentIndex) => (
                    <li
                      key={contentIndex}
                      className={`content-item ${activeContent.sectionIndex === sectionIndex && activeContent.contentIndex === contentIndex ? "active-content" : '' }`}
                    >
                      <a href="#!" onClick={() => handleContentClick(sectionIndex, contentIndex, item)} className="content-link">
                        <div className="content-info">
                          <div className="content-left">
                            <FontAwesomeIcon icon={item.icon} style={{ marginRight: "8px" }} />
                            <span>{item.label}</span>
                          </div>
                          <div className="content-right">
                            <span className="content-timing">Min</span>
                            <FontAwesomeIcon
                              icon={completedCourses.includes(`${sectionIndex}-${contentIndex}`) ? faCheckCircle : faCircle}
                              className="completion-icon"
                            />
                          </div>
                        </div>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="content-side-bar">
        <div className="video-player-header">
          <button className="toggle-btn" onClick={toggleSidebar}>
            {isExpanded ? ">" : "<"}
          </button>
          {/* Home Icon and Go to Home Message */}
          <span  onClick={handlePopupOpen} className="go-home">
            <FontAwesomeIcon icon={faHome} />  Go to Course Dashboard
          </span>
          <span className="header-title-side-bar">
            <h3><FontAwesomeIcon icon={activeContent.icon} /> {activeContent.title}</h3>
          </span>
        </div>
        {/* <video src={activeContent.video} controls width="100%" autoPlay /> */}
        
        {/* Conditionally show QuizCalculatorMulti if "The Beauty of 11" is selected */}
        {activeContent.title === "Ancient Indian History - Harappan Civilization (KBC 2000)" && <QuizCalculatorMultiChoice />}
        {activeContent.title === "Mughal Emperors and their Contributions (KBC 2001)" && <QuizCalculatorMugal />}
        {activeContent.title === "Modern History - Indian Independence Movement (KBC 2002)" && <ModernHistory />}
        {activeContent.title === "Famous Scientists and their Inventions (KBC 2003)" && <FamousScientists/>}
        {activeContent.title === "Geography: World All States and their Capitals (KBC 2004)" && <GeographyKbc/>}
        {activeContent.title === "World Geography:Currency,Language,Famous for, Rivers, Mountains, and Deserts (KBC 2005)" && <GeographyRiver/>}
        {activeContent.title === "Constitution of India: Important Articles (KBC 2006)" && <IndianConstitution/>}
        {activeContent.title === "Science: Basic Physics Laws - Newton's Laws && All Law (KBC 2007)" && <PhysicsLaws/>}
        {activeContent.title === "Biology: Human Anatomy - Digestive System (KBC 2008)" && <BiologicalKbc/>}
        {activeContent.title === "Mathematics: Pythagorean Theorem and Applications (KBC 2009)" && <Pythagorean/>}
        {activeContent.title === "Chemistry: Periodic Table Elements and their Properties (KBC 2010)" && <Chemistry/>}
        {activeContent.title === "Current Affairs: Recent Nobel Prize Winners (KBC 2011)" && <NobelPrizewinner/>}
        {activeContent.title === "Famous Indian Authors, All Authors, and their Works (KBC 2012)" && <FamousAuther/>}
        {activeContent.title === "Sports: Cricket World Cup Winners by Year (KBC 2013)" && <Sports/>}
        {activeContent.title === "Indian Classical Dances and Their Origins (KBC 2014)" && <ClassicalDances/>}
        {activeContent.title === "Current Affairs: Major Global Events - Olympics (KBC 2015)" && <MajorGlobalEvents/>}
        {activeContent.title === "Famous Battles in Indian History - Panipat, Plassey (KBC 2016)" && <FamousBattles/>}
        {activeContent.title === "Political Science: Indian Parliament Structure (KBC 2017)" && <PoliticalScience/>}
        {activeContent.title === "Space Science: Solar System and Planets (KBC 2018)" && <SpaceScience/>}
        {activeContent.title === "Technology: Computer Fundamentals and Internet (KBC 2019)" && <ComputerFundamentals/>}
        {activeContent.title === "Economics: Basic Concepts of GDP, Inflation (KBC 2021)" && <BasicConceptsGDP/>}
        {activeContent.title === "Indian Rivers and their Tributaries (KBC 2022)" && <TheirTributaries/>}
        {activeContent.title === "Mythology: Indian Gods and Goddesses (KBC 2023)" && <IndianGods/>}
        {activeContent.title === "World War History - Key Events and Figures (KBC 2001)" && <WorldWarHistory/>}
        {activeContent.title === "Important Freedom Fighters of India (KBC 2002)" && <ImportantFreedom/>}

        {activeContent.title === "Space Explorations and Missions (KBC 2005)" && <SpaceExplorations/>}
        {activeContent.title === "Global Famous Landmarks and Monuments (KBC 2003)" && <Monuments/>}
        {activeContent.title === "Folk Dances from Different States of India (KBC 2007)" && <FolkDances/>}
        {activeContent.title === "Indian Constitution Amendments and Articles (KBC 2008)" && <ConstitutionAmendments/>}
        {activeContent.title === "Environmental Science: Global Warming (KBC 2010)" && <EnvironmentalScience/>}
        {activeContent.title === "Famous Mathematicians and their Theorems (KBC 2006)" && <FamousMathematicians/>}

        {activeContent.title === "Renaissance Period and Key Figures (KBC 2011)" && <RenaissancePeriod/>}
        {activeContent.title === "Literature: Nobel Prize Winners in Literature (KBC 2014)" && <LiteratureNobel/>}
        {activeContent.title === "Great Emperors and Conquerors of the World (KBC 2015)" && <GreatEmperors/>}
        {activeContent.title === "Art and Architecture of India (KBC 2016)" && <ArtandArchitecture/>}
        {activeContent.title === "Major Indian Festivals and Their Significance (KBC 2018)" && <MajorIndianFestivals/>}
        {activeContent.title === "Physics: Theory of Relativity (KBC 2019)" && <TheoryofRelativity/>}
        {activeContent.title === "Economic Planning in India (KBC 2021)" && <EconomicPlanning/>}

        {activeContent.title === "Science and Technology - ISRO Missions (KBC 2017)" && <ISROMissions/>}

        {activeContent.title === "Significant Global Movements - Civil Rights (KBC 2020)" && <SignificantGlobalMovements/>}
        {activeContent.title === "Indian Space Research Achievements (KBC 2022)" && <ResearchAchievements/>}

        {activeContent.title === "Cultural Heritage Sites in India (KBC 2013)" && <CulturalHeritage/>}

        {activeContent.title === "Famous Global Leaders in History (KBC 2004)" && <FamousGlobalLeaders/>}

        {activeContent.title === "Endangered Species and Conservation (KBC 2012)" && <EndangeredSpecies/>}

        {activeContent.title === "Indian Economy: Basic Economic Terms (KBC 2009)" && <BasicEconomic/>}

        {activeContent.title === "Ancient Greek and Roman Mythology (KBC 2000)" && <AncientGreek/>}

        {activeContent.title === "Recent Scientific Breakthroughs (KBC 2008)" && <RecentScientific/>}

        {activeContent.title === "Indian Armed Forces: Major Operations (KBC 2014)" && <IndianArmedForces/>}
        {activeContent.title === "Space Science: Black Holes and Stars (KBC 2016)" && <BlackHoles/>}
        {activeContent.title === "The Enigma of Black Holes" && <BlackHoles/>}
        {activeContent.title === "Summits and Conferences in Current Affairs MCQs" && <SummitsandConferences/>}
        {activeContent.title === "Government Schemes [India & States]" && <GovernmentSchemes/>}
        {activeContent.title === "India-government-politics-current-affairs" && <Indiagovernment/>}
        {activeContent.title === "Indian Culture MCQs" && <IndianCulture/>}
        {activeContent.title === "Science & Technology Current Affairs MCQs" && <ScienceTechnologyCurrentAffairs/>}
        {activeContent.title === "Empress of India MCQs" && <EmpressofIndia/>}
        {activeContent.title === "World History MCQs" && <WorldHistory/>}
        {activeContent.title === "Environment & Biodiversity MCQs" && <EnvironmentBiodiversity/>}
        {activeContent.title === "Modern Indian History MCQs" && <ModernIndianHistory/>}
        {activeContent.title === "Fastest Finger First KBC" && <FastestFingerFirst/>}

        
      
        {activeContent.title === "Arrange Order Question" && <OrderQuizApp/>}
        {activeContent.title === "Arrange Order Question Level One" && <QuizArrangeLevel1/>}
        {activeContent.title === "Arrange Order Question Level Two" && <OrderQuizAppLevel2/>}
        {activeContent.title === "Arrange Order Question Level Three" && <OrderQuizAppLevel3/>}
        {activeContent.title === "Arrange Order Question Level Four" && <OrderQuizAppLevel4/>}
        {activeContent.title === "Arrange Order Question Level Five" && <OrderQuizAppLevel5/>}

        {activeContent.title === "Match Order Question level One" && <QuizmatchColumn/>}
        {activeContent.title === "Match Order Question level Two" && <QuizmatchColumnLevelTwo/>}
        {activeContent.title === "Match Order Question level Three" && <QuizmatchColumnLevelThree/>}
        {activeContent.title === "Match Order Question level Four" && <QuizmatchColumnLevelFour/>}
        {activeContent.title === "Match Order Question level Five" && <QuizmatchColumnLevelFive/>}
        {activeContent.title === "Match Order Question level Six" && <QuizmatchColumnLevelSix/>}


        {activeContent.title === "World Map with Country Area Tooltip" && <WorldMap/>}
        {activeContent.title === "Interactive India States Map" && <WorldMapStatewise/>}


        {activeContent.title === "Environment: Famous Environmentalists (KBC 2020)" && <FamousEnvironmentalists/>}

       
        
        
        
       
       
        
      </div>

    </div>
     {/* Render Popup if it's open */}
     {isPopupOpen && (
            <DashboardPopup 
              onClose={handlePopupClose} 
              onConfirm={handleConfirmNavigation} 
            />
          )}

  </>
   
  );
}

export default AppSideNavKBC;
