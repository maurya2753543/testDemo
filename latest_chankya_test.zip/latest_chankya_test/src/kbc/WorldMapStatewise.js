import React, { useState } from 'react';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';

// URL to fetch the India GeoJSON
const indiaGeoUrl = 'https://raw.githubusercontent.com/geohacker/india/master/state/india_telengana.geojson';

const IndiaMap = () => {
  const [tooltipContent, setTooltipContent] = useState('');
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const [isTooltipVisible, setTooltipVisible] = useState(false);

  // Function to handle mouse enter for tooltip
  const handleMouseEnter = (geo, event) => {
    const stateName = geo.properties.NAME_1; // State name from GeoJSON
    setTooltipContent(stateName);

    // Set tooltip position based on mouse coordinates
    setTooltipPosition({
      top: event.clientY + 10,
      left: event.clientX + 10,
    });

    setTooltipVisible(true); // Show the tooltip
  };

  // Hide tooltip when mouse leaves
  const handleMouseLeave = () => {
    setTooltipVisible(false);
  };

  return (
    <div style={{ position: 'relative', textAlign: 'center', padding: '20px' }}>
      <div style={{ textAlign: 'center', fontSize: '16px', fontWeight: 'bold', marginBottom: '10px' }}>
        <p>For better viewing, click to open the map in full screen or wide mode.</p>
      </div>
            <h2>India State Map</h2>

      <ComposableMap
        projection="geoMercator"
        projectionConfig={{ scale: 1000, center: [80, 22] }}
        width={800}
        height={600}
      >
        <Geographies geography={indiaGeoUrl}>
          {({ geographies }) =>
            geographies.map((geo) => (
              <Geography
                key={geo.rsmKey}
                geography={geo}
                onMouseEnter={(event) => handleMouseEnter(geo, event)}
                onMouseLeave={handleMouseLeave}
                style={{
                  default: {
                    fill: '#D6D6DA',
                    outline: 'none',
                  },
                  hover: {
                    fill: '#F53',
                    outline: 'none',
                  },
                  pressed: {
                    fill: '#E42',
                    outline: 'none',
                  },
                }}
              />
            ))
          }
        </Geographies>
      </ComposableMap>

      {/* Tooltip for showing state name */}
      {isTooltipVisible && (
        <div
          style={{
            position: 'absolute',
            top: tooltipPosition.top,
            left: tooltipPosition.left,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            color: '#fff',
            padding: '5px 10px',
            borderRadius: '5px',
            pointerEvents: 'none',
          }}
        >
          {tooltipContent}
        </div>
      )}
    </div>
  );
};

export default IndiaMap;
