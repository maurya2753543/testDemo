import React, { useState, useEffect } from "react";
import quizData from "./BasicEconomic.json";
import "../kbc-level-three/FamousEnvironmentalists.css";
import AppwriteService from '../../appwrite/AppwriteService';


const ChemistyKbc = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [quizStarted, setQuizStarted] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(30 * 60); // 30 minutes in seconds
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [name, setName] = useState('');

  const calculateLevel = () => {
    if (score < 20) return "Starter";
    if (score >= 20 && score < 30) return "Challenger";
    if (score >= 30 && score < 40) return "Master";
    return "Genius";
  };
  
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get();
        setName(user.name);
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  useEffect(() => {
    if (!quizStarted) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setShowResult(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [quizStarted]);

  const startQuiz = () => setQuizStarted(true);

  const handleAnswerSubmit = () => {
    const currentQuestion = quizData[currentQuestionIndex];
    if (currentQuestion.options[selectedAnswer]?.correct) {
      setScore(score + 1);
    } else {
      setWrongAnswers(wrongAnswers + 1);
    }
    setIsAnswerSubmitted(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    } else {
      setShowResult(true);
    }
  };

  const restartQuiz = () => {
    setQuizStarted(false);
    setCurrentQuestionIndex(0);
    setScore(0);
    setWrongAnswers(0);
    setShowResult(false);
    setTimeRemaining(30 * 60);
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  const progressPercentage = ((30 * 60 - timeRemaining) / (30 * 60)) * 100;

  if (!quizStarted) {
    return (
      <div className="quiz-start-container">
         <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="MuiCardContent-root dashboard-background">
          <div className="MuiPaper-root MuiCard-root MuiPaper-elevation1 MuiPaper-rounded" style={{ background: "transparent", borderBottom: "3px solid rgb(116, 130, 232)", marginBottom: "10px", backdropFilter: "blur(4px)" }}>
            <div>
              <h1 style={{ width: '100%', textWrap: 'nowrap', fontSize: '25px', fontWeight: "800", color: "rgb(85, 100, 204)", paddingTop: '40px', paddingLeft: '100px' }}>
                The Ultimate KBC Challenge!
              </h1>
            </div>
          </div>
          <div style={{ padding: "40px", width: '100%', textAlign: "center", marginTop: "3%", marginBottom: "5%", background: "transparent", backdropFilter: "blur(4px)" }}>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)' }} className="MuiTypography-root MuiTypography-h4">KBC Prep: Test Your Knowledge to Win Big!</h1>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontSize: '20px' }}>Quiz Bank: Answer Your Way to the Top!</p>
            <button className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary" onClick={startQuiz} style={{ marginTop: "10px", color: 'white', width: '80%', backgroundColor: '#3f51b5', fontSize: '16px', borderRadius: '5px' }}>
              <h3 className="MuiTypography-root MuiTypography-h6">LET'S GO</h3>
            </button>
          </div>
        </div>
      </div>      
      </div>
    );
  }

  if (showResult) {
    return (
        <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="main-multi-section">
          <div className="MuiCardContent-root dashboard-background">
            <h1 className="Game_over">GAME OVER</h1>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)' }}>Hi {name}, Your Score: {score}</h1>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
              Your Level: {calculateLevel()} 
            </p>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
            Correct Answers: {score}            </p>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
            Wrong Answers: {wrongAnswers}            </p>
            <button
              className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary"
              onClick={restartQuiz}
              style={{
                marginTop: "10px",
                marginBottom: '100px',
                color: 'white',
                width: '60%',
                backgroundColor: '#3f51b5',
                fontSize: '16px',
                borderRadius: '10px',
                marginLeft: '150px',
                height: '80px',
              }}
            >
              <h2 className="MuiTypography-root MuiTypography-h6">PLAY AGAIN</h2>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = quizData[currentQuestionIndex];

  return (
    <div className="quiz-container">
      <div className="timer-container">
        <div className="progress-bar" style={{ width: `${progressPercentage}%` }}></div>
        <p>Time Remaining: {formatTime(timeRemaining)}</p>
      </div>
      <div className="question-container">
        <h2>
          Question {currentQuestionIndex + 1}/{quizData.length}: {currentQuestion.question}
        </h2>
        <div className="options-container">
          {currentQuestion.options.map((option, index) => (
            <div key={index} className="option-item">
              <label>
                <input
                  type="radio"
                  style={{width : '10px'}}
                  name="option"
                  value={index}
                  checked={selectedAnswer === index}
                  onChange={() => setSelectedAnswer(index)}
                />
                {option.answer}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div className="button-container-levelthree">
  <button
    onClick={handleAnswerSubmit}
    className="button-three"
    disabled={selectedAnswer === null || isAnswerSubmitted}
  >
    Submit
  </button>
  <button
    className="button-three"
    onClick={handleNextQuestion}
    disabled={!isAnswerSubmitted}
  >
    Next
  </button>
  <button
    onClick={() => setShowResult(true)}
    className="end-quiz-button"
  >
    End Quiz
  </button>
</div>

    </div>
  );
};

export default ChemistyKbc;
