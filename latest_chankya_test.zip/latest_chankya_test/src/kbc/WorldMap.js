import React, { useState } from 'react';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';
import './WorldMap.css';  // Ensure you have a proper CSS file for styling

// GeoJSON URL for world map data
const geoUrl = "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson";

const WorldMap = () => {
  const [tooltipContent, setTooltipContent] = useState("");
  const [area, setArea] = useState("");
  const [coordinates, setCoordinates] = useState("");

  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const [isTooltipVisible, setTooltipVisible] = useState(false);

  const handleMouseEnter = (geo, event) => {
    const countryName = geo.properties.ADMIN;
    const countryArea = geo.properties.ISO_A3;
    const countryCoordinates = geo.geometry.coordinates[0][0]; // Take the first coordinate for positioning
 

    setTooltipContent(countryName);
    setArea(`Country Name: ${countryName}`);
    setCoordinates(`Coordinates: ${countryCoordinates[0]}, ${countryCoordinates[1]}`);
    setCoordinates(`ISO: ${countryArea}`);


    // Set tooltip position based on mouse coordinates
    setTooltipPosition({
      top: event.clientY + 10,  // Position tooltip just below mouse cursor
      left: event.clientX + 10, // Position tooltip just right of mouse cursor
    });

    setTooltipVisible(true);  // Show the tooltip
  };

  const handleMouseLeave = () => {
    setTooltipVisible(false);  // Hide the tooltip when mouse leaves
  };

  return (
    <div style={{ position: 'relative' , margin : '20px' , padding : '40px' }}>
       <div style={{ textAlign: 'center', fontSize: '16px', fontWeight: 'bold', marginBottom: '10px' }}>
        <p>For better viewing, click to open the map in full screen or wide mode.</p>
      </div>
      <h2 style={{justifyContent : 'center' ,display : 'flex'}}>Interactive World Map</h2>

      <ComposableMap projection="geoMercator">
        <Geographies geography={geoUrl}>
          {({ geographies }) =>
            geographies.map((geo) => (
              <Geography
                key={geo.rsmKey}
                geography={geo}
                onMouseEnter={(event) => handleMouseEnter(geo, event)}  // Mouse hover event
                onMouseLeave={handleMouseLeave}  // Hide tooltip when mouse leaves
                style={{
                  default: {
                    fill: "#D6D6DA",
                    outline: "none",
                  },
                  hover: {
                    fill: "#F53",
                    outline: "none",
                  },
                  pressed: {
                    fill: "#E42",
                    outline: "none",
                  },
                }}
              />
            ))
          }
        </Geographies>
      </ComposableMap>

      {/* Display Tooltip */}
      {isTooltipVisible && (
        <div
          className="tooltip"
          style={{
            backgroundColor: '#333', // Black background
            color: '#ffff', // White text
            padding: '10px',
            borderRadius: '5px',
            position: 'absolute',
            top: tooltipPosition.top,
            left: tooltipPosition.left,
            zIndex: 10,
            pointerEvents: 'none',  // Ensure the tooltip doesn't block map interaction
          }}
        >
          <div>
            <h4>{tooltipContent}</h4>
            <p>{area}</p>
            <p>{coordinates}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorldMap;
