import React, { useState, useEffect } from "react";
import MajorGlobalEvents from './MajorGlobalEvents.json';
import "../QuizCalculatorMultiChoice.css";
import AppwriteService from '../../appwrite/AppwriteService';
import { FaTimes, FaCheck } from 'react-icons/fa'; // Import icons for correct/incorrect feedback
const MajorGlobalEventsKbc = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [timeLeft, setTimeLeft] = useState(7200);
  const [quizStarted, setQuizStarted] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [showQuitConfirm, setShowQuitConfirm] = useState(false);
  const [name, setName] = useState('');
  const [questionOrder, setQuestionOrder] = useState([]);
  const [answeredQuestions, setAnsweredQuestions] = useState(new Set()); // Track answered questions

  const totalDuration = 7200;

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get();
        setName(user.name);
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  useEffect(() => {
    const order = Array.from({ length: MajorGlobalEvents.length }, (_, i) => i);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    setQuestionOrder(order);
  }, []);

  useEffect(() => {
    if (quizStarted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setShowResult(true);
    }
  }, [timeLeft, quizStarted]);

  const handleAnswerSubmit = () => {
    // Check if the question has already been answered
    const questionId = questionOrder[currentQuestionIndex];
    if (answeredQuestions.has(questionId)) {
      return; // Ignore if already answered
    }

    // Mark the question as answered
    answeredQuestions.add(questionId);
    setAnsweredQuestions(new Set(answeredQuestions)); // Update state

    if (MajorGlobalEvents[questionId].options[selectedAnswer].correct) {
      setScore(score + 1);
    } else {
      setWrongAnswers(wrongAnswers + 1);
    }

    if (currentQuestionIndex < questionOrder.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowResult(true);
    }

    setSelectedAnswer(null);
  };

  const startQuiz = () => setQuizStarted(true);
  
  const restartQuiz = () => {
    setQuizStarted(false);
    setCurrentQuestionIndex(0);
    setScore(0);
    setWrongAnswers(0);
    setAnsweredQuestions(new Set()); // Reset answered questions
    setTimeLeft(totalDuration);
    setShowResult(false);
    const order = Array.from({ length: MajorGlobalEvents.length }, (_, i) => i);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    setQuestionOrder(order);
  };
  
  const calculateLevel = () => {
    if (score < 20) return "Starter";
    if (score >= 20 && score < 30) return "Challenger";
    if (score >= 30 && score < 40) return "Master";
    return "Genius";
  };
  
  const handleQuitConfirm = () => setShowQuitConfirm(true);
  const handleQuitCancel = () => setShowQuitConfirm(false);

  const handleQuitOk = () => {
    setShowQuitConfirm(false);
    setShowResult(true);
  };

  if (!quizStarted) {
    return (  
      <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="MuiCardContent-root dashboard-background">
          <div className="MuiPaper-root MuiCard-root MuiPaper-elevation1 MuiPaper-rounded" style={{ background: "transparent", borderBottom: "3px solid rgb(116, 130, 232)", marginBottom: "10px", backdropFilter: "blur(4px)" }}>
            <div>
              <h1 style={{ width: '100%', textWrap: 'nowrap', fontSize: '25px', fontWeight: "800", color: "rgb(85, 100, 204)", paddingTop: '40px', paddingLeft: '100px' }}>
                The Ultimate KBC Challenge!
              </h1>
            </div>
          </div>
          <div style={{ padding: "40px", width: '100%', textAlign: "center", marginTop: "3%", marginBottom: "5%", background: "transparent", backdropFilter: "blur(4px)" }}>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)' }} className="MuiTypography-root MuiTypography-h4">KBC Prep: Test Your Knowledge to Win Big!</h1>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontSize: '20px' }}>Quiz Bank: Answer Your Way to the Top!</p>
            <button className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary" onClick={startQuiz} style={{ marginTop: "10px", color: 'white', width: '80%', backgroundColor: '#3f51b5', fontSize: '16px', borderRadius: '5px' }}>
              <h3 className="MuiTypography-root MuiTypography-h6">LET'S GO</h3>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showResult) {
    return (
      <div className="MuiPaper-root MuiCard-root widget-container MuiPaper-elevation1 MuiPaper-rounded">
        <div className="main-multi-section">
          <div className="MuiCardContent-root dashboard-background">
            <h1 className="Game_over">GAME OVER</h1>
            <h1 style={{ marginTop: "10px", color: 'rgb(116, 130, 232)' }}>Hi {name}, Your Score: {score}</h1>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
              Your Level: {calculateLevel()} 
            </p>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
            Correct Answers: {score}            </p>
            <p style={{ marginTop: "10px", color: 'rgb(116, 130, 232)', fontWeight: '700', marginLeft: '220px', fontSize: '18px' }}>
            Wrong Answers: {wrongAnswers}            </p>
            <button
              className="MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary"
              onClick={restartQuiz}
              style={{
                marginTop: "10px",
                marginBottom: '100px',
                color: 'white',
                width: '60%',
                backgroundColor: '#3f51b5',
                fontSize: '16px',
                borderRadius: '10px',
                marginLeft: '150px',
                height: '80px',
              }}
            >
              <h2 className="MuiTypography-root MuiTypography-h6">PLAY AGAIN</h2>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = MajorGlobalEvents[questionOrder[currentQuestionIndex]];
  const progressPercentage = (timeLeft / totalDuration) * 100;
  let timerColor;
  let timerBackgroundColor;

  if (timeLeft > 1800) { // More than 30 minutes
    timerColor = "#BCB6E2";
    timerBackgroundColor = "#2962FF"; // Light blue background
  } else if (timeLeft > 300) { // Between 30 minutes and 5 minutes
    timerColor = "#BCB6E2";
    timerBackgroundColor = "darkorange"; // Orange background
  } else { // Less than 5 minutes
    timerColor = "red";
    timerBackgroundColor = "red"; // Red background
  }

  return (
    <div className="quiz-container">
       {/* Quit Button */}
       <button
        className="quit-button" // Add styles for positioning and appearance
        onClick={handleQuitConfirm}
        style={{ position: "absolute",
           top: "100px", right: "20px",
            fontSize: "16px", 
            padding : '10px',
            background : 'red',
            color: 'white',
            borderRadius : '5px',            
            fontWeight: "bold",
            border : 'none'
           }}
      >
        Quit Quiz
      </button>

      {/* Quit Confirmation Popup */}
      {showQuitConfirm && (
        <div className="quit-confirm-overlay">
          <div className="quit-confirm-box">
            <p>Are you sure you want to quit the quiz?</p>
            <button style={{background : 'blue'}} onClick={handleQuitOk}>OK</button>
            <button onClick={handleQuitCancel}>Cancel</button>
          </div>
        </div>
        
      )}

 {/* Add CSS styles for the popup */}
 <style jsx>{`
        .quit-confirm-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
          display: flex;
          justify-content: center;         
          align-items: center;
          z-index: 1000; /* Ensure it's above other elements */
        }

        .quit-confirm-box {
          background-color: white;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
          text-align: center;
        }

        .quit-confirm-box p {
          margin-bottom: 20px;
          margin-left : 50px;
        }

        .quit-confirm-box button {
          margin: 0 10px;
          padding: 10px 15px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          background-color: red; /* Light gray on hover */
          color : white;
        }

        .quit-confirm-box button:hover {
          background-color: red; /* Light gray on hover */
          color : 'white';
        }
      `}</style>
      <div className="multiple-title-MajorGlobalEvents">
       <h1>Fastest Finger First</h1>
       <h5>Note: Your score will be calculated only when you submit the quiz. You can review your answers before final submission. Make sure to check each option carefully, as the calculation of the final score happens after you submit. Good luck!</h5>

      </div>
      <div style={{ position: "relative", marginTop: "50px" }}>
        <div>
          <div className="MuiLinearProgress-root MuiLinearProgress-colorPrimary MuiLinearProgress-determinate" style={{ height: "10px", backgroundColor: timerColor }}>
            <div
              className="MuiLinearProgress-bar MuiLinearProgress-barColorPrimary MuiLinearProgress-bar1Determinate"
              style={{
                width: `${progressPercentage}%`, // Ensure the width decreases as timeLeft decreases
                transition: "width 1s linear", // Smooth transition when the width changes
                backgroundColor: "#3f51b5", // Progress bar color
                height: "100%",
                borderRadius: "5px",
              }}
            ></div>
          </div>
        </div>
        <div
          style={{
            position: "absolute",
            marginTop: "10px",
            right: "20px",
            top: "-50px",
            zIndex: "10",
            fontSize: "24px",
            fontWeight: "bold",
            color: "white",
            lineHeight: "5px",
            backgroundColor: timerBackgroundColor,
            padding: "5px",
            borderRadius: "5px",
            boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
          }}
        >
          <h3>{`${Math.floor(timeLeft / 60)}:${timeLeft % 60 < 10 ? "0" : ""}${timeLeft % 60}`}</h3>
        </div>
      </div>

      
      <div style={{marginTop : '60px'}} className="multiple-title-MajorGlobalEvents">
        <p>{currentQuestionIndex + 1}: {currentQuestion.question}</p>
      </div>

     <div  style={{marginTop : '60px'}} className="options-grid">
  {currentQuestion.options.map((option, index) => (
    <label key={index} className={`option-item ${selectedAnswer === index ? 'selected' : ''}`}>
      <input
        type="radio"
        name="quiz-option"
        checked={selectedAnswer === index}
        onChange={() => setSelectedAnswer(index)}
        style={{ display: 'none' }} // Hide the default radio button
      />
      {/* Display A, B, C, D with spacing */}
      <span className="option-label" style={{ marginRight: '8px' }}>
        {String.fromCharCode(65 + index)}.
      </span>
      {option.answer}
      {selectedAnswer === index && (
        <span style={{ marginLeft: '10px' }}>
          {option.correct ? <FaCheck color="green" /> : <FaTimes color="red" />}
        </span>
      )}
    </label>
  ))}
</div>

      <div className="submit-container">
        <button
          className="submit-button"
          onClick={handleAnswerSubmit}
          disabled={selectedAnswer === null} // Disable button if no answer is selected
        >
 Submit → Next   
      </button>
      </div>
    </div>
  );
};

export default MajorGlobalEventsKbc;
