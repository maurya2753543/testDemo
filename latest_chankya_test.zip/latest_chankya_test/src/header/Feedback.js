import React from 'react';
import './Feedback.css'; // Assuming you will create custom styles in this file
import student4 from '../images/student4.jpeg';
import student5 from '../images/student5.jpeg';
import student6 from '../images/student6.jpeg';


const testimonials = [
  {
    id: 1,
    quote: "I recently enrolled my child in the math classes offered, and I couldn't be more pleased with the results. The lessons are engaging, well-structured, and tailored to meet each student's unique needs and skill levels. ",
    author: "Suchita Maurya",
    designation: "Noida 62",
    image: student4
  },
  {
    id: 2,
    quote: "The instructor’s ability to simplify complex concepts and break them down into easy-to-understand steps has significantly boosted my child’s confidence in math!. does an amazing job in interacting with kids. I never expected my kid to be so happy!",
    author: "Neha Patel",
    designation: "Sector 44, Gurugram",
    image: student5
  },
  {
    id: 3,
    quote: "I think the magic of Super memory course is this whole system, nicely designed interesting questions, asking students to make videos, giving great feedback. It creates a positive spiral of confidence, enjoyment & extra effort in your students.",
    author: "Sonu Vath",
    designation: "Delhi",
    image: student6
  }
];

const Feedback = () => {
  return (
    <>
<div className="feedback-main">
<h1 class="qubely-block-text-title-feedback">What Do Parents Say About Chanakya Classes?</h1>
<div className="feedback-container">
      <div className="feedback-row">
        {testimonials.map((testimonial) => (
          <div key={testimonial.id} className="feedback-card">
            <div className="card-body">
              <div className="testimonial-quote">
                <i className="fas fa-quote-left"></i>
              </div>
              <div className="testimonial-content">
                <p><em>{testimonial.quote}</em></p>
              </div>
              <div className="testimonial-author d-flex align-items-center">
                <img
                  className="testimonial-avatar"
                  src={testimonial.image}
                  alt={testimonial.author}
                />
                <div className="author-info">
                  <div className="author-name">{testimonial.author}</div>
                  <div className="author-designation">{testimonial.designation}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
</div>
  
    </>
  
  );
};

export default Feedback;
