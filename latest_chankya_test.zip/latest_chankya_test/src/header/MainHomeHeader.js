import React from 'react';
import { Link } from 'react-router-dom';
import './MainHomeHeader.css';
import logo from '../images/Designer-modified.png';


const MainHomeHeader = () => {
  return (
    <>
      <header id="masthead" className="site-header-header header-transparent disable-sticky">
        <div className="container-fluid">
          <div className="navbar-row d-flex align-items-center justify-content-between">
            <div className="logo-wrapper">
              <Link className="skillate-navbar-brand" to="/">
              <img
        className="enter-logo img-responsive"
        src={logo}
        alt="Logo"
        title="Logo"
      />
              </Link>
            </div>

            <div className="menu-center">
              <Link style={{ textDecoration: 'none' }}  to="/">
                <h2 style ={{marginLeft : '30px' }}className="Home_lable">Home</h2>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="row m-0" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%' }}>
        <div className="col-12 container-cover" style={{ width: '100%', maxWidth: '600px', marginBottom: '0px' }}>
          <img
            src="https://www.profved.com/static/media/profvedvedant2.4707a77f.webp"
            alt="Demo class booking"
            style={{ width: '100%', height: 'auto', objectFit: 'contain', maxWidth: '100%' }}
          />
        </div>

        <div className="col-12 p-0 form-container" style={{ width: '100%', maxWidth: '600px', padding: '0px 20px', boxSizing: 'border-box' }}>
          <div className="onboarding-form animate__animated animate__faster">
            <div>
              <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                <h1
                  style={{
                    fontSize: '2.5rem',
                    fontWeight: 'bold',
                    background: 'linear-gradient(to right, rgb(255, 111, 97), rgb(222, 60, 222)) text',
                    color: 'transparent',
                    textShadow: 'rgba(0, 0, 0, 0.2) 2px 2px 8px',
                    animation: '2s ease-out 0s 1 normal none running fadeIn',
                  }}
                >
                  Make your child a math genius!
                </h1>
                <span
                  style={{
                    fontSize: '1.2rem',
                    color: 'rgb(51, 51, 51)',
                    letterSpacing: '0.05em',
                    textTransform: 'uppercase',
                    textShadow: 'rgba(0, 0, 0, 0.2) 1px 1px 4px',
                    marginTop: '10px',
                    animation: '2.5s ease-out 0s 1 normal none running fadeIn',
                    borderBottom: '2px solid rgb(255, 111, 97)',
                    display: 'inline-block',
                    paddingBottom: '5px',
                  }}
                >
                </span>
              </div>
            
            </div>
          </div>
        </div>
      </div>

      {/* CSS for vertical line */}
      
    </>
  );
};

export default MainHomeHeader;
