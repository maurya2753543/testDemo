import React, { useState } from 'react';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa'; // Close button icon
import LoginPopup from './LoginPopup';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AppwriteService from '../appwrite/AppwriteService';

// Styled Components
const ModalWrapper = styled.div`
  position: fixed;
  top: 0;
  right: 0;
  width: 400px;
  height: 100vh;
  background-color: #fff;
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
  padding: 20px;
  overflow-y: auto;
`;

const ModalContent = styled.div`
  position: relative;
  padding: 10px 15px;
`;

const CloseButton = styled(FaTimes)`
  position: absolute;
  top: -5px;
  right: 10px;
  cursor: pointer;
  background-color: #ff5248;
  color: white;
  padding: 8px;
  border-radius: 20px;
  font-weight: 700;
`;

const Title = styled.h2`
  font-size: 30px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 700;
  line-height: 27px;
  color: #1f2949;
`;

const Subtitle = styled.h4`
  font-size: 16px;
  margin-bottom: 20px;
  color: black;
  a {
    color: #ff5248;
    cursor: pointer;
    text-decoration: none;  /* Removes the underline */
  }
`;

const RegisterForm = styled.form`
  display: flex;
  flex-direction: column;
  input {
    margin-bottom: 20px;
    padding: 15px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  button {
    padding: 15px;
    background-color: #ff5248;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    font-weight: 700;
    font-size: 18px;
    margin-top: 25px;
  }
`;

const SignUp = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    nickname: '',
    phone: '',
    email: '',
    password: '',
  });

  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [title, setTitle] = useState('Sign Up'); // Default title

  const appwriteService = new AppwriteService(); // Initialize Appwrite service

  const openLogin = () => setIsLoginOpen(true);
  const closeLogin = () => setIsLoginOpen(false);

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);
  const validatePhoneNumber = (phone) => /^[0-9]{10}$/.test(phone);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateEmail(formData.email)) {
      toast.error('Invalid email format!');
      return;
    }

    if (!validatePhoneNumber(formData.phone)) {
      toast.error('Invalid phone number! Must be 10 digits.');
      return;
    }

    try {
      // Call Appwrite to create an account
      await appwriteService.createAccount({
        email: formData.email,
        password: formData.password,
        name: formData.nickname,
      });

     
      toast.success('Registration successful! You can log in now.');
      setFormData({
        nickname: '',
        phone: '',
        email: '',
        password: '',
      });

    } catch (error) {
      toast.error('Error: ' + error.message);
    }
  };

  return (
    <>
      <ModalWrapper isOpen={isOpen}>
        <ModalContent>
          <CloseButton onClick={onClose} />
          <Title>{title}</Title>
          <Subtitle>
            Already have an account? <a onClick={openLogin}>Sign In</a>
          </Subtitle>

          <RegisterForm onSubmit={handleSubmit}>
            <input
              type="text"
              name="nickname"
              placeholder="Full Name"
              value={formData.nickname}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="phone"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleInputChange}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleInputChange}
            />
            <button style={{width : '80%' , marginLeft : '10px'}} type="submit">Register Now</button>
          </RegisterForm>
        </ModalContent>
      </ModalWrapper>
      <LoginPopup isOpen={isLoginOpen} onClose={closeLogin} />
      <ToastContainer />
    </>
  );
};

export default SignUp;
