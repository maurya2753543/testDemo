import React, { useState } from "react";
import AppwriteService from "../appwrite/AppwriteService";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "./MainHomeForm.css";
import DashboardTopHeader from "../comman-header/Dashbord-header";
import Footer from "../footer/Footer";
import ClipLoader from "react-spinners/ClipLoader"; // Importing a loading spinner

const FormComponent = () => {
    const [formData, setFormData] = useState({
        phoneNumber: "",
        parentFirstName: "",
        parentLastName: "",
        gender: "",
        email: "",
        childName: "",
        grade: "",
        timezone: "",
        selectedDate: "",
        selectedTime: "",
        consentGiven: false,
    });

    const [selectedDate, setSelectedDate] = useState("");
    const [selectedTime, setSelectedTime] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const appwriteService = new AppwriteService(); // Initialize Appwrite service

    // Example of available dates and times
    const dates = ["2024-10-22", "2024-10-23", "2024-10-24"]; // Replace with actual dates
    const times = ["10:00 AM", "11:00 AM", "12:00 PM"]; // Replace with actual times

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value,
        });
    };

    const handleDateSelect = (date) => {
        setSelectedDate(date);
        setFormData({ ...formData, selectedDate: date });
    };

    const handleTimeSelect = (time) => {
        setSelectedTime(time);
        setFormData({ ...formData, selectedTime: time });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!selectedDate || !selectedTime) {
            toast.error("Please select both a date and a time.");
            return;
        }

        setIsSubmitting(true);

        try {
            await appwriteService.saveFormData(formData); // Save the form data
            toast.success("Data saved successfully!"); // Show success message
            setFormData({
                phoneNumber: "",
                parentFirstName: "",
                parentLastName: "",
                gender: "",
                email: "",
                childName: "",
                grade: "",
                timezone: "",
                selectedDate: "",
                selectedTime: "",
                consentGiven: false,
            }); // Reset form
            setSelectedDate("");
            setSelectedTime("");
        } catch (error) {
            toast.error("Failed to save data: " + error.message); // Show error message
            console.error("Error saving data:", error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <>
            <ToastContainer /> {/* Include the ToastContainer for toast notifications */}

            <div className="Top-header-dashboard">
                <DashboardTopHeader username="Username" avatarUrl="https://secure.gravatar.com/avatar/f72172a0cf3d814741f44ae012b5cbe5?s=150&d=mm&r=g" />
            </div>

            <div className="form-card">
                <form onSubmit={handleSubmit}>
                    {/* Phone Number and Parent First Name */}
                    <div className="row1">
                        <div className="column" style={{ width: '20%', position: 'relative' }}>
                            <label>Code</label>
                            <select name="countryCode" onChange={handleChange}>
                                <option value="+19">IN (+91)</option>
                            </select>
                            <div className="vertical-separator" />
                        </div>
                        <div className="column" style={{ width: '78%' }}>
                            <label>Phone Number*</label>
                            <input
                                type="text"
                                name="phoneNumber"
                                value={formData.phoneNumber}
                                onChange={handleChange}
                                placeholder="Enter 10 digits phone number"
                                required
                            />
                        </div>
                    </div>

                    {/* Parent First Name and Last Name */}
                    <div className="row1">
                        <div className="column">
                            <label>Parent First Name*</label>
                            <input
                                type="text"
                                name="parentFirstName"
                                value={formData.parentFirstName}
                                onChange={handleChange}
                                placeholder="Enter First Name"
                                required
                            />
                        </div>
                        <div className="column">
                            <label>Parent Last Name*</label>
                            <input
                                type="text"
                                name="parentLastName"
                                value={formData.parentLastName}
                                placeholder="Enter Last Name"
                                onChange={handleChange}
                                required
                            />
                        </div>
                    </div>

                    {/* Gender and Email */}
                    <div className="row1">
                        <div className="column" style={{ width: '20%', position: 'relative' }}>
                            <label>Gender</label>
                            <select name="gender" value={formData.gender} onChange={handleChange}>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <div className="vertical-separator" />
                        </div>
                        <div className="column" style={{ width: '78%' }}>
                            <label>Email Address*</label>
                            <input
                                type="email"
                                name="email"
                                placeholder="Email address"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    </div>

                    {/* Child's Name and Grade */}
                    <div className="row1">
                        <div className="column" style={{ width: '78%' }}>
                            <label>Your Child's Name*</label>
                            <input
                                type="text"
                                name="childName"
                                value={formData.childName}
                                placeholder="Enter your child's name"
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="column" style={{ width: '20%', position: 'relative' }}>
                            <label>Grade</label>
                            <select name="grade" value={formData.grade} onChange={handleChange}>
                                <option value="">Select Grade</option>
                                {Array.from({ length: 10 }, (_, i) => (
                                    <option key={i + 1} value={i + 1}>
                                        {i + 2}
                                    </option>
                                ))}
                                <option key="kbc" value="KBC">KBC</option>
                            </select>
                            <div className="vertical-separator" />
                        </div>
                    </div>

                    {/* Timezone */}
                    <div className="row1">
                        <div className="column" style={{ width: '100%', position: 'relative' }}>
                            <label>Timezone</label>
                            <select name="timezone" value={formData.timezone} onChange={handleChange}>
                                <option value="">Select Timezone</option>
                                <option value="IST">Indian Standard Time (IST)</option>
                                <option value="PST">Pacific Standard Time (PST)</option>
                                <option value="MST">Mountain Standard Time (MST)</option>
                                <option value="CST">Central Standard Time (CST)</option>
                                <option value="EST">Eastern Standard Time (EST)</option>
                            </select>
                            <div className="vertical-separator" />
                        </div>
                    </div>

                    {/* Date Selection */}
                    <div className="date-row1">
                        <label>Pick a Date</label>
                        <div className="date-grid">
                            {dates.map((date, index) => (
                                <div
                                    key={index}
                                    className={`date-box ${selectedDate === date ? "selected" : ""}`}
                                    onClick={() => handleDateSelect(date)}
                                >
                                    {date}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Time Selection */}
                    <div className="time-row1">
                        <label>Pick a Time</label>
                        <div className="time-grid">
                            {times.map((time, index) => (
                                <div
                                    key={index}
                                    className={`time-box ${selectedTime === time ? "selected" : ""}`}
                                    onClick={() => handleTimeSelect(time)}
                                >
                                    {time}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Consent Checkbox */}
                    <div className="row1">
                        <div className="column" style={{ width: '100%' }}>
                            <input
                                type="checkbox"
                                name="consentGiven"
                                checked={formData.consentGiven}
                                onChange={handleChange}
                                required
                            />
                            <label>I give my consent to collect this data</label>
                        </div>
                    </div>

                    {/* Submit Button */}
                    <button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? (
                            <ClipLoader size={15} color="#ffffff" /> // Spinner for loading state
                        ) : (
                            "Submit"
                        )}
                    </button>
                </form>
            </div>

            <Footer />
        </>
    );
};

export default FormComponent;
