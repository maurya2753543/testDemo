import React, { useState } from 'react';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa'; // Close button icon
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AppwriteService from '../appwrite/AppwriteService';

// Styled Components
const ModalWrapper = styled.div`
  position: fixed;
  top: 0;
  right: 0;
  width: 400px;
  height: 100vh;
  background-color: #fff;
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
  padding: 20px;
  overflow-y: auto;
`;

const ModalContent = styled.div`
  position: relative;
  padding: 10px 15px;
`;

const CloseButton = styled(FaTimes)`
  position: absolute;
  top: -5px;
  right: 10px;
  cursor: pointer;
  background-color: #ff5248;
  color: white;
  padding: 8px;
  border-radius: 20px;
  font-weight: 700;
`;

const Title = styled.h2`
  font-size: 30px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 700;
  line-height: 27px;
  color: #1f2949;
`;

const Subtitle = styled.h4`
  font-size: 16px;
  margin-bottom: 20px;
  color: black;
  a {
    color: #ff5248;
    cursor: pointer;
    text-decoration: none;
  }
`;

const ForgetPasswordForm = styled.form`
  display: flex;
  flex-direction: column;
  input {
    margin-bottom: 20px;
    padding: 15px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  button {
    padding: 15px;
    background-color: #ff5248;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    font-weight: 700;
    font-size: 18px;
    margin-top: 25px;
    width: 80%;
    margin-left: 10px;
  }
`;

const ForgetPassword = ({ isOpen, onClose }) => {
  const [userEmail, setUserEmail] = useState('');
  const appwriteService = new AppwriteService(); // Initialize Appwrite service

  const handleForgetPassword = async (e) => {
    e.preventDefault();
    if (userEmail.trim() && userEmail.includes('@')) {
      try {
        await appwriteService.sendPasswordRecovery(
          userEmail,
          'http://localhost:3000/reset-password'
        );
        toast.success('Email has been sent!');
        setUserEmail(''); // Clear the email input after success
      } catch (error) {
        toast.error('An error occurred. Please try again later.');
        console.error(error);
      }
    } else {
      toast.error('Please enter a valid email!');
    }
  };

  return (
    <>
      <ModalWrapper isOpen={isOpen}>
        <ModalContent>
          <CloseButton onClick={onClose} />
          <Title>Password Recovery</Title>
        

          <ForgetPasswordForm onSubmit={handleForgetPassword}>
            <input
              type="email"
              name="email"
              placeholder="example@domain.com"
              value={userEmail}
              onChange={(e) => setUserEmail(e.target.value)}
            />
            <button type="submit">Reset Password</button>
          </ForgetPasswordForm>
        </ModalContent>
      </ModalWrapper>
      <ToastContainer />
    </>
  );
};

export default ForgetPassword;
