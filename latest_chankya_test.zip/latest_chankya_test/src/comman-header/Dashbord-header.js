import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import StickyButton from '../header/StickyButton';
import LoginPopup from '../header/LoginPopup';
import SignUp from '../header/Registration';
import AppwriteService from '../appwrite/AppwriteService'; // Import AppwriteService
import styled from 'styled-components';
import './Dashbord-header.css';
import ClipLoader from "react-spinners/ClipLoader"; // Import the loader
import logo from '../images/Designer-modified.png';


const NavbarWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 20px;
  background-color: #333;
  color: white;
`;

const DropdownMenu = styled.div`
  position: absolute;
  top: 60px;
  right: 40px;
  width: 200px;
  background-color: white;
  color: black;
  border-radius: 3px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  display: ${(props) => (props.show ? 'block' : 'none')};
  z-index: 10;

  div {
    padding: 9px 30px;
    cursor: pointer;

    &:hover {
      background-color: rgba(0, 0, 0, 0.05);
    }
  }
`;

const ProfileIcon = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background-color: red;
  color: white;
  font-weight: bold;
  border-radius: 50%;
  cursor: pointer;
  font-size: 16px; /* Adjusted font size */
  text-transform: uppercase;
`;

const Dashboard_Header = ({ onTabClick }) => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [loading, setLoading] = useState(true); // State for loader

  const [userProfile, setUserProfile] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phoneNumber: '',
    bio: '',
    registrationDate: ''
  });
  const [userInitials, setUserInitials] = useState(''); // State to store user initials
  const navigate = useNavigate();
  

  useEffect(() => {
    const fetchUserProfile = async () => {
      setLoading(true); // Show loader before fetching
      try {
        const appwriteService = new AppwriteService();
        const user = await appwriteService.account.get(); // Fetch the current user's data

        const firstName = user.name.split(' ')[0] || ''; // Get first name from user.name
        const lastName = user.name.split(' ')[1] || ''; // Get last name from user.name

        setUserProfile({
          registrationDate: new Date(user.$createdAt).toLocaleString(),
          firstName,
          lastName,
          username: user.prefs?.username || '', // Optional username from preferences
          email: user.email || '',
          phoneNumber: user.prefs?.phoneNumber || 'Not Provided', // Optional phone number from preferences
          bio: user.prefs?.bio || 'Not Provided' // Optional bio from preferences
        });

        // Combine initials
        const initials = `${firstName.charAt(0).toUpperCase()}${lastName.charAt(0).toUpperCase()}`;
        setUserInitials(initials); // Set the initials for display in the profile icon

      } catch (error) {
        console.error("Error fetching user profile:", error);
      } finally {
        setLoading(false); // Hide loader after fetching
      }
    };

    fetchUserProfile();
  }, []);


  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  const handleNavigation = (route) => {
    onTabClick(route);  // Invoke the function passed from TabLayout
    setIsDropdownOpen(false); // Close dropdown
  };

  const handleLogout = async () => {
    try {
      const appwriteService = new AppwriteService();
      await appwriteService.logout();
      navigate('/'); // Redirect to homepage after logout
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  return (
    <>
      <header id="masthead" className="site-header-header header-transparent disable-sticky">
        <div className="container-fluid">
          <div className="navbar-row d-flex align-items-center justify-content-between">
            <div className="logo-wrapper">
              <Link className="skillate-navbar-brand" to="/">
              <img
        className="enter-logo img-responsive"
        src={logo}
        alt="Logo"
        title="Logo"
      />
              </Link>
            </div>

            <div className="menu-center">
              <ul id="menu-main-menu" className="nav">
                <li className="menu-item">
                  <Link to="/score-dashbord">SCORE TRACKER</Link>
                </li>
                <li className="menu-item">
                  <Link to="/dashboard">DASHBOARD</Link>
                </li>
              </ul>
            </div>

            <div className="skillate-header-cart mr-lg-2 d-none d-lg-inline-block">
              <div id="site-header-cart" className="site-header-cart menu">
                <span className="cart-icon">
                  <img
                    src="https://www.profved.com/wp-content/themes/skillate/images/cart-icon.svg"
                    alt="Cart Icon"
                  />
                  <a className="cart-contents" href="#modal-cart" title="View your shopping cart">
                    <span className="count">0</span>
                  </a>
                </span>
              </div>
            </div>

            <div className="d-flex align-items-center right-section">
              {/* Profile Icon showing initials */}
              <ProfileIcon onClick={toggleDropdown} >
                {userInitials} {/* Display user initials here */}
              </ProfileIcon>

              <DropdownMenu show={isDropdownOpen} >
                <div onClick={() => handleNavigation('profile')}>My Profile</div>
                <div onClick={() => handleNavigation('enrolled-courses')}>Enrolled Courses</div>
                <div onClick={() => handleNavigation('wishlist')}>Wishlist</div>
                <div onClick={() => handleNavigation('reviews')}>Reviews</div>
                <div onClick={() => handleNavigation('my-quiz-attempts')}>My Quiz Attempts</div>
                <div onClick={() => handleNavigation('purchase-history')}>Purchase History</div>
                <div onClick={() => handleNavigation('settings')}>Settings</div>
                <div onClick={handleLogout}>Logout</div> {/* Logout Button */}
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Show loader while loading is true */}
      {loading ? (
        <div className="loader-container">
          <ClipLoader color={"#36d7b7"} loading={loading} size={50} />
        </div>
      ) : (
        <>
          {!isLoginOpen && !isSignUpOpen && <StickyButton />}
          <LoginPopup isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
          <SignUp isOpen={isSignUpOpen} onClose={() => setIsSignUpOpen(false)} />
        </>
      )}
    </>
  );
};

export default Dashboard_Header;
