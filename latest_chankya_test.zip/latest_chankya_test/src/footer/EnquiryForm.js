import React, { useState } from 'react';
import './EnquiryForm.css'; // Import the CSS file for styling
import { toast, ToastContainer } from 'react-toastify'; // Import toastify
import 'react-toastify/dist/ReactToastify.css'; // Import toastify styles
import emailjs from 'emailjs-com'; // Import emailjs

const EnquiryForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    productName: '',
    casNo: '',
    quantity: '',
    specification: ''
  });

  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Basic validation
    if (!formData.name || !formData.email || !formData.phone || !formData.productName) {
      setError('Please fill out all required fields.');
      return;
    }

    // Prepare email parameters
    const templateParams = {
      to_name: 'Recipient Name', // You can dynamically set this if needed
      user_name: formData.name,
      user_email: formData.email,
      user_phone: formData.phone,
      product_name: formData.productName,
      cas_no: formData.casNo,
      quantity: formData.quantity,
      specification: formData.specification
    };

    // EmailJS service
    emailjs.send('service_ndzw3dp', 'template_tl6z14d', templateParams, 'j9IeoZw8w6Mkpkxl6')
      .then((response) => {
        console.log('Email sent successfully!', response);
        toast.success('Form submitted successfully!');
        setFormData({
          name: '',
          email: '',
          phone: '',
          productName: '',
          casNo: '',
          quantity: '',
          specification: ''
        });
        setError('');
      })
      .catch((error) => {
        console.error('Error sending email:', error);
        toast.error('Failed to submit the form. Please try again.');
        setError('');
      });
  };

  return (
    <>
      <ToastContainer />
      <div className="enquiry-form-container">
        <div className="enquiry-inner">
          <div className="enquiry-title">ENQUIRE WITH US</div>
          <br />
          <form className="subscribe-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <input
                  type="text"
                  name="name"
                  className="textbox"
                  placeholder="YOUR NAME *"
                  value={formData.name}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  name="email"
                  className="textbox"
                  placeholder="EMAIL*"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <input
                  type="tel"
                  name="phone"
                  className="textbox"
                  placeholder="PHONE*"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <input
                  type="text"
                  name="productName"
                  className="textbox"
                  placeholder="Course NAME *"
                  value={formData.productName}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  name="casNo"
                  className="textbox"
                  placeholder="Course Id"
                  value={formData.casNo}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  name="quantity"
                  className="textbox"
                  placeholder="Grade"
                  value={formData.quantity}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-row full-width">
              <textarea
                rows="5"
                name="specification"
                className="textarea"
                placeholder="SPECIFICATION"
                value={formData.specification}
                onChange={handleChange}
              ></textarea>
            </div>
            <div className="button-container">
              <button type="submit" className="submit-button">Send</button>
            </div>
            {error && <span className="error alert-message">{error}</span>}
          </form>
        </div>
      </div>
    </>
  );
};

export default EnquiryForm;
